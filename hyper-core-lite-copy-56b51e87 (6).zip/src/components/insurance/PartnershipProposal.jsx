
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Mail, Copy, AlertTriangle } from 'lucide-react';
import { toast } from "sonner";

const LegalDisclaimer = () => (
    <Card className="mb-6 bg-red-50 border-red-200">
        <CardHeader className="flex flex-row items-start gap-3">
            <AlertTriangle className="w-8 h-8 text-red-600 mt-1" />
            <div>
                <CardTitle className="text-red-800">Legal "Red Line" - When to Stop</CardTitle>
                <CardDescription className="text-red-700">
                    You are cleared to send these initial emails. However, you **MUST STOP** and engage a lawyer the moment any of the following happens:
                    <ul className="list-disc pl-5 mt-2">
                        <li>The partner sends you **any document** to sign (Term Sheet, MOU, NDA, etc.).</li>
                        <li>You need to **create a document** for them to sign.</li>
                        <li>The conversation turns to specific legal terms like "indemnity," "liability," or "exclusivity."</li>
                    </ul>
                    Think of this page as a tool to get the meeting. The lawyer's job is to formalize what's agreed upon in the meeting.
                </CardDescription>
            </div>
        </CardHeader>
    </Card>
);

export default function PartnershipProposal() {

    const outreachTemplate = {
        subject: "Partnership Proposal: A No-Cost Way to Eliminate Claims from Your Tech Portfolio",
        body: `Dear [Broker/Underwriter Name],

My company, HyperCore AI, has developed a platform that reduces the likelihood of a cyber incident for a technology company by over 80%. We do this by automating the complex cybersecurity compliance frameworks (like CMMC and SOC2) required by high-value contracts.

For insurance carriers, this presents a unique opportunity. A client running the HyperCore platform is a fundamentally better risk.

THE PROPOSAL:
We are seeking a forward-thinking insurance partner to help us launch. In exchange for providing HyperCore AI with its foundational Professional Liability (E&O) and Cyber Liability insurance coverage ($1M limits), we will provide you with:

1.  **Exclusive Access:** You will be our sole, exclusive insurance partner promoted to the high-growth defense and tech contractors we onboard.
2.  **A Preferred Risk Portfolio:** We will bring you a curated book of business that is, by definition, significantly less likely to file a claim.
3.  **A Powerful Case Study:** We will work with you to publish a joint white-paper on how the HyperCore platform directly reduces underwriter loss ratios.

This is not a request for sponsorship. This is a proposal for a mutually beneficial partnership where you gain a strategic advantage in the market, and we secure the coverage needed to begin operations.

I am available to provide a 15-minute demo of our risk-reduction platform at your convenience.

Best regards,

Christine Boes
CEO, HyperCore AI

P.S. This letter serves as an invitation to discuss a potential partnership and does not constitute a formal or binding offer. Any formal relationship would be subject to a definitive, mutually agreed-upon contract reviewed by legal counsel.`
    };

    const copyToClipboard = (text) => {
        navigator.clipboard.writeText(text);
        toast.success("Copied to clipboard! Ready to paste into your email.");
    };

    return (
        <>
            <LegalDisclaimer />
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Mail className="w-5 h-5 text-gray-600" />
                        Outreach & Proposal Toolkit
                    </CardTitle>
                    <CardDescription>
                        Use this template to contact the partners listed above. This is not a cold email; it's a high-value business proposal.
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="mb-4">
                        <label className="text-sm font-medium">Email Subject</label>
                        <div className="flex items-center gap-2 mt-1">
                            <Textarea readOnly value={outreachTemplate.subject} className="font-semibold" rows={1} />
                            <Button variant="outline" size="icon" onClick={() => copyToClipboard(outreachTemplate.subject)}>
                                <Copy className="w-4 h-4" />
                            </Button>
                        </div>
                    </div>
                    <div>
                        <label className="text-sm font-medium">Email Body</label>
                        <div className="flex items-center gap-2 mt-1">
                            <Textarea readOnly value={outreachTemplate.body} rows={18} />
                            <Button variant="outline" size="icon" onClick={() => copyToClipboard(outreachTemplate.body)}>
                                <Copy className="w-4 h-4" />
                            </Button>
                        </div>
                    </div>
                    <Button className="w-full mt-4" onClick={() => copyToClipboard(outreachTemplate.body)}>
                        <Copy className="w-4 h-4 mr-2" />
                        Copy Full Proposal Email
                    </Button>
                </CardContent>
            </Card>
        </>
    );
}
