import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { AlertTriangle, CheckCircle, XCircle, ExternalLink } from "lucide-react";

const COMPARISON_DATA = [
    { feature: "Legal Advice", ai: false, legal_service: true, note: "AI cannot provide legal advice." },
    { feature: "State-Specific Laws", ai: false, legal_service: true, note: "Legal services use Virginia-specific clauses." },
    { feature: "Attorney Reviewed", ai: false, legal_service: true, note: "Their documents are drafted by lawyers." },
    { feature: "Legal Defensibility", ai: false, legal_service: true, note: "Shows good-faith effort in a dispute." },
    { feature: "Insurance Compliance", ai: false, legal_service: true, note: "E&O policies require valid contracts." },
    { feature: "Liability Shield", ai: false, legal_service: true, note: "You are using a recognized legal product." }
];

export default function LegalDocumentStrategy() {
    return (
        <Card className="bg-white border-blue-200">
            <CardHeader>
                <CardTitle className="flex items-center gap-2">
                    <AlertTriangle className="w-6 h-6 text-blue-600" />
                    Why a $149 Legal Service is Necessary
                </CardTitle>
                <CardDescription>Understanding the difference between an AI-generated blueprint and a legally binding document.</CardDescription>
            </CardHeader>
            <CardContent>
                <p className="mb-4 text-sm text-gray-700">
                    My templates are excellent starting points and structural guides. However, they are **not a substitute for a document from a legal service provider.** You are not paying for the text; you are paying for the legal protection behind the text.
                </p>
                <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                        <thead>
                            <tr className="border-b">
                                <th className="p-2 text-left font-semibold">Feature</th>
                                <th className="p-2 text-center font-semibold">HyperCore AI Template</th>
                                <th className="p-2 text-center font-semibold">LegalZoom / Rocket Lawyer</th>
                            </tr>
                        </thead>
                        <tbody>
                            {COMPARISON_DATA.map(item => (
                                <tr key={item.feature} className="border-b">
                                    <td className="p-2 font-medium">{item.feature}</td>
                                    <td className="p-2 text-center">
                                        <XCircle className="w-5 h-5 text-red-500 mx-auto" />
                                    </td>
                                    <td className="p-2 text-center">
                                        <CheckCircle className="w-5 h-5 text-green-500 mx-auto" />
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
                <div className="mt-6 flex flex-col sm:flex-row gap-4">
                    <Button asChild className="w-full bg-blue-600 hover:bg-blue-700">
                        <a href="https://www.legalzoom.com/business/business-operations/business-contract-templates.html" target="_blank" rel="noopener noreferrer">
                            Go to LegalZoom <ExternalLink className="w-4 h-4 ml-2" />
                        </a>
                    </Button>
                    <Button asChild variant="outline" className="w-full">
                        <a href="https://www.rocketlawyer.com/business-and-contracts" target="_blank" rel="noopener noreferrer">
                            Explore Rocket Lawyer <ExternalLink className="w-4 h-4 ml-2" />
                        </a>
                    </Button>
                </div>
            </CardContent>
        </Card>
    );
}