import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Building, FileText, Download, Banknote, CheckCircle } from 'lucide-react';
import { toast } from "sonner";
import { generateBankEngagementLetter } from "@/api/functions";

export default function BankingEngagementGenerator() {
    const [generating, setGenerating] = useState(false);

    const handleGenerateLetter = async () => {
        setGenerating(true);
        try {
            const response = await generateBankEngagementLetter();
            
            if (response.status === 200) {
                // Create download link
                const blob = new Blob([response.data], { type: 'application/pdf' });
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = 'HyperCore-United-Bank-Engagement-Letter.pdf';
                document.body.appendChild(a);
                a.click();
                window.URL.revokeObjectURL(url);
                a.remove();
                
                toast.success("Banking engagement letter generated successfully!");
            } else {
                toast.error("Failed to generate banking engagement letter");
            }
        } catch (error) {
            console.error('Failed to generate banking engagement letter:', error);
            toast.error("Error generating document");
        } finally {
            setGenerating(false);
        }
    };

    return (
        <Card>
            <CardHeader>
                <CardTitle className="flex items-center gap-2">
                    <Building className="w-5 h-5 text-blue-600" />
                    United Bank Enterprise Banking Engagement
                </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
                <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                    <h4 className="font-semibold text-blue-900 mb-2">Banking Services Integration Request</h4>
                    <p className="text-blue-800 text-sm">
                        This engagement letter formalizes HyperCore's request for enhanced commercial banking services 
                        to support enterprise cybersecurity platform operations, including high-volume wire transfers 
                        and automated payment tracking integration.
                    </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <h5 className="font-semibold mb-2">Requested Services:</h5>
                        <ul className="text-sm space-y-1">
                            <li className="flex items-center gap-2">
                                <CheckCircle className="w-4 h-4 text-green-600" />
                                Enhanced Wire Transfer Processing
                            </li>
                            <li className="flex items-center gap-2">
                                <CheckCircle className="w-4 h-4 text-green-600" />
                                Net 30 Payment Tracking & APIs
                            </li>
                            <li className="flex items-center gap-2">
                                <CheckCircle className="w-4 h-4 text-green-600" />
                                Commercial Account Features
                            </li>
                            <li className="flex items-center gap-2">
                                <CheckCircle className="w-4 h-4 text-green-600" />
                                Technical Integration Support
                            </li>
                        </ul>
                    </div>
                    
                    <div>
                        <h5 className="font-semibold mb-2">Projected Volume:</h5>
                        <div className="space-y-2 text-sm">
                            <div className="flex justify-between">
                                <span>Monthly Incoming Wires:</span>
                                <Badge>$200K - $2M</Badge>
                            </div>
                            <div className="flex justify-between">
                                <span>Average Transaction:</span>
                                <Badge>$15K - $50K</Badge>
                            </div>
                            <div className="flex justify-between">
                                <span>Client Type:</span>
                                <Badge variant="outline">Enterprise/Gov</Badge>
                            </div>
                            <div className="flex justify-between">
                                <span>Growth Projection:</span>
                                <Badge className="bg-green-100 text-green-800">300% Annual</Badge>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="border-t pt-4">
                    <Button 
                        onClick={handleGenerateLetter}
                        disabled={generating}
                        className="w-full bg-blue-600 hover:bg-blue-700"
                    >
                        {generating ? (
                            <>
                                <FileText className="w-4 h-4 mr-2 animate-spin" />
                                Generating Banking Engagement Letter...
                            </>
                        ) : (
                            <>
                                <Download className="w-4 h-4 mr-2" />
                                Generate United Bank Engagement Letter
                            </>
                        )}
                    </Button>
                </div>

                <div className="text-xs text-gray-600 bg-gray-50 p-3 rounded-lg">
                    <strong>Next Steps:</strong> Present this engagement letter to United Bank's commercial banking division 
                    to establish enhanced services for enterprise cybersecurity platform operations. The letter includes 
                    technical specifications for API integration and projected transaction volumes to support their 
                    service planning and implementation timeline.
                </div>
            </CardContent>
        </Card>
    );
}