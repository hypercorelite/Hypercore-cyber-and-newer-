
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { FileText, Download, Banknote, Building, Shield } from 'lucide-react';
import { toast } from "sonner";
import { generateInvoice } from "@/api/functions";
import { generateEngagementLetter } from "@/api/functions";
import { getBankSecrets } from "@/api/functions";

export default function EnterprisePaymentTerms() {
    const [invoiceData, setInvoiceData] = useState({
        clientName: '',
        clientAddress: '',
        serviceDescription: '',
        amount: '',
        projectDescription: ''
    });

    const [engagementData, setEngagementData] = useState({
        clientName: '',
        clientTitle: '',
        clientCompany: '',
        serviceType: 'CMMC Assessment',
        projectValue: '',
        startDate: '',
        deliverables: ['Comprehensive CMMC Level 2 Assessment', 'System Security Plan Review', 'Gap Analysis Report', 'Remediation Roadmap']
    });

    const [bankingInfo, setBankingInfo] = useState({ routingNumber: '', accountNumber: '' });
    const [loadingBankInfo, setLoadingBankInfo] = useState(true);

    useEffect(() => {
        loadBankingInfo();
    }, []);

    const loadBankingInfo = async () => {
        try {
            const response = await getBankSecrets();
            if (response.status === 200) {
                setBankingInfo(response.data.bankSecrets);
            }
        } catch (error) {
            console.error('Failed to load banking information', error);
            toast.error("Banking information not available");
        } finally {
            setLoadingBankInfo(false);
        }
    };

    const generateInvoiceDoc = async () => {
        try {
            const response = await generateInvoice({
                ...invoiceData,
                amount: parseFloat(invoiceData.amount),
                invoiceNumber: `HC-${Date.now()}`
            });

            if (response.status === 200) {
                const blob = new Blob([response.data], { type: 'application/pdf' });
                const url = window.URL.createObjectURL(blob);
                const link = document.createElement('a');
                link.href = url;
                link.download = `HyperCore-Invoice-${invoiceData.clientName.replace(/\s+/g, '')}.pdf`;
                document.body.appendChild(link);
                link.click();
                window.URL.revokeObjectURL(url);
                document.body.removeChild(link);
                toast.success("Invoice generated and downloaded!");
            }
        } catch (error) {
            toast.error("Failed to generate invoice");
        }
    };

    const generateEngagementDoc = async () => {
        try {
            const response = await generateEngagementLetter({
                ...engagementData,
                projectValue: parseFloat(engagementData.projectValue)
            });

            if (response.status === 200) {
                const blob = new Blob([response.data], { type: 'application/pdf' });
                const url = window.URL.createObjectURL(blob);
                const link = document.createElement('a');
                link.href = url;
                link.download = `HyperCore-Engagement-${engagementData.clientCompany.replace(/\s+/g, '')}.pdf`;
                document.body.appendChild(link);
                link.click();
                window.URL.revokeObjectURL(url);
                document.body.removeChild(link);
                toast.success("Engagement letter generated and downloaded!");
            }
        } catch (error) {
            toast.error("Failed to generate engagement letter");
        }
    };

    return (
        <div className="space-y-6">
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Shield className="w-5 h-5 text-green-600" />
                        Secure Enterprise Payment Terms & Banking
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-4">
                            <h4 className="font-semibold">Standard Payment Structure:</h4>
                            <div className="space-y-2 text-sm">
                                <div className="flex justify-between">
                                    <span>CMMC Assessment:</span>
                                    <Badge>$15,000 - $25,000</Badge>
                                </div>
                                <div className="flex justify-between">
                                    <span>Insurance Risk Analysis:</span>
                                    <Badge>$25,000 - $50,000</Badge>
                                </div>
                                <div className="flex justify-between">
                                    <span>Municipal Cyber Assessment:</span>
                                    <Badge>$25,000 - $40,000</Badge>
                                </div>
                                <div className="flex justify-between">
                                    <span>Payment Terms:</span>
                                    <Badge variant="outline">Net 30 Days</Badge>
                                </div>
                            </div>
                        </div>
                        
                        <div className="space-y-4">
                            <h4 className="font-semibold">Secure Wire Transfer Instructions:</h4>
                            {loadingBankInfo ? (
                                <div className="bg-gray-50 p-4 rounded-lg text-sm">
                                    <div>Loading secure banking information...</div>
                                </div>
                            ) : (
                                <div className="bg-gray-50 p-4 rounded-lg text-sm space-y-1">
                                    <div><strong>Bank:</strong> United Bank</div>
                                    <div><strong>Account Name:</strong> HyperCore Lite Cybersecurity Ecosystem LLC</div>
                                    <div><strong>Routing Number:</strong> {bankingInfo.routingNumber ? `***${bankingInfo.routingNumber.slice(-4)}` : 'Not Available'}</div>
                                    <div><strong>Account Number:</strong> {bankingInfo.accountNumber ? `***${bankingInfo.accountNumber.slice(-4)}` : 'Not Available'}</div>
                                    <div><strong>EIN:</strong> 39-4162842</div>
                                    <div className="text-xs text-gray-600 mt-2">
                                        <Shield className="w-3 h-3 inline mr-1" />
                                        Full banking details included in generated invoices
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>
                </CardContent>
            </Card>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Invoice Generator */}
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <FileText className="w-5 h-5 text-blue-600" />
                            Generate Professional Invoice
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <Input
                            placeholder="Client Name"
                            value={invoiceData.clientName}
                            onChange={(e) => setInvoiceData({...invoiceData, clientName: e.target.value})}
                        />
                        <Textarea
                            placeholder="Client Address"
                            value={invoiceData.clientAddress}
                            onChange={(e) => setInvoiceData({...invoiceData, clientAddress: e.target.value})}
                        />
                        <Input
                            placeholder="Service Description"
                            value={invoiceData.serviceDescription}
                            onChange={(e) => setInvoiceData({...invoiceData, serviceDescription: e.target.value})}
                        />
                        <Input
                            placeholder="Amount (e.g., 25000)"
                            type="number"
                            value={invoiceData.amount}
                            onChange={(e) => setInvoiceData({...invoiceData, amount: e.target.value})}
                        />
                        <Button onClick={generateInvoiceDoc} className="w-full">
                            <Download className="w-4 h-4 mr-2" />
                            Generate Invoice PDF
                        </Button>
                    </CardContent>
                </Card>

                {/* Engagement Letter Generator */}
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <Building className="w-5 h-5 text-purple-600" />
                            Generate Engagement Letter
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <Input
                            placeholder="Client Name"
                            value={engagementData.clientName}
                            onChange={(e) => setEngagementData({...engagementData, clientName: e.target.value})}
                        />
                        <Input
                            placeholder="Client Title"
                            value={engagementData.clientTitle}
                            onChange={(e) => setEngagementData({...engagementData, clientTitle: e.target.value})}
                        />
                        <Input
                            placeholder="Company Name"
                            value={engagementData.clientCompany}
                            onChange={(e) => setEngagementData({...engagementData, clientCompany: e.target.value})}
                        />
                        <Input
                            placeholder="Project Value (e.g., 25000)"
                            type="number"
                            value={engagementData.projectValue}
                            onChange={(e) => setEngagementData({...engagementData, projectValue: e.target.value})}
                        />
                        <Input
                            placeholder="Start Date"
                            type="date"
                            value={engagementData.startDate}
                            onChange={(e) => setEngagementData({...engagementData, startDate: e.target.value})}
                        />
                        <Button onClick={generateEngagementDoc} className="w-full">
                            <Download className="w-4 h-4 mr-2" />
                            Generate Engagement Letter PDF
                        </Button>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}
