import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Copy, DollarSign, FileText, AlertTriangle } from 'lucide-react';
import { toast } from "sonner";

const AFFORDABLE_LEGAL_OPTIONS = [
    {
        option: "LegalZoom Business Contracts",
        cost: "$149-299",
        timeline: "2-3 days",
        what_you_get: "Basic service agreement, NDA, pilot agreement templates",
        pros: "Fast, affordable, legally reviewed",
        cons: "Generic, may need customization later",
        best_for: "Initial partnerships and pilots"
    },
    {
        option: "Rocket Lawyer Business Plan", 
        cost: "$39.99/month",
        timeline: "Same day",
        what_you_get: "Unlimited document creation, attorney consultations",
        pros: "Very affordable, includes attorney advice",
        cons: "Subscription model, limited customization",
        best_for: "Ongoing document needs"
    },
    {
        option: "Nolo Legal Forms + DIY",
        cost: "$49-99",
        timeline: "Same day",
        what_you_get: "State-specific business forms, guidance",
        pros: "Cheapest option, immediate access",
        cons: "Requires more work, no attorney review",
        best_for: "Bootstrap budget"
    }
];

const PILOT_AGREEMENT_TEMPLATE = `PILOT PROGRAM AGREEMENT

This Pilot Program Agreement ("Agreement") is entered into between HyperCore AI, LLC ("HyperCore") and [CLIENT NAME] ("Client").

1. PILOT SCOPE
• Duration: 30-90 days
• Services: CMMC gap analysis and recommendations
• Deliverables: Assessment report, remediation roadmap
• Data: Client will provide only non-CUI, non-sensitive information

2. NO COST PILOT
• This pilot is provided at no charge to Client
• Client is under no obligation to purchase services
• HyperCore retains right to use anonymized learnings for platform improvement

3. LIMITED LIABILITY
• HyperCore's liability is limited to $1,000 maximum
• Services provided "as-is" for evaluation purposes only
• Client acknowledges this is a pilot/demonstration, not production service

4. CONFIDENTIALITY
• Both parties agree to maintain confidentiality of shared information
• HyperCore will not share Client's specific data with third parties
• Client may share results of pilot publicly

5. DATA HANDLING
• Client warrants no CUI or classified information will be shared
• All data exchanges will use encrypted channels
• Data will be purged within 30 days of pilot completion

6. TERMINATION
• Either party may terminate with 48 hours written notice
• No penalties for early termination
• Client retains all deliverables created during pilot

By signing below, both parties agree to these terms.

HyperCore AI, LLC: _________________________ Date: _______
[CLIENT NAME]: _________________________ Date: _______

NOTICE: This template is for reference only. Consult legal counsel before use.`;

export default function AffordableLegalStrategy() {
    const copyTemplate = () => {
        navigator.clipboard.writeText(PILOT_AGREEMENT_TEMPLATE);
        toast.success("Pilot agreement template copied to clipboard!");
    };

    return (
        <div className="space-y-6">
            <Card className="border-green-200 bg-green-50">
                <CardHeader>
                    <CardTitle className="text-green-800">The $200 Legal Strategy</CardTitle>
                </CardHeader>
                <CardContent>
                    <p className="text-green-700 mb-4">
                        <strong>Reality:</strong> You can start CMMC partnerships with basic legal docs for under $200. 
                        The $3,000 lawyer comes later when you're making money.
                    </p>
                    <div className="space-y-3">
                        {AFFORDABLE_LEGAL_OPTIONS.map((option, index) => (
                            <div key={index} className="bg-white rounded-lg p-4 border">
                                <div className="flex justify-between items-start mb-2">
                                    <h4 className="font-semibold">{option.option}</h4>
                                    <Badge className="bg-green-100 text-green-800">{option.cost}</Badge>
                                </div>
                                <p className="text-sm text-gray-600 mb-2">{option.what_you_get}</p>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs">
                                    <div>
                                        <span className="font-semibold text-green-600">Pros:</span>
                                        <p className="text-green-600">{option.pros}</p>
                                    </div>
                                    <div>
                                        <span className="font-semibold text-orange-600">Cons:</span>
                                        <p className="text-orange-600">{option.cons}</p>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <FileText className="w-5 h-5 text-blue-600" />
                        FREE Pilot Agreement Template
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 mb-4">
                        <div className="flex items-center gap-2">
                            <AlertTriangle className="w-4 h-4 text-yellow-600" />
                            <span className="text-sm text-yellow-800 font-semibold">
                                Use this for initial pilots, but get legal review before signing major contracts.
                            </span>
                        </div>
                    </div>
                    <Textarea 
                        value={PILOT_AGREEMENT_TEMPLATE}
                        readOnly
                        rows={20}
                        className="bg-gray-50 text-xs font-mono"
                    />
                    <Button onClick={copyTemplate} className="mt-4 w-full">
                        <Copy className="w-4 h-4 mr-2" />
                        Copy Pilot Agreement Template
                    </Button>
                </CardContent>
            </Card>
        </div>
    );
}