// This is a new component for reusability.
import React from 'react';
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Gavel } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function DisclaimerBanner() {
    return (
        <Alert variant="destructive" className="bg-red-50 border-red-200 text-red-800">
            <Gavel className="h-4 w-4 !text-red-700" />
            <AlertTitle className="font-bold">Important: Our Role is Advisory & Preparatory</AlertTitle>
            <AlertDescription className="space-y-1 mt-2">
                <p>
                    <strong>We are not a C3PAO.</strong> HyperCore AI provides expert CMMC preparation training, AI-powered tools, and guidance. We do not conduct official audits or grant certifications. This ensures our guidance is unbiased and 100% focused on your success.
                </p>
                 <p>
                    <strong>Your Team Implements.</strong> Our program is a partnership. We provide the expert roadmap and weekly coaching; your team is responsible for performing the actual implementation of all security controls. Success depends on this collaboration.
                </p>
                <Link to={createPageUrl('Legal')} className="text-sm font-semibold underline hover:text-red-700">
                    Read our full legal terms and service limitations.
                </Link>
            </AlertDescription>
        </Alert>
    );
}