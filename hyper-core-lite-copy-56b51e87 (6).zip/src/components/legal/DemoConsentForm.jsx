import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Shield, FileText, Database, AlertTriangle, CheckCircle } from 'lucide-react';
import { motion } from "framer-motion";
import { collectDemoData } from "@/api/functions";
import { toast } from "sonner";

const CONSENT_LEVELS = [
    {
        level: "demo_only",
        title: "Demonstration Only",
        description: "Your data will be used solely for this technology demonstration and deleted within 30 days.",
        benefits: ["Technology evaluation", "No long-term data retention"],
        icon: Shield,
        color: "bg-blue-100 text-blue-800"
    },
    {
        level: "training_contribution", 
        title: "AI Training Contribution",
        description: "Your anonymized data will contribute to improving HyperCore AI models for the benefit of all users.",
        benefits: ["Support AI advancement", "Improved analysis accuracy", "Better cybersecurity for everyone"],
        icon: Database,
        color: "bg-green-100 text-green-800"
    },
    {
        level: "partnership_track",
        title: "Strategic Partnership Track",
        description: "Enhanced analysis and priority consideration for strategic partnership opportunities.",
        benefits: ["Enhanced demonstration features", "Partnership consideration", "Exclusive early access"],
        icon: CheckCircle,
        color: "bg-purple-100 text-purple-800"
    }
];

export default function DemoConsentForm({ demoType, onConsentComplete }) {
    const [selectedConsent, setSelectedConsent] = useState('demo_only');
    const [organizationName, setOrganizationName] = useState('');
    const [clientData, setClientData] = useState('');
    const [hasReadTerms, setHasReadTerms] = useState(false);
    const [isSubmitting, setIsSubmitting] = useState(false);

    const handleSubmitConsent = async () => {
        if (!hasReadTerms || !clientData) {
            toast.error('Please complete all required fields and agree to terms.');
            return;
        }

        setIsSubmitting(true);
        
        try {
            const result = await collectDemoData({
                demoType,
                clientData,
                consentLevel: selectedConsent,
                organizationName: organizationName || 'Anonymous Demo'
            });

            if (result.status === 200) {
                toast.success('Consent recorded successfully. Beginning demonstration...');
                onConsentComplete({
                    demoRecordId: result.data.demo_record_id,
                    consentLevel: selectedConsent,
                    clientData
                });
            } else {
                toast.error('Failed to record consent. Please try again.');
            }
        } catch (error) {
            console.error('Consent submission error:', error);
            toast.error('Error recording consent. Please try again.');
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-4xl mx-auto"
        >
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <FileText className="w-6 h-6 text-blue-600" />
                        HyperCore AI Technology Demonstration Consent
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                    <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                        <div className="flex items-center gap-2 mb-2">
                            <AlertTriangle className="w-5 h-5 text-yellow-600" />
                            <span className="font-semibold text-yellow-800">Important Legal Notice</span>
                        </div>
                        <p className="text-sm text-yellow-700">
                            This demonstration is provided for technology evaluation purposes only. Results are estimates 
                            and should not be considered professional cybersecurity advice or compliance certification. 
                            By proceeding, you acknowledge this is a technology demonstration with no liability for outcomes.
                        </p>
                    </div>

                    <div>
                        <label className="text-sm font-medium text-gray-700">Organization Name (Optional)</label>
                        <Input
                            placeholder="Your organization name (can be left blank for anonymous demo)"
                            value={organizationName}
                            onChange={(e) => setOrganizationName(e.target.value)}
                            className="mt-1"
                        />
                    </div>

                    <div>
                        <label className="text-sm font-medium text-gray-700">Demo Data Input</label>
                        <Textarea
                            placeholder="Enter data for demonstration (e.g., IP addresses, company information, security policies, etc.)"
                            value={clientData}
                            onChange={(e) => setClientData(e.target.value)}
                            rows={4}
                            className="mt-1"
                        />
                    </div>

                    <div>
                        <h3 className="text-lg font-semibold mb-4">Data Usage Consent Level</h3>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            {CONSENT_LEVELS.map((consent) => (
                                <motion.div
                                    key={consent.level}
                                    initial={{ opacity: 0, y: 10 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    className={`border-2 rounded-lg p-4 cursor-pointer transition-all ${
                                        selectedConsent === consent.level 
                                            ? 'border-blue-500 bg-blue-50' 
                                            : 'border-gray-200 hover:border-gray-300'
                                    }`}
                                    onClick={() => setSelectedConsent(consent.level)}
                                >
                                    <div className="flex items-center gap-3 mb-2">
                                        <consent.icon className="w-5 h-5 text-gray-600" />
                                        <Badge className={consent.color}>
                                            {consent.title}
                                        </Badge>
                                    </div>
                                    <p className="text-sm text-gray-600 mb-3">{consent.description}</p>
                                    <div className="space-y-1">
                                        {consent.benefits.map((benefit, idx) => (
                                            <div key={idx} className="flex items-center gap-2">
                                                <CheckCircle className="w-3 h-3 text-green-500" />
                                                <span className="text-xs text-gray-600">{benefit}</span>
                                            </div>
                                        ))}
                                    </div>
                                </motion.div>
                            ))}
                        </div>
                    </div>

                    <div className="bg-gray-50 rounded-lg p-4">
                        <h4 className="font-semibold mb-2">Data Processing & Retention Policy:</h4>
                        <ul className="text-sm text-gray-600 space-y-1">
                            <li>• Demo data is processed exclusively for the selected consent level</li>
                            <li>• "Demo Only" data is automatically deleted after 30 days</li>
                            <li>• "Training Contribution" data is anonymized before AI training use</li>
                            <li>• All data processing complies with applicable privacy regulations</li>
                            <li>• You may request data deletion at any time by contacting support</li>
                        </ul>
                    </div>

                    <div className="flex items-center space-x-2">
                        <Checkbox 
                            id="terms"
                            checked={hasReadTerms}
                            onCheckedChange={setHasReadTerms}
                        />
                        <label htmlFor="terms" className="text-sm text-gray-700">
                            I have read and agree to the data processing terms and understand this is a technology 
                            demonstration for evaluation purposes only.
                        </label>
                    </div>

                    <Button 
                        onClick={handleSubmitConsent}
                        disabled={!hasReadTerms || !clientData || isSubmitting}
                        className="w-full bg-blue-600 hover:bg-blue-700"
                        size="lg"
                    >
                        {isSubmitting ? (
                            'Recording Consent...'
                        ) : (
                            `Proceed with ${CONSENT_LEVELS.find(c => c.level === selectedConsent)?.title} Demo`
                        )}
                    </Button>
                </CardContent>
            </Card>
        </motion.div>
    );
}