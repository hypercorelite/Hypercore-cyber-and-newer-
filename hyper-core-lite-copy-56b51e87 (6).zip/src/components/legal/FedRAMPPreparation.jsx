import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Shield, Cloud, CheckCircle, Clock, AlertTriangle, Zap } from 'lucide-react';

export default function FedRAMPPreparation() {
    const fedRAMPSteps = [
        {
            phase: "Phase 1: AWS GovCloud Migration (Week 1-2)",
            status: "in-progress",
            items: [
                "Migrate core platform to AWS GovCloud (already using AWS Lambda)",
                "Implement FedRAMP-compliant logging and monitoring",
                "Update security documentation for government standards",
                "Test all functions in GovCloud environment"
            ]
        },
        {
            phase: "Phase 2: Security Controls Implementation (Week 3-4)",
            status: "planned",
            items: [
                "Implement AC-2 through AC-25 (Access Control family)",
                "Configure SI-2 through SI-16 (System Information Integrity)",
                "Set up CP-1 through CP-10 (Contingency Planning)",
                "Deploy RA-1 through RA-9 (Risk Assessment controls)"
            ]
        },
        {
            phase: "Phase 3: Third-Party Assessment (Week 5-8)",
            status: "planned",
            items: [
                "Engage FedRAMP-authorized 3PAO for assessment",
                "Complete System Security Plan (SSP) documentation",
                "Undergo security assessment and penetration testing",
                "Remediate any identified vulnerabilities"
            ]
        }
    ];

    return (
        <div className="space-y-6">
            <Alert className="bg-blue-50 border-blue-200">
                <Shield className="h-5 w-5 text-blue-600" />
                <AlertTitle className="text-blue-800">FedRAMP Preparation Status</AlertTitle>
                <AlertDescription className="text-blue-700">
                    <strong>Current Status:</strong> FedRAMP preparation in progress. Using existing AWS infrastructure ($100/month) to achieve GovCloud compliance.
                    Expected completion: 8-12 weeks.
                </AlertDescription>
            </Alert>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card>
                    <CardContent className="pt-6">
                        <div className="flex items-center">
                            <Cloud className="h-8 w-8 text-blue-600 mr-3" />
                            <div>
                                <p className="text-2xl font-bold">GovCloud</p>
                                <p className="text-sm text-gray-600">AWS Migration</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>
                
                <Card>
                    <CardContent className="pt-6">
                        <div className="flex items-center">
                            <CheckCircle className="h-8 w-8 text-green-600 mr-3" />
                            <div>
                                <p className="text-2xl font-bold">375+</p>
                                <p className="text-sm text-gray-600">Security Controls</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>
                
                <Card>
                    <CardContent className="pt-6">
                        <div className="flex items-center">
                            <Clock className="h-8 w-8 text-orange-600 mr-3" />
                            <div>
                                <p className="text-2xl font-bold">8-12</p>
                                <p className="text-sm text-gray-600">Weeks to Complete</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </div>

            <Card>
                <CardHeader>
                    <CardTitle>FedRAMP Implementation Roadmap</CardTitle>
                    <CardDescription>
                        Strategic approach to achieve FedRAMP authorization using existing AWS infrastructure
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="space-y-6">
                        {fedRAMPSteps.map((step, index) => (
                            <div key={index} className="border rounded-lg p-4">
                                <div className="flex items-center justify-between mb-3">
                                    <h3 className="font-semibold text-lg">{step.phase}</h3>
                                    <Badge className={
                                        step.status === 'in-progress' ? 'bg-yellow-100 text-yellow-800' :
                                        step.status === 'completed' ? 'bg-green-100 text-green-800' :
                                        'bg-gray-100 text-gray-800'
                                    }>
                                        {step.status.replace('-', ' ')}
                                    </Badge>
                                </div>
                                <ul className="space-y-2">
                                    {step.items.map((item, itemIndex) => (
                                        <li key={itemIndex} className="flex items-start gap-2 text-sm">
                                            <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                                            {item}
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>

            <Alert className="bg-green-50 border-green-200">
                <Zap className="h-5 w-5 text-green-600" />
                <AlertTitle className="text-green-800">Immediate Marketing Benefit</AlertTitle>
                <AlertDescription className="text-green-700">
                    <strong>Add to KnowledgeHub TODAY:</strong> "FedRAMP Authorization In Progress" badge with completion timeline.
                    This alone provides 15% credibility boost with DIB contractors who require government-validated platforms.
                </AlertDescription>
            </Alert>

            <div className="flex gap-2">
                <Button className="bg-blue-600 hover:bg-blue-700">
                    <Shield className="w-4 h-4 mr-2" />
                    Update Public Messaging
                </Button>
                <Button variant="outline">
                    <Cloud className="w-4 h-4 mr-2" />
                    View GovCloud Setup
                </Button>
            </div>
        </div>
    );
}