import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Star, MessageSquare } from 'lucide-react';
import { ClientFeedback } from "@/api/entities";
import { User } from "@/api/entities";
import { toast } from "sonner";
import { motion } from "framer-motion";

export default function FeedbackWidget({ context = "general" }) {
    const [isOpen, setIsOpen] = useState(false);
    const [rating, setRating] = useState(0);
    const [feedbackType, setFeedbackType] = useState("platform_usability");
    const [feedbackText, setFeedbackText] = useState("");
    const [wouldRecommend, setWouldRecommend] = useState(null);
    const [conversionInterest, setConversionInterest] = useState("somewhat_interested");
    const [testimonialConsent, setTestimonialConsent] = useState(false);
    const [isSubmitting, setIsSubmitting] = useState(false);

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (rating === 0 || !feedbackText.trim()) {
            toast.error("Please provide a rating and feedback text");
            return;
        }

        setIsSubmitting(true);
        try {
            const user = await User.me();
            await ClientFeedback.create({
                client_email: user.email,
                feedback_type: feedbackType,
                rating: rating,
                feedback_text: feedbackText,
                would_recommend: wouldRecommend,
                conversion_interest: conversionInterest,
                testimonial_consent: testimonialConsent,
                page_context: context
            });

            toast.success("Thank you for your feedback! This helps us improve.");
            setIsOpen(false);
            // Reset form
            setRating(0);
            setFeedbackText("");
            setWouldRecommend(null);
        } catch (error) {
            toast.error("Failed to submit feedback. Please try again.");
        } finally {
            setIsSubmitting(false);
        }
    };

    const StarRating = ({ value, onChange }) => (
        <div className="flex gap-1">
            {[1, 2, 3, 4, 5].map((star) => (
                <button
                    key={star}
                    type="button"
                    onClick={() => onChange(star)}
                    className={`p-1 ${star <= value ? 'text-yellow-400' : 'text-gray-300'} hover:text-yellow-400 transition-colors`}
                >
                    <Star className="w-6 h-6 fill-current" />
                </button>
            ))}
        </div>
    );

    if (!isOpen) {
        return (
            <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="fixed bottom-6 right-6 z-50"
            >
                <Button
                    onClick={() => setIsOpen(true)}
                    className="bg-blue-600 hover:bg-blue-700 shadow-lg rounded-full p-3"
                >
                    <MessageSquare className="w-5 h-5 mr-2" />
                    Feedback
                </Button>
            </motion.div>
        );
    }

    return (
        <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="fixed bottom-6 right-6 z-50 w-96"
        >
            <Card className="shadow-xl">
                <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                        <span className="flex items-center gap-2">
                            <MessageSquare className="w-5 h-5" />
                            Quick Feedback
                        </span>
                        <Button variant="ghost" size="sm" onClick={() => setIsOpen(false)}>
                            ×
                        </Button>
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <form onSubmit={handleSubmit} className="space-y-4">
                        <div>
                            <Label>How would you rate this experience?</Label>
                            <StarRating value={rating} onChange={setRating} />
                        </div>
                        
                        <div>
                            <Label>Feedback Category</Label>
                            <Select value={feedbackType} onValueChange={setFeedbackType}>
                                <SelectTrigger>
                                    <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="platform_usability">Platform Usability</SelectItem>
                                    <SelectItem value="ai_accuracy">AI Accuracy</SelectItem>
                                    <SelectItem value="report_quality">Report Quality</SelectItem>
                                    <SelectItem value="support_experience">Support Experience</SelectItem>
                                    <SelectItem value="feature_request">Feature Request</SelectItem>
                                    <SelectItem value="general_comment">General Comment</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>

                        <div>
                            <Label>Your Feedback</Label>
                            <Textarea
                                value={feedbackText}
                                onChange={(e) => setFeedbackText(e.target.value)}
                                placeholder="What worked well? What could be improved?"
                                rows={3}
                            />
                        </div>

                        <div>
                            <Label>Would you recommend HyperCore to a colleague?</Label>
                            <div className="flex gap-2 mt-1">
                                <Button
                                    type="button"
                                    size="sm"
                                    variant={wouldRecommend === true ? "default" : "outline"}
                                    onClick={() => setWouldRecommend(true)}
                                >
                                    Yes
                                </Button>
                                <Button
                                    type="button"
                                    size="sm"
                                    variant={wouldRecommend === false ? "default" : "outline"}
                                    onClick={() => setWouldRecommend(false)}
                                >
                                    No
                                </Button>
                            </div>
                        </div>

                        <div>
                            <Label>Interest in paid version after Dec 5th?</Label>
                            <Select value={conversionInterest} onValueChange={setConversionInterest}>
                                <SelectTrigger>
                                    <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="not_interested">Not Interested</SelectItem>
                                    <SelectItem value="somewhat_interested">Somewhat Interested</SelectItem>
                                    <SelectItem value="very_interested">Very Interested</SelectItem>
                                    <SelectItem value="ready_to_purchase">Ready to Purchase</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>

                        <Button type="submit" className="w-full" disabled={isSubmitting}>
                            {isSubmitting ? "Submitting..." : "Submit Feedback"}
                        </Button>
                    </form>
                </CardContent>
            </Card>
        </motion.div>
    );
}