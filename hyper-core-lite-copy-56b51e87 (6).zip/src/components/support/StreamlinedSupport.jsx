import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Bot, Mail, MessageSquare, Clock, CheckCircle } from 'lucide-react';
import { toast } from "sonner";
import { SupportTicket } from "@/api/entities";

export default function StreamlinedSupport() {
    const [question, setQuestion] = useState("");
    const [email, setEmail] = useState("");
    const [aiResponse, setAiResponse] = useState("");
    const [isProcessing, setIsProcessing] = useState(false);

    const handleSubmitQuestion = async () => {
        if (!question.trim() || !email.trim()) {
            toast.error("Please enter both your email and question.");
            return;
        }

        setIsProcessing(true);
        
        try {
            // Create support ticket
            await SupportTicket.create({
                client_email: email,
                subject: "Platform Support Question",
                description: question,
                source: "portal_form",
                status: "new"
            });

            // Simulate AI processing
            setTimeout(() => {
                setAiResponse("Thank you for your question. Our AI is analyzing your request and will provide an initial response within a few moments. If the AI cannot fully answer your question, we'll escalate it to our expert team who will respond via email within 1 business day.");
                setIsProcessing(false);
                toast.success("Support ticket created successfully!");
            }, 2000);
        } catch (error) {
            setIsProcessing(false);
            toast.error("Failed to submit question. Please try again.");
        }
    };

    return (
        <div className="max-w-2xl mx-auto space-y-6">
            <Card className="bg-blue-50 border-blue-200">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-blue-800">
                        <Bot className="w-5 h-5" />
                        AI-First Support Model
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="space-y-4 text-sm">
                        <div className="flex items-start gap-3">
                            <Bot className="w-4 h-4 text-blue-600 mt-0.5" />
                            <div>
                                <strong>Step 1: AI Instant Support</strong>
                                <p className="text-gray-600">Ask your question below. Our AI answers 95% of CMMC questions immediately.</p>
                            </div>
                        </div>
                        <div className="flex items-start gap-3">
                            <MessageSquare className="w-4 h-4 text-green-600 mt-0.5" />
                            <div>
                                <strong>Step 2: Smart Escalation</strong>
                                <p className="text-gray-600">If AI can't fully answer, we automatically escalate to our expert team.</p>
                            </div>
                        </div>
                        <div className="flex items-start gap-3">
                            <Mail className="w-4 h-4 text-purple-600 mt-0.5" />
                            <div>
                                <strong>Step 3: Email Response</strong>
                                <p className="text-gray-600">Expert answers delivered to your email within 1 business day.</p>
                            </div>
                        </div>
                    </div>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>Submit Your Question</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <Input
                        placeholder="Your email address"
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                    />
                    <Textarea
                        placeholder="What's your CMMC question? Be as specific as possible..."
                        value={question}
                        onChange={(e) => setQuestion(e.target.value)}
                        rows={4}
                    />
                    <Button 
                        onClick={handleSubmitQuestion}
                        disabled={isProcessing}
                        className="w-full"
                    >
                        {isProcessing ? (
                            <>
                                <Bot className="w-4 h-4 mr-2 animate-spin" />
                                AI Processing...
                            </>
                        ) : (
                            <>
                                <Bot className="w-4 h-4 mr-2" />
                                Get AI Support
                            </>
                        )}
                    </Button>
                </CardContent>
            </Card>

            {aiResponse && (
                <Card className="bg-green-50 border-green-200">
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2 text-green-800">
                            <CheckCircle className="w-5 h-5" />
                            Support Request Received
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-green-700">{aiResponse}</p>
                        <div className="mt-4 p-3 bg-white rounded border">
                            <p className="text-sm text-gray-600">
                                <strong>No Phone Support:</strong> We don't provide phone support to keep costs low and maintain detailed records. Our AI + email model provides faster, more comprehensive help than traditional phone support.
                            </p>
                        </div>
                    </CardContent>
                </Card>
            )}

            <Card className="bg-gray-50">
                <CardContent className="p-4">
                    <h4 className="font-medium mb-2">Direct Email Contact</h4>
                    <p className="text-sm text-gray-600 mb-2">
                        For urgent matters, you can also email us directly:
                    </p>
                    <p className="text-sm">
                        <strong>support@hypercorecyber.com</strong>
                    </p>
                    <p className="text-xs text-gray-500 mt-2">
                        Response time: Within 1 business day
                    </p>
                </CardContent>
            </Card>
        </div>
    );
}