import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Bot, User, UserCheck, CheckCircle, AlertTriangle, ArrowRight } from "lucide-react";
import { motion, AnimatePresence } from 'framer-motion';

const workflowSteps = [
    { name: "AI Analysis", status: "pending_ai_analysis", icon: Bot, actor: "CMMC Assessment Agent" },
    { name: "Analyst Review", status: "pending_human_review", icon: User, actor: "Human Analyst" },
    { name: "Manager Approval", status: "pending_secondary_approval", icon: UserCheck, actor: "Compliance Manager" },
    { name: "Completed", status: "completed", icon: CheckCircle, actor: "System" }
];

export default function AIWorkflowDemo() {
    const [currentStepIndex, setCurrentStepIndex] = useState(0);

    const handleAdvance = () => {
        if (currentStepIndex < workflowSteps.length - 1) {
            setCurrentStepIndex(currentStepIndex + 1);
        }
    };
    
    const handleReset = () => {
        setCurrentStepIndex(0);
    };

    const currentStep = workflowSteps[currentStepIndex];

    return (
        <Card className="bg-gray-50 overflow-hidden">
            <CardHeader>
                <CardTitle>Demonstration: The "Triple Lock" Compliance Workflow</CardTitle>
                <CardDescription>Simulate our legally-defensible workflow that combines AI speed with mandatory human oversight.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
                <div className="flex items-center justify-between p-4 bg-white border rounded-lg">
                    <h4 className="font-semibold">Control AC.1.001: Limit System Access</h4>
                    <Badge variant={currentStep.status === 'completed' ? 'success' : 'outline'}>
                        Status: {currentStep.status.replace(/_/g, ' ')}
                    </Badge>
                </div>
                
                <div className="relative flex justify-between items-center w-full px-4">
                    {workflowSteps.map((step, index) => (
                        <React.Fragment key={step.name}>
                            <div className="flex flex-col items-center z-10">
                                <div className={`h-12 w-12 rounded-full flex items-center justify-center border-2 transition-all duration-300 ${index <= currentStepIndex ? 'bg-blue-600 border-blue-600 text-white' : 'bg-gray-100 border-gray-300 text-gray-400'}`}>
                                    <step.icon className="h-6 w-6" />
                                </div>
                                <p className={`mt-2 text-xs font-medium ${index <= currentStepIndex ? 'text-blue-700' : 'text-gray-500'}`}>{step.name}</p>
                            </div>
                            {index < workflowSteps.length - 1 && <div className="flex-1 h-0.5 bg-gray-200" />}
                        </React.Fragment>
                    ))}
                    <div className="absolute top-6 left-0 w-full h-0.5 bg-gray-200" />
                    <motion.div 
                        className="absolute top-6 left-0 h-0.5 bg-blue-600"
                        initial={{ width: 0 }}
                        animate={{ width: `${(currentStepIndex / (workflowSteps.length - 1)) * 100}%` }}
                        transition={{ type: 'spring', stiffness: 50 }}
                    />
                </div>

                <AnimatePresence mode="wait">
                    <motion.div
                        key={currentStepIndex}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        transition={{ duration: 0.2 }}
                    >
                        <Card className="p-4">
                            <div className="flex items-start gap-4">
                                <div className="flex-shrink-0 h-10 w-10 rounded-full bg-gray-100 flex items-center justify-center">
                                    <currentStep.icon className="h-5 w-5 text-gray-600" />
                                </div>
                                <div>
                                    <h5 className="font-semibold">{currentStep.actor}</h5>
                                    {currentStepIndex === 0 && <p className="text-sm text-gray-600">AI agent analyzes the provided evidence against the CMMC control requirements.</p>}
                                    {currentStepIndex === 1 && <p className="text-sm text-gray-600">A human analyst verifies the AI's findings, ensuring context and accuracy. This step is mandatory.</p>}
                                    {currentStepIndex === 2 && <p className="text-sm text-gray-600">A compliance manager provides the final sign-off, creating a defensible audit trail.</p>}
                                    {currentStepIndex === 3 && <p className="text-sm text-green-700 font-semibold">The control is now marked as compliant with a full, auditable approval history.</p>}
                                </div>
                            </div>
                        </Card>
                    </motion.div>
                </AnimatePresence>

                <div className="flex justify-center gap-4">
                    {currentStepIndex < workflowSteps.length - 1 ? (
                        <Button onClick={handleAdvance}>
                            Simulate "{workflowSteps[currentStepIndex + 1].name}" Step <ArrowRight className="w-4 h-4 ml-2" />
                        </Button>
                    ) : (
                         <Button onClick={handleReset} variant="outline">Reset Demonstration</Button>
                    )}
                </div>
            </CardContent>
        </Card>
    );
}