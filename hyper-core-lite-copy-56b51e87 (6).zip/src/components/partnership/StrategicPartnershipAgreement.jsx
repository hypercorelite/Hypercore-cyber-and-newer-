import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { generatePartnershipAgreement } from "@/api/functions";
import { Handshake, FileText, DollarSign, Shield, Download, CheckCircle } from 'lucide-react';
import { toast } from "sonner";

const PARTNERSHIP_MODELS = {
    "revenue_share": {
        name: "Revenue Share Model",
        description: "HyperCore receives 15-25% of assessment fees for qualified referrals",
        pros: ["Predictable revenue stream", "Aligned incentives", "Scales with partner success"],
        cons: ["Lower immediate returns", "Dependent on partner pricing"],
        typical_terms: "15% for basic referrals, 25% for AI-prepared clients"
    },
    "referral_fee": {
        name: "Fixed Referral Fee Model", 
        description: "Fixed fee per successful client referral that completes assessment",
        pros: ["Predictable per-client revenue", "Simple tracking", "Quick payments"],
        cons: ["No upside from high-value assessments", "Fixed ceiling per client"],
        typical_terms: "$5K-15K per successful assessment completion"
    },
    "hybrid": {
        name: "Hybrid Fee + Revenue Model",
        description: "Upfront referral fee + smaller percentage of assessment revenue", 
        pros: ["Immediate cash flow", "Upside participation", "Risk mitigation"],
        cons: ["More complex accounting", "Requires strong partner trust"],
        typical_terms: "$3K upfront + 10% of assessment fee"
    },
    "exclusive_territory": {
        name: "Exclusive Territory Partnership",
        description: "HyperCore has exclusive readiness rights in partner's geographic region",
        pros: ["Market protection", "Higher revenue share", "Strategic positioning"],
        cons: ["Geographic limitations", "Exclusivity obligations"],
        typical_terms: "25-35% revenue share for exclusive regional partnership"
    }
};

export default function StrategicPartnershipAgreement() {
    const [formData, setFormData] = useState({
        partnerCompanyName: "",
        partnershipModel: "",
        territoryScope: "",
        revenueSharePercent: "",
        referralFeeAmount: "",
        minimumClientPrep: "",
        qualityStandards: "",
        termLength: "24",
        exclusivityLevel: ""
    });

    const [generating, setGenerating] = useState(false);

    const handleGenerate = async () => {
        if (!formData.partnerCompanyName || !formData.partnershipModel) {
            toast.error("Please fill in required fields");
            return;
        }

        setGenerating(true);
        try {
            const response = await generatePartnershipAgreement(formData);
            
            if (response.status === 200) {
                // Create download link
                const blob = new Blob([response.data], { type: 'application/pdf' });
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `HyperCore-${formData.partnerCompanyName.replace(/\s+/g, '')}-Partnership-Agreement.pdf`;
                document.body.appendChild(a);
                a.click();
                window.URL.revokeObjectURL(url);
                document.body.removeChild(a);
                
                toast.success("Partnership agreement generated and downloaded!");
            }
        } catch (error) {
            toast.error("Failed to generate agreement. Please try again.");
            console.error(error);
        } finally {
            setGenerating(false);
        }
    };

    const selectedModel = PARTNERSHIP_MODELS[formData.partnershipModel];

    return (
        <div className="space-y-6">
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Handshake className="w-5 h-5 text-blue-600" />
                        Strategic C3PAO Partnership Agreement Generator
                    </CardTitle>
                    <CardDescription>
                        Generate legally compliant partnership agreements for CMMC readiness + assessment partnerships
                    </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    <Alert>
                        <Shield className="h-4 w-4" />
                        <AlertTitle>Conflict of Interest Compliance</AlertTitle>
                        <AlertDescription>
                            This agreement structure ensures full compliance with CMMC-AB COI requirements by maintaining true independence between readiness services (HyperCore) and official assessments (Partner C3PAO).
                        </AlertDescription>
                    </Alert>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-2">
                            <label htmlFor="partnerCompanyName" className="text-sm font-medium block">Partner C3PAO Company Name *</label>
                            <Input
                                id="partnerCompanyName"
                                placeholder="e.g., Coalfire Federal, Schellman & Company"
                                value={formData.partnerCompanyName}
                                onChange={(e) => setFormData({...formData, partnerCompanyName: e.target.value})}
                            />
                        </div>
                        
                        <div className="space-y-2">
                            <label htmlFor="partnershipModel" className="text-sm font-medium block">Partnership Financial Model *</label>
                            <Select value={formData.partnershipModel} onValueChange={(value) => setFormData({...formData, partnershipModel: value})}>
                                <SelectTrigger id="partnershipModel">
                                    <SelectValue placeholder="Select a model..." />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="revenue_share">Revenue Share Model</SelectItem>
                                    <SelectItem value="referral_fee">Fixed Referral Fee</SelectItem>
                                    <SelectItem value="hybrid">Hybrid (Fee + Revenue Share)</SelectItem>
                                    <SelectItem value="exclusive_territory">Exclusive Territory</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>

                        {(formData.partnershipModel === 'revenue_share' || formData.partnershipModel === 'hybrid' || formData.partnershipModel === 'exclusive_territory') && (
                            <div className="space-y-2">
                                <label htmlFor="revenueSharePercent" className="text-sm font-medium block">Revenue Share (%)</label>
                                <Input 
                                    id="revenueSharePercent" 
                                    type="number" 
                                    placeholder="e.g., 20" 
                                    value={formData.revenueSharePercent}
                                    onChange={(e) => setFormData({...formData, revenueSharePercent: e.target.value})} 
                                />
                            </div>
                        )}

                        {(formData.partnershipModel === 'referral_fee' || formData.partnershipModel === 'hybrid') && (
                            <div className="space-y-2">
                                <label htmlFor="referralFeeAmount" className="text-sm font-medium block">Referral Fee ($)</label>
                                <Input 
                                    id="referralFeeAmount" 
                                    type="number" 
                                    placeholder="e.g., 5000" 
                                    value={formData.referralFeeAmount}
                                    onChange={(e) => setFormData({...formData, referralFeeAmount: e.target.value})} 
                                />
                            </div>
                        )}

                        <div className="space-y-2">
                            <label htmlFor="territoryScope" className="text-sm font-medium block">Territory/Market Scope</label>
                            <Select value={formData.territoryScope} onValueChange={(value) => setFormData({...formData, territoryScope: value})}>
                                <SelectTrigger id="territoryScope">
                                    <SelectValue placeholder="Geographic or market scope" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="national">National (All US markets)</SelectItem>
                                    <SelectItem value="regional_east">Regional - East Coast</SelectItem>
                                    <SelectItem value="regional_west">Regional - West Coast</SelectItem>
                                    <SelectItem value="regional_central">Regional - Central US</SelectItem>
                                    <SelectItem value="state_specific">State-Specific Territory</SelectItem>
                                    <SelectItem value="dod_focused">DoD Contractors Only</SelectItem>
                                    <SelectItem value="sector_specific">Industry Sector Specific</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>

                        <div className="space-y-2">
                            <label htmlFor="termLength" className="text-sm font-medium block">Agreement Term Length</label>
                            <Select value={formData.termLength} onValueChange={(value) => setFormData({...formData, termLength: value})}>
                                <SelectTrigger id="termLength">
                                    <SelectValue placeholder="Contract duration" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="12">12 months</SelectItem>
                                    <SelectItem value="24">24 months (Recommended)</SelectItem>
                                    <SelectItem value="36">36 months</SelectItem>
                                    <SelectItem value="60">5 years</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                    </div>

                    {selectedModel && (
                        <Card className="bg-blue-50 border-blue-200">
                            <CardHeader className="pb-3">
                                <CardTitle className="text-lg">{selectedModel.name}</CardTitle>
                                <CardDescription>{selectedModel.description}</CardDescription>
                            </CardHeader>
                            <CardContent>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div>
                                        <h4 className="font-semibold text-green-700 mb-2">Advantages:</h4>
                                        <ul className="text-sm space-y-1">
                                            {selectedModel.pros.map((pro, index) => (
                                                <li key={index} className="flex items-center gap-2">
                                                    <CheckCircle className="w-3 h-3 text-green-600" />
                                                    {pro}
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                                    <div>
                                        <h4 className="font-semibold text-orange-700 mb-2">Considerations:</h4>
                                        <ul className="text-sm space-y-1">
                                            {selectedModel.cons.map((con, index) => (
                                                <li key={index} className="flex items-start gap-2">
                                                    <div className="w-2 h-2 bg-orange-500 rounded-full mt-1.5 flex-shrink-0"></div>
                                                    {con}
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                                </div>
                                <div className="mt-3 p-3 bg-white rounded border border-blue-300">
                                    <span className="font-semibold text-blue-800">Typical Terms: </span>
                                    <span className="text-blue-700">{selectedModel.typical_terms}</span>
                                </div>
                            </CardContent>
                        </Card>
                    )}

                    <div className="space-y-2">
                        <label htmlFor="minimumClientPrep" className="text-sm font-medium block">Minimum Client Preparation Standards</label>
                        <Textarea
                            id="minimumClientPrep"
                            placeholder="e.g., All referred clients must complete HyperCore readiness assessment with 80%+ compliance score..."
                            value={formData.minimumClientPrep}
                            onChange={(e) => setFormData({...formData, minimumClientPrep: e.target.value})}
                            rows={3}
                        />
                    </div>

                    <div className="space-y-2">
                        <label htmlFor="qualityStandards" className="text-sm font-medium block">Quality & Performance Standards</label>
                        <Textarea
                            id="qualityStandards"
                            placeholder="e.g., Partner agrees to 90% first-pass assessment rate for HyperCore-prepared clients..."
                            value={formData.qualityStandards}
                            onChange={(e) => setFormData({...formData, qualityStandards: e.target.value})}
                            rows={3}
                        />
                    </div>

                    <Button 
                        onClick={handleGenerate}
                        disabled={generating}
                        className="w-full bg-blue-600 hover:bg-blue-700"
                        size="lg"
                    >
                        {generating ? (
                            <>
                                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                                Generating Partnership Agreement...
                            </>
                        ) : (
                            <>
                                <FileText className="w-4 h-4 mr-2" />
                                Generate Partnership Agreement (PDF)
                            </>
                        )}
                    </Button>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <DollarSign className="w-5 h-5 text-green-600" />
                        Financial Projection Calculator
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="bg-green-50 rounded-lg p-4 space-y-3">
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
                            <div>
                                <div className="text-2xl font-bold text-green-700">$50K - $150K</div>
                                <div className="text-sm text-green-600">Annual Revenue Per Partnership</div>
                            </div>
                            <div>
                                <div className="text-2xl font-bold text-blue-700">5-15 clients/month</div>
                                <div className="text-sm text-blue-600">Expected Referral Volume</div>
                            </div>
                            <div>
                                <div className="text-2xl font-bold text-purple-700">85%+</div>
                                <div className="text-sm text-purple-600">First-Pass Success Rate</div>
                            </div>
                        </div>
                        <Alert>
                            <AlertDescription className="text-sm">
                                <strong>Conservative Projection:</strong> A single strategic C3PAO partnership with 10 client referrals per month at 20% revenue share can generate $100K+ annually while your partner handles the complex certification process.
                            </AlertDescription>
                        </Alert>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}