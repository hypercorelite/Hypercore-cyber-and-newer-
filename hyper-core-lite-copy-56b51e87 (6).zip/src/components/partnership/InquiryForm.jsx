import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Loader2, CheckCircle } from "lucide-react";
import { PartnershipCommunication } from "@/api/entities";
import { toast } from "sonner";

export default function InquiryForm() {
    const [formData, setFormData] = useState({
        organization: '',
        contact_person: '',
        email: '',
        partnership_type: '',
        notes: ''
    });
    const [loading, setLoading] = useState(false);
    const [submitted, setSubmitted] = useState(false);

    const handleInputChange = (e) => {
        const { id, value } = e.target;
        setFormData(prev => ({ ...prev, [id]: value }));
    };

    const handleSelectChange = (value) => {
        setFormData(prev => ({ ...prev, partnership_type: value }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!formData.organization || !formData.contact_person || !formData.email || !formData.partnership_type) {
            toast.error("Please fill out all required fields.");
            return;
        }

        setLoading(true);
        try {
            await PartnershipCommunication.create({
                ...formData,
                status: 'target',
                communication_type: 'initial_contact'
            });
            toast.success("Inquiry submitted successfully!");
            setSubmitted(true);
        } catch (error) {
            console.error("Failed to submit inquiry:", error);
            toast.error("Failed to submit inquiry. Please try again.");
        } finally {
            setLoading(false);
        }
    };

    if (submitted) {
        return (
            <div className="text-center py-10">
                <CheckCircle className="w-12 h-12 text-green-600 mx-auto mb-4" />
                <h3 className="text-xl font-semibold">Thank You!</h3>
                <p className="text-gray-600">Your partnership inquiry has been received. We will be in touch shortly.</p>
            </div>
        );
    }

    return (
        <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-1">
                <Label htmlFor="organization">Organization Name *</Label>
                <Input id="organization" value={formData.organization} onChange={handleInputChange} required />
            </div>
            <div className="space-y-1">
                <Label htmlFor="contact_person">Your Name *</Label>
                <Input id="contact_person" value={formData.contact_person} onChange={handleInputChange} required />
            </div>
            <div className="space-y-1">
                <Label htmlFor="email">Work Email *</Label>
                <Input id="email" type="email" value={formData.email} onChange={handleInputChange} required />
            </div>
            <div className="space-y-1">
                <Label>Partnership Type *</Label>
                <Select onValueChange={handleSelectChange} value={formData.partnership_type} required>
                    <SelectTrigger>
                        <SelectValue placeholder="Select your industry" />
                    </SelectTrigger>
                    <SelectContent>
                        <SelectItem value="legal_partner">Legal Firm</SelectItem>
                        <SelectItem value="insurance_partner">Insurance Carrier/Broker</SelectItem>
                        <SelectItem value="defense_contractor">Defense / CMMC</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                </Select>
            </div>
            <div className="space-y-1">
                <Label htmlFor="notes">Message (Optional)</Label>
                <Textarea id="notes" placeholder="Tell us about your needs or how you'd like to partner..." value={formData.notes} onChange={handleInputChange} />
            </div>
            <Button type="submit" className="w-full" disabled={loading}>
                {loading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : "Submit Inquiry"}
            </Button>
        </form>
    );
}