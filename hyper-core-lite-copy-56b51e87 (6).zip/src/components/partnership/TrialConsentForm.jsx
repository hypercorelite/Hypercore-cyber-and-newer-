
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Shield, UserPlus, Building } from 'lucide-react';
import { toast } from "sonner";
import PasswordInput from '../ui/PasswordInput';

export default function TrialConsentForm({ onConsentGiven }) {
    const [formData, setFormData] = useState({
        email: '',
        password: '',
        confirmPassword: '',
        name: '',
        organizationName: '',
        userCount: '',
        industry: 'defense_contractor',
        consentGiven: false
    });
    const [loading, setLoading] = useState(false);
    const [errors, setErrors] = useState({});

    const validateForm = () => {
        const newErrors = {};
        
        if (!formData.email) newErrors.email = 'Email is required';
        if (!formData.password) newErrors.password = 'Password is required';
        if (formData.password.length < 8) newErrors.password = 'Password must be at least 8 characters';
        if (!formData.confirmPassword) newErrors.confirmPassword = 'Please confirm your password';
        if (formData.password !== formData.confirmPassword) {
            newErrors.confirmPassword = 'Passwords do not match';
        }
        if (!formData.name) newErrors.name = 'Name is required';
        if (!formData.organizationName) newErrors.organizationName = 'Organization name is required';
        if (!formData.userCount) newErrors.userCount = 'Please select user count';
        if (!formData.consentGiven) newErrors.consentGiven = 'You must agree to the terms to continue';

        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        
        if (!validateForm()) {
            toast.error("Please fix the errors below");
            return;
        }

        // Track trial signup conversion
        if (window.trackConversion) {
            window.trackConversion('trial_signup', {
                company_size: formData.userCount,
                industry: 'defense_contractor', // As per outline, explicitly set to 'defense_contractor'
                source: 'partnership_trial'
            });
        }

        setLoading(true);
        try {
            // Here we would normally create the user account
            // For now, we'll simulate this and pass data to parent
            onConsentGiven(formData); // Pass the full formData object as per outline
            toast.success("Account created! Starting your assessment...");
        } catch (error) {
            toast.error("Failed to create account. Please try again.");
        } finally {
            setLoading(false);
        }
    };

    const passwordsMatch = formData.password && formData.confirmPassword && formData.password === formData.confirmPassword;
    const passwordsDontMatch = formData.password && formData.confirmPassword && formData.password !== formData.confirmPassword;

    return (
        <Card className="max-w-2xl mx-auto">
            <CardHeader className="text-center">
                <div className="mx-auto w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                    <UserPlus className="w-6 h-6 text-blue-600" />
                </div>
                <CardTitle className="text-2xl font-bold">Start Your Free AI Assessment</CardTitle>
                <CardDescription>
                    Create your account to begin the CMMC compliance assessment
                </CardDescription>
            </CardHeader>
            <CardContent>
                <form onSubmit={handleSubmit} className="space-y-4">
                    {/* Email */}
                    <div>
                        <Input
                            type="email"
                            placeholder="Email Address"
                            value={formData.email}
                            onChange={(e) => setFormData({...formData, email: e.target.value})}
                            className={errors.email ? 'border-red-500' : ''}
                            required
                        />
                        {errors.email && <p className="text-red-500 text-sm mt-1">{errors.email}</p>}
                    </div>

                    {/* Password with visibility toggle */}
                    <div>
                        <PasswordInput
                            value={formData.password}
                            onChange={(e) => setFormData({...formData, password: e.target.value})}
                            placeholder="Password (minimum 8 characters)"
                            error={!!errors.password}
                            required
                        />
                        {errors.password && <p className="text-red-500 text-sm mt-1">{errors.password}</p>}
                    </div>

                    {/* Confirm Password with visibility toggle and match indicator */}
                    <div>
                        <PasswordInput
                            value={formData.confirmPassword}
                            onChange={(e) => setFormData({...formData, confirmPassword: e.target.value})}
                            placeholder="Confirm Password"
                            error={!!errors.confirmPassword}
                            required
                        />
                        {passwordsMatch && (
                            <p className="text-green-600 text-sm mt-1 flex items-center">
                                <Shield className="w-4 h-4 mr-1" />
                                Passwords match
                            </p>
                        )}
                        {passwordsDontMatch && (
                            <p className="text-red-500 text-sm mt-1">
                                Passwords do not match - use the eye icons above to check what you typed
                            </p>
                        )}
                        {errors.confirmPassword && <p className="text-red-500 text-sm mt-1">{errors.confirmPassword}</p>}
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                        {/* Name */}
                        <div>
                            <Input
                                placeholder="Full Name"
                                value={formData.name}
                                onChange={(e) => setFormData({...formData, name: e.target.value})}
                                className={errors.name ? 'border-red-500' : ''}
                                required
                            />
                            {errors.name && <p className="text-red-500 text-sm mt-1">{errors.name}</p>}
                        </div>

                        {/* User Count */}
                        <div>
                            <Select 
                                value={formData.userCount} 
                                onValueChange={(value) => setFormData({...formData, userCount: value})}
                            >
                                <SelectTrigger className={errors.userCount ? 'border-red-500' : ''}>
                                    <SelectValue placeholder="Company Size" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="1-10">1-10 employees</SelectItem>
                                    <SelectItem value="11-50">11-50 employees</SelectItem>
                                    <SelectItem value="51-200">51-200 employees</SelectItem>
                                    <SelectItem value="201-1000">201-1000 employees</SelectItem>
                                    <SelectItem value="1000+">1000+ employees</SelectItem>
                                </SelectContent>
                            </Select>
                            {errors.userCount && <p className="text-red-500 text-sm mt-1">{errors.userCount}</p>}
                        </div>
                    </div>

                    {/* Organization Name */}
                    <div>
                        <Input
                            placeholder="Organization/Company Name"
                            value={formData.organizationName}
                            onChange={(e) => setFormData({...formData, organizationName: e.target.value})}
                            className={errors.organizationName ? 'border-red-500' : ''}
                            required
                        />
                        {errors.organizationName && <p className="text-red-500 text-sm mt-1">{errors.organizationName}</p>}
                    </div>

                    {/* Industry */}
                    <Select 
                        value={formData.industry} 
                        onValueChange={(value) => setFormData({...formData, industry: value})}
                    >
                        <SelectTrigger>
                            <SelectValue placeholder="Industry" />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="defense_contractor">Defense Contractor</SelectItem>
                            <SelectItem value="aerospace">Aerospace</SelectItem>
                            <SelectItem value="manufacturing">Manufacturing</SelectItem>
                            <SelectItem value="technology">Technology</SelectItem>
                            <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                    </Select>

                    {/* Consent */}
                    <div className="flex items-start space-x-2">
                        <Checkbox 
                            id="consent" 
                            checked={formData.consentGiven}
                            onCheckedChange={(checked) => setFormData({...formData, consentGiven: checked})}
                        />
                        <div className="grid gap-1.5 leading-none">
                            <label htmlFor="consent" className={`text-sm cursor-pointer ${errors.consentGiven ? 'text-red-500' : 'text-gray-700'}`}>
                                I agree to the terms of service and consent to the free CMMC assessment. 
                                I understand this is a trial program ending December 5th, 2025.
                            </label>
                            {errors.consentGiven && <p className="text-red-500 text-sm">{errors.consentGiven}</p>}
                        </div>
                    </div>

                    <Alert className="bg-blue-50 border-blue-200">
                        <Shield className="h-4 w-4" />
                        <AlertDescription className="text-blue-700">
                            Your data is secure and will only be used for CMMC compliance assistance. 
                            We do not share data with third parties.
                        </AlertDescription>
                    </Alert>

                    <Button 
                        type="submit" 
                        className="w-full bg-blue-600 hover:bg-blue-700" 
                        disabled={loading}
                        size="lg"
                    >
                        {loading ? "Creating Account..." : "Create Account & Start Assessment"}
                    </Button>
                </form>
            </CardContent>
        </Card>
    );
}
