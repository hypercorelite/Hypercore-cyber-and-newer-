
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { Check, X, FileDown, Loader2 } from 'lucide-react';
import { motion } from 'framer-motion';
import { toast } from "sonner";
import { createPageUrl } from '@/utils';
import { User } from '@/api/entities'; // Import user entity

const ASSESSMENT_QUESTIONS = [
    { id: 'cui', text: "Do you handle Controlled Unclassified Information (CUI)?" },
    { id: 'mfa', text: "Is Multi-Factor Authentication (MFA) required for all user access?" },
    { id: 'ssp', text: "Do you have a documented System Security Plan (SSP)?" },
    { id: 'ir_plan', text: "Do you have a documented Incident Response Plan?" },
    { id: 'access_reviews', text: "Do you perform regular user access reviews (at least annually)?" },
    { id: 'logging', text: "Are system audit logs enabled and reviewed?" },
    { id: 'encryption', text: "Is all CUI encrypted both at rest (on disk) and in transit (over the network)?" },
    { id: 'training', text: "Do you provide annual cybersecurity awareness training to all employees?" }
];

export default function TrialAssessmentChecklist({ onComplete, organizationName }) {
    const [answers, setAnswers] = useState({});
    const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
    const [currentUser, setCurrentUser] = useState(null);

    React.useEffect(() => {
        User.me().then(setCurrentUser).catch(() => setCurrentUser(null));
    }, []);

    const handleAnswer = (questionId, answer) => {
        const newAnswers = { ...answers, [questionId]: answer };
        setAnswers(newAnswers);

        const nextIndex = currentQuestionIndex + 1;
        if (nextIndex < ASSESSMENT_QUESTIONS.length) {
            setCurrentQuestionIndex(nextIndex);
        } else {
            // All questions answered, call onComplete with all answers
            onComplete({ ...newAnswers, [questionId]: answer }, currentUser?.email);
        }
    };
    
    const progress = (Object.keys(answers).length / ASSESSMENT_QUESTIONS.length) * 100;
    const currentQuestion = ASSESSMENT_QUESTIONS[currentQuestionIndex];

    return (
        <Card>
            <CardHeader>
                <CardTitle>CMMC Level 2 Checklist</CardTitle>
                <Progress value={progress} className="mt-2" />
            </CardHeader>
            <CardContent className="text-center">
                <p className="text-lg font-semibold mb-6 min-h-[56px] flex items-center justify-center">
                    {currentQuestion.text}
                </p>
                <div className="flex justify-center gap-4">
                    <Button 
                        size="lg" 
                        variant="outline" 
                        className="bg-green-50 hover:bg-green-100 text-green-700 border-green-300"
                        onClick={() => handleAnswer(currentQuestion.id, true)}
                    >
                        <Check className="w-5 h-5 mr-2" /> Yes
                    </Button>
                    <Button 
                        size="lg" 
                        variant="outline" 
                        className="bg-red-50 hover:bg-red-100 text-red-700 border-red-300"
                        onClick={() => handleAnswer(currentQuestion.id, false)}
                    >
                        <X className="w-5 h-5 mr-2" /> No
                    </Button>
                </div>
            </CardContent>
        </Card>
    );
}
