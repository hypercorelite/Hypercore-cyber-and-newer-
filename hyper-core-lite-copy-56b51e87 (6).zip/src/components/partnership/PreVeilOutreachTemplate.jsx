import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Mail, Copy, CheckCircle } from 'lucide-react';
import { toast } from "sonner";

export default function PreVeilOutreachTemplate() {
    const [copied, setCopied] = useState(false);
    
    const emailTemplate = `Subject: AI + Zero-Trust for Seamless CMMC - Partnership Opportunity for PreVeil's DIB Network

Hi [Name],

I hope this message finds you well. I'm reaching out from HyperCore Cyber because I believe there's a compelling partnership opportunity between PreVeil's zero-trust email solutions and our AI-driven CMMC compliance automation.

**Why This Partnership Makes Sense:**
• PreVeil's 1,500+ DIB clients need continuous doc automation for DFARS 7021 compliance
• Your zero-trust approach + our AI monitoring creates an unbeatable end-to-end solution  
• The market is shifting from "one-and-done" to continuous compliance - perfect timing for bundled offerings

**Proposed Partnership Model:**
• Bundle HyperCore's AI (SSP/POA&M automation) with PreVeil's secure email
• Co-sell $4,999/year packages to your NoVA subcontractor network
• "Powered by HyperCore" recognition in your DIB summits and marketing materials
• Revenue share model: 20-30% on joint conversions

**Immediate Next Steps:**
1. Free POC with 2-3 of your current DIB clients needing Level 2 affirmations
2. API integration demo showing real-time compliance monitoring
3. Co-branded whitepaper: "AI + Encryption for CMMC 2.0" 

I'd love to show you how this works in a 15-minute demo. The Rackspace-SMPL-C partnership cut compliance time by 50% through similar AI integration - we can achieve even better results for the DIB market.

Are you available for a brief call this week to explore this further?

Best regards,
[Your Name]
HyperCore Cyber
[Your Contact Info]

P.S. We're seeing 20-30% conversion rates from referral partners. This could be significant additional revenue for PreVeil with minimal effort on your part.`;

    const copyToClipboard = () => {
        navigator.clipboard.writeText(emailTemplate);
        setCopied(true);
        toast.success("Email template copied to clipboard!");
        setTimeout(() => setCopied(false), 2000);
    };

    return (
        <Card className="w-full">
            <CardHeader>
                <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center gap-2">
                        <Mail className="w-5 h-5 text-blue-600" />
                        PreVeil Partnership Outreach Email
                    </CardTitle>
                    <Badge className="bg-green-100 text-green-800">High Priority Target</Badge>
                </div>
            </CardHeader>
            <CardContent className="space-y-4">
                <div className="bg-blue-50 p-4 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Target Profile:</h4>
                    <ul className="text-sm text-blue-700 space-y-1">
                        <li>• 1,500+ DIB clients needing automation</li>
                        <li>• Zero-trust email complements our AI monitoring</li>
                        <li>• Strong ties to Lockheed and NoVA primes</li>
                        <li>• Expected conversion: 20-30% from referrals</li>
                    </ul>
                </div>
                
                <Textarea
                    value={emailTemplate}
                    readOnly
                    className="h-96 font-mono text-sm"
                />
                
                <div className="flex gap-2">
                    <Button onClick={copyToClipboard} className="flex items-center gap-2">
                        {copied ? <CheckCircle className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                        {copied ? 'Copied!' : 'Copy Email Template'}
                    </Button>
                    <Button variant="outline" asChild>
                        <a href="mailto:?subject=AI + Zero-Trust for Seamless CMMC - Partnership Opportunity&body=" target="_blank">
                            Open in Email Client
                        </a>
                    </Button>
                </div>
            </CardContent>
        </Card>
    );
}