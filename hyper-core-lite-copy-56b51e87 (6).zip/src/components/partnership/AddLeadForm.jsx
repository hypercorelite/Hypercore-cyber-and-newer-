import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Loader2 } from 'lucide-react';

const statusOptions = ["target", "contacted", "replied", "demo_scheduled", "negotiating", "active_partner", "on_hold", "closed_lost"];
const typeOptions = ["defense_contractor", "prime_contractor", "legal_partner", "insurance_partner", "municipal_government", "energy_partner", "client"];

export default function AddLeadForm({ onSubmit, onCancel, isSubmitting }) {
    const [lead, setLead] = useState({
        organization: '',
        contact_person: '',
        email: '',
        partnership_type: 'defense_contractor',
        status: 'target',
        estimated_value: 0,
        notes: ''
    });

    const handleChange = (field, value) => {
        setLead(prev => ({ ...prev, [field]: value }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        onSubmit(lead);
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
                <div>
                    <Label htmlFor="organization">Organization Name *</Label>
                    <Input id="organization" value={lead.organization} onChange={e => handleChange('organization', e.target.value)} required />
                </div>
                <div>
                    <Label htmlFor="contact_person">Contact Person *</Label>
                    <Input id="contact_person" value={lead.contact_person} onChange={e => handleChange('contact_person', e.target.value)} required />
                </div>
            </div>
            <div>
                <Label htmlFor="email">Email</Label>
                <Input id="email" type="email" value={lead.email} onChange={e => handleChange('email', e.target.value)} />
            </div>
            <div className="grid grid-cols-2 gap-4">
                 <div>
                    <Label htmlFor="partnership_type">Partnership Type *</Label>
                    <Select value={lead.partnership_type} onValueChange={v => handleChange('partnership_type', v)}>
                        <SelectTrigger id="partnership_type"><SelectValue /></SelectTrigger>
                        <SelectContent>
                            {typeOptions.map(opt => <SelectItem key={opt} value={opt}>{opt.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}</SelectItem>)}
                        </SelectContent>
                    </Select>
                </div>
                <div>
                    <Label htmlFor="status">Status *</Label>
                    <Select value={lead.status} onValueChange={v => handleChange('status', v)}>
                        <SelectTrigger id="status"><SelectValue /></SelectTrigger>
                        <SelectContent>
                            {statusOptions.map(opt => <SelectItem key={opt} value={opt}>{opt.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}</SelectItem>)}
                        </SelectContent>
                    </Select>
                </div>
            </div>
             <div>
                <Label htmlFor="estimated_value">Estimated Value ($)</Label>
                <Input id="estimated_value" type="number" value={lead.estimated_value} onChange={e => handleChange('estimated_value', Number(e.target.value))} />
            </div>
            <div>
                <Label htmlFor="notes">Notes</Label>
                <Textarea id="notes" value={lead.notes} onChange={e => handleChange('notes', e.target.value)} />
            </div>
            <div className="flex justify-end gap-2">
                <Button type="button" variant="ghost" onClick={onCancel}>Cancel</Button>
                <Button type="submit" disabled={isSubmitting}>
                    {isSubmitting && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                    Add Lead
                </Button>
            </div>
        </form>
    );
}