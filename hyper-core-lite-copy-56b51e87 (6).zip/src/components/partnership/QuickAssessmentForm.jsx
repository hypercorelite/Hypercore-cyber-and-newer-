import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import { ArrowRight, Shield, CheckCircle } from 'lucide-react';

const assessmentQuestions = [
    {
        id: 'systemEnvironment',
        title: 'System Environment & Architecture',
        question: 'Which best describes your primary IT environment where CUI will be processed?',
        type: 'radio',
        options: [
            { value: 'on_premise_windows', label: 'On-premise Windows domain with Active Directory' },
            { value: 'on_premise_mixed', label: 'Mixed on-premise (Windows + Linux servers)' },
            { value: 'cloud_aws', label: 'Primarily AWS cloud infrastructure' },
            { value: 'cloud_azure', label: 'Primarily Microsoft Azure cloud' },
            { value: 'hybrid_cloud', label: 'Hybrid cloud and on-premise environment' }
        ]
    },
    {
        id: 'industrySpecifics',
        title: 'Defense Contract Specifics',
        question: 'What type of defense work does your organization primarily perform?',
        type: 'radio',
        options: [
            { value: 'manufacturing', label: 'Manufacturing/Production (vehicles, equipment, components)' },
            { value: 'engineering', label: 'Engineering Services & Design' },
            { value: 'it_services', label: 'IT Services & Software Development' },
            { value: 'research', label: 'Research & Development' },
            { value: 'logistics', label: 'Logistics & Supply Chain Management' }
        ]
    },
    {
        id: 'cuiTypes',
        title: 'CUI Data Types & Volume',
        question: 'What types of CUI does your organization typically handle? (Select primary type)',
        type: 'radio',
        options: [
            { value: 'technical_drawings', label: 'Technical drawings, specifications, and engineering data' },
            { value: 'financial_pricing', label: 'Financial data, pricing, and procurement information' },
            { value: 'personnel_security', label: 'Personnel records and security clearance information' },
            { value: 'operational_logistics', label: 'Operational plans and logistics information' },
            { value: 'mixed_cui', label: 'Multiple CUI types across different projects' }
        ]
    },
    {
        id: 'currentSecurity',
        title: 'Current Security Posture',
        question: 'Which best describes your organization\'s current cybersecurity implementation?',
        type: 'radio',
        options: [
            { value: 'basic_antivirus', label: 'Basic antivirus and firewall protection' },
            { value: 'managed_security', label: 'Managed security services with some monitoring' },
            { value: 'comprehensive_security', label: 'Comprehensive security tools (SIEM, EDR, vulnerability scanning)' },
            { value: 'enterprise_security', label: 'Enterprise-grade security operations center (SOC)' },
            { value: 'minimal_security', label: 'Minimal security measures currently in place' }
        ]
    },
    {
        id: 'accessControl',
        title: 'Access Control Implementation',
        question: 'How does your organization currently manage user access to systems and data?',
        type: 'radio',
        options: [
            { value: 'manual_local', label: 'Manual local accounts on each system' },
            { value: 'active_directory', label: 'Active Directory with group-based access control' },
            { value: 'cloud_identity', label: 'Cloud-based identity management (Azure AD, AWS IAM)' },
            { value: 'privileged_access', label: 'Privileged Access Management (PAM) solution implemented' },
            { value: 'no_formal_process', label: 'No formal access control process currently' }
        ]
    },
    {
        id: 'incidentResponse',
        title: 'Incident Response Capability',
        question: 'What is your organization\'s current incident response capability?',
        type: 'radio',
        options: [
            { value: 'documented_tested', label: 'Documented plan with regular testing and trained team' },
            { value: 'documented_untested', label: 'Written plan but not regularly tested' },
            { value: 'informal_response', label: 'Informal response procedures, no written plan' },
            { value: 'outsourced_incident', label: 'Outsourced to managed security provider' },
            { value: 'no_incident_plan', label: 'No formal incident response plan' }
        ]
    },
    {
        id: 'businessDetails',
        title: 'Business Context',
        question: 'Additional details to customize your documentation:',
        type: 'form',
        fields: [
            { id: 'employeeCount', label: 'Number of employees', type: 'select', options: ['1-10', '11-25', '26-50', '51-100', '101-250', '250+'] },
            { id: 'primaryContracts', label: 'Primary DoD contracting vehicles', type: 'text', placeholder: 'e.g., GSA, SEWP, specific prime contractors' },
            { id: 'complianceTimeline', label: 'Target CMMC compliance date', type: 'select', options: ['Within 6 months', '6-12 months', '1-2 years', 'Not yet determined'] },
            { id: 'currentChallenges', label: 'Biggest compliance challenges', type: 'textarea', placeholder: 'e.g., Limited IT staff, budget constraints, technical complexity...' }
        ]
    }
];

export default function QuickAssessmentForm({ onSubmit }) {
    const [currentQuestion, setCurrentQuestion] = useState(0);
    const [answers, setAnswers] = useState({});

    const handleAnswerChange = (questionId, value, fieldId = null) => {
        if (fieldId) {
            // Handle form fields
            setAnswers(prev => ({
                ...prev,
                [questionId]: {
                    ...prev[questionId],
                    [fieldId]: value
                }
            }));
        } else {
            setAnswers(prev => ({ ...prev, [questionId]: value }));
        }
    };

    const handleNext = () => {
        if (currentQuestion < assessmentQuestions.length - 1) {
            setCurrentQuestion(currentQuestion + 1);
        } else {
            onSubmit(answers);
        }
    };

    const handleBack = () => {
        if (currentQuestion > 0) {
            setCurrentQuestion(currentQuestion - 1);
        }
    };

    const progress = ((currentQuestion + 1) / assessmentQuestions.length) * 100;
    const question = assessmentQuestions[currentQuestion];
    const currentAnswer = answers[question.id];

    const isAnswerComplete = () => {
        if (question.type === 'radio') {
            return currentAnswer;
        } else if (question.type === 'form') {
            // Check if at least the required fields are filled
            return currentAnswer?.employeeCount && currentAnswer?.complianceTimeline;
        }
        return true;
    };

    return (
        <Card className="max-w-4xl mx-auto">
            <CardHeader>
                <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2">
                        <Shield className="w-6 h-6 text-blue-600" />
                        <CardTitle>Enhanced CMMC Readiness Assessment</CardTitle>
                    </div>
                    <div className="text-sm text-gray-500">
                        Step {currentQuestion + 1} of {assessmentQuestions.length}
                    </div>
                </div>
                <Progress value={progress} className="mb-4" />
                <CardDescription>
                    These detailed questions help our AI generate highly specific, customized documentation for your organization
                </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
                <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">
                        {question.title}
                    </h3>
                    <p className="text-gray-600 mb-4">
                        {question.question}
                    </p>
                    
                    {question.type === 'radio' ? (
                        <RadioGroup 
                            value={currentAnswer || ''} 
                            onValueChange={(value) => handleAnswerChange(question.id, value)}
                            className="space-y-3"
                        >
                            {question.options.map((option) => (
                                <div key={option.value} className="flex items-start space-x-3 p-3 border rounded-lg hover:bg-gray-50">
                                    <RadioGroupItem value={option.value} id={option.value} className="mt-1" />
                                    <Label htmlFor={option.value} className="flex-grow cursor-pointer">
                                        {option.label}
                                    </Label>
                                </div>
                            ))}
                        </RadioGroup>
                    ) : (
                        // Form fields for business details
                        <div className="space-y-4">
                            {question.fields.map((field) => {
                                const fieldValue = currentAnswer?.[field.id] || '';
                                return (
                                    <div key={field.id}>
                                        <Label className="text-sm font-medium">{field.label}</Label>
                                        {field.type === 'select' ? (
                                            <Select 
                                                value={fieldValue}
                                                onValueChange={(value) => handleAnswerChange(question.id, value, field.id)}
                                            >
                                                <SelectTrigger className="mt-1">
                                                    <SelectValue placeholder="Select..." />
                                                </SelectTrigger>
                                                <SelectContent>
                                                    {field.options.map(option => (
                                                        <SelectItem key={option} value={option}>{option}</SelectItem>
                                                    ))}
                                                </SelectContent>
                                            </Select>
                                        ) : field.type === 'textarea' ? (
                                            <Textarea
                                                value={fieldValue}
                                                onChange={(e) => handleAnswerChange(question.id, e.target.value, field.id)}
                                                placeholder={field.placeholder}
                                                className="mt-1"
                                                rows={3}
                                            />
                                        ) : (
                                            <Input
                                                value={fieldValue}
                                                onChange={(e) => handleAnswerChange(question.id, e.target.value, field.id)}
                                                placeholder={field.placeholder}
                                                className="mt-1"
                                            />
                                        )}
                                    </div>
                                );
                            })}
                        </div>
                    )}
                </div>

                <div className="flex justify-between">
                    <Button 
                        variant="outline" 
                        onClick={handleBack}
                        disabled={currentQuestion === 0}
                    >
                        Back
                    </Button>
                    <Button 
                        onClick={handleNext}
                        disabled={!isAnswerComplete()}
                        className="bg-blue-600 hover:bg-blue-700"
                    >
                        {currentQuestion === assessmentQuestions.length - 1 ? (
                            <>
                                <CheckCircle className="w-4 h-4 mr-2" />
                                Generate My Custom CMMC Package
                            </>
                        ) : (
                            <>
                                Next Step
                                <ArrowRight className="w-4 h-4 ml-2" />
                            </>
                        )}
                    </Button>
                </div>
            </CardContent>
        </Card>
    );
}