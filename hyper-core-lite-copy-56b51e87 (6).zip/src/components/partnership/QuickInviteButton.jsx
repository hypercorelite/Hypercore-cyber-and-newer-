import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { UserPlus, Send } from 'lucide-react';
import { PartnershipCommunication } from "@/api/entities";
import { toast } from "sonner";

export default function QuickInviteButton() {
    const [open, setOpen] = useState(false);
    const [formData, setFormData] = useState({
        email: '',
        name: '',
        organization: '',
        sector: ''
    });

    const handleQuickInvite = async () => {
        try {
            // Create the partnership communication record
            await PartnershipCommunication.create({
                organization: formData.organization,
                contact_person: formData.name,
                email: formData.email,
                partnership_type: formData.sector,
                subject: `Demo Invitation: HyperCore AI Platform Access`,
                message: `You have been invited to access our secure demo portal for ${formData.sector} evaluation.`,
                status: 'sent',
                priority: 'high',
                notes: `Quick invite sent on ${new Date().toLocaleDateString()}`
            });

            toast.success(`Demo invite sent to ${formData.name}!`);
            setOpen(false);
            setFormData({ email: '', name: '', organization: '', sector: '' });
        } catch (error) {
            toast.error('Failed to send invite');
            console.error('Invite error:', error);
        }
    };

    return (
        <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
                <Button className="bg-green-600 hover:bg-green-700">
                    <UserPlus className="w-4 h-4 mr-2" />
                    Quick Demo Invite
                </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
                <DialogHeader>
                    <DialogTitle>Send Demo Invitation</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                    <Input
                        placeholder="Contact Name"
                        value={formData.name}
                        onChange={(e) => setFormData({...formData, name: e.target.value})}
                    />
                    <Input
                        placeholder="Email Address"
                        type="email"
                        value={formData.email}
                        onChange={(e) => setFormData({...formData, email: e.target.value})}
                    />
                    <Input
                        placeholder="Organization"
                        value={formData.organization}
                        onChange={(e) => setFormData({...formData, organization: e.target.value})}
                    />
                    <Select value={formData.sector} onValueChange={(value) => setFormData({...formData, sector: value})}>
                        <SelectTrigger>
                            <SelectValue placeholder="Select Sector" />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="legal_partner">Legal Partner</SelectItem>
                            <SelectItem value="insurance_partner">Insurance Partner</SelectItem>
                            <SelectItem value="defense_contractor">Defense Contractor</SelectItem>
                            <SelectItem value="municipal_government">Municipal Government</SelectItem>
                            <SelectItem value="energy_partner">Energy Partner</SelectItem>
                        </SelectContent>
                    </Select>
                    <Button onClick={handleQuickInvite} className="w-full" disabled={!formData.email || !formData.sector}>
                        <Send className="w-4 h-4 mr-2" />
                        Send Demo Invite
                    </Button>
                </div>
            </DialogContent>
        </Dialog>
    );
}