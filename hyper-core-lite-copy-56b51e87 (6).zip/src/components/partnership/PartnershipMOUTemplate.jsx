import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { FileText, Download, Handshake } from 'lucide-react';
import { toast } from "sonner";

export default function PartnershipMOUTemplate() {
    const [partnerData, setPartnerData] = useState({
        partnerName: "",
        partnerType: "",
        revenueShare: "",
        recognitionLevel: "",
        services: ""
    });

    const partnershipModels = [
        { 
            type: "API Integration Partner", 
            revenueShare: "15-20%", 
            recognition: "Powered by HyperCore badge + co-marketing",
            description: "Technical integration where partner's platform uses HyperCore AI engine"
        },
        { 
            type: "Bundled Solution Partner", 
            revenueShare: "20-30%", 
            recognition: "Joint branding + shared booth space at events",
            description: "Combined offering where both platforms are sold together"
        },
        { 
            type: "White-Label Partner", 
            revenueShare: "25-35%", 
            recognition: "HyperCore credit in footer + case studies",
            description: "Partner sells HyperCore tools under their brand"
        },
        { 
            type: "Referral Partner", 
            revenueShare: "10-15%", 
            recognition: "Preferred Partner status + website listing",
            description: "Partner refers clients to HyperCore for AI compliance tools"
        }
    ];

    const generateMOU = () => {
        const mouContent = `
MEMORANDUM OF UNDERSTANDING
AI-First CMMC Compliance Partnership

Between: HyperCore Cyber and ${partnerData.partnerName}

PARTNERSHIP MODEL: ${partnerData.partnerType}
REVENUE SHARING: ${partnerData.revenueShare}% to ${partnerData.partnerName}
RECOGNITION: ${partnerData.recognitionLevel}

1. PURPOSE
This MOU establishes a strategic partnership to deliver AI-first CMMC compliance solutions to the Defense Industrial Base (DIB), leveraging HyperCore's automation platform with ${partnerData.partnerName}'s ${partnerData.services}.

2. SCOPE OF SERVICES
${partnerData.partnerName} will:
- Integrate HyperCore AI tools into their service offerings
- Maintain "Powered by HyperCore" recognition as specified
- Provide client support and implementation services
- Share revenue based on agreed percentage structure

HyperCore Cyber will:
- Provide AI compliance automation platform
- Offer technical support and integration assistance
- Share marketing materials and co-branding assets
- Process payments and handle revenue distribution

3. REVENUE STRUCTURE
- ${partnerData.partnerName} receives ${partnerData.revenueShare}% of gross revenue from jointly acquired clients
- Monthly payment within 30 days of collection
- Minimum quarterly revenue threshold: $5,000

4. RECOGNITION & MARKETING
- ${partnerData.recognitionLevel}
- Joint case studies and success stories
- Co-marketing at industry events
- Shared content creation and thought leadership

5. TERM & TERMINATION
- Initial term: 12 months
- Auto-renewal unless terminated with 60 days notice
- Either party may terminate for cause immediately

This MOU represents our mutual commitment to serving the DIB market with innovative AI-first compliance solutions.

Signatures:
HyperCore Cyber: _________________ Date: _________
${partnerData.partnerName}: _________________ Date: _________
        `;

        // Create downloadable file
        const blob = new Blob([mouContent], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `HyperCore_${partnerData.partnerName}_MOU.txt`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);

        toast.success("MOU template downloaded successfully!");
    };

    return (
        <div className="space-y-6">
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Handshake className="w-5 h-5 text-blue-600" />
                        Partnership MOU Generator
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="grid md:grid-cols-2 gap-4">
                        <div>
                            <label className="block text-sm font-medium mb-2">Partner Name</label>
                            <Input
                                placeholder="e.g., PreVeil, Core-CSI"
                                value={partnerData.partnerName}
                                onChange={(e) => setPartnerData({...partnerData, partnerName: e.target.value})}
                            />
                        </div>
                        <div>
                            <label className="block text-sm font-medium mb-2">Partnership Type</label>
                            <Select
                                value={partnerData.partnerType}
                                onValueChange={(value) => {
                                    const model = partnershipModels.find(m => m.type === value);
                                    setPartnerData({
                                        ...partnerData, 
                                        partnerType: value,
                                        revenueShare: model?.revenueShare || "",
                                        recognitionLevel: model?.recognition || ""
                                    });
                                }}
                            >
                                <SelectTrigger>
                                    <SelectValue placeholder="Select partnership model" />
                                </SelectTrigger>
                                <SelectContent>
                                    {partnershipModels.map((model) => (
                                        <SelectItem key={model.type} value={model.type}>
                                            {model.type}
                                        </SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>
                    </div>

                    <div>
                        <label className="block text-sm font-medium mb-2">Partner Services/Expertise</label>
                        <Input
                            placeholder="e.g., zero-trust email, enterprise consulting, GRC platforms"
                            value={partnerData.services}
                            onChange={(e) => setPartnerData({...partnerData, services: e.target.value})}
                        />
                    </div>

                    {partnerData.partnerType && (
                        <div className="p-4 bg-blue-50 rounded-lg">
                            <h4 className="font-semibold text-blue-800 mb-2">Partnership Details:</h4>
                            <div className="space-y-2 text-sm">
                                <p><strong>Revenue Share:</strong> {partnerData.revenueShare}</p>
                                <p><strong>Recognition:</strong> {partnerData.recognitionLevel}</p>
                                <p><strong>Description:</strong> {partnershipModels.find(m => m.type === partnerData.partnerType)?.description}</p>
                            </div>
                        </div>
                    )}

                    <Button 
                        onClick={generateMOU}
                        disabled={!partnerData.partnerName || !partnerData.partnerType}
                        className="w-full"
                    >
                        <Download className="w-4 h-4 mr-2" />
                        Generate Partnership MOU
                    </Button>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>Partnership Models Comparison</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="grid md:grid-cols-2 gap-4">
                        {partnershipModels.map((model, index) => (
                            <div key={index} className="p-4 border rounded-lg">
                                <h4 className="font-semibold text-gray-800">{model.type}</h4>
                                <p className="text-sm text-gray-600 mt-1">{model.description}</p>
                                <div className="mt-2 flex flex-wrap gap-2">
                                    <Badge variant="outline">{model.revenueShare}</Badge>
                                    <Badge variant="secondary">Recognition Included</Badge>
                                </div>
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}