import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Download, AlertTriangle, CheckCircle, Lightbulb } from 'lucide-react';
import { motion } from 'framer-motion';

const AIGapAnalysisResults = ({ analysis, onGeneratePdfs }) => {
    if (!analysis) return null;

    const { summary, gaps, overall_score } = analysis;

    const getScoreColor = (score) => {
        if (score >= 80) return 'bg-green-100 text-green-800';
        if (score >= 50) return 'bg-yellow-100 text-yellow-800';
        return 'bg-red-100 text-red-800';
    };

    return (
        <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="space-y-8"
        >
            <Card className="border-blue-200 bg-blue-50">
                <CardHeader>
                    <div className="flex justify-between items-center">
                        <CardTitle className="text-2xl text-blue-800">AI Gap Analysis Summary</CardTitle>
                        <Badge className={`px-4 py-2 text-lg ${getScoreColor(overall_score)}`}>
                            Score: {overall_score} / 100
                        </Badge>
                    </div>
                    <CardDescription className="text-blue-700">{summary}</CardDescription>
                </CardHeader>
                <CardContent>
                     <Button onClick={onGeneratePdfs} size="lg" className="w-full">
                        <Download className="w-5 h-5 mr-2" />
                        Download Your Gap Analysis & Action Plan PDF
                    </Button>
                    <p className="text-xs text-center mt-2 text-gray-500">
                        This report includes your SPRS score estimate, prioritized action items, and cost estimates.
                    </p>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>Prioritized Compliance Gaps</CardTitle>
                    <CardDescription>
                        Our AI has identified the following areas requiring attention to meet CMMC Level 2.
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    {gaps && gaps.length > 0 ? (
                        <div className="space-y-6">
                            {gaps.map((gap, index) => (
                                <motion.div
                                    key={index}
                                    initial={{ opacity: 0, x: -20 }}
                                    animate={{ opacity: 1, x: 0 }}
                                    transition={{ delay: index * 0.1 }}
                                    className="p-4 border rounded-lg"
                                >
                                    <div className="flex items-start gap-4">
                                        <AlertTriangle className="w-6 h-6 text-orange-500 mt-1" />
                                        <div className="flex-1">
                                            <h3 className="font-semibold text-gray-800">
                                                {gap.controlId}: {gap.controlTitle}
                                            </h3>
                                            <p className="text-sm text-gray-600 mt-1">{gap.analysis}</p>
                                            <div className="mt-3 p-3 bg-green-50 rounded-md border border-green-200">
                                                <div className="flex items-center gap-2">
                                                    <Lightbulb className="w-4 h-4 text-green-600" />
                                                    <h4 className="text-sm font-semibold text-green-800">Recommended Action</h4>
                                                </div>
                                                <p className="text-sm text-green-700 mt-1">{gap.recommendation}</p>
                                            </div>
                                        </div>
                                    </div>
                                </motion.div>
                            ))}
                        </div>
                    ) : (
                        <div className="text-center py-8">
                            <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-4" />
                            <h3 className="text-xl font-semibold text-gray-800">No Major Gaps Identified!</h3>
                            <p className="text-gray-600 mt-2">
                                Based on your responses, your foundational controls appear strong. The next step is to formalize documentation.
                            </p>
                        </div>
                    )}
                </CardContent>
            </Card>
        </motion.div>
    );
};

export default AIGapAnalysisResults;