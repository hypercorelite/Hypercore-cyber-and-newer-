import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { motion } from "framer-motion";
import { ShieldCheck, TrendingUp, ShieldAlert } from 'lucide-react';

const ASSESSMENT_QUESTIONS = [
    { id: 'q1', text: 'Do you enforce Multi-Factor Authentication (MFA) for all users?', weight: 25 },
    { id: 'q2', text: 'Do you have a written Information Security Policy (WISP)?', weight: 20 },
    { id: 'q3', text: 'Do you conduct regular security awareness training for employees?', weight: 15 },
    { id: 'q4', text: 'Do you have a formal incident response plan?', weight: 15 },
    { id: 'q5', text: 'Do you have a system for managing and patching software vulnerabilities?', weight: 15 },
    { id: 'q6', text: 'Do you encrypt sensitive data both at rest and in transit?', weight: 10 },
];

export default function CyberScoreAssessor({ organizationName }) {
    const [answers, setAnswers] = useState({});
    const [score, setScore] = useState(null);

    const handleAnswerChange = (id, checked) => {
        setAnswers(prev => ({ ...prev, [id]: checked }));
    };

    const calculateScore = () => {
        let calculatedScore = 0;
        ASSESSMENT_QUESTIONS.forEach(q => {
            if (answers[q.id]) {
                calculatedScore += q.weight;
            }
        });
        setScore(calculatedScore);
    };

    const getScoreColor = (s) => {
        if (s > 75) return "bg-green-500";
        if (s > 40) return "bg-yellow-500";
        return "bg-red-500";
    };
    
    const getScoreFeedback = (s) => {
        if (s > 75) return { title: "Strong Posture", text: "You have strong foundational controls, making you a low-risk partner.", icon: ShieldCheck };
        if (s > 40) return { title: "Needs Improvement", text: "You have some controls, but there are key gaps to address.", icon: TrendingUp };
        return { title: "High Risk Identified", text: "There are significant gaps in your security controls that require immediate attention.", icon: ShieldAlert };
    };

    return (
        <Card>
            <CardHeader>
                <CardTitle>Instant Cybersecurity Score</CardTitle>
                <CardDescription>Answer a few questions to get a high-level estimate of your organization's cyber resilience.</CardDescription>
            </CardHeader>
            <CardContent>
                <div className="space-y-4 mb-6">
                    {ASSESSMENT_QUESTIONS.map(q => (
                        <div key={q.id} className="flex items-center space-x-2">
                            <Checkbox id={q.id} onCheckedChange={(checked) => handleAnswerChange(q.id, checked)} />
                            <Label htmlFor={q.id}>{q.text}</Label>
                        </div>
                    ))}
                </div>
                <Button onClick={calculateScore} className="w-full">Calculate My Score</Button>

                {score !== null && (
                    <motion.div 
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="mt-6 text-center"
                    >
                        <CardDescription>Estimated Cyber Score for {organizationName}</CardDescription>
                        <div className="text-6xl font-bold my-2">{score}</div>
                        <Progress value={score} className="h-4" indicatorClassName={getScoreColor(score)} />
                        
                        <div className="mt-4 flex items-center justify-center gap-4 p-4 bg-gray-50 rounded-lg">
                           {React.createElement(getScoreFeedback(score).icon, {className: "w-8 h-8"})}
                           <div>
                               <h4 className="font-semibold">{getScoreFeedback(score).title}</h4>
                               <p className="text-sm text-gray-600">{getScoreFeedback(score).text}</p>
                           </div>
                        </div>
                    </motion.div>
                )}
            </CardContent>
        </Card>
    );
}