
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Download, FileText } from 'lucide-react';
import { jsPDF } from 'jspdf';
import { toast } from "sonner";

// LOI Form JSON Structure (your design)
const loiFormStructure = {
  formMetadata: {
    title: "HyperCore Cyber CMMC Compliance Platform Letter of Intent",
    version: "1.0.0",
    date: "2025-09-17",
    description: "Engagement form for SMB DoD contractors to commit to HyperCore Cyber's AI platform",
    compliance: "CMMC Level 2, NIST SP 800-171, DFARS 252.204-7021"
  }
};

export default function LOIFormGenerator({ onSubmit }) {
    const [formData, setFormData] = useState({
        // Company Info
        companyName: '',
        cageCode: '',
        uei: '',
        contractNumbers: '',
        
        // Representative Info
        repName: '',
        repTitle: '',
        repEmail: '',
        
        // Commitment
        commitmentLevel: 'Pilot Participant (Phase I Beta, Free)',
        intentStatement: 'As a DoD contractor, we intend to use HyperCore Cyber\'s AI platform to prepare for CMMC Level 2 compliance, including SSP generation, policy development, and 3PAO audit readiness, to meet DFARS 252.204-7021 requirements.',
        
        // Feedback
        likeFeedback: '',
        loveFeedback: '',
        improveFeedback: '',
        priorityFeatures: 'Automated SSP Generation',
        
        // Signature
        signatureDate: new Date().toISOString().split('T')[0],
        digitalSignatureConsent: false
    });

    const [isSubmitting, setIsSubmitting] = useState(false);
    const [submissionSuccess, setSubmissionSuccess] = useState(false);

    const handleInputChange = (field, value) => {
        setFormData(prev => ({ ...prev, [field]: value }));
    };

    const validateForm = () => {
        const required = ['companyName', 'cageCode', 'uei', 'repName', 'repTitle', 'repEmail'];
        const missing = required.filter(field => !formData[field]);
        
        if (missing.length > 0) {
            toast.error(`Please fill in required fields: ${missing.map(field => {
                const fieldMap = {
                    companyName: 'Company Name',
                    cageCode: 'CAGE Code',
                    uei: 'UEI',
                    repName: 'Full Name',
                    repTitle: 'Title',
                    repEmail: 'Email',
                };
                return fieldMap[field] || field;
            }).join(', ')}`);
            return false;
        }
        
        // Basic email validation
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (formData.repEmail && !emailRegex.test(formData.repEmail)) {
            toast.error('Please enter a valid email address for the representative.');
            return false;
        }

        if (!formData.digitalSignatureConsent) {
            toast.error('Digital signature consent is required to submit the LOI.');
            return false;
        }
        
        return true;
    };

    const handleSubmit = async () => {
        if (!validateForm()) {
            return;
        }

        if (!onSubmit) {
            toast.error("LOI submission handler is not configured. Please contact support.");
            console.error("LOIFormGenerator: onSubmit prop is missing.");
            return;
        }

        setIsSubmitting(true);
        try {
            // Assume onSubmit is an async function that sends data and returns { success: boolean, message?: string }
            const result = await onSubmit(formData);
            
            // Track LOI submission conversion
            if (window.trackConversion) {
                window.trackConversion('loi_submission', {
                    commitment_level: formData.commitmentLevel,
                    company_size: 'smb_defense_contractor',
                    priority_feature: formData.priorityFeatures,
                    amount: 99 // Estimated monthly value for a typical subscription
                });
            }

            if (result && result.success) {
                // PDF Generation logic, moved from original generateLoiPdf and integrated here
                const doc = new jsPDF();
                let currentY = 20; // Starting Y position for content

                // Header
                doc.setFontSize(18);
                doc.text('Letter of Intent', 20, currentY);
                currentY += 10;
                doc.setFontSize(12);
                doc.text('HyperCore Cyber CMMC Compliance Platform', 20, currentY);
                currentY += 10;
                doc.text(`Date: ${formData.signatureDate}`, 20, currentY);
                currentY += 20; // Space before next section
                
                // Company Information
                doc.setFontSize(14);
                doc.text('Company Information', 20, currentY);
                currentY += 10;
                doc.setFontSize(10);
                doc.text(`Company Name: ${formData.companyName}`, 20, currentY);
                currentY += 10;
                doc.text(`CAGE Code: ${formData.cageCode}`, 20, currentY);
                currentY += 10;
                doc.text(`UEI: ${formData.uei}`, 20, currentY);
                currentY += 10;
                if (formData.contractNumbers) {
                    doc.text(`DoD Contracts: ${formData.contractNumbers}`, 20, currentY);
                    currentY += 10;
                }
                currentY += 10; // Space before next section
                
                // Representative
                doc.setFontSize(14);
                doc.text('Authorized Representative', 20, currentY);
                currentY += 10;
                doc.setFontSize(10);
                doc.text(`Name: ${formData.repName}`, 20, currentY);
                currentY += 10;
                doc.text(`Title: ${formData.repTitle}`, 20, currentY);
                currentY += 10;
                doc.text(`Email: ${formData.repEmail}`, 20, currentY);
                currentY += 20; // Space before next section
                
                // Intent Statement
                doc.setFontSize(14);
                doc.text('Intent Statement', 20, currentY);
                currentY += 10;
                doc.setFontSize(10);
                const intentLines = doc.splitTextToSize(formData.intentStatement, 170);
                doc.text(intentLines, 20, currentY);
                currentY += (intentLines.length * 7) + 10; // Approx line height + space
                
                // Commitment Level
                doc.text(`Commitment Level: ${formData.commitmentLevel}`, 20, currentY);
                currentY += 20; // Space before next section
                
                // Feedback Section
                doc.setFontSize(14);
                doc.text('Platform Feedback', 20, currentY);
                currentY += 10;
                doc.setFontSize(10);
                doc.text(`Priority Features: ${formData.priorityFeatures}`, 20, currentY);
                currentY += 10;
                
                if (formData.likeFeedback) {
                    currentY += 5; // Small buffer
                    doc.text('What We Like:', 20, currentY);
                    currentY += 5; // Text start Y
                    const likeLines = doc.splitTextToSize(formData.likeFeedback, 170);
                    doc.text(likeLines, 20, currentY);
                    currentY += (likeLines.length * 7); // Approx line height
                }
                
                if (formData.loveFeedback) {
                    currentY += 5; // Small buffer
                    doc.text('What We Love:', 20, currentY);
                    currentY += 5; // Text start Y
                    const loveLines = doc.splitTextToSize(formData.loveFeedback, 170);
                    doc.text(loveLines, 20, currentY);
                    currentY += (loveLines.length * 7);
                }
                
                if (formData.improveFeedback) {
                    currentY += 5; // Small buffer
                    doc.text('What Needs Improvement:', 20, currentY);
                    currentY += 5; // Text start Y
                    const improveLines = doc.splitTextToSize(formData.improveFeedback, 170);
                    doc.text(improveLines, 20, currentY);
                    currentY += (improveLines.length * 7);
                }
                
                // Ensure there's enough space for signature on the current page, or add new page
                if (currentY > 260) { // Arbitrary threshold, adjust as needed
                    doc.addPage();
                    currentY = 20;
                } else {
                    currentY += 20; // Space before signature
                }

                // Signature
                doc.setFontSize(12);
                doc.text('Digital Signature Consent: ✓ Agreed', 20, currentY);
                currentY += 10;
                doc.text(`Signed: ${formData.repName}, ${formData.repTitle}`, 20, currentY);
                doc.text(`Date: ${formData.signatureDate}`, 120, currentY);

                // Save PDF
                doc.save(`${formData.companyName.replace(/\s+/g, '_')}_LOI.pdf`);
                
                toast.success("LOI submitted and PDF downloaded successfully! Thank you for your commitment.");
                setSubmissionSuccess(true);
            } else {
                throw new Error(result ? result.message || "Submission failed" : "Submission failed");
            }
        } catch (error) {
            toast.error(`Failed to submit LOI: ${error.message || "Please try again."}`);
            console.error(error);
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <Card className="max-w-4xl mx-auto">
            <CardHeader>
                <CardTitle className="flex items-center gap-2">
                    <FileText className="w-6 h-6 text-blue-600" />
                    Letter of Intent Generator
                </CardTitle>
                <p className="text-sm text-gray-600">
                    Generate a professional LOI for CMMC compliance partnership with HyperCore Cyber
                </p>
            </CardHeader>
            <CardContent className="space-y-6">
                {/* Company Information */}
                <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Company Information</h3>
                    <div className="grid md:grid-cols-2 gap-4">
                        <Input
                            placeholder="Company Name *"
                            value={formData.companyName}
                            onChange={(e) => handleInputChange('companyName', e.target.value)}
                            disabled={isSubmitting}
                        />
                        <Input
                            placeholder="CAGE Code *"
                            value={formData.cageCode}
                            onChange={(e) => handleInputChange('cageCode', e.target.value)}
                            disabled={isSubmitting}
                        />
                        <Input
                            placeholder="UEI *"
                            value={formData.uei}
                            onChange={(e) => handleInputChange('uei', e.target.value)}
                            disabled={isSubmitting}
                        />
                        <Input
                            placeholder="DoD Contract Numbers (optional)"
                            value={formData.contractNumbers}
                            onChange={(e) => handleInputChange('contractNumbers', e.target.value)}
                            disabled={isSubmitting}
                        />
                    </div>
                </div>

                {/* Representative Information */}
                <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Authorized Representative</h3>
                    <div className="grid md:grid-cols-3 gap-4">
                        <Input
                            placeholder="Full Name *"
                            value={formData.repName}
                            onChange={(e) => handleInputChange('repName', e.target.value)}
                            disabled={isSubmitting}
                        />
                        <Input
                            placeholder="Title *"
                            value={formData.repTitle}
                            onChange={(e) => handleInputChange('repTitle', e.target.value)}
                            disabled={isSubmitting}
                        />
                        <Input
                            type="email"
                            placeholder="Email *"
                            value={formData.repEmail}
                            onChange={(e) => handleInputChange('repEmail', e.target.value)}
                            disabled={isSubmitting}
                        />
                    </div>
                </div>

                {/* Commitment Level */}
                <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Commitment Level</h3>
                    <Select 
                        value={formData.commitmentLevel} 
                        onValueChange={(value) => handleInputChange('commitmentLevel', value)}
                        disabled={isSubmitting}
                    >
                        <SelectTrigger>
                            <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="Pilot Participant (Phase I Beta, Free)">
                                Pilot Participant (Phase I Beta, Free)
                            </SelectItem>
                            <SelectItem value="Early Adopter (Post-Phase I, Freemium)">
                                Early Adopter (Post-Phase I, Freemium)
                            </SelectItem>
                            <SelectItem value="Paid Subscriber ($99/month Post-Phase II)">
                                Paid Subscriber ($99/month Post-Phase II)
                            </SelectItem>
                        </SelectContent>
                    </Select>
                </div>

                {/* Intent Statement */}
                <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Intent Statement</h3>
                    <Textarea
                        value={formData.intentStatement}
                        onChange={(e) => handleInputChange('intentStatement', e.target.value)}
                        rows={4}
                        className="text-sm"
                        disabled={isSubmitting}
                    />
                </div>

                {/* Platform Feedback */}
                <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Platform Feedback</h3>
                    <div className="grid md:grid-cols-2 gap-4">
                        <div>
                            <label className="text-sm font-medium">Priority Features</label>
                            <Select 
                                value={formData.priorityFeatures} 
                                onValueChange={(value) => handleInputChange('priorityFeatures', value)}
                                disabled={isSubmitting}
                            >
                                <SelectTrigger>
                                    <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="Automated SSP Generation">Automated SSP Generation</SelectItem>
                                    <SelectItem value="Policy and Procedure Templates">Policy Templates</SelectItem>
                                    <SelectItem value="110-Control Mapping and Scoring">Control Mapping</SelectItem>
                                    <SelectItem value="POA&M and SPRS Reporting">POAM & SPRS</SelectItem>
                                    <SelectItem value="Implementation Guidance">Implementation Guidance</SelectItem>
                                    <SelectItem value="Mock 3PAO Audit Simulator">Audit Simulator</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                    </div>
                    
                    <div className="space-y-3">
                        <Textarea
                            placeholder="What do you like about our platform?"
                            value={formData.likeFeedback}
                            onChange={(e) => handleInputChange('likeFeedback', e.target.value)}
                            rows={2}
                            disabled={isSubmitting}
                        />
                        <Textarea
                            placeholder="What do you love about our platform?"
                            value={formData.loveFeedback}
                            onChange={(e) => handleInputChange('loveFeedback', e.target.value)}
                            rows={2}
                            disabled={isSubmitting}
                        />
                        <Textarea
                            placeholder="What needs improvement?"
                            value={formData.improveFeedback}
                            onChange={(e) => handleInputChange('improveFeedback', e.target.value)}
                            rows={2}
                            disabled={isSubmitting}
                        />
                    </div>
                </div>

                {/* Digital Signature Consent */}
                <div className="flex items-start space-x-2">
                    <Checkbox 
                        id="signature-consent" 
                        checked={formData.digitalSignatureConsent}
                        onCheckedChange={(checked) => handleInputChange('digitalSignatureConsent', checked)}
                        disabled={isSubmitting}
                    />
                    <label htmlFor="signature-consent" className="text-sm">
                        I agree to digitally sign this Letter of Intent and authorize its use for SBIR proposal purposes. 
                        This constitutes a legal digital signature equivalent to a handwritten signature.
                    </label>
                </div>

                {/* Submit Button */}
                <Button 
                    onClick={handleSubmit}
                    className="w-full bg-blue-600 hover:bg-blue-700"
                    size="lg"
                    disabled={isSubmitting}
                >
                    <Download className="w-4 h-4 mr-2" />
                    {isSubmitting ? "Submitting & Generating..." : "Submit LOI & Download PDF"}
                </Button>
            </CardContent>
        </Card>
    );
}
