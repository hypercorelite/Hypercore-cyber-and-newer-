import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Check, X } from 'lucide-react';
import { cn } from "@/lib/utils";

const ValuePropositionComparison = ({ title, description, badge, items, isFeatured = false }) => {
    return (
        <Card className={cn("flex flex-col h-full", isFeatured && "ring-2 ring-blue-600 shadow-xl bg-blue-50")}>
            <CardHeader>
                {badge && <Badge className={cn("w-fit mb-2", isFeatured ? "bg-blue-600" : "bg-gray-600")}>{badge}</Badge>}
                <CardTitle>{title}</CardTitle>
                <CardDescription>{description}</CardDescription>
            </CardHeader>
            <CardContent className="flex-grow">
                <ul className="space-y-3">
                    {items.map((item, index) => (
                        <li key={index} className="flex items-start gap-3">
                            {item.included ? (
                                <Check className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                            ) : (
                                <X className="w-5 h-5 text-red-500 mt-0.5 flex-shrink-0" />
                            )}
                            <span className="text-sm">{item.text}</span>
                        </li>
                    ))}
                </ul>
            </CardContent>
        </Card>
    );
};

export default ValuePropositionComparison;