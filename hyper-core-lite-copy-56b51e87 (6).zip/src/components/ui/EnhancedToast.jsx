import React from 'react';
import { toast as sonnerToast } from 'sonner';
import { CheckCircle, AlertTriangle, Info, X } from 'lucide-react';

const toastStyles = {
  success: {
    icon: CheckCircle,
    className: 'border-green-200 bg-green-50 text-green-800',
    iconColor: 'text-green-600'
  },
  error: {
    icon: AlertTriangle,
    className: 'border-red-200 bg-red-50 text-red-800',
    iconColor: 'text-red-600'
  },
  info: {
    icon: Info,
    className: 'border-blue-200 bg-blue-50 text-blue-800',
    iconColor: 'text-blue-600'
  }
};

export const toast = {
  success: (message, options = {}) => {
    const style = toastStyles.success;
    const Icon = style.icon;
    
    return sonnerToast.custom(() => (
      <div className={`flex items-center gap-3 p-4 rounded-lg border ${style.className} shadow-sm`}>
        <Icon className={`h-5 w-5 ${style.iconColor}`} />
        <div className="flex-1">
          <p className="font-medium">{message}</p>
          {options.description && (
            <p className="text-sm opacity-90 mt-1">{options.description}</p>
          )}
        </div>
      </div>
    ), {
      duration: options.duration || 4000,
      ...options
    });
  },

  error: (message, options = {}) => {
    const style = toastStyles.error;
    const Icon = style.icon;
    
    return sonnerToast.custom(() => (
      <div className={`flex items-center gap-3 p-4 rounded-lg border ${style.className} shadow-sm`}>
        <Icon className={`h-5 w-5 ${style.iconColor}`} />
        <div className="flex-1">
          <p className="font-medium">{message}</p>
          {options.description && (
            <p className="text-sm opacity-90 mt-1">{options.description}</p>
          )}
        </div>
      </div>
    ), {
      duration: options.duration || 6000,
      ...options
    });
  },

  info: (message, options = {}) => {
    const style = toastStyles.info;
    const Icon = style.icon;
    
    return sonnerToast.custom(() => (
      <div className={`flex items-center gap-3 p-4 rounded-lg border ${style.className} shadow-sm`}>
        <Icon className={`h-5 w-5 ${style.iconColor}`} />
        <div className="flex-1">
          <p className="font-medium">{message}</p>
          {options.description && (
            <p className="text-sm opacity-90 mt-1">{options.description}</p>
          )}
        </div>
      </div>
    ), {
      duration: options.duration || 4000,
      ...options
    });
  }
};