import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TrendingUp, TrendingDown, Minus } from 'lucide-react';

export default function AdminMetricsWidget({ title, value, previousValue, icon: Icon, trend = null }) {
  const getTrendIcon = () => {
    if (trend === null || previousValue === undefined) return null;
    
    if (value > previousValue) return <TrendingUp className="w-4 h-4 text-green-600" />;
    if (value < previousValue) return <TrendingDown className="w-4 h-4 text-red-600" />;
    return <Minus className="w-4 h-4 text-gray-400" />;
  };

  const getTrendColor = () => {
    if (trend === null || previousValue === undefined) return 'text-gray-500';
    
    if (value > previousValue) return 'text-green-600';
    if (value < previousValue) return 'text-red-600';
    return 'text-gray-500';
  };

  const calculatePercentageChange = () => {
    if (previousValue === undefined || previousValue === 0) return null;
    
    const change = ((value - previousValue) / previousValue) * 100;
    return Math.abs(change).toFixed(1);
  };

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium text-gray-600">{title}</CardTitle>
        {Icon && <Icon className="w-5 h-5 text-gray-400" />}
      </CardHeader>
      <CardContent>
        <div className="flex items-center space-x-2">
          <div className="text-2xl font-bold">{value}</div>
          {getTrendIcon()}
        </div>
        {calculatePercentageChange() && (
          <p className={`text-xs ${getTrendColor()} mt-1`}>
            {value > previousValue ? '+' : ''}{calculatePercentageChange()}% from last period
          </p>
        )}
      </CardContent>
    </Card>
  );
}