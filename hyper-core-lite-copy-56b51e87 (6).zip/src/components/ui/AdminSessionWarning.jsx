import React, { useState, useEffect } from 'react';
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Shield, Clock, X } from 'lucide-react';

export default function AdminSessionWarning() {
  const [showWarning, setShowWarning] = useState(false);
  const [timeLeft, setTimeLeft] = useState(300); // 5 minutes in seconds

  useEffect(() => {
    // Simulate session timeout warning (replace with actual session logic)
    const timer = setTimeout(() => {
      setShowWarning(true);
    }, 25 * 60 * 1000); // Show warning after 25 minutes

    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (showWarning && timeLeft > 0) {
      const countdown = setInterval(() => {
        setTimeLeft(prev => prev - 1);
      }, 1000);

      return () => clearInterval(countdown);
    }
  }, [showWarning, timeLeft]);

  if (!showWarning) return null;

  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;

  return (
    <div className="fixed top-4 right-4 z-50 w-80">
      <Alert variant="destructive" className="bg-red-50 border-red-200">
        <Shield className="h-4 w-4 text-red-600" />
        <AlertTitle className="text-red-800 flex items-center justify-between">
          Session Expiring Soon
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowWarning(false)}
            className="h-4 w-4 p-0 text-red-600 hover:text-red-800"
          >
            <X className="h-3 w-3" />
          </Button>
        </AlertTitle>
        <AlertDescription className="text-red-700">
          <div className="flex items-center gap-2 mb-2">
            <Clock className="h-3 w-3" />
            {minutes}:{seconds.toString().padStart(2, '0')} remaining
          </div>
          <Button size="sm" className="bg-red-600 hover:bg-red-700 text-white">
            Extend Session
          </Button>
        </AlertDescription>
      </Alert>
    </div>
  );
}