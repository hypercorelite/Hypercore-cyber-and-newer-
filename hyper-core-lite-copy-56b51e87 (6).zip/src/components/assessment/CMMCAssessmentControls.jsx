
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { ComplianceTask } from "@/api/entities";
import { Progress } from "@/components/ui/progress";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { CheckCircle, XCircle, AlertCircle, Circle } from 'lucide-react';

const CMMC_DOMAINS = {
    'AC': 'Access Control',
    'IR': 'Incident Response',
    'RA': 'Risk Assessment',
    'SC': 'System and Communications Protection',
    'SI': 'System and Information Integrity',
};

const CMMC_CONTROLS = [
    { id: 'AC.L2-3.1.1', domain: 'AC', text: 'Limit information system access to authorized users.' },
    { id: 'AC.L2-3.1.2', domain: 'AC', text: 'Limit information system access to the types of transactions and functions that authorized users are permitted to execute.' },
    { id: 'AC.L2-3.1.5', domain: 'AC', text: 'Employ the principle of least privilege, including for specific security functions and privileged accounts.' },
    { id: 'IR.L2-3.6.1', domain: 'IR', text: 'Establish an operational incident-handling capability for organizational systems and data.' },
    { id: 'IR.L2-3.6.2', domain: 'IR', text: 'Track, document, and report incidents to designated officials and/or authorities both internal and external to the organization.' },
    { id: 'RA.L2-3.11.2', domain: 'RA', text: 'Scan for vulnerabilities in organizational systems and applications periodically and when new vulnerabilities are identified.' },
    { id: 'SC.L2-3.13.1', domain: 'SC', text: 'Monitor, control, and protect organizational communications at the external boundaries and key internal boundaries of the systems.' },
    { id: 'SI.L2-3.14.1', domain: 'SI', text: 'Identify, report, and correct information and system flaws in a timely manner.' },
    { id: 'SI.L2-3.14.5', domain: 'SI', text: 'Perform periodic and real-time scans of files and systems from malicious code and update scans when new releases are available.' },
];

const STATUS_OPTIONS = [
    { value: "completed", label: "Compliant", icon: CheckCircle, color: "text-green-600" },
    { value: "rejected", label: "Non-Compliant", icon: XCircle, color: "text-red-600" },
    { value: "pending_human_review", label: "Partial / Needs Review", icon: AlertCircle, color: "text-yellow-600" },
    { value: "pending_ai_analysis", label: "Not Assessed", icon: Circle, color: "text-gray-400" },
];

export default function CMMCAssessmentControls({ framework }) {
    const [tasks, setTasks] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const loadTasks = async () => {
            if (!framework) return;
            setLoading(true);
            const existingTasks = await ComplianceTask.filter({ framework_id: framework.id });
            setTasks(existingTasks);
            setLoading(false);
        };
        loadTasks();
    }, [framework]);

    const handleStatusChange = async (control, newStatus) => {
        const existingTask = tasks.find(t => t.requirement_section === control.id);
        const toastId = toast.loading(`Updating ${control.id}...`);
        
        try {
            if (existingTask) {
                const updatedTask = await ComplianceTask.update(existingTask.id, { status: newStatus });
                setTasks(tasks.map(t => t.id === existingTask.id ? updatedTask : t));
            } else {
                const newTask = await ComplianceTask.create({
                    framework_id: framework.id,
                    task_title: control.text,
                    requirement_section: control.id,
                    task_type: 'audit',
                    priority: 'medium',
                    status: newStatus,
                });
                setTasks([...tasks, newTask]);
            }
            toast.success(`${control.id} updated successfully.`, { id: toastId });
        } catch (error) {
            console.error("Failed to update task:", error);
            toast.error(`Failed to update ${control.id}.`, { id: toastId });
        }
    };

    const getTaskStatus = (controlId) => {
        const task = tasks.find(t => t.requirement_section === controlId);
        return task ? task.status : 'pending_ai_analysis';
    };

    const assessedCount = CMMC_CONTROLS.filter(c => getTaskStatus(c.id) !== 'pending_ai_analysis').length;
    const progress = (assessedCount / CMMC_CONTROLS.length) * 100;

    if (loading) {
        return <div className="text-center p-8">Loading assessment controls...</div>;
    }

    return (
        <Card>
            <CardHeader>
                <CardTitle>CMMC Level 2 Assessment</CardTitle>
                <CardDescription>Assess each control below. Progress is saved automatically.</CardDescription>
                <div className="pt-2">
                    <Label>{assessedCount} of {CMMC_CONTROLS.length} controls assessed</Label>
                    <Progress value={progress} className="mt-1" />
                </div>
            </CardHeader>
            <CardContent>
                <Accordion type="multiple" className="w-full">
                    {Object.entries(CMMC_DOMAINS).map(([domainKey, domainName]) => (
                        <AccordionItem key={domainKey} value={domainKey}>
                            <AccordionTrigger className="font-semibold">{domainKey}: {domainName}</AccordionTrigger>
                            <AccordionContent>
                                <div className="space-y-6 pl-2">
                                    {CMMC_CONTROLS.filter(c => c.domain === domainKey).map(control => (
                                        <div key={control.id}>
                                            <h4 className="font-medium text-sm mb-2">{control.id}: {control.text}</h4>
                                            <RadioGroup
                                                value={getTaskStatus(control.id)}
                                                onValueChange={(newStatus) => handleStatusChange(control, newStatus)}
                                                className="flex flex-wrap gap-4"
                                            >
                                                {STATUS_OPTIONS.map(opt => {
                                                    const Icon = opt.icon;
                                                    return (
                                                        <div key={opt.value} className="flex items-center space-x-2">
                                                            <RadioGroupItem value={opt.value} id={`${control.id}-${opt.value}`} />
                                                            <Label htmlFor={`${control.id}-${opt.value}`} className={`flex items-center gap-1.5 cursor-pointer ${opt.color}`}>
                                                                <Icon className="w-4 h-4" />
                                                                {opt.label}
                                                            </Label>
                                                        </div>
                                                    )
                                                })}
                                            </RadioGroup>
                                        </div>
                                    ))}
                                </div>
                            </AccordionContent>
                        </AccordionItem>
                    ))}
                </Accordion>
            </CardContent>
        </Card>
    );
}
