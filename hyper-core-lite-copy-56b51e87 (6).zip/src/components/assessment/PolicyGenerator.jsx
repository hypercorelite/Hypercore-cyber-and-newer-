import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { generatePolicyDocuments } from '@/api/functions';
import { Download, Loader2, FileText } from 'lucide-react';
import { toast } from 'sonner';

export default function PolicyGenerator() {
  const [clientDetails, setClientDetails] = useState({
    company_name: '',
    industry: '',
    size: '',
    location: '',
    cmmc_level: 'Level 2',
  });
  const [isGenerating, setIsGenerating] = useState(false);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setClientDetails((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleLevelChange = (value) => {
    setClientDetails((prev) => ({ ...prev, cmmc_level: value }));
  };

  const handleGeneratePolicies = async () => {
    setIsGenerating(true);
    toast.info("Generating your policy documents... This may take a moment.");
    try {
      const details = { ...clientDetails, size: parseInt(clientDetails.size) };
      const { data } = await generatePolicyDocuments(details);
      
      const byteCharacters = atob(data.fileContent);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], {type: 'application/pdf'});
      
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', data.fileName);
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);

      toast.success("Policy documents downloaded successfully!");
    } catch (error) {
      console.error('Error generating policies:', error);
      toast.error('Failed to generate policies. Please try again.');
    } finally {
      setIsGenerating(false);
    }
  };
  
  const isFormInvalid = !clientDetails.company_name || !clientDetails.industry || !clientDetails.size || !clientDetails.location;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2"><FileText className="w-5 h-5"/> AI Policy Generator</CardTitle>
        <CardDescription>Enter your company details to generate a set of CMMC-aligned policy documents.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <Input name="company_name" placeholder="Company Name" value={clientDetails.company_name} onChange={handleInputChange} />
          <Input name="industry" placeholder="Industry (e.g., Manufacturing)" value={clientDetails.industry} onChange={handleInputChange} />
          <Input name="size" type="number" placeholder="Number of Employees" value={clientDetails.size} onChange={handleInputChange} />
          <Input name="location" placeholder="Location (e.g., New York, NY)" value={clientDetails.location} onChange={handleInputChange} />
          <Select onValueChange={handleLevelChange} defaultValue={clientDetails.cmmc_level}>
            <SelectTrigger><SelectValue placeholder="Select CMMC Level" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="Level 2">CMMC Level 2</SelectItem>
              <SelectItem value="Level 3">CMMC Level 3</SelectItem>
            </SelectContent>
          </Select>
          <Button onClick={handleGeneratePolicies} disabled={isGenerating || isFormInvalid} className="w-full">
            {isGenerating ? (
              <span className="flex items-center"><Loader2 className="animate-spin h-5 w-5 mr-2" />Generating...</span>
            ) : (
              <span className="flex items-center"><Download className="h-5 w-5 mr-2" />Generate & Download Policies</span>
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}