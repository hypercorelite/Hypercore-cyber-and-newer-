import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ThumbsUp, ThumbsDown, ShieldCheck, CheckCircle } from 'lucide-react';

export default function TopicAnalysisCard({ topic, alignmentScore, achievabilityScore, strengths, risks, verdict }) {
    const getBadgeClass = (score) => {
        if (score === 5) return "bg-green-100 text-green-800 border-green-300";
        if (score === 4) return "bg-blue-100 text-blue-800 border-blue-300";
        return "bg-yellow-100 text-yellow-800 border-yellow-300";
    };

    return (
        <Card className="mt-4 border-gray-200">
            <CardHeader>
                <CardTitle>{topic}</CardTitle>
                <div className="flex gap-4 pt-2">
                    <Badge className={getBadgeClass(alignmentScore)}>Alignment: {alignmentScore}/5</Badge>
                    <Badge className={getBadgeClass(achievabilityScore)}>Achievability: {achievabilityScore}/5</Badge>
                </div>
            </CardHeader>
            <CardContent className="space-y-4">
                <div className="flex items-start gap-3">
                    <ThumbsUp className="w-5 h-5 text-green-500 mt-1 flex-shrink-0" />
                    <div>
                        <h4 className="font-semibold text-gray-800">Key Strengths</h4>
                        <p className="text-sm text-gray-600">{strengths}</p>
                    </div>
                </div>
                <div className="flex items-start gap-3">
                    <ThumbsDown className="w-5 h-5 text-red-500 mt-1 flex-shrink-0" />
                    <div>
                        <h4 className="font-semibold text-gray-800">Key Risks / Challenges</h4>
                        <p className="text-sm text-gray-600">{risks}</p>
                    </div>
                </div>
                 <div className="p-3 bg-gray-50 rounded-md border">
                    <div className="flex items-center gap-2">
                        <CheckCircle className="w-5 h-5 text-indigo-500" />
                        <h4 className="font-semibold text-indigo-700">Verdict: {verdict}</h4>
                    </div>
                </div>
            </CardContent>
        </Card>
    );
}