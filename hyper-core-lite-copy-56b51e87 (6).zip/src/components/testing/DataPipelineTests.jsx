import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { CheckCircle, AlertTriangle, Loader2, Database, Shield } from 'lucide-react';
import { toast } from "sonner";

// Assuming you have a function to test these pipelines.
// For now, we'll simulate them.
const testDataPipeline = async (pipelineName) => {
    return new Promise(resolve => {
        setTimeout(() => {
            resolve({ success: true, message: `Pipeline '${pipelineName}' ran successfully. Data processed and stored.` });
        }, 1500);
    });
};

export default function DataPipelineTests() {
    const [results, setResults] = useState({});
    const [loading, setLoading] = useState({});

    const runTest = async (testName) => {
        setLoading(prev => ({ ...prev, [testName]: true }));
        try {
            const result = await testDataPipeline(testName);
            setResults(prev => ({ ...prev, [testName]: result }));
            toast.success(`✅ ${testName} test passed!`);
        } catch (error) {
            setResults(prev => ({ ...prev, [testName]: { success: false, message: error.message } }));
            toast.error(`❌ ${testName} test failed.`);
        } finally {
            setLoading(prev => ({ ...prev, [testName]: false }));
        }
    };
    
    const tests = [
        { name: "OnboardingDataPipeline", title: "Client Onboarding Data Pipeline", description: "Tests the flow of new client data from signup form to the 'ClientOnboarding' entity." },
        { name: "EngagementDataPipeline", title: "Client Engagement Pipeline", description: "Verifies that client actions (e.g., report download) are logged in the 'ClientEngagement' entity." },
        { name: "FeedbackDataPipeline", title: "Client Feedback Pipeline", description: "Ensures client feedback is correctly captured and stored in the 'ClientFeedback' entity." },
        { name: "SupportTicketPipeline", title: "Support Ticket Data Pipeline", description: "Checks that support tickets are created in the 'SupportTicket' entity and alerts are triggered." }
    ];

    return (
        <div className="grid md:grid-cols-2 gap-6 mt-6">
            {tests.map(test => (
                <Card key={test.name}>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2"><Database className="w-5 h-5 text-blue-600" /> {test.title}</CardTitle>
                        <CardDescription>{test.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <Button onClick={() => runTest(test.name)} disabled={loading[test.name]}>
                            {loading[test.name] ? <Loader2 className="w-4 h-4 mr-2 animate-spin"/> : <Shield className="w-4 h-4 mr-2" />}
                            Run Test
                        </Button>
                        {results[test.name] && (
                            <Alert className={`mt-4 ${results[test.name].success ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'}`}>
                                <AlertTitle>{results[test.name].success ? 'Test Passed' : 'Test Failed'}</AlertTitle>
                                <AlertDescription>{results[test.name].message}</AlertDescription>
                            </Alert>
                        )}
                    </CardContent>
                </Card>
            ))}
        </div>
    );
}