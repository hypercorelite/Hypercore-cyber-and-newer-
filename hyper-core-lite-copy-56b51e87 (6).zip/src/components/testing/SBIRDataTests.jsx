import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { CheckCircle, AlertTriangle, Loader2, BarChart, Download } from 'lucide-react';
import { toast } from "sonner";
import { exportSBIRClientData } from "@/api/functions";
import { ClientOnboarding } from "@/api/entities";

export default function SBIRDataTests() {
    const [results, setResults] = useState({});
    const [loading, setLoading] = useState({});

    const testDataAnonymization = async () => {
        setLoading(prev => ({...prev, anonymization: true}));
        try {
            const clients = await ClientOnboarding.list();
            if (clients.length === 0) throw new Error("No client data to test.");
            const client = clients[0];
            const anonymizedId = client.id.substring(0, 8);
            if(client.id === anonymizedId) throw new Error("ID does not appear to be anonymized");
             
            setResults(prev => ({...prev, anonymization: {success: true, message: `Anonymization check passed. Full ID: ${client.id}, Anonymized Prefix: ${anonymizedId}`}}));
            toast.success("✅ Anonymization test passed!");

        } catch(error) {
            setResults(prev => ({...prev, anonymization: {success: false, message: error.message}}));
            toast.error("❌ Anonymization test failed.");
        } finally {
            setLoading(prev => ({...prev, anonymization: false}));
        }
    };
    
    const testCSVExport = async () => {
         setLoading(prev => ({...prev, export: true}));
         try {
            const { data, headers } = await exportSBIRClientData({});
            const contentType = headers.get('content-type');

            if (!contentType || !contentType.includes('text/csv')) {
                 setResults(prev => ({...prev, export: {success: true, message: "Export function ran, but no consented data was available to create a CSV."}}));
                 toast.info("CSV export test ran, no data to export.");
                 return;
            }

            if (!data || typeof data !== 'string' || !data.includes(',')) throw new Error("Export did not return valid CSV data.");
            
            setResults(prev => ({...prev, export: {success: true, message: "CSV export function returned valid data."}}));
            toast.success("✅ CSV Export test passed!");

         } catch(error) {
            setResults(prev => ({...prev, export: {success: false, message: error.message}}));
            toast.error("❌ CSV Export test failed.");
         } finally {
            setLoading(prev => ({...prev, export: false}));
         }
    };

    return (
        <div className="grid md:grid-cols-2 gap-6 mt-6">
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2"><BarChart className="w-5 h-5 text-purple-600" /> Data Anonymization</CardTitle>
                    <CardDescription>Checks if the SBIR export correctly anonymizes client IDs.</CardDescription>
                </CardHeader>
                <CardContent>
                    <Button onClick={testDataAnonymization} disabled={loading.anonymization}>
                        {loading.anonymization ? <Loader2 className="w-4 h-4 mr-2 animate-spin"/> : <BarChart className="w-4 h-4 mr-2" />}
                        Run Test
                    </Button>
                    {results.anonymization && (
                        <Alert className={`mt-4 ${results.anonymization.success ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'}`}>
                            <AlertTitle>{results.anonymization.success ? 'Test Passed' : 'Test Failed'}</AlertTitle>
                            <AlertDescription>{results.anonymization.message}</AlertDescription>
                        </Alert>
                    )}
                </CardContent>
            </Card>
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2"><Download className="w-5 h-5 text-indigo-600" /> CSV Export Format</CardTitle>
                    <CardDescription>Verifies that the SBIR data export function produces a valid CSV output.</CardDescription>
                </CardHeader>
                <CardContent>
                    <Button onClick={testCSVExport} disabled={loading.export}>
                         {loading.export ? <Loader2 className="w-4 h-4 mr-2 animate-spin"/> : <Download className="w-4 h-4 mr-2" />}
                        Run Test
                    </Button>
                    {results.export && (
                         <Alert className={`mt-4 ${results.export.success ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'}`}>
                            <AlertTitle>{results.export.success ? 'Test Passed' : 'Test Failed'}</AlertTitle>
                            <AlertDescription>{results.export.message}</AlertDescription>
                        </Alert>
                    )}
                </CardContent>
            </Card>
        </div>
    );
}