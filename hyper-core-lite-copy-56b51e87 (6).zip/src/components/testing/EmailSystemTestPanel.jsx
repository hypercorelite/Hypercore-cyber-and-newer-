import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { CheckCircle, AlertTriangle, Send, Mail, Loader2, Info, Cloud } from 'lucide-react';
import { testEmailSystem } from "@/api/functions";
import { toast } from "sonner";
import { User } from "@/api/entities";

export default function EmailSystemTestPanel() {
    const [testResults, setTestResults] = useState({});
    const [testing, setTesting] = useState({});
    const [user, setUser] = useState(null);

    React.useEffect(() => {
        const fetchUser = async () => {
            try {
                const currentUser = await User.me();
                setUser(currentUser);
            } catch (e) {
                console.log("User not logged in");
            }
        };
        fetchUser();
    }, []);

    const runTest = async (testName, testFunction, params) => {
        setTesting(prev => ({ ...prev, [testName]: true }));
        try {
            const { data } = await testFunction(params);
            setTestResults(prev => ({ 
                ...prev, 
                [testName]: { success: true, data } 
            }));
            toast.success(`${testName} test completed successfully.`);
        } catch (error) {
            // Attempt to parse error response
            const errorData = error.response?.data || { details: error.message };
            setTestResults(prev => ({ 
                ...prev, 
                [testName]: { success: false, error: errorData.details || error.message } 
            }));
            toast.error(`${testName} test failed: ${errorData.details || error.message}`);
        } finally {
            setTesting(prev => ({ ...prev, [testName]: false }));
        }
    };
    
    const TestResult = ({ result }) => {
        if (!result) return null;
        return (
             <Alert className={`mt-3 ${result.success ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'}`}>
                {result.success ? <CheckCircle className="h-4 w-4 text-green-600" /> : <AlertTriangle className="h-4 w-4 text-red-600" />}
                <AlertTitle className={result.success ? 'text-green-800' : 'text-red-800'}>
                    {result.success ? 'Test Passed' : 'Test Failed'}
                </AlertTitle>
                <AlertDescription className={`text-xs ${result.success ? 'text-green-700' : 'text-red-700'}`}>
                    {result.success ? result.data.details : result.error}
                </AlertDescription>
            </Alert>
        )
    };

    return (
        <Card>
            <CardHeader>
                <CardTitle className="flex items-center gap-2">
                    <Mail className="w-5 h-5" />
                    Live Email System Diagnostics
                </CardTitle>
                <CardDescription>
                    Verify your email infrastructure configuration and send live test emails to your account ({user?.email || '...loading'}).
                </CardDescription>
            </CardHeader>
            <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* SendGrid */}
                <Card className="p-4">
                    <h4 className="font-semibold flex items-center gap-2 mb-3"><Send className="text-blue-500 h-5 w-5" /> SendGrid</h4>
                    <div className="space-y-3">
                        <div>
                            <Button 
                                className="w-full"
                                variant="outline"
                                onClick={() => runTest('SendGrid Config', testEmailSystem, { mode: "diagnostic", provider: "sendgrid" })}
                                disabled={testing['SendGrid Config']}
                            >
                                {testing['SendGrid Config'] ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                                1. Test SendGrid Configuration
                            </Button>
                            <TestResult result={testResults['SendGrid Config']} />
                        </div>
                        <div>
                            <Button 
                                className="w-full"
                                onClick={() => runTest('SendGrid Send Test', testEmailSystem, { mode: "send_test", provider: "sendgrid" })}
                                disabled={!user || testing['SendGrid Send Test']}
                            >
                                {testing['SendGrid Send Test'] ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                                2. Send Live Test Email via SendGrid
                            </Button>
                            <TestResult result={testResults['SendGrid Send Test']} />
                        </div>
                    </div>
                </Card>

                {/* AWS SES */}
                <Card className="p-4">
                    <h4 className="font-semibold flex items-center gap-2 mb-3"><Cloud className="text-orange-500 h-5 w-5" /> AWS SES</h4>
                    <div className="space-y-3">
                       <div>
                            <Button 
                                className="w-full"
                                variant="outline"
                                onClick={() => runTest('AWS SES Config', testEmailSystem, { mode: "diagnostic", provider: "ses" })}
                                disabled={testing['AWS SES Config']}
                            >
                                {testing['AWS SES Config'] ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                                1. Test AWS SES Configuration
                            </Button>
                            <TestResult result={testResults['AWS SES Config']} />
                        </div>
                        <div>
                            <Button 
                                className="w-full"
                                onClick={() => runTest('AWS SES Send Test', testEmailSystem, { mode: "send_test", provider: "ses" })}
                                disabled={!user || testing['AWS SES Send Test']}
                            >
                                {testing['AWS SES Send Test'] ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                                2. Send Live Test Email via AWS SES
                            </Button>
                             <TestResult result={testResults['AWS SES Send Test']} />
                        </div>
                    </div>
                </Card>
            </CardContent>
        </Card>
    );
}