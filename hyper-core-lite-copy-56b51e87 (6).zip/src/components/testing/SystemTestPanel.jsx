
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { CheckCircle, XCircle, Loader2, Download, Eye } from 'lucide-react';
import { toast } from "sonner";

const testSuite = [
    {
        name: 'Real Data Validation',
        description: 'Verify all tracking systems capture only authentic user data',
        endpoint: 'clearSampleTrackingData',
        category: 'data_integrity'
    },
    {
        name: 'Analytics Report Generation',
        description: 'Generate analytics report with real data only',
        endpoint: 'getAnalyticsReport',
        category: 'analytics'
    },
];

// Dynamically import functions
const functionMap = {
    generateAdvancedSSP: () => import('@/api/functions').then(m => m.generateAdvancedSSP),
    generateAdvancedPolicies: () => import('@/api/functions').then(m => m.generateAdvancedPolicies),
    generateCMMCReport: () => import('@/api/functions').then(m => m.generateCMMCReport),
    testDatabaseConnection: () => import('@/api/functions').then(m => m.testDatabaseConnection),
    testEmailSystem: () => import('@/api/functions').then(m => m.testEmailSystem),
};

export default function SystemTestPanel({ title, description, testFunction, buttonText, icon: Icon, testPayload }) {
    const [status, setStatus] = useState('idle'); // idle, loading, success, error
    const [result, setResult] = useState(null);
    const [showRaw, setShowRaw] = useState(false);

    const handleRunTest = async () => {
        setStatus('loading');
        setResult(null);
        setShowRaw(false);
        const toastId = toast.loading(`Running test: ${title}...`);

        try {
            const func = await functionMap[testFunction]();
            const { data } = await func(testPayload);
            
            setStatus('success');
            setResult(data);
            toast.success(`Test Succeeded: ${title}`, { id: toastId });
        } catch (err) {
            setStatus('error');
            const errorMessage = err.response?.data?.error || err.message || 'An unknown error occurred.';
            setResult({ error: errorMessage });
            toast.error(`Test Failed: ${title}`, { id: toastId, description: errorMessage });
        }
    };

    return (
        <Card className="flex flex-col">
            <CardHeader>
                <div className="flex items-center gap-3">
                    {Icon && <Icon className="w-6 h-6" />}
                    <CardTitle>{title}</CardTitle>
                </div>
                <CardDescription>{description}</CardDescription>
            </CardHeader>
            <CardContent className="flex-grow space-y-4">
                <Button onClick={handleRunTest} disabled={status === 'loading'} className="w-full">
                    {status === 'loading' ? (
                        <>
                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                            Testing...
                        </>
                    ) : (
                        buttonText
                    )}
                </Button>

                {status === 'success' && (
                    <Alert className="bg-green-50 border-green-200">
                        <CheckCircle className="h-4 w-4 text-green-600" />
                        <AlertTitle className="text-green-800">Test Successful</AlertTitle>
                        <AlertDescription className="text-green-700">
                            {result?.message || 'The operation completed successfully.'}
                        </AlertDescription>
                        <div className="mt-2 flex gap-2">
                             {result?.pdfBase64 && (
                                <Button size="sm" variant="outline" onClick={() => window.open(`data:application/pdf;base64,${result.pdfBase64}`, '_blank')}>
                                    <Download className="w-4 h-4 mr-2"/>
                                    Download PDF
                                </Button>
                            )}
                             {result?.rawText && (
                                <Button size="sm" variant="outline" onClick={() => setShowRaw(!showRaw)}>
                                    <Eye className="w-4 h-4 mr-2"/>
                                    {showRaw ? 'Hide' : 'Show'} AI Text
                                </Button>
                            )}
                        </div>
                    </Alert>
                )}

                {status === 'error' && (
                     <Alert variant="destructive">
                        <XCircle className="h-4 w-4" />
                        <AlertTitle>Test Failed</AlertTitle>
                        <AlertDescription>
                           {result?.error || 'An unexpected error occurred.'}
                        </AlertDescription>
                    </Alert>
                )}
                 {showRaw && result?.rawText && (
                    <pre className="bg-gray-100 p-3 rounded-md text-xs max-h-48 overflow-auto">
                        {result.rawText}
                    </pre>
                )}
            </CardContent>
        </Card>
    );
}
