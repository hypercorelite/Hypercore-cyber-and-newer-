import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, Zap, FileText, CheckCircle, XCircle } from 'lucide-react';
import { generateAdvancedSSP } from '@/api/functions';
import { generateAdvancedPolicies } from '@/api/functions';
import { toast } from "sonner";

export default function ToolValueTest() {
    const [testInputs, setTestInputs] = useState({
        companyName: 'ACME Defense Solutions',
        systemDescription: 'A 25-person engineering team using AWS cloud services with a custom quantum encryption system for CUI storage.',
        industry: 'Defense Manufacturing',
        uniqueDetail: 'We use carrier pigeons for offline data backup protocols.'
    });
    const [isLoading, setIsLoading] = useState(false);
    const [testResults, setTestResults] = useState(null);

    const runValueTest = async () => {
        setIsLoading(true);
        setTestResults(null);
        
        try {
            const systemInfo = {
                companyName: testInputs.companyName,
                systemName: "Primary Corporate Network",
                systemDescription: testInputs.systemDescription,
                industry: testInputs.industry
            };

            // Test both SSP and Policy generation
            const [sspResult, policyResult] = await Promise.all([
                generateAdvancedSSP({ systemInfo, isTest: false }),
                generateAdvancedPolicies({ clientInfo: systemInfo, assessmentAnswers: {} })
            ]);

            const sspContent = sspResult.data?.sspData;
            const policyContent = policyResult.data;

            // Analyze if our unique inputs appear in the outputs
            const testPhrase = testInputs.uniqueDetail.toLowerCase();
            const companyNameTest = testInputs.companyName.toLowerCase();
            
            let sspText = '';
            if (sspContent?.sections) {
                sspText = sspContent.sections.map(s => s.content).join(' ').toLowerCase();
            }
            
            const containsCompanyName = sspText.includes(companyNameTest);
            const containsUniqueDetail = sspText.includes('quantum') || sspText.includes('carrier') || sspText.includes('pigeon');
            const containsIndustryContext = sspText.includes('defense') || sspText.includes('manufacturing');

            setTestResults({
                sspData: sspContent,
                policyData: policyContent,
                tailoringAnalysis: {
                    companyNamePresent: containsCompanyName,
                    uniqueDetailPresent: containsUniqueDetail,
                    industryContextPresent: containsIndustryContext,
                    overallTailoring: containsCompanyName && (containsUniqueDetail || containsIndustryContext)
                }
            });

            if (containsCompanyName && (containsUniqueDetail || containsIndustryContext)) {
                toast.success("✅ AI Successfully Tailored Output!", {
                    description: "The AI incorporated your specific company details into the generated documents."
                });
            } else {
                toast.warning("⚠️ Limited Tailoring Detected", {
                    description: "The AI may not have fully incorporated all unique details. This helps us improve."
                });
            }
            
        } catch (error) {
            console.error("Value test failed:", error);
            toast.error("Test Failed", { description: error.message });
        } finally {
            setIsLoading(false);
        }
    };

    const TestResult = ({ label, passed, description }) => (
        <div className="flex items-start gap-3 p-3 rounded-lg bg-gray-50">
            {passed ? <CheckCircle className="w-5 h-5 text-green-600 mt-0.5" /> : <XCircle className="w-5 h-5 text-red-500 mt-0.5" />}
            <div>
                <p className="font-semibold text-sm">{label}</p>
                <p className="text-xs text-gray-600">{description}</p>
            </div>
        </div>
    );

    return (
        <div className="space-y-6">
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                        <Zap className="text-yellow-500" />
                        AI Tailoring Value Test
                    </CardTitle>
                    <CardDescription>
                        This test proves our core value proposition: Does the AI actually tailor outputs based on your specific input, or does it just generate generic templates?
                    </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="grid md:grid-cols-2 gap-4">
                        <div>
                            <Label htmlFor="companyName">Company Name</Label>
                            <Input
                                id="companyName"
                                value={testInputs.companyName}
                                onChange={(e) => setTestInputs({...testInputs, companyName: e.target.value})}
                            />
                        </div>
                        <div>
                            <Label htmlFor="industry">Industry</Label>
                            <Input
                                id="industry"
                                value={testInputs.industry}
                                onChange={(e) => setTestInputs({...testInputs, industry: e.target.value})}
                            />
                        </div>
                    </div>
                    
                    <div>
                        <Label htmlFor="systemDescription">System Description</Label>
                        <Textarea
                            id="systemDescription"
                            value={testInputs.systemDescription}
                            onChange={(e) => setTestInputs({...testInputs, systemDescription: e.target.value})}
                            rows={3}
                        />
                    </div>
                    
                    <div>
                        <Label htmlFor="uniqueDetail">Unique Detail (Test Phrase)</Label>
                        <Input
                            id="uniqueDetail"
                            value={testInputs.uniqueDetail}
                            onChange={(e) => setTestInputs({...testInputs, uniqueDetail: e.target.value})}
                            placeholder="Add something unusual that should appear in the output..."
                        />
                        <p className="text-xs text-gray-500 mt-1">
                            This unique detail will help us verify if the AI is truly tailoring content vs. using generic templates.
                        </p>
                    </div>

                    <Button onClick={runValueTest} disabled={isLoading} className="w-full">
                        {isLoading ? (
                            <>
                                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                Testing AI Tailoring...
                            </>
                        ) : (
                            "Run Value Test"
                        )}
                    </Button>
                </CardContent>
            </Card>

            {testResults && (
                <div className="grid lg:grid-cols-2 gap-6">
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-3">
                                <FileText className="text-blue-600" />
                                Tailoring Analysis
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-3">
                            <TestResult
                                label="Company Name Integration"
                                passed={testResults.tailoringAnalysis.companyNamePresent}
                                description="Did the AI include your specific company name in the generated documents?"
                            />
                            <TestResult
                                label="Unique Detail Recognition"
                                passed={testResults.tailoringAnalysis.uniqueDetailPresent}
                                description="Did the AI incorporate the unique detail you provided?"
                            />
                            <TestResult
                                label="Industry Context"
                                passed={testResults.tailoringAnalysis.industryContextPresent}
                                description="Did the AI use industry-specific language and context?"
                            />
                            <div className={`p-4 rounded-lg border-2 ${testResults.tailoringAnalysis.overallTailoring ? 'border-green-300 bg-green-50' : 'border-orange-300 bg-orange-50'}`}>
                                <p className="font-bold">
                                    Overall Result: {testResults.tailoringAnalysis.overallTailoring ? "✅ AI IS TAILORING" : "⚠️ GENERIC TEMPLATE DETECTED"}
                                </p>
                            </div>
                        </CardContent>
                    </Card>

                    <Card>
                        <CardHeader>
                            <CardTitle>Generated Content Sample</CardTitle>
                            <CardDescription>Review the first section to see AI tailoring in action</CardDescription>
                        </CardHeader>
                        <CardContent>
                            {testResults.sspData?.sections?.[0] && (
                                <div className="bg-gray-50 p-4 rounded-lg max-h-64 overflow-y-auto">
                                    <h4 className="font-semibold text-sm mb-2">{testResults.sspData.sections[0].title}</h4>
                                    <p className="text-sm whitespace-pre-wrap">{testResults.sspData.sections[0].content}</p>
                                </div>
                            )}
                        </CardContent>
                    </Card>
                </div>
            )}
        </div>
    );
}