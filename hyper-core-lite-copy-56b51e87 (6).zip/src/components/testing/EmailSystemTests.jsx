import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { CheckCircle, AlertTriangle, Loader2, Mail } from 'lucide-react';
import { toast } from "sonner";
import { testEmailSystem } from "@/api/functions";
import { sendEmail } from "@/api/functions";

export default function EmailSystemTests() {
    const [results, setResults] = useState({});
    const [loading, setLoading] = useState({});
    const [recipient, setRecipient] = useState('test.recipient@example.com');

    const testInfra = async () => {
        setLoading(prev => ({...prev, infra: true}));
        try {
            const { data } = await testEmailSystem({ testRecipient: recipient });
            setResults(prev => ({...prev, infra: {success: true, message: data.message}}));
            toast.success("✅ Email infrastructure test passed!");
        } catch (error) {
            setResults(prev => ({...prev, infra: {success: false, message: error.message}}));
            toast.error("❌ Email infrastructure test failed.");
        } finally {
            setLoading(prev => ({...prev, infra: false}));
        }
    };
    
    const testDirectSend = async () => {
        setLoading(prev => ({...prev, direct: true}));
        try {
            await sendEmail({ to: recipient, subject: "Direct Send Test", html: "<p>This is a direct send test.</p>" });
            setResults(prev => ({...prev, direct: {success: true, message: `Successfully sent test email to ${recipient}.`}}));
            toast.success("✅ Direct send test passed!");
        } catch (error) {
            setResults(prev => ({...prev, direct: {success: false, message: error.message}}));
            toast.error("❌ Direct send test failed.");
        } finally {
            setLoading(prev => ({...prev, direct: false}));
        }
    };

    return (
        <div className="grid md:grid-cols-2 gap-6 mt-6">
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2"><Mail className="w-5 h-5 text-red-600" /> SendGrid Infrastructure</CardTitle>
                    <CardDescription>Verifies API key, verified sender, and ability to connect to SendGrid.</CardDescription>
                </CardHeader>
                <CardContent>
                     <Input 
                        placeholder="Recipient for test email" 
                        value={recipient}
                        onChange={(e) => setRecipient(e.target.value)}
                        className="mb-4"
                    />
                    <Button onClick={testInfra} disabled={loading.infra}>
                        {loading.infra ? <Loader2 className="w-4 h-4 mr-2 animate-spin"/> : <Mail className="w-4 h-4 mr-2" />}
                        Run Test
                    </Button>
                    {results.infra && (
                        <Alert className={`mt-4 ${results.infra.success ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'}`}>
                            <AlertTitle>{results.infra.success ? 'Test Passed' : 'Test Failed'}</AlertTitle>
                            <AlertDescription>{results.infra.message}</AlertDescription>
                        </Alert>
                    )}
                </CardContent>
            </Card>
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2"><Mail className="w-5 h-5 text-orange-600" /> Direct Email Send</CardTitle>
                    <CardDescription>Tests the basic `sendEmail` function to a specified recipient.</CardDescription>
                </CardHeader>
                <CardContent>
                    <Input 
                        placeholder="Recipient for test email" 
                        value={recipient}
                        onChange={(e) => setRecipient(e.target.value)}
                        className="mb-4"
                    />
                    <Button onClick={testDirectSend} disabled={loading.direct}>
                        {loading.direct ? <Loader2 className="w-4 h-4 mr-2 animate-spin"/> : <Mail className="w-4 h-4 mr-2" />}
                        Run Test
                    </Button>
                    {results.direct && (
                        <Alert className={`mt-4 ${results.direct.success ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'}`}>
                            <AlertTitle>{results.direct.success ? 'Test Passed' : 'Test Failed'}</AlertTitle>
                            <AlertDescription>{results.direct.message}</AlertDescription>
                        </Alert>
                    )}
                </CardContent>
            </Card>
        </div>
    );
}