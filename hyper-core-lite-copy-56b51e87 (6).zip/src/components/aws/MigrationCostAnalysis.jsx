import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { 
    DollarSign, 
    Clock, 
    TrendingUp, 
    Calculator,
    AlertTriangle,
    CheckCircle,
    Target,
    Zap
} from 'lucide-react';

const MIGRATION_COST_BREAKDOWN = {
    one_time_costs: {
        title: "One-Time Migration Costs",
        items: [
            { 
                item: "AWS Professional Services Consultation", 
                cost: 15000, 
                description: "Architecture review and migration planning",
                optional: true 
            },
            { 
                item: "Developer Time (160 hours @ $150/hr)", 
                cost: 24000, 
                description: "4 weeks full-time development for migration",
                optional: false 
            },
            { 
                item: "Database Migration Tools & Testing", 
                cost: 5000, 
                description: "AWS DMS, testing environments, data validation",
                optional: false 
            },
            { 
                item: "Security & Compliance Audit", 
                cost: 8000, 
                description: "FedRAMP readiness assessment and remediation",
                optional: true 
            },
            { 
                item: "Load Testing & Performance Optimization", 
                cost: 3000, 
                description: "Artillery.io, JMeter, CloudWatch optimization",
                optional: false 
            }
        ],
        total_min: 32000,
        total_max: 55000
    },
    
    monthly_operational_costs: {
        title: "Monthly AWS Operational Costs",
        startup_scale: {
            title: "Startup Scale (0-1,000 users)",
            items: [
                { service: "ECS Fargate (2 containers)", cost: 72, description: "2 vCPU, 4GB RAM each" },
                { service: "RDS PostgreSQL (db.t3.small)", cost: 85, description: "Multi-AZ, 100GB storage" },
                { service: "DynamoDB (5GB + requests)", cost: 25, description: "On-demand pricing" },
                { service: "Lambda (1M requests)", cost: 20, description: "API functions" },
                { service: "S3 Storage (100GB)", cost: 23, description: "Standard storage class" },
                { service: "CloudFront CDN", cost: 15, description: "Global content delivery" },
                { service: "Application Load Balancer", cost: 23, description: "High availability" },
                { service: "Route 53 + SSL", cost: 5, description: "DNS and certificates" },
                { service: "CloudWatch Monitoring", cost: 10, description: "Logs and metrics" },
                { service: "AWS Bedrock (AI/ML)", cost: 50, description: "10K AI requests/month" }
            ],
            total: 328
        },
        
        growth_scale: {
            title: "Growth Scale (1K-10K users)",
            items: [
                { service: "ECS Fargate (5 containers)", cost: 180, description: "Auto-scaling enabled" },
                { service: "RDS PostgreSQL (db.r6g.large)", cost: 285, description: "Multi-AZ, read replicas" },
                { service: "DynamoDB (50GB + requests)", cost: 125, description: "High throughput" },
                { service: "Lambda (10M requests)", cost: 180, description: "Serverless APIs" },
                { service: "S3 Storage (1TB)", cost: 230, description: "Multi-tier storage" },
                { service: "CloudFront CDN", cost: 85, description: "High traffic" },
                { service: "Application Load Balancer", cost: 45, description: "Multi-zone" },
                { service: "WAF + GuardDuty", cost: 25, description: "Security services" },
                { service: "CloudWatch + X-Ray", cost: 35, description: "Advanced monitoring" },
                { service: "AWS Bedrock (AI/ML)", cost: 400, description: "100K AI requests/month" }
            ],
            total: 1590
        },
        
        enterprise_scale: {
            title: "Enterprise Scale (10K+ users)",
            items: [
                { service: "ECS Fargate (20 containers)", cost: 720, description: "Full auto-scaling" },
                { service: "RDS PostgreSQL Cluster", cost: 850, description: "Multi-master, global" },
                { service: "DynamoDB Global Tables", cost: 500, description: "Multi-region" },
                { service: "Lambda (100M requests)", cost: 1800, description: "Massive serverless" },
                { service: "S3 Storage (10TB)", cost: 2300, description: "Intelligent tiering" },
                { service: "CloudFront + Shield Advanced", cost: 3200, description: "DDoS protection" },
                { service: "Multiple Load Balancers", cost: 150, description: "Regional distribution" },
                { service: "Security Hub + Config", cost: 75, description: "Compliance monitoring" },
                { service: "CloudWatch Enterprise", cost: 200, description: "Custom dashboards" },
                { service: "SageMaker + Bedrock", cost: 2000, description: "Custom AI training" }
            ],
            total: 11795
        }
    }
};

const TIME_BREAKDOWN = {
    total_duration: "4-6 weeks",
    phases: [
        {
            name: "Foundation Setup",
            duration: "5-7 days",
            developer_days: 7,
            critical_path: true,
            tasks: [
                "AWS GovCloud account setup",
                "VPC and networking configuration", 
                "IAM roles and security policies",
                "CloudTrail audit logging",
                "Initial cost monitoring setup"
            ]
        },
        {
            name: "Database Migration",
            duration: "7-10 days",
            developer_days: 10,
            critical_path: true,
            tasks: [
                "RDS PostgreSQL deployment",
                "DynamoDB table creation",
                "Data migration scripts",
                "Performance testing",
                "Backup configuration"
            ]
        },
        {
            name: "Application Containerization",
            duration: "7-14 days",
            developer_days: 12,
            critical_path: false,
            tasks: [
                "Docker container creation",
                "ECS Fargate deployment",
                "Load balancer configuration",
                "CloudFront CDN setup",
                "Auto-scaling policies"
            ]
        },
        {
            name: "API Migration",
            duration: "5-10 days", 
            developer_days: 8,
            critical_path: false,
            tasks: [
                "Lambda function conversion",
                "API Gateway setup",
                "Integration testing",
                "Performance optimization",
                "Error handling"
            ]
        },
        {
            name: "AI/ML Integration",
            duration: "3-5 days",
            developer_days: 5,
            critical_path: false,
            tasks: [
                "Bedrock API integration",
                "SageMaker model deployment",
                "Training pipeline setup",
                "Model versioning",
                "Performance monitoring"
            ]
        },
        {
            name: "Security & Compliance",
            duration: "3-7 days",
            developer_days: 5,
            critical_path: true,
            tasks: [
                "WAF configuration",
                "GuardDuty setup",
                "Security Hub integration",
                "FedRAMP compliance validation",
                "Penetration testing"
            ]
        },
        {
            name: "Testing & Go-Live",
            duration: "3-5 days",
            developer_days: 5,
            critical_path: true,
            tasks: [
                "Load testing",
                "User acceptance testing",
                "DNS cutover",
                "Production monitoring",
                "Team training"
            ]
        }
    ]
};

const ROI_ANALYSIS = {
    current_base44_costs: {
        monthly: 200, // Estimated current Base44 costs
        annual: 2400,
        limitations: [
            "Limited to Base44's scaling capacity",
            "No FedRAMP compliance path", 
            "Restricted AI/ML capabilities",
            "Vendor lock-in risks"
        ]
    },
    
    aws_benefits: {
        year_1: {
            cost_savings: 0, // Higher costs initially
            revenue_enablement: 150000, // FedRAMP contracts
            description: "Break-even on infrastructure, major revenue from compliance"
        },
        year_2: {
            cost_savings: 12000, // Efficiency gains
            revenue_enablement: 500000, // Scale and more contracts
            description: "Cost optimizations + explosive revenue growth"
        },
        year_3: {
            cost_savings: 36000, // Full optimization
            revenue_enablement: 1500000, // Market leadership
            description: "Massive scale efficiencies + market dominance"
        }
    }
};

export default function MigrationCostAnalysis() {
    const [selectedScale, setSelectedScale] = useState('startup_scale');

    return (
        <div className="space-y-6">
            {/* Executive Summary */}
            <Card className="bg-gradient-to-r from-green-50 to-blue-50 border-green-200">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-green-800">
                        <Target className="w-6 h-6" />
                        AWS Migration: Executive Cost Summary
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                        <div className="text-center">
                            <div className="text-3xl font-bold text-green-600">
                                ${MIGRATION_COST_BREAKDOWN.one_time_costs.total_min.toLocaleString()}
                            </div>
                            <div className="text-sm text-gray-600">Minimum Migration Cost</div>
                        </div>
                        <div className="text-center">
                            <div className="text-3xl font-bold text-blue-600">4-6</div>
                            <div className="text-sm text-gray-600">Weeks to Complete</div>
                        </div>
                        <div className="text-center">
                            <div className="text-3xl font-bold text-purple-600">
                                ${MIGRATION_COST_BREAKDOWN.monthly_operational_costs.startup_scale.total}
                            </div>
                            <div className="text-sm text-gray-600">Monthly Cost (Startup)</div>
                        </div>
                        <div className="text-center">
                            <div className="text-3xl font-bold text-orange-600">3-6x</div>
                            <div className="text-sm text-gray-600">Revenue Multiplier</div>
                        </div>
                    </div>
                </CardContent>
            </Card>

            <Tabs defaultValue="one-time" className="w-full">
                <TabsList className="grid w-full grid-cols-4">
                    <TabsTrigger value="one-time">One-Time Costs</TabsTrigger>
                    <TabsTrigger value="operational">Operational Costs</TabsTrigger>
                    <TabsTrigger value="timeline">Time Breakdown</TabsTrigger>
                    <TabsTrigger value="roi">ROI Analysis</TabsTrigger>
                </TabsList>

                <TabsContent value="one-time" className="mt-6">
                    <Card>
                        <CardHeader>
                            <CardTitle>One-Time Migration Investment</CardTitle>
                            <CardDescription>
                                Upfront costs to migrate from Base44 to AWS enterprise architecture
                            </CardDescription>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-4">
                                {MIGRATION_COST_BREAKDOWN.one_time_costs.items.map((item, index) => (
                                    <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                                        <div className="flex-1">
                                            <div className="flex items-center gap-2">
                                                <h4 className="font-medium">{item.item}</h4>
                                                {item.optional && (
                                                    <Badge variant="outline" className="text-xs">Optional</Badge>
                                                )}
                                            </div>
                                            <p className="text-sm text-gray-600">{item.description}</p>
                                        </div>
                                        <div className="text-right">
                                            <div className="text-lg font-bold">${item.cost.toLocaleString()}</div>
                                        </div>
                                    </div>
                                ))}
                                
                                <div className="border-t pt-4">
                                    <div className="flex justify-between items-center">
                                        <div>
                                            <h3 className="text-lg font-bold">Total Investment Range</h3>
                                            <p className="text-sm text-gray-600">Depending on optional services</p>
                                        </div>
                                        <div className="text-right">
                                            <div className="text-2xl font-bold text-green-600">
                                                ${MIGRATION_COST_BREAKDOWN.one_time_costs.total_min.toLocaleString()} - ${MIGRATION_COST_BREAKDOWN.one_time_costs.total_max.toLocaleString()}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="operational" className="mt-6">
                    <div className="space-y-6">
                        <div className="flex justify-center">
                            <div className="flex bg-gray-100 rounded-lg p-1">
                                <Button 
                                    variant={selectedScale === 'startup_scale' ? 'default' : 'ghost'}
                                    onClick={() => setSelectedScale('startup_scale')}
                                    className="text-sm"
                                >
                                    Startup (0-1K users)
                                </Button>
                                <Button 
                                    variant={selectedScale === 'growth_scale' ? 'default' : 'ghost'}
                                    onClick={() => setSelectedScale('growth_scale')}
                                    className="text-sm"
                                >
                                    Growth (1K-10K users)
                                </Button>
                                <Button 
                                    variant={selectedScale === 'enterprise_scale' ? 'default' : 'ghost'}
                                    onClick={() => setSelectedScale('enterprise_scale')}
                                    className="text-sm"
                                >
                                    Enterprise (10K+ users)
                                </Button>
                            </div>
                        </div>

                        <Card>
                            <CardHeader>
                                <CardTitle>
                                    {MIGRATION_COST_BREAKDOWN.monthly_operational_costs[selectedScale].title}
                                </CardTitle>
                                <CardDescription>
                                    Monthly AWS costs at this scale
                                </CardDescription>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-3">
                                    {MIGRATION_COST_BREAKDOWN.monthly_operational_costs[selectedScale].items.map((item, index) => (
                                        <div key={index} className="flex items-center justify-between p-2 border rounded">
                                            <div className="flex-1">
                                                <div className="font-medium">{item.service}</div>
                                                <div className="text-sm text-gray-600">{item.description}</div>
                                            </div>
                                            <div className="font-bold">${item.cost}/month</div>
                                        </div>
                                    ))}
                                    
                                    <div className="border-t pt-3">
                                        <div className="flex justify-between items-center">
                                            <h3 className="text-lg font-bold">Total Monthly Cost</h3>
                                            <div className="text-2xl font-bold text-blue-600">
                                                ${MIGRATION_COST_BREAKDOWN.monthly_operational_costs[selectedScale].total}/month
                                            </div>
                                        </div>
                                        <div className="text-right text-gray-600">
                                            ${(MIGRATION_COST_BREAKDOWN.monthly_operational_costs[selectedScale].total * 12).toLocaleString()}/year
                                        </div>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    </div>
                </TabsContent>

                <TabsContent value="timeline" className="mt-6">
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <Clock className="w-5 h-5" />
                                Migration Timeline: {TIME_BREAKDOWN.total_duration}
                            </CardTitle>
                            <CardDescription>
                                Detailed breakdown of migration phases and dependencies
                            </CardDescription>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-6">
                                {TIME_BREAKDOWN.phases.map((phase, index) => (
                                    <div key={index} className="border rounded-lg p-4">
                                        <div className="flex items-center justify-between mb-3">
                                            <div className="flex items-center gap-3">
                                                <h3 className="text-lg font-semibold">{phase.name}</h3>
                                                {phase.critical_path && (
                                                    <Badge variant="destructive" className="text-xs">
                                                        Critical Path
                                                    </Badge>
                                                )}
                                            </div>
                                            <div className="text-right">
                                                <div className="font-bold">{phase.duration}</div>
                                                <div className="text-sm text-gray-600">
                                                    {phase.developer_days} developer days
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                            <div>
                                                <h4 className="font-medium mb-2">Key Tasks:</h4>
                                                <ul className="text-sm space-y-1">
                                                    {phase.tasks.map((task, i) => (
                                                        <li key={i} className="flex items-center gap-2">
                                                            <CheckCircle className="w-3 h-3 text-green-500" />
                                                            {task}
                                                        </li>
                                                    ))}
                                                </ul>
                                            </div>
                                            <div>
                                                <Progress 
                                                    value={((index + 1) / TIME_BREAKDOWN.phases.length) * 100} 
                                                    className="h-2 mb-2"
                                                />
                                                <div className="text-sm text-gray-600">
                                                    Phase {index + 1} of {TIME_BREAKDOWN.phases.length}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                ))}
                                
                                <div className="bg-blue-50 rounded-lg p-4 border border-blue-200">
                                    <div className="flex items-center gap-2 mb-2">
                                        <Zap className="w-5 h-5 text-blue-600" />
                                        <h3 className="font-bold text-blue-800">Timeline Summary</h3>
                                    </div>
                                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                                        <div>
                                            <div className="font-semibold">Total Duration:</div>
                                            <div>{TIME_BREAKDOWN.total_duration}</div>
                                        </div>
                                        <div>
                                            <div className="font-semibold">Developer Days:</div>
                                            <div>{TIME_BREAKDOWN.phases.reduce((sum, phase) => sum + phase.developer_days, 0)} days</div>
                                        </div>
                                        <div>
                                            <div className="font-semibold">Can Start Revenue:</div>
                                            <div>After Phase 3 (Week 3)</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="roi" className="mt-6">
                    <div className="space-y-6">
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2">
                                    <TrendingUp className="w-5 h-5 text-green-600" />
                                    Return on Investment Analysis
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <div>
                                        <h3 className="font-bold text-lg mb-3">Current Base44 Limitations</h3>
                                        <div className="space-y-2">
                                            <div className="flex justify-between">
                                                <span>Monthly Cost:</span>
                                                <span className="font-bold">${ROI_ANALYSIS.current_base44_costs.monthly}</span>
                                            </div>
                                            <div className="border-t pt-2">
                                                <div className="text-sm font-medium mb-2">Key Limitations:</div>
                                                <ul className="text-sm space-y-1">
                                                    {ROI_ANALYSIS.current_base44_costs.limitations.map((limitation, i) => (
                                                        <li key={i} className="flex items-center gap-2">
                                                            <AlertTriangle className="w-3 h-3 text-orange-500" />
                                                            {limitation}
                                                        </li>
                                                    ))}
                                                </ul>
                                            </div>
                                        </div>
                                    </div>

                                    <div>
                                        <h3 className="font-bold text-lg mb-3">AWS Migration Benefits</h3>
                                        <div className="space-y-4">
                                            {Object.entries(ROI_ANALYSIS.aws_benefits).map(([year, data]) => (
                                                <div key={year} className="border rounded-lg p-3">
                                                    <h4 className="font-semibold capitalize mb-2">{year.replace('_', ' ')}</h4>
                                                    <div className="space-y-1 text-sm">
                                                        <div className="flex justify-between">
                                                            <span>Cost Savings:</span>
                                                            <span className="font-bold text-green-600">
                                                                +${data.cost_savings.toLocaleString()}
                                                            </span>
                                                        </div>
                                                        <div className="flex justify-between">
                                                            <span>Revenue Enablement:</span>
                                                            <span className="font-bold text-blue-600">
                                                                +${data.revenue_enablement.toLocaleString()}
                                                            </span>
                                                        </div>
                                                        <div className="text-xs text-gray-600 mt-1">
                                                            {data.description}
                                                        </div>
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                </div>

                                <div className="mt-6 bg-green-50 rounded-lg p-4 border border-green-200">
                                    <h3 className="font-bold text-green-800 mb-2">3-Year Financial Impact</h3>
                                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                        <div className="text-center">
                                            <div className="text-2xl font-bold text-green-600">
                                                ${(32000 + (328 * 12)).toLocaleString()}
                                            </div>
                                            <div className="text-sm">Total Investment (Year 1)</div>
                                        </div>
                                        <div className="text-center">
                                            <div className="text-2xl font-bold text-blue-600">
                                                ${Object.values(ROI_ANALYSIS.aws_benefits).reduce((sum, year) => sum + year.revenue_enablement, 0).toLocaleString()}
                                            </div>
                                            <div className="text-sm">Total Revenue Enabled</div>
                                        </div>
                                        <div className="text-center">
                                            <div className="text-2xl font-bold text-purple-600">
                                                {Math.round(Object.values(ROI_ANALYSIS.aws_benefits).reduce((sum, year) => sum + year.revenue_enablement, 0) / (32000 + (328 * 12)))}x
                                            </div>
                                            <div className="text-sm">Return Multiple</div>
                                        </div>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    </div>
                </TabsContent>
            </Tabs>
        </div>
    );
}