import React, { useState } from 'react';
import { Clock, CheckCircle, Circle, AlertCircle, Trophy, Target } from 'lucide-react';
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

export default function TaskBreakdown({ task, hours, description, milestone, status = "pending", deliverable, commands = [] }) {
    const [isCompleted, setIsCompleted] = useState(status === "completed");
    const [isExpanded, setIsExpanded] = useState(false);
    
    const getStatusIcon = () => {
        if (isCompleted) return <CheckCircle className="w-4 h-4 text-green-600" />;
        if (status === "in_progress") return <AlertCircle className="w-4 h-4 text-yellow-600" />;
        return <Circle className="w-4 h-4 text-gray-400" />;
    };
    
    const getStatusColor = () => {
        if (isCompleted) return "border-l-green-500 bg-green-50";
        if (status === "in_progress") return "border-l-yellow-500 bg-yellow-50";
        return "border-l-gray-300 bg-white";
    };

    const toggleComplete = () => {
        setIsCompleted(!isCompleted);
    };

    return (
        <div className={`border-l-4 ${getStatusColor()} p-4 rounded-r-lg transition-all duration-200`}>
            <div className="flex items-start justify-between">
                <div className="flex-grow">
                    <div className="flex items-center gap-3 mb-2">
                        <button onClick={toggleComplete} className="transition-colors">
                            {getStatusIcon()}
                        </button>
                        <h4 className={`font-semibold text-gray-800 ${isCompleted ? 'line-through opacity-75' : ''}`}>
                            {task}
                        </h4>
                        <Badge variant="outline" className="text-xs">
                            {milestone}
                        </Badge>
                    </div>
                    <p className="text-sm text-gray-600 ml-7">{description}</p>
                    
                    {deliverable && (
                        <div className="ml-7 mt-2">
                            <div className="flex items-center gap-2 text-sm">
                                <Target className="w-3 h-3 text-purple-500" />
                                <span className="font-medium text-purple-700">Deliverable:</span>
                                <span className="text-gray-600">{deliverable}</span>
                            </div>
                        </div>
                    )}

                    {commands.length > 0 && (
                        <div className="ml-7 mt-2">
                            <button 
                                onClick={() => setIsExpanded(!isExpanded)}
                                className="text-xs text-blue-600 hover:text-blue-800 underline"
                            >
                                {isExpanded ? 'Hide' : 'Show'} Commands
                            </button>
                            {isExpanded && (
                                <div className="mt-2 bg-gray-900 text-green-400 p-2 rounded text-xs font-mono">
                                    {commands.map((cmd, i) => (
                                        <div key={i}>{cmd}</div>
                                    ))}
                                </div>
                            )}
                        </div>
                    )}
                </div>
                
                <div className="flex items-center gap-2 text-blue-600 ml-4">
                    <Clock className="w-4 h-4" />
                    <span className="text-sm font-semibold">{hours}</span>
                </div>
            </div>
            
            {isCompleted && (
                <div className="ml-7 mt-2 flex items-center gap-2 text-green-600">
                    <Trophy className="w-4 h-4" />
                    <span className="text-sm font-medium">Milestone achieved!</span>
                </div>
            )}
        </div>
    );
}