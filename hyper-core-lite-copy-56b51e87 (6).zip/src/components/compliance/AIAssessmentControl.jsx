
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Brain, Upload, Loader2, CheckCircle, AlertTriangle, FileText, ChevronRight } from "lucide-react";
import { toast } from "sonner";
import { queryHuggingFaceModel } from "@/api/functions";
import { ComplianceTask } from '@/api/entities';
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";

const SAMPLE_TASKS = [
    {
        id: 'AT.2.056',
        title: 'AT.2.056 - Provide security awareness training.',
        description: 'Ensure that managers, systems administrators, and users of organizational systems are made aware of the security risks associated with their activities and of the applicable laws, executive orders, directives, policies, standards, and procedures. Provide security awareness training on recognizing and reporting incidents.'
    },
    {
        id: 'AC.1.001',
        title: 'AC.1.001 - Limit system access to authorized users.',
        description: 'Limit information system access to authorized users, processes acting on behalf of authorized users, or devices (including other information systems).'
    },
    {
        id: 'IR.2.092',
        title: 'IR.2.092 - Detect and report events.',
        description: 'Detect and report events to appropriate officials. This includes monitoring systems to detect attacks and indicators of potential attacks.'
    }
];

const SAMPLE_EVIDENCE = {
    'AT.2.056': `To whom it may concern,

This document serves as an attestation of our security awareness training program for the year 2024.

- All new hires complete a mandatory 60-minute security awareness module via our HR platform, 'Workday'.
- On October 15, 2024, we conducted our annual mandatory security refresh training for all employees, covering topics such as phishing, social engineering, and password security.
- Attendance records are attached in Appendix A. A sample of the training presentation is in Appendix B.

Sincerely,
Jane Doe, HR Manager`,
    'AC.1.001': `Access Control Policy Snippet:

- All system access requires authentication via company-issued credentials through our Okta SSO portal.
- User access levels are defined by roles (e.g., 'Admin', 'User', 'Auditor') managed within Okta groups.
- Access requests are submitted through Jira and require manager approval. An audit log of all access grants is maintained in the 'AccessGrants' Splunk index.`,
    'IR.2.092': `Incident Response Plan Excerpt (Section 3.1):

- Our Security Information and Event Management (SIEM) system, Splunk, is configured with alerts for suspicious activities, including multiple failed logins, malware detection signatures from CrowdStrike, and unusual data exfiltration patterns.
- When an alert is triggered, an incident is automatically created in our SOAR platform and assigned to the on-call security analyst.
- Critical alerts generate a PagerDuty notification to ensure immediate response.`
};

export default function AIAssessmentControl() {
    const [selectedTask, setSelectedTask] = useState(null);
    const [evidence, setEvidence] = useState('');
    const [loading, setLoading] = useState(false);
    const [result, setResult] = useState(null);

    const handleTaskChange = (taskId) => {
        const task = SAMPLE_TASKS.find(t => t.id === taskId);
        setSelectedTask(task);
        setEvidence(SAMPLE_EVIDENCE[taskId] || '');
        setResult(null);
    };

    const handleAnalyze = async () => {
        if (!selectedTask || !evidence) {
            toast.error("Please select a control and provide evidence.");
            return;
        }

        setLoading(true);
        setResult(null);

        try {
            // This would normally be a file upload, but we'll use the text area content.
            const prompt = `Task: ${selectedTask.title}\nRequirement: ${selectedTask.description}\n\nEvidence provided:\n---\n${evidence}\n---\nBased *only* on the evidence provided, does it sufficiently meet the CMMC requirement? Provide a short 'judgment' (Sufficient, Partially Sufficient, Insufficient), a 'confidence_score' (0-100), and a 'reasoning' explaining your decision based on the evidence.`;
            
            const response = await queryHuggingFaceModel({
                modelName: 'cmmc-assessor-v1', // This is a virtual name for our fine-tuned model
                prompt: prompt
            });

            if (response.status === 200 && response.data.success) {
                // Attempt to parse the response from the model
                try {
                    const modelResponse = response.data.response;
                    
                    // Simple parsing logic, can be improved
                    const judgmentMatch = modelResponse.match(/judgment:\s*(Sufficient|Partially Sufficient|Insufficient)/i);
                    const confidenceMatch = modelResponse.match(/confidence_score:\s*(\d+)/i);
                    const reasoningMatch = modelResponse.match(/reasoning:\s*([\s\S]*)/i);

                    const parsedResult = {
                        judgment: judgmentMatch ? judgmentMatch[1] : 'Unknown',
                        confidence: confidenceMatch ? parseInt(confidenceMatch[1], 10) : 0,
                        reasoning: reasoningMatch ? reasoningMatch[1].trim() : modelResponse,
                        raw: modelResponse
                    };
                    
                    setResult(parsedResult);
                    toast.success("AI analysis complete.");

                } catch (parseError) {
                    toast.error("Could not parse AI response.");
                    setResult({ error: "Failed to parse AI response.", raw: response.data.response });
                }
            } else {
                throw new Error(response.data.error || 'Analysis failed.');
            }
        } catch (error) {
            toast.error(error.message);
            setResult({ error: error.message });
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <Label htmlFor="task-select">1. Select a CMMC Control</Label>
                    <Select onValueChange={handleTaskChange} id="task-select">
                        <SelectTrigger>
                            <SelectValue placeholder="Choose a control to assess..." />
                        </SelectTrigger>
                        <SelectContent>
                            {SAMPLE_TASKS.map(task => (
                                <SelectItem key={task.id} value={task.id}>
                                    {task.title}
                                </SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                </div>
                {selectedTask && (
                    <Card className="md:col-span-2 bg-gray-50">
                        <CardHeader className="pb-3">
                            <CardTitle className="text-base">{selectedTask.title}</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="text-sm text-gray-600">{selectedTask.description}</p>
                        </CardContent>
                    </Card>
                )}
            </div>

            {selectedTask && (
                 <div>
                    <Label htmlFor="evidence">2. Provide or Review Evidence</Label>
                    <Textarea
                        id="evidence"
                        value={evidence}
                        onChange={(e) => setEvidence(e.target.value)}
                        rows={10}
                        placeholder="Paste or describe the evidence here. In a real scenario, you would upload files."
                    />
                    <p className="text-xs text-gray-500 mt-1">
                        For demo purposes, sample evidence is pre-filled. You can edit it before analyzing.
                    </p>
                </div>
            )}
           
            <Button onClick={handleAnalyze} disabled={loading || !selectedTask || !evidence}>
                {loading ? (
                    <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Analyzing...</>
                ) : (
                    <><Brain className="w-4 h-4 mr-2" />Ask AI Agent to Assess</>
                )}
            </Button>

            {result && (
                <Card className={result.error ? "border-red-200" : "border-green-200"}>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            {result.error ? <AlertTriangle className="w-5 h-5 text-red-600" /> : <CheckCircle className="w-5 h-5 text-green-600" />}
                            AI Assessment Result
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        {result.error ? (
                            <p className="text-red-700">{result.error}</p>
                        ) : (
                            <div className="space-y-4">
                                <div className="flex items-center justify-between">
                                    <span className="font-semibold">Judgment:</span>
                                    <Badge className={
                                        result.judgment === 'Sufficient' ? "bg-green-100 text-green-800" :
                                        result.judgment === 'Partially Sufficient' ? "bg-yellow-100 text-yellow-800" :
                                        "bg-red-100 text-red-800"
                                    }>
                                        {result.judgment}
                                    </Badge>
                                </div>
                                <div className="flex items-center justify-between">
                                    <span className="font-semibold">AI Confidence:</span>
                                    <div className="flex items-center gap-2">
                                        <span className="font-bold text-lg">{result.confidence}%</span>
                                        <Progress value={result.confidence} className="w-24" />
                                    </div>
                                </div>
                                <div>
                                    <h4 className="font-semibold mb-2">Reasoning:</h4>
                                    <p className="text-sm text-gray-700 bg-gray-50 p-3 rounded-md border">{result.reasoning}</p>
                                </div>
                            </div>
                        )}
                    </CardContent>
                </Card>
            )}
        </div>
    );
}
