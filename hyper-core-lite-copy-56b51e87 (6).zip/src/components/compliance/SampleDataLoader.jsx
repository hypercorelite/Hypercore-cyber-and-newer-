import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ComplianceFramework } from "@/api/entities";
import { ComplianceTask } from "@/api/entities";
import { AIComplianceAgent } from "@/api/entities";
import { Plus, CheckCircle, Loader2 } from "lucide-react";

export default function SampleDataLoader() {
    const [loading, setLoading] = useState(false);
    const [created, setCreated] = useState(false);

    const createSampleData = async () => {
        setLoading(true);
        try {
            // Create sample frameworks
            const frameworks = await Promise.all([
                ComplianceFramework.create({
                    framework_name: "HIPAA",
                    organization_name: "MedTech Solutions Inc.",
                    compliance_status: "in_progress",
                    completion_percentage: 67,
                    target_completion_date: "2024-12-15",
                    assigned_compliance_officer: "Dr. Sarah Chen",
                    ai_agent_assigned: "HIPAA Specialist Agent",
                    risk_level: "medium",
                    notes: "Making good progress on technical safeguards implementation"
                }),
                ComplianceFramework.create({
                    framework_name: "FERPA",
                    organization_name: "Lincoln University",
                    compliance_status: "review_required",
                    completion_percentage: 89,
                    target_completion_date: "2024-10-30",
                    assigned_compliance_officer: "Prof. Michael Torres",
                    ai_agent_assigned: "FERPA Specialist Agent",
                    risk_level: "low",
                    notes: "Final review phase for student data protection policies"
                }),
                ComplianceFramework.create({
                    framework_name: "CMMC",
                    organization_name: "Defense Contractor LLC",
                    compliance_status: "in_progress",
                    completion_percentage: 45,
                    target_completion_date: "2025-03-01",
                    assigned_compliance_officer: "James Rodriguez",
                    ai_agent_assigned: "CMMC Specialist Agent",
                    risk_level: "high",
                    notes: "Critical DoD contract requirements - accelerated timeline needed"
                })
            ]);

            // Create sample tasks
            await Promise.all([
                ComplianceTask.create({
                    framework_id: frameworks[0].id,
                    task_title: "Implement Access Controls for PHI",
                    requirement_section: "HIPAA 164.312(a)(1)",
                    task_description: "Establish unique user identification, emergency access, automatic logoff, and encryption/decryption controls",
                    task_type: "technical_implementation",
                    priority: "high",
                    status: "human_review_required",
                    assigned_to: "IT Security Team",
                    ai_agent_suggestions: "Recommend implementing multi-factor authentication with role-based access controls. Suggest Azure AD integration with automatic session timeout after 15 minutes of inactivity.",
                    human_approval_required: true,
                    due_date: "2024-10-15"
                }),
                ComplianceTask.create({
                    framework_id: frameworks[1].id,
                    task_title: "Student Records Access Audit",
                    requirement_section: "FERPA 99.32",
                    task_description: "Conduct comprehensive audit of who accessed student education records in the past year",
                    task_type: "audit",
                    priority: "medium",
                    status: "ai_completed",
                    assigned_to: "FERPA Specialist Agent",
                    ai_agent_suggestions: "Automated analysis shows 3,247 record accesses by 47 authorized personnel. No unauthorized access detected. Recommend quarterly reviews going forward.",
                    human_approval_required: true,
                    due_date: "2024-10-05"
                }),
                ComplianceTask.create({
                    framework_id: frameworks[2].id,
                    task_title: "Implement Network Segmentation",
                    requirement_section: "CMMC AC.3.020",
                    task_description: "Separate system components processing CUI from other network components",
                    task_type: "technical_implementation",
                    priority: "critical",
                    status: "in_progress",
                    assigned_to: "Network Engineering Team",
                    ai_agent_suggestions: "Deploy VLAN segmentation with firewall rules. Isolate CUI processing systems on dedicated network segment with monitoring.",
                    human_approval_required: true,
                    due_date: "2024-11-01"
                })
            ]);

            // Create sample AI agents
            await Promise.all([
                AIComplianceAgent.create({
                    agent_name: "HIPAA Specialist Agent",
                    specialization: "HIPAA_specialist",
                    status: "active",
                    tasks_completed: 147,
                    accuracy_rate: 94.2,
                    human_intervention_rate: 15.8,
                    capabilities: "PHI identification, risk assessments, policy generation, audit automation, breach analysis",
                    performance_metrics: '{"avg_completion_time": "2.3 hours", "complexity_handled": "high", "client_satisfaction": 4.7}'
                }),
                AIComplianceAgent.create({
                    agent_name: "FERPA Specialist Agent", 
                    specialization: "FERPA_specialist",
                    status: "active",
                    tasks_completed: 89,
                    accuracy_rate: 97.1,
                    human_intervention_rate: 8.3,
                    capabilities: "Student record analysis, consent management, directory information handling, disclosure tracking",
                    performance_metrics: '{"avg_completion_time": "1.8 hours", "complexity_handled": "medium", "client_satisfaction": 4.9}'
                }),
                AIComplianceAgent.create({
                    agent_name: "CMMC Specialist Agent",
                    specialization: "CMMC_specialist", 
                    status: "active",
                    tasks_completed: 73,
                    accuracy_rate: 91.5,
                    human_intervention_rate: 22.1,
                    capabilities: "CUI handling, DoD requirements analysis, security control implementation, maturity assessment",
                    performance_metrics: '{"avg_completion_time": "4.1 hours", "complexity_handled": "very_high", "client_satisfaction": 4.6}'
                })
            ]);

            setCreated(true);
        } catch (error) {
            console.error('Failed to create sample data:', error);
        } finally {
            setLoading(false);
        }
    };

    if (created) {
        return (
            <Card className="bg-green-50 border-green-200">
                <CardContent className="p-6 text-center">
                    <CheckCircle className="w-12 h-12 text-green-600 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-green-800 mb-2">
                        Sample Data Created Successfully!
                    </h3>
                    <p className="text-green-700">
                        Your compliance management platform is now populated with sample frameworks, tasks, and AI agents.
                    </p>
                </CardContent>
            </Card>
        );
    }

    return (
        <Card className="bg-blue-50 border-blue-200">
            <CardHeader>
                <CardTitle className="flex items-center gap-2">
                    <Plus className="w-5 h-5 text-blue-600" />
                    Load Sample Compliance Data
                </CardTitle>
            </CardHeader>
            <CardContent>
                <p className="text-gray-700 mb-4">
                    Click below to populate your compliance platform with sample HIPAA, FERPA, and CMMC frameworks, tasks, and AI agents.
                </p>
                <Button 
                    onClick={createSampleData}
                    disabled={loading}
                    className="bg-blue-600 hover:bg-blue-700 w-full"
                >
                    {loading ? (
                        <>
                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                            Creating Sample Data...
                        </>
                    ) : (
                        <>
                            <Plus className="w-4 h-4 mr-2" />
                            Create Sample Data
                        </>
                    )}
                </Button>
            </CardContent>
        </Card>
    );
}