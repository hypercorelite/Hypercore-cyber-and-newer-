import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Database, CheckCircle, AlertTriangle } from 'lucide-react';
import { seedDemoData } from "@/api/functions";
import { toast } from "sonner";

export default function SeedDataButton() {
    const [isSeeding, setIsSeeding] = useState(false);

    const handleSeedData = async () => {
        setIsSeeding(true);
        try {
            const { data } = await seedDemoData({});
            toast.success(`Demo data seeded: ${data.auditLogs} audit logs, ${data.testingLogs} testing logs`);
        } catch (error) {
            toast.error(`Failed to seed demo data: ${error.message}`);
        } finally {
            setIsSeeding(false);
        }
    };

    return (
        <Button 
            onClick={handleSeedData} 
            disabled={isSeeding}
            className="bg-blue-600 hover:bg-blue-700"
        >
            <Database className="w-4 h-4 mr-2" />
            {isSeeding ? 'Seeding Data...' : 'Seed Demo Data'}
        </Button>
    );
}