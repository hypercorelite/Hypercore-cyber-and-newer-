
import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Home } from 'lucide-react';
import { createPageUrl } from '@/utils';

const getBreadcrumbs = (currentPageName) => {
    const breadcrumbMap = {
        'Dashboard': [{ name: 'Dashboard', path: 'Dashboard' }],
        'ClientAcquisitionHub': [
            { name: 'Dashboard', path: 'Dashboard' },
            { name: 'Client Acquisition Hub', path: 'ClientAcquisitionHub' }
        ],
        'SystemTests': [
            { name: 'Dashboard', path: 'Dashboard' },
            { name: 'System Diagnostics', path: 'SystemTests' }
        ],
        'SEOMetricsDashboard': [
            { name: 'Dashboard', path: 'Dashboard' },
            { name: 'SEO Analytics Dashboard', path: 'SEOMetricsDashboard' }
        ],
        'AnalyticsDashboard': [
            { name: 'Dashboard', path: 'Dashboard' },
            { name: 'Analytics Dashboard', path: 'AnalyticsDashboard' }
        ],
        'POAMGenerator': [
            { name: 'Dashboard', path: 'Dashboard' },
            { name: 'POA&M Generator', path: 'POAMGenerator' }
        ],
        'ImplementationTimeline': [
            { name: 'Dashboard', path: 'Dashboard' },
            { name: 'Implementation Timeline', path: 'ImplementationTimeline' }
        ],
        'ControlPrioritizationMatrix': [
            { name: 'Dashboard', path: 'Dashboard' },
            { name: 'Control Prioritization Matrix', path: 'ControlPrioritizationMatrix' }
        ],
        'CurrentMVPStatus': [
            { name: 'Dashboard', path: 'Dashboard' },
            { name: 'Current MVP Status', path: 'CurrentMVPStatus' }
        ],
        'PartnershipHub': [
            { name: 'Dashboard', path: 'Dashboard' },
            { name: 'Client CRM', path: 'PartnershipHub' }
        ],
        'PartnershipEmailCampaign': [
            { name: 'Dashboard', path: 'Dashboard' },
            { name: 'Client CRM', path: 'PartnershipHub' },
            { name: 'Email Campaigns', path: 'PartnershipEmailCampaign' }
        ],
        'SupportDashboard': [
            { name: 'Dashboard', path: 'Dashboard' },
            { name: 'Support Dashboard', path: 'SupportDashboard' }
        ],
        'SBIRTechnicalStrategy': [
            { name: 'Dashboard', path: 'Dashboard' },
            { name: 'SBIR Technical Strategy', path: 'SBIRTechnicalStrategy' }
        ],
        'GrantFueledScalingStrategy': [
            { name: 'Dashboard', path: 'Dashboard' },
            { name: 'Grant-Fueled Scaling', path: 'GrantFueledScalingStrategy' }
        ],
        'SBIRTimelineAlignment': [
            { name: 'Dashboard', path: 'Dashboard' },
            { name: 'SBIR Timeline Alignment', path: 'SBIRTimelineAlignment' }
        ],
        'StreamlinedActionPlan': [
            { name: 'Dashboard', path: 'Dashboard' },
            { name: 'Hyperspeed Action Plan', path: 'StreamlinedActionPlan' }
        ],
        'RealisticTimelineAssessment': [
            { name: 'Dashboard', path: 'Dashboard' },
            { name: 'Hyperspeed Action Plan', path: 'StreamlinedActionPlan' },
            { name: 'Timeline Reality Check', path: 'RealisticTimelineAssessment' }
        ],
        'LocalDevelopmentGuide': [
            { name: 'Dashboard', path: 'Dashboard' },
            { name: '16-Week Build Plan', path: 'LocalDevelopmentGuide' }
        ],
        'SBIRGrantRequirements': [
            { name: 'Dashboard', path: 'Dashboard' },
            { name: 'SBIR Grant Requirements', path: 'SBIRGrantRequirements' }
        ],
        'CMMCReadinessAssessment': [
            { name: 'Dashboard', path: 'Dashboard' },
            { name: 'CMMC Assessment', path: 'CMMCReadinessAssessment' }
        ],
        'MockCMMCAssessment': [
            { name: 'Dashboard', path: 'Dashboard' },
            { name: 'SBIR Timeline Alignment', path: 'SBIRTimelineAlignment' }, // Changed from SBIR Timeline to SBIR Timeline Alignment to match existing path name
            { name: 'Mock Assessment', path: 'MockCMMCAssessment' }
        ],
        'CMMCImplementationGuide': [
            { name: 'Dashboard', path: 'Dashboard' },
            { name: 'CMMC Implementation Guide', path: 'CMMCImplementationGuide' }
        ],
        'DeploymentReadiness': [
            { name: 'Dashboard', path: 'Dashboard' },
            { name: 'System Status', path: 'DeploymentReadiness' }
        ],
        'AIToolsAdvantage': [
            { name: 'Dashboard', path: 'Dashboard' },
            { name: 'AI Tools Advantage', path: 'AIToolsAdvantage' }
        ],
        'AWSMigrationExecutionPlan': [
            { name: 'Dashboard', path: 'Dashboard' },
            { name: 'AWS Migration Plan', path: 'AWSMigrationExecutionPlan' }
        ],
        'MGNAgentSetupGuide': [
            { name: 'Dashboard', path: 'Dashboard' },
            { name: 'AWS Migration Plan', path: 'AWSMigrationExecutionPlan' },
            { name: 'MGN Agent Setup', path: 'MGNAgentSetupGuide' }
        ],
        'StreamlinedAWSMigration': [
            { name: 'Dashboard', path: 'Dashboard' },
            { name: 'Streamlined AWS Migration', path: 'StreamlinedAWSMigration' }
        ],
        'CompleteExecutionRoadmap': [
            { name: 'Dashboard', path: 'Dashboard' },
            { name: 'Complete Execution Roadmap', path: 'CompleteExecutionRoadmap' }
        ],
        'Resources': [
            { name: 'Dashboard', path: 'Dashboard' },
            { name: 'Resources', path: 'Resources' }
        ],
        'BlogPost': [
            { name: 'Dashboard', path: 'Dashboard' },
            { name: 'Knowledge Hub', path: 'KnowledgeHub'},
            { name: 'Article', path: 'BlogPost' }
        ],
        'SBIRMarketingAppendix': [
            { name: 'Dashboard', path: 'Dashboard' },
            { name: 'Marketing Appendix', path: 'SBIRMarketingAppendix' }
        ],
        'CustomerSuccessStories': [
            { name: 'Dashboard', path: 'Dashboard' },
            { name: 'Customer Success Stories', path: 'CustomerSuccessStories' }
        ],
        'SBIRProposalEvidence': [
            { name: 'Dashboard', path: 'Dashboard' },
            { name: 'SBIR Proposal Evidence', path: 'SBIRProposalEvidence' }
        ],
        'LiveSecurityScanGuide': [
            { name: 'Dashboard', path: 'Dashboard' },
            { name: 'Live Security Scan Guide', path: 'LiveSecurityScanGuide' }
        ],
        'JMeterLoadTestingGuide': [
            { name: 'Dashboard', path: 'Dashboard' },
            { name: 'JMeter Load Test Guide', path: 'JMeterLoadTestingGuide' }
        ]
    };

    return breadcrumbMap[currentPageName] || [{ name: currentPageName, path: currentPageName }];
};

export default function BreadcrumbNav({ currentPageName }) {
    const breadcrumbs = getBreadcrumbs(currentPageName);

    if (breadcrumbs.length <= 1) return null;

    return (
        <nav className="flex items-center space-x-2 text-sm text-gray-500 mb-6 px-1">
            <Home className="w-3 h-3" />
            {breadcrumbs.map((crumb, index) => (
                <React.Fragment key={crumb.path}>
                    {index > 0 && <ArrowRight className="w-3 h-3 text-gray-400" />}
                    {index === breadcrumbs.length - 1 ? (
                        <span className="text-gray-900 font-medium">{crumb.name}</span>
                    ) : (
                        <Link
                            to={createPageUrl(crumb.path)}
                            className="hover:text-blue-600 transition-colors"
                        >
                            {crumb.name}
                        </Link>
                    )}
                </React.Fragment>
            ))}
        </nav>
    );
}
