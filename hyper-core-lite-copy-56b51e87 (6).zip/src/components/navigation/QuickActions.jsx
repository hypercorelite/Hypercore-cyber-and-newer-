import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Users, Mail, Phone, FileText, Plus, X } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion, AnimatePresence } from 'framer-motion';

const quickActions = [
    {
        icon: Users,
        label: 'New Contact',
        path: 'PartnershipHub',
        color: 'bg-blue-500 hover:bg-blue-600',
        action: 'add-contact'
    },
    {
        icon: Mail,
        label: 'Send Email',
        path: 'PartnershipEmailCampaign',
        color: 'bg-green-500 hover:bg-green-600',
        action: 'compose'
    },
    {
        icon: Phone,
        label: 'Log Call',
        path: 'PartnershipHub',
        color: 'bg-purple-500 hover:bg-purple-600',
        action: 'log-call'
    },
    {
        icon: FileText,
        label: 'New Report',
        path: 'CMMCReadinessAssessment',
        color: 'bg-orange-500 hover:bg-orange-600',
        action: 'new-assessment'
    }
];

export default function QuickActions() {
    const [isOpen, setIsOpen] = useState(false);

    return (
        <div className="fixed right-6 bottom-6 z-50">
            <AnimatePresence>
                {isOpen && (
                    <motion.div
                        initial={{ opacity: 0, scale: 0.8, y: 20 }}
                        animate={{ opacity: 1, scale: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.8, y: 20 }}
                        className="absolute bottom-16 right-0 space-y-3"
                    >
                        {quickActions.map((action, index) => (
                            <motion.div
                                key={action.label}
                                initial={{ opacity: 0, x: 20 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ delay: index * 0.1 }}
                            >
                                <Link to={createPageUrl(action.path)}>
                                    <Button
                                        className={`${action.color} text-white shadow-lg rounded-full p-3 group relative`}
                                        size="icon"
                                        onClick={() => setIsOpen(false)}
                                    >
                                        <action.icon className="w-5 h-5" />
                                        <span className="absolute right-full mr-3 bg-gray-900 text-white px-2 py-1 rounded text-xs whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity">
                                            {action.label}
                                        </span>
                                    </Button>
                                </Link>
                            </motion.div>
                        ))}
                    </motion.div>
                )}
            </AnimatePresence>

            <Button
                onClick={() => setIsOpen(!isOpen)}
                className={`rounded-full w-14 h-14 shadow-lg transition-all duration-200 ${
                    isOpen 
                        ? 'bg-red-500 hover:bg-red-600 rotate-45' 
                        : 'bg-blue-600 hover:bg-blue-700'
                }`}
                size="icon"
            >
                {isOpen ? <X className="w-6 h-6" /> : <Plus className="w-6 h-6" />}
            </Button>
        </div>
    );
}