import React, { useState, useEffect } from 'react';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Search, ArrowRight, Users, Mail, BarChart, Settings } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const searchablePages = [
    { name: 'Dashboard', path: 'Dashboard', icon: BarChart, category: 'Main' },
    { name: 'Partnership Hub', path: 'PartnershipHub', icon: Users, category: 'CRM' },
    { name: 'Email Campaigns', path: 'PartnershipEmailCampaign', icon: Mail, category: 'Marketing' },
    { name: 'Support Dashboard', path: 'SupportDashboard', icon: Users, category: 'Support' },
    { name: 'CMMC Assessment', path: 'CMMCReadinessAssessment', icon: Settings, category: 'Tools' },
    { name: 'System Status', path: 'DeploymentReadiness', icon: Settings, category: 'Admin' }
];

export default function GlobalSearch({ className = "" }) {
    const [isOpen, setIsOpen] = useState(false);
    const [searchTerm, setSearchTerm] = useState('');
    const [filteredPages, setFilteredPages] = useState([]);

    useEffect(() => {
        const handleKeyDown = (e) => {
            if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
                e.preventDefault();
                setIsOpen(true);
            }
            if (e.key === 'Escape') {
                setIsOpen(false);
            }
        };

        window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, []);

    useEffect(() => {
        if (searchTerm) {
            const filtered = searchablePages.filter(page =>
                page.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                page.category.toLowerCase().includes(searchTerm.toLowerCase())
            );
            setFilteredPages(filtered);
        } else {
            setFilteredPages(searchablePages.slice(0, 6));
        }
    }, [searchTerm]);

    const handlePageSelect = (path) => {
        setIsOpen(false);
        setSearchTerm('');
    };

    return (
        <>
            <div className={`relative ${className}`}>
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                    placeholder="Search pages... (Ctrl+K)"
                    className="pl-10 pr-4 py-2 w-64 cursor-pointer"
                    readOnly
                    onClick={() => setIsOpen(true)}
                />
            </div>

            <Dialog open={isOpen} onOpenChange={setIsOpen}>
                <DialogContent className="max-w-2xl">
                    <DialogHeader>
                        <DialogTitle>Quick Navigation</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                        <div className="relative">
                            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                            <Input
                                placeholder="Type to search pages, features, or data..."
                                className="pl-10"
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                autoFocus
                            />
                        </div>
                        <div className="max-h-96 overflow-y-auto">
                            <div className="grid gap-2">
                                {filteredPages.map((page, index) => (
                                    <Link
                                        key={page.path}
                                        to={createPageUrl(page.path)}
                                        onClick={() => handlePageSelect(page.path)}
                                        className="flex items-center gap-3 p-3 rounded-md hover:bg-gray-50 transition-colors group"
                                    >
                                        <page.icon className="w-5 h-5 text-gray-500 group-hover:text-blue-600" />
                                        <div className="flex-grow">
                                            <div className="font-medium text-gray-900">{page.name}</div>
                                            <div className="text-xs text-gray-500">{page.category}</div>
                                        </div>
                                        <ArrowRight className="w-4 h-4 text-gray-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                                    </Link>
                                ))}
                            </div>
                        </div>
                        <div className="text-xs text-gray-500 border-t pt-2">
                            <div className="flex justify-between">
                                <span>Use ↑↓ to navigate</span>
                                <span>Enter to select • Esc to close</span>
                            </div>
                        </div>
                    </div>
                </DialogContent>
            </Dialog>
        </>
    );
}