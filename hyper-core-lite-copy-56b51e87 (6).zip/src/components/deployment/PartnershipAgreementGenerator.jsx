import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Copy, AlertTriangle } from 'lucide-react';
import { toast } from "sonner";

const AGREEMENT_TEMPLATE = `STRATEGIC DATA PARTNERSHIP AGREEMENT

This Agreement is between HyperCore AI, LLC ("HyperCore") and [PARTNER_NAME] ("Partner").

1.  SERVICES & SERVICE FEE
    HyperCore will provide its Cybersecurity Platform ("Services") to Partner. In exchange, Partner agrees to pay an annual service fee of $[ANNUAL_FEE]. This fee represents a significant discount from the standard market rate in consideration of the data rights granted herein.

2.  DATA RIGHTS & USAGE
    Partner grants HyperCore the right to ingest and analyze anonymized security, network, and operational data ("Data") generated during the provision of Services. HyperCore is explicitly permitted to use this anonymized Data for the sole purpose of training, validating, and improving its proprietary artificial intelligence models.

3.  INTELLECTUAL PROPERTY
    All pre-existing intellectual property remains with its original owner. Any new artificial intelligence models, algorithms, or derivative technologies created by HyperCore utilizing the anonymized Data shall be the sole and exclusive property of HyperCore AI, LLC.

4.  TECHNOLOGY TRANSFER
    Partner shall receive access to the continuously improving Services, which incorporate the enhanced AI models trained on their Data, at no additional cost for the duration of this Agreement.

5.  CONFIDENTIALITY & SECURITY
    HyperCore will treat all Partner data as confidential. Data will be anonymized using industry-standard techniques before use in AI training.

6.  LIABILITY & DISCLAIMER
    HyperCore provides its services "as-is." Liability for any damages arising from the Services is limited to the total service fees paid in the preceding 12 months.

7.  TERM & TERMINATION
    This agreement is for an initial term of one (1) year and will automatically renew unless terminated by either party with 60 days written notice.

This Agreement constitutes the entire understanding between the parties.

HyperCore AI, LLC: _________________________
[PARTNER_NAME]: _________________________`;

export default function PartnershipAgreementGenerator() {
    const copyTemplate = () => {
        navigator.clipboard.writeText(AGREEMENT_TEMPLATE);
        toast.success("Agreement template copied!");
    };

    return (
        <Card>
            <CardHeader>
                <CardTitle>Strategic Data Partnership Agreement Template</CardTitle>
                <CardDescription>
                    This is the key legal instrument for your new model. It exchanges discounted services for data rights.
                </CardDescription>
            </CardHeader>
            <CardContent>
                <div className="bg-yellow-50 border border-yellow-200 p-3 rounded-lg mb-4 flex items-start gap-3">
                    <AlertTriangle className="w-8 h-8 text-yellow-600" />
                    <div>
                        <h4 className="font-semibold text-yellow-800">Legal Disclaimer</h4>
                        <p className="text-xs text-yellow-700">This is a template for discussion purposes only and NOT a legally binding document. You MUST have this reviewed and finalized by a qualified attorney before use.</p>
                    </div>
                </div>
                <Textarea 
                    readOnly 
                    value={AGREEMENT_TEMPLATE}
                    className="h-96 font-mono text-xs bg-gray-50"
                />
                <Button onClick={copyTemplate} className="mt-4 w-full">
                    <Copy className="w-4 h-4 mr-2" />
                    Copy Template to Clipboard
                </Button>
            </CardContent>
        </Card>
    );
}