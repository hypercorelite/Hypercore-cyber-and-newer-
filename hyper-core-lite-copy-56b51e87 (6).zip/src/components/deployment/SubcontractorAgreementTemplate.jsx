import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { FileText, Download } from 'lucide-react';

export default function SubcontractorAgreementTemplate() {
    const [primeContractor, setPrimeContractor] = useState('');
    const [contactEmail, setContactEmail] = useState('');

    const agreementTemplate = `
SUBCONTRACTOR SERVICES AGREEMENT
CMMC Compliance Assessment Services

This agreement between ${primeContractor || '[PRIME CONTRACTOR NAME]'} ("Prime") and HyperCore AI, LLC ("HyperCore") establishes terms for CMMC Level 2 compliance assessment services.

1. SCOPE OF SERVICES
HyperCore will provide AI-powered CMMC Level 2 readiness assessments for Prime's subcontractors, including:
- Automated gap analysis across all 14 CMMC domains
- Evidence-based risk scoring and compliance recommendations
- Policy template generation and implementation guidance
- Pre-audit readiness validation and C3PAO preparation

2. PERFORMANCE METRICS
- Assessment completion timeline: 30 days maximum
- Success rate guarantee: 95% C3PAO audit pass rate
- Cost per assessment: $25,000 (83% savings vs traditional consulting)
- Scalability: Up to 50 simultaneous assessments

3. DATA RIGHTS AND PRIVACY
- All client-specific data remains confidential to Prime and subcontractor
- HyperCore may retain anonymized compliance patterns for model improvement
- No subcontractor data shared between Prime's competitors
- Full audit trail provided for each assessment

4. PAYMENT TERMS
- Payment due 30 days after successful subcontractor certification
- Volume discounts available for 25+ assessments annually
- No upfront costs or retainer fees required
- Performance-based pricing tied to audit success rates

5. STRATEGIC PARTNERSHIP BENEFITS
- Priority access to HyperCore's latest compliance tools
- Quarterly supply chain cyber risk reports
- Direct access to compliance legal and insurance partner network
- Joint marketing opportunities in defense sector

Contact: partnerships@hypercorecyber.com for execution.
`;

    const handleGenerateAgreement = () => {
        const element = document.createElement('a');
        const file = new Blob([agreementTemplate], { type: 'text/plain' });
        element.href = URL.createObjectURL(file);
        element.download = `HyperCore_Subcontractor_Agreement_${primeContractor || 'Template'}.txt`;
        document.body.appendChild(element);
        element.click();
        document.body.removeChild(element);
    };

    return (
        <Card>
            <CardHeader>
                <CardTitle className="flex items-center gap-2">
                    <FileText className="w-5 h-5 text-blue-600" />
                    Subcontractor Agreement Template
                </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Input
                        placeholder="Prime Contractor Name"
                        value={primeContractor}
                        onChange={(e) => setPrimeContractor(e.target.value)}
                    />
                    <Input
                        placeholder="Contact Email"
                        value={contactEmail}
                        onChange={(e) => setContactEmail(e.target.value)}
                    />
                </div>
                
                <div className="bg-gray-50 p-4 rounded-lg border max-h-64 overflow-y-auto">
                    <pre className="text-xs text-gray-700 whitespace-pre-wrap">
                        {agreementTemplate}
                    </pre>
                </div>

                <Button onClick={handleGenerateAgreement} className="w-full">
                    <Download className="w-4 h-4 mr-2" />
                    Download Customized Agreement
                </Button>
            </CardContent>
        </Card>
    );
}