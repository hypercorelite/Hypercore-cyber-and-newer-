import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { DollarSign, Percent, TrendingDown, TrendingUp } from 'lucide-react';

export default function FinancialModel() {
    const [model, setModel] = useState({
        industryCost: 500000,
        hypercoreDiscount: 60,
        annualOverhead: 150000,
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        setModel(prev => ({ ...prev, [name]: parseFloat(value) || 0 }));
    };

    const hypercoreFee = model.industryCost * (1 - model.hypercoreDiscount / 100);
    const netOperatingIncome = hypercoreFee - model.annualOverhead;

    return (
        <Card>
            <CardHeader>
                <CardTitle>Overhead Coverage Financial Model</CardTitle>
                <CardDescription>Calculate the service fee required to cover costs and achieve profitability on a single partnership.</CardDescription>
            </CardHeader>
            <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-4">
                    <div>
                        <Label htmlFor="industryCost">Standard Industry Cost (Annual)</Label>
                        <div className="relative">
                            <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                            <Input id="industryCost" name="industryCost" type="number" value={model.industryCost} onChange={handleChange} className="pl-8" />
                        </div>
                    </div>
                    <div>
                        <Label htmlFor="hypercoreDiscount">HyperCore Discount</Label>
                        <div className="relative">
                            <Percent className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                            <Input id="hypercoreDiscount" name="hypercoreDiscount" type="number" value={model.hypercoreDiscount} onChange={handleChange} className="pl-8" />
                        </div>
                    </div>
                    <div>
                        <Label htmlFor="annualOverhead">Your Annual Operational Overhead</Label>
                        <div className="relative">
                            <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                            <Input id="annualOverhead" name="annualOverhead" type="number" value={model.annualOverhead} onChange={handleChange} className="pl-8" />
                        </div>
                    </div>
                </div>

                <div className="space-y-4 rounded-lg bg-gray-50 p-6 border">
                    <h4 className="font-semibold text-center mb-4">Partnership Financials</h4>
                    <div className="space-y-3">
                        <div className="flex justify-between items-center">
                            <span className="text-sm text-gray-600">Partner's Savings</span>
                            <span className="font-semibold text-green-600">
                                {model.hypercoreDiscount}%
                            </span>
                        </div>
                        <div className="flex justify-between items-center border-t pt-3">
                            <span className="font-semibold">HyperCore Annual Service Fee</span>
                            <span className="font-bold text-lg text-blue-600">
                                ${hypercoreFee.toLocaleString()}
                            </span>
                        </div>
                        <div className="flex justify-between items-center">
                            <span className="text-sm text-gray-600">Annual Overhead</span>
                            <span className="font-semibold text-red-600">
                                - ${model.annualOverhead.toLocaleString()}
                            </span>
                        </div>
                        <div className="flex justify-between items-center border-t-2 pt-3">
                            <span className="font-bold text-xl">Net Operating Income</span>
                            <span className={`font-extrabold text-2xl ${netOperatingIncome >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                                ${netOperatingIncome.toLocaleString()}
                            </span>
                        </div>
                    </div>
                    <div className="mt-4 text-xs text-gray-500 text-center">
                        This model demonstrates how one strategic partnership can cover all your operating costs, making every subsequent deal pure profit.
                    </div>
                </div>
            </CardContent>
        </Card>
    );
}