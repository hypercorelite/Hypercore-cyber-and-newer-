import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { TrendingUp, Database, Brain, DollarSign } from 'lucide-react';

const DATA_ASSET_METRICS = {
    current_assessments: 0,
    target_year_1: 100,
    data_points_per_assessment: 2000,
    model_improvement_rate: 15, // % improvement per 25 assessments
    market_value_per_data_point: 5, // $ estimated market value
    competitive_moat_strength: 85 // % based on data exclusivity
};

export default function DataAssetValuation() {
    const currentValue = DATA_ASSET_METRICS.current_assessments * 
                        DATA_ASSET_METRICS.data_points_per_assessment * 
                        DATA_ASSET_METRICS.market_value_per_data_point;

    const projectedYear1Value = DATA_ASSET_METRICS.target_year_1 * 
                               DATA_ASSET_METRICS.data_points_per_assessment * 
                               DATA_ASSET_METRICS.market_value_per_data_point;

    return (
        <div className="space-y-6">
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Database className="w-5 h-5 text-purple-600" />
                        Data Asset Valuation Model
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                        <div className="text-center">
                            <div className="text-2xl font-bold text-purple-600">${currentValue.toLocaleString()}</div>
                            <div className="text-sm text-gray-600">Current Asset Value</div>
                        </div>
                        <div className="text-center">
                            <div className="text-2xl font-bold text-blue-600">${projectedYear1Value.toLocaleString()}</div>
                            <div className="text-sm text-gray-600">Year 1 Projected</div>
                        </div>
                        <div className="text-center">
                            <div className="text-2xl font-bold text-green-600">{DATA_ASSET_METRICS.competitive_moat_strength}%</div>
                            <div className="text-sm text-gray-600">Moat Strength</div>
                        </div>
                        <div className="text-center">
                            <div className="text-2xl font-bold text-orange-600">{DATA_ASSET_METRICS.model_improvement_rate}%</div>
                            <div className="text-sm text-gray-600">Model Improvement</div>
                        </div>
                    </div>

                    <div className="space-y-4">
                        <div>
                            <div className="flex justify-between items-center mb-2">
                                <span className="text-sm font-medium">Data Collection Progress</span>
                                <span className="text-sm text-gray-600">
                                    {DATA_ASSET_METRICS.current_assessments} / {DATA_ASSET_METRICS.target_year_1} assessments
                                </span>
                            </div>
                            <Progress 
                                value={(DATA_ASSET_METRICS.current_assessments / DATA_ASSET_METRICS.target_year_1) * 100} 
                                className="h-2"
                            />
                        </div>

                        <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                            <h4 className="font-semibold text-blue-800 mb-2">Strategic Data Assets Being Built</h4>
                            <ul className="text-sm text-blue-700 space-y-1">
                                <li>• <strong>Compliance Pattern Library:</strong> Industry-specific implementation examples</li>
                                <li>• <strong>Risk Scoring Models:</strong> Predictive algorithms for C3PAO audit outcomes</li>
                                <li>• <strong>Policy Generation Engines:</strong> Automated creation of compliant documentation</li>
                                <li>• <strong>Sector Benchmarks:</strong> Comparative analysis across defense industry segments</li>
                                <li>• <strong>Supply Chain Intelligence:</strong> Subcontractor risk profiling and trends</li>
                            </ul>
                        </div>

                        <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                            <h4 className="font-semibold text-green-800 mb-2">Revenue Streams from Data Assets</h4>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                                <div>
                                    <h5 className="font-medium text-green-700">Direct Revenue</h5>
                                    <ul className="text-green-700 space-y-1">
                                        <li>• Assessment services ($25K each)</li>
                                        <li>• Ongoing monitoring subscriptions</li>
                                        <li>• Premium analytics dashboards</li>
                                    </ul>
                                </div>
                                <div>
                                    <h5 className="font-medium text-green-700">Licensing Revenue</h5>
                                    <ul className="text-green-700 space-y-1">
                                        <li>• Model licensing to consultants</li>
                                        <li>• C3PAO partnership fees</li>
                                        <li>• Insurance carrier integrations</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}