import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { 
    Play, 
    Square, 
    RotateCcw, 
    Monitor,
    HardDrive,
    Cpu,
    MemoryStick,
    Plus,
    Loader2
} from "lucide-react";
import { motion } from "framer-motion";

const KVM_API_URL = "https://your-kvm-server.com/api"; // Replace with your server

export default function VMControlPanel({ vm, onVMUpdate }) {
    const [loading, setLoading] = useState(false);
    const [vncUrl, setVncUrl] = useState(null);

    const callKVMAPI = async (endpoint, method = 'GET', data = null) => {
        try {
            const response = await fetch(`${KVM_API_URL}${endpoint}`, {
                method,
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer YOUR_API_TOKEN`
                },
                body: data ? JSON.stringify(data) : null
            });
            return await response.json();
        } catch (error) {
            console.error('KVM API Error:', error);
            throw error;
        }
    };

    const startVM = async () => {
        setLoading(true);
        try {
            await callKVMAPI(`/vms/${vm.kvm_id}/start`, 'POST');
            onVMUpdate(vm.id, { status: 'running' });
        } catch (error) {
            console.error('Failed to start VM:', error);
        } finally {
            setLoading(false);
        }
    };

    const stopVM = async () => {
        setLoading(true);
        try {
            await callKVMAPI(`/vms/${vm.kvm_id}/stop`, 'POST');
            onVMUpdate(vm.id, { status: 'stopped' });
        } catch (error) {
            console.error('Failed to stop VM:', error);
        } finally {
            setLoading(false);
        }
    };

    const connectVNC = async () => {
        try {
            const response = await callKVMAPI(`/vms/${vm.kvm_id}/vnc`);
            setVncUrl(response.vnc_url);
        } catch (error) {
            console.error('Failed to get VNC connection:', error);
        }
    };

    const createSnapshot = async () => {
        setLoading(true);
        try {
            await callKVMAPI(`/vms/${vm.kvm_id}/snapshot`, 'POST', {
                name: `snapshot-${Date.now()}`
            });
        } catch (error) {
            console.error('Failed to create snapshot:', error);
        } finally {
            setLoading(false);
        }
    };

    return (
        <Card className="border-l-4 border-l-blue-500">
            <CardHeader>
                <div className="flex justify-between items-center">
                    <CardTitle className="flex items-center gap-2">
                        <Monitor className="w-5 h-5" />
                        {vm.name}
                    </CardTitle>
                    <Badge 
                        className={vm.status === 'running' ? 
                            'bg-green-100 text-green-800' : 
                            'bg-gray-100 text-gray-800'
                        }
                    >
                        {vm.status}
                    </Badge>
                </div>
                <div className="text-sm text-gray-600">
                    KVM ID: {vm.kvm_id || 'Not assigned'}
                </div>
            </CardHeader>
            <CardContent className="space-y-4">
                <div className="grid grid-cols-3 gap-4 text-sm">
                    <div className="flex items-center gap-2">
                        <Cpu className="w-4 h-4 text-blue-500" />
                        {vm.cpu_cores} cores
                    </div>
                    <div className="flex items-center gap-2">
                        <MemoryStick className="w-4 h-4 text-green-500" />
                        {vm.memory}GB RAM
                    </div>
                    <div className="flex items-center gap-2">
                        <HardDrive className="w-4 h-4 text-purple-500" />
                        {vm.storage}GB
                    </div>
                </div>

                <div className="flex gap-2">
                    {vm.status === 'stopped' ? (
                        <Button 
                            onClick={startVM}
                            disabled={loading}
                            className="bg-green-600 hover:bg-green-700"
                        >
                            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4" />}
                            Start VM
                        </Button>
                    ) : (
                        <Button 
                            onClick={stopVM}
                            disabled={loading}
                            variant="destructive"
                        >
                            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Square className="w-4 h-4" />}
                            Stop VM
                        </Button>
                    )}
                    
                    <Button 
                        onClick={connectVNC}
                        disabled={vm.status !== 'running'}
                        variant="outline"
                    >
                        <Monitor className="w-4 h-4" />
                        Connect
                    </Button>
                    
                    <Button 
                        onClick={createSnapshot}
                        disabled={loading || vm.status !== 'running'}
                        variant="outline"
                    >
                        <RotateCcw className="w-4 h-4" />
                        Snapshot
                    </Button>
                </div>

                {vncUrl && (
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="border rounded-lg p-4 bg-gray-50"
                    >
                        <div className="text-sm font-semibold mb-2">VM Console:</div>
                        <iframe 
                            src={vncUrl} 
                            width="100%" 
                            height="400"
                            className="border rounded"
                        />
                    </motion.div>
                )}
            </CardContent>
        </Card>
    );
}