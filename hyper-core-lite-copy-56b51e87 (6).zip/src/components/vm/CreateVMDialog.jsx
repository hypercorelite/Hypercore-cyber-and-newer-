import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Plus, Loader2 } from "lucide-react";

const KVM_API_URL = "https://your-kvm-server.com/api";

export default function CreateVMDialog({ onVMCreated }) {
    const [open, setOpen] = useState(false);
    const [creating, setCreating] = useState(false);
    const [vmConfig, setVmConfig] = useState({
        name: "",
        os_template: "",
        cpu_cores: 2,
        memory: 4,
        storage: 50
    });

    const createVM = async () => {
        setCreating(true);
        try {
            // Step 1: Create VM in KVM
            const kvmResponse = await fetch(`${KVM_API_URL}/vms/create`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer YOUR_API_TOKEN'
                },
                body: JSON.stringify(vmConfig)
            });
            const kvmData = await kvmResponse.json();

            // Step 2: Create VM record in Base44 database
            if (onVMCreated) {
                await onVMCreated({
                    ...vmConfig,
                    kvm_id: kvmData.vm_id,
                    status: 'stopped',
                    ip_address: kvmData.ip_address || 'Pending'
                });
            }

            setOpen(false);
            setVmConfig({
                name: "",
                os_template: "",
                cpu_cores: 2,
                memory: 4,
                storage: 50
            });
        } catch (error) {
            console.error('Failed to create VM:', error);
        } finally {
            setCreating(false);
        }
    };

    return (
        <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
                <Button className="bg-blue-600 hover:bg-blue-700">
                    <Plus className="w-4 h-4 mr-2" />
                    Create VM
                </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
                <DialogHeader>
                    <DialogTitle>Create New Virtual Machine</DialogTitle>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                    <div className="grid gap-2">
                        <Label htmlFor="name">VM Name</Label>
                        <Input
                            id="name"
                            value={vmConfig.name}
                            onChange={(e) => setVmConfig({...vmConfig, name: e.target.value})}
                            placeholder="e.g., Security-Workstation-01"
                        />
                    </div>
                    
                    <div className="grid gap-2">
                        <Label htmlFor="template">Operating System</Label>
                        <Select 
                            value={vmConfig.os_template} 
                            onValueChange={(value) => setVmConfig({...vmConfig, os_template: value})}
                        >
                            <SelectTrigger>
                                <SelectValue placeholder="Select OS template" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="ubuntu-22.04">Ubuntu 22.04 LTS</SelectItem>
                                <SelectItem value="windows-11">Windows 11</SelectItem>
                                <SelectItem value="kali-linux">Kali Linux</SelectItem>
                                <SelectItem value="centos-8">CentOS Stream 8</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                        <div className="grid gap-2">
                            <Label htmlFor="cpu">CPU Cores</Label>
                            <Select 
                                value={vmConfig.cpu_cores.toString()} 
                                onValueChange={(value) => setVmConfig({...vmConfig, cpu_cores: parseInt(value)})}
                            >
                                <SelectTrigger>
                                    <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="2">2 cores</SelectItem>
                                    <SelectItem value="4">4 cores</SelectItem>
                                    <SelectItem value="8">8 cores</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>

                        <div className="grid gap-2">
                            <Label htmlFor="memory">RAM (GB)</Label>
                            <Select 
                                value={vmConfig.memory.toString()} 
                                onValueChange={(value) => setVmConfig({...vmConfig, memory: parseInt(value)})}
                            >
                                <SelectTrigger>
                                    <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="4">4 GB</SelectItem>
                                    <SelectItem value="8">8 GB</SelectItem>
                                    <SelectItem value="16">16 GB</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                    </div>

                    <div className="grid gap-2">
                        <Label htmlFor="storage">Storage (GB)</Label>
                        <Input
                            id="storage"
                            type="number"
                            value={vmConfig.storage}
                            onChange={(e) => setVmConfig({...vmConfig, storage: parseInt(e.target.value)})}
                            min="20"
                            max="500"
                        />
                    </div>
                </div>
                
                <div className="flex justify-end gap-2">
                    <Button variant="outline" onClick={() => setOpen(false)}>
                        Cancel
                    </Button>
                    <Button 
                        onClick={createVM} 
                        disabled={creating || !vmConfig.name || !vmConfig.os_template}
                    >
                        {creating ? (
                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        ) : (
                            <Plus className="w-4 h-4 mr-2" />
                        )}
                        Create VM
                    </Button>
                </div>
            </DialogContent>
        </Dialog>
    );
}