import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { PartnershipCommunication } from "@/api/entities";
import { Phone, Mail, ExternalLink, Plus } from 'lucide-react';
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";

const URGENT_CONTACTS = [
    {
        type: "insurance",
        company: "TechShield Insurance",
        contact: "Sarah Chen",
        phone: "(415) 555-0187",
        email: "sarah@techshield.com",
        priority: "Call TODAY - Cyber/Tech specialist"
    },
    {
        type: "attorney", 
        company: "Cooley LLP",
        contact: "Gov Contracts Group",
        phone: "(650) 843-5000",
        email: "info@cooley.com",
        priority: "Email TODAY - Federal contract expertise"
    }
];

export default function ProfessionalServicesWidget() {
    const [recentComms, setRecentComms] = useState([]);

    useEffect(() => {
        const loadRecentComms = async () => {
            try {
                const comms = await PartnershipCommunication.filter(
                    { partnership_type: ['insurance_broker', 'attorney'] },
                    '-created_date',
                    3
                );
                setRecentComms(comms);
            } catch (error) {
                console.error('Failed to load communications:', error);
            }
        };
        loadRecentComms();
    }, []);

    return (
        <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7 }}
        >
            <Card className="bg-gradient-to-br from-red-50 to-orange-50 border-red-200">
                <CardHeader>
                    <CardTitle className="text-red-800 flex items-center gap-2">
                        🚨 URGENT: Complete Legal Foundation
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="space-y-4">
                        <div className="bg-red-100 border border-red-300 rounded-lg p-3">
                            <p className="text-sm text-red-800 font-semibold">
                                ⚠️ No client work can begin until insurance is in place. 
                                Start these conversations immediately.
                            </p>
                        </div>

                        <div className="grid gap-3">
                            {URGENT_CONTACTS.map((contact) => (
                                <div key={`${contact.type}-${contact.company}`} className="bg-white rounded-lg p-3 border">
                                    <div className="flex justify-between items-start mb-2">
                                        <div>
                                            <h4 className="font-semibold text-sm">{contact.company}</h4>
                                            <p className="text-xs text-gray-600">{contact.contact}</p>
                                        </div>
                                        <Badge className={contact.type === 'insurance' ? 'bg-blue-100 text-blue-800' : 'bg-purple-100 text-purple-800'}>
                                            {contact.type}
                                        </Badge>
                                    </div>
                                    <p className="text-xs text-orange-600 font-medium mb-2">{contact.priority}</p>
                                    <div className="flex gap-2">
                                        <Button size="sm" variant="outline" asChild>
                                            <a href={`tel:${contact.phone}`}>
                                                <Phone className="w-3 h-3 mr-1" />
                                                Call
                                            </a>
                                        </Button>
                                        <Button size="sm" variant="outline" asChild>
                                            <a href={`mailto:${contact.email}`}>
                                                <Mail className="w-3 h-3 mr-1" />
                                                Email
                                            </a>
                                        </Button>
                                    </div>
                                </div>
                            ))}
                        </div>

                        {recentComms.length > 0 && (
                            <div className="border-t pt-3">
                                <h4 className="text-sm font-semibold mb-2">Recent Communications:</h4>
                                {recentComms.map((comm) => (
                                    <div key={comm.id} className="text-xs text-gray-600 mb-1">
                                        • {comm.organization} - {comm.status} ({new Date(comm.created_date).toLocaleDateString()})
                                    </div>
                                ))}
                            </div>
                        )}

                        <div className="flex gap-2">
                            <Button size="sm" asChild className="flex-1">
                                <Link to={createPageUrl('ProfessionalServices')}>
                                    <Plus className="w-3 h-3 mr-1" />
                                    Full Contact System
                                </Link>
                            </Button>
                        </div>
                    </div>
                </CardContent>
            </Card>
        </motion.div>
    );
}