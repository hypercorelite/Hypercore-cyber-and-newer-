import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Handshake, Mail, Rocket, ArrowRight, BarChart, Users, CheckCircle, Shield, Bot, HardDrive, Database, Trash2, RefreshCw, Github, FileText, Gavel, DollarSign, AlertCircle, Award, Clock, Target, Zap, GitBranch, Calendar, Monitor, BookOpen, Search, Settings, TestTube, AlertTriangle, Gauge, Cloud, Eye, Layers, Calculator } from "lucide-react";
import SecurityMetrics from "../security/SecurityMetrics";
import WelcomeBanner from "../security/WelcomeBanner";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { PartnershipCommunication } from "@/api/entities";
import { AuditLog } from "@/api/entities";
import { TestingLog } from "@/api/entities";
import { SupportTicket } from "@/api/entities";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import BreadcrumbNav from "../navigation/BreadcrumbNav";
import { LoadingSpinner } from "../ui/LoadingSpinner";
import MVPScopeWidget from "./MVPScopeWidget";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

export default function AdminDashboardView({ user }) {
    const [sampleData, setSampleData] = useState({
        partnerships: [],
        auditLogs: [],
        testingLogs: [],
        supportTickets: []
    });
    const [loading, setLoading] = useState(false);

    const loadSampleData = async () => {
        setLoading(true);
        try {
            const [partnerships, auditLogs, testingLogs, supportTickets] = await Promise.all([
                PartnershipCommunication.list('-created_date', 20),
                AuditLog.list('-created_date', 20),
                TestingLog.list('-created_date', 20),
                SupportTicket.list('-created_date', 20)
            ]);
            
            setSampleData({ partnerships, auditLogs, testingLogs, supportTickets });
        } catch (error) {
            console.error("Failed to load sample data:", error);
            toast.error("Failed to load sample data");
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        loadSampleData();
    }, []);

    const deleteRecord = async (entityName, recordId, entityObject) => {
        if (!confirm("Are you sure you want to delete this record? This action cannot be undone.")) return;
        try {
            await entityObject.delete(recordId);
            toast.success("Record deleted successfully");
            loadSampleData();
        } catch (error) {
            toast.error("Failed to delete record");
        }
    };

    const clearAllData = async (entityName, entityObject) => {
        if (!confirm(`Are you sure you want to delete ALL ${entityName} records? This action cannot be undone.`)) return;
        try {
            const records = await entityObject.list();
            for (const record of records) await entityObject.delete(record.id);
            toast.success(`All ${entityName} records deleted`);
            loadSampleData();
        } catch (error) {
            toast.error("Failed to clear all data");
        }
    };
    
    const adminTools = [
        { name: "🔧 SYSTEM DIAGNOSTICS", description: "Test all critical functions: SSP generation, email system, database, AI analysis.", href: createPageUrl('SystemTests'), icon: TestTube, color: "from-red-600 via-orange-600 to-yellow-600 text-white" },
        { name: "Traceability Matrix", description: "Map controls to policies, evidence, and status.", href: createPageUrl('TraceabilityMatrix'), icon: Layers, color: "from-blue-500 to-indigo-600" },
        { name: "SPRS Score Calculator", description: "Calculate your NIST 800-171 assessment score for SPRS submission.", href: createPageUrl('SPRSScoreCalculator'), icon: Calculator, color: "from-green-500 to-teal-600" },
        { name: "POA&M Generator", description: "Create a Plan of Action & Milestones from gap analysis results.", href: createPageUrl('POAMGenerator'), icon: FileText, color: "from-purple-500 to-violet-600" },
        { name: "Implementation Timeline", description: "Generate a 12-week project plan for CMMC compliance.", href: createPageUrl('ImplementationTimeline'), icon: Calendar, color: "from-sky-500 to-blue-600" },
        { name: "Control Prioritization Matrix", description: "Focus on high-impact 'quick wins' for compliance.", href: createPageUrl('ControlPrioritizationMatrix'), icon: Target, color: "from-yellow-500 to-amber-600" },
        { name: "User Roles & Views", description: "Explanation of the public, client, and admin portals.", href: createPageUrl("UserRolesAndViews"), icon: Eye, color: "from-slate-500 to-slate-700" },
        { name: "Client CRM", description: "Manage your sales pipeline and track leads.", href: createPageUrl("PartnershipHub"), icon: Handshake, color: "from-blue-500 to-indigo-600" },
        { name: "Support Dashboard", description: "Manage client support tickets and expert requests.", href: createPageUrl("SupportDashboard"), icon: Users, color: "from-purple-500 to-violet-600" },
        { name: "🔥 Daily Achievement Schedule 🔥", description: "Your 75-day bible. The daily checklist from Sep 15 to Dec 3.", href: createPageUrl("DailyAchievementSchedule"), icon: Calendar, color: "from-red-500 to-orange-500 animate-pulse" },
        { name: "🔥 AWS Migration Plan 🔥", description: "AI-assisted playbook for migrating from Base44 to AWS Serverless.", href: createPageUrl("AWSMigrationExecutionPlan"), icon: Cloud, color: "from-orange-500 to-amber-600 animate-pulse" },
        { name: "🔥 8-Week Hybrid Sprint Plan 🔥", description: "The balanced approach: AI-powered dev with sustainable learning.", href: createPageUrl("HybridSprintPlan"), icon: Calendar, color: "from-blue-500 to-green-500 animate-pulse" },
    ];
    
    return (
        <div className="space-y-6">
            <BreadcrumbNav currentPageName="Dashboard" />
            <WelcomeBanner user={user} />
            <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
                <Card className="bg-gradient-to-r from-red-600 via-orange-600 to-red-700 text-white border-0 shadow-xl">
                    <CardContent className="p-6">
                        <div className="flex items-center gap-4">
                            <Shield className="w-12 h-12 text-white flex-shrink-0 animate-pulse" />
                            <div className="flex-grow">
                                <h2 className="text-2xl font-bold">🚨 DFARS RULE IS FINAL: ENFORCEMENT BEGINS NOVEMBER 10, 2025</h2>
                                <p className="text-lg font-semibold">Published September 10, 2025 • 60 Days to Mandatory CMMC Compliance</p>
                            </div>
                            <Button asChild size="lg" className="bg-white text-red-600 hover:bg-gray-100 font-bold px-6 py-4 flex-shrink-0">
                                <Link to={createPageUrl('SBIRBackupStrategy')}>VIEW RESPONSE STRATEGY <ArrowRight className="w-5 h-5 ml-2" /></Link>
                            </Button>
                        </div>
                    </CardContent>
                </Card>
            </motion.div>
            <Tabs defaultValue="tools" className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="tools">Admin Tools</TabsTrigger>
                    <TabsTrigger value="data">Data Management</TabsTrigger>
                    <TabsTrigger value="system">System Status</TabsTrigger>
                </TabsList>
                <TabsContent value="tools">
                    <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }}>
                        <CardHeader className="px-0">
                            <CardTitle className="text-2xl sm:text-3xl font-bold text-gray-900 flex items-center gap-3">
                                <BarChart className="w-7 h-7" /> Admin Dashboard
                            </CardTitle>
                            <CardDescription>Your command center for the MVP sprint, SBIR preparation, and business development.</CardDescription>
                        </CardHeader>
                    </motion.div>
                    <motion.div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.1, staggerChildren: 0.1 }}>
                        {adminTools.map((tool) => (
                             <motion.div key={tool.name} variants={{ hidden: { y: 20, opacity: 0 }, visible: { y: 0, opacity: 1 } }}>
                                <Link to={tool.href} className="block h-full">
                                    <Card className={`bg-gradient-to-br ${tool.color} text-white hover:shadow-xl transition-shadow h-full flex flex-col`}>
                                        <CardHeader>
                                            <tool.icon className="w-8 h-8 mb-3" />
                                            <CardTitle>{tool.name}</CardTitle>
                                        </CardHeader>
                                        <CardContent className="flex-grow">
                                            <p className="text-sm opacity-90">{tool.description}</p>
                                        </CardContent>
                                        <div className="p-4 pt-0">
                                             <Button variant="secondary" className="w-full justify-between text-sm">Open Tool <ArrowRight className="w-4 h-4 ml-2"/></Button>
                                        </div>
                                    </Card>
                                </Link>
                            </motion.div>
                        ))}
                    </motion.div>
                </TabsContent>
                <TabsContent value="data">
                    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
                        <div className="flex justify-between items-center">
                            <div>
                                <h2 className="text-2xl font-bold flex items-center gap-3"><Database className="w-6 h-6 text-blue-600" /> Sample Data Management</h2>
                                <p className="text-gray-600">View, edit, and delete sample data across all entities</p>
                            </div>
                            <Button onClick={loadSampleData} disabled={loading}><RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />{loading ? 'Loading...' : 'Refresh Data'}</Button>
                        </div>
                        <Card>
                            <CardHeader className="flex flex-row items-center justify-between">
                                <div><CardTitle>Partnership Communications ({sampleData.partnerships.length})</CardTitle><CardDescription>Manage partnership contacts and communications</CardDescription></div>
                                <Button variant="destructive" size="sm" onClick={() => clearAllData('Partnership Communications', PartnershipCommunication)}><Trash2 className="w-4 h-4 mr-2" /> Clear All</Button>
                            </CardHeader>
                            <CardContent><div className="space-y-2 max-h-60 overflow-y-auto">{sampleData.partnerships.map((record) => (<div key={record.id} className="flex flex-col sm:flex-row justify-between items-start sm:items-center p-3 bg-gray-50 rounded-md gap-2"><div className="flex-grow"><p className="font-medium">{record.organization}</p><p className="text-sm text-gray-600">{record.contact_person} - {record.email}</p><div className="flex gap-2 mt-1 flex-wrap"><Badge className="text-xs">{record.status}</Badge><Badge variant="outline" className="text-xs">{record.partnership_type}</Badge></div></div><Button variant="destructive" size="sm" onClick={() => deleteRecord('Partnership', record.id, PartnershipCommunication)} className="self-end sm:self-center"><Trash2 className="w-4 h-4" /></Button></div>))}{sampleData.partnerships.length === 0 && (<p className="text-center text-gray-500 py-4">No partnership records found</p>)}</div></CardContent>
                        </Card>
                        <Card>
                            <CardHeader className="flex flex-row items-center justify-between">
                                <div><CardTitle>Audit Logs ({sampleData.auditLogs.length})</CardTitle><CardDescription>System audit trail and event logs</CardDescription></div>
                                <Button variant="destructive" size="sm" onClick={() => clearAllData('Audit Logs', AuditLog)}><Trash2 className="w-4 h-4 mr-2" /> Clear All</Button>
                            </CardHeader>
                            <CardContent><div className="space-y-2 max-h-60 overflow-y-auto">{sampleData.auditLogs.map((record) => (<div key={record.id} className="flex flex-col sm:flex-row justify-between items-start sm:items-center p-3 bg-gray-50 rounded-md gap-2"><div className="flex-grow"><p className="font-medium">{record.event_name}</p><p className="text-sm text-gray-600">{record.user_email}</p><div className="flex gap-2 mt-1 flex-wrap"><Badge className={record.status === 'SUCCESS' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}>{record.status}</Badge>{record.sector_category && (<Badge variant="outline" className="text-xs">{record.sector_category}</Badge>)}</div></div><Button variant="destructive" size="sm" onClick={() => deleteRecord('Audit Log', record.id, AuditLog)} className="self-end sm:self-center"><Trash2 className="w-4 h-4" /></Button></div>))}{sampleData.auditLogs.length === 0 && (<p className="text-center text-gray-500 py-4">No audit logs found</p>)}</div></CardContent>
                        </Card>
                    </motion.div>
                </TabsContent>
                <TabsContent value="system">
                     <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.3 }} className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                        <Card className="bg-green-50 border-green-200"><CardContent className="p-4"><div className="flex items-center gap-3"><CheckCircle className="w-6 h-6 text-green-600" /><div><h4 className="font-semibold text-green-800">Email System</h4><p className="text-sm text-green-600">SendGrid configured & ready</p></div></div></CardContent></Card>
                        <Card className="bg-blue-50 border-blue-200"><CardContent className="p-4"><div className="flex items-center gap-3"><Shield className="w-6 h-6 text-blue-600" /><div><h4 className="font-semibold text-blue-800">Banking Infrastructure</h4><p className="text-sm text-blue-600">Wire transfer system ready</p></div></div></CardContent></Card>
                        <Card className="bg-purple-50 border-purple-200"><CardContent className="p-4"><div className="flex items-center gap-3"><Bot className="w-6 h-6 text-purple-600" /><div><h4 className="font-semibold text-purple-800">AI Support Agent</h4><p className="text-sm text-purple-600">24/7 customer support active</p></div></div></CardContent></Card>
                    </motion.div>
                    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0, transition: { delay: 0.5 } }} className="mt-6"><MVPScopeWidget /></motion.div>
                    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.2 }} className="mt-4"><SecurityMetrics /></motion.div>
                </TabsContent>
            </Tabs>
        </div>
    );
}