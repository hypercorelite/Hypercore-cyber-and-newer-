import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { ArrowRight, Zap, Clock, Shield, Layers, Calculator, FileText, Calendar, Target, Award } from 'lucide-react';
import { motion } from 'framer-motion';
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { checkBetaStatus } from '@/api/functions';
import { LoadingSpinner } from '../ui/LoadingSpinner';
import WelcomeBanner from '../security/WelcomeBanner';

const clientTools = [
    { name: "Traceability Matrix", description: "Map controls to policies, evidence, and status.", href: createPageUrl('TraceabilityMatrix'), icon: Layers, color: "from-blue-500 to-indigo-600" },
    { name: "SPRS Score Calculator", description: "Calculate your NIST 800-171 assessment score.", href: createPageUrl('SPRSScoreCalculator'), icon: Calculator, color: "from-green-500 to-teal-600" },
    { name: "POA&M Generator", description: "Create a Plan of Action & Milestones from gaps.", href: createPageUrl('POAMGenerator'), icon: FileText, color: "from-purple-500 to-violet-600" },
    { name: "Implementation Timeline", description: "Generate a 12-week project plan for compliance.", href: createPageUrl('ImplementationTimeline'), icon: Calendar, color: "from-sky-500 to-blue-600" },
    { name: "Control Prioritization Matrix", description: "Focus on high-impact 'quick wins' for compliance.", href: createPageUrl('ControlPrioritizationMatrix'), icon: Target, color: "from-yellow-500 to-amber-600" },
    { name: "System Diagnostics", description: "Test core SSP and report generation functions.", href: createPageUrl('SystemTests'), icon: Zap, color: "from-red-600 to-orange-500" },
];

export default function ClientDashboardView({ user }) {
    const [betaStatus, setBetaStatus] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const getStatus = async () => {
            try {
                const { data } = await checkBetaStatus();
                setBetaStatus(data);
            } catch (error) {
                console.error("Failed to check beta status:", error);
                setBetaStatus({ canAccessTools: false, error: "Could not verify status." });
            } finally {
                setLoading(false);
            }
        };
        getStatus();
    }, []);

    if (loading) {
        return <LoadingSpinner text="Loading client dashboard..." />;
    }

    if (!betaStatus?.canAccessTools) {
        return (
            <div className="text-center py-20">
                <Shield className="w-16 h-16 mx-auto text-red-500 mb-4" />
                <h1 className="text-3xl font-bold mb-4">Free Trial Has Ended</h1>
                <p className="text-lg text-gray-600 mb-8">The free beta program concluded on December 5th, 2025. Please contact us for commercial access.</p>
                <Button asChild>
                    <Link to={createPageUrl('PartnershipInquiry')}>Contact Sales</Link>
                </Button>
            </div>
        );
    }
    
    return (
        <div className="space-y-8">
            <WelcomeBanner user={user} />
            <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }}>
                <Card className="bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-700 text-white border-0 shadow-xl">
                    <CardHeader>
                        <CardTitle className="text-3xl font-bold flex items-center gap-3">
                            <Award className="w-8 h-8" />
                            Free Trial Active!
                        </CardTitle>
                        <CardDescription className="text-blue-200">
                            You have full access to all CMMC compliance tools.
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="grid md:grid-cols-2 gap-6 text-center">
                            <div className="bg-white/20 p-4 rounded-lg">
                                <div className="text-3xl font-bold text-green-300">{betaStatus.daysRemaining}</div>
                                <div className="text-sm opacity-90">Days Remaining in Trial</div>
                            </div>
                             <div className="bg-white/20 p-4 rounded-lg">
                                <div className="text-lg font-bold">Ends Dec 5, 2025</div>
                                <div className="text-sm opacity-90">Your data will be available for export after trial ends.</div>
                            </div>
                        </div>
                         <Button asChild size="lg" className="w-full mt-6 bg-white text-purple-600 hover:bg-gray-100 font-bold">
                            <Link to={createPageUrl('ClientFAQ')}>
                                Learn What Happens After The Trial <ArrowRight className="w-5 h-5 ml-2" />
                            </Link>
                        </Button>
                    </CardContent>
                </Card>
            </motion.div>

            <div>
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Your CMMC Compliance Toolkit</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {clientTools.map((tool) => (
                         <motion.div key={tool.name} whileHover={{ y: -5 }} className="h-full">
                            <Link to={tool.href} className="block h-full">
                                <Card className="bg-white hover:shadow-xl transition-shadow h-full flex flex-col border">
                                    <CardHeader className="flex-row items-center gap-4">
                                        <div className={`w-12 h-12 rounded-lg flex items-center justify-center bg-gradient-to-br ${tool.color}`}>
                                            <tool.icon className="w-6 h-6 text-white" />
                                        </div>
                                        <CardTitle>{tool.name}</CardTitle>
                                    </CardHeader>
                                    <CardContent className="flex-grow">
                                        <p className="text-sm text-gray-600">{tool.description}</p>
                                    </CardContent>
                                    <div className="p-4 pt-0">
                                         <Button variant="ghost" className="w-full justify-start text-blue-600 p-0 h-auto hover:bg-transparent">
                                            Open Tool <ArrowRight className="w-4 h-4 ml-2"/>
                                        </Button>
                                    </div>
                                </Card>
                            </Link>
                        </motion.div>
                    ))}
                </div>
            </div>
        </div>
    );
}