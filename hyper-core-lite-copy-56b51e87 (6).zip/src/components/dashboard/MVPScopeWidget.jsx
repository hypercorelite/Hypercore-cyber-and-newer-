import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { CheckCircle, Clock, Code, Users, FileText, AlertTriangle, Target, ArrowRight } from 'lucide-react';

const deliverables = [
    {
        item: "110/110 NIST Control Coverage",
        mvpStatus: "CORE MVP",
        mvpDescription: "DB with all controls & assessment procedures.",
        icon: CheckCircle,
        color: "bg-green-100 text-green-800"
    },
    {
        item: "AI-Generated System Security Plan (SSP)",
        mvpStatus: "DEMO",
        mvpDescription: "Basic template generation for demo purposes.",
        icon: FileText,
        color: "bg-blue-100 text-blue-800"
    },
    {
        item: "14 AI-Generated Policy Documents",
        mvpStatus: "DEMO",
        mvpDescription: "5-7 core policy templates generated via AI.",
        icon: FileText,
        color: "bg-blue-100 text-blue-800"
    },
    {
        item: "Structured 90-Day Implementation Plan",
        mvpStatus: "CORE MVP",
        mvpDescription: "Template-based project timeline & task list.",
        icon: Clock,
        color: "bg-green-100 text-green-800"
    },
    {
        item: "C3PAO-Ready Evidence Package",
        mvpStatus: "DEMO",
        mvpDescription: "PDF report export with compliance summary.",
        icon: Target,
        color: "bg-blue-100 text-blue-800"
    },
    {
        item: "Automated 'Dark CUI' Discovery",
        mvpStatus: "POST-MVP",
        mvpDescription: "Concept demo only; real scanning is Phase 2.",
        icon: AlertTriangle,
        color: "bg-yellow-100 text-yellow-800"
    },
    {
        item: "12 Weekly Expert Coaching Sessions",
        mvpStatus: "MANUAL SERVICE",
        mvpDescription: "Service, not software. Delivered manually.",
        icon: Users,
        color: "bg-gray-100 text-gray-800"
    }
];

export default function MVPScopeWidget() {
    return (
        <Card>
            <CardHeader>
                <CardTitle>MVP Scope vs. Full Program</CardTitle>
                <CardDescription>At-a-glance view of what's included in the current 8-week sprint.</CardDescription>
            </CardHeader>
            <CardContent>
                <div className="space-y-4">
                    {deliverables.map((d) => (
                        <div key={d.item} className="flex items-center justify-between p-3 bg-gray-50 rounded-md">
                            <div className="flex items-center gap-3">
                                <d.icon className="w-5 h-5 text-gray-500" />
                                <div>
                                    <p className="font-semibold text-sm">{d.item}</p>
                                    <p className="text-xs text-gray-600">{d.mvpDescription}</p>
                                </div>
                            </div>
                            <Badge className={`${d.color}`}>{d.mvpStatus}</Badge>
                        </div>
                    ))}
                </div>
                 <Button asChild variant="outline" className="w-full mt-6">
                    <Link to={createPageUrl('MVPRealityCheck')}>
                        View Detailed Reality Check <ArrowRight className="w-4 h-4 ml-2" />
                    </Link>
                </Button>
            </CardContent>
        </Card>
    );
}