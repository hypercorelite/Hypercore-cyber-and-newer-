import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { 
    PartyPopper, 
    FileText, 
    Shield, 
    Award, 
    ArrowRight, 
    AlertTriangle, 
    CheckCircle,
    FileSignature,
    Layers,
    Target
} from 'lucide-react';
import { motion } from 'framer-motion';
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

export default function CelebrationMessage({ documentType = 'CMMC Package', onContinueJourney }) {
    const [showConfetti, setShowConfetti] = useState(true);

    useEffect(() => {
        // Hide confetti after animation
        const timer = setTimeout(() => setShowConfetti(false), 3000);
        return () => clearTimeout(timer);
    }, []);

    return (
        <div className="max-w-4xl mx-auto space-y-6">
            {/* Celebration Header */}
            <motion.div
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ duration: 0.6, type: "spring" }}
            >
                <Card className="bg-gradient-to-br from-green-50 via-blue-50 to-purple-50 border-2 border-green-300">
                    <CardHeader className="text-center pb-2">
                        <motion.div
                            animate={{ rotate: showConfetti ? [0, 10, -10, 0] : 0 }}
                            transition={{ duration: 0.5, repeat: showConfetti ? 3 : 0 }}
                        >
                            <PartyPopper className="w-16 h-16 mx-auto text-green-600 mb-4" />
                        </motion.div>
                        <CardTitle className="text-3xl font-bold text-green-800">
                            🎉 Congratulations! 🎉
                        </CardTitle>
                        <p className="text-xl text-green-700 mt-2">
                            Your {documentType} has been generated successfully! 💕💕💕💖🎉🎉🎉💕💖😎
                        </p>
                        <div className="flex justify-center gap-2 mt-4">
                            <Badge className="bg-green-100 text-green-800">Documents Generated</Badge>
                            <Badge className="bg-blue-100 text-blue-800">Audit-Ready</Badge>
                            <Badge className="bg-purple-100 text-purple-800">Customized for You</Badge>
                        </div>
                    </CardHeader>
                </Card>
            </motion.div>

            {/* Important Disclaimer */}
            <Alert className="bg-yellow-50 border-yellow-300">
                <AlertTriangle className="h-5 w-5 text-yellow-600" />
                <AlertTitle className="text-yellow-800 font-bold">Important Legal Disclaimer</AlertTitle>
                <AlertDescription className="text-yellow-700">
                    <strong>This documentation does NOT guarantee you will pass your 3PAO assessment.</strong> These are preparation materials designed to give you the best possible foundation for success. Your actual compliance depends on implementation of controls and operational procedures. We strongly recommend working with qualified cybersecurity professionals and C3PAOs for final assessment preparation.
                </AlertDescription>
            </Alert>

            {/* What You've Accomplished */}
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <CheckCircle className="w-6 h-6 text-green-600" />
                        What You've Accomplished
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="grid md:grid-cols-3 gap-4">
                        <div className="text-center p-4 bg-blue-50 rounded-lg">
                            <FileText className="w-8 h-8 mx-auto text-blue-600 mb-2" />
                            <h4 className="font-medium">Custom Documentation</h4>
                            <p className="text-sm text-gray-600">Tailored to your specific environment and business requirements</p>
                        </div>
                        <div className="text-center p-4 bg-green-50 rounded-lg">
                            <Shield className="w-8 h-8 mx-auto text-green-600 mb-2" />
                            <h4 className="font-medium">CMMC Preparation</h4>
                            <p className="text-sm text-gray-600">Professional-grade SSP, policies, and implementation guidance</p>
                        </div>
                        <div className="text-center p-4 bg-purple-50 rounded-lg">
                            <Award className="w-8 h-8 mx-auto text-purple-600 mb-2" />
                            <h4 className="font-medium">Audit Readiness</h4>
                            <p className="text-sm text-gray-600">Structured documentation that assessors expect to see</p>
                        </div>
                    </div>
                </CardContent>
            </Card>

            {/* Continue Your CMMC Journey */}
            <Card className="bg-gradient-to-r from-blue-50 to-indigo-50">
                <CardHeader>
                    <CardTitle className="text-center text-blue-800">🚀 Continue Your CMMC Journey</CardTitle>
                    <p className="text-center text-blue-700">Take the next steps to maximize your 3PAO assessment success</p>
                </CardHeader>
                <CardContent>
                    <div className="grid md:grid-cols-2 gap-4">
                        <Link to={createPageUrl('TraceabilityMatrix')}>
                            <Card className="hover:shadow-md transition-shadow cursor-pointer border-2 border-blue-200 hover:border-blue-400">
                                <CardContent className="p-4 text-center">
                                    <Layers className="w-10 h-10 mx-auto text-blue-600 mb-2" />
                                    <h4 className="font-medium">Create Traceability Matrix</h4>
                                    <p className="text-sm text-gray-600">Map each NIST control to your policies and evidence</p>
                                    <ArrowRight className="w-4 h-4 mx-auto mt-2 text-blue-600" />
                                </CardContent>
                            </Card>
                        </Link>
                        <Link to={createPageUrl('EvidenceCollectionTracker')}>
                            <Card className="hover:shadow-md transition-shadow cursor-pointer border-2 border-green-200 hover:border-green-400">
                                <CardContent className="p-4 text-center">
                                    <FileText className="w-10 h-10 mx-auto text-green-600 mb-2" />
                                    <h4 className="font-medium">Collect Evidence</h4>
                                    <p className="text-sm text-gray-600">Gather screenshots, logs, and audit artifacts</p>
                                    <ArrowRight className="w-4 h-4 mx-auto mt-2 text-green-600" />
                                </CardContent>
                            </Card>
                        </Link>
                        <Link to={createPageUrl('SPRSScoreCalculator')}>
                            <Card className="hover:shadow-md transition-shadow cursor-pointer border-2 border-purple-200 hover:border-purple-400">
                                <CardContent className="p-4 text-center">
                                    <Target className="w-10 h-10 mx-auto text-purple-600 mb-2" />
                                    <h4 className="font-medium">Calculate SPRS Score</h4>
                                    <p className="text-sm text-gray-600">Self-assessment for contract requirements</p>
                                    <ArrowRight className="w-4 h-4 mx-auto mt-2 text-purple-600" />
                                </CardContent>
                            </Card>
                        </Link>
                        <Link to={createPageUrl('POAMGenerator')}>
                            <Card className="hover:shadow-md transition-shadow cursor-pointer border-2 border-orange-200 hover:border-orange-400">
                                <CardContent className="p-4 text-center">
                                    <AlertTriangle className="w-10 h-10 mx-auto text-orange-600 mb-2" />
                                    <h4 className="font-medium">Generate POA&M</h4>
                                    <p className="text-sm text-gray-600">Document remediation plans for gaps</p>
                                    <ArrowRight className="w-4 h-4 mx-auto mt-2 text-orange-600" />
                                </CardContent>
                            </Card>
                        </Link>
                    </div>

                    {/* SBIR Partnership CTA */}
                    <div className="mt-6 p-4 bg-green-100 rounded-lg border-2 border-green-300">
                        <h4 className="font-bold text-green-800 mb-2">🤝 Help Scale This Solution Across the Defense Industrial Base</h4>
                        <p className="text-green-700 text-sm mb-3">
                            Your success story validates our SBIR grant proposal to deliver this same AI-first CMMC automation to thousands of SMB defense contractors. Help us secure federal funding to scale across the entire DIB supply chain.
                        </p>
                        <Button asChild className="bg-green-600 hover:bg-green-700 text-white">
                            <Link to={createPageUrl('LOIGenerator')}>
                                <FileSignature className="w-4 h-4 mr-2" />
                                Submit SBIR Validation Letter of Intent
                            </Link>
                        </Button>
                    </div>
                </CardContent>
            </Card>

            <div className="text-center">
                <p className="text-sm text-gray-500">
                    🎯 <strong>Remember:</strong> Implementation success depends on your team executing these recommendations. 
                    Consider engaging qualified cybersecurity professionals for implementation assistance.
                </p>
            </div>
        </div>
    );
}