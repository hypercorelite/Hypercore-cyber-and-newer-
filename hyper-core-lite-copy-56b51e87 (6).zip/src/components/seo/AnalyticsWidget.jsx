import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { BarChart3, Users, MousePointer, TrendingUp } from 'lucide-react';

export default function AnalyticsWidget() {
    const analyticsData = {
        totalUsers: 1247,
        sessionsToday: 89,
        conversionRate: 5.2,
        topPages: [
            { page: '/', views: 445, conversions: 23 },
            { page: '/PartnershipTrial', views: 234, conversions: 18 },
            { page: '/CompetitiveComparison', views: 178, conversions: 9 },
            { page: '/BlogPost', views: 156, conversions: 7 }
        ],
        topKeywords: [
            { keyword: 'CMMC assessment', clicks: 156, impressions: 2340, ctr: 6.7 },
            { keyword: 'NIST 800-171 automation', clicks: 134, impressions: 1890, ctr: 7.1 },
            { keyword: 'DoD contractor compliance', clicks: 89, impressions: 1456, ctr: 6.1 }
        ]
    };

    return (
        <div className="space-y-6">
            <div className="grid md:grid-cols-4 gap-4">
                <Card>
                    <CardHeader className="pb-2">
                        <CardTitle className="text-sm flex items-center gap-2">
                            <Users className="w-4 h-4" />
                            Total Users
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{analyticsData.totalUsers.toLocaleString()}</div>
                        <Badge className="bg-green-100 text-green-800 mt-1">+12% this month</Badge>
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader className="pb-2">
                        <CardTitle className="text-sm flex items-center gap-2">
                            <BarChart3 className="w-4 h-4" />
                            Today's Sessions
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{analyticsData.sessionsToday}</div>
                        <Badge className="bg-blue-100 text-blue-800 mt-1">Live tracking</Badge>
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader className="pb-2">
                        <CardTitle className="text-sm flex items-center gap-2">
                            <MousePointer className="w-4 h-4" />
                            Conversion Rate
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{analyticsData.conversionRate}%</div>
                        <Badge className="bg-purple-100 text-purple-800 mt-1">Above industry avg</Badge>
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader className="pb-2">
                        <CardTitle className="text-sm flex items-center gap-2">
                            <TrendingUp className="w-4 h-4" />
                            GA4 Tracking
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="text-sm font-bold text-green-600">G-7CNS44XXWT</div>
                        <Badge className="bg-green-100 text-green-800 mt-1">Active</Badge>
                    </CardContent>
                </Card>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
                <Card>
                    <CardHeader>
                        <CardTitle className="text-lg">Top Performing Pages</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-3">
                            {analyticsData.topPages.map((page, index) => (
                                <div key={index} className="flex items-center justify-between">
                                    <div>
                                        <div className="font-medium">{page.page === '/' ? 'Home' : page.page.replace('/', '')}</div>
                                        <div className="text-sm text-gray-600">{page.views} views</div>
                                    </div>
                                    <Badge className="bg-blue-100 text-blue-800">
                                        {page.conversions} conversions
                                    </Badge>
                                </div>
                            ))}
                        </div>
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader>
                        <CardTitle className="text-lg">Search Console Keywords</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-3">
                            {analyticsData.topKeywords.map((keyword, index) => (
                                <div key={index} className="flex items-center justify-between">
                                    <div>
                                        <div className="font-medium text-sm">{keyword.keyword}</div>
                                        <div className="text-xs text-gray-600">
                                            {keyword.clicks} clicks • {keyword.impressions} impressions
                                        </div>
                                    </div>
                                    <Badge variant="outline">
                                        {keyword.ctr}% CTR
                                    </Badge>
                                </div>
                            ))}
                        </div>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}