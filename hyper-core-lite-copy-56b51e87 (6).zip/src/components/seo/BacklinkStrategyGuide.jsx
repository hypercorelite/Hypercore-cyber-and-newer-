import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link as LinkIcon, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';

const BacklinkStrategyGuide = () => {
    const emailTemplate = `Subject: CMMC Compliance Research & Collaboration

Hi [Name],

I was just reading your article on [Their Article Title] and really appreciated your insights into [Specific Point].

Our team at HyperCore AI recently published a research-based analysis on the CMMC timeline crisis, drawing from CDW and Federal Register data. It proves why the old 18-month manual approach is obsolete.

Here's the link: [Link to your new blog post]

Given your expertise in the defense contracting space, I thought you might find it valuable for your audience. If you agree, a mention or link back would be fantastic.

We're always open to collaborating with leaders like you.

Best,

[Your Name]
HyperCore CMMC Training`;

    return (
        <Card className="h-full">
            <CardHeader>
                <CardTitle className="flex items-center gap-2">
                    <LinkIcon className="w-5 h-5 text-green-600" />
                    Your Backlink Building Plan
                </CardTitle>
                <CardDescription>A 3-step guide to earning your first 5-10 high-quality backlinks.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4 text-sm">
                <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800">1. Identify Your Targets (Goal: 15-20 sites)</h4>
                    <p className="text-green-700 mt-1">Focus on sites where DoD contractors get their news and resources:</p>
                    <ul className="list-disc list-inside mt-2 text-xs">
                        <li>CMMC resource sites (e.g., cmmcaudit.org)</li>
                        <li>Defense industry news (e.g., GovConWire, Defense News)</li>
                        <li>Cybersecurity blogs with a federal focus</li>
                        <li>Partner or vendor websites</li>
                    </ul>
                </div>
                <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800">2. Craft Your Outreach Email</h4>
                    <p className="text-blue-700 mt-1">Use this template. The key is to offer value first (your new blog post) before asking for a link.</p>
                    <pre className="mt-2 text-xs p-2 bg-white rounded whitespace-pre-wrap font-mono">{emailTemplate}</pre>
                </div>
                 <div className="p-3 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800">3. Track Your Outreach</h4>
                    <p className="text-purple-700 mt-1">Use a simple spreadsheet to track who you've contacted, when, and if they've replied. Follow up once after 7 days if you don't hear back.</p>
                    <p className="text-xs mt-2"><strong>Pro Tip:</strong> Guest posting is another great way to get a powerful backlink. Offer to write an article for their site.</p>
                </div>
            </CardContent>
        </Card>
    );
};

export default BacklinkStrategyGuide;