import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { CheckCircle, AlertTriangle, Copy, Eye, Search, Target } from 'lucide-react';
import { toast } from "sonner";

export default function MetadataOptimizer() {
    const [copied, setCopied] = useState('');

    const copyToClipboard = (text, type) => {
        navigator.clipboard.writeText(text);
        setCopied(type);
        toast.success('Copied to clipboard!');
        setTimeout(() => setCopied(''), 2000);
    };

    // Optimized meta data for key pages based on 2025 best practices
    const metaOptimizations = [
        {
            page: 'Home',
            current: { 
                title: 'NIST 800-171 Automation | Automated CMMC Assessment Platform | HyperCore',
                description: 'NIST 800-171 automation platform for DoD contractors. Automated CMMC Level 2 assessment, gap analysis, and compliance documentation.',
                length: 137
            },
            optimized: {
                title: 'AI-First CMMC Level 2 Compliance for Defense Contractors | HyperCore',
                description: 'Achieve CMMC Level 2 compliance fast with AI automation: Automated docs, 3PAO testing guidance, and free trial for DoD primes/subs. Start today.',
                length: 155,
                improvements: ['Front-loaded "AI-First"', 'Added "3PAO testing"', 'Clear CTA "Start today"', 'LSI terms: primes/subs']
            }
        },
        {
            page: 'SuccessPlan', 
            current: {
                title: 'Your 90-Day CMMC Success Plan',
                description: 'A week-by-week automated guide to get you C3PAO-ready. This is your scalable path to compliance.',
                length: 107
            },
            optimized: {
                title: 'AI-Powered 90-Day CMMC Success Plan for Defense Subs | HyperCore',
                description: 'Achieve CMMC Level 2 compliance fast with our AI-first 90-day plan: Automated docs, 3PAO audit prep, and free trial for DoD contractors.',
                length: 152,
                improvements: ['Added "AI-Powered"', 'Specific "Defense Subs"', 'Better CTA', 'Optimal 152 chars']
            }
        },
        {
            page: 'CompetitiveComparison',
            current: {
                title: 'How We\'re Different - HyperCore',
                description: 'Compare CMMC compliance options: AI automation vs consultants vs GRC tools.',
                length: 89
            },
            optimized: {
                title: 'CMMC AI vs Consultants vs GRC Tools: Complete Comparison | HyperCore', 
                description: 'Compare CMMC compliance: AI automation vs $200K consultants vs complex GRC tools. See cost, time, and ROI analysis for DoD contractors.',
                length: 148,
                improvements: ['Specific comparison terms', 'Added cost anchor "$200K"', 'ROI focus', 'DoD entity']
            }
        },
        {
            page: 'CustomerSuccessStories',
            current: {
                title: 'Customer Success Stories',
                description: 'See how HyperCore helps SMB DoD contractors achieve compliance 90% faster.',
                length: 92
            },
            optimized: {
                title: 'CMMC Success Stories: Defense Contractors Save $75K+ | HyperCore',
                description: 'Real DoD contractor wins: 90% faster CMMC compliance, $75K saved vs consultants, 3PAO audit success. See case studies and ROI proof.',
                length: 152,
                improvements: ['Specific savings "$75K+"', '3PAO success proof', 'ROI focus', 'Perfect length']
            }
        }
    ];

    // Open Graph and Twitter optimizations
    const socialOptimizations = [
        {
            page: 'Home',
            openGraph: {
                title: 'Streamline CMMC Compliance with AI Assistance',
                description: 'Prime/subcontractor services for audit-ready docs and production.',
                image: 'https://images.unsplash.com/photo-1551434678-e076c223a692?w=1200&h=630&fit=crop'
            },
            twitter: {
                card: 'summary_large_image',
                title: 'AI-First CMMC Solutions for Defense Contractors',
                description: 'AI-first CMMC solutions: From gap analysis to 3PAO success.',
                image: 'https://images.unsplash.com/photo-1551434678-e076c223a692?w=1200&h=630&fit=crop'
            }
        }
    ];

    return (
        <div className="space-y-6">
            <div className="text-center">
                <h2 className="text-2xl font-bold mb-2">🎯 Meta Data Optimization Hub</h2>
                <p className="text-gray-600">Implement 2025 SEO best practices for CMMC-focused searches</p>
            </div>

            <Alert className="bg-blue-50 border-blue-200">
                <Target className="h-4 w-4 text-blue-700" />
                <AlertTitle className="font-bold text-blue-800">Expected Impact</AlertTitle>
                <AlertDescription className="text-blue-700">
                    <strong>Short-term (1-3 months):</strong> 15-25% CTR uplift from optimized titles/descriptions<br/>
                    <strong>Long-term:</strong> Top-3 rankings for "AI CMMC compliance" and related terms
                </AlertDescription>
            </Alert>

            {metaOptimizations.map((meta, index) => (
                <Card key={index} className="border-l-4 border-l-green-500">
                    <CardHeader>
                        <CardTitle className="flex items-center justify-between">
                            <span>{meta.page} Page</span>
                            <Badge className="bg-green-100 text-green-800">High Priority</Badge>
                        </CardTitle>
                        <CardDescription>Meta optimization for better CMMC search visibility</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        {/* Current vs Optimized */}
                        <div className="grid md:grid-cols-2 gap-4">
                            <div className="p-4 bg-red-50 rounded-lg">
                                <div className="flex items-center gap-2 mb-2">
                                    <AlertTriangle className="w-4 h-4 text-red-600" />
                                    <h4 className="font-semibold text-red-800">Current</h4>
                                </div>
                                <div className="space-y-2">
                                    <p className="text-sm"><strong>Title:</strong> {meta.current.title}</p>
                                    <p className="text-sm"><strong>Description:</strong> {meta.current.description}</p>
                                    <p className="text-xs text-red-600">Length: {meta.current.length} chars (suboptimal)</p>
                                </div>
                            </div>
                            
                            <div className="p-4 bg-green-50 rounded-lg">
                                <div className="flex items-center gap-2 mb-2">
                                    <CheckCircle className="w-4 h-4 text-green-600" />
                                    <h4 className="font-semibold text-green-800">Optimized</h4>
                                </div>
                                <div className="space-y-2">
                                    <div className="flex items-center gap-2">
                                        <p className="text-sm flex-grow"><strong>Title:</strong> {meta.optimized.title}</p>
                                        <Button 
                                            size="sm" 
                                            variant="outline"
                                            onClick={() => copyToClipboard(meta.optimized.title, `${meta.page}-title`)}
                                        >
                                            <Copy className="w-3 h-3" />
                                        </Button>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        <p className="text-sm flex-grow"><strong>Description:</strong> {meta.optimized.description}</p>
                                        <Button 
                                            size="sm" 
                                            variant="outline"
                                            onClick={() => copyToClipboard(meta.optimized.description, `${meta.page}-desc`)}
                                        >
                                            <Copy className="w-3 h-3" />
                                        </Button>
                                    </div>
                                    <p className="text-xs text-green-600">Length: {meta.optimized.length} chars (optimal)</p>
                                </div>
                            </div>
                        </div>

                        {/* Improvements */}
                        <div className="p-3 bg-blue-50 rounded-lg">
                            <h5 className="font-semibold text-blue-800 mb-2">🎯 Key Improvements:</h5>
                            <ul className="text-sm text-blue-700 space-y-1">
                                {meta.optimized.improvements.map((improvement, i) => (
                                    <li key={i}>• {improvement}</li>
                                ))}
                            </ul>
                        </div>
                    </CardContent>
                </Card>
            ))}

            {/* Social Media Meta */}
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Eye className="text-purple-600" />
                        Social Media Meta Tags (Open Graph + Twitter)
                    </CardTitle>
                    <CardDescription>Optimize for LinkedIn shares and defense contractor networks</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="space-y-4">
                        {socialOptimizations.map((social, index) => (
                            <div key={index} className="p-4 border rounded-lg">
                                <h4 className="font-semibold mb-3">{social.page} Page Social Tags</h4>
                                
                                <div className="grid md:grid-cols-2 gap-4">
                                    <div className="space-y-2">
                                        <h5 className="text-sm font-medium text-blue-800">Open Graph (LinkedIn/Facebook)</h5>
                                        <div className="text-xs space-y-1">
                                            <p><code>og:title</code>: {social.openGraph.title}</p>
                                            <p><code>og:description</code>: {social.openGraph.description}</p>
                                            <p><code>og:image</code>: Professional CMMC dashboard (1200x630)</p>
                                        </div>
                                    </div>
                                    
                                    <div className="space-y-2">
                                        <h5 className="text-sm font-medium text-blue-800">Twitter Cards</h5>
                                        <div className="text-xs space-y-1">
                                            <p><code>twitter:card</code>: summary_large_image</p>
                                            <p><code>twitter:title</code>: {social.twitter.title}</p>
                                            <p><code>twitter:description</code>: {social.twitter.description}</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>

            {/* Implementation Guide */}
            <Alert className="bg-yellow-50 border-yellow-200">
                <Search className="h-4 w-4 text-yellow-700" />
                <AlertTitle className="font-bold text-yellow-800">🚀 Next Steps</AlertTitle>
                <AlertDescription className="text-yellow-700">
                    <ol className="list-decimal list-inside space-y-1 mt-2">
                        <li>Copy optimized titles/descriptions above</li>
                        <li>Update each page's useEffect meta tags</li>
                        <li>Test with Google's Rich Results Tool</li>
                        <li>Monitor CTR improvements in Google Search Console (2-4 weeks)</li>
                        <li>A/B test variations for best performance</li>
                    </ol>
                </AlertDescription>
            </Alert>
        </div>
    );
}