import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ExternalLink, CheckCircle, HelpCircle } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const SitemapSubmitter = () => {
    return (
        <Card>
            <CardHeader>
                <CardTitle className="flex items-center gap-2">
                    <CheckCircle className="w-5 h-5 text-green-600" />
                    Task 1: Generate & Submit Sitemap
                </CardTitle>
                <CardDescription>
                    Get your `sitemap.xml` file and instructions for Google Search Console.
                </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
                <Alert>
                    <HelpCircle className="h-4 w-4" />
                    <AlertTitle className="font-bold">Sitemap Generation Page</AlertTitle>
                    <AlertDescription>
                        Your sitemap must be downloaded and manually uploaded to your main website's hosting. Visit the Sitemap Generator page to get the file and full instructions.
                    </AlertDescription>
                </Alert>
                <Button asChild className="w-full">
                    <Link to={createPageUrl('Sitemap')}>
                        Go to Sitemap Generator
                        <ExternalLink className="w-4 h-4 ml-2" />
                    </Link>
                </Button>
            </CardContent>
        </Card>
    );
};

export default SitemapSubmitter;