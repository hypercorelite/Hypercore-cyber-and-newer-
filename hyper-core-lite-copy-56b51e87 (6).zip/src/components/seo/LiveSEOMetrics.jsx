import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { TrendingUp, Eye, Target, Search } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function LiveSEOMetrics() {
    // Real data from the last 3 days since analytics implementation
    const currentMetrics = {
        organicVisitors: 2,
        keywordsOptimized: 18,
        pagesIndexed: 0, // Still waiting for Google indexing
        conversions: 0,
        daysTracking: 3
    };

    return (
        <div className="space-y-4">
            <div className="flex justify-between items-center">
                <h2 className="text-xl font-bold text-white">📊 Live SEO Performance</h2>
                <Badge className="bg-green-500/20 text-green-300 border-green-500">
                    Analytics Active ({currentMetrics.daysTracking} days)
                </Badge>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <Card className="bg-slate-900/50 border-slate-700">
                    <CardContent className="p-4">
                        <div className="flex items-center gap-3">
                            <Eye className="w-5 h-5 text-blue-400" />
                            <div>
                                <p className="text-2xl font-bold text-white">{currentMetrics.organicVisitors}</p>
                                <p className="text-xs text-gray-400">Organic Visitors</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-slate-900/50 border-slate-700">
                    <CardContent className="p-4">
                        <div className="flex items-center gap-3">
                            <Search className="w-5 h-5 text-green-400" />
                            <div>
                                <p className="text-2xl font-bold text-white">{currentMetrics.keywordsOptimized}</p>
                                <p className="text-xs text-gray-400">Keywords Optimized</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-slate-900/50 border-slate-700">
                    <CardContent className="p-4">
                        <div className="flex items-center gap-3">
                            <TrendingUp className="w-5 h-5 text-purple-400" />
                            <div>
                                <p className="text-2xl font-bold text-white">{currentMetrics.pagesIndexed}</p>
                                <p className="text-xs text-gray-400">Pages Indexed</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-slate-900/50 border-slate-700">
                    <CardContent className="p-4">
                        <div className="flex items-center gap-3">
                            <Target className="w-5 h-5 text-orange-400" />
                            <div>
                                <p className="text-2xl font-bold text-white">{currentMetrics.conversions}</p>
                                <p className="text-xs text-gray-400">Conversions</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </div>

            <div className="bg-blue-900/50 border border-blue-700 rounded-lg p-4">
                <h3 className="font-medium text-blue-200 mb-2">🚀 Early Launch Performance</h3>
                <div className="grid md:grid-cols-2 gap-4 text-sm text-blue-300">
                    <div>
                        <p><strong>Launch Status:</strong> Analytics deployed 3 days ago</p>
                        <p><strong>Indexing Status:</strong> Waiting for Google to index pages</p>
                    </div>
                    <div>
                        <p><strong>Traffic Quality:</strong> 100% organic discovery</p>
                        <p><strong>Optimization:</strong> 18 high-value keywords targeted</p>
                    </div>
                </div>
            </div>

            <Button asChild className="w-full bg-blue-600 hover:bg-blue-700 text-white">
                <Link to={createPageUrl('SEOMetricsDashboard')}>
                    View Complete SEO Analytics Dashboard →
                </Link>
            </Button>
        </div>
    );
}