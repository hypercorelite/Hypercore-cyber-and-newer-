import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Terminal, GitBranch, FileText, CheckCircle, AlertCircle, Clock } from 'lucide-react';

const workflowSteps = [
    {
        id: 'initialize',
        title: 'Initialize CMMC Repository',
        status: 'completed',
        command: 'git clone https://github.com/company/cmmc-compliance.git',
        description: 'Set up your Git repository with CMMC structure'
    },
    {
        id: 'branch',
        title: 'Create Control Branch',
        status: 'in-progress', 
        command: 'git checkout -b feature/ac-3-1-3-cui-flow',
        description: 'Create branch for AC.L2-3.1.3 implementation'
    },
    {
        id: 'implement',
        title: 'Document Implementation',
        status: 'pending',
        command: 'vim controls/AC/AC.L2-3.1.3/implementation.md',
        description: 'Document your technical implementation'
    },
    {
        id: 'evidence',
        title: 'Collect Evidence',
        status: 'pending', 
        command: './scripts/evidence-collectors/collect-firewall-logs.sh',
        description: 'Run automated evidence collection'
    },
    {
        id: 'validate',
        title: 'Validate Control',
        status: 'pending',
        command: './scripts/compliance-checks/validate-control.sh AC.L2-3.1.3',
        description: 'Validate control implementation'
    },
    {
        id: 'review',
        title: 'Create Pull Request',
        status: 'pending',
        command: 'gh pr create --title "Implement AC.L2-3.1.3 CUI Flow Controls"',
        description: 'Submit for expert review'
    }
];

export default function GitWorkflowDemo() {
    const [currentStep, setCurrentStep] = useState(0);

    const getStatusIcon = (status) => {
        switch (status) {
            case 'completed':
                return <CheckCircle className="w-5 h-5 text-green-600" />;
            case 'in-progress':
                return <Clock className="w-5 h-5 text-blue-600 animate-pulse" />;
            case 'pending':
                return <AlertCircle className="w-5 h-5 text-gray-400" />;
            default:
                return <AlertCircle className="w-5 h-5 text-gray-400" />;
        }
    };

    const getStatusColor = (status) => {
        switch (status) {
            case 'completed':
                return 'bg-green-100 text-green-800 border-green-200';
            case 'in-progress':
                return 'bg-blue-100 text-blue-800 border-blue-200';
            case 'pending':
                return 'bg-gray-100 text-gray-600 border-gray-200';
            default:
                return 'bg-gray-100 text-gray-600 border-gray-200';
        }
    };

    return (
        <Card>
            <CardHeader>
                <CardTitle className="flex items-center gap-2">
                    <GitBranch className="w-5 h-5" />
                    Interactive CMMC Git Workflow
                </CardTitle>
            </CardHeader>
            <CardContent>
                <div className="space-y-4">
                    {workflowSteps.map((step, index) => (
                        <div
                            key={step.id}
                            className={`border rounded-lg p-4 transition-all ${
                                index === currentStep ? 'border-blue-300 bg-blue-50' : 'border-gray-200'
                            }`}
                        >
                            <div className="flex items-start justify-between">
                                <div className="flex items-start gap-3">
                                    {getStatusIcon(step.status)}
                                    <div>
                                        <h3 className="font-medium">{step.title}</h3>
                                        <p className="text-sm text-gray-600 mb-2">{step.description}</p>
                                        <div className="bg-gray-900 text-white p-2 rounded text-xs font-mono">
                                            $ {step.command}
                                        </div>
                                    </div>
                                </div>
                                <Badge className={`text-xs ${getStatusColor(step.status)}`}>
                                    {step.status.replace('-', ' ')}
                                </Badge>
                            </div>
                        </div>
                    ))}
                </div>
                
                <div className="mt-6 flex justify-between">
                    <Button
                        variant="outline"
                        onClick={() => setCurrentStep(Math.max(0, currentStep - 1))}
                        disabled={currentStep === 0}
                    >
                        Previous Step
                    </Button>
                    <Button
                        onClick={() => setCurrentStep(Math.min(workflowSteps.length - 1, currentStep + 1))}
                        disabled={currentStep === workflowSteps.length - 1}
                    >
                        Next Step
                    </Button>
                </div>
            </CardContent>
        </Card>
    );
}