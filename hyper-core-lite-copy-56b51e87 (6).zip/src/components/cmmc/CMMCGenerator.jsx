
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Download, FileText, Shield, CheckCircle, Loader2, Bot, Eye } from 'lucide-react';
import { toast } from "sonner";
import { jsPDF } from 'jspdf';
import 'jspdf-autotable';
import { generateAdvancedSSP } from '@/api/functions';
import { generateAdvancedPolicies } from '@/api/functions';
import { generateCMMCReport } from '@/api/functions';

// Client-side PDF generation logic
const generateSspPdfFromData = (data) => {
    const doc = new jsPDF();
    const { system, sections, controls } = data;
    doc.setFontSize(22); doc.text(data.documentType || 'System Security Plan', 105, 20, { align: 'center' });
    doc.setFontSize(12); doc.text(`Organization: ${system.organization}`, 20, 40);
    doc.text(`System: ${system.name}`, 20, 48); doc.text(`Generated: ${system.date}`, 20, 56);
    let yPos = 80;
    sections.forEach(section => {
        if (yPos > 250) { doc.addPage(); yPos = 20; }
        doc.setFontSize(16); doc.text(section.title, 14, yPos); yPos += 8;
        doc.setFontSize(10); const lines = doc.splitTextToSize(section.content, 180);
        doc.text(lines, 14, yPos); yPos += lines.length * 5 + 10;
    });
    const tableData = controls.map(c => [c.id, c.domain, c.implementation, c.status]);
    doc.autoTable({ startY: yPos, head: [['Control ID', 'Domain', 'Implementation', 'Status']], body: tableData, theme: 'grid' });
    return doc.output('datauristring');
};

const CMMCGenerator = ({ clientDetails }) => {
    const [isLoading, setIsLoading] = useState(false);
    const [generationResult, setGenerationResult] = useState(null);
    const [loadingMessage, setLoadingMessage] = useState('');

    const defaultClient = {
        companyName: clientDetails?.companyName || 'Defense Solutions Inc.',
        systemName: clientDetails?.systemName || 'Integrated Defense Network',
        systemDescription: clientDetails?.systemDescription || 'Mission-critical network supporting defense contract operations.',
        systemType: clientDetails?.systemType || 'hybrid',
    };
    
    const callGenerator = async (generatorFunction, params, message, resultType = 'ssp') => {
        setIsLoading(true);
        setGenerationResult(null);
        setLoadingMessage(message);
        try {
            const { data } = await generatorFunction(params);
            if (data) {
                let pdfUri, fileName;
                if (resultType === 'ssp' && data.success) {
                    pdfUri = generateSspPdfFromData(data.sspData);
                    fileName = `SSP_${data.sspData.system.organization.replace(/\s+/g, '_')}.pdf`;
                } else if (resultType !== 'ssp' && data.pdfBase64) {
                    const byteCharacters = atob(data.pdfBase64);
                    const byteNumbers = new Array(byteCharacters.length);
                    for (let i = 0; i < byteCharacters.length; i++) {
                        byteNumbers[i] = byteCharacters.charCodeAt(i);
                    }
                    const byteArray = new Uint8Array(byteNumbers);
                    const blob = new Blob([byteArray], {type: 'application/pdf'});
                    pdfUri = URL.createObjectURL(blob);
                    fileName = `${message.split(' ')[1]}_${defaultClient.companyName.replace(/\s+/g, '_')}.pdf`
                } else {
                     throw new Error(data.details || 'Document generation failed.');
                }
                
                setGenerationResult({ pdfUri, fileName });
                toast.success('Document generated successfully!');
            } else {
                throw new Error('No data received from generation function.');
            }
        } catch (error) {
            console.error(`${message} error:`, error);
            toast.error(error.message);
        } finally {
            setIsLoading(false);
        }
    };

    const generateSSP = () => callGenerator(generateAdvancedSSP, { systemInfo: defaultClient }, 'Generating Professional SSP Data...', 'ssp');
    const generatePolicies = () => callGenerator(generateAdvancedPolicies, { clientInfo: defaultClient }, 'Generating Core Policies...', 'policies');
    const generateReport = () => callGenerator(generateCMMCReport, { clientInfo: defaultClient }, 'Generating Readiness Report...', 'report');

    return (
        <Card className="shadow-lg">
            <CardHeader>
                <CardTitle className="flex items-center gap-2 text-xl">
                    <Bot className="w-6 h-6 text-blue-600" />
                    CMMC Document Generation Engine
                </CardTitle>
                <CardDescription>
                    Select a document to have our AI generate it. The resulting PDF can be previewed and downloaded.
                </CardDescription>
            </CardHeader>
            <CardContent>
                <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-4 p-4 border rounded-lg">
                        <h3 className="font-semibold">Core Compliance Documents</h3>
                        <Button onClick={generateSSP} className="w-full justify-start gap-2" variant="outline">
                            <Shield className="w-4 h-4" /> System Security Plan (SSP)
                        </Button>
                        <Button onClick={generatePolicies} className="w-full justify-start gap-2" variant="outline">
                            <FileText className="w-4 h-4" /> Core Policies Document
                        </Button>
                        <Button onClick={generateReport} className="w-full justify-start gap-2" variant="outline">
                            <CheckCircle className="w-4 h-4" /> CMMC Readiness Report
                        </Button>
                    </div>
                    
                    <div className="space-y-4">
                        {isLoading && (
                            <Card className="flex flex-col items-center justify-center p-8 text-center h-full">
                                <Loader2 className="w-12 h-12 animate-spin text-blue-600 mb-4" />
                                <p className="font-semibold text-gray-800">{loadingMessage}</p>
                            </Card>
                        )}
                        {generationResult && (
                             <Card className="h-full">
                                <CardHeader>
                                    <CardTitle className="flex items-center justify-between">
                                        <div className="flex items-center gap-2"><CheckCircle className="w-6 h-6 text-green-600" />Generation Complete</div>
                                        <Button asChild size="sm">
                                            <a href={generationResult.pdfUri} download={generationResult.fileName}>
                                                <Download className="w-4 h-4 mr-2" /> Download
                                            </a>
                                        </Button>
                                    </CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <iframe src={generationResult.pdfUri} className="w-full h-96 rounded-md border" title="PDF Preview"></iframe>
                                </CardContent>
                            </Card>
                        )}
                    </div>
                </div>
            </CardContent>
        </Card>
    );
};

export default CMMCGenerator;
