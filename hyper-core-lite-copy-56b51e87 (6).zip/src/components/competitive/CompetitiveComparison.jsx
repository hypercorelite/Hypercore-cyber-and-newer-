import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, X, Star, DollarSign, Clock, Users, Zap } from 'lucide-react';

const competitorData = [
    {
        name: "HyperCore CMMC Preparation",
        type: "our_service",
        tagline: "Expert-Guided Preparation Service",
        price: "$7,500",
        pricing_model: "Fixed fee (50% down, 50% on completion)",
        timeline: "90 days guaranteed",
        effort_required: "2-4 hours/week",
        support_model: "Dedicated expert guidance",
        deliverables: "Complete evidence package + training",
        advantages: ["Fixed timeline", "Guaranteed deliverables", "Expert guidance", "Minimal time investment"],
        disadvantages: ["Higher upfront cost", "Less control over process"]
    },
    {
        name: "GRC Platforms (Secureframe, Vanta)",
        type: "platform",
        tagline: "Self-Service Compliance Platform",
        price: "$2,000-5,000/month",
        pricing_model: "Monthly subscription",
        timeline: "12-18 months (self-paced)",
        effort_required: "20+ hours/week",
        support_model: "Documentation + chat support",
        deliverables: "Platform access + templates",
        advantages: ["More control", "Ongoing platform access"],
        disadvantages: ["High monthly costs", "Steep learning curve", "No implementation guarantee"]
    },
    {
        name: "Traditional Consultants (RPOs)",
        type: "consulting",
        tagline: "Hourly Consulting Services",
        price: "$300-500/hour",
        pricing_model: "Hourly billing (200-500 hours typical)",
        timeline: "6-24 months (depends on availability)",
        effort_required: "10-15 hours/week managing consultants",
        support_model: "Direct consultant access",
        deliverables: "Custom consulting deliverables",
        advantages: ["Highly customized", "Direct expert access"],
        disadvantages: ["Unpredictable costs", "Timeline uncertainty", "Heavy management overhead"]
    },
    {
        name: "Managed Service Providers",
        type: "managed",
        tagline: "Full Managed Compliance Service",
        price: "$50,000-200,000/year",
        pricing_model: "Annual contracts",
        timeline: "3-6 months + ongoing",
        effort_required: "5-10 hours/week coordination",
        support_model: "Dedicated team",
        deliverables: "Managed infrastructure + compliance",
        advantages: ["Hands-off approach", "Ongoing management"],
        disadvantages: ["Very expensive", "Vendor lock-in", "Limited flexibility"]
    }
];

const CompetitorCard = ({ competitor, isHighlighted = false }) => {
    const getTypeColor = (type) => {
        const colors = {
            our_service: "bg-green-100 text-green-800 border-green-200",
            platform: "bg-blue-100 text-blue-800 border-blue-200",
            consulting: "bg-yellow-100 text-yellow-800 border-yellow-200",
            managed: "bg-purple-100 text-purple-800 border-purple-200"
        };
        return colors[type] || "bg-gray-100 text-gray-800";
    };

    return (
        <Card className={`${isHighlighted ? 'ring-2 ring-green-500 shadow-lg' : ''} h-full`}>
            <CardHeader className="pb-4">
                <div className="flex items-center justify-between mb-2">
                    <Badge className={getTypeColor(competitor.type)}>
                        {competitor.type.replace('_', ' ').toUpperCase()}
                    </Badge>
                    {isHighlighted && <Star className="w-5 h-5 text-yellow-500 fill-current" />}
                </div>
                <CardTitle className="text-lg">{competitor.name}</CardTitle>
                <p className="text-sm text-gray-600">{competitor.tagline}</p>
            </CardHeader>
            <CardContent className="space-y-4">
                <div className="space-y-3">
                    <div className="flex items-center gap-2">
                        <DollarSign className="w-4 h-4 text-green-600" />
                        <div>
                            <div className="font-semibold text-lg">{competitor.price}</div>
                            <div className="text-xs text-gray-600">{competitor.pricing_model}</div>
                        </div>
                    </div>
                    
                    <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4 text-blue-600" />
                        <div>
                            <div className="font-medium">{competitor.timeline}</div>
                            <div className="text-xs text-gray-600">Time to completion</div>
                        </div>
                    </div>
                    
                    <div className="flex items-center gap-2">
                        <Users className="w-4 h-4 text-purple-600" />
                        <div>
                            <div className="font-medium">{competitor.effort_required}</div>
                            <div className="text-xs text-gray-600">Your time investment</div>
                        </div>
                    </div>
                </div>

                <div className="border-t pt-3">
                    <h4 className="font-medium text-green-700 mb-2">✓ Advantages</h4>
                    <ul className="text-xs space-y-1">
                        {competitor.advantages.map((advantage, index) => (
                            <li key={index} className="flex items-center gap-2">
                                <CheckCircle className="w-3 h-3 text-green-500" />
                                {advantage}
                            </li>
                        ))}
                    </ul>
                </div>

                <div className="border-t pt-3">
                    <h4 className="font-medium text-red-700 mb-2">✗ Limitations</h4>
                    <ul className="text-xs space-y-1">
                        {competitor.disadvantages.map((disadvantage, index) => (
                            <li key={index} className="flex items-center gap-2">
                                <X className="w-3 h-3 text-red-500" />
                                {disadvantage}
                            </li>
                        ))}
                    </ul>
                </div>
            </CardContent>
        </Card>
    );
};

export default function CompetitiveComparison() {
    return (
        <div className="space-y-6">
            <div className="text-center">
                <h2 className="text-2xl font-bold text-gray-900 mb-4">
                    How We Compare to Other CMMC Preparation Options
                </h2>
                <p className="text-gray-600 max-w-3xl mx-auto">
                    The CMMC market offers several approaches. Here's an honest comparison of the trade-offs 
                    between our expert-guided service and other popular options.
                </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {competitorData.map((competitor, index) => (
                    <CompetitorCard
                        key={competitor.name}
                        competitor={competitor}
                        isHighlighted={competitor.type === 'our_service'}
                    />
                ))}
            </div>

            <Card className="bg-green-50 border-green-200">
                <CardContent className="p-6">
                    <h3 className="font-bold text-green-800 mb-3 flex items-center gap-2">
                        <Zap className="w-5 h-5" />
                        Why Our Approach Works Better for SMBs
                    </h3>
                    <div className="grid md:grid-cols-2 gap-4 text-sm">
                        <div>
                            <h4 className="font-semibold text-green-700 mb-2">Predictable Investment</h4>
                            <p className="text-green-800">
                                $7,500 total cost vs. $24,000-60,000/year for platforms or $60,000-250,000 for consulting.
                            </p>
                        </div>
                        <div>
                            <h4 className="font-semibold text-green-700 mb-2">Guaranteed Timeline</h4>
                            <p className="text-green-800">
                                90 days to assessment readiness vs. 12-24 months of uncertain progress.
                            </p>
                        </div>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}