import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Clock, DollarSign, Bot, Users, Building } from 'lucide-react';

export default function ValuePropositionCard({ 
    toolName, 
    aiTime, 
    aiCost, 
    saasTime, 
    saasCost, 
    consultantTime, 
    consultantCost,
    aiAdvantage 
}) {
    return (
        <Card className="bg-gradient-to-r from-blue-50 to-green-50 border-2 border-blue-200">
            <CardHeader>
                <CardTitle className="text-center">Why AI Outperforms Traditional Solutions</CardTitle>
            </CardHeader>
            <CardContent>
                <div className="grid md:grid-cols-3 gap-6 mb-6">
                    {/* AI Solution */}
                    <div className="text-center p-4 bg-green-100 rounded-lg border-2 border-green-300">
                        <Bot className="w-8 h-8 text-green-600 mx-auto mb-2" />
                        <h4 className="font-bold text-green-800">AI Solution</h4>
                        <div className="mt-3 space-y-2">
                            <div className="flex items-center justify-center gap-2">
                                <Clock className="w-4 h-4 text-green-600" />
                                <span className="font-semibold">{aiTime}</span>
                            </div>
                            <div className="flex items-center justify-center gap-2">
                                <DollarSign className="w-4 h-4 text-green-600" />
                                <span className="font-semibold">${aiCost.toLocaleString()}</span>
                            </div>
                        </div>
                    </div>

                    {/* SaaS Tools */}
                    <div className="text-center p-4 bg-yellow-100 rounded-lg border border-yellow-300">
                        <Building className="w-8 h-8 text-yellow-600 mx-auto mb-2" />
                        <h4 className="font-bold text-yellow-800">Traditional SaaS</h4>
                        <div className="mt-3 space-y-2">
                            <div className="flex items-center justify-center gap-2">
                                <Clock className="w-4 h-4 text-yellow-600" />
                                <span>{saasTime}</span>
                            </div>
                            <div className="flex items-center justify-center gap-2">
                                <DollarSign className="w-4 h-4 text-yellow-600" />
                                <span>${saasCost.toLocaleString()}</span>
                            </div>
                        </div>
                    </div>

                    {/* Consultants */}
                    <div className="text-center p-4 bg-red-100 rounded-lg border border-red-300">
                        <Users className="w-8 h-8 text-red-600 mx-auto mb-2" />
                        <h4 className="font-bold text-red-800">Consultants</h4>
                        <div className="mt-3 space-y-2">
                            <div className="flex items-center justify-center gap-2">
                                <Clock className="w-4 h-4 text-red-600" />
                                <span>{consultantTime}</span>
                            </div>
                            <div className="flex items-center justify-center gap-2">
                                <DollarSign className="w-4 h-4 text-red-600" />
                                <span>${consultantCost.toLocaleString()}+</span>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="bg-blue-50 p-4 rounded-lg border-l-4 border-blue-500">
                    <p className="text-blue-800 font-medium">
                        <strong>AI Advantage:</strong> {aiAdvantage}
                    </p>
                </div>
            </CardContent>
        </Card>
    );
}