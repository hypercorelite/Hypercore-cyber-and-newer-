import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, Zap } from 'lucide-react';

const highlights = [
    { text: "Automated SSP & Policy Generation in under 2 hours, eliminating a 6-month manual process.", keywords: "automated ssp, cmmc policy generation" },
    { text: "AI-Powered Gap Analysis of all 110 NIST controls, replacing the need for $50K+ consultant assessments.", keywords: "ai cmmc assessment, nist gap analysis" },
    { text: "Defensible SPRS Scoring, providing an accurate, verifiable score for DoD submission.", keywords: "sprs score automation, dod compliance" },
    { text: "A 90-Day Guided Implementation Plan to systematically close all identified compliance gaps.", keywords: "cmmc implementation plan, 90-day compliance" },
];

export default function SEONarrativeHighlight() {
    return (
        <Card className="bg-gradient-to-br from-blue-50 to-green-50 border-2 border-blue-200 shadow-lg">
            <CardHeader>
                <Badge className="bg-blue-100 text-blue-800 mb-3 text-base">
                    <Zap className="w-4 h-4 mr-2" /> Platform Capabilities
                </Badge>
                <CardTitle className="text-2xl font-bold text-gray-900">
                    Why This Is a Game-Changer for DoD Contractors
                </CardTitle>
                <CardDescription className="text-gray-600">
                    Our platform is not another complex GRC tool. It's an AI-first engine designed to solve the most expensive and time-consuming CMMC compliance challenges that prevent SMBs from competing for DoD contracts.
                </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
                {highlights.map((item, index) => (
                    <div key={index} className="flex items-start gap-3 p-3 bg-white rounded-lg shadow-sm">
                        <CheckCircle className="w-5 h-5 text-green-600 mt-1 flex-shrink-0" />
                        <div>
                            <p className="font-medium text-gray-800">{item.text}</p>
                            <p className="text-xs text-blue-600 font-mono mt-1">Target Keywords: {item.keywords}</p>
                        </div>
                    </div>
                ))}
            </CardContent>
        </Card>
    );
}