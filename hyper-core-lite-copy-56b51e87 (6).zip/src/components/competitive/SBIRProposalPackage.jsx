import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { FileText, Download, Target, Zap, DollarSign } from "lucide-react";

const SBIRExecutiveSummary = () => (
    <div className="prose prose-sm max-w-none">
        <h2 className="text-xl font-bold mb-4">SBIR Phase I Executive Summary: AI-Powered CMMC Compliance Automation</h2>
        
        <div className="bg-blue-50 p-4 rounded-lg mb-6">
            <h3 className="font-semibold text-blue-800 mb-2">Technical Innovation Summary</h3>
            <p className="text-sm text-blue-700">
                HyperCore Cyber proposes developing an AI-first cybersecurity compliance platform that autonomously generates 
                NIST SP 800-171 System Security Plans (SSPs) and compliance documentation for Defense Industrial Base (DIB) 
                small and medium-sized businesses (SMBs). Leveraging fine-tuned Large Language Models (LLMs), natural language 
                processing (NLP), and automated control mapping algorithms, this innovation addresses the critical gap between 
                CMMC 2.0 requirements and SMB implementation capabilities.
            </p>
        </div>

        <h3 className="font-semibold mb-3">Problem Statement & Federal Alignment</h3>
        <p className="mb-4">
            The Department of Defense's CMMC 2.0 mandate (DFARS 252.204-7021) requires approximately 300,000 DIB contractors 
            to achieve Level 2 compliance by 2025-2028, with 90% being resource-constrained SMBs. Current implementation costs 
            ($50,000-$200,000 per SMB) and timelines (12-18 months) threaten supply chain resilience, with projected 40% 
            dropout rates jeopardizing critical defense programs. This directly impacts AFWERX's cyber resilience objectives 
            and broader DoD supply chain security.
        </p>

        <h3 className="font-semibold mb-3">Technical Approach & Innovation</h3>
        <p className="mb-4">Our Phase I research will develop and validate AI algorithms capable of:</p>
        <ul className="list-disc pl-6 mb-4 space-y-1">
            <li><strong>Automated SSP Generation:</strong> NLP-driven analysis of organizational data to produce NIST 800-18 compliant documentation</li>
            <li><strong>Intelligent Control Mapping:</strong> Machine learning algorithms for real-time mapping of existing security controls to 110 NIST SP 800-171 requirements</li>
            <li><strong>Predictive Gap Analysis:</strong> AI-powered identification and remediation planning for compliance deficiencies</li>
            <li><strong>3PAO Simulation:</strong> Virtual assessment environments training SMBs for third-party audits</li>
        </ul>

        <h3 className="font-semibold mb-3">Quantifiable Objectives & Success Metrics</h3>
        <div className="bg-green-50 p-4 rounded-lg mb-4">
            <div className="grid md:grid-cols-2 gap-4 text-sm">
                <div>
                    <h4 className="font-semibold text-green-800">Technical Performance</h4>
                    <ul className="text-green-700">
                        <li>• 90% AI accuracy in control mapping</li>
                        <li>• Under 320ms average API response time</li>
                        <li>• 80% reduction in documentation effort</li>
                        <li>• 95% user satisfaction rating</li>
                    </ul>
                </div>
                <div>
                    <h4 className="font-semibold text-green-800">Market Validation</h4>
                    <ul className="text-green-700">
                        <li>• 10+ SMB pilot implementations</li>
                        <li>• 5+ Letters of Intent from contractors</li>
                        <li>• $5,000 target cost per SMB (90% reduction)</li>
                        <li>• 90-day implementation timeline</li>
                    </ul>
                </div>
            </div>
        </div>

        <h3 className="font-semibold mb-3">Commercial Potential & Phase II Transition</h3>
        <p className="mb-4">
            Total Addressable Market: $1+ billion annually serving 31,500 SMB contractors. Phase I validation enables Phase II 
            productization with dual-use applications across regulated industries (HIPAA, FERPA, SOX). Projected revenue: 
            $3.1M (Year 1), $15.8M (Year 3) through freemium SaaS model disrupting traditional $5,000-$15,000 GRC platforms.
        </p>

        <div className="bg-yellow-50 p-4 rounded-lg">
            <h4 className="font-semibold text-yellow-800 mb-2">Federal Impact Statement</h4>
            <p className="text-sm text-yellow-700">
                This innovation directly supports DoD's cyber resilience strategy by preserving SMB participation in defense 
                contracts, maintaining supply chain diversity, and accelerating CMMC compliance across the industrial base. 
                Alignment with AFWERX priorities ensures dual-use transition potential and sustainable commercialization.
            </p>
        </div>
    </div>
);

export default function SBIRProposalPackage() {
    return (
        <div className="space-y-8">
            <div className="text-center mb-8">
                <Badge className="mb-4 bg-red-100 text-red-800">SBIR PHASE I PACKAGE</Badge>
                <h1 className="text-3xl font-bold mb-4">SBIR-Optimized Proposal Materials</h1>
                <p className="text-gray-600">Technical proposal content optimized for federal grant evaluation</p>
            </div>

            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Target className="w-5 h-5 text-blue-600" />
                        Executive Summary (SBIR Format)
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <SBIRExecutiveSummary />
                    <div className="mt-4 flex gap-2">
                        <Button size="sm" variant="outline">
                            <FileText className="w-4 h-4 mr-2" />
                            Export to Word
                        </Button>
                        <Button size="sm" variant="outline">
                            <Download className="w-4 h-4 mr-2" />
                            Download PDF
                        </Button>
                    </div>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>Alternative SBIR Executive Summary (Version 2)</CardTitle>
                    <p className="text-sm text-gray-600 mt-2">More technical focus for engineering-heavy evaluation panels</p>
                </CardHeader>
                <CardContent className="prose prose-sm max-w-none">
                    <div className="bg-gray-50 p-4 rounded-lg">
                        <h3 className="font-semibold mb-3">SBIR Phase I: Machine Learning-Driven CMMC Compliance Automation for Defense SMBs</h3>
                        
                        <p className="mb-4">
                            <strong>Technical Problem:</strong> The Cybersecurity Maturity Model Certification (CMMC) 2.0 mandate requires 
                            300,000 Defense Industrial Base contractors (90% SMBs) to implement 110 NIST SP 800-171 controls by 2025-2028. 
                            Current manual approaches require 168+ hours for System Security Plan generation alone, costing $50K-$200K per SMB 
                            and threatening 40% supply chain dropout. No existing solution automates the complex mapping between organizational 
                            security practices and federal compliance requirements.
                        </p>

                        <p className="mb-4">
                            <strong>Technical Innovation:</strong> HyperCore Cyber will develop novel machine learning algorithms that: 
                            (1) automatically parse organizational security documentation using fine-tuned transformer models, 
                            (2) map existing controls to NIST 800-171 requirements through semantic similarity algorithms, 
                            (3) generate compliant SSP documentation using template-driven natural language generation, and 
                            (4) simulate 3PAO assessments through adversarial testing frameworks. Core innovation: context-aware 
                            compliance mapping that learns from expert annotations and real audit outcomes.
                        </p>

                        <p className="mb-4">
                            <strong>Phase I Objectives:</strong> Develop and validate ML models achieving 90% accuracy in control classification, 
                            sub-320ms inference times, and 80% reduction in documentation effort. Deploy with 10+ SMB pilots to collect 
                            performance metrics and user feedback. Deliverables include working prototype, performance benchmarks, 
                            user validation studies, and Phase II commercialization roadmap.
                        </p>

                        <p className="mb-4">
                            <strong>Broader Impact:</strong> Addresses critical DoD supply chain vulnerability while creating $1B+ commercial 
                            market serving 31,500 SMB contractors. Phase II transition enables dual-use applications across healthcare (HIPAA), 
                            education (FERPA), and financial services (SOX) regulations. Direct alignment with AFWERX cyber resilience priorities 
                            and DoD's small business innovation objectives.
                        </p>

                        <div className="bg-blue-50 p-3 rounded mt-4">
                            <p className="text-sm font-semibold text-blue-800 mb-1">Key Technical Merit:</p>
                            <p className="text-sm text-blue-700">
                                Novel application of transformer architectures to regulatory compliance, validated against existing 
                                MVP with real user data (4 LOIs, 90% satisfaction, 320ms response times).
                            </p>
                        </div>
                    </div>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>Key SBIR Success Factors</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="grid md:grid-cols-2 gap-6 text-sm">
                        <div>
                            <h4 className="font-semibold mb-2 text-green-800">Technical Merit Strengths</h4>
                            <ul className="space-y-1 text-green-700">
                                <li>• Novel AI approach to regulatory compliance automation</li>
                                <li>• Quantifiable performance metrics (90% accuracy, under 320ms response)</li>
                                <li>• Existing MVP demonstrating technical feasibility</li>
                                <li>• Scalable architecture supporting 31,500+ contractors</li>
                            </ul>
                        </div>
                        <div>
                            <h4 className="font-semibold mb-2 text-blue-800">Commercial Potential Strengths</h4>
                            <ul className="space-y-1 text-blue-700">
                                <li>• Clear path to Phase II commercialization</li>
                                <li>• $1B+ addressable market with validated demand</li>
                                <li>• Disrupts existing $5K-15K competitor pricing</li>
                                <li>• Dual-use applications across regulated industries</li>
                            </ul>
                        </div>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}