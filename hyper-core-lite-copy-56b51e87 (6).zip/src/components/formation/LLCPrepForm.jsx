
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Copy, ExternalLink, Search, Landmark } from 'lucide-react';
import { toast } from "sonner";

export default function LLCPrepForm({ onDataSaved }) {
    const [formData, setFormData] = useState({
        entityName: 'HyperCore Lite Cybersecurity Ecosystem LLC',
        registeredAgent: '', // Cleared for user input
        officeAddress: '11410 Bacon Race Rd, Woodbridge, VA 22192',
        organizer: '', // Cleared for user input
    });

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.id]: e.target.value });
    };

    const copyToClipboard = (text) => {
        navigator.clipboard.writeText(text);
        toast.success(`Copied: ${text}`);
    };

    const handleSaveAndContinue = () => {
        // Basic validation
        if (!formData.entityName || !formData.registeredAgent || !formData.officeAddress || !formData.organizer) {
            toast.error("Please fill all fields before continuing.");
            return;
        }
        onDataSaved(formData);
        toast.success("LLC Information Saved. Proceeding to Operating Agreement.");
    };

    return (
        <Card>
            <CardHeader>
                <CardTitle>Step 1: Prepare Virginia LLC Articles of Organization</CardTitle>
                <CardDescription>Fill this form out completely. Then, use the copy buttons to paste the information into the official Virginia SCC portal.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
                <Alert>
                    <Landmark className="h-4 w-4" />
                    <AlertTitle>Official Government Portal</AlertTitle>
                    <AlertDescription className="flex justify-between items-center">
                        <span>Use this information to file on the Virginia SCC website.</span>
                        <Button variant="outline" size="sm" asChild>
                            <a href="https://cis.scc.virginia.gov/" target="_blank" rel="noopener noreferrer">
                                Open VA SCC Portal <ExternalLink className="w-4 h-4 ml-2" />
                            </a>
                        </Button>
                    </AlertDescription>
                </Alert>

                <div className="space-y-2">
                    <Label htmlFor="entityName">1. LLC Name</Label>
                    <div className="flex gap-2">
                        <Input id="entityName" value={formData.entityName} onChange={handleChange} />
                        <Button variant="outline" size="icon" onClick={() => copyToClipboard(formData.entityName)}><Copy className="w-4 h-4" /></Button>
                        <Button variant="secondary" asChild>
                            <a href="https://cis.scc.virginia.gov/EntitySearch/Index" target="_blank" rel="noopener noreferrer">
                                <Search className="w-4 h-4 mr-2" /> Check Availability
                            </a>
                        </Button>
                    </div>
                </div>
                <div className="space-y-2">
                    <Label htmlFor="registeredAgent">2. Registered Agent</Label>
                    <div className="flex gap-2">
                        <Input id="registeredAgent" value={formData.registeredAgent} onChange={handleChange} placeholder="Your full name (or a service)" />
                        <Button variant="outline" size="icon" onClick={() => copyToClipboard(formData.registeredAgent)}><Copy className="w-4 h-4" /></Button>
                    </div>
                    <p className="text-xs text-gray-500">This is the person designated to receive official legal documents. This must be a Virginia resident with a physical Virginia street address (not a P.O. Box).</p>
                </div>
                <div className="space-y-2">
                    <Label htmlFor="officeAddress">3. Principal Office Address</Label>
                    <div className="flex gap-2">
                        <Input id="officeAddress" value={formData.officeAddress} onChange={handleChange} placeholder="Your business street address" />
                        <Button variant="outline" size="icon" onClick={() => copyToClipboard(formData.officeAddress)}><Copy className="w-4 h-4" /></Button>
                    </div>
                </div>
                <div className="space-y-2">
                    <Label htmlFor="organizer">4. Organizer</Label>
                    <div className="flex gap-2">
                        <Input id="organizer" value={formData.organizer} onChange={handleChange} placeholder="Your full name" />
                        <Button variant="outline" size="icon" onClick={() => copyToClipboard(formData.organizer)}><Copy className="w-4 h-4" /></Button>
                    </div>
                    <p className="text-xs text-gray-500">The person filing the document. This is you.</p>
                </div>
                
                <Button onClick={handleSaveAndContinue} className="w-full">
                    Save and Continue to Operating Agreement
                </Button>
            </CardContent>
        </Card>
    );
}
