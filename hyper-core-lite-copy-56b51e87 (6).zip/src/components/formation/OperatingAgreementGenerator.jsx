import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Copy, FileText, CheckCircle } from 'lucide-react';
import { toast } from "sonner";

export const generateOperatingAgreementContent = (llcData) => {
    return `
OPERATING AGREEMENT
of
${llcData.name}
A VIRGINIA LIMITED LIABILITY COMPANY

This Operating Agreement is made effective as of September 4, 2025, by and between the Company and its sole member, ${llcData.ownerName}.

ARTICLE 1: FORMATION
1.1 Formation. The Company has been formed as a Virginia limited liability company by filing Articles of Organization with the Virginia State Corporation Commission.
1.2 Name. The name of the Company is ${llcData.name}.
1.3 Purpose. The purpose of the Company is to engage in any lawful act or activity for which a limited liability company may be formed under the Virginia Limited Liability Company Act, primarily focusing on cybersecurity services, AI technology, and related government contracting.
1.4 Principal Office. The principal office of the Company shall be located at ${llcData.address}.

ARTICLE 2: MEMBERSHIP
2.1 Sole Member. The sole member of the Company is ${llcData.ownerName} ("the Member").
2.2 Additional Members. No additional members may be admitted to the Company except with the written consent of the Member.

ARTICLE 3: MANAGEMENT
3.1 Management by Member. The Company shall be managed by its Member. The Member shall have full and complete authority, power, and discretion to manage and control the business, affairs, and properties of the Company.
3.2 Title of Member. The Member shall hold the title of Managing Member.

ARTICLE 4: CAPITAL CONTRIBUTIONS
4.1 Initial Contribution. The Member is deemed to have made an initial capital contribution to the Company. The nature and amount of this contribution shall be reflected in the Company's books and records.

ARTICLE 5: DISTRIBUTIONS
5.1 Distributions. Distributions of cash or other assets shall be made from the Company to the Member at such times and in such amounts as the Member shall determine.

ARTICLE 6: DISSOLUTION
6.1 Dissolution. The Company shall be dissolved upon the written determination of the Member or upon the occurrence of any other event causing dissolution under the Virginia Limited Liability Company Act.

IN WITNESS WHEREOF, the undersigned, being the sole member of ${llcData.name}, has executed this Operating Agreement.

____________________________
${llcData.ownerName}, Managing Member
Date: ${new Date('2025-09-04').toLocaleDateString()}
    `;
};

export default function OperatingAgreementGenerator({ llcData }) {
    const [agreement, setAgreement] = useState('');

    useEffect(() => {
        setAgreement(generateOperatingAgreementContent(llcData));
    }, [llcData]);

    const copyToClipboard = () => {
        navigator.clipboard.writeText(agreement);
        toast.success("Operating Agreement copied to clipboard!");
    };

    return (
        <Card>
            <CardHeader>
                <CardTitle className="flex items-center gap-2">
                    <FileText className="w-5 h-5 text-blue-600" />
                    Step 2: Generate Operating Agreement
                </CardTitle>
            </CardHeader>
            <CardContent>
                <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-4">
                    <div className="flex items-center gap-2">
                        <CheckCircle className="w-5 h-5 text-green-600" />
                        <span className="font-semibold text-green-800">Agreement Generated</span>
                    </div>
                    <p className="text-green-700 text-sm mt-1">
                        A standard single-member LLC operating agreement has been generated based on your company information.
                    </p>
                </div>
                <Textarea 
                    value={agreement}
                    readOnly
                    rows={10}
                    className="bg-gray-50 text-xs"
                />
                <Button onClick={copyToClipboard} className="mt-4 w-full">
                    <Copy className="w-4 h-4 mr-2" />
                    Copy to Clipboard
                </Button>
            </CardContent>
        </Card>
    );
}