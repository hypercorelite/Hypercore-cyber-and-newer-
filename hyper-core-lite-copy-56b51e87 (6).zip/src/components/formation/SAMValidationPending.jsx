
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Loader2, Clock, MailCheck, ShieldCheck, ExternalLink } from 'lucide-react';
import { toast } from "sonner";
import { createPageUrl } from '@/utils'; // Added this import

export default function SAMValidationPending() {
    const copyToClipboard = (text) => {
        navigator.clipboard.writeText(text);
        toast.success(`Copied: ${text}`);
    };
    
    return (
        <Card>
            <CardHeader>
                <CardTitle className="flex items-center gap-2">
                    <Loader2 className="w-6 h-6 animate-spin text-blue-600" />
                    Step 4: SAM.gov Validation In Progress
                </CardTitle>
                <CardDescription>
                    Your documentation has been submitted. The government is now validating your entity.
                </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
                <Alert className="bg-blue-50 border-blue-200">
                    <AlertTitle className="text-blue-800">Reference Number: INC-GSAFSD20264951</AlertTitle>
                    <AlertDescription className="text-blue-700">
                        Keep this number for your records. The validation process has started.
                    </AlertDescription>
                </Alert>

                <div>
                    <h3 className="font-semibold text-lg mb-3">Validation Timeline & Process:</h3>
                    <ol className="relative border-l border-gray-200 dark:border-gray-700 ml-2">                  
                        <li className="mb-10 ml-6">            
                            <span className="absolute flex items-center justify-center w-6 h-6 bg-blue-100 rounded-full -left-3 ring-8 ring-white">
                                <Loader2 className="w-4 h-4 text-blue-600 animate-spin" />
                            </span>
                            <h3 className="flex items-center mb-1 text-base font-semibold text-gray-900">
                                Document Review <span className="bg-blue-100 text-blue-800 text-sm font-medium mr-2 px-2.5 py-0.5 rounded ml-3">IN PROGRESS</span>
                            </h3>
                            <time className="block mb-2 text-sm font-normal leading-none text-gray-400">1.5 - 3.5 Business Days</time>
                            <p className="text-sm text-gray-600">The General Services Administration (GSA) is reviewing your submitted LLC and EIN documents for accuracy.</p>
                        </li>
                        <li className="mb-10 ml-6">
                             <span className="absolute flex items-center justify-center w-6 h-6 bg-gray-100 rounded-full -left-3 ring-8 ring-white">
                                <MailCheck className="w-4 h-4 text-gray-500" />
                            </span>
                            <h3 className="mb-1 text-base font-semibold text-gray-900">Email Confirmation</h3>
                            <time className="block mb-2 text-sm font-normal leading-none text-gray-400">Next: Check Your Email</time>
                            <p className="text-sm text-gray-600">You will receive an email confirming your documents are approved. This is your signal that final validation has begun.</p>
                        </li>
                        <li className="ml-6">
                            <span className="absolute flex items-center justify-center w-6 h-6 bg-gray-100 rounded-full -left-3 ring-8 ring-white">
                                <ShieldCheck className="w-4 h-4 text-gray-500" />
                            </span>
                            <h3 className="mb-1 text-base font-semibold text-gray-900">TIN & CAGE Code Validation</h3>
                            <time className="block mb-2 text-sm font-normal leading-none text-gray-400">7 - 10 Business Days (after email)</time>
                            <p className="text-sm text-gray-600">The IRS validates your EIN and the DLA assigns your CAGE code. Once complete, your registration will be fully active.</p>
                        </li>
                    </ol>
                </div>
                
                <Alert>
                    <Clock className="h-4 w-4" />
                    <AlertTitle>What to Do Now</AlertTitle>
                    <AlertDescription>
                        No action is needed from you at this time. Monitor your email for updates from `sam.gov` or `GSA`. In the meantime, you can explore the SBIR Grant Hub to prepare your proposal.
                    </AlertDescription>
                </Alert>
                 <Button asChild className="w-full">
                     <a href={createPageUrl('SBIRGrantHub')}>
                        Prepare SBIR Grant Proposal While You Wait <ExternalLink className="w-4 h-4 ml-2" />
                    </a>
                </Button>
            </CardContent>
        </Card>
    );
}
