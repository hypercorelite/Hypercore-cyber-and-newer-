
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Copy, Download, Banknote, CheckCircle, FileDown } from 'lucide-react';
import { motion } from "framer-motion";
import { toast } from "sonner";
import { getBankSecrets } from "@/api/functions";
import { jsPDF } from "jspdf";

export default function BankingConversionKit() {
    const [bankInfo, setBankInfo] = useState({
        bankName: 'United Bank',
        routingNumber: '',
        currentAccountNumber: '',
        signerName: '' // Cleared for user input
    });

    // Auto-populate bank details from secrets
    useEffect(() => {
        const loadBankSecrets = async () => {
            try {
                // Get routing number and account number from backend function
                const response = await getBankSecrets();
                if (response.data?.bankSecrets) {
                    setBankInfo(prev => ({
                        ...prev,
                        routingNumber: response.data.bankSecrets.routingNumber,
                        currentAccountNumber: response.data.bankSecrets.accountNumber
                    }));
                }
            } catch (error) {
                console.log('Bank details will be manually entered or could not be loaded:', error);
                toast.error("Failed to load bank secrets automatically.");
            }
        };

        loadBankSecrets();
    }, []);

    const copyToClipboard = (text) => {
        navigator.clipboard.writeText(text);
        toast.success("Copied to clipboard!");
    };

    const generateBankingDocuments = () => {
        const conversionLetter = `
**ACCOUNT CONVERSION REQUEST LETTER**

Date: ${new Date().toLocaleDateString()}

To: United Bank
Branch Manager / Business Account Department

RE: Conversion of Personal Account to Business Account
Account Holder: ${bankInfo.signerName || '[Your Full Name]'}
Current Account Number: ${bankInfo.currentAccountNumber}
Routing Number: ${bankInfo.routingNumber}

Dear Banking Representative,

I am writing to request the conversion of my existing personal account to a business account for my newly formed Limited Liability Company.

**BUSINESS INFORMATION:**
• Legal Business Name: HyperCore Lite Cybersecurity Ecosystem LLC
• Federal Tax ID (EIN): 39-4162842
• State of Formation: Virginia
• Formation Date: September 4, 2025
• Business Address: 11410 Bacon Race Rd, Woodbridge, VA 22192
• Business Type: Cybersecurity Services & AI Technology

**AUTHORIZED SIGNATORY:**
• Name: ${bankInfo.signerName || '[Your Full Name]'}
• Title: Managing Member
• Authority: Full banking authority as outlined in Operating Agreement

**CURRENT ACCOUNT DETAILS:**
• Bank: United Bank
• Account Number: ${bankInfo.currentAccountNumber}
• Routing Number: ${bankInfo.routingNumber}

**SUPPORTING DOCUMENTATION PROVIDED:**
✓ Virginia Articles of Organization (State Filing Receipt)
✓ IRS EIN Assignment Letter (SS-4 Confirmation)
✓ LLC Operating Agreement (Signed Original)
✓ Certificate of Good Standing (if required)

**CONVERSION REQUEST:**
Please convert the above personal account to a business checking account under the LLC name. I understand this process typically includes:
1. Updating account title to business name
2. Issuing new business checks and debit cards
3. Updating all account documentation
4. Providing business banking agreement

**BANKING SERVICES NEEDED:**
• Business Checking Account
• Online Business Banking Access
• Business Debit Card
• Mobile Banking for Business
• ACH/Wire Transfer Capabilities

I am available to complete any additional paperwork or provide further documentation as needed. Please contact me at your earliest convenience to schedule an appointment or discuss next steps.

Thank you for your assistance with this conversion.

Sincerely,

____________________________
${bankInfo.signerName || '[Your Full Name]'}
Managing Member
HyperCore Lite Cybersecurity Ecosystem LLC

Contact Information:
Email: [Your Business Email]
Phone: [Your Business Phone]
Address: 11410 Bacon Race Rd, Woodbridge, VA 22192
        `;

        return conversionLetter;
    };

    const downloadDocument = () => {
        const docContent = generateBankingDocuments();
        const blob = new Blob([docContent], { type: 'text/plain' });
        const url = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = 'United_Bank_LLC_Conversion_Request.txt';
        document.body.appendChild(link);
        link.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(link);
        toast.success("Text document downloaded!");
    };

    const generateAndDownloadPDF = () => {
        toast.info("Generating your PDF, please wait...");
        try {
            const content = generateBankingDocuments();
            const doc = new jsPDF();

            doc.setFont("Helvetica", "normal");
            doc.setFontSize(12);
            
            // Use splitTextToSize to handle wrapping automatically
            const lines = doc.splitTextToSize(content, 180); // 180mm width
            doc.text(lines, 15, 15); // x: 15mm, y: 15mm
            
            // Generate the PDF as a Data URI
            const pdfDataUri = doc.output('datauristring');

            // Create a link and trigger the download
            const link = document.createElement('a');
            link.href = pdfDataUri;
            link.download = 'United_Bank_LLC_Conversion_Request.pdf';
            
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            
            toast.success("PDF download started! Check your notifications.");
        } catch (error) {
            console.error("PDF Generation Error:", error);
            toast.error("Could not generate PDF. Please try the .txt download instead.");
        }
    };

    // Form is complete if all bank info fields (even if auto-populated) have values
    const isFormComplete = bankInfo.bankName && bankInfo.routingNumber && bankInfo.currentAccountNumber && bankInfo.signerName;

    return (
        <Card>
            <CardHeader>
                <CardTitle className="flex items-center gap-2">
                    <Banknote className="w-5 h-5 text-green-600" />
                    Step 5: Business Banking Conversion Kit
                </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                    <div className="flex items-center gap-2 mb-2">
                        <CheckCircle className="w-5 h-5 text-green-600" />
                        <span className="font-semibold text-green-800">Bank Details Auto-Loaded</span>
                    </div>
                    <p className="text-green-700 text-sm">
                        Your United Bank information has been securely loaded and is ready for conversion.
                    </p>
                </div>

                <div className="grid grid-cols-2 gap-4">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Bank Name</label>
                        <Input value={bankInfo.bankName} readOnly className="bg-gray-50" />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Authorized Signer</label>
                        <Input 
                            value={bankInfo.signerName}
                            onChange={(e) => setBankInfo({...bankInfo, signerName: e.target.value})}
                            placeholder="Your Full Name"
                            className="bg-white" 
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Routing Number</label>
                        <Input value={bankInfo.routingNumber || 'Loading...'} readOnly className="bg-gray-50" />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Current Account Number</label>
                        <Input value={bankInfo.currentAccountNumber || 'Loading...'} readOnly className="bg-gray-50" />
                    </div>
                </div>

                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <h4 className="font-semibold text-blue-800 mb-2">Conversion Letter Preview:</h4>
                    <div className="text-xs text-blue-700 bg-white p-3 rounded border max-h-32 overflow-y-auto">
                        {generateBankingDocuments().substring(0, 300)}...
                    </div>
                </div>

                <div className="flex gap-3">
                    <Button
                        onClick={generateAndDownloadPDF}
                        className="flex-1 bg-green-600 hover:bg-green-700"
                        disabled={!isFormComplete}
                    >
                        <FileDown className="w-4 h-4 mr-2" /> Generate PDF for Printing
                    </Button>
                    <Button
                        onClick={downloadDocument}
                        variant="outline"
                        className="flex-1"
                        disabled={!isFormComplete}
                    >
                        <Download className="w-4 h-4 mr-2" /> Download .txt
                    </Button>
                </div>

                <div className="text-center text-xs text-gray-500">
                    After generating the PDF, open it from your phone's downloads and use the 'Print' or 'Share' option.
                </div>

                <div className="text-sm text-gray-600">
                    <p><strong>Next Steps:</strong></p>
                    <ol className="list-decimal list-inside space-y-1 mt-2">
                        <li>Generate and download the PDF version of the banking conversion letter</li>
                        <li>Gather your LLC documents (Articles of Organization, Operating Agreement, EIN letter)</li>
                        <li>Visit your local United Bank branch</li>
                        <li>Present the letter and documents to convert your account</li>
                    </ol>
                </div>
            </CardContent>
        </Card>
    );
}
