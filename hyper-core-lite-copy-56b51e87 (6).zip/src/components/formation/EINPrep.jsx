import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { ExternalLink, CheckSquare, Shield, Banknote } from 'lucide-react';

export default function EINPrep({ llcData, onComplete }) {
    return (
        <Card>
            <CardHeader>
                <CardTitle>Step 3: Obtain Federal Employer Identification Number (EIN)</CardTitle>
                <CardDescription>After your LLC is approved by Virginia, you must get an EIN from the IRS. It's free and instant online.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
                <Alert className="bg-yellow-50 border-yellow-200">
                    <Shield className="h-4 w-4" />
                    <AlertTitle>IMPORTANT: Wait for LLC Approval!</AlertTitle>
                    <AlertDescription>
                        Do not apply for an EIN until you have received confirmation from the Virginia SCC that your LLC has been officially formed.
                    </AlertDescription>
                </Alert>

                <Alert>
                    <Banknote className="h-4 w-4" />
                    <AlertTitle>Official IRS EIN Application</AlertTitle>
                    <AlertDescription className="flex justify-between items-center">
                        <span>The application is free. Do not pay any third-party service.</span>
                        <Button variant="outline" size="sm" asChild>
                            <a href="https://www.irs.gov/businesses/small-businesses-self-employed/apply-for-an-employer-identification-number-ein-online" target="_blank" rel="noopener noreferrer">
                                Open IRS Portal <ExternalLink className="w-4 h-4 ml-2" />
                            </a>
                        </Button>
                    </AlertDescription>
                </Alert>

                <div>
                    <h3 className="font-semibold mb-2">Information You Will Need:</h3>
                    <ul className="space-y-2 text-sm text-gray-700">
                        <li className="flex items-start gap-2"><CheckSquare className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" /><span>**LLC Name:** `{llcData?.entityName || 'HyperCore Lite Cybersecurity Ecosystem LLC'}`</span></li>
                        <li className="flex items-start gap-2"><CheckSquare className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" /><span>**Principal Address:** `{llcData?.officeAddress || '11410 Bacon Race Rd, Woodbridge, VA 22192'}`</span></li>
                        <li className="flex items-start gap-2"><CheckSquare className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" /><span>**Responsible Party:** The name and Social Security Number (SSN) of the responsible person.</span></li>
                        <li className="flex items-start gap-2"><CheckSquare className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" /><span>**LLC Formation Date:** The date your LLC was approved by Virginia.</span></li>
                        <li className="flex items-start gap-2"><CheckSquare className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" /><span>**Reason for Applying:** "Started a new business."</span></li>
                    </ul>
                </div>
                
                <Button onClick={onComplete} className="w-full">
                    I Have My EIN, Continue to SAM.gov Prep
                </Button>
            </CardContent>
        </Card>
    );
}