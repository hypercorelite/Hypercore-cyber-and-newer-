import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { ExternalLink, CheckSquare, Clock, ShieldCheck, Copy } from 'lucide-react';
import { toast } from "sonner";

export default function SAMPrep({ llcData }) {
    const copyToClipboard = (text) => {
        navigator.clipboard.writeText(text);
        toast.success(`Copied: ${text}`);
    };

    return (
        <Card>
            <CardHeader>
                <CardTitle>Step 4: Register in SAM.gov</CardTitle>
                <CardDescription>This is the final step to become eligible for federal contracts. This process is free but can take 7-10 business days for approval.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
                <Alert className="bg-green-50 border-green-200">
                    <CheckSquare className="h-4 w-4 text-green-600" />
                    <AlertTitle className="text-green-800">Ready for SAM.gov Registration!</AlertTitle>
                    <AlertDescription className="text-green-700">
                        Your LLC is approved and you have your Federal EIN. You can now complete SAM.gov registration.
                    </AlertDescription>
                </Alert>

                <Alert className="bg-red-50 border-red-200">
                    <Clock className="h-4 w-4" />
                    <AlertTitle>Patience is Required</AlertTitle>
                    <AlertDescription>
                        The government's validation process after you submit can take up to two weeks. Plan accordingly.
                    </AlertDescription>
                </Alert>

                <Alert>
                    <ShieldCheck className="h-4 w-4" />
                    <AlertTitle>Official SAM.gov Portal</AlertTitle>
                    <AlertDescription className="flex justify-between items-center">
                        <span>System for Award Management (SAM) is the only portal for this.</span>
                        <Button variant="outline" size="sm" asChild>
                            <a href="https://sam.gov/SAM/" target="_blank" rel="noopener noreferrer">
                                Open SAM.gov <ExternalLink className="w-4 h-4 ml-2" />
                            </a>
                        </Button>
                    </AlertDescription>
                </Alert>

                <div>
                    <h3 className="font-semibold mb-2">Your Information for SAM.gov Registration:</h3>
                    <ul className="space-y-3 text-sm text-gray-700">
                        <li className="flex items-start gap-2">
                            <CheckSquare className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                            <div className="flex-1">
                                <span className="font-medium">Legal Business Name:</span>
                                <div className="flex items-center gap-2 mt-1">
                                    <code className="bg-gray-100 px-2 py-1 rounded text-xs">HYPERCORE LITE CYBERSECURITY ECOSYSTEM LLC</code>
                                    <Button variant="ghost" size="sm" onClick={() => copyToClipboard('HYPERCORE LITE CYBERSECURITY ECOSYSTEM LLC')}>
                                        <Copy className="w-3 h-3" />
                                    </Button>
                                </div>
                            </div>
                        </li>
                        
                        <li className="flex items-start gap-2">
                            <CheckSquare className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                            <div className="flex-1">
                                <span className="font-medium">Federal EIN:</span>
                                <div className="flex items-center gap-2 mt-1">
                                    <code className="bg-gray-100 px-2 py-1 rounded text-xs">39-4162842</code>
                                    <Button variant="ghost" size="sm" onClick={() => copyToClipboard('39-4162842')}>
                                        <Copy className="w-3 h-3" />
                                    </Button>
                                </div>
                            </div>
                        </li>
                        
                        <li className="flex items-start gap-2">
                            <CheckSquare className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                            <div className="flex-1">
                                <span className="font-medium">Physical Address:</span>
                                <div className="flex items-center gap-2 mt-1">
                                    <code className="bg-gray-100 px-2 py-1 rounded text-xs">11410 BACON RACE RD, WOODBRIDGE, VA 22192</code>
                                    <Button variant="ghost" size="sm" onClick={() => copyToClipboard('11410 BACON RACE RD, WOODBRIDGE, VA 22192')}>
                                        <Copy className="w-3 h-3" />
                                    </Button>
                                </div>
                            </div>
                        </li>
                        
                        <li className="flex items-start gap-2">
                            <CheckSquare className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                            <span><strong>Business Bank Account Information:</strong> You need a dedicated bank account for your LLC to receive payments. The account name must match your LLC name.</span>
                        </li>
                        
                        <li className="flex items-start gap-2">
                            <CheckSquare className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                            <div className="flex-1">
                                <span className="font-medium">NAICS Codes:</span> These classify your business activities. Common codes for you:
                                <div className="flex items-center gap-2 mt-1">
                                    <code className="bg-gray-100 px-2 py-1 rounded text-xs">541512 - Computer Systems Design Services</code>
                                    <Button variant="ghost" size="sm" onClick={() => copyToClipboard('541512')}>
                                        <Copy className="w-3 h-3" />
                                    </Button>
                                </div>
                                <div className="flex items-center gap-2 mt-1">
                                    <code className="bg-gray-100 px-2 py-1 rounded text-xs">541519 - Other Computer Related Services</code>
                                    <Button variant="ghost" size="sm" onClick={() => copyToClipboard('541519')}>
                                        <Copy className="w-3 h-3" />
                                    </Button>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
                
                <Alert className="bg-blue-50 border-blue-200">
                    <AlertTitle className="text-blue-800">Next: SBIR Grant Opportunity</AlertTitle>
                    <AlertDescription className="text-blue-700">
                        After SAM.gov registration, you'll be eligible for the Air Force SBIR grant ($1.75M) with a March 15, 2025 deadline.
                    </AlertDescription>
                </Alert>
                
                <Button className="w-full bg-green-600 hover:bg-green-700">
                    🎯 Ready to Apply for Federal Contracts
                </Button>
            </CardContent>
        </Card>
    );
}