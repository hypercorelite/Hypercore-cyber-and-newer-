
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { ShieldCheck, Target, Calendar, DollarSign, Users, CheckCircle, ExternalLink } from 'lucide-react';

const THREEPAO_TARGETS = [
    {
        name: "Kratos Defense & Security Solutions",
        specialization: "DoD/Government Cloud Assessments",
        fedrampExperience: "50+ FedRAMP assessments",
        contactEmail: "fedramp.partnerships@kratosdefense.com",
        estimatedCost: "$75K - $150K",
        timeline: "6-9 months",
        priority: "high"
    },
    {
        name: "Coalfire Federal",
        specialization: "Federal Cloud Security Assessments",
        fedrampExperience: "Leading 3PAO with 100+ assessments",
        contactEmail: "federal.sales@coalfire.com", 
        estimatedCost: "$100K - $200K",
        timeline: "9-12 months",
        priority: "critical"
    },
    {
        name: "Schellman & Company",
        specialization: "Compliance and Security Assessments",
        fedrampExperience: "Authorized 3PAO since 2012",
        contactEmail: "fedramp@schellman.com",
        estimatedCost: "$80K - $160K", 
        timeline: "6-12 months",
        priority: "high"
    }
];

export default function ThreePAOPartnershipPlan() {
    return (
        <Card>
            <CardHeader>
                <CardTitle className="flex items-center gap-2">
                    <ShieldCheck className="w-5 h-5 text-purple-600" />
                    3PAO Partnership & Certification Strategy
                </CardTitle>
                <CardDescription>
                    Phase 1: Partner with existing 3PAOs. Phase 2: Form our own C3PAO for market dominance.
                </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
                <Alert className="bg-purple-50 border-purple-200">
                    <Target className="h-4 w-4 text-purple-600" />
                    <AlertTitle className="text-purple-800">Strategic Value</AlertTitle>
                    <AlertDescription className="text-purple-700">
                        3PAO partnerships unlock $500K+ federal cloud contracts and provide credibility for CMMC Level 3 assessments
                    </AlertDescription>
                </Alert>

                <Alert className="bg-blue-50 border-blue-200">
                    <Target className="h-4 w-4 text-blue-600" />
                    <AlertTitle className="text-blue-800">Long-Term Strategic Goal: Form an In-House C3PAO</AlertTitle>
                    <AlertDescription className="text-blue-700">
                        To avoid conflicts of interest, we will form a separate legal entity to act as our official C3PAO.
                        <ul className="list-disc pl-5 mt-2">
                            <li><strong>HyperCore AI (Readiness):</strong> Sells software and prepares clients. (Current business)</li>
                            <li><strong>HyperCore Assessors (Certification):</strong> Performs official audits. (Future business)</li>
                            <li>This two-company model is the key to capturing the entire CMMC market value chain.</li>
                        </ul>
                    </AlertDescription>
                </Alert>

                <div>
                    <h3 className="font-semibold text-lg mb-3">Phase 1 Prerequisites (Complete First):</h3>
                    <div className="space-y-2">
                        <div className="flex items-center gap-2">
                            <CheckCircle className="w-4 h-4 text-green-500" />
                            <span className="text-sm">✅ LLC Formation Complete</span>
                        </div>
                        <div className="flex items-center gap-2">
                            <CheckCircle className="w-4 h-4 text-green-500" />
                            <span className="text-sm">✅ Federal EIN Obtained</span>
                        </div>
                        <div className="flex items-center gap-2">
                            <CheckCircle className="w-4 h-4 text-yellow-500" />
                            <span className="text-sm">🔄 SAM.gov Registration (In Progress)</span>
                        </div>
                        <div className="flex items-center gap-2">
                            <CheckCircle className="w-4 h-4 text-gray-400" />
                            <span className="text-sm">⏳ Business Bank Account Setup</span>
                        </div>
                        <div className="flex items-center gap-2">
                            <CheckCircle className="w-4 h-4 text-gray-400" />
                            <span className="text-sm">⏳ Initial Revenue ($25K+ recommended)</span>
                        </div>
                    </div>
                </div>

                <div>
                    <h3 className="font-semibold text-lg mb-3">Phase 1 Priority 3PAO Partnership Targets:</h3>
                    <div className="space-y-4">
                        {THREEPAO_TARGETS.map((target, index) => (
                            <div key={target.name} className="border rounded-lg p-4">
                                <div className="flex justify-between items-start mb-2">
                                    <h4 className="font-semibold">{target.name}</h4>
                                    <Badge className={
                                        target.priority === 'critical' ? 'bg-red-100 text-red-800' :
                                        target.priority === 'high' ? 'bg-orange-100 text-orange-800' :
                                        'bg-blue-100 text-blue-800'
                                    }>
                                        {target.priority}
                                    </Badge>
                                </div>
                                <div className="space-y-1 text-sm text-gray-600">
                                    <div><strong>Specialization:</strong> {target.specialization}</div>
                                    <div><strong>Experience:</strong> {target.fedrampExperience}</div>
                                    <div><strong>Estimated Cost:</strong> {target.estimatedCost}</div>
                                    <div><strong>Timeline:</strong> {target.timeline}</div>
                                    <div><strong>Contact:</strong> 
                                        <Button variant="link" className="p-0 h-auto ml-1 text-blue-600">
                                            {target.contactEmail}
                                        </Button>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>

                <Alert>
                    <Calendar className="h-4 w-4" />
                    <AlertTitle>Recommended Timeline</AlertTitle>
                    <AlertDescription>
                        <div className="mt-2 space-y-2">
                            <div><strong>Months 1-2:</strong> Complete business formation, secure initial contracts</div>
                            <div><strong>Months 3-4:</strong> Initial 3PAO outreach and partnership discussions</div>
                            <div><strong>Months 6-12:</strong> Begin FedRAMP assessment preparation</div>
                            <div><strong>Months 12-18:</strong> Complete FedRAMP authorization process</div>
                        </div>
                    </AlertDescription>
                </Alert>

                <div className="bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg p-4">
                    <h4 className="font-semibold mb-2">Partnership Value Proposition:</h4>
                    <ul className="text-sm space-y-1">
                        <li>• <strong>AI-Powered Assessment Tools:</strong> Reduce 3PAO assessment time by 40%</li>
                        <li>• <strong>Continuous Compliance Monitoring:</strong> Real-time control validation</li>
                        <li>• <strong>Automated Evidence Collection:</strong> Streamlined ATO packages</li>
                        <li>• <strong>Revenue Share Model:</strong> 15% of contracts secured through partnership</li>
                    </ul>
                </div>
            </CardContent>
        </Card>
    );
}
