import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { CheckCircle2, Loader2, Circle, Milestone, FileText, Code, DollarSign, Users, Briefcase, Zap, Shield } from 'lucide-react';

const timelinePhases = [
    {
        name: "Phase 1: Foundation & Validation",
        duration: "Now – Mid-October 2025",
        goal: "Solidify business entity, financials, and federal validation.",
        icon: Milestone,
        tasks: [
            { text: "Monitor email for SAM.gov validation approval", status: "in_progress", icon: Loader2, className: "text-blue-600 animate-spin" },
            { text: "Use generated forms to convert personal bank account to a business account", status: "todo", icon: Circle },
            { text: "Secure a business credit card under the LLC's EIN", status: "todo", icon: Circle },
            { text: "Set up basic accounting software (e.g., Wave, QuickBooks)", status: "todo", icon: Circle },
        ]
    },
    {
        name: "Phase 2: Capability Development & Initial Traction",
        duration: "Mid-October – December 2025",
        goal: "Build and test the HyperCore MVP to demonstrate technical feasibility for the SBIR proposal.",
        icon: Zap,
        tasks: [
            { text: "Test existing backend functions (checkIPReputation, queryHuggingFaceModel) and document results", status: "todo", icon: Code },
            { text: "Develop MVP feature: A simple, interactive SOAR playbook on the Response Automation page", status: "todo", icon: Code },
            { text: "Develop MVP feature: Enhance CMMC Dashboard with manual progress tracking for controls", status: "todo", icon: Code },
            { text: "Draft a high-level system architecture diagram for the SBIR proposal", status: "todo", icon: FileText },
            { text: "Begin initial outreach to a potential first client to show market interest", status: "todo", icon: Users },
        ]
    },
    {
        name: "Phase 3: SBIR Proposal & Strategic Growth",
        duration: "January 2026 – March 15, 2026",
        goal: "Write and submit a winning Air Force SBIR proposal and pursue strategic partnerships.",
        icon: Briefcase,
        tasks: [
            { text: "Analyze final AFWERX SBIR 25.1 topics upon release (Dec '25)", status: "todo", icon: Circle },
            { text: "Draft Technical Proposal using MVP demo results as proof of capability", status: "todo", icon: FileText },
            { text: "Draft Commercialization Plan, highlighting 3PAO partnership strategy for FedRAMP", status: "todo", icon: DollarSign },
            { text: "Prepare detailed budget for the $1.75M Direct to Phase II grant", status: "todo", icon: DollarSign },
            { text: "Submit final proposal package via the official defense portal", status: "todo", icon: Shield, className: "text-green-600" },
        ]
    }
];

export default function CompletionTimeline() {
    const getStatusIcon = (task) => {
        if (task.status === 'done') return <CheckCircle2 className="w-5 h-5 text-green-500" />;
        if (task.status === 'in_progress') return <Loader2 className="w-5 h-5 text-blue-600 animate-spin" />;
        return <Circle className="w-5 h-5 text-gray-400" />;
    };

    return (
        <Card>
            <CardHeader>
                <CardTitle>Roadmap to SBIR Submission (March 15, 2026)</CardTitle>
                <CardDescription>Your step-by-step guide to federal readiness and proposal submission.</CardDescription>
            </CardHeader>
            <CardContent>
                <div className="space-y-8">
                    {timelinePhases.map(phase => (
                        <div key={phase.name} className="flex gap-4">
                            <div className="flex flex-col items-center">
                                <div className="flex-shrink-0 w-12 h-12 rounded-full bg-gray-100 flex items-center justify-center">
                                    <phase.icon className="w-6 h-6 text-gray-600" />
                                </div>
                                <div className="w-px h-full bg-gray-200"></div>
                            </div>
                            <div className="pb-8 flex-1">
                                <p className="text-sm text-gray-500">{phase.duration}</p>
                                <h3 className="text-lg font-semibold text-gray-900">{phase.name}</h3>
                                <p className="text-sm text-gray-600 mb-4">{phase.goal}</p>
                                <div className="space-y-3">
                                    {phase.tasks.map(task => (
                                        <div key={task.text} className="flex items-center gap-3">
                                            {getStatusIcon(task)}
                                            <span className="text-sm text-gray-800">{task.text}</span>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </CardContent>
        </Card>
    );
}