import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileDown, Layers } from 'lucide-react';
import { toast } from "sonner";
import { jsPDF } from "jspdf";
import { generateOperatingAgreementContent } from './OperatingAgreementGenerator';

export default function SupportingDocumentsPackage({ llcData, ein }) {

    const generatePdf = () => {
        toast.info("Generating your complete documents package...");
        try {
            const doc = new jsPDF();
            
            // --- Page 1: Articles of Organization ---
            doc.setFont("Helvetica", "bold");
            doc.setFontSize(18);
            doc.text("Commonwealth of Virginia", 105, 20, { align: 'center' });
            doc.text("State Corporation Commission", 105, 30, { align: 'center' });

            doc.setFont("Helvetica", "normal");
            doc.setFontSize(12);
            doc.text("Certificate of Organization of a Limited Liability Company", 105, 50, { align: 'center' });
            
            doc.setFont("Helvetica", "bold");
            doc.text("1. Name of the Limited Liability Company:", 15, 70);
            doc.setFont("Helvetica", "normal");
            doc.text(llcData.name, 20, 78);

            doc.setFont("Helvetica", "bold");
            doc.text("2. Principal Office Address:", 15, 90);
            doc.setFont("Helvetica", "normal");
            doc.text(llcData.address, 20, 98);

            doc.setFont("Helvetica", "bold");
            doc.text("3. Registered Agent:", 15, 110);
            doc.setFont("Helvetica", "normal");
            doc.text("Name: Christine Boes", 20, 118);
            doc.text("Address: 11410 Bacon Race Rd, Woodbridge, VA 22192", 20, 126);

            doc.setFont("Helvetica", "bold");
            doc.text("Date Filed:", 15, 150);
            doc.setFont("Helvetica", "normal");
            doc.text(new Date('2025-09-04').toLocaleDateString(), 20, 158);
            
            doc.setDrawColor(0, 80, 0);
            doc.setLineWidth(1);
            doc.rect(140, 160, 50, 20);
            doc.setFont("Helvetica", "bold");
            doc.setTextColor(0, 80, 0);
            doc.text("FILED", 165, 172, { align: 'center'});


            // --- Page 2: EIN Confirmation ---
            doc.addPage();
            doc.setTextColor(0, 0, 0); // reset color
            doc.setFont("Helvetica", "bold");
            doc.setFontSize(22);
            doc.text("Internal Revenue Service", 105, 25, { align: 'center' });

            doc.setFont("Helvetica", "normal");
            doc.setFontSize(12);
            doc.text(`Date: ${new Date().toLocaleDateString()}`, 150, 40);

            doc.text("HyperCore Lite Cybersecurity Ecosystem LLC", 15, 60);
            doc.text("11410 Bacon Race Rd", 15, 67);
            doc.text("Woodbridge, VA 22192", 15, 74);

            doc.setFontSize(14);
            doc.setFont("Helvetica", "bold");
            doc.text("RE: Federal Employer Identification Number (EIN) Assignment", 15, 95);

            doc.setFontSize(12);
            doc.setFont("Helvetica", "normal");
            const einBody = `This letter confirms that your organization has been assigned the following Federal Employer Identification Number (EIN). Please use this number on all tax forms and correspondence with the IRS.`;
            doc.text(einBody, 15, 105, { maxWidth: 180 });

            doc.setFontSize(20);
            doc.setFont("Helvetica", "bold");
            doc.text(`EIN: ${ein}`, 105, 135, { align: 'center' });

            doc.setFontSize(10);
            doc.setFont("Helvetica", "normal");
            doc.text("Keep this letter for your records. This is your official notification of your assigned EIN.", 15, 160);


            // --- Page 3+: Operating Agreement ---
            doc.addPage();
            const operatingAgreementContent = generateOperatingAgreementContent(llcData);
            doc.setFontSize(10);
            const agreementLines = doc.splitTextToSize(operatingAgreementContent, 180);
            doc.text(agreementLines, 15, 15);

            // --- Download ---
            const pdfDataUri = doc.output('datauristring');
            const link = document.createElement('a');
            link.href = pdfDataUri;
            link.download = 'HyperCore_LLC_Formation_Documents.pdf';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            
            toast.success("Complete documents package downloaded!");

        } catch (error) {
            console.error("PDF Generation Error:", error);
            toast.error("Could not generate PDF package.");
        }
    };

    return (
        <div className="mt-8">
            <Card className="border-2 border-purple-500 bg-purple-50">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-purple-800">
                        <Layers className="w-6 h-6" />
                        Complete Supporting Documents Package
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <p className="text-purple-700 mb-4">
                        Generate a single PDF containing your Articles of Organization, EIN Confirmation, and Operating Agreement. This is everything you need to provide to the bank or for your records.
                    </p>
                    <Button 
                        onClick={generatePdf} 
                        className="w-full bg-purple-600 hover:bg-purple-700"
                    >
                        <FileDown className="w-5 h-5 mr-2" />
                        Generate & Download All Documents (PDF)
                    </Button>
                </CardContent>
            </Card>
        </div>
    );
}