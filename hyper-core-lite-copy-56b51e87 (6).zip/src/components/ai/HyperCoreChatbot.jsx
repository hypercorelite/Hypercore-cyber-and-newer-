import React, { useState, useRef, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Bot, User, Send, Minimize2, Maximize2, Loader2 } from 'lucide-react';
import { hyperCoreChatbot } from "@/api/functions";
import { toast } from "sonner";

export default function HyperCoreChatbot({ isMinimized = false, onToggleMinimize }) {
    const [messages, setMessages] = useState([
        {
            role: 'assistant',
            content: "Hi! I'm HyperCore AI, your DFARS/CMMC compliance assistant. I can help with questions about NIST 800-171, flow-down requirements, our AI tools, and compliance strategies. What would you like to know?",
            timestamp: new Date().toISOString()
        }
    ]);
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const scrollAreaRef = useRef(null);

    const scrollToBottom = () => {
        if (scrollAreaRef.current) {
            const scrollContainer = scrollAreaRef.current.querySelector('[data-radix-scroll-area-viewport]');
            if (scrollContainer) {
                scrollContainer.scrollTop = scrollContainer.scrollHeight;
            }
        }
    };

    useEffect(() => {
        scrollToBottom();
    }, [messages]);

    const sendMessage = async () => {
        if (!input.trim() || isLoading) return;

        const userMessage = { role: 'user', content: input.trim(), timestamp: new Date().toISOString() };
        setMessages(prev => [...prev, userMessage]);
        setInput('');
        setIsLoading(true);

        try {
            const { data } = await hyperCoreChatbot({
                message: userMessage.content,
                conversationHistory: messages
            });

            const assistantMessage = {
                role: 'assistant',
                content: data.response,
                timestamp: data.timestamp,
                context: data.context
            };

            setMessages(prev => [...prev, assistantMessage]);
        } catch (error) {
            console.error('Chatbot error:', error);
            toast.error("Sorry, I'm having trouble right now. Please try again.");
            
            const errorMessage = {
                role: 'assistant',
                content: "I apologize, but I'm experiencing technical difficulties. Please try your question again in a moment, or contact support if the issue persists.",
                timestamp: new Date().toISOString(),
                isError: true
            };
            setMessages(prev => [...prev, errorMessage]);
        } finally {
            setIsLoading(false);
        }
    };

    const handleKeyPress = (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    };

    if (isMinimized) {
        return (
            <div className="fixed bottom-4 right-4 z-50">
                <Button 
                    onClick={onToggleMinimize}
                    className="h-12 w-12 rounded-full bg-blue-600 hover:bg-blue-700 shadow-lg"
                    size="icon"
                >
                    <Bot className="h-6 w-6" />
                </Button>
            </div>
        );
    }

    return (
        <div className="fixed bottom-4 right-4 z-50 w-96 h-[500px] shadow-2xl">
            <Card className="h-full flex flex-col bg-white border-blue-200">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3 bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-t-lg">
                    <div className="flex items-center space-x-2">
                        <Bot className="h-5 w-5" />
                        <CardTitle className="text-lg font-semibold">HyperCore AI</CardTitle>
                        <Badge variant="secondary" className="text-xs bg-white/20 text-white">
                            Live
                        </Badge>
                    </div>
                    <Button
                        variant="ghost"
                        size="icon"
                        onClick={onToggleMinimize}
                        className="h-8 w-8 text-white hover:bg-white/10"
                    >
                        <Minimize2 className="h-4 w-4" />
                    </Button>
                </CardHeader>

                <CardContent className="flex-1 flex flex-col p-0">
                    <ScrollArea ref={scrollAreaRef} className="flex-1 p-4">
                        <div className="space-y-4">
                            {messages.map((message, index) => (
                                <div
                                    key={index}
                                    className={`flex items-start space-x-2 ${
                                        message.role === 'user' ? 'flex-row-reverse space-x-reverse' : ''
                                    }`}
                                >
                                    <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${
                                        message.role === 'user' 
                                            ? 'bg-gray-200' 
                                            : message.isError 
                                            ? 'bg-red-100' 
                                            : 'bg-blue-100'
                                    }`}>
                                        {message.role === 'user' ? (
                                            <User className="h-4 w-4 text-gray-600" />
                                        ) : (
                                            <Bot className={`h-4 w-4 ${message.isError ? 'text-red-600' : 'text-blue-600'}`} />
                                        )}
                                    </div>
                                    <div className={`max-w-[80%] rounded-lg p-3 ${
                                        message.role === 'user'
                                            ? 'bg-blue-600 text-white ml-auto'
                                            : message.isError
                                            ? 'bg-red-50 text-red-800 border border-red-200'
                                            : 'bg-gray-100 text-gray-800'
                                    }`}>
                                        <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                                        <p className={`text-xs mt-1 opacity-70 ${
                                            message.role === 'user' ? 'text-blue-100' : 'text-gray-500'
                                        }`}>
                                            {new Date(message.timestamp).toLocaleTimeString()}
                                        </p>
                                    </div>
                                </div>
                            ))}
                            
                            {isLoading && (
                                <div className="flex items-start space-x-2">
                                    <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center">
                                        <Bot className="h-4 w-4 text-blue-600" />
                                    </div>
                                    <div className="bg-gray-100 rounded-lg p-3 flex items-center space-x-2">
                                        <Loader2 className="h-4 w-4 animate-spin text-gray-600" />
                                        <span className="text-sm text-gray-600">HyperCore AI is thinking...</span>
                                    </div>
                                </div>
                            )}
                        </div>
                    </ScrollArea>

                    <div className="p-4 border-t">
                        <div className="flex space-x-2">
                            <Input
                                value={input}
                                onChange={(e) => setInput(e.target.value)}
                                onKeyPress={handleKeyPress}
                                placeholder="Ask about DFARS, CMMC, or our AI tools..."
                                disabled={isLoading}
                                className="flex-1"
                            />
                            <Button
                                onClick={sendMessage}
                                disabled={isLoading || !input.trim()}
                                size="icon"
                                className="bg-blue-600 hover:bg-blue-700"
                            >
                                <Send className="h-4 w-4" />
                            </Button>
                        </div>
                        <p className="text-xs text-gray-500 mt-2 text-center">
                            Powered by HyperCore AI • DFARS/CMMC Expert
                        </p>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}