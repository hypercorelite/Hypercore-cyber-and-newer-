import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Database, Download, Zap, Bot, TrendingUp, FileText } from 'lucide-react';
import { exportTrainingDataset } from "@/api/functions";
import { trainCustomMistral } from "@/api/functions";
import { toast } from "sonner";

export default function TrainingDataDashboard() {
    const [trainingStats, setTrainingStats] = useState({
        totalInteractions: 12543,
        highQualityData: 8764,
        readyForTraining: true,
        lastExport: '2 days ago'
    });
    const [isExporting, setIsExporting] = useState(false);
    const [isTraining, setIsTraining] = useState(false);

    const handleExportDataset = async () => {
        setIsExporting(true);
        try {
            const { data } = await exportTrainingDataset({
                quality_filter: 'high',
                format: 'jsonl'
            });
            toast.success(`Dataset exported: ${data.training_examples} examples ready for Mistral training`);
            setTrainingStats(prev => ({
                ...prev,
                lastExport: 'Just now',
                readyForTraining: true
            }));
        } catch (error) {
            toast.error('Export failed: ' + error.message);
        } finally {
            setIsExporting(false);
        }
    };

    const handleStartTraining = async () => {
        setIsTraining(true);
        try {
            const { data } = await trainCustomMistral({
                model_name: 'hypercore-cmmc-specialist-v2',
                dataset_s3_location: 's3://hypercore-ai-training-data/datasets/latest.jsonl'
            });
            toast.success(`Training started! Model: ${data.model_repository}`);
        } catch (error) {
            toast.error('Training failed: ' + error.message);
        } finally {
            setIsTraining(false);
        }
    };

    return (
        <div className="space-y-6">
            <div className="grid md:grid-cols-3 gap-6">
                <Card>
                    <CardContent className="p-6">
                        <div className="flex items-center gap-3">
                            <Database className="w-8 h-8 text-blue-600" />
                            <div>
                                <h3 className="font-bold text-2xl text-blue-800">{trainingStats.totalInteractions.toLocaleString()}</h3>
                                <p className="text-sm text-blue-600">Total AI Interactions</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>
                
                <Card>
                    <CardContent className="p-6">
                        <div className="flex items-center gap-3">
                            <TrendingUp className="w-8 h-8 text-green-600" />
                            <div>
                                <h3 className="font-bold text-2xl text-green-800">{trainingStats.highQualityData.toLocaleString()}</h3>
                                <p className="text-sm text-green-600">High Quality Examples</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>
                
                <Card>
                    <CardContent className="p-6">
                        <div className="flex items-center gap-3">
                            <Bot className="w-8 h-8 text-purple-600" />
                            <div>
                                <h3 className="font-bold text-2xl text-purple-800">Ready</h3>
                                <p className="text-sm text-purple-600">Training Status</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </div>

            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Zap className="w-6 h-6" />
                        Custom Mistral Model Training Pipeline
                    </CardTitle>
                    <CardDescription>
                        Export your HyperCore AI interactions to train a specialized CMMC compliance model
                    </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="grid md:grid-cols-2 gap-4">
                        <div className="space-y-3">
                            <h4 className="font-semibold">Step 1: Export Training Dataset</h4>
                            <p className="text-sm text-gray-600">
                                Export high-quality user interactions in JSONL format for Mistral fine-tuning
                            </p>
                            <Button 
                                onClick={handleExportDataset} 
                                disabled={isExporting}
                                className="w-full"
                            >
                                <FileText className="w-4 h-4 mr-2" />
                                {isExporting ? 'Exporting...' : 'Export Training Data'}
                            </Button>
                        </div>

                        <div className="space-y-3">
                            <h4 className="font-semibold">Step 2: Train Custom Model</h4>
                            <p className="text-sm text-gray-600">
                                Fine-tune Mistral-7B with your CMMC expertise to create hypercore/cmmc-specialist-v2
                            </p>
                            <Button 
                                onClick={handleStartTraining} 
                                disabled={isTraining || !trainingStats.readyForTraining}
                                className="w-full bg-purple-600 hover:bg-purple-700"
                            >
                                <Bot className="w-4 h-4 mr-2" />
                                {isTraining ? 'Training...' : 'Start Mistral Training'}
                            </Button>
                        </div>
                    </div>

                    <div className="border-t pt-4">
                        <div className="flex items-center justify-between text-sm">
                            <span>Last dataset export: {trainingStats.lastExport}</span>
                            <Badge variant="outline">S3 Storage Active</Badge>
                        </div>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}