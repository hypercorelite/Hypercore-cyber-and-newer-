
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, Copy, FileCode, GitBranch, Database, Server } from 'lucide-react';
import { toast } from "sonner";

const MIGRATION_PHASES = [
    {
        phase: "Phase 0: Preparation & Inventory",
        description: "Before you write a single line of new code, know what you have.",
        steps: [
            {
                task: "Full Application Export",
                details: "Use the `exportAppBackup` function to get a complete list of all entities, pages, components, and functions. This is your migration manifest.",
                tools: "Base44 `exportAppBackup` function"
            },
            {
                task: "Setup a Private GitHub Repository",
                details: "Create a new private repository called 'hypercore-defense-platform'. This will be the new home for your code.",
                tools: "GitHub"
            },
            {
                task: "Local Development Environment Setup",
                details: "Set up a local environment with Node.js, npm/yarn, and your preferred code editor (VS Code recommended).",
                tools: "Node.js, VS Code"
            }
        ]
    },
    {
        phase: "Phase 1: Code Migration",
        description: "Move your frontend and backend logic to your own repository.",
        steps: [
            {
                task: "Copy Frontend Code",
                details: "Copy all files from `pages/`, `components/`, and `Layout.js` into a `/src` directory in your new repository.",
                tools: "Manual file copy"
            },
            {
                task: "Refactor Entity Logic",
                details: "Replace all Base44 SDK calls (e.g., `ThreatAlert.list()`) with functions that will call your new API. Create a temporary mock API.",
                tools: "Code editor (search for `.list`, `.create`, etc.)"
            },
            {
                task: "Copy Backend Functions",
                details: "Copy the logic from your Base44 `functions/` to a new `/functions` or `/api` directory. Remove Base44-specific wrappers.",
                tools: "Manual file copy"
            }
        ]
    },
    {
        phase: "Phase 2: Infrastructure Setup on AWS",
        description: "Build your new professional home on the AWS Free Tier.",
        steps: [
            {
                task: "Create AWS Account & Secure It",
                details: "Sign up for AWS, enable MFA on the root account, and create a separate IAM user for daily administrative tasks.",
                tools: "AWS Console, Authenticator App"
            },
            {
                task: "Deploy Frontend to AWS Amplify",
                details: "Connect your GitHub repo to AWS Amplify. It will automatically build and host your React application on a global CDN.",
                tools: "AWS Amplify Console"
            },
            {
                task: "Set up PostgreSQL Database with RDS",
                details: "Launch a `db.t3.micro` PostgreSQL instance on RDS. Ensure it's in a private subnet and only accessible from your backend.",
                tools: "AWS RDS Console"
            },
            {
                task: "Deploy Backend Functions to AWS Lambda",
                details: "Convert each of your backend functions into an AWS Lambda function, exposed via API Gateway.",
                tools: "AWS Lambda, API Gateway"
            }
        ]
    },
    {
        phase: "Phase 3: Data & Go-Live",
        description: "Migrate existing data and point your domain to the new platform.",
        steps: [
            {
                task: "Export Data from Base44",
                details: "Go to the Data tab in Base44 for each entity and export all records as CSV or JSON files.",
                tools: "Base44 Dashboard"
            },
            {
                task: "Import Data into RDS",
                details: "Write a simple Node.js script to read the exported files and insert the records into your new PostgreSQL database.",
                tools: "Node.js, `pg` (PostgreSQL client)"
            },
            {
                task: "Configure DNS",
                details: "Point your professional domain (e.g., `app.hypercoredefense.com`) to your AWS Amplify deployment and API Gateway.",
                tools: "Your Domain Registrar (Namecheap, GoDaddy)"
            },
            {
                task: "Final Testing & Decommission",
                details: "Thoroughly test the live application. Once confirmed, you can decommission your Base44 app.",
                tools: "Live testing, Base44 Dashboard"
            }
        ]
    }
];


export default function MigrationChecklist() {
    const [completedSteps, setCompletedSteps] = useState({});

    const toggleStep = (phase, stepIndex) => {
        const key = `${phase}_${stepIndex}`;
        setCompletedSteps(prev => ({
            ...prev,
            [key]: !prev[key]
        }));
    };

    return (
        <div className="space-y-6">
            {MIGRATION_PHASES.map((phase, phaseIndex) => (
                <Card key={phaseIndex} className="bg-slate-800 border-slate-600">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-3">
                            {phase.phase === 'Phase 0: Preparation & Inventory' && <FileCode className="w-6 h-6 text-blue-400" />}
                            {phase.phase === 'Phase 1: Code Migration' && <GitBranch className="w-6 h-6 text-blue-400" />}
                            {phase.phase === 'Phase 2: Infrastructure Setup on AWS' && <Server className="w-6 h-6 text-blue-400" />}
                            {phase.phase === 'Phase 3: Data & Go-Live' && <Database className="w-6 h-6 text-blue-400" />}
                            {phase.phase}
                        </CardTitle>
                        <CardDescription className="text-gray-400">{phase.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-3">
                            {phase.steps.map((step, stepIndex) => (
                                <div key={stepIndex} className="flex items-start gap-3 p-3 bg-slate-900 rounded-lg border border-slate-700">
                                    <Button
                                        variant="ghost"
                                        size="sm"
                                        onClick={() => toggleStep(phase.phase, stepIndex)}
                                        className={completedSteps[`${phase.phase}_${stepIndex}`] ? "text-green-400" : "text-gray-400"}
                                    >
                                        <CheckCircle className="w-5 h-5" />
                                    </Button>
                                    <div className="flex-grow">
                                        <h4 className="font-semibold text-white">{step.task}</h4>
                                        <p className="text-sm text-gray-300 my-1">{step.details}</p>
                                        <Badge variant="outline" className="text-xs border-slate-500 text-gray-400">
                                            Tools: {step.tools}
                                        </Badge>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </CardContent>
                </Card>
            ))}
        </div>
    );
}
