import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
    Shield, 
    AlertTriangle, 
    TrendingUp, 
    Activity,
    Eye,
    Zap
} from "lucide-react";

export default function SecurityMetrics() {
    const metrics = [
        {
            title: "Active Protections",
            value: "24/7",
            icon: Shield,
            color: "text-green-600",
            bg: "bg-green-50 border-green-200"
        },
        {
            title: "Threats Blocked Today",
            value: "1,247",
            icon: AlertTriangle,
            color: "text-red-600", 
            bg: "bg-red-50 border-red-200"
        },
        {
            title: "AI Detection Rate",
            value: "99.2%",
            icon: TrendingUp,
            color: "text-blue-600",
            bg: "bg-blue-50 border-blue-200"
        },
        {
            title: "System Health",
            value: "Optimal",
            icon: Activity,
            color: "text-green-600",
            bg: "bg-green-50 border-green-200"
        },
        {
            title: "Monitored Endpoints", 
            value: "847",
            icon: Eye,
            color: "text-purple-600",
            bg: "bg-purple-50 border-purple-200"
        },
        {
            title: "Response Time",
            value: "< 1s",
            icon: Zap,
            color: "text-yellow-600",
            bg: "bg-yellow-50 border-yellow-200"
        }
    ];

    return (
        <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-3 sm:gap-4">
            {metrics.map((metric, index) => (
                <Card key={index} className={`${metric.bg} h-full`}>
                    <CardHeader className="pb-2 px-3 sm:px-4 pt-3 sm:pt-4">
                        <div className="flex items-center justify-center sm:justify-between">
                            <metric.icon className={`w-4 h-4 sm:w-5 sm:h-5 ${metric.color}`} />
                        </div>
                    </CardHeader>
                    <CardContent className="px-3 sm:px-4 pb-3 sm:pb-4 pt-0">
                        <div className={`text-lg sm:text-2xl font-bold ${metric.color} text-center sm:text-left`}>
                            {metric.value}
                        </div>
                        <div className="text-xs sm:text-sm text-gray-600 text-center sm:text-left leading-tight">
                            {metric.title}
                        </div>
                    </CardContent>
                </Card>
            ))}
        </div>
    );
}