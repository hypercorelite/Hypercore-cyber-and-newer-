import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Bot, Zap, TrendingUp, Users, Calculator, Presentation } from 'lucide-react';
import { motion } from "framer-motion";

const LIVE_AI_CAPABILITIES = [
    {
        title: "AI Business Intelligence",
        status: "LIVE",
        description: "Upload your operational data, get AI-powered business insights and predictions",
        value: "Turn security data into competitive intelligence",
        demo_action: "Try Demo",
        color: "bg-blue-500"
    },
    {
        title: "Automated Decision Support",
        status: "LIVE", 
        description: "AI analyzes your compliance gaps and provides prioritized action plans",
        value: "Never guess what to fix next - AI tells you the highest-impact improvements",
        demo_action: "See Analysis",
        color: "bg-green-500"
    },
    {
        title: "AI Demo Assistant",
        status: "LIVE",
        description: "AI generates customized demonstrations for your specific audience and needs",
        value: "Perfect presentations every time, tailored to your prospect",
        demo_action: "Generate Demo",
        color: "bg-purple-500"
    }
];

const PARTNERSHIP_VALUE_PROPS = [
    {
        partner_type: "Legal Firms",
        current_pain: "40 hours to review compliance requirements manually",
        hypercore_solution: "AI reviews in 2 hours with 99.2% accuracy",
        partnership_offer: "Legal services for exclusive AI platform access",
        roi: "Scale practice 10x without adding staff"
    },
    {
        partner_type: "Insurance Carriers", 
        current_pain: "2-week underwriting process, 15% loss ratio",
        hypercore_solution: "Instant risk assessment, 25% loss ratio reduction",
        partnership_offer: "$50K development funding for 6-month exclusivity",
        roi: "$10M+ annual savings through better risk selection"
    },
    {
        partner_type: "Defense Contractors",
        current_pain: "$150K consultant fees, 18-month CMMC timeline",
        hypercore_solution: "AI-powered CMMC compliance in 90 days",
        partnership_offer: "$15K assessment now, 50% automation discount later",
        roi: "Faster DoD contracts + $100K+ consultant savings"
    }
];

export default function ProfessionalServicesWidget() {
    const [selectedDemo, setSelectedDemo] = useState(null);

    return (
        <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.5 }}
            className="space-y-6"
        >
            <Card className="bg-gradient-to-br from-purple-50 to-blue-50 border-purple-200">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Bot className="w-6 h-6 text-purple-600" />
                        AI-Enhanced Platform
                    </CardTitle>
                    <CardDescription>
                        Live AI capabilities that create irresistible value for strategic partners
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="space-y-3">
                        {LIVE_AI_CAPABILITIES.map((capability, index) => (
                            <motion.div
                                key={index}
                                initial={{ opacity: 0, y: 10 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: index * 0.1 }}
                                className="bg-white rounded-lg p-4 border hover:shadow-md transition-shadow"
                            >
                                <div className="flex justify-between items-start mb-2">
                                    <div>
                                        <h4 className="font-semibold text-gray-800">{capability.title}</h4>
                                        <p className="text-sm text-gray-600 mt-1">{capability.description}</p>
                                    </div>
                                    <Badge className={`${capability.color} text-white font-bold text-xs`}>
                                        {capability.status}
                                    </Badge>
                                </div>
                                <div className="bg-green-50 rounded-lg p-3 border border-green-200 mb-3">
                                    <div className="text-green-800 text-sm font-medium">{capability.value}</div>
                                </div>
                                <Button 
                                    size="sm" 
                                    className="w-full bg-gray-700 hover:bg-gray-800"
                                    onClick={() => setSelectedDemo(capability.title)}
                                >
                                    <Presentation className="w-4 h-4 mr-2" />
                                    {capability.demo_action}
                                </Button>
                            </motion.div>
                        ))}
                    </div>
                </CardContent>
            </Card>

            <Card className="border-green-200 bg-green-50">
                <CardHeader>
                    <CardTitle className="text-green-800 flex items-center gap-2">
                        <TrendingUp className="w-5 h-5" />
                        Zero-Capital Partnership Model
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="space-y-4">
                        {PARTNERSHIP_VALUE_PROPS.map((partner, index) => (
                            <div key={index} className="bg-white rounded-lg p-3 border">
                                <div className="flex justify-between items-center mb-2">
                                    <h4 className="font-semibold text-gray-800 text-sm">{partner.partner_type}</h4>
                                    <Badge className="bg-green-100 text-green-800 text-xs">
                                        {partner.roi}
                                    </Badge>
                                </div>
                                <div className="grid grid-cols-1 gap-2 text-xs">
                                    <div className="bg-red-50 rounded p-2 border border-red-200">
                                        <strong className="text-red-800">Current Pain:</strong>
                                        <div className="text-red-700">{partner.current_pain}</div>
                                    </div>
                                    <div className="bg-blue-50 rounded p-2 border border-blue-200">
                                        <strong className="text-blue-800">HyperCore Solution:</strong>
                                        <div className="text-blue-700">{partner.hypercore_solution}</div>
                                    </div>
                                    <div className="bg-purple-50 rounded p-2 border border-purple-200">
                                        <strong className="text-purple-800">Partnership Offer:</strong>
                                        <div className="text-purple-700">{partner.partnership_offer}</div>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>

            <Card className="border-yellow-200 bg-yellow-50">
                <CardHeader>
                    <CardTitle className="text-yellow-800 text-sm flex items-center gap-2">
                        <Calculator className="w-4 h-4" />
                        This Week's Partnership Targets
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="space-y-2 text-xs">
                        <div className="bg-white rounded p-2 border">
                            <strong>Legal Partner Demo:</strong> Schedule 30-min demo with local business lawyer
                        </div>
                        <div className="bg-white rounded p-2 border">
                            <strong>Insurance Broker Contact:</strong> Reach out to regional insurance carrier
                        </div>
                        <div className="bg-white rounded p-2 border">
                            <strong>CMMC Client Prospect:</strong> Contact defense contractors in DMV area
                        </div>
                    </div>
                </CardContent>
            </Card>
        </motion.div>
    );
}