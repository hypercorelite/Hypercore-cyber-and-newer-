
import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Info, Shield, Scale, Umbrella, User } from 'lucide-react';

export default function WelcomeBanner({ user }) {
    if (!user) {
        return (
             <Card className="mb-6 bg-gray-50 border-gray-200">
                <CardContent className="p-4">
                    <div className="flex items-start gap-4">
                        <User className="w-6 h-6 mt-1 text-gray-700" />
                        <div>
                            <h3 className="font-semibold text-lg text-gray-800">Welcome, Guest</h3>
                            <p className="text-sm text-gray-600">You are viewing a public demonstration. Create an account to explore partnership opportunities.</p>
                        </div>
                    </div>
                </CardContent>
            </Card>
        );
    }

    const rolesConfig = {
        legal_partner: {
            icon: Scale,
            title: "Legal Partner Portal",
            message: "This portal demonstrates our AI-powered contract analysis and compliance workflow automation capabilities for the November 2025 CMMC rollout.",
            color: "border-purple-500 bg-purple-50"
        },
        prospect: {
            icon: Info,
            title: `Welcome, ${user.full_name}`,
            message: "You are viewing a general prospect demonstration. With the CMMC phased rollout beginning November 10, 2025, explore our AI pipeline and contact us for role-specific guidance.",
            color: "border-gray-300 bg-gray-50"
        },
        admin: {
            icon: Shield,
            title: "Administrator View",
            message: "You have full access to all platform features and administrative controls.",
            color: "border-green-500 bg-green-50"
        }
    };

    const config = rolesConfig[user.partnership_role] || rolesConfig.prospect;
    const Icon = config.icon;

    return (
        <Card className={`mb-6 ${config.color}`}>
            <CardContent className="p-4">
                <div className="flex items-start gap-4">
                    <Icon className="w-6 h-6 mt-1 text-gray-700" />
                    <div>
                        <h3 className="font-semibold text-lg text-gray-800">{config.title}</h3>
                        <p className="text-sm text-gray-600">{config.message}</p>
                    </div>
                </div>
            </CardContent>
        </Card>
    );
}
