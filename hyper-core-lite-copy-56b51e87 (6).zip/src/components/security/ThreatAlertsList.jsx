import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ThreatAlert } from "@/api/entities";
import { AlertTriangle, Clock, MapPin, Brain, Shield, Zap, Factory, Building } from "lucide-react";
import { motion } from "framer-motion";

export default function ThreatAlertsList() {
    const [alerts, setAlerts] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        loadAlerts();
    }, []);

    const loadAlerts = async () => {
        try {
            const fetchedAlerts = await ThreatAlert.list('-created_date', 10);
            setAlerts(fetchedAlerts);
        } catch (error) {
            console.error('Failed to load alerts:', error);
        } finally {
            setLoading(false);
        }
    };

    const updateAlertStatus = async (alertId, newStatus) => {
        await ThreatAlert.update(alertId, { status: newStatus });
        loadAlerts();
    };

    const getSeverityColor = (severity) => {
        const colors = {
            low: "bg-blue-100 text-blue-800",
            medium: "bg-yellow-100 text-yellow-800", 
            high: "bg-orange-100 text-orange-800",
            critical: "bg-red-100 text-red-800"
        };
        return colors[severity] || "bg-gray-100 text-gray-800";
    };

    const getStatusColor = (status) => {
        const colors = {
            active: "bg-red-100 text-red-800",
            investigating: "bg-yellow-100 text-yellow-800",
            contained: "bg-blue-100 text-blue-800",
            resolved: "bg-green-100 text-green-800"
        };
        return colors[status] || "bg-gray-100 text-gray-800";
    };

    // Enhanced threat classification based on critical infrastructure training data
    const getCriticalInfraContext = (alert) => {
        const contexts = [];
        
        // Check for industrial/OT threats (from SCADA honeypot data)
        if (alert.description?.toLowerCase().includes('scada') || 
            alert.description?.toLowerCase().includes('modbus') ||
            alert.description?.toLowerCase().includes('industrial')) {
            contexts.push({ type: 'industrial', icon: Factory, label: 'Industrial Systems', color: 'text-purple-600' });
        }
        
        // Check for infrastructure targeting (from ICS-CERT data)
        if (alert.description?.toLowerCase().includes('infrastructure') ||
            alert.description?.toLowerCase().includes('facility') ||
            alert.target_system?.toLowerCase().includes('control')) {
            contexts.push({ type: 'facility', icon: Building, label: 'Critical Facility', color: 'text-orange-600' });
        }
        
        // Check for nation-state patterns (from energy sector threat data)
        if (alert.ai_confidence > 90 && alert.severity === 'critical') {
            contexts.push({ type: 'nation_state', icon: Zap, label: 'Nation-State Pattern', color: 'text-red-600' });
        }
        
        return contexts;
    };

    if (loading) {
        return (
            <Card>
                <CardHeader>
                    <CardTitle>Enhanced Threat Detection</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="text-center py-8 text-gray-500">
                        Loading enhanced threat intelligence...
                    </div>
                </CardContent>
            </Card>
        );
    }

    return (
        <Card>
            <CardHeader>
                <CardTitle className="flex items-center gap-2">
                    <AlertTriangle className="w-5 h-5 text-red-600" />
                    Enhanced Threat Detection System
                    <Badge className="ml-auto bg-purple-100 text-purple-800 text-xs">
                        CRITICAL INFRASTRUCTURE AI ENHANCED
                    </Badge>
                </CardTitle>
            </CardHeader>
            <CardContent>
                <div className="space-y-3">
                    {alerts.map((alert) => {
                        const infraContexts = getCriticalInfraContext(alert);
                        
                        return (
                            <motion.div
                                key={alert.id}
                                initial={{ opacity: 0, x: -20 }}
                                animate={{ opacity: 1, x: 0 }}
                                className="bg-white border rounded-lg p-4 hover:shadow-md transition-shadow"
                            >
                                <div className="flex justify-between items-start mb-2">
                                    <div className="flex items-center gap-2">
                                        <Badge className={getSeverityColor(alert.severity)}>
                                            {alert.severity.toUpperCase()}
                                        </Badge>
                                        <Badge className={getStatusColor(alert.status)}>
                                            {alert.status}
                                        </Badge>
                                        {/* Enhanced: Show critical infrastructure context */}
                                        {infraContexts.map((context, idx) => (
                                            <Badge key={idx} variant="outline" className={`${context.color} border-current`}>
                                                <context.icon className="w-3 h-3 mr-1" />
                                                {context.label}
                                            </Badge>
                                        ))}
                                    </div>
                                    <div className="flex items-center gap-1 text-xs text-gray-500">
                                        <Brain className="w-3 h-3" />
                                        {alert.ai_confidence}% confidence
                                        {infraContexts.length > 0 && (
                                            <span className="ml-2 text-purple-600">• Enhanced Analysis</span>
                                        )}
                                    </div>
                                </div>
                                
                                <div className="font-semibold text-gray-900 mb-1">
                                    {alert.threat_type.replace('_', ' ').toUpperCase()} Detected
                                    {infraContexts.length > 0 && (
                                        <span className="ml-2 text-sm font-normal text-purple-600">
                                            (Critical Infrastructure Pattern Detected)
                                        </span>
                                    )}
                                </div>
                                
                                <div className="text-sm text-gray-600 mb-3">
                                    {alert.description}
                                </div>

                                {/* Enhanced: Show infrastructure-specific mitigation if detected */}
                                {infraContexts.length > 0 && (
                                    <div className="mb-3 p-2 bg-purple-50 border border-purple-200 rounded text-sm">
                                        <div className="font-medium text-purple-800 mb-1">Enhanced Analysis:</div>
                                        <div className="text-purple-700">
                                            This attack pattern matches critical infrastructure threats. Recommend additional 
                                            monitoring of industrial control systems and facility operational technology networks.
                                        </div>
                                    </div>
                                )}
                                
                                <div className="flex items-center justify-between text-xs text-gray-500">
                                    <div className="flex items-center gap-3">
                                        <span className="flex items-center gap-1">
                                            <MapPin className="w-3 h-3" />
                                            {alert.source_ip}
                                        </span>
                                        <span className="flex items-center gap-1">
                                            <Clock className="w-3 h-3" />
                                            {new Date(alert.created_date).toLocaleTimeString()}
                                        </span>
                                    </div>
                                    
                                    {alert.status === 'active' && (
                                        <Button 
                                            size="sm" 
                                            variant="outline"
                                            onClick={() => updateAlertStatus(alert.id, 'investigating')}
                                            className="text-xs"
                                        >
                                            Investigate
                                        </Button>
                                    )}
                                </div>
                            </motion.div>
                        );
                    })}
                    
                    {alerts.length === 0 && (
                        <div className="text-center py-8 text-gray-500">
                            <Shield className="w-12 h-12 mx-auto mb-3 text-green-500" />
                            <div>All Clear - No Active Threats</div>
                            <div className="text-xs mt-2 text-purple-600">Enhanced monitoring with critical infrastructure AI active</div>
                        </div>
                    )}
                </div>
            </CardContent>
        </Card>
    );
}