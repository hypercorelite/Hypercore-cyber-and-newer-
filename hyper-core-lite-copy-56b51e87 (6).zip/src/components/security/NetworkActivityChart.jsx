import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, Tooltip } from "recharts";
import { Activity, TrendingUp } from "lucide-react";

export default function NetworkActivityChart() {
    // Simulate network activity data
    const data = [
        { time: "00:00", normal: 45, suspicious: 2 },
        { time: "04:00", normal: 32, suspicious: 1 },
        { time: "08:00", normal: 78, suspicious: 5 },
        { time: "12:00", normal: 92, suspicious: 8 },
        { time: "16:00", normal: 85, suspicious: 12 },
        { time: "20:00", normal: 67, suspicious: 3 },
        { time: "24:00", normal: 54, suspicious: 2 }
    ];

    return (
        <Card>
            <CardHeader>
                <CardTitle className="flex items-center gap-2">
                    <Activity className="w-5 h-5 text-blue-600" />
                    Network Activity (24h)
                </CardTitle>
            </CardHeader>
            <CardContent>
                <div className="h-48">
                    <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={data}>
                            <XAxis dataKey="time" />
                            <YAxis />
                            <Tooltip />
                            <Line 
                                type="monotone" 
                                dataKey="normal" 
                                stroke="#22c55e" 
                                strokeWidth={2}
                                name="Normal Traffic"
                            />
                            <Line 
                                type="monotone" 
                                dataKey="suspicious" 
                                stroke="#ef4444" 
                                strokeWidth={2}
                                name="Suspicious Activity"
                            />
                        </LineChart>
                    </ResponsiveContainer>
                </div>
                <div className="flex items-center justify-between text-sm text-gray-600 mt-4">
                    <div className="flex items-center gap-2">
                        <div className="w-3 h-3 bg-green-500 rounded"></div>
                        Normal Traffic
                    </div>
                    <div className="flex items-center gap-2">
                        <div className="w-3 h-3 bg-red-500 rounded"></div>
                        Suspicious Activity
                    </div>
                    <div className="flex items-center gap-1">
                        <TrendingUp className="w-3 h-3 text-blue-500" />
                        AI Monitoring
                    </div>
                </div>
            </CardContent>
        </Card>
    );
}