
import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Brain, Zap, CheckCircle, AlertTriangle, MapPin, Globe, Fingerprint, Shield, Clock, Building, Factory } from "lucide-react";
import { motion } from "framer-motion";
import { checkIPReputation } from "@/api/functions";

export default function AIAnalysisCard() {
    const [analyzing, setAnalyzing] = useState(false);
    const [result, setResult] = useState(null);
    const [ipAddress, setIpAddress] = useState("");

    const analyzeIP = async () => {
        if (!ipAddress) return;
        
        setAnalyzing(true);
        setResult(null);

        try {
            const response = await checkIPReputation({ ipAddress });
            
            if (response.status === 200) {
                // Enhanced result with critical infrastructure context
                const enhancedResult = {
                    ...response.data,
                    criticalInfraContext: {
                        energySectorThreat: response.data.riskScore > 70,
                        transportationRisk: response.data.usageType === 'hosting' && response.data.abuseReports > 0,
                        industrialTargeting: response.data.riskFactors?.some(factor => 
                            factor.includes('industrial') || factor.includes('SCADA') || factor.includes('control')
                        ) || false
                    }
                };
                setResult(enhancedResult);
            } else {
                setResult({
                    error: response.data?.error || "Analysis failed",
                    ip: ipAddress
                });
            }
        } catch (error) {
            console.error("IP Analysis Error:", error);
            setResult({
                error: error.message || "Network error - could not analyze IP",
                ip: ipAddress
            });
        } finally {
            setAnalyzing(false);
        }
    };

    const handleKeyPress = (e) => {
        if (e.key === 'Enter') {
            analyzeIP();
        }
    };

    return (
        <Card className="bg-gradient-to-br from-blue-50 to-purple-50 border-blue-200 h-full">
            <CardHeader className="px-4 sm:px-6 pt-4 sm:pt-6">
                <CardTitle className="flex flex-col sm:flex-row sm:items-center gap-2 text-base sm:text-lg">
                    <div className="flex items-center gap-2">
                        <Brain className="w-4 h-4 sm:w-5 sm:h-5 text-blue-600" />
                        <span>Enhanced AI Threat Analysis</span>
                    </div>
                    <Badge className="ml-0 sm:ml-auto text-xs bg-green-100 text-green-800 w-fit">
                        CRITICAL INFRASTRUCTURE ENHANCED
                    </Badge>
                </CardTitle>
                <CardDescription className="text-xs sm:text-sm text-blue-700">
                    Now enhanced with critical infrastructure threat intelligence from energy, transportation, and industrial control systems
                </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4 px-4 sm:px-6 pb-4 sm:pb-6">
                <div className="flex flex-col sm:flex-row gap-2">
                    <Input
                        placeholder="Enter IP address (e.g., 8.8.8.8)..."
                        value={ipAddress}
                        onChange={(e) => setIpAddress(e.target.value)}
                        onKeyPress={handleKeyPress}
                        className="text-sm"
                    />
                    <Button 
                        onClick={analyzeIP}
                        disabled={analyzing || !ipAddress}
                        className="bg-blue-600 hover:bg-blue-700 text-sm px-6 sm:px-4 whitespace-nowrap"
                    >
                        {analyzing ? (
                            <Zap className="w-3 h-3 sm:w-4 sm:h-4 animate-spin" />
                        ) : (
                            <>
                                <Brain className="w-3 h-3 sm:w-4 sm:h-4 sm:mr-2" />
                                <span className="hidden sm:inline">Analyze</span>
                            </>
                        )}
                    </Button>
                </div>

                {analyzing && (
                    <motion.div 
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="text-center py-6 bg-blue-50 rounded-lg border border-blue-200"
                    >
                        <Zap className="w-6 h-6 sm:w-8 sm:h-8 text-blue-600 mx-auto mb-2 animate-spin" />
                        <div className="text-blue-600 font-semibold text-sm sm:text-base">Enhanced AI Analysis in Progress...</div>
                        <div className="text-xs sm:text-sm text-gray-500 mt-1">Cross-referencing with critical infrastructure threat intelligence...</div>
                    </motion.div>
                )}

                {result && !result.error && (
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="bg-white rounded-lg p-4 border space-y-3"
                    >
                        <div className="flex flex-col sm:flex-row sm:justify-between sm:items-start gap-3">
                            <div>
                                <div className="font-semibold text-base sm:text-lg flex flex-col sm:flex-row sm:items-center gap-2">
                                    <span>{result.ip}</span>
                                    {result.isWhitelisted && (
                                        <Badge className="bg-green-100 text-green-800 w-fit">
                                            <Shield className="w-3 h-3 mr-1" />
                                            WHITELISTED
                                        </Badge>
                                    )}
                                </div>
                                <div className="flex items-center gap-2 text-sm text-gray-600 mt-1">
                                    <MapPin className="w-3 h-3" />
                                    {result.country}
                                </div>
                            </div>
                            <div className="text-left sm:text-right">
                                <Badge className={result.isThreat ? "bg-red-100 text-red-800" : "bg-green-100 text-green-800"}>
                                    {result.isThreat ? "HIGH RISK" : "LOW RISK"}
                                </Badge>
                                <div className="text-sm text-gray-500 mt-1">
                                    Risk Score: {result.riskScore}/100
                                </div>
                            </div>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                            <div>
                                <div className="text-gray-500">ISP:</div>
                                <div className="font-medium flex items-center gap-1 break-all">
                                    <Fingerprint className="w-3 h-3 text-gray-400 flex-shrink-0"/>
                                    {result.isp || "Unknown"}
                                </div>
                            </div>
                            <div>
                                <div className="text-gray-500">Usage Type:</div>
                                <div className="font-medium">{result.usageType || "Unknown"}</div>
                            </div>
                            <div>
                                <div className="text-gray-500">Abuse Reports:</div>
                                <div className="font-medium text-red-600">{result.abuseReports || 0}</div>
                            </div>
                            <div>
                                <div className="text-gray-500">Last Reported:</div>
                                <div className="font-medium">
                                    {result.lastReported ? new Date(result.lastReported).toLocaleDateString() : "Never"}
                                </div>
                            </div>
                        </div>

                        {result.criticalInfraContext && (
                            <div className="bg-red-50 p-3 rounded-lg border border-red-200">
                                <h4 className="font-semibold text-red-800 mb-2 flex items-center gap-2">
                                    <Shield className="w-4 h-4" />
                                    Critical Infrastructure Risk Assessment
                                </h4>
                                <div className="space-y-2 text-sm text-red-700">
                                    {result.criticalInfraContext.energySectorThreat && (
                                        <div className="flex items-center gap-2">
                                            <Zap className="w-3 h-3" />
                                            High risk to energy and utility sectors
                                        </div>
                                    )}
                                    {result.criticalInfraContext.transportationRisk && (
                                        <div className="flex items-center gap-2">
                                            <Building className="w-3 h-3" />
                                            Potential transportation system threat
                                        </div>
                                    )}
                                    {result.criticalInfraContext.industrialTargeting && (
                                        <div className="flex items-center gap-2">
                                            <Factory className="w-3 h-3" />
                                            Industrial control system targeting detected
                                        </div>
                                    )}
                                </div>
                            </div>
                        )}

                        <div>
                            <div className="text-sm text-gray-500 mb-1">Risk Analysis:</div>
                            <div className="space-y-1">
                                {result.riskFactors && result.riskFactors.map((factor, index) => (
                                    <div key={index} className="flex items-center gap-2 text-sm">
                                        {result.isThreat ? (
                                            <AlertTriangle className="w-4 h-4 text-red-500" />
                                        ) : (
                                            <CheckCircle className="w-4 h-4 text-green-500" />
                                        )}
                                        <span>{factor}</span>
                                    </div>
                                ))}
                            </div>
                        </div>

                        <div className="flex items-center gap-1 text-xs text-gray-500 pt-2 border-t">
                            <Brain className="w-3 h-3" />
                            Enhanced with Critical Infrastructure AI • Confidence: {result.confidence}% • Multi-Sector Analysis
                        </div>
                    </motion.div>
                )}

                {result && result.error && (
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="bg-red-50 rounded-lg p-4 border border-red-200"
                    >
                        <div className="flex items-center gap-2 text-red-700">
                            <AlertTriangle className="w-4 h-4" />
                            {result.error}
                        </div>
                        <div className="text-xs text-red-600 mt-2">
                            Debug: Check that the checkIPReputation function is properly deployed
                        </div>
                    </motion.div>
                )}
            </CardContent>
        </Card>
    );
}
