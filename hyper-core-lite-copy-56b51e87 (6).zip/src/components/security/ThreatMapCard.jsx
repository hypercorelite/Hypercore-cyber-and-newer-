import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, Shield, Globe } from "lucide-react";

export default function ThreatMapCard() {
    const [threatCount, setThreatCount] = useState(0);
    const [blockedThreats, setBlockedThreats] = useState(0);

    useEffect(() => {
        // Simulate real-time threat data
        const interval = setInterval(() => {
            setThreatCount(prev => prev + Math.floor(Math.random() * 3));
            setBlockedThreats(prev => prev + Math.floor(Math.random() * 5));
        }, 3000);

        return () => clearInterval(interval);
    }, []);

    return (
        <Card className="bg-gradient-to-br from-red-50 to-orange-50 border-red-200">
            <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="text-lg font-semibold flex items-center gap-2">
                    <Globe className="w-5 h-5 text-red-600" />
                    Global Threat Map
                </CardTitle>
                <Badge variant="destructive" className="animate-pulse">
                    LIVE
                </Badge>
            </CardHeader>
            <CardContent>
                <div className="grid grid-cols-2 gap-4">
                    <div className="text-center">
                        <div className="text-2xl font-bold text-red-600">{threatCount}</div>
                        <div className="text-sm text-gray-600 flex items-center justify-center gap-1">
                            <AlertTriangle className="w-3 h-3" />
                            Active Threats
                        </div>
                    </div>
                    <div className="text-center">
                        <div className="text-2xl font-bold text-green-600">{blockedThreats}</div>
                        <div className="text-sm text-gray-600 flex items-center justify-center gap-1">
                            <Shield className="w-3 h-3" />
                            Blocked Today
                        </div>
                    </div>
                </div>
                <div className="mt-4 h-32 bg-gray-900 rounded-lg relative overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-r from-red-500/20 to-orange-500/20 animate-pulse" />
                    <div className="absolute top-2 left-2 text-green-400 text-xs font-mono">
                        AI MONITORING ACTIVE
                    </div>
                    <div className="absolute bottom-2 right-2 text-red-400 text-xs font-mono">
                        {threatCount} THREATS DETECTED
                    </div>
                </div>
            </CardContent>
        </Card>
    );
}