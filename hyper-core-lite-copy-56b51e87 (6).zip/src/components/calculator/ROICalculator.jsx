
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { DollarSign, Clock, Shield, TrendingUp, CheckCircle, AlertTriangle } from 'lucide-react';
import { motion } from 'framer-motion';

const ROICalculator = ({ embedded = false }) => {
    const [companySize, setCompanySize] = useState('50');
    const [subcontractors, setSubcontractors] = useState('1');
    const [timeline, setTimeline] = useState('urgent');

    // Base costs
    const hyperCoreBase = 17000; // $5K setup + $12K service
    const consultantBase = 75000;
    const grcPlatformBase = 24000; // Annual subscription

    // Calculate multipliers based on inputs
    const sizeMultiplier = companySize <= 25 ? 1 : companySize <= 100 ? 1.2 : 1.5;
    const subMultiplier = parseInt(subcontractors);
    const timelineMultiplier = timeline === 'urgent' ? 1.3 : timeline === 'standard' ? 1 : 0.8;

    const hyperCoreTotal = Math.round(hyperCoreBase * sizeMultiplier);
    const consultantTotal = Math.round(consultantBase * sizeMultiplier * timelineMultiplier);
    const grcTotal = Math.round(grcPlatformBase * sizeMultiplier + (consultantBase * 0.5)); // GRC + implementation help

    const savings = consultantTotal - hyperCoreTotal;
    const savingsPercent = Math.round((savings / consultantTotal) * 100);
    const roi = Math.round((savings / hyperCoreTotal) * 100);

    const timelineMap = {
        urgent: { hypercore: '90 days', consultant: '12-18 months', grc: '12-24 months' },
        standard: { hypercore: '90 days', consultant: '6-12 months', grc: '9-15 months' },
        flexible: { hypercore: '90 days', consultant: '4-8 months', grc: '6-12 months' }
    };

    const fcaRisk = 4600000; // $4.6M FCA risk

    const ComparisonCard = ({ title, cost, timeline, accuracy, guarantee, bgColor, textColor, icon: Icon }) => (
        <Card className={`${bgColor} ${textColor} border-2`}>
            <CardHeader>
                <CardTitle className="flex items-center gap-2">
                    <Icon className="w-5 h-5" />
                    {title}
                </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
                <div className="text-2xl font-bold">${cost.toLocaleString()}</div>
                <div className="space-y-2 text-sm">
                    <div><strong>Timeline:</strong> {timeline}</div>
                    <div><strong>Accuracy:</strong> {accuracy}</div>
                    <div><strong>Guarantee:</strong> {guarantee}</div>
                </div>
            </CardContent>
        </Card>
    );

    return (
        <div className={embedded ? '' : 'max-w-6xl mx-auto p-6'}>
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-8"
            >
                {!embedded && (
                    <div className="text-center">
                        <h1 className="text-3xl font-bold text-gray-900 mb-4">
                            HyperCore ROI Calculator
                        </h1>
                        <p className="text-lg text-gray-600">
                            Calculate your savings vs traditional consultants and GRC platforms - built for the entire DIB supply chain
                        </p>
                    </div>
                )}

                {/* Input Controls */}
                <Card className="bg-blue-50 border-blue-200">
                    <CardHeader>
                        <CardTitle className="text-blue-800">Your Organization Details</CardTitle>
                    </CardHeader>
                    <CardContent className="grid md:grid-cols-3 gap-4">
                        <div>
                            <Label>Organization Type</Label>
                            <Select value={companySize} onValueChange={setCompanySize}>
                                <SelectTrigger>
                                    <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="10">Small Contractor (1-50 employees)</SelectItem>
                                    <SelectItem value="150">Mid-Size Contractor (51-200 employees)</SelectItem>
                                    <SelectItem value="500">Large Contractor/Prime (200+ employees)</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                        <div>
                            <Label>Supply Chain Position</Label>
                            <Select value={subcontractors} onValueChange={setSubcontractors}>
                                <SelectTrigger>
                                    <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="1">Subcontractor Only</SelectItem>
                                    <SelectItem value="3">Prime with 2-10 Subs</SelectItem>
                                    <SelectItem value="8">Prime with 10+ Subs</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                        <div>
                            <Label>Timeline Urgency</Label>
                            <Select value={timeline} onValueChange={setTimeline}>
                                <SelectTrigger>
                                    <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="urgent">URGENT (Nov 10 DFARS)</SelectItem>
                                    <SelectItem value="standard">Standard</SelectItem>
                                    <SelectItem value="flexible">Flexible</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                    </CardContent>
                </Card>

                {/* ROI Summary */}
                <div className="grid md:grid-cols-4 gap-4">
                    <Card className="bg-green-50 border-green-200 text-center">
                        <CardContent className="p-6">
                            <DollarSign className="w-8 h-8 text-green-600 mx-auto mb-2" />
                            <div className="text-2xl font-bold text-green-700">
                                ${savings.toLocaleString()}
                            </div>
                            <div className="text-sm text-green-600">Total Savings</div>
                        </CardContent>
                    </Card>
                    <Card className="bg-blue-50 border-blue-200 text-center">
                        <CardContent className="p-6">
                            <TrendingUp className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                            <div className="text-2xl font-bold text-blue-700">
                                {roi}%
                            </div>
                            <div className="text-sm text-blue-600">ROI</div>
                        </CardContent>
                    </Card>
                    <Card className="bg-purple-50 border-purple-200 text-center">
                        <CardContent className="p-6">
                            <Clock className="w-8 h-8 text-purple-600 mx-auto mb-2" />
                            <div className="text-2xl font-bold text-purple-700">
                                9 months
                            </div>
                            <div className="text-sm text-purple-600">Time Saved</div>
                        </CardContent>
                    </Card>
                    <Card className="bg-red-50 border-red-200 text-center">
                        <CardContent className="p-6">
                            <Shield className="w-8 h-8 text-red-600 mx-auto mb-2" />
                            <div className="text-2xl font-bold text-red-700">
                                ${(fcaRisk/1000000).toFixed(1)}M
                            </div>
                            <div className="text-sm text-red-600">FCA Risk Avoided</div>
                        </CardContent>
                    </Card>
                </div>

                {/* Detailed Comparison */}
                <div className="grid lg:grid-cols-3 gap-6">
                    <ComparisonCard
                        title="HyperCore AI"
                        cost={hyperCoreTotal}
                        timeline={timelineMap[timeline].hypercore}
                        accuracy="85-95%"
                        guarantee="90-day money-back"
                        bgColor="bg-green-50 border-green-600"
                        textColor="text-green-800"
                        icon={CheckCircle}
                    />
                    <ComparisonCard
                        title="Traditional Consultant"
                        cost={consultantTotal}
                        timeline={timelineMap[timeline].consultant}
                        accuracy="90%"
                        guarantee="None"
                        bgColor="bg-red-50 border-red-600"
                        textColor="text-red-800"
                        icon={AlertTriangle}
                    />
                    <ComparisonCard
                        title="GRC Platform + Help"
                        cost={grcTotal}
                        timeline={timelineMap[timeline].grc}
                        accuracy="Depends on user"
                        guarantee="Platform access only"
                        bgColor="bg-yellow-50 border-yellow-600"
                        textColor="text-yellow-800"
                        icon={DollarSign}
                    />
                </div>

                {/* Key Advantages */}
                <Card className="bg-gradient-to-r from-green-50 to-blue-50 border-green-200">
                    <CardHeader>
                        <CardTitle className="text-green-800">Why HyperCore Wins</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="grid md:grid-cols-2 gap-4">
                            <div className="space-y-3">
                                <div className="flex items-center gap-2">
                                    <CheckCircle className="w-5 h-5 text-green-600" />
                                    <span><strong>Fixed pricing:</strong> No hourly surprises</span>
                                </div>
                                <div className="flex items-center gap-2">
                                    <CheckCircle className="w-5 h-5 text-green-600" />
                                    <span><strong>90-day guarantee:</strong> ${hyperCoreTotal.toLocaleString()} risk-free trial</span>
                                </div>
                                <div className="flex items-center gap-2">
                                    <CheckCircle className="w-5 h-5 text-green-600" />
                                    <span><strong>Proven timeline:</strong> 90 days vs 6+ months</span>
                                </div>
                            </div>
                            <div className="space-y-3">
                                <div className="flex items-center gap-2">
                                    <CheckCircle className="w-5 h-5 text-green-600" />
                                    <span><strong>AI-powered:</strong> Eliminates human error</span>
                                </div>
                                <div className="flex items-center gap-2">
                                    <CheckCircle className="w-5 h-5 text-green-600" />
                                    <span><strong>Complete package:</strong> SSP, policies, training</span>
                                </div>
                                <div className="flex items-center gap-2">
                                    <CheckCircle className="w-5 h-5 text-green-600" />
                                    <span><strong>FCA protection:</strong> Same risk mitigation as consultants</span>
                                </div>
                            </div>
                        </div>
                    </CardContent>
                </Card>

                {!embedded && (
                    <div className="text-center">
                        <Button size="lg" className="bg-green-600 hover:bg-green-700 text-lg px-8">
                            Start Your ${hyperCoreTotal.toLocaleString()} Risk-Free Trial
                        </Button>
                        <p className="text-sm text-gray-600 mt-2">
                            90-day money-back guarantee • No setup fees • Complete CMMC package
                        </p>
                    </div>
                )}
            </motion.div>
        </div>
    );
};

export default ROICalculator;
