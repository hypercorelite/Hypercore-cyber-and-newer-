import React, { useState } from 'react';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import { Button } from '@/components/ui/button';
import { Download, Eye } from 'lucide-react';

// Sample CMMC JSON data (SSP excerpt for SMB)
const cmmcJsonData = {
  "system": {
    "name": "CUI Processing Network",
    "organization": "ABC Defense Tech, Inc.",
    "complianceLevel": "Level 2",
    "score": "105/110",
    "date": new Date().toLocaleDateString()
  },
  "controls": [
    {
      "id": "AC.L2-3.1.1",
      "domain": "Access Control",
      "description": "Limit system access to authorized users.",
      "status": "Met",
      "evidence": "AD logs, MFA config"
    },
    {
      "id": "AU.L1-3.3.1",
      "domain": "Audit and Accountability",
      "description": "Create audit records.",
      "status": "Not Met",
      "evidence": "SIEM config pending"
    },
    {
      "id": "IR.L2-3.6.1",
      "domain": "Incident Response",
      "description": "Establish an incident-handling capability.",
      "status": "Met",
      "evidence": "IR Plan v1.2"
    },
    {
      "id": "SC.L1-3.13.1",
      "domain": "System & Comm Protection",
      "description": "Monitor, control, and protect communications.",
      "status": "Met",
      "evidence": "Firewall ruleset, Network Diagram"
    }
  ]
};

// Function to generate PDF from JSON
async function generateCmmcPdf(data, action = 'save') {
  const doc = new jsPDF();

  // Title
  doc.setFontSize(20);
  doc.text('CMMC Compliance Report', 20, 20);
  doc.setFontSize(12);
  doc.text(`Organization: ${data.system.organization}`, 20, 35);
  doc.text(`System: ${data.system.name}`, 20, 45);
  doc.text(`Level: ${data.system.complianceLevel}`, 20, 55);
  doc.text(`Score: ${data.system.score}`, 20, 65);
  doc.text(`Generated: ${data.system.date}`, 20, 75);

  // Controls Table
  const tableData = data.controls.map(control => [
      control.id,
      control.domain,
      control.description,
      control.status,
      control.evidence
  ]);

  autoTable(doc, {
    head: [['ID', 'Domain', 'Description', 'Status', 'Evidence']],
    body: tableData,
    startY: 90,
    theme: 'grid',
    styles: { fontSize: 8 },
    headStyles: { fillColor: [41, 128, 185] }
  });

  if (action === 'datauristring') {
      return doc.output('datauristring');
  }
  
  doc.save('CMMC_Compliance_Report.pdf');
  return null;
}

export default function ReportGeneratorComponent() {
    const [pdfUri, setPdfUri] = useState(null);

    const handleGenerate = async () => {
        const uri = await generateCmmcPdf(cmmcJsonData, 'datauristring');
        setPdfUri(uri);
    };

    return (
        <div className="space-y-4">
            <Button onClick={handleGenerate}>
                <Download className="w-4 h-4 mr-2" />
                Generate Sample CMMC Report PDF
            </Button>

            {pdfUri && (
                <div className="mt-6">
                    <h3 className="font-semibold mb-2 flex items-center gap-2"><Eye className="w-5 h-5"/>PDF Preview</h3>
                    <iframe
                        src={pdfUri}
                        className="w-full h-96 rounded-md border"
                        title="PDF Preview"
                    ></iframe>
                    <a href={pdfUri} download="CMMC_Compliance_Report.pdf" className="text-blue-600 hover:underline mt-2 inline-block">
                        Download again
                    </a>
                </div>
            )}
        </div>
    );
}