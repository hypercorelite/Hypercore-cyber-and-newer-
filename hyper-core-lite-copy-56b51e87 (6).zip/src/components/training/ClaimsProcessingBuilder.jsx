import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowRight } from 'lucide-react';

const WEEKLY_PLAN = {
    week1: { title: "Data Intake", tasks: ["Build a pipeline to process claim forms (PDF, JSON)", "Use OCR to extract data from scanned documents", "Normalize data into a standard claims schema"] },
    week2: { title: "Business Rules", tasks: ["Implement a rules engine for basic validation (e.g., policy active, coverage match)", "Automate assignment of claims to adjusters", "Create initial fraud flags based on simple rules"] },
    week3: { title: "AI Damage Assessment", tasks: ["Train a computer vision model to assess damage from photos (e.g., car dents)", "Use an LLM to summarize adjuster notes and claimant statements", "Estimate initial claim value based on historical data"] },
    week4: { title: "API & Adjuster UI", tasks: ["Create an API to submit a new claim for processing", "Build a dashboard for adjusters to review AI-processed claims", "Highlight AI suggestions and fraud warnings"] },
    week5: { title: "Pilot Program", tasks: ["Process 100 historical claims through the system", "Compare AI results with human outcomes for accuracy", "Demonstrate 80% reduction in manual processing time"] }
};

const CODE_SNIPPET = `# Core Claim Triage Logic (Python)
def triage_claim(claim_data):
    # Basic validation
    if not is_policy_active(claim_data['policy_id']):
        return {"status": "rejected", "reason": "Inactive policy"}
    
    # AI-powered fraud score
    fraud_score = fraud_model.predict(claim_data)
    if fraud_score > 0.8:
        return {"status": "review_needed", "reason": "High fraud risk"}
        
    # AI-powered damage estimate
    estimated_cost = damage_estimator.predict(claim_data['photos'])
    
    return {
        "status": "approved_for_payment",
        "estimated_value": estimated_cost,
        "fraud_score": fraud_score
    }
`;

export default function ClaimsProcessingBuilder() {
    return (
        <Card className="bg-white border-gray-200 mt-6">
            <CardHeader>
                <CardTitle>AI Asset: AI Claims Processing Engine</CardTitle>
                <CardDescription>Reduces claims processing costs by up to 80% through automation. <span className="font-semibold text-blue-700">A foundational tool for any modern insurance carrier.</span></CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
                <h4 className="font-semibold">5-Week Build Plan</h4>
                <div className="grid grid-cols-1 md:grid-cols-5 gap-2">
                    {Object.values(WEEKLY_PLAN).map((week, index) => (
                        <Card key={index} className="bg-gray-50 p-3"><CardTitle className="text-xs font-bold mb-1">{week.title}</CardTitle><ul className="list-disc pl-3 text-xs space-y-1 text-gray-600">{week.tasks.map((task, i) => <li key={i}>{task}</li>)}</ul></Card>
                    ))}
                </div>
                <div>
                    <h4 className="font-semibold mb-2">Core Technology Snippet</h4>
                    <Card className="bg-slate-900 text-white font-mono"><CardContent className="p-3"><pre className="overflow-x-auto text-xs"><code>{CODE_SNIPPET}</code></pre></CardContent></Card>
                </div>
            </CardContent>
        </Card>
    );
}