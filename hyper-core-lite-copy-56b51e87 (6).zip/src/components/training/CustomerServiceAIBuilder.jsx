import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowRight } from 'lucide-react';

const WEEKLY_PLAN = {
    week1: { title: "Knowledge Base", tasks: ["Ingest all policy documents, FAQs, and help articles", "Create vector embeddings for the entire knowledge base", "Set up a RAG pipeline for answering questions"] },
    week2: { title: "Chatbot Core", tasks: ["Build a basic chatbot interface", "Integrate the RAG pipeline to answer user questions", "Implement conversation history management"] },
    week3: { title: "Tool Integration", tasks: ["Give the AI tools to perform actions (e.g., 'check claim status')", "Create API connections to backend systems for policy data", "Implement secure handling of policyholder PII"] },
    week4: { title: "Escalation Path", tasks: ["Develop logic to detect when the AI is failing", "Implement a seamless handoff to a human agent", "Provide human agents with the full chat transcript for context"] },
    week5: { title: "Deployment", tasks: ["Deploy the chatbot widget on a test website", "Measure 'deflection rate' (how many queries are solved without a human)", "Target a 40% deflection rate for pilot launch"] }
};

const CODE_SNIPPET = `# Core Tool-Using AI Logic (Python)
def process_user_message(message, user_id):
    # First, try to answer from the knowledge base
    answer = rag_pipeline.query(message)
    
    # If the answer suggests an action, use a tool
    if "check the status of your claim" in answer.lower():
        claim_status = tools.get_claim_status(user_id)
        return f"Your claim status is: {claim_status}"
        
    # If AI is not confident, escalate
    if answer.confidence < 0.7:
        return tools.escalate_to_human(user_id, message)
        
    return answer.text
`;

export default function CustomerServiceAIBuilder() {
    return (
        <Card className="bg-white border-gray-200 mt-6">
            <CardHeader>
                <CardTitle>AI Asset: Insurance Customer Service AI</CardTitle>
                <CardDescription>Automates 40% of customer inquiries, reducing call center costs significantly. <span className="font-semibold text-blue-700">Improves customer satisfaction and operational efficiency.</span></CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
                <h4 className="font-semibold">5-Week Build Plan</h4>
                <div className="grid grid-cols-1 md:grid-cols-5 gap-2">
                    {Object.values(WEEKLY_PLAN).map((week, index) => (
                        <Card key={index} className="bg-gray-50 p-3"><CardTitle className="text-xs font-bold mb-1">{week.title}</CardTitle><ul className="list-disc pl-3 text-xs space-y-1 text-gray-600">{week.tasks.map((task, i) => <li key={i}>{task}</li>)}</ul></Card>
                    ))}
                </div>
                <div>
                    <h4 className="font-semibold mb-2">Core Technology Snippet</h4>
                    <Card className="bg-slate-900 text-white font-mono"><CardContent className="p-3"><pre className="overflow-x-auto text-xs"><code>{CODE_SNIPPET}</code></pre></CardContent></Card>
                </div>
            </CardContent>
        </Card>
    );
}