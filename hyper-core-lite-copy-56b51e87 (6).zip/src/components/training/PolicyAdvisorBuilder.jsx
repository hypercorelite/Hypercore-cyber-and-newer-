import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
    Umbrella, 
    FileText,
    CheckCircle,
    ArrowRight
} from 'lucide-react';

const WEEKLY_PLAN = {
    week1: {
        title: "Week 1: Data Acquisition",
        goal: "Collect and parse thousands of insurance policies and public breach cost data.",
        tasks: ["Scrape 50+ carrier policy templates (PDFs)", "Extract coverage clauses, limits, and exclusions", "Collect industry risk benchmarks (e.g., IBM Cost of a Breach Report)", "Normalize all data into a structured format"]
    },
    week2: {
        title: "Week 2: Risk Modeling Engine",
        goal: "Build the core logic to quantify a company's specific cyber risk.",
        tasks: ["Develop a risk-scoring algorithm based on industry, size, and tech stack", "Create a financial model to estimate potential loss for different breach types", "Integrate compliance posture (e.g., CMMC) as a risk-reducing factor"]
    },
    week3: {
        title: "Week 3: Coverage Optimization AI",
        goal: "Train an AI to recommend the most efficient insurance coverage.",
        tasks: ["Use historical claims data to train a model that predicts loss ratios", "Develop an optimization function to find the best coverage mix for a given budget", "Generate plain-English 'Reasoning' for each recommendation"]
    },
    week4: {
        title: "Week 4: API & Partner Portal",
        goal: "Create the interface for insurance partners to use the tool.",
        tasks: ["Build a secure FastAPI endpoint for the optimization engine", "Develop a simple React-based portal for brokers to input client data", "Visualize the recommendations with charts and graphs"]
    },
    week5: {
        title: "Week 5: Testing & Partnership Launch",
        goal: "Finalize the tool and begin trading access for our own business insurance.",
        tasks: ["Validate recommendations against real-world policies", "Draft the 'Trade for Insurance' partnership agreement", "Launch outreach to 10 target insurance brokers and 3 carriers", "Secure full business insurance coverage for HyperCore AI"]
    }
};

const CODE_SNIPPET = `# Core Optimization Logic (Python/SciPy)
from scipy.optimize import minimize

def objective(coverage_limits):
    """
    Goal: Minimize the sum of the insurance premium and the remaining,
    uncovered financial risk after a potential claim.
    """
    premium = calculate_premium(coverage_limits)
    remaining_risk = calculate_post_claim_risk(coverage_limits)
    return premium + remaining_risk

# Define constraints (e.g., budget cannot exceed $X)
constraints = ({'type': 'ineq', 'fun': lambda x: budget - calculate_premium(x)})

# Run the optimization to find the best possible coverage limits
result = minimize(objective, initial_guess, constraints=constraints)

return result.x # The optimal coverage limits
`;

export default function PolicyAdvisorBuilder() {
    return (
        <Card className="bg-white border-gray-200">
            <CardHeader>
                <CardTitle className="text-2xl font-bold text-gray-900 flex items-center gap-3">
                    <Umbrella className="w-6 h-6 text-blue-600"/>
                    AI Asset: Policy Optimization Advisor
                </CardTitle>
                <CardDescription className="text-gray-600">
                    This tool analyzes a company's risk profile and recommends the most efficient cyber insurance coverage, saving clients money and increasing broker win-rates. 
                    <span className="font-semibold text-blue-700"> We trade unlimited access for our comprehensive business insurance policies.</span>
                </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
                <div>
                    <h4 className="font-semibold text-lg mb-3">5-Week Build Plan</h4>
                    <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                        {Object.values(WEEKLY_PLAN).map((week, index) => (
                            <Card key={index} className="bg-gray-50">
                                <CardHeader className="pb-2">
                                    <CardTitle className="text-sm font-bold">{week.title}</CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <ul className="list-disc pl-4 text-xs space-y-1 text-gray-700">
                                        {week.tasks.map((task, i) => <li key={i}>{task}</li>)}
                                    </ul>
                                </CardContent>
                            </Card>
                        ))}
                    </div>
                </div>
                 <div>
                    <h4 className="font-semibold text-lg mb-3">Core Technology Snippet</h4>
                     <Card className="bg-slate-900 text-white font-mono">
                         <CardContent className="p-4">
                             <pre className="overflow-x-auto text-sm"><code>{CODE_SNIPPET}</code></pre>
                         </CardContent>
                     </Card>
                </div>
                <div>
                    <Button size="lg" className="w-full bg-blue-600 hover:bg-blue-700">
                        View Detailed Technical Plan & Live Demo
                        <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                </div>
            </CardContent>
        </Card>
    );
}