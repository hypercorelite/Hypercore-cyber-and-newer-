import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
    Search, 
    Database, 
    Code, 
    Brain, 
    Users,
    CheckCircle,
    FileText,
    ArrowRight
} from 'lucide-react';

const WEEKLY_PLAN = {
    week1: {
        title: "Week 1: Data Ingestion & Pipeline",
        goal: "Establish the data pipeline from SAM.gov to reliably collect federal contract opportunities.",
        tasks: ["Develop Python client for SAM.gov API", "Set up S3 bucket for raw data storage", "Create Lambda function for daily data pulls", "Define a normalized contract data schema"]
    },
    week2: {
        title: "Week 2: Capability Scraping & NLP Prep",
        goal: "Gather company capability data and prepare all text for AI processing.",
        tasks: ["Build web scrapers for 100+ defense contractor websites", "Clean and normalize contract and capability text data", "Integrate NAICS codes for industry classification", "Set up vector database (Pinecone/FAISS)"]
    },
    week3: {
        title: "Week 3: AI Model Training (Embeddings)",
        goal: "Convert all text data into meaningful vectors and train the core matching model.",
        tasks: ["Extract key phrases and technical requirements using spaCy", "Use sentence-transformers to create vector embeddings for all documents", "Train a similarity model to match company capabilities with contract requirements", "Store all vectors in the database"]
    },
    week4: {
        title: "Week 4: API & Frontend Development",
        goal: "Build the user-facing application for legal partners.",
        tasks: ["Develop a FastAPI backend to query the vector database", "Implement authentication for partner access", "Build a React frontend for partners to input client capabilities and see matched contracts", "Display match scores and reasoning"]
    },
    week5: {
        title: "Week 5: Testing & Partner Outreach",
        goal: "Validate the tool and begin trading it for legal services.",
        tasks: ["Conduct end-to-end testing with sample law firm clients", "Refine the matching algorithm based on feedback", "Draft the 'Trade for Services' partnership agreement", "Initiate outreach to 20 target law firms"]
    }
};

const CODE_SNIPPET = `# Core Matching Logic (Python/FastAPI)
from sentence_transformers import SentenceTransformer, util

@app.post("/match-contracts")
async def match_contracts(client_capability: str, user: Partner = Depends(get_current_partner)):
    # 1. Convert client's capability statement to a vector
    client_vector = model.encode(client_capability, convert_to_tensor=True)
    
    # 2. Query the vector database for top 100 closest contracts
    # This is a highly efficient cosine-similarity search
    search_results = vector_db.query(
        vector=client_vector.tolist(),
        top_k=100,
        include_metadata=True
    )
    
    # 3. Re-rank results with business logic (e.g., contract value, NAICS code)
    ranked_results = custom_reranker(search_results, client_profile)
    
    return {"matches": ranked_results[:10]}
`;

export default function ContractIntelligenceBuilder() {
    return (
        <Card className="bg-white border-gray-200">
            <CardHeader>
                <CardTitle className="text-2xl font-bold text-gray-900 flex items-center gap-3">
                    <Search className="w-6 h-6 text-purple-600"/>
                    AI Asset: Contract Opportunity Intelligence
                </CardTitle>
                <CardDescription className="text-gray-600">
                    This tool finds perfect-match federal contracts for a law firm's clients, eliminating hundreds of hours of manual search. 
                    <span className="font-semibold text-purple-700"> We trade unlimited access for comprehensive legal services.</span>
                </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
                <div>
                    <h4 className="font-semibold text-lg mb-3">5-Week Build Plan</h4>
                    <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                        {Object.values(WEEKLY_PLAN).map((week, index) => (
                            <Card key={index} className="bg-gray-50">
                                <CardHeader className="pb-2">
                                    <CardTitle className="text-sm font-bold">{week.title}</CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <ul className="list-disc pl-4 text-xs space-y-1 text-gray-700">
                                        {week.tasks.map((task, i) => <li key={i}>{task}</li>)}
                                    </ul>
                                </CardContent>
                            </Card>
                        ))}
                    </div>
                </div>
                 <div>
                    <h4 className="font-semibold text-lg mb-3">Core Technology Snippet</h4>
                     <Card className="bg-slate-900 text-white font-mono">
                         <CardContent className="p-4">
                             <pre className="overflow-x-auto text-sm"><code>{CODE_SNIPPET}</code></pre>
                         </CardContent>
                     </Card>
                </div>
                <div>
                    <Button size="lg" className="w-full bg-purple-600 hover:bg-purple-700">
                        View Detailed Technical Plan & Live Demo
                        <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                </div>
            </CardContent>
        </Card>
    );
}