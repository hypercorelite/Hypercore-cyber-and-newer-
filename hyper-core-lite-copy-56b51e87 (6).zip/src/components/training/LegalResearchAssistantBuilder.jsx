import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowRight } from 'lucide-react';

const WEEKLY_PLAN = {
    week1: { title: "Data Ingestion", tasks: ["Integrate with public legal APIs (CourtListener)", "Set up pipeline to ingest and normalize case law data", "Store documents in a searchable format"] },
    week2: { title: "Vector Database", tasks: ["Use sentence-transformers to create vector embeddings for all legal documents", "Set up and populate a vector database (e.g., Pinecone/FAISS)", "Index documents for efficient similarity search"] },
    week3: { title: "RAG Pipeline", tasks: ["Implement Retrieval-Augmented Generation (RAG) logic", "Build prompt templates to ask questions of the legal data", "Develop function to retrieve relevant documents and feed to an LLM for answers"] },
    week4: { title: "API & Frontend", tasks: ["Create a secure API endpoint for legal queries", "Build a simple React UI for natural language questions", "Display AI-generated answers with citations to source documents"] },
    week5: { title: "Testing & Validation", tasks: ["Test against 50 common legal research questions", "Validate citations and answer accuracy with a partner", "Refine prompts and retrieval logic based on feedback"] }
};

const CODE_SNIPPET = `# Core RAG Logic (Python/FastAPI)
@app.post("/legal-query")
async def legal_query(question: str):
    # 1. Vectorize the user's question
    question_vector = model.encode(question)
    
    # 2. Retrieve relevant legal documents from vector DB
    retrieved_docs = vector_db.query(question_vector, top_k=5)
    
    # 3. Construct a prompt for the LLM
    prompt = f"""
    Context: {retrieved_docs}
    Question: {question}
    Answer based only on the context provided.
    """
    
    # 4. Get the final answer from the LLM
    answer = llm.generate(prompt)
    return {"answer": answer, "sources": retrieved_docs}
`;

export default function LegalResearchAssistantBuilder() {
    return (
        <Card className="bg-white border-gray-200 mt-6">
            <CardHeader>
                <CardTitle>AI Asset: Legal Research Assistant</CardTitle>
                <CardDescription>Reduces junior associate research time by 60%, saving firms over $8K/month. <span className="font-semibold text-purple-700">We trade access for specialized legal counsel.</span></CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
                <h4 className="font-semibold">5-Week Build Plan</h4>
                <div className="grid grid-cols-1 md:grid-cols-5 gap-2">
                    {Object.values(WEEKLY_PLAN).map((week, index) => (
                        <Card key={index} className="bg-gray-50 p-3"><CardTitle className="text-xs font-bold mb-1">{week.title}</CardTitle><ul className="list-disc pl-3 text-xs space-y-1 text-gray-600">{week.tasks.map((task, i) => <li key={i}>{task}</li>)}</ul></Card>
                    ))}
                </div>
                <div>
                    <h4 className="font-semibold mb-2">Core Technology Snippet</h4>
                    <Card className="bg-slate-900 text-white font-mono"><CardContent className="p-3"><pre className="overflow-x-auto text-xs"><code>{CODE_SNIPPET}</code></pre></CardContent></Card>
                </div>
            </CardContent>
        </Card>
    );
}