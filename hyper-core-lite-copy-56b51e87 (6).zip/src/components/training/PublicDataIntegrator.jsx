import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Download, Upload, CheckCircle, AlertCircle, Loader2 } from 'lucide-react';
import { toast } from "sonner";

import { importPublicSecurityData } from "@/api/functions";

export default function PublicDataIntegrator() {
    const [importing, setImporting] = useState(false);
    const [progress, setProgress] = useState(0);
    const [lastImport, setLastImport] = useState(null);

    const dataSources = [
        { id: 'nist_800_171', name: 'NIST SP 800-171', status: 'ready', records: 2847 },
        { id: 'cmmc_guides', name: 'CMMC Assessment Guides', status: 'ready', records: 1203 },
        { id: 'cve_database', name: 'CVE Vulnerability Database', status: 'ready', records: 45678 },
        { id: 'aws_security', name: 'AWS Security Best Practices', status: 'ready', records: 892 },
        { id: 'ms_gcc_high', name: 'Microsoft GCC High Guidelines', status: 'ready', records: 567 }
    ];

    const handleImportData = async (sourceId) => {
        setImporting(true);
        setProgress(0);
        
        try {
            // Simulate progress updates
            const progressInterval = setInterval(() => {
                setProgress(prev => {
                    if (prev >= 90) {
                        clearInterval(progressInterval);
                        return prev;
                    }
                    return prev + Math.random() * 15;
                });
            }, 500);

            const result = await importPublicSecurityData({ 
                source: sourceId,
                include_vulnerabilities: true,
                update_models: true 
            });

            clearInterval(progressInterval);
            setProgress(100);
            
            setLastImport({
                source: sourceId,
                timestamp: new Date(),
                recordsProcessed: result.data?.records_processed || 0,
                modelsUpdated: result.data?.models_updated || []
            });

            toast.success(`Successfully imported ${result.data?.records_processed || 0} records from ${sourceId}`);
            
        } catch (error) {
            toast.error(`Failed to import data: ${error.message}`);
        } finally {
            setImporting(false);
            setTimeout(() => setProgress(0), 2000);
        }
    };

    return (
        <div className="space-y-6">
            <Alert>
                <Download className="h-4 w-4" />
                <AlertDescription>
                    This system automatically imports and processes public cybersecurity data to train our AI models. 
                    All data sources are publicly available and regularly updated.
                </AlertDescription>
            </Alert>

            <div className="grid gap-4">
                {dataSources.map((source) => (
                    <Card key={source.id}>
                        <CardContent className="p-4">
                            <div className="flex justify-between items-center">
                                <div>
                                    <h3 className="font-medium">{source.name}</h3>
                                    <p className="text-sm text-gray-600">{source.records.toLocaleString()} records available</p>
                                </div>
                                <div className="flex items-center gap-3">
                                    <Badge 
                                        className={source.status === 'ready' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}
                                    >
                                        <CheckCircle className="w-3 h-3 mr-1" />
                                        {source.status}
                                    </Badge>
                                    <Button 
                                        onClick={() => handleImportData(source.id)}
                                        disabled={importing}
                                        size="sm"
                                    >
                                        {importing ? (
                                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                        ) : (
                                            <Upload className="w-4 h-4 mr-2" />
                                        )}
                                        Import
                                    </Button>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                ))}
            </div>

            {importing && (
                <Card>
                    <CardHeader>
                        <CardTitle className="text-lg">Importing Public Data...</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <Progress value={progress} className="mb-2" />
                        <p className="text-sm text-gray-600">{Math.round(progress)}% complete</p>
                    </CardContent>
                </Card>
            )}

            {lastImport && (
                <Card className="bg-green-50 border-green-200">
                    <CardContent className="p-4">
                        <div className="flex items-center gap-2 mb-2">
                            <CheckCircle className="w-4 h-4 text-green-600" />
                            <h3 className="font-medium text-green-800">Last Import Successful</h3>
                        </div>
                        <div className="text-sm text-green-700">
                            <p>Source: {lastImport.source}</p>
                            <p>Records Processed: {lastImport.recordsProcessed.toLocaleString()}</p>
                            <p>Models Updated: {lastImport.modelsUpdated.join(', ')}</p>
                            <p>Completed: {lastImport.timestamp.toLocaleString()}</p>
                        </div>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}