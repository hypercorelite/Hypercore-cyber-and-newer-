import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowRight } from 'lucide-react';

const WEEKLY_PLAN = {
    week1: { title: "Framework Ingestion", tasks: ["Ingest compliance frameworks (e.g., SOC 2, HIPAA) as structured data", "Map controls to evidence types", "Create templates for evidence collection"] },
    week2: { title: "Evidence Collection", tasks: ["Build connectors to cloud services (AWS, Azure) to pull configuration data", "Create a secure evidence upload portal for documents", "Tag all evidence against a specific control"] },
    week3: { title: "AI Control Testing", tasks: ["Develop scripts to automatically test technical controls (e.g., 'Is MFA enabled?')", "Use an LLM to analyze policy documents for required clauses", "Generate a pass/fail status for each control"] },
    week4: { title: "Report Generation", tasks: ["Build a generator for the final compliance report (PDF)", "Automatically populate the report with control status and evidence links", "Create a dashboard showing overall compliance posture"] },
    week5: { title: "Auditor View", tasks: ["Create a read-only 'Auditor Mode' for third-party review", "Allow auditors to comment on and approve evidence", "Demonstrate a 70% reduction in manual audit preparation time"] }
};

const CODE_SNIPPET = `# Core Control Testing Logic (Python)
def test_soc2_cc6_1(aws_client):
    # Test if MFA is enabled for all IAM users
    response = aws_client.list_users()
    for user in response['Users']:
        mfa_devices = aws_client.list_mfa_devices(UserName=user['UserName'])
        if not mfa_devices['MFADevices']:
            return {"control": "CC6.1", "status": "FAIL", "reason": f"User {user['UserName']} lacks MFA."}
            
    return {"control": "CC6.1", "status": "PASS"}
`;

export default function ComplianceReportingBuilder() {
    return (
        <Card className="bg-white border-gray-200 mt-6">
            <CardHeader>
                <CardTitle>AI Asset: Compliance Reporting Automation</CardTitle>
                <CardDescription>Reduces audit preparation time by 70% by automating evidence collection and control testing. <span className="font-semibold text-blue-700">A must-have for any regulated company.</span></CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
                <h4 className="font-semibold">5-Week Build Plan</h4>
                <div className="grid grid-cols-1 md:grid-cols-5 gap-2">
                    {Object.values(WEEKLY_PLAN).map((week, index) => (
                        <Card key={index} className="bg-gray-50 p-3"><CardTitle className="text-xs font-bold mb-1">{week.title}</CardTitle><ul className="list-disc pl-3 text-xs space-y-1 text-gray-600">{week.tasks.map((task, i) => <li key={i}>{task}</li>)}</ul></Card>
                    ))}
                </div>
                <div>
                    <h4 className="font-semibold mb-2">Core Technology Snippet</h4>
                    <Card className="bg-slate-900 text-white font-mono"><CardContent className="p-3"><pre className="overflow-x-auto text-xs"><code>{CODE_SNIPPET}</code></pre></CardContent></Card>
                </div>
            </CardContent>
        </Card>
    );
}