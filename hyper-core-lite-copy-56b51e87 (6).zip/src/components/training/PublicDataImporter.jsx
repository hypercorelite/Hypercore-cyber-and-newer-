import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { CheckCircle, Database, Download, Brain, Zap, FileText, Scale, Umbrella } from 'lucide-react';
import { importPublicSecurityData } from '@/api/functions';
import { toast } from "sonner";

const PUBLIC_DATA_SOURCES = {
    cybersecurity: [
        {
            name: "NIST Cybersecurity Framework",
            source: "https://www.nist.gov/cyberframework",
            data_type: "Control mappings, implementation guidance, risk management",
            value: "Foundation for all compliance AI models",
            size: "~50MB structured data",
            update_frequency: "Annually"
        },
        {
            name: "MITRE ATT&CK Framework",
            source: "https://attack.mitre.org/",
            data_type: "Threat tactics, techniques, and procedures (TTPs)",
            value: "Threat detection and incident response AI training",
            size: "~100MB JSON data",
            update_frequency: "Quarterly"
        },
        {
            name: "CVE Database (NIST)",
            source: "https://nvd.nist.gov/",
            data_type: "Vulnerability descriptions, CVSS scores, affected systems",
            value: "Vulnerability assessment and prioritization AI",
            size: "~2GB historical data",
            update_frequency: "Daily"
        },
        {
            name: "CMMC Assessment Guides (Public)",
            source: "CMMC-AB.org + DoD Acquisition",
            data_type: "Assessment procedures, control requirements, maturity levels",
            value: "CMMC compliance automation (your core product)",
            size: "~25MB documentation",
            update_frequency: "Semi-annually"
        }
    ],

    legal_intelligence: [
        {
            name: "Federal Contract Opportunities (SAM.gov)",
            source: "https://sam.gov/api",
            data_type: "Contract descriptions, requirements, award amounts",
            value: "Contract opportunity matching AI for lawyers",
            size: "~500MB active contracts",
            update_frequency: "Daily"
        },
        {
            name: "USPTO Patent Database",
            source: "https://developer.uspto.gov/",
            data_type: "Patent applications, descriptions, legal language",
            value: "IP analysis and prior art search automation",
            size: "~10GB text data",
            update_frequency: "Weekly"
        },
        {
            name: "SEC EDGAR Filings",
            source: "https://www.sec.gov/developer",
            data_type: "Corporate filings, risk disclosures, compliance statements",
            value: "Corporate risk analysis for M&A due diligence",
            size: "~1TB historical data",
            update_frequency: "Real-time"
        }
    ],

    insurance_intelligence: [
        {
            name: "Cyber Incident Reports (ICS-CERT)",
            source: "https://www.cisa.gov/uscert/",
            data_type: "Incident descriptions, affected industries, remediation",
            value: "Risk scoring and premium calculation AI",
            size: "~200MB incident reports",
            update_frequency: "Weekly"
        },
        {
            name: "Breach Cost Studies (Ponemon/IBM)",
            source: "Public research reports",
            data_type: "Breach costs by industry, company size, threat type",
            value: "Financial impact prediction models",
            size: "~50MB study data",
            update_frequency: "Annually"
        },
        {
            name: "Company Cybersecurity Ratings (BitSight/SecurityScorecard)",
            source: "Public APIs (free tier)",
            data_type: "Security ratings, vulnerability scans, reputation data",
            value: "Automated underwriting and risk assessment",
            size: "~1GB company profiles",
            update_frequency: "Daily"
        }
    ]
};

const STRATEGIC_AI_TOOLS = {
    lawyers: [
        {
            name: "Contract Opportunity Intelligence",
            description: "AI that monitors SAM.gov and finds federal contracts your lawyer clients are qualified to bid on",
            value_proposition: "Generate 10x more qualified leads for government contract lawyers",
            technical_implementation: "NLP analysis of contract requirements vs. client capabilities",
            trade_value: "$3,000/month service for $3,000/month legal services",
            demo_ready: "2 weeks with public SAM.gov data"
        },
        {
            name: "Legal Document Risk Analyzer",
            description: "AI that reviews MSAs, NDAs, and contracts for hidden liability and unfavorable terms",
            value_proposition: "Review contracts 20x faster than manual review, catch more issues",
            technical_implementation: "Fine-tuned model on contract language + risk pattern recognition",
            trade_value: "$2,000/month tool for LLC formation + ongoing legal support",
            demo_ready: "3 weeks with public contract databases"
        },
        {
            name: "Patent Prior Art Search Engine",
            description: "AI that searches USPTO database and finds relevant prior art for patent applications",
            value_proposition: "Reduce patent research time from weeks to hours",
            technical_implementation: "Semantic search + technical concept matching on USPTO data",
            trade_value: "$4,000/month service for partnership agreement + IP protection",
            demo_ready: "4 weeks with USPTO API integration"
        }
    ],

    insurance: [
        {
            name: "Cyber Risk Scoring Engine",
            description: "AI that analyzes a company's digital footprint and generates insurance risk scores",
            value_proposition: "Underwrite cyber policies 10x faster with 30% better accuracy",
            technical_implementation: "Multi-source data fusion: DNS, SSL, breach history, industry data",
            trade_value: "$5,000/month platform for $2,000/month insurance coverage",
            demo_ready: "2 weeks with public security APIs"
        },
        {
            name: "Claims Fraud Detection System",
            description: "AI that analyzes cyber insurance claims for fraud indicators and patterns",
            value_proposition: "Reduce fraudulent claims by 40%, save millions in payouts",
            technical_implementation: "Anomaly detection on claim patterns + incident timeline analysis",
            trade_value: "$10,000/month service for preferred insurance rates + partnership",
            demo_ready: "6 weeks with synthetic claims data + public incident reports"
        },
        {
            name: "Policy Optimization Advisor",
            description: "AI that analyzes client risk profiles and recommends optimal coverage levels",
            value_proposition: "Increase policy values by 25% while reducing claims through better matching",
            technical_implementation: "Risk modeling + actuarial analysis + client behavior prediction",
            trade_value: "$3,000/month tool for comprehensive business insurance package",
            demo_ready: "4 weeks with industry risk data + cost models"
        }
    ]
};

export default function PublicDataImporter() {
    const [activeTab, setActiveTab] = useState('cybersecurity');
    const [importing, setImporting] = useState(false);
    const [progress, setProgress] = useState(0);
    const [selectedSources, setSelectedSources] = useState([]);

    const handleImport = async (sources) => {
        setImporting(true);
        setProgress(0);
        toast.info("Starting public data import...");

        try {
            for (let i = 0; i < sources.length; i++) {
                const source = sources[i];
                toast.info(`Importing ${source.name}...`);
                
                await importPublicSecurityData({
                    sourceName: source.name,
                    sourceUrl: source.source,
                    dataType: source.data_type,
                    expectedSize: source.size
                });
                
                setProgress(((i + 1) / sources.length) * 100);
            }
            
            toast.success("Public data import completed successfully!");
        } catch (error) {
            toast.error(`Import failed: ${error.message}`);
        } finally {
            setImporting(false);
            setProgress(0);
        }
    };

    return (
        <div className="space-y-6">
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Database className="w-6 h-6 text-blue-600" />
                        Public Data AI Training Pipeline
                    </CardTitle>
                    <CardDescription>
                        Build competitive AI models using publicly available cybersecurity, legal, and insurance data
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <Tabs value={activeTab} onValueChange={setActiveTab}>
                        <TabsList className="grid w-full grid-cols-3">
                            <TabsTrigger value="cybersecurity">Cybersecurity Data</TabsTrigger>
                            <TabsTrigger value="legal_intelligence">Legal Intelligence</TabsTrigger>
                            <TabsTrigger value="insurance_intelligence">Insurance Intelligence</TabsTrigger>
                        </TabsList>

                        {Object.entries(PUBLIC_DATA_SOURCES).map(([category, sources]) => (
                            <TabsContent key={category} value={category} className="mt-6">
                                <div className="space-y-4">
                                    {sources.map((source, index) => (
                                        <Card key={index} className="bg-gray-50">
                                            <CardContent className="p-4">
                                                <div className="flex justify-between items-start mb-2">
                                                    <h4 className="font-semibold">{source.name}</h4>
                                                    <Badge variant="secondary">{source.size}</Badge>
                                                </div>
                                                <p className="text-sm text-gray-600 mb-2">{source.data_type}</p>
                                                <p className="text-sm font-medium text-blue-600 mb-2">Value: {source.value}</p>
                                                <div className="flex justify-between items-center">
                                                    <span className="text-xs text-gray-500">Updates: {source.update_frequency}</span>
                                                    <Button 
                                                        size="sm"
                                                        onClick={() => handleImport([source])}
                                                        disabled={importing}
                                                    >
                                                        <Download className="w-4 h-4 mr-2" />
                                                        Import
                                                    </Button>
                                                </div>
                                            </CardContent>
                                        </Card>
                                    ))}
                                    
                                    <Button 
                                        className="w-full"
                                        onClick={() => handleImport(sources)}
                                        disabled={importing}
                                    >
                                        <Database className="w-4 h-4 mr-2" />
                                        Import All {category.replace('_', ' ').toUpperCase()} Data
                                    </Button>
                                </div>
                            </TabsContent>
                        ))}
                    </Tabs>

                    {importing && (
                        <div className="mt-4">
                            <Progress value={progress} className="w-full" />
                            <p className="text-sm text-gray-600 mt-2">Importing data... {Math.round(progress)}% complete</p>
                        </div>
                    )}
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Brain className="w-6 h-6 text-purple-600" />
                        Strategic Partnership AI Tools
                    </CardTitle>
                    <CardDescription>
                        AI tools so valuable that lawyers and insurance companies will trade their services for access
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <Tabs defaultValue="lawyers">
                        <TabsList className="grid w-full grid-cols-2">
                            <TabsTrigger value="lawyers" className="flex items-center gap-2">
                                <Scale className="w-4 h-4" />
                                Lawyer Tools
                            </TabsTrigger>
                            <TabsTrigger value="insurance" className="flex items-center gap-2">
                                <Umbrella className="w-4 h-4" />
                                Insurance Tools
                            </TabsTrigger>
                        </TabsList>

                        {Object.entries(STRATEGIC_AI_TOOLS).map(([category, tools]) => (
                            <TabsContent key={category} value={category} className="mt-6">
                                <div className="space-y-4">
                                    {tools.map((tool, index) => (
                                        <Card key={index} className="bg-gradient-to-r from-green-50 to-blue-50 border-green-200">
                                            <CardHeader>
                                                <div className="flex justify-between items-start">
                                                    <CardTitle className="text-lg">{tool.name}</CardTitle>
                                                    <Badge className="bg-green-100 text-green-800">
                                                        {tool.demo_ready}
                                                    </Badge>
                                                </div>
                                                <CardDescription>{tool.description}</CardDescription>
                                            </CardHeader>
                                            <CardContent>
                                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                                    <div>
                                                        <h5 className="font-semibold text-sm mb-2">Value Proposition:</h5>
                                                        <p className="text-sm text-gray-700">{tool.value_proposition}</p>
                                                    </div>
                                                    <div>
                                                        <h5 className="font-semibold text-sm mb-2">Trade Value:</h5>
                                                        <p className="text-sm text-green-700 font-medium">{tool.trade_value}</p>
                                                    </div>
                                                </div>
                                                <div className="mt-4">
                                                    <h5 className="font-semibold text-sm mb-2">Technical Implementation:</h5>
                                                    <p className="text-sm text-gray-600">{tool.technical_implementation}</p>
                                                </div>
                                                <Button className="w-full mt-4" variant="outline">
                                                    <Zap className="w-4 h-4 mr-2" />
                                                    Start Building This Tool
                                                </Button>
                                            </CardContent>
                                        </Card>
                                    ))}
                                </div>
                            </TabsContent>
                        ))}
                    </Tabs>
                </CardContent>
            </Card>

            <Alert>
                <CheckCircle className="h-4 w-4" />
                <AlertDescription>
                    <strong>Strategy:</strong> Build 1-2 tools from each category. Demo them to potential partners. 
                    The value is so obvious they'll trade their services for access. This gets you professional 
                    legal and insurance coverage for $0 cash while building your core AI capabilities.
                </AlertDescription>
            </Alert>
        </div>
    );
}