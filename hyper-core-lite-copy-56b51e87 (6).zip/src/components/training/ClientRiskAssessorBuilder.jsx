import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowRight } from 'lucide-react';

const WEEKLY_PLAN = {
    week1: { title: "Data Connectors", tasks: ["Integrate with corporate record APIs (e.g., OpenCorporates)", "Connect to news sentiment analysis APIs", "Add sanctions list (OFAC) checking"] },
    week2: { title: "Risk Algorithm", tasks: ["Develop a weighted scoring model for risk factors", "Define rules for red flags (e.g., sanctions hit, negative news spike)", "Incorporate financial stability metrics"] },
    week3: { title: "Report Generation", tasks: ["Design a clean, professional PDF report layout", "Build a function to populate the report with data and risk scores", "Add charts and visualizations for key metrics"] },
    week4: { title: "API & Frontend", tasks: ["Create an API to trigger an assessment for a given company", "Build a simple UI to input a company name and view/download the report", "Implement caching to avoid duplicate API calls"] },
    week5: { title: "Validation", tasks: ["Run assessments on 10 known high-risk and 10 low-risk entities", "Compare results with manual due diligence", "Refine scoring algorithm based on findings"] }
};

const CODE_SNIPPET = `# Core Risk Scoring Logic (Python)
def calculate_risk_score(company_data):
    score = 0
    # company_data from various APIs
    
    if company_data['sanctions_hit']:
        score += 50 # Major red flag
    if company_data['negative_news_sentiment'] > 0.7:
        score += 20
    if company_data['directors_on_watchlists']:
        score += 15
    if company_data['financials']['debt_ratio'] > 0.6:
        score += 10
        
    return min(score, 100) # Cap score at 100
`;

export default function ClientRiskAssessorBuilder() {
    return (
        <Card className="bg-white border-gray-200 mt-6">
            <CardHeader>
                <CardTitle>AI Asset: Client Risk Assessment Engine</CardTitle>
                <CardDescription>Automates client due diligence, turning a 5-hour manual process into a 5-minute task. <span className="font-semibold text-purple-700">Essential for intake and risk management.</span></CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
                <h4 className="font-semibold">5-Week Build Plan</h4>
                <div className="grid grid-cols-1 md:grid-cols-5 gap-2">
                    {Object.values(WEEKLY_PLAN).map((week, index) => (
                        <Card key={index} className="bg-gray-50 p-3"><CardTitle className="text-xs font-bold mb-1">{week.title}</CardTitle><ul className="list-disc pl-3 text-xs space-y-1 text-gray-600">{week.tasks.map((task, i) => <li key={i}>{task}</li>)}</ul></Card>
                    ))}
                </div>
                <div>
                    <h4 className="font-semibold mb-2">Core Technology Snippet</h4>
                    <Card className="bg-slate-900 text-white font-mono"><CardContent className="p-3"><pre className="overflow-x-auto text-xs"><code>{CODE_SNIPPET}</code></pre></CardContent></Card>
                </div>
            </CardContent>
        </Card>
    );
}