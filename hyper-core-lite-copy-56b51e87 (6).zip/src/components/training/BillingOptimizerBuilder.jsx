import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowRight } from 'lucide-react';

const WEEKLY_PLAN = {
    week1: { title: "Data Ingestion", tasks: ["Build a CSV/XLSX importer for time-tracking data", "Define a standard schema for billing records", "Implement data validation and cleaning on upload"] },
    week2: { title: "Analysis Engine", tasks: ["Use pandas to analyze billing patterns", "Identify common reasons for write-offs (e.g., vague descriptions)", "Calculate realization rates per lawyer and practice area"] },
    week3: { title: "AI Recommendations", tasks: ["Train a simple model to flag time entries likely to be disputed", "Use an LLM to suggest better, more descriptive billing narratives", "Develop logic to recommend optimal billing rates"] },
    week4: { title: "Dashboard UI", tasks: ["Build a dashboard to visualize key metrics (realization, write-offs)", "Display AI-powered recommendations for improving entries", "Create reports for practice group leaders"] },
    week5: { title: "Partner Pilot", tasks: ["Run the tool with a friendly law firm's historical data", "Demonstrate recovered revenue potential", "Gather feedback to refine the recommendation engine"] }
};

const CODE_SNIPPET = `# Core Analysis Logic (Python/Pandas)
import pandas as pd

def analyze_billing(df: pd.DataFrame):
    # Calculate realization rate
    df['realization'] = df['billed_amount'] / df['logged_amount']
    
    # Find top reasons for write-offs
    write_off_reasons = df[df['realization'] < 1]['reason'].value_counts()
    
    # Flag vague entries
    df['is_vague'] = df['description'].str.len() < 20
    
    return {
        "overall_realization": df['realization'].mean(),
        "top_write_off_reasons": write_off_reasons.head(3),
        "vague_entries_count": df['is_vague'].sum()
    }
`;

export default function BillingOptimizerBuilder() {
    return (
        <Card className="bg-white border-gray-200 mt-6">
            <CardHeader>
                <CardTitle>AI Asset: AI Billing Optimizer</CardTitle>
                <CardDescription>Helps firms recover 15-20% of lost billable time through intelligent analysis. <span className="font-semibold text-purple-700">A direct ROI tool that pays for itself in the first month.</span></CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
                <h4 className="font-semibold">5-Week Build Plan</h4>
                <div className="grid grid-cols-1 md:grid-cols-5 gap-2">
                    {Object.values(WEEKLY_PLAN).map((week, index) => (
                        <Card key={index} className="bg-gray-50 p-3"><CardTitle className="text-xs font-bold mb-1">{week.title}</CardTitle><ul className="list-disc pl-3 text-xs space-y-1 text-gray-600">{week.tasks.map((task, i) => <li key={i}>{task}</li>)}</ul></Card>
                    ))}
                </div>
                <div>
                    <h4 className="font-semibold mb-2">Core Technology Snippet</h4>
                    <Card className="bg-slate-900 text-white font-mono"><CardContent className="p-3"><pre className="overflow-x-auto text-xs"><code>{CODE_SNIPPET}</code></pre></CardContent></Card>
                </div>
            </CardContent>
        </Card>
    );
}