import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowRight } from 'lucide-react';

const WEEKLY_PLAN = {
    week1: { title: "Template Engine", tasks: ["Set up a document templating engine (Jinja2/docx-template)", "Create 10 standard legal document templates (e.g., MNDA, Service Agreement)", "Define variable placeholders in templates"] },
    week2: { title: "AI Integration", tasks: ["Build a function to take high-level inputs (e.g., 'NDA for Project X')", "Use an LLM to generate the specific text for variable sections", "Structure LLM output as JSON to match template placeholders"] },
    week3: { title: "Frontend UI", tasks: ["Develop a simple form to select a document template", "Add input fields for key details (names, dates, scope)", "Implement a 'Generate with AI' button"] },
    week4: { title: "Backend Logic", tasks: ["Create an API endpoint that receives form data", "Orchestrate the process: LLM generates text, then populates template", "Enable downloading the final document (DOCX/PDF)"] },
    week5: { title: "Testing & Refinement", tasks: ["Generate all 10 document types and validate for accuracy", "Refine LLM prompts for better clause generation", "Add ability for users to upload their own templates"] }
};

const CODE_SNIPPET = `# Core Document Generation (Python/Flask)
from docxtpl import DocxTemplate

@app.route('/generate-doc', methods=['POST'])
def generate_doc():
    data = request.json # { "template": "nda.docx", "context": {...} }
    doc = DocxTemplate(f"templates/{data['template']}")
    
    # Use AI to enrich the context if needed
    # ai_generated_clauses = llm.generate_clauses(data['context'])
    # data['context'].update(ai_generated_clauses)
    
    doc.render(data['context'])
    doc.save("output/generated_doc.docx")
    
    return send_file("output/generated_doc.docx")
`;

export default function DocumentGeneratorBuilder() {
    return (
        <Card className="bg-white border-gray-200 mt-6">
            <CardHeader>
                <CardTitle>AI Asset: Smart Document Generator</CardTitle>
                <CardDescription>Automates repetitive document drafting, saving over 20 hours per week. <span className="font-semibold text-purple-700">A high-value tool for any law firm partner.</span></CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
                <h4 className="font-semibold">5-Week Build Plan</h4>
                <div className="grid grid-cols-1 md:grid-cols-5 gap-2">
                    {Object.values(WEEKLY_PLAN).map((week, index) => (
                        <Card key={index} className="bg-gray-50 p-3"><CardTitle className="text-xs font-bold mb-1">{week.title}</CardTitle><ul className="list-disc pl-3 text-xs space-y-1 text-gray-600">{week.tasks.map((task, i) => <li key={i}>{task}</li>)}</ul></Card>
                    ))}
                </div>
                <div>
                    <h4 className="font-semibold mb-2">Core Technology Snippet</h4>
                    <Card className="bg-slate-900 text-white font-mono"><CardContent className="p-3"><pre className="overflow-x-auto text-xs"><code>{CODE_SNIPPET}</code></pre></CardContent></Card>
                </div>
            </CardContent>
        </Card>
    );
}