import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowRight } from 'lucide-react';

const WEEKLY_PLAN = {
    week1: { title: "Data Modeling", tasks: ["Model relationships between claimants, providers, and policies", "Ingest historical claims data into a graph database (e.g., Neo4j)", "Identify known historical fraud patterns"] },
    week2: { title: "Pattern Recognition", tasks: ["Develop algorithms to detect suspicious patterns (e.g., multiple claimants at one address)", "Implement anomaly detection for claim values and frequencies", "Build a network graph of all entities in a claim"] },
    week3: { title: "AI Scoring", tasks: ["Train a machine learning model (e.g., Gradient Boosting) on labeled fraud data", "Generate a 'fraud risk score' for every incoming claim", "Use LLM to explain *why* a claim was flagged"] },
    week4: { title: "Investigator Dashboard", tasks: ["Build a UI to visualize the network graph of a suspicious claim", "Create a case management system for investigators", "Prioritize high-risk claims for human review"] },
    week5: { title: "Effectiveness Test", tasks: ["Run the system on a batch of 1,000 historical claims", "Measure the model's ability to identify the known fraudulent ones", "Demonstrate a 5% lift in fraud detection rate"] }
};

const CODE_SNIPPET = `# Core Anomaly Detection Logic (Python)
def check_claim_anomaly(claim_data, historical_data):
    # Check for anomalies in claim amount for this type of incident
    mean = historical_data['amount'].mean()
    std = historical_data['amount'].std()
    
    if abs(claim_data['amount'] - mean) > 3 * std:
        return {"is_anomaly": True, "reason": "Claim amount is a 3-sigma event."}
        
    # Check for excessive claim frequency
    if claimant_frequency(claim_data['claimant_id']) > 5: # 5 claims in a year
        return {"is_anomaly": True, "reason": "Excessive claim frequency."}
        
    return {"is_anomaly": False}
`;

export default function FraudDetectionBuilder() {
    return (
        <Card className="bg-white border-gray-200 mt-6">
            <CardHeader>
                <CardTitle>AI Asset: AI Fraud Detection System</CardTitle>
                <CardDescription>Identifies 5-10% more fraudulent claims than traditional methods, saving carriers millions. <span className="font-semibold text-blue-700">A high-impact tool for profitability.</span></CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
                <h4 className="font-semibold">5-Week Build Plan</h4>
                <div className="grid grid-cols-1 md:grid-cols-5 gap-2">
                    {Object.values(WEEKLY_PLAN).map((week, index) => (
                        <Card key={index} className="bg-gray-50 p-3"><CardTitle className="text-xs font-bold mb-1">{week.title}</CardTitle><ul className="list-disc pl-3 text-xs space-y-1 text-gray-600">{week.tasks.map((task, i) => <li key={i}>{task}</li>)}</ul></Card>
                    ))}
                </div>
                <div>
                    <h4 className="font-semibold mb-2">Core Technology Snippet</h4>
                    <Card className="bg-slate-900 text-white font-mono"><CardContent className="p-3"><pre className="overflow-x-auto text-xs"><code>{CODE_SNIPPET}</code></pre></CardContent></Card>
                </div>
            </CardContent>
        </Card>
    );
}