import { base44 } from './base44Client';


export const ThreatAlert = base44.entities.ThreatAlert;

export const SecurityIncident = base44.entities.SecurityIncident;

export const NetworkLog = base44.entities.NetworkLog;

export const VMInstance = base44.entities.VMInstance;

export const ComplianceFramework = base44.entities.ComplianceFramework;

export const ComplianceTask = base44.entities.ComplianceTask;

export const AIComplianceAgent = base44.entities.AIComplianceAgent;

export const SecurityPlaybook = base44.entities.SecurityPlaybook;

export const GovernmentEntity = base44.entities.GovernmentEntity;

export const NationalDebtHolder = base44.entities.NationalDebtHolder;

export const StrategicAsset = base44.entities.StrategicAsset;

export const EnergyPartner = base44.entities.EnergyPartner;

export const DataProcessingAgreement = base44.entities.DataProcessingAgreement;

export const AITrainingSession = base44.entities.AITrainingSession;

export const ComplianceReport = base44.entities.ComplianceReport;

export const InsurancePartner = base44.entities.InsurancePartner;

export const CyberInsurancePolicy = base44.entities.CyberInsurancePolicy;

export const GrantProposal = base44.entities.GrantProposal;

export const PartnershipCommunication = base44.entities.PartnershipCommunication;

export const PartnerClient = base44.entities.PartnerClient;

export const AuditLog = base44.entities.AuditLog;

export const DemoDataCollection = base44.entities.DemoDataCollection;

export const TestingLog = base44.entities.TestingLog;

export const ComplianceDocument = base44.entities.ComplianceDocument;

export const SupportTicket = base44.entities.SupportTicket;

export const KnowledgeBaseArticle = base44.entities.KnowledgeBaseArticle;

export const Organization = base44.entities.Organization;

export const ClientOnboarding = base44.entities.ClientOnboarding;

export const ClientEngagement = base44.entities.ClientEngagement;

export const ClientFeedback = base44.entities.ClientFeedback;

export const BlogPost = base44.entities.BlogPost;

export const ComplianceActionItem = base44.entities.ComplianceActionItem;

export const UsageMetric = base44.entities.UsageMetric;

export const AIMetric = base44.entities.AIMetric;

export const LetterOfIntent = base44.entities.LetterOfIntent;

export const StrategicPartner = base44.entities.StrategicPartner;

export const PrimeContractorLead = base44.entities.PrimeContractorLead;



// auth sdk:
export const User = base44.auth;