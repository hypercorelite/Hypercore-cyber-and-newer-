import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Copy, Github, GitBranch, FileText, Shield, CheckCircle, Terminal, Code, FolderTree } from 'lucide-react';
import { toast } from "sonner";
import { motion } from "framer-motion";

const CodeBlock = ({ content, title, language = "yaml" }) => {
    const handleCopy = () => {
        navigator.clipboard.writeText(content);
        toast.success(`${title} copied to clipboard!`);
    };

    return (
        <div className="relative bg-gray-900 text-white p-4 rounded-md font-mono text-xs my-4">
            <div className="flex justify-between items-center mb-2">
                <Badge variant="secondary" className="text-xs">{language}</Badge>
                <Button
                    size="icon"
                    variant="ghost"
                    className="h-6 w-6 text-gray-400 hover:bg-gray-700 hover:text-white"
                    onClick={handleCopy}
                >
                    <Copy className="h-3 w-3" />
                </Button>
            </div>
            <pre className="overflow-x-auto">
                <code>{content}</code>
            </pre>
        </div>
    );
};

const workflowSteps = [
    {
        step: "1. Initialize CMMC Repository",
        description: "Set up a dedicated Git repository for CMMC compliance documentation and evidence collection",
        icon: Github
    },
    {
        step: "2. Create Control Branches",
        description: "Each CMMC control gets its own feature branch for focused implementation and review",
        icon: GitBranch
    },
    {
        step: "3. Automated Evidence Collection",
        description: "GitHub Actions automatically collect evidence, run compliance checks, and generate reports",
        icon: Terminal
    },
    {
        step: "4. Continuous Compliance Monitoring",
        description: "Automated workflows ensure ongoing compliance and alert on deviations",
        icon: Shield
    }
];

const cmmcControls = [
    {
        id: "AC.L2-3.1.3",
        title: "Control the flow of CUI",
        githubIssue: "Implement Data Flow Controls",
        branch: "feature/ac-3-1-3-cui-flow",
        evidence: ["network-diagrams/", "access-logs/", "dlp-configs/"]
    },
    {
        id: "IA.L2-3.5.3", 
        title: "Use multifactor authentication",
        githubIssue: "Deploy MFA Across All Systems",
        branch: "feature/ia-3-5-3-mfa",
        evidence: ["mfa-configs/", "user-enrollment/", "audit-logs/"]
    },
    {
        id: "AU.L2-3.3.1",
        title: "Create and retain system audit logs",
        githubIssue: "Implement Comprehensive Logging",
        branch: "feature/au-3-3-1-logging",
        evidence: ["log-configs/", "retention-policies/", "log-samples/"]
    }
];

export default function CMMCGitWorkflow() {
    const [selectedControl, setSelectedControl] = useState(cmmcControls[0]);

    return (
        <div className="space-y-8">
            <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center"
            >
                <Badge className="mb-4 bg-blue-100 text-blue-800">TECHNICAL IMPLEMENTATION</Badge>
                <h1 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-3 flex items-center justify-center gap-3">
                    <Github className="w-8 h-8 text-gray-800" />
                    CMMC Compliance via Git/GitHub Workflows
                </h1>
                <p className="text-lg lg:text-xl text-gray-600 max-w-4xl mx-auto">
                    Reverse-engineer CMMC requirements into trackable Git workflows, automated evidence collection, and collaborative compliance management.
                </p>
            </motion.div>

            <Tabs defaultValue="overview" className="w-full">
                <TabsList className="grid w-full grid-cols-2 md:grid-cols-5">
                    <TabsTrigger value="overview">Workflow Overview</TabsTrigger>
                    <TabsTrigger value="repository">Repository Structure</TabsTrigger>
                    <TabsTrigger value="automation">GitHub Actions</TabsTrigger>
                    <TabsTrigger value="controls">Control Implementation</TabsTrigger>
                    <TabsTrigger value="evidence">Evidence Collection</TabsTrigger>
                </TabsList>

                <TabsContent value="overview">
                    <Card>
                        <CardHeader>
                            <CardTitle>The Git-Based CMMC Approach</CardTitle>
                            <CardDescription>Transform compliance from documentation chaos into organized, trackable development workflows</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <div className="grid md:grid-cols-2 gap-6 mb-8">
                                {workflowSteps.map((step, index) => (
                                    <motion.div
                                        key={index}
                                        initial={{ opacity: 0, x: -20 }}
                                        animate={{ opacity: 1, x: 0 }}
                                        transition={{ delay: index * 0.1 }}
                                        className="flex items-start gap-3"
                                    >
                                        <step.icon className="w-8 h-8 text-blue-600 mt-1" />
                                        <div>
                                            <h3 className="font-semibold text-lg">{step.step}</h3>
                                            <p className="text-gray-600">{step.description}</p>
                                        </div>
                                    </motion.div>
                                ))}
                            </div>
                            
                            <Card className="bg-gray-50">
                                <CardHeader>
                                    <CardTitle className="text-lg">Why This Approach Works</CardTitle>
                                </CardHeader>
                                <CardContent className="space-y-3">
                                    <div className="flex items-start gap-2">
                                        <CheckCircle className="w-5 h-5 text-green-600 mt-0.5" />
                                        <p className="text-sm"><strong>Version Control:</strong> Every compliance change is tracked, reviewed, and approved</p>
                                    </div>
                                    <div className="flex items-start gap-2">
                                        <CheckCircle className="w-5 h-5 text-green-600 mt-0.5" />
                                        <p className="text-sm"><strong>Collaborative:</strong> Multiple team members can work on different controls simultaneously</p>
                                    </div>
                                    <div className="flex items-start gap-2">
                                        <CheckCircle className="w-5 h-5 text-green-600 mt-0.5" />
                                        <p className="text-sm"><strong>Automated Evidence:</strong> Scripts collect and validate evidence continuously</p>
                                    </div>
                                    <div className="flex items-start gap-2">
                                        <CheckCircle className="w-5 h-5 text-green-600 mt-0.5" />
                                        <p className="text-sm"><strong>Audit Ready:</strong> Complete history and evidence package ready for C3PAO</p>
                                    </div>
                                </CardContent>
                            </Card>
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="repository">
                    <Card>
                        <CardHeader>
                            <CardTitle>CMMC Repository Structure</CardTitle>
                            <CardDescription>Organized file structure that maps directly to CMMC requirements</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <CodeBlock
                                title="Repository Structure"
                                language="text"
                                content={`cmmc-compliance-repo/
├── .github/
│   ├── workflows/
│   │   ├── evidence-collection.yml
│   │   ├── compliance-check.yml
│   │   └── ssp-generation.yml
│   └── ISSUE_TEMPLATE/
│       └── cmmc-control.md
├── controls/
│   ├── AC/                    # Access Control
│   │   ├── AC.L2-3.1.3/
│   │   │   ├── implementation.md
│   │   │   ├── evidence/
│   │   │   └── tests/
│   │   └── AC.L2-3.1.5/
│   ├── AU/                    # Audit & Accountability  
│   ├── IA/                    # Identification & Authentication
│   └── SC/                    # System & Communications Protection
├── documentation/
│   ├── ssp/                   # System Security Plan
│   ├── poam/                  # Plan of Action & Milestones
│   └── policies/              # Organizational Policies
├── evidence/
│   ├── automated/             # Script-collected evidence
│   ├── manual/                # Human-provided evidence
│   └── archived/              # Historical evidence
├── scripts/
│   ├── evidence-collectors/   # Automated evidence collection
│   ├── compliance-checks/     # Validation scripts
│   └── report-generators/     # C3PAO report generation
└── templates/
    ├── control-template.md
    ├── evidence-template.md
    └── implementation-guide.md`}
                            />
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="automation">
                    <Card>
                        <CardHeader>
                            <CardTitle>GitHub Actions for CMMC Compliance</CardTitle>
                            <CardDescription>Automated workflows that continuously monitor and validate CMMC controls</CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-6">
                            <div>
                                <h3 className="text-lg font-semibold mb-3">Daily Evidence Collection Workflow</h3>
                                <CodeBlock
                                    title="Evidence Collection Action"
                                    language="yaml"
                                    content={`name: Daily CMMC Evidence Collection

on:
  schedule:
    - cron: '0 6 * * *'  # Run daily at 6 AM
  push:
    paths: ['controls/**']

jobs:
  collect-evidence:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Collect Network Flow Evidence (AC.L2-3.1.3)
      run: |
        # Collect firewall logs
        ./scripts/evidence-collectors/collect-firewall-logs.sh
        # Document network segmentation
        ./scripts/evidence-collectors/network-topology.sh
        
    - name: Validate MFA Implementation (IA.L2-3.5.3)
      run: |
        # Check MFA enrollment rates
        ./scripts/evidence-collectors/mfa-status.sh
        # Validate MFA policies
        ./scripts/compliance-checks/validate-mfa.sh
        
    - name: Audit Log Collection (AU.L2-3.3.1)
      run: |
        # Collect system logs
        ./scripts/evidence-collectors/collect-audit-logs.sh
        # Verify log retention
        ./scripts/compliance-checks/log-retention-check.sh
        
    - name: Generate Compliance Report
      run: |
        ./scripts/report-generators/daily-compliance-status.sh
        
    - name: Commit Evidence
      run: |
        git config --local user.email "cmmc-bot@company.com"
        git config --local user.name "CMMC Bot"
        git add evidence/automated/
        git commit -m "Daily evidence collection - $(date)" || exit 0
        git push`}
                                />
                            </div>

                            <div>
                                <h3 className="text-lg font-semibold mb-3">Control Implementation Validation</h3>
                                <CodeBlock
                                    title="Compliance Check Action"
                                    language="yaml"
                                    content={`name: CMMC Control Validation

on:
  pull_request:
    paths: ['controls/**']

jobs:
  validate-control:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Extract Control ID from PR
      id: control
      run: |
        CONTROL_ID=$(echo "\\${{ github.head_ref }}" | sed 's/.*\\/\\([^/]*\\)$/\\1/')
        echo "::set-output name=id::\\$CONTROL_ID"
        
    - name: Validate Control Implementation
      run: |
        # Run control-specific validation
        ./scripts/compliance-checks/validate-control.sh \\${{ steps.control.outputs.id }}
        
    - name: Check Evidence Completeness
      run: |
        ./scripts/compliance-checks/evidence-completeness.sh \\${{ steps.control.outputs.id }}
        
    - name: Generate Control Report
      run: |
        ./scripts/report-generators/control-status.sh \\${{ steps.control.outputs.id }} > control-report.md`}
                                />
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="controls">
                    <Card>
                        <CardHeader>
                            <CardTitle>CMMC Control Implementation Workflow</CardTitle>
                            <CardDescription>How each CMMC control becomes a trackable GitHub issue and feature branch</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <div className="mb-6">
                                <h3 className="text-lg font-semibold mb-4">Select a CMMC Control to See Implementation:</h3>
                                <div className="grid md:grid-cols-3 gap-3 mb-6">
                                    {cmmcControls.map((control) => (
                                        <Button
                                            key={control.id}
                                            variant={selectedControl.id === control.id ? "default" : "outline"}
                                            className="text-left h-auto p-3"
                                            onClick={() => setSelectedControl(control)}
                                        >
                                            <div>
                                                <div className="font-mono text-sm">{control.id}</div>
                                                <div className="text-xs text-gray-600">{control.title}</div>
                                            </div>
                                        </Button>
                                    ))}
                                </div>
                            </div>

                            <Card className="border-blue-200 bg-blue-50">
                                <CardHeader>
                                    <CardTitle className="text-lg">{selectedControl.id}: {selectedControl.title}</CardTitle>
                                    <CardDescription>
                                        <Badge variant="outline">GitHub Issue: {selectedControl.githubIssue}</Badge>
                                        <Badge variant="outline" className="ml-2">Branch: {selectedControl.branch}</Badge>
                                    </CardDescription>
                                </CardHeader>
                                <CardContent>
                                    <div>
                                        <h4 className="font-semibold mb-2">Implementation Workflow:</h4>
                                        <CodeBlock
                                            title="Control Implementation"
                                            language="bash"
                                            content={`# 1. Create feature branch for this control
git checkout -b ${selectedControl.branch}

# 2. Create control directory structure
mkdir -p controls/${selectedControl.id.split('.')[0]}/${selectedControl.id}
cd controls/${selectedControl.id.split('.')[0]}/${selectedControl.id}

# 3. Initialize control files
touch implementation.md
mkdir evidence tests
echo "# ${selectedControl.id}: ${selectedControl.title}" > implementation.md

# 4. Document implementation approach
cat >> implementation.md << EOF

## Implementation Status: In Progress

## Technical Implementation:
- [ ] Configure access controls
- [ ] Deploy monitoring tools  
- [ ] Update security policies
- [ ] Train staff on procedures

## Evidence Collection:
${selectedControl.evidence.map(e => `- [ ] ${e}`).join('\n')}

## Testing & Validation:
- [ ] Functional testing
- [ ] Security testing
- [ ] Compliance validation

EOF

# 5. Commit and push
git add .
git commit -m "Initialize ${selectedControl.id} implementation"
git push -u origin ${selectedControl.branch}

# 6. Create pull request for review
gh pr create --title "${selectedControl.githubIssue}" \\
  --body "Implements CMMC control ${selectedControl.id}\\n\\nSee implementation.md for details."
`}
                                        />
                                    </div>
                                </CardContent>
                            </Card>
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="evidence">
                    <Card>
                        <CardHeader>
                            <CardTitle>Automated Evidence Collection Scripts</CardTitle>
                            <CardDescription>Real scripts that collect CMMC evidence from your systems automatically</CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-6">
                            <div>
                                <h3 className="text-lg font-semibold mb-3">Network Flow Evidence (AC.L2-3.1.3)</h3>
                                <CodeBlock
                                    title="collect-firewall-logs.sh"
                                    language="bash"
                                    content={`#!/bin/bash
# Collect firewall logs for CUI flow control evidence

EVIDENCE_DIR="evidence/automated/AC.L2-3.1.3"
DATE=$(date +%Y-%m-%d)

mkdir -p "$EVIDENCE_DIR"

# Collect pfSense firewall logs
echo "Collecting firewall logs for $DATE..."
ssh pfsense@firewall.local "tail -1000 /var/log/filter.log" > "$EVIDENCE_DIR/firewall-$DATE.log"

# Collect network flow summaries
echo "Generating network flow summary..."
cat "$EVIDENCE_DIR/firewall-$DATE.log" | awk '{
    if($0 ~ /BLOCK/ && $0 ~ /CUI/) {
        blocked++
    }
    if($0 ~ /PASS/ && $0 ~ /CUI/) {
        allowed++
    }
}
END {
    print "Date: '$DATE'"
    print "CUI Traffic Blocked: " blocked
    print "CUI Traffic Allowed: " allowed
    print "Control Status: " (blocked > 0 ? "ACTIVE" : "VERIFY")
}' > "$EVIDENCE_DIR/flow-summary-$DATE.txt"

# Generate network topology evidence
./scripts/evidence-collectors/network-topology.sh >> "$EVIDENCE_DIR/topology-$DATE.txt"

echo "Evidence collected: $EVIDENCE_DIR/"
ls -la "$EVIDENCE_DIR/"
`}
                                />
                            </div>

                            <div>
                                <h3 className="text-lg font-semibold mb-3">MFA Status Evidence (IA.L2-3.5.3)</h3>
                                <CodeBlock
                                    title="mfa-status.sh"
                                    language="bash"
                                    content={`#!/bin/bash
# Collect MFA implementation evidence

EVIDENCE_DIR="evidence/automated/IA.L2-3.5.3"
DATE=$(date +%Y-%m-%d)

mkdir -p "$EVIDENCE_DIR"

# Check Azure AD MFA status
echo "Collecting Azure AD MFA status..."
az ad user list --query '[].{UPN:userPrincipalName,MFAStatus:strongAuthenticationMethods[0].methodType}' \\
    --output table > "$EVIDENCE_DIR/azure-mfa-status-$DATE.txt"

# Check VPN MFA requirements  
echo "Checking VPN MFA configuration..."
ssh vpn-admin@vpn.local "show config | grep -i 'multi-factor\\|mfa\\|2fa'" > "$EVIDENCE_DIR/vpn-mfa-config-$DATE.txt"

# Generate MFA compliance report
TOTAL_USERS=$(az ad user list --query 'length(@)')
MFA_USERS=$(az ad user list --query 'length([?strongAuthenticationMethods[0]])')
COMPLIANCE_RATE=$((MFA_USERS * 100 / TOTAL_USERS))

cat > "$EVIDENCE_DIR/mfa-compliance-$DATE.json" << EOF
{
    "date": "$DATE",
    "total_users": $TOTAL_USERS,
    "mfa_enabled_users": $MFA_USERS,
    "compliance_rate": $COMPLIANCE_RATE,
    "control_status": "$([ $COMPLIANCE_RATE -eq 100 ] && echo 'COMPLIANT' || echo 'NON-COMPLIANT')",
    "evidence_files": [
        "azure-mfa-status-$DATE.txt",
        "vpn-mfa-config-$DATE.txt"
    ]
}
EOF

echo "MFA evidence collected: $COMPLIANCE_RATE% compliance rate"
`}
                                />
                            </div>

                            <div>
                                <h3 className="text-lg font-semibold mb-3">Audit Log Evidence (AU.L2-3.3.1)</h3>
                                <CodeBlock
                                    title="collect-audit-logs.sh"
                                    language="bash"
                                    content={`#!/bin/bash
# Collect audit log evidence for CMMC compliance

EVIDENCE_DIR="evidence/automated/AU.L2-3.3.1"
DATE=$(date +%Y-%m-%d)

mkdir -p "$EVIDENCE_DIR"

# Collect Windows Security Event Logs
echo "Collecting Windows audit logs..."
wevtutil qe Security /c:1000 /f:text /q:"*[System[TimeCreated[timediff(@SystemTime) <= 86400000]]]" \\
    > "$EVIDENCE_DIR/windows-security-$DATE.log"

# Collect Linux audit logs
echo "Collecting Linux audit logs..."
sudo ausearch -ts today > "$EVIDENCE_DIR/linux-audit-$DATE.log"

# Collect application audit logs
echo "Collecting application audit logs..."
tail -1000 /var/log/application-audit.log > "$EVIDENCE_DIR/app-audit-$DATE.log"

# Generate audit log summary
echo "Generating audit log summary..."
cat > "$EVIDENCE_DIR/audit-summary-$DATE.json" << EOF
{
    "date": "$DATE",
    "log_sources": [
        {
            "source": "Windows Security",
            "events": $(wc -l < "$EVIDENCE_DIR/windows-security-$DATE.log"),
            "file": "windows-security-$DATE.log"
        },
        {
            "source": "Linux Audit",
            "events": $(wc -l < "$EVIDENCE_DIR/linux-audit-$DATE.log"),
            "file": "linux-audit-$DATE.log"
        },
        {
            "source": "Application Audit",
            "events": $(wc -l < "$EVIDENCE_DIR/app-audit-$DATE.log"),
            "file": "app-audit-$DATE.log"
        }
    ],
    "retention_policy": "7 years",
    "control_status": "ACTIVE"
}
EOF

echo "Audit log evidence collected successfully"
ls -la "$EVIDENCE_DIR/"
`}
                                />
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>
            </Tabs>
        </div>
    );
}