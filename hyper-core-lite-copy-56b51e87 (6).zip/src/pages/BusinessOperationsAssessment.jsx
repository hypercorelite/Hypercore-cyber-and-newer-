import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { CheckCircle, AlertTriangle, ArrowRight, Gavel, DollarSign, Clock } from "lucide-react";

export default function BusinessOperationsAssessment() {

    const assessmentAreas = [
        {
            area: "Contractual Obligations",
            description: "Reviewing existing DoD contracts for specific DFARS clauses (e.g., 252.204-7012) that mandate CMMC.",
            status: "Compliant",
            finding: "All active contracts contain the required DFARS clauses, making CMMC a legal necessity."
        },
        {
            area: "Supply Chain Risk Management",
            description: "Assessing the compliance status of key subcontractors and their ability to handle CUI.",
            status: "High Risk",
            finding: "Over 60% of subcontractors have not started CMMC preparation, posing a significant risk to prime contract eligibility."
        },
        {
            area: "Financial Readiness",
            description: "Evaluating the budget allocated for compliance versus realistic market costs for assessment and remediation.",
            status: "Medium Risk",
            finding: "Budget is allocated for a C3PAO audit, but not for the likely high cost of remediation, creating a potential financial shortfall."
        },
        {
            area: "Operational Timelines",
            description: "Comparing the company's internal project timelines with the 2026 CMMC mandate and typical audit scheduling delays.",
            status: "High Risk",
            finding: "Internal timelines do not account for the 6-12 month average for C3PAO scheduling and potential remediation cycles."
        }
    ];

    return (
        <div className="min-h-screen bg-gray-100 p-8">
            <div className="max-w-5xl mx-auto">
                <header className="text-center mb-12">
                    <h1 className="text-4xl font-bold text-gray-900">Client Business Operations Assessment</h1>
                    <p className="text-xl text-gray-600 mt-2">Connecting CMMC compliance to real-world business risk and operational readiness.</p>
                </header>

                <div className="space-y-6">
                    {assessmentAreas.map((item, index) => (
                        <Card key={index} className={item.status.includes('Risk') ? 'border-red-300' : 'border-green-300'}>
                            <CardHeader>
                                <div className="flex justify-between items-start">
                                    <div>
                                        <CardTitle className="flex items-center gap-2 text-xl">
                                            {item.status.includes('Risk') 
                                                ? <AlertTriangle className="w-6 h-6 text-red-500" />
                                                : <CheckCircle className="w-6 h-6 text-green-500" />}
                                            {item.area}
                                        </CardTitle>
                                        <CardDescription className="mt-2">{item.description}</CardDescription>
                                    </div>
                                    <span className={`font-bold py-1 px-3 rounded-full text-sm ${item.status.includes('Risk') ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'}`}>{item.status}</span>
                                </div>
                            </CardHeader>
                            <CardContent className="bg-gray-50 p-4 rounded-b-lg">
                                <p className="font-semibold text-gray-800">Key Finding:</p>
                                <p className="text-gray-600">{item.finding}</p>
                            </CardContent>
                        </Card>
                    ))}
                </div>
                
                <Card className="mt-12 bg-blue-600 text-white">
                    <CardHeader>
                        <CardTitle>Strategic Recommendation</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p>The primary business risk is supply chain non-compliance and unpreparedness for remediation costs and timelines. Recommend immediate rollout of the HyperCore platform to key subcontractors to accelerate their readiness and secure the prime's eligibility for future contracts.</p>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}