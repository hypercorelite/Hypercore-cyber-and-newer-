import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { CheckCircle, Clock, Target, Zap } from 'lucide-react';

const currentDeliverables = [
    {
        category: "AI-Powered Assessment & Documentation",
        status: "AVAILABLE TODAY",
        features: [
            "110-control NIST SP 800-171 gap analysis (automated)",
            "Complete System Security Plan (SSP) generation",
            "All 14 CMMC Level 2 policy documents (auto-generated)",
            "SPRS score calculation and validation", 
            "Evidence collection templates and guidance",
            "90-day implementation roadmap",
            "AI assistant for CMMC questions"
        ],
        delivery_time: "Instant generation (minutes, not months)"
    },
    {
        category: "Compliance Management Tools", 
        status: "AVAILABLE TODAY",
        features: [
            "Control prioritization matrix",
            "POA&M (Plan of Action & Milestones) generator",
            "Implementation timeline tracking",
            "Evidence collection tracker",
            "Control traceability matrix",
            "Mock assessment preparation",
            "Automated compliance reporting"
        ],
        delivery_time: "Real-time tracking and updates"
    },
    {
        category: "Knowledge & Support Infrastructure",
        status: "AVAILABLE TODAY", 
        features: [
            "Expert knowledge base (NIST, DoD guidance)",
            "AI-powered support chat",
            "Regulatory update notifications",
            "Best practices library",
            "Implementation guides and templates",
            "Video tutorials and walkthroughs"
        ],
        delivery_time: "24/7 availability"
    }
];

const nearTermCapabilities = [
    {
        category: "Enhanced Automation (3-6 months)",
        features: [
            "Continuous compliance monitoring",
            "Automated policy updates when regulations change",
            "Integration with common security tools",
            "Advanced reporting and analytics",
            "Multi-framework support (SOC 2, ISO 27001)"
        ],
        confidence: "High - core platform extensions"
    },
    {
        category: "Scale Infrastructure (6-12 months)",
        features: [
            "Enterprise multi-tenant management",
            "Advanced user role management", 
            "API integrations with GRC tools",
            "Custom branding for RPOs/consultants",
            "White-label partner solutions"
        ],
        confidence: "High - planned development roadmap"
    }
];

const projectedImpacts = [
    {
        claim: "72-hour contractor onboarding → enables rapid mobilization",
        reality: "**PROJECTION**: Based on instant document generation + 72-hour implementation sprint",
        current_state: "Documents generate instantly; implementation time depends on contractor resources",
        confidence: "Medium - requires validation with real contractors"
    },
    {
        claim: "Aggregated intelligence from 20K+ networks → unprecedented visibility", 
        reality: "**STRATEGIC VISION**: Requires reaching significant market penetration first",
        current_state: "AI models trained on public NIST/DoD data; no contractor network intelligence yet",
        confidence: "Low - depends on user adoption at scale"
    },
    {
        claim: "Instant identification of compliant alternatives",
        reality: "**PROJECTION**: Requires marketplace/directory of assessed contractors",
        current_state: "Can instantly assess individual contractors; no database of pre-assessed alternatives",
        confidence: "Medium - technically feasible, needs business development"
    },
    {
        claim: "Prevents supply chain collapse through SMB viability",
        reality: "**MARKET IMPACT HYPOTHESIS**: Based on cost reduction enabling more SMBs to compete",
        current_state: "Platform reduces individual compliance costs by 75-90%",
        confidence: "High on individual impact, Medium on market-level effects"
    },
    {
        claim: "Predictive threat modeling → prevents breaches",
        reality: "**FUTURE CAPABILITY**: Requires aggregated data from many contractors",
        current_state: "AI identifies compliance gaps; no predictive threat intelligence yet",
        confidence: "Low - significant development and data requirements"
    }
];

export default function CurrentCapabilitiesVsProjections() {
    return (
        <div className="space-y-8 p-6">
            <div className="text-center">
                <h1 className="text-4xl font-bold text-gray-900 mb-4">
                    Current Deliverables vs. Future Impact Projections
                </h1>
                <p className="text-xl text-gray-600 max-w-4xl mx-auto">
                    Honest assessment of what's available today versus strategic vision projections
                </p>
            </div>

            <Alert className="bg-blue-50 border-blue-200">
                <CheckCircle className="h-4 w-4 text-blue-600" />
                <AlertTitle className="text-blue-800">Transparency Commitment</AlertTitle>
                <AlertDescription className="text-blue-700">
                    We separate current capabilities from future projections to ensure honest positioning with prospects and partners. Current deliverables are battle-tested; projections are based on reasonable scaling assumptions.
                </AlertDescription>
            </Alert>

            {/* Current Deliverables */}
            <div className="space-y-6">
                <h2 className="text-3xl font-bold text-green-800 flex items-center gap-3">
                    <CheckCircle className="w-8 h-8" />
                    Available TODAY - Proven Deliverables
                </h2>
                
                <div className="grid md:grid-cols-1 gap-6">
                    {currentDeliverables.map((category, index) => (
                        <Card key={index} className="border-l-4 border-green-500 bg-green-50">
                            <CardHeader>
                                <div className="flex justify-between items-start">
                                    <CardTitle className="text-xl">{category.category}</CardTitle>
                                    <Badge className="bg-green-600 text-white">{category.status}</Badge>
                                </div>
                                <CardDescription className="text-green-800 font-medium">
                                    {category.delivery_time}
                                </CardDescription>
                            </CardHeader>
                            <CardContent>
                                <ul className="space-y-2">
                                    {category.features.map((feature, i) => (
                                        <li key={i} className="flex items-start gap-2">
                                            <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                                            <span className="text-gray-700">{feature}</span>
                                        </li>
                                    ))}
                                </ul>
                            </CardContent>
                        </Card>
                    ))}
                </div>
            </div>

            {/* Near-Term Capabilities */}
            <div className="space-y-6">
                <h2 className="text-3xl font-bold text-blue-800 flex items-center gap-3">
                    <Clock className="w-8 h-8" />
                    Near-Term Development (3-12 months)
                </h2>
                
                <div className="grid md:grid-cols-2 gap-6">
                    {nearTermCapabilities.map((category, index) => (
                        <Card key={index} className="border-l-4 border-blue-500 bg-blue-50">
                            <CardHeader>
                                <CardTitle className="text-xl">{category.category}</CardTitle>
                                <Badge className="bg-blue-600 text-white">{category.confidence}</Badge>
                            </CardHeader>
                            <CardContent>
                                <ul className="space-y-2">
                                    {category.features.map((feature, i) => (
                                        <li key={i} className="flex items-start gap-2">
                                            <Clock className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                                            <span className="text-gray-700">{feature}</span>
                                        </li>
                                    ))}
                                </ul>
                            </CardContent>
                        </Card>
                    ))}
                </div>
            </div>

            {/* Projected Impacts */}
            <div className="space-y-6">
                <h2 className="text-3xl font-bold text-orange-800 flex items-center gap-3">
                    <Target className="w-8 h-8" />
                    Strategic Impact Projections (1-5 years)
                </h2>
                
                <Alert className="bg-orange-50 border-orange-200">
                    <Target className="h-4 w-4 text-orange-600" />
                    <AlertTitle className="text-orange-800">Projection Disclaimer</AlertTitle>
                    <AlertDescription className="text-orange-700">
                        These impacts are based on scaling assumptions and market penetration projections. While technically feasible, they require significant user adoption and market development to achieve.
                    </AlertDescription>
                </Alert>

                <div className="space-y-4">
                    {projectedImpacts.map((projection, index) => (
                        <Card key={index} className="border-l-4 border-orange-500">
                            <CardContent className="pt-6">
                                <div className="space-y-3">
                                    <h4 className="font-bold text-lg text-gray-900">{projection.claim}</h4>
                                    <div className="p-3 bg-orange-50 rounded border border-orange-200">
                                        <p className="text-orange-800 font-medium">{projection.reality}</p>
                                    </div>
                                    <div className="p-3 bg-gray-50 rounded">
                                        <p className="text-sm text-gray-600"><strong>Current State:</strong> {projection.current_state}</p>
                                    </div>
                                    <div className="flex justify-between items-center">
                                        <Badge variant="outline" className={`${
                                            projection.confidence.startsWith('High') ? 'border-green-500 text-green-700' :
                                            projection.confidence.startsWith('Medium') ? 'border-yellow-500 text-yellow-700' :
                                            'border-red-500 text-red-700'
                                        }`}>
                                            {projection.confidence}
                                        </Badge>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    ))}
                </div>
            </div>

            {/* Honest Positioning */}
            <Card className="bg-gradient-to-r from-gray-50 to-gray-100">
                <CardContent className="p-8">
                    <h3 className="text-2xl font-bold text-gray-900 mb-4">
                        Honest Positioning for Prospects
                    </h3>
                    <div className="grid md:grid-cols-2 gap-6 text-sm">
                        <div>
                            <h4 className="font-bold text-green-800 mb-2">What You Get Today:</h4>
                            <ul className="space-y-1 text-gray-700">
                                <li>• Complete CMMC Level 2 documentation in minutes</li>
                                <li>• 75-90% reduction in compliance preparation time</li>
                                <li>• AI-verified accuracy eliminating human errors</li>
                                <li>• Instant SPRS scoring and gap identification</li>
                                <li>• 90-day guided implementation roadmap</li>
                            </ul>
                        </div>
                        <div>
                            <h4 className="font-bold text-orange-800 mb-2">What We're Building Toward:</h4>
                            <ul className="space-y-1 text-gray-700">
                                <li>• Industry-wide threat intelligence sharing</li>
                                <li>• Predictive compliance risk modeling</li>
                                <li>• Instant contractor verification marketplace</li>
                                <li>• Real-time supply chain resilience monitoring</li>
                                <li>• Essential DIB infrastructure platform</li>
                            </ul>
                        </div>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}