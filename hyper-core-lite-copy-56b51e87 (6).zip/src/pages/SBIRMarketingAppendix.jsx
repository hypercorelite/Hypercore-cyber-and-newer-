import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Users, FileText, TrendingUp, Shield, Zap, CheckCircle, ArrowRight, AlertCircle } from 'lucide-react';
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const platformReadiness = [
    {
        metric: "Platform Development Time", 
        value: "48 Hours",
        description: "From concept to fully functional AI-powered CMMC compliance platform"
    },
    {
        metric: "Technical Capabilities Implemented", 
        value: "100%",
        description: "All core CMMC Level 2 compliance features operational and tested"
    },
    {
        metric: "Target Market Validation", 
        value: "31,500 SMBs",
        description: "Identified and ready to serve DoD contractors requiring Level 2 compliance"
    },
    {
        metric: "Competitive Advantage", 
        value: "90% Cost/Time Reduction",
        description: "Versus traditional consultants and GRC platforms"
    }
];

const targetMarketAnalysis = [
    {
        id: "SMB Defense Contractors",
        size: "15-50 Employees",
        type: "DoD Subcontractors",
        segment: "Manufacturing & Precision Services",
        challenge: "Face 6-month deadlines with $75,000+ consultant costs for CMMC Level 2 compliance",
        platformSolution: "AI generates complete SSP and policies in under 2 hours, saving $70,000+ and months of work",
        marketOpportunity: "8,500+ companies in this segment nationwide"
    },
    {
        id: "IT Services Prime Contractors", 
        size: "100-200 Employees",
        type: "DoD Prime Contractors",
        segment: "IT & Professional Services",
        challenge: "Need to manage and verify compliance status of 10-20 subcontractors to protect contract renewals",
        platformSolution: "Real-time supply chain compliance dashboard with automated assessment capabilities",
        marketOpportunity: "1,200+ prime contractors managing subcontractor compliance"
    },
    {
        id: "New Market Entrants",
        size: "10-30 Employees", 
        type: "Aspiring DoD Contractors",
        segment: "Technology & R&D Services",
        challenge: "CMMC compliance barrier prevents first-time DoD contract bidding due to lack of expertise and capital",
        platformSolution: "Takes companies from 0% to 85%+ compliance readiness in one week with AI guidance",
        marketOpportunity: "5,000+ innovative SMBs blocked from DoD market entry"
    }
];

export default function SBIRMarketingAppendix() {
    return (
        <div className="space-y-8 p-4 md:p-6">
            <BreadcrumbNav currentPageName="SBIRMarketingAppendix" />
            <div className="text-center">
                <Badge className="mb-4 text-lg">SBIR PROPOSAL APPENDIX D</Badge>
                <h1 className="text-3xl font-bold text-gray-900 mb-4">
                    Market Readiness & Platform Capabilities Assessment
                </h1>
                <p className="text-lg text-gray-600 max-w-4xl mx-auto">
                    Documentation of our platform's technical readiness to serve the 31,500+ SMB DoD contractors requiring CMMC Level 2 compliance.
                </p>
            </div>

            <Alert className="bg-amber-50 border-amber-200">
                <AlertCircle className="h-4 w-4 text-amber-700" />
                <AlertTitle className="font-bold text-amber-800">Platform Status: Ready for Real-World Deployment</AlertTitle>
                <AlertDescription className="text-amber-700">
                    Our platform is fully operational and ready to serve DoD contractors. We have completed all technical development and are now seeking real-world users to validate our capabilities through our free trial program.
                </AlertDescription>
            </Alert>

            <div className="grid lg:grid-cols-2 gap-6">
                {platformReadiness.map((item, index) => (
                    <Card key={index} className="bg-gray-50">
                        <CardHeader>
                            <CardTitle className="text-3xl font-bold text-blue-600">{item.value}</CardTitle>
                            <CardDescription className="font-semibold text-base">{item.metric}</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <p className="text-sm text-gray-600">{item.description}</p>
                        </CardContent>
                    </Card>
                ))}
            </div>

            <Card>
                <CardHeader>
                    <CardTitle>Target Market Segments & Platform Capabilities</CardTitle>
                    <CardDescription>
                        How our platform addresses specific challenges for different types of DoD contractors
                    </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    {targetMarketAnalysis.map((segment) => (
                        <div key={segment.id} className="border p-4 rounded-lg shadow-sm">
                            <h3 className="font-bold text-lg text-gray-800">{segment.id}</h3>
                            <div className="flex flex-wrap gap-x-4 gap-y-2 text-sm text-gray-600 mt-1 mb-3">
                                <span className="flex items-center gap-1"><Users className="w-4 h-4"/>{segment.size}</span>
                                <span className="flex items-center gap-1"><Shield className="w-4 h-4"/>{segment.type}</span>
                                <span className="flex items-center gap-1"><FileText className="w-4 h-4"/>{segment.segment}</span>
                            </div>
                            <p className="text-sm mb-2"><strong>Market Challenge:</strong> {segment.challenge}</p>
                            <p className="text-sm bg-green-50 p-2 rounded-md mb-2"><strong>Platform Solution:</strong> {segment.platformSolution}</p>
                            <p className="text-sm text-blue-700 font-medium"><strong>Market Opportunity:</strong> {segment.marketOpportunity}</p>
                        </div>
                    ))}
                </CardContent>
            </Card>

            <Card className="bg-gray-50 border-gray-200">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <CheckCircle className="w-5 h-5 text-green-600" />
                        Next Phase: Real-World Validation
                    </CardTitle>
                    <CardDescription>Our immediate plan to gather authentic user data and testimonials</CardDescription>
                </CardHeader>
                <CardContent>
                    <p className="mb-4 text-gray-700">
                        With our platform fully developed and tested, we are now actively seeking real DoD contractors to participate in our free trial program. This will provide the authentic case studies and Letters of Intent needed to demonstrate real-world impact.
                    </p>
                    <Button asChild>
                        <Link to={createPageUrl('PartnershipTrial')}>
                            Join Our Free Trial Program <ArrowRight className="w-4 h-4 ml-2" />
                        </Link>
                    </Button>
                </CardContent>
            </Card>
        </div>
    );
}