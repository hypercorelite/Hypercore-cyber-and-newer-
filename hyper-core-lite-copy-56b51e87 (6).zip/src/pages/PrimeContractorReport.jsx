import React, { useState, useEffect } from 'react';
import { TestingLog } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';
import { Progress } from "@/components/ui/progress";
import { CheckCircle, Download, FileText, Target, Shield, Zap } from 'lucide-react';
import { toast } from 'sonner';
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";
import { generatePrimeContractorReport } from '@/api/functions';

export default function PrimeContractorReport() {
    const [latestResults, setLatestResults] = useState(null);
    const [isLoading, setIsLoading] = useState(true);
    const [isGenerating, setIsGenerating] = useState(false);
    
    useEffect(() => {
        const fetchLatestResults = async () => {
            try {
                const logs = await TestingLog.filter(
                    { test_type: 'nist_accuracy_validation_L2', status: 'SUCCESS' },
                    '-created_date',
                    1
                );
                if (logs.length > 0) {
                    const resultsSummary = JSON.parse(logs[0].results_summary || '{}');
                    setLatestResults({
                        ...resultsSummary,
                        date: logs[0].created_date,
                    });
                }
            } catch (error) {
                toast.error('Failed to fetch latest validation results.');
                console.error(error);
            } finally {
                setIsLoading(false);
            }
        };
        fetchLatestResults();
    }, []);

    const handleGenerateReport = async () => {
        setIsGenerating(true);
        toast.info("Generating your Prime Contractor Due Diligence Report...");
        try {
            const { data } = await generatePrimeContractorReport({ 
                primeContractorName: "Fortune 500 Defense Prime",
                testResults: {
                    nistAccuracy: latestResults.accuracy,
                    avgConfidence: latestResults.avgConfidence
                }
            });
            
            if(data.success) {
                toast.success(data.summary);
                // In a real scenario, this would trigger a PDF download.
                // For now, we'll just show a success message.
            } else {
                 throw new Error(data.error || 'Report generation failed');
            }
        } catch (error) {
            toast.error(error.message);
        } finally {
            setIsGenerating(false);
        }
    };

    if (isLoading) {
        return <div>Loading latest test results...</div>;
    }

    if (!latestResults) {
        return (
            <Alert variant="destructive">
                <AlertTitle>No Validation Data Found</AlertTitle>
                <AlertDescription>
                    Please run a successful NIST Accuracy Validation test before generating a report.
                </AlertDescription>
            </Alert>
        );
    }

    return (
        <div className="space-y-6">
            <BreadcrumbNav currentPageName="PrimeContractorReport" />
            
            <div className="text-center">
                <h1 className="text-3xl font-bold text-gray-900 flex items-center justify-center gap-3">
                    <FileText className="w-8 h-8 text-blue-600" />
                    Prime Contractor Due Diligence Report
                </h1>
                <p className="text-lg text-gray-600 mt-2">
                    Package your validated, enterprise-ready metrics into a professional report.
                </p>
            </div>

            <Card>
                <CardHeader>
                    <CardTitle>Latest Validated Metrics</CardTitle>
                    <CardDescription>
                        Based on the test run on {new Date(latestResults.date).toLocaleString()}
                    </CardDescription>
                </CardHeader>
                <CardContent className="grid md:grid-cols-3 gap-6">
                    <div className="text-center p-4 bg-green-50 rounded-lg">
                        <div className="flex items-center justify-center gap-2">
                           <Target className="w-6 h-6 text-green-700"/>
                           <div className="text-3xl font-bold text-green-700">{latestResults.accuracy}%</div>
                        </div>
                        <div className="text-sm text-green-600 mt-1">NIST Mapping Accuracy</div>
                    </div>
                     <div className="text-center p-4 bg-blue-50 rounded-lg">
                        <div className="flex items-center justify-center gap-2">
                           <Shield className="w-6 h-6 text-blue-700"/>
                           <div className="text-3xl font-bold text-blue-700">{latestResults.avgConfidence}%</div>
                        </div>
                        <div className="text-sm text-blue-600 mt-1">AI Confidence Score</div>
                    </div>
                     <div className="text-center p-4 bg-purple-50 rounded-lg">
                        <div className="flex items-center justify-center gap-2">
                           <Zap className="w-6 h-6 text-purple-700"/>
                           <div className="text-3xl font-bold text-purple-700">{latestResults.correctMappings}/{latestResults.totalControls}</div>
                        </div>
                        <div className="text-sm text-purple-600 mt-1">Correct Mappings</div>
                    </div>
                </CardContent>
            </Card>

            <Alert className="bg-green-50 border-green-200">
                <CheckCircle className="h-4 w-4 text-green-700" />
                <AlertTitle className="text-green-800">Ready for Prime Time</AlertTitle>
                <AlertDescription className="text-green-700">
                    Your platform's accuracy of <strong>{latestResults.accuracy}%</strong> decisively exceeds the 95% threshold required by prime contractors. This data provides objective proof of your platform's reliability and readiness for enterprise deployment.
                </AlertDescription>
            </Alert>
            
            <div className="text-center">
                <Button onClick={handleGenerateReport} disabled={isGenerating} size="lg">
                    <Download className="mr-2 h-5 w-5" />
                    {isGenerating ? 'Generating Report...' : 'Generate & Download PDF Report'}
                </Button>
            </div>
        </div>
    );
}