import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { LetterOfIntent } from "@/api/entities";
import { ClientOnboarding } from "@/api/entities";
import { ClientEngagement } from "@/api/entities";
import { FileSignature, Users, TrendingUp, Award, ExternalLink, ArrowRight } from 'lucide-react';
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function LOITrackingDashboard() {
    const [loiData, setLoiData] = useState({
        totalTrialUsers: 0,
        toolUsersNeedingLOI: 0,
        submittedLOIs: 0,
        conversionRate: 0,
        sbirValidationGoal: 50,
        timeToDecember5: 0,
        companyTypes: {},
        priorityFeatures: {}
    });
    const [recentLOIs, setRecentLOIs] = useState([]);
    const [trialUsersNeedingLOI, setTrialUsersNeedingLOI] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        loadLOIData();
    }, []);

    const loadLOIData = async () => {
        try {
            const [lois, trialUsers, engagements] = await Promise.all([
                LetterOfIntent.list('-created_date', 200),
                ClientOnboarding.list('-created_date', 200),
                ClientEngagement.list('-created_date', 500)
            ]);

            // Calculate days until Dec 5th
            const dec5 = new Date('2025-12-05');
            const today = new Date();
            const daysLeft = Math.ceil((dec5 - today) / (1000 * 60 * 60 * 24));

            // Find trial users who used tools but haven't submitted LOI
            const loiEmails = new Set(lois.map(loi => loi.repEmail));
            const toolUsers = engagements.filter(e => 
                e.engagement_type === 'pdf_downloaded' || 
                e.engagement_type === 'assessment_completed'
            );
            const toolUserEmails = new Set(toolUsers.map(e => e.client_email));
            
            const needsLOI = trialUsers.filter(user => 
                toolUserEmails.has(user.client_email) && 
                !loiEmails.has(user.client_email) &&
                new Date(user.created_date) < new Date(Date.now() - 24 * 60 * 60 * 1000)
            );

            // Analyze LOI data
            const companyTypes = {};
            const priorityFeatures = {};
            lois.forEach(loi => {
                companyTypes[loi.companyName] = (companyTypes[loi.companyName] || 0) + 1;
                priorityFeatures[loi.priorityFeatures] = (priorityFeatures[loi.priorityFeatures] || 0) + 1;
            });

            const conversionRate = trialUsers.length > 0 ? ((lois.length / trialUsers.length) * 100).toFixed(1) : 0;

            setLoiData({
                totalTrialUsers: trialUsers.length,
                toolUsersNeedingLOI: needsLOI.length,
                submittedLOIs: lois.length,
                conversionRate: parseFloat(conversionRate),
                sbirValidationGoal: 50,
                timeToDecember5: Math.max(0, daysLeft),
                companyTypes,
                priorityFeatures
            });

            setRecentLOIs(lois.slice(0, 10));
            setTrialUsersNeedingLOI(needsLOI.slice(0, 15));

        } catch (error) {
            console.error('Failed to load LOI data:', error);
        } finally {
            setLoading(false);
        }
    };

    if (loading) {
        return <div className="p-8 text-center">Loading LOI tracking data...</div>;
    }

    const sbirProgressPercent = ((loiData.submittedLOIs / loiData.sbirValidationGoal) * 100).toFixed(0);

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <div>
                    <h1 className="text-3xl font-bold">SBIR Validation Pipeline</h1>
                    <p className="text-gray-600">Track LOI submissions from trial users to validate DIB supply chain market</p>
                </div>
                <div className="text-right">
                    <div className="text-2xl font-bold text-red-600">{loiData.timeToDecember5} days</div>
                    <div className="text-sm text-gray-600">until Dec 5th deadline</div>
                </div>
            </div>

            {/* SBIR Progress Alert */}
            <Alert className="bg-blue-50 border-blue-200">
                <Award className="h-4 w-4 text-blue-700" />
                <AlertTitle className="text-blue-800 font-bold">SBIR Grant Validation Progress</AlertTitle>
                <AlertDescription className="text-blue-700">
                    <div className="mt-2">
                        <div className="flex justify-between items-center mb-1">
                            <span>Market Validation Progress: {loiData.submittedLOIs} / {loiData.sbirValidationGoal} LOIs</span>
                            <span className="font-bold">{sbirProgressPercent}%</span>
                        </div>
                        <div className="w-full bg-blue-200 rounded-full h-2">
                            <div className="bg-blue-600 h-2 rounded-full" style={{width: `${Math.min(100, sbirProgressPercent)}%`}}></div>
                        </div>
                        <p className="text-sm mt-2">Each LOI from a real DoD contractor validates our solution for the Defense Industrial Base supply chain.</p>
                    </div>
                </AlertDescription>
            </Alert>

            {/* Key Metrics */}
            <div className="grid md:grid-cols-4 gap-6">
                <Card>
                    <CardHeader className="pb-2">
                        <CardTitle className="text-sm flex items-center gap-2">
                            <Users className="w-4 h-4" />
                            Trial Users (Total)
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-3xl font-bold">{loiData.totalTrialUsers}</p>
                        <p className="text-sm text-gray-600">Free trial signups</p>
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader className="pb-2">
                        <CardTitle className="text-sm flex items-center gap-2">
                            <TrendingUp className="w-4 h-4 text-orange-600" />
                            Used Tools, Need LOI
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-3xl font-bold text-orange-600">{loiData.toolUsersNeedingLOI}</p>
                        <p className="text-sm text-gray-600">Ready for LOI conversion</p>
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader className="pb-2">
                        <CardTitle className="text-sm flex items-center gap-2">
                            <FileSignature className="w-4 h-4 text-green-600" />
                            SBIR Validation LOIs
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-3xl font-bold text-green-600">{loiData.submittedLOIs}</p>
                        <p className="text-sm text-gray-600">Market validation evidence</p>
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader className="pb-2">
                        <CardTitle className="text-sm flex items-center gap-2">
                            <Award className="w-4 h-4" />
                            Trial-to-LOI Rate
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-3xl font-bold">{loiData.conversionRate}%</p>
                        <Badge variant={loiData.conversionRate > 5 ? "default" : "destructive"}>
                            {loiData.conversionRate > 5 ? "Strong" : "Needs Focus"}
                        </Badge>
                    </CardContent>
                </Card>
            </div>

            {/* Tool Users Ready for LOI Conversion */}
            <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                    <div>
                        <CardTitle className="flex items-center gap-2">
                            <TrendingUp className="w-5 h-5 text-orange-600" />
                            High-Value Users Ready for LOI
                        </CardTitle>
                        <CardDescription>
                            Trial users who used your tools but haven't submitted SBIR validation LOI yet
                        </CardDescription>
                    </div>
                    <Button asChild>
                        <Link to={createPageUrl('LOIGenerator')}>
                            Direct to LOI Generator <ArrowRight className="w-4 h-4 ml-2" />
                        </Link>
                    </Button>
                </CardHeader>
                <CardContent>
                    {trialUsersNeedingLOI.length > 0 ? (
                        <div className="space-y-3">
                            {trialUsersNeedingLOI.map((user, index) => (
                                <div key={index} className="flex justify-between items-center p-3 bg-orange-50 border border-orange-200 rounded-lg">
                                    <div>
                                        <p className="font-medium">{user.client_name}</p>
                                        <p className="text-sm text-gray-600">{user.client_email}</p>
                                        <p className="text-sm font-medium text-orange-700">{user.company_name}</p>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        <Badge variant="outline">Used Tools</Badge>
                                        <Button size="sm" asChild>
                                            <Link to={createPageUrl('LOIGenerator')}>
                                                Send LOI Link
                                            </Link>
                                        </Button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    ) : (
                        <p className="text-center text-gray-500 py-8">All tool users have submitted LOIs! 🎉</p>
                    )}
                </CardContent>
            </Card>

            {/* Recent LOI Submissions */}
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <FileSignature className="w-5 h-5 text-green-600" />
                        Recent SBIR Validation LOIs
                    </CardTitle>
                    <CardDescription>Latest Letters of Intent from DoD contractors</CardDescription>
                </CardHeader>
                <CardContent>
                    {recentLOIs.length > 0 ? (
                        <div className="space-y-3">
                            {recentLOIs.map((loi, index) => (
                                <div key={index} className="flex justify-between items-center p-3 bg-green-50 border border-green-200 rounded-lg">
                                    <div>
                                        <p className="font-medium">{loi.companyName}</p>
                                        <p className="text-sm text-gray-600">{loi.repName} - {loi.repTitle}</p>
                                        <div className="flex gap-2 mt-1">
                                            <Badge className="text-xs bg-green-100 text-green-800">{loi.commitmentLevel}</Badge>
                                            <Badge variant="outline" className="text-xs">{loi.priorityFeatures}</Badge>
                                        </div>
                                    </div>
                                    <div className="text-right">
                                        <p className="text-sm font-medium">CAGE: {loi.cageCode}</p>
                                        <p className="text-xs text-gray-600">{new Date(loi.created_date).toLocaleDateString()}</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    ) : (
                        <p className="text-center text-gray-500 py-8">No LOIs submitted yet. Drive trial users to the LOI generator!</p>
                    )}
                </CardContent>
            </Card>

            {/* SBIR Strategy Navigation */}
            <Card className="bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
                <CardHeader>
                    <CardTitle>SBIR Grant Strategy Navigation</CardTitle>
                    <CardDescription>Quick access to SBIR proposal components using LOI data</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="grid md:grid-cols-3 gap-4">
                        <Button asChild variant="outline" className="h-auto p-4 flex flex-col items-start">
                            <Link to={createPageUrl('SBIRProposalEvidence')}>
                                <Award className="w-5 h-5 mb-2" />
                                <div className="text-left">
                                    <div className="font-semibold">Proposal Evidence</div>
                                    <div className="text-sm text-gray-600">Use LOI data in proposal</div>
                                </div>
                            </Link>
                        </Button>
                        <Button asChild variant="outline" className="h-auto p-4 flex flex-col items-start">
                            <Link to={createPageUrl('TraceabilityMatrix')}>
                                <FileSignature className="w-5 h-5 mb-2" />
                                <div className="text-left">
                                    <div className="font-semibold">Back to Tools</div>
                                    <div className="text-sm text-gray-600">Show LOI users the tools</div>
                                </div>
                            </Link>
                        </Button>
                        <Button asChild variant="outline" className="h-auto p-4 flex flex-col items-start">
                            <Link to={createPageUrl('PartnershipTrial')}>
                                <Users className="w-5 h-5 mb-2" />
                                <div className="text-left">
                                    <div className="font-semibold">Drive More Trials</div>
                                    <div className="text-sm text-gray-600">Get more DoD contractors</div>
                                </div>
                            </Link>
                        </Button>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}