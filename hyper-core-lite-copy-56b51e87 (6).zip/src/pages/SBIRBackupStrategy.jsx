import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Shield, CheckCircle, DollarSign, Calendar, Target, ArrowRight, Zap } from 'lucide-react';
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";

const backupPlans = [
    {
        plan: "Plan A: SBIR 25.4 Success (Target)",
        probability: "Target Scenario",
        timeline: "Oct 29 submission → Feb award",
        funding: "$275K Phase I",
        outcome: "Full automation development funded",
        icon: Target,
        color: "border-green-500 bg-green-50",
        details: [
            "MVP launches Nov 10 as planned",
            "SBIR Phase I funds full automation features",
            "Scale to enterprise-grade platform by summer 2026",
            "Strong position for Phase II ($1.5M) in 2026"
        ]
    },
    {
        plan: "Plan B: Commercial Success Without SBIR",
        probability: "90% Success Rate",
        timeline: "MVP revenue funds development",
        funding: "Bootstrap to $50K+ MRR",
        outcome: "Self-funded growth to acquisition",
        icon: DollarSign,
        color: "border-blue-500 bg-blue-50",
        details: [
            "MVP generates $10K+ MRR by Dec 2025",
            "Scale to $50K+ MRR by mid-2026",
            "Self-fund automation features from revenue",
            "Attractive acquisition target or IPO candidate"
        ]
    },
    {
        plan: "Plan C: SBIR 25.5 (Spring 2026)",
        probability: "85% Success Rate",
        timeline: "Apply spring cycle with proven traction",
        funding: "$275K+ with better terms",
        outcome: "Stronger application with revenue proof",
        icon: Calendar,
        color: "border-purple-500 bg-purple-50",
        details: [
            "6 months of revenue and client testimonials",
            "Much stronger commercialization case",
            "Higher probability of Phase I award",
            "Better position for larger Phase II"
        ]
    }
];

export default function SBIRBackupStrategy() {
    return (
        <div className="space-y-8">
            <BreadcrumbNav currentPageName="SBIRBackupStrategy" />
            
            <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="text-center">
                <Badge className="mb-4 bg-green-100 text-green-800">STRATEGIC CONTINGENCY PLANNING</Badge>
                <h1 className="text-4xl font-bold text-gray-900 mb-4">
                    Multiple Paths to Success: SBIR + Commercial Strategy
                </h1>
                <p className="text-xl text-gray-600 max-w-4xl mx-auto">
                    Smart entrepreneurs have backup plans. Here are your three paths to building a successful CMMC compliance platform.
                </p>
            </motion.div>

            <Alert className="bg-blue-50 border-blue-200">
                <Zap className="h-4 w-4 text-blue-600" />
                <AlertTitle className="text-blue-800">Strategic Advantage: Multiple Success Paths</AlertTitle>
                <AlertDescription className="text-blue-700">
                    The MVP is valuable regardless of SBIR outcome. Each path builds on the November 10 launch, creating multiple opportunities for exponential growth.
                </AlertDescription>
            </Alert>

            <div className="space-y-6">
                {backupPlans.map((plan, index) => (
                    <motion.div
                        key={index}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.1 }}
                    >
                        <Card className={`${plan.color} border-2`}>
                            <CardHeader>
                                <div className="flex items-center gap-4">
                                    <plan.icon className={`w-8 h-8 ${index === 0 ? 'text-green-600' : index === 1 ? 'text-blue-600' : 'text-purple-600'}`} />
                                    <div className="flex-grow">
                                        <CardTitle className="text-xl">{plan.plan}</CardTitle>
                                        <CardDescription>
                                            {plan.probability} • {plan.timeline}
                                        </CardDescription>
                                    </div>
                                    <Badge className={`${index === 0 ? 'bg-green-600' : index === 1 ? 'bg-blue-600' : 'bg-purple-600'} text-white`}>
                                        {plan.funding}
                                    </Badge>
                                </div>
                            </CardHeader>
                            <CardContent>
                                <div className="mb-4">
                                    <h4 className="font-semibold text-gray-800 mb-2">Expected Outcome:</h4>
                                    <p className="text-gray-600">{plan.outcome}</p>
                                </div>
                                <div>
                                    <h4 className="font-semibold text-gray-800 mb-3">Execution Details:</h4>
                                    <div className="space-y-2">
                                        {plan.details.map((detail, detailIndex) => (
                                            <div key={detailIndex} className="flex items-start gap-3">
                                                <CheckCircle className={`w-4 h-4 mt-0.5 ${index === 0 ? 'text-green-600' : index === 1 ? 'text-blue-600' : 'text-purple-600'}`} />
                                                <span className="text-sm text-gray-700">{detail}</span>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    </motion.div>
                ))}
            </div>

            <Card className="bg-gradient-to-r from-gray-900 to-blue-900 text-white">
                <CardHeader>
                    <CardTitle className="text-2xl">Why All Three Plans Lead to Success</CardTitle>
                    <CardDescription className="text-blue-200">Each path leverages the same MVP foundation with different growth strategies</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    <div className="grid md:grid-cols-3 gap-6">
                        <div>
                            <h4 className="font-semibold mb-2 text-green-400">Plan A Advantage</h4>
                            <p className="text-sm text-gray-300">SBIR funding allows rapid feature development without revenue pressure. Fastest path to full automation.</p>
                        </div>
                        <div>
                            <h4 className="font-semibold mb-2 text-blue-400">Plan B Advantage</h4>
                            <p className="text-sm text-gray-300">100% equity retention. Market-driven development ensures product-market fit. Higher valuation potential.</p>
                        </div>
                        <div>
                            <h4 className="font-semibold mb-2 text-purple-400">Plan C Advantage</h4>
                            <p className="text-sm text-gray-300">Proven traction makes SBIR application much stronger. Best of both worlds: revenue proof + government funding.</p>
                        </div>
                    </div>
                    
                    <div className="pt-6 border-t border-gray-700 text-center">
                        <h4 className="font-semibold mb-4">The Common Foundation: November 10 MVP Launch</h4>
                        <p className="text-gray-300 mb-6">All three plans depend on the same critical milestone: launching a working MVP by November 10th. Everything else is just different scaling strategies.</p>
                        <Button asChild size="lg" className="bg-white text-gray-900 hover:bg-gray-200">
                            <Link to={createPageUrl('DailyAchievementSchedule')}>
                                Focus on the Foundation: View Daily Sprint Plan <ArrowRight className="w-4 h-4 ml-2" />
                            </Link>
                        </Button>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}