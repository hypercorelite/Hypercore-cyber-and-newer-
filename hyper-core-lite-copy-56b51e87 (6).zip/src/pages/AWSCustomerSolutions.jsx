import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { 
    Phone, MessageSquare, Calendar, Mail, Bot, DollarSign, 
    CheckCircle, ArrowRight, Cloud, Zap, Users, Shield 
} from 'lucide-react';
import { motion } from 'framer-motion';
import { setupProfessionalCommunication } from '@/api/functions';
import { toast } from 'sonner';

export default function AWSCustomerSolutions() {
    const [solutions, setSolutions] = useState(null);
    const [loading, setLoading] = useState(false);

    const loadSolutions = async () => {
        setLoading(true);
        try {
            const response = await setupProfessionalCommunication();
            setSolutions(response.data);
        } catch (error) {
            toast.error('Failed to load communication solutions');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        loadSolutions();
    }, []);

    const awsFreeServices = [
        {
            service: "AWS Connect",
            category: "Phone System",
            free_tier: "90 minutes/month + basic features",
            use_case: "Professional inbound calls with routing",
            setup_time: "2-3 hours",
            monthly_cost: "$0 for light usage",
            integration: "Direct CRM webhook integration",
            icon: Phone,
            color: "text-blue-600"
        },
        {
            service: "AWS SES (Simple Email Service)",
            category: "Email Marketing",
            free_tier: "62,000 emails/month from EC2",
            use_case: "Automated email campaigns and responses",
            setup_time: "30 minutes",
            monthly_cost: "$0 within free tier",
            integration: "Built-in with our email functions",
            icon: Mail,
            color: "text-green-600"
        },
        {
            service: "AWS Lex + Lambda",
            category: "AI Chatbot",
            free_tier: "10,000 text requests/month",
            use_case: "24/7 customer support and lead qualification",
            setup_time: "4-6 hours",
            monthly_cost: "$0 for moderate usage",
            integration: "Direct integration with support tickets",
            icon: Bot,
            color: "text-purple-600"
        },
        {
            service: "AWS EventBridge + Lambda",
            category: "Scheduling Automation",
            free_tier: "1M events/month + 1M Lambda requests",
            use_case: "Appointment scheduling and follow-up automation",
            setup_time: "2-3 hours",
            monthly_cost: "$0 within free limits",
            integration: "Connects with Calendly, Google Calendar",
            icon: Calendar,
            color: "text-orange-600"
        },
        {
            service: "AWS Pinpoint",
            category: "Customer Engagement",
            free_tier: "5,000 targeted users/month",
            use_case: "SMS notifications and customer journeys",
            setup_time: "1-2 hours",
            monthly_cost: "$0 + SMS costs ($0.0075/message)",
            integration: "Multi-channel customer campaigns",
            icon: MessageSquare,
            color: "text-indigo-600"
        },
        {
            service: "AWS API Gateway + Lambda",
            category: "Webhook Integration",
            free_tier: "1M API calls/month + 1M Lambda requests",
            use_case: "Third-party integrations (Calendly, CRM, etc.)",
            setup_time: "1 hour per integration",
            monthly_cost: "$0 within free tier",
            integration: "Universal connector for all services",
            icon: Zap,
            color: "text-yellow-600"
        }
    ];

    const implementationPlan = [
        {
            week: "Week 1",
            title: "Foundation Setup",
            tasks: [
                "Configure AWS SES for professional email",
                "Set up basic Calendly integration",
                "Create callback request system in CRM"
            ],
            cost: "$0",
            result: "Professional email and basic scheduling"
        },
        {
            week: "Week 2", 
            title: "Phone System",
            tasks: [
                "Deploy AWS Connect phone system OR Grasshopper",
                "Configure professional greeting",
                "Set up voicemail-to-email forwarding"
            ],
            cost: "$0-14/month",
            result: "Professional phone presence"
        },
        {
            week: "Week 3",
            title: "AI Support",
            tasks: [
                "Deploy AWS Lex chatbot for basic inquiries",
                "Configure support ticket creation",
                "Test customer support workflows"
            ],
            cost: "$0",
            result: "24/7 automated customer support"
        },
        {
            week: "Week 4",
            title: "Advanced Automation",
            tasks: [
                "Set up EventBridge for follow-up automation",
                "Configure SMS notifications via Pinpoint",
                "Integrate all services with CRM webhooks"
            ],
            cost: "$0 + SMS costs",
            result: "Fully automated customer journey"
        }
    ];

    return (
        <div className="space-y-8">
            <div className="text-center">
                <h1 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-3">
                    Professional Customer Communication
                </h1>
                <p className="text-lg lg:text-xl text-gray-600">
                    AWS free tier solutions for enterprise-grade customer acquisition and support.
                </p>
            </div>

            <Alert className="bg-green-50 border-green-200">
                <Shield className="h-4 w-4 text-green-600" />
                <AlertTitle className="text-green-800">Free Tier Strategy</AlertTitle>
                <AlertDescription className="text-green-700">
                    Using AWS free tier services, you can build a professional customer communication system for $0-50/month that rivals enterprise solutions costing thousands.
                </AlertDescription>
            </Alert>

            {/* AWS Free Services Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {awsFreeServices.map((service, index) => (
                    <motion.div key={index} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.1 }}>
                        <Card className="h-full">
                            <CardHeader>
                                <div className="flex items-center gap-3">
                                    <service.icon className={`w-6 h-6 ${service.color}`} />
                                    <div>
                                        <CardTitle className="text-lg">{service.service}</CardTitle>
                                        <Badge variant="secondary">{service.category}</Badge>
                                    </div>
                                </div>
                            </CardHeader>
                            <CardContent className="space-y-3">
                                <div className="space-y-2 text-sm">
                                    <div><strong>Free Tier:</strong> {service.free_tier}</div>
                                    <div><strong>Use Case:</strong> {service.use_case}</div>
                                    <div><strong>Setup Time:</strong> {service.setup_time}</div>
                                    <div><strong>Monthly Cost:</strong> {service.monthly_cost}</div>
                                    <div><strong>Integration:</strong> {service.integration}</div>
                                </div>
                            </CardContent>
                        </Card>
                    </motion.div>
                ))}
            </div>

            {/* Implementation Timeline */}
            <Card>
                <CardHeader>
                    <CardTitle>4-Week Implementation Plan</CardTitle>
                    <CardDescription>Progressive deployment of AWS customer communication services</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="space-y-6">
                        {implementationPlan.map((phase, index) => (
                            <div key={index} className="flex gap-4">
                                <div className="flex-shrink-0 w-20 text-center">
                                    <Badge variant="outline">{phase.week}</Badge>
                                </div>
                                <div className="flex-grow">
                                    <h4 className="font-semibold text-lg">{phase.title}</h4>
                                    <ul className="list-disc list-inside text-sm text-gray-600 mt-1">
                                        {phase.tasks.map((task, taskIndex) => (
                                            <li key={taskIndex}>{task}</li>
                                        ))}
                                    </ul>
                                    <div className="flex justify-between items-center mt-2">
                                        <span className="text-sm font-medium text-green-600">Cost: {phase.cost}</span>
                                        <span className="text-sm text-gray-500">→ {phase.result}</span>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>

            {/* Cost Comparison */}
            <Card>
                <CardHeader>
                    <CardTitle>Cost Comparison: AWS vs Traditional Solutions</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="overflow-x-auto">
                        <table className="min-w-full divide-y divide-gray-200">
                            <thead className="bg-gray-50">
                                <tr>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Service</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Traditional Cost</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">AWS Free Tier</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Monthly Savings</th>
                                </tr>
                            </thead>
                            <tbody className="bg-white divide-y divide-gray-200">
                                <tr>
                                    <td className="px-6 py-4 text-sm font-medium text-gray-900">Phone System</td>
                                    <td className="px-6 py-4 text-sm text-gray-500">$50-200/month</td>
                                    <td className="px-6 py-4 text-sm text-green-600">$0-20/month</td>
                                    <td className="px-6 py-4 text-sm text-green-600">$50-180/month</td>
                                </tr>
                                <tr>
                                    <td className="px-6 py-4 text-sm font-medium text-gray-900">Email Marketing</td>
                                    <td className="px-6 py-4 text-sm text-gray-500">$30-100/month</td>
                                    <td className="px-6 py-4 text-sm text-green-600">$0/month</td>
                                    <td className="px-6 py-4 text-sm text-green-600">$30-100/month</td>
                                </tr>
                                <tr>
                                    <td className="px-6 py-4 text-sm font-medium text-gray-900">AI Chatbot</td>
                                    <td className="px-6 py-4 text-sm text-gray-500">$100-500/month</td>
                                    <td className="px-6 py-4 text-sm text-green-600">$0/month</td>
                                    <td className="px-6 py-4 text-sm text-green-600">$100-500/month</td>
                                </tr>
                                <tr>
                                    <td className="px-6 py-4 text-sm font-medium text-gray-900">Scheduling System</td>
                                    <td className="px-6 py-4 text-sm text-gray-500">$20-50/month</td>
                                    <td className="px-6 py-4 text-sm text-green-600">$0/month</td>
                                    <td className="px-6 py-4 text-sm text-green-600">$20-50/month</td>
                                </tr>
                                <tr className="bg-green-50">
                                    <td className="px-6 py-4 text-sm font-bold text-gray-900">Total</td>
                                    <td className="px-6 py-4 text-sm font-bold text-gray-500">$200-850/month</td>
                                    <td className="px-6 py-4 text-sm font-bold text-green-600">$0-20/month</td>
                                    <td className="px-6 py-4 text-sm font-bold text-green-600">$200-830/month</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </CardContent>
            </Card>

            {/* Quick Start Actions */}
            <Card>
                <CardHeader>
                    <CardTitle>Immediate Next Steps</CardTitle>
                    <CardDescription>Start building your professional communication system today</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <Button className="h-16 flex flex-col gap-2" onClick={() => toast.info('AWS SES setup guide coming soon')}>
                            <Mail className="w-5 h-5" />
                            <span>Set Up Professional Email</span>
                        </Button>
                        <Button variant="outline" className="h-16 flex flex-col gap-2" onClick={() => toast.info('Calendly integration guide coming soon')}>
                            <Calendar className="w-5 h-5" />
                            <span>Configure Scheduling</span>
                        </Button>
                        <Button variant="outline" className="h-16 flex flex-col gap-2" onClick={() => toast.info('AWS Connect setup guide coming soon')}>
                            <Phone className="w-5 h-5" />
                            <span>Deploy Phone System</span>
                        </Button>
                        <Button variant="outline" className="h-16 flex flex-col gap-2" onClick={() => toast.info('Chatbot deployment guide coming soon')}>
                            <Bot className="w-5 h-5" />
                            <span>Launch AI Support</span>
                        </Button>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}