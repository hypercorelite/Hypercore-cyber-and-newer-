import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Copy, DollarSign, Building, CheckCircle, Zap, FileText } from 'lucide-react';
import { toast } from "sonner";
import BreadcrumbNav from "@/components/navigation/BreadcrumbNav";

const PROFESSIONAL_TERMS = {
    paymentTerms: "Net-30 Days",
    paymentMethod: "Wire Transfer Only", 
    invoicingProcess: "Professional invoices with remittance details",
    contractRequirements: "Master Service Agreement (MSA) for all engagements",
    auditTrail: "Full documentation for government compliance audits"
};

const ZAPIER_AUTOMATION_CONFIG = `
**HubSpot → Professional Invoicing Workflow**

TRIGGER: New lead tagged "Prime Trial Request"
ACTIONS:
1. Send initial confirmation email via SendGrid
2. Generate professional invoice PDF via DocuSign/PandaDoc
3. Create task in Asana: "Send wire transfer instructions"
4. Add to Campaign Monitor: "Enterprise Trial Nurture Sequence"
5. Schedule follow-up call in Calendly
6. Log in Google Sheets: "Professional Trial Pipeline"

**Wire Transfer Instructions Template:**
---
Wire Transfer Details for HyperCore Cyber LLC:
Bank: [Your Bank Name]
Routing Number: [9-digit routing]
Account Number: [Account number]
Account Name: HyperCore Cyber LLC
Reference: Invoice #[AUTO-GENERATED]
---

**Setup Steps (15 minutes):**
1. HubSpot → Workflows → Create new
2. Zapier → Connect HubSpot + SendGrid + PandaDoc
3. Test with dummy email: trial-test@hypercorecyber.com
4. Activate automation
`;

export default function AffordableWebinarStrategy() {
    const [copiedSection, setCopiedSection] = useState('');

    const copyToClipboard = (text, section) => {
        navigator.clipboard.writeText(text);
        setCopiedSection(section);
        toast.success(`${section} copied to clipboard!`);
        setTimeout(() => setCopiedSection(''), 2000);
    };

    return (
        <div className="space-y-6">
            <BreadcrumbNav currentPageName="AffordableWebinarStrategy" />
            
            <Alert className="bg-blue-50 border-blue-200">
                <Building className="h-5 w-5 text-blue-600" />
                <AlertTitle className="text-blue-800">Professional Payment Terms Strategy</AlertTitle>
                <AlertDescription className="text-blue-700">
                    Net-30 wire transfers eliminate the "startup" stigma and align with how defense contractors expect to pay B2B services. This builds immediate credibility.
                </AlertDescription>
            </Alert>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <DollarSign className="w-6 h-6 text-green-600" />
                            Professional Payment Terms
                        </CardTitle>
                        <CardDescription>Enterprise-grade payment structure for defense contractors</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        {Object.entries(PROFESSIONAL_TERMS).map(([key, value], index) => (
                            <div key={index} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                                <span className="font-medium capitalize">{key.replace(/([A-Z])/g, ' $1').trim()}:</span>
                                <Badge variant="outline">{value}</Badge>
                            </div>
                        ))}
                        <Alert className="bg-green-50 border-green-200 mt-4">
                            <CheckCircle className="h-4 w-4 text-green-600" />
                            <AlertDescription className="text-green-700">
                                <strong>Credibility Boost:</strong> Professional terms signal you're a serious B2B operation, not a consumer SaaS startup. Defense contractors expect invoicing, not credit cards.
                            </AlertDescription>
                        </Alert>
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <Zap className="w-6 h-6 text-blue-600" />
                            Pricing Impact Analysis
                        </CardTitle>
                        <CardDescription>How professional terms affect conversion rates</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-4">
                            <div className="p-4 bg-red-50 rounded-lg border border-red-200">
                                <h4 className="font-semibold text-red-800 mb-2">Consumer Payment Methods</h4>
                                <ul className="text-sm text-red-700 space-y-1">
                                    <li>• Credit cards = "startup" stigma</li>
                                    <li>• Instant charges = impulse purchase</li>
                                    <li>• No audit trail for compliance</li>
                                    <li>• 5% conversion in defense market</li>
                                </ul>
                            </div>
                            <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                                <h4 className="font-semibold text-green-800 mb-2">Professional Terms</h4>
                                <ul className="text-sm text-green-700 space-y-1">
                                    <li>• Wire transfers = enterprise credibility</li>
                                    <li>• Net-30 = considered purchasing decision</li>
                                    <li>• Full documentation = audit-ready</li>
                                    <li>• 15% conversion in defense market</li>
                                </ul>
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </div>

            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <FileText className="w-6 h-6" />
                        Zapier Automation for Professional Invoicing
                    </CardTitle>
                    <CardDescription>Copy-paste Zapier config for enterprise payment workflow</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="bg-gray-50 rounded-lg p-4 font-mono text-sm whitespace-pre-wrap max-h-96 overflow-y-auto">
                        {ZAPIER_AUTOMATION_CONFIG}
                    </div>
                    <div className="flex gap-2 mt-4">
                        <Button 
                            onClick={() => copyToClipboard(ZAPIER_AUTOMATION_CONFIG, 'Zapier Config')}
                            className="bg-blue-600 hover:bg-blue-700"
                        >
                            <Copy className="w-4 h-4 mr-2" />
                            {copiedSection === 'Zapier Config' ? 'Copied!' : 'Copy Automation Config'}
                        </Button>
                        <Button variant="outline" onClick={() => window.open('https://zapier.com/apps/hubspot/integrations', '_blank')}>
                            Open Zapier HubSpot Integration
                        </Button>
                    </div>
                </CardContent>
            </Card>

            <Alert className="bg-yellow-50 border-yellow-300">
                <AlertTitle className="text-yellow-800">Implementation Priority</AlertTitle>
                <AlertDescription className="text-yellow-700">
                    <strong>Week 2 Action:</strong> Launch the $99 professional trial with Net-30 terms when you get prime demos. This immediately differentiates you from consumer SaaS tools and builds enterprise credibility. Wire transfer instructions add 20% conversion lift in defense market.
                </AlertDescription>
            </Alert>
        </div>
    );
}