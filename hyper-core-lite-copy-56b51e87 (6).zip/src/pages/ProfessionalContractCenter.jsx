// ... keep existing code (all imports and state) ...

export default function ProfessionalContractCenter() {
    // ... keep existing code (state and functions) ...

    const executeImmediateOutreach = async () => {
        setLoading(true);
        toast.info("Sending DFARS-compliant documentation packages to 5 prime contractors...");
        
        try {
            const { data } = await sendPrimeDocumentationPackage();
            if (data.success) {
                toast.success(`${data.message}`);
                toast.info("Next: Follow up in 3 days with demo scheduling");
            } else {
                throw new Error(data.error || 'Failed to send documentation packages');
            }
        } catch (error) {
            toast.error(`Documentation outreach failed: ${error.message}`);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="space-y-6">
            <BreadcrumbNav currentPageName="ProfessionalContractCenter" />
            
            <div className="text-center">
                <h1 className="text-3xl font-bold text-gray-900 flex items-center justify-center gap-3">
                    <Building className="w-8 h-8 text-blue-600" />
                    DoD Professional Contract Center
                </h1>
                <p className="text-lg text-gray-600 mt-2">
                    Generate MSAs, SOWs, and professional invoices with Net-30 wire transfer terms
                </p>
            </div>

            {/* IMMEDIATE ACTION PANEL - ADDED */}
            <Card className="border-2 border-blue-500 bg-blue-50">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-blue-800">
                        <Rocket className="w-5 h-5" />
                        IMMEDIATE EXECUTION: Day 1 Prime Contractor Outreach
                    </CardTitle>
                    <CardDescription className="text-blue-700">
                        Send DFARS-compliant documentation packages to 5 NoVA prime contractors with your 100% Level 3 validation
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="grid md:grid-cols-2 gap-4 mb-4">
                        <div>
                            <h4 className="font-semibold text-blue-800 mb-2">Target Prime Contractors:</h4>
                            <ul className="text-sm space-y-1">
                                <li>• Leidos (Gerry Fasano) - 1,000 subs, $5M FCA risk</li>
                                <li>• Booz Allen (Karen Dahut) - 800 subs, $4M FCA risk</li>
                                <li>• SAIC (Michael Daniels) - 750 subs, $4.6M FCA risk</li>
                                <li>• GDIT (Daniel Johnson) - 500 subs, $3.5M FCA risk</li>
                                <li>• SPA (Mark Testoni) - 200 subs, $1.5M FCA risk</li>
                            </ul>
                        </div>
                        <div>
                            <h4 className="font-semibold text-blue-800 mb-2">Documentation Package Includes:</h4>
                            <ul className="text-sm space-y-1">
                                <li>✅ DFARS 252.204-7012 compliant MSA</li>
                                <li>✅ 87-day Level 3 SOW template</li>
                                <li>✅ Scalable PSO for subcontractor portfolios</li>
                                <li>✅ NIST SP 800-171 security requirements</li>
                                <li>✅ 100% Level 3 validation proof</li>
                            </ul>
                        </div>
                    </div>
                    <Button 
                        onClick={executeImmediateOutreach} 
                        disabled={loading} 
                        size="lg"
                        className="w-full bg-blue-600 hover:bg-blue-700"
                    >
                        {loading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Rocket className="w-4 h-4 mr-2" />}
                        Execute Day 1 Outreach: Send Documentation to 5 Primes
                    </Button>
                </CardContent>
            </Card>

            {/* ... keep existing code (tab interface and document generators) ... */}
        </div>
    );
}