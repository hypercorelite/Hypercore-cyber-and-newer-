import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CheckCircle, XCircle, AlertTriangle, Clock, DollarSign, FileText, Users, Mail, Database, Zap } from 'lucide-react';
import { motion } from "framer-motion";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function ProgramDeploymentReadiness() {
    const kickstarterReadiness = [
        { feature: "AI-generated CMMC documentation suite (14 policies)", status: "missing", effort: "4-6 weeks", critical: true },
        { feature: "System Security Plan (SSP) template", status: "missing", effort: "3-4 weeks", critical: true },
        { feature: "Plan of Action & Milestones (POA&M) template", status: "missing", effort: "2-3 weeks", critical: true },
        { feature: "2-hour kickoff consultation call infrastructure", status: "partial", effort: "1 week", critical: false },
        { feature: "Final documentation review session", status: "ready", effort: "0", critical: false },
        { feature: "PDF generation system", status: "ready", effort: "0", critical: false },
        { feature: "Email automation", status: "ready", effort: "0", critical: false },
        { feature: "Client portal access", status: "ready", effort: "0", critical: false }
    ];

    const fullProgramReadiness = [
        { feature: "Structured 90-day program workflow", status: "missing", effort: "6-8 weeks", critical: true },
        { feature: "Weekly coaching call scheduling", status: "missing", effort: "2-3 weeks", critical: true },
        { feature: "Evidence review and feedback system", status: "missing", effort: "4-5 weeks", critical: true },
        { feature: "Control implementation tracking", status: "partial", effort: "3-4 weeks", critical: true },
        { feature: "C3PAO-ready evidence package assembly", status: "missing", effort: "5-6 weeks", critical: true },
        { feature: "Direct email support system", status: "ready", effort: "0", critical: false },
        { feature: "Client progress tracking", status: "partial", effort: "2-3 weeks", critical: false },
        { feature: "Payment processing ($7,500)", status: "missing", effort: "1-2 weeks", critical: true }
    ];

    const backendInfrastructure = [
        { component: "AWS Lambda functions", status: "ready", deployment: "immediate" },
        { component: "PostgreSQL database", status: "ready", deployment: "immediate" },
        { component: "SendGrid email system", status: "ready", deployment: "immediate" },
        { component: "PDF generation", status: "ready", deployment: "immediate" },
        { component: "Client authentication", status: "ready", deployment: "immediate" },
        { component: "Admin dashboard", status: "ready", deployment: "immediate" },
        { component: "Partnership CRM", status: "ready", deployment: "immediate" },
        { component: "Basic CMMC assessment logic", status: "ready", deployment: "immediate" }
    ];

    const getStatusColor = (status) => {
        switch (status) {
            case 'ready': return 'bg-green-100 text-green-800 border-green-300';
            case 'partial': return 'bg-yellow-100 text-yellow-800 border-yellow-300';
            case 'missing': return 'bg-red-100 text-red-800 border-red-300';
            default: return 'bg-gray-100 text-gray-800 border-gray-300';
        }
    };

    const getStatusIcon = (status) => {
        switch (status) {
            case 'ready': return <CheckCircle className="w-4 h-4 text-green-600" />;
            case 'partial': return <AlertTriangle className="w-4 h-4 text-yellow-600" />;
            case 'missing': return <XCircle className="w-4 h-4 text-red-600" />;
            default: return <Clock className="w-4 h-4 text-gray-600" />;
        }
    };

    const calculateReadiness = (items) => {
        const ready = items.filter(item => item.status === 'ready').length;
        const partial = items.filter(item => item.status === 'partial').length;
        const total = items.length;
        return Math.round(((ready + partial * 0.5) / total) * 100);
    };

    return (
        <div className="space-y-8">
            <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center"
            >
                <Badge className="mb-4 bg-red-100 text-red-800">🔒 REALITY CHECK</Badge>
                <h1 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-3">
                    Program Deployment Readiness Assessment
                </h1>
                <p className="text-lg lg:text-xl text-gray-600 max-w-4xl mx-auto">
                    Honest assessment of what's deployment-ready vs. what still needs to be built for real-world service delivery.
                </p>
            </motion.div>

            <div className="grid md:grid-cols-2 gap-6">
                <Card className="border-2 border-yellow-300">
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <DollarSign className="w-5 h-5 text-yellow-600" />
                            $5,000 Kickstarter Program
                        </CardTitle>
                        <CardDescription>
                            Deployment Readiness: <Badge className="bg-yellow-100 text-yellow-800">{calculateReadiness(kickstarterReadiness)}%</Badge>
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-2">
                            {kickstarterReadiness.map((item, index) => (
                                <div key={index} className={`p-2 rounded border ${getStatusColor(item.status)}`}>
                                    <div className="flex items-start justify-between">
                                        <div className="flex items-start gap-2 flex-grow">
                                            {getStatusIcon(item.status)}
                                            <span className="text-sm font-medium">{item.feature}</span>
                                        </div>
                                        {item.status !== 'ready' && (
                                            <Badge variant="outline" className="text-xs ml-2">
                                                {item.effort}
                                            </Badge>
                                        )}
                                    </div>
                                </div>
                            ))}
                        </div>
                    </CardContent>
                </Card>

                <Card className="border-2 border-red-300">
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <Users className="w-5 h-5 text-red-600" />
                            $7,500 Full Program
                        </CardTitle>
                        <CardDescription>
                            Deployment Readiness: <Badge className="bg-red-100 text-red-800">{calculateReadiness(fullProgramReadiness)}%</Badge>
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-2">
                            {fullProgramReadiness.map((item, index) => (
                                <div key={index} className={`p-2 rounded border ${getStatusColor(item.status)}`}>
                                    <div className="flex items-start justify-between">
                                        <div className="flex items-start gap-2 flex-grow">
                                            {getStatusIcon(item.status)}
                                            <span className="text-sm font-medium">{item.feature}</span>
                                        </div>
                                        {item.status !== 'ready' && (
                                            <Badge variant="outline" className="text-xs ml-2">
                                                {item.effort}
                                            </Badge>
                                        )}
                                    </div>
                                </div>
                            ))}
                        </div>
                    </CardContent>
                </Card>
            </div>

            <Alert className="bg-green-50 border-green-200">
                <CheckCircle className="h-4 w-4 text-green-600" />
                <AlertTitle className="text-green-800">Backend Infrastructure: Ready for Deployment</AlertTitle>
                <AlertDescription className="text-green-700">
                    Your core technical infrastructure is solid and can support both programs once the missing features are built.
                </AlertDescription>
            </Alert>

            <Tabs defaultValue="backend-ready" className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="backend-ready">Backend Infrastructure</TabsTrigger>
                    <TabsTrigger value="critical-gaps">Critical Gaps</TabsTrigger>
                    <TabsTrigger value="deployment-timeline">Deployment Timeline</TabsTrigger>
                </TabsList>

                <TabsContent value="backend-ready" className="mt-6">
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <Database className="w-5 h-5 text-green-600" />
                                Backend Infrastructure Status: 100% Ready
                            </CardTitle>
                            <CardDescription>
                                Your technical foundation is solid and deployment-ready
                            </CardDescription>
                        </CardHeader>
                        <CardContent>
                            <div className="grid md:grid-cols-2 gap-4">
                                {backendInfrastructure.map((item, index) => (
                                    <div key={index} className="flex items-center gap-3 p-3 bg-green-50 rounded-lg border border-green-200">
                                        <CheckCircle className="w-5 h-5 text-green-600" />
                                        <div className="flex-grow">
                                            <span className="font-medium text-green-800">{item.component}</span>
                                            <Badge className="ml-2 bg-green-100 text-green-800 text-xs">
                                                {item.deployment}
                                            </Badge>
                                        </div>
                                    </div>
                                ))}
                            </div>
                            <Alert className="mt-4 bg-blue-50 border-blue-200">
                                <Zap className="h-4 w-4 text-blue-600" />
                                <AlertDescription className="text-blue-700">
                                    <strong>Key Strength:</strong> You have a professional, scalable backend that can handle paying clients today. The missing pieces are business logic and user experience, not infrastructure.
                                </AlertDescription>
                            </Alert>
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="critical-gaps" className="mt-6">
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <XCircle className="w-5 h-5 text-red-600" />
                                Critical Gaps for Real-World Deployment
                            </CardTitle>
                            <CardDescription>
                                What must be built before you can deliver these services
                            </CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                                <h4 className="font-semibold text-red-800 mb-2">❌ Cannot Launch Either Program Today</h4>
                                <ul className="text-sm text-red-700 space-y-1">
                                    <li>• No AI document generation system (core value proposition)</li>
                                    <li>• No SSP or POA&M template generation</li>
                                    <li>• No structured 90-day program workflow</li>
                                    <li>• No payment processing for $5K-7.5K charges</li>
                                    <li>• No evidence review or coaching infrastructure</li>
                                </ul>
                            </div>
                            
                            <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                                <h4 className="font-semibold text-yellow-800 mb-2">⚠️ Partial Capabilities Available</h4>
                                <ul className="text-sm text-yellow-700 space-y-1">
                                    <li>• Basic CMMC assessment and gap analysis</li>
                                    <li>• PDF report generation</li>
                                    <li>• Email communication</li>
                                    <li>• Client portal and user management</li>
                                </ul>
                            </div>

                            <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                                <h4 className="font-semibold text-blue-800 mb-2">💡 What You Could Launch Today</h4>
                                <ul className="text-sm text-blue-700 space-y-1">
                                    <li>• $500-1000 basic CMMC gap assessment service</li>
                                    <li>• Free trial assessments for lead generation</li>
                                    <li>• Consultation calls and expert guidance</li>
                                </ul>
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="deployment-timeline" className="mt-6">
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <Clock className="w-5 h-5 text-blue-600" />
                                Realistic Deployment Timeline
                            </CardTitle>
                            <CardDescription>
                                How long to build the missing pieces for each program
                            </CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-6">
                            <div className="grid md:grid-cols-2 gap-6">
                                <div className="p-4 border rounded-lg">
                                    <h4 className="font-semibold text-lg mb-3 flex items-center gap-2">
                                        <DollarSign className="w-5 h-5 text-yellow-600" />
                                        $5K Kickstarter: 8-12 Weeks
                                    </h4>
                                    <div className="space-y-2 text-sm">
                                        <div className="flex justify-between">
                                            <span>AI document generation</span>
                                            <Badge className="bg-red-100 text-red-800">6 weeks</Badge>
                                        </div>
                                        <div className="flex justify-between">
                                            <span>SSP template system</span>
                                            <Badge className="bg-red-100 text-red-800">4 weeks</Badge>
                                        </div>
                                        <div className="flex justify-between">
                                            <span>POA&M generation</span>
                                            <Badge className="bg-red-100 text-red-800">3 weeks</Badge>
                                        </div>
                                        <div className="flex justify-between">
                                            <span>Payment processing</span>
                                            <Badge className="bg-yellow-100 text-yellow-800">2 weeks</Badge>
                                        </div>
                                    </div>
                                </div>
                                
                                <div className="p-4 border rounded-lg">
                                    <h4 className="font-semibold text-lg mb-3 flex items-center gap-2">
                                        <Users className="w-5 h-5 text-red-600" />
                                        $7.5K Full Program: 16-20 Weeks
                                    </h4>
                                    <div className="space-y-2 text-sm">
                                        <div className="flex justify-between">
                                            <span>Everything in Kickstarter</span>
                                            <Badge className="bg-red-100 text-red-800">12 weeks</Badge>
                                        </div>
                                        <div className="flex justify-between">
                                            <span>90-day program workflow</span>
                                            <Badge className="bg-red-100 text-red-800">8 weeks</Badge>
                                        </div>
                                        <div className="flex justify-between">
                                            <span>Evidence review system</span>
                                            <Badge className="bg-red-100 text-red-800">5 weeks</Badge>
                                        </div>
                                        <div className="flex justify-between">
                                            <span>Coaching infrastructure</span>
                                            <Badge className="bg-yellow-100 text-yellow-800">3 weeks</Badge>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <Alert className="bg-orange-50 border-orange-200">
                                <AlertTriangle className="h-4 w-4 text-orange-600" />
                                <AlertTitle className="text-orange-800">Recommendation: Phase Your Launch</AlertTitle>
                                <AlertDescription className="text-orange-700">
                                    Start with a $500-1000 basic assessment service using your current capabilities. Build revenue and validate demand while developing the full programs.
                                </AlertDescription>
                            </Alert>
                        </CardContent>
                    </Card>
                </TabsContent>
            </Tabs>
        </div>
    );
}