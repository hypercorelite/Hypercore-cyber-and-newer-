
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { DollarSign, Cloud, AlertTriangle, CheckCircle } from 'lucide-react';
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";

const realAWSCosts = {
    development: {
        "Infrastructure as Code (CDK)": 0, // Free, just time
        "Lambda Functions Migration": 0, // Converting Base44 functions to Lambda
        "Frontend S3/CloudFront Deploy": 0, // Standard deployment
        "Database Schema Export/Import": 0, // Data migration scripts
        "Environment Variables/Secrets": 0, // AWS Systems Manager Parameter Store
        total: 0,
        note: "All development work - no service costs"
    },
    awsServices: {
        "Lambda": 0, // Free tier: 1M requests, 400k GB-seconds
        "S3 Static Hosting": 1, // $0.50-1 for storage + requests
        "CloudFront CDN": 2, // First 1TB free, then minimal
        "API Gateway": 3, // $3.50 per million requests after 1M free
        "RDS Postgres (t3.micro)": 0, // Free tier: 750 hours/month Year 1
        "Route 53 DNS": 0.50, // $0.50 per hosted zone
        "Systems Manager (Secrets)": 0, // Free tier covers small usage
        "CloudWatch Logging": 1, // Minimal for basic monitoring
        total: 7.50,
        note: "Monthly recurring costs (Year 1 with free tier)"
    },
    oneTimeCosts: {
        "Domain SSL Certificate": 0, // Free with CloudFront
        "Initial Data Transfer": 5, // One-time Base44 -> AWS data migration
        "Testing/Validation": 10, // Load testing, security scans
        total: 15,
        note: "One-time setup costs"
    }
};

const migrationRealities = [
    {
        task: "Export Base44 Frontend Code",
        effort: "2 hours",
        cost: "$0",
        reality: "Base44 gives you React source code - just download and clean up"
    },
    {
        task: "Convert Backend Functions to Lambda", 
        effort: "8 hours",
        cost: "$0", 
        reality: "Mostly find/replace Base44 SDK calls with AWS SDK calls"
    },
    {
        task: "Set up AWS Infrastructure",
        effort: "4 hours",
        cost: "$15",
        reality: "Use CDK templates - mostly copy/paste infrastructure as code"
    },
    {
        task: "Deploy and Test",
        effort: "6 hours", 
        cost: "$7.50/month",
        reality: "Standard CI/CD pipeline deployment, basic monitoring"
    }
];

const scalingBreakpoints = [
    {
        users: "1-100 users",
        monthlyAWS: "$0-10",
        bottleneck: "None - free tier covers everything",
        action: "Just monitor usage"
    },
    {
        users: "100-1,000 users", 
        monthlyAWS: "$25-75",
        bottleneck: "RDS instance size, Lambda concurrency",
        action: "Upgrade RDS to t3.small ($25/month), monitor Lambda limits"
    },
    {
        users: "1,000-10,000 users",
        monthlyAWS: "$150-400", 
        bottleneck: "Database connections, API Gateway throttling",
        action: "RDS scaling, CloudFront optimization, maybe Aurora Serverless"
    },
    {
        users: "10,000+ users",
        monthlyAWS: "$500+",
        bottleneck: "Everything - need architecture review", 
        action: "Multi-AZ, auto-scaling, performance optimization"
    }
];

export default function RealisticAWSMigrationCosts() {
    return (
        <div className="space-y-8">
            <BreadcrumbNav currentPageName="RealisticAWSMigrationCosts" />
            
            <div className="text-center">
                <Badge className="mb-4 bg-green-100 text-green-800">COST REALITY CHECK</Badge>
                <h1 className="text-4xl font-bold text-gray-900 mb-4">Realistic AWS Migration Costs</h1>
                <p className="text-xl text-gray-600 max-w-4xl mx-auto">
                    Actual costs for serverless AWS deployment without the consultant markup - what you'll really pay.
                </p>
            </div>

            <Alert className="bg-green-50 border-green-200">
                <CheckCircle className="h-5 w-5 text-green-600" />
                <AlertTitle className="text-green-800 font-bold">Reality: AWS Migration is Much Cheaper Than Expected</AlertTitle>
                <AlertDescription className="text-green-700 mt-2">
                    Total real cost: ~$22.50 ($15 one-time + $7.50/month). The main investment is your time (~20 hours), not money. AWS free tier covers almost everything for the first year.
                </AlertDescription>
            </Alert>

            {/* Real Cost Breakdown */}
            <div className="grid md:grid-cols-3 gap-6">
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <DollarSign className="w-5 h-5 text-green-600" />
                            Development (Your Time)
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="text-3xl font-bold text-green-600 mb-2">${realAWSCosts.development.total}</div>
                        <p className="text-sm text-gray-600 mb-4">{realAWSCosts.development.note}</p>
                        <div className="space-y-2 text-sm">
                            <div className="flex justify-between">
                                <span>Code Export/Cleanup</span>
                                <span>$0</span>
                            </div>
                            <div className="flex justify-between">
                                <span>Function Migration</span>
                                <span>$0</span>
                            </div>
                            <div className="flex justify-between">
                                <span>Infrastructure Setup</span>
                                <span>$0</span>
                            </div>
                        </div>
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <Cloud className="w-5 h-5 text-blue-600" />
                            AWS Services (Monthly)
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="text-3xl font-bold text-blue-600 mb-2">${realAWSCosts.awsServices.total}</div>
                        <p className="text-sm text-gray-600 mb-4">{realAWSCosts.awsServices.note}</p>
                        <div className="space-y-2 text-sm">
                            <div className="flex justify-between">
                                <span>Lambda + API Gateway</span>
                                <span>$3</span>
                            </div>
                            <div className="flex justify-between">
                                <span>S3 + CloudFront</span>
                                <span>$3</span>
                            </div>
                            <div className="flex justify-between">
                                <span>RDS (Free Tier)</span>
                                <span>$0</span>
                            </div>
                            <div className="flex justify-between">
                                <span>Misc (DNS, logs)</span>
                                <span>$1.50</span>
                            </div>
                        </div>
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <AlertTriangle className="w-5 h-5 text-orange-600" />
                            One-Time Setup
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="text-3xl font-bold text-orange-600 mb-2">${realAWSCosts.oneTimeCosts.total}</div>
                        <p className="text-sm text-gray-600 mb-4">{realAWSCosts.oneTimeCosts.note}</p>
                        <div className="space-y-2 text-sm">
                            <div className="flex justify-between">
                                <span>Data Migration</span>
                                <span>$5</span>
                            </div>
                            <div className="flex justify-between">
                                <span>Testing/Validation</span>
                                <span>$10</span>
                            </div>
                            <div className="flex justify-between">
                                <span>SSL Certificates</span>
                                <span>$0</span>
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </div>

            {/* Migration Reality Check */}
            <Card>
                <CardHeader>
                    <CardTitle>Migration Task Reality Check</CardTitle>
                    <CardDescription>What each migration step actually involves</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="space-y-4">
                        {migrationRealities.map((task, index) => (
                            <div key={index} className="p-4 bg-gray-50 rounded-lg">
                                <div className="flex justify-between items-start mb-2">
                                    <h4 className="font-semibold">{task.task}</h4>
                                    <div className="text-right text-sm">
                                        <div className="font-bold text-blue-600">{task.effort}</div>
                                        <div className="text-gray-500">{task.cost}</div>
                                    </div>
                                </div>
                                <p className="text-sm text-gray-600">{task.reality}</p>
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>

            {/* Scaling Expectations */}
            <Card>
                <CardHeader>
                    <CardTitle>When Do Costs Actually Scale?</CardTitle>
                    <CardDescription>Real breakpoints where AWS costs increase</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="space-y-4">
                        {scalingBreakpoints.map((tier, index) => (
                            <div key={index} className="p-4 border rounded-lg">
                                <div className="flex justify-between items-start mb-2">
                                    <div>
                                        <h4 className="font-semibold">{tier.users}</h4>
                                        <p className="text-sm text-gray-600">Bottleneck: {tier.bottleneck}</p>
                                    </div>
                                    <Badge className="bg-blue-100 text-blue-800">{tier.monthlyAWS}</Badge>
                                </div>
                                <p className="text-sm text-green-600">Action needed: {tier.action}</p>
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-green-900 to-blue-900 text-white">
                <CardHeader>
                    <CardTitle className="text-2xl">Bottom Line: AWS Migration Economics</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <p className="text-lg"><strong>Real Total Cost:</strong> $22.50 ($15 one-time + $7.50/month for Year 1)</p>
                    <p className="text-lg"><strong>Your Investment:</strong> ~20 hours of work over 2-3 weeks</p>
                    <p className="text-lg"><strong>Free Tier Coverage:</strong> Handles 100+ users with no additional charges</p>
                    <p className="text-lg"><strong>Scaling Point:</strong> Only pay more after 1,000+ active users</p>
                    
                    <Alert className="bg-green-600 border-green-500 mt-6">
                        <CheckCircle className="h-5 w-5 text-white" />
                        <AlertTitle className="text-white font-bold">Migration is Financially Risk-Free</AlertTitle>
                        <AlertDescription className="text-green-100 mt-1">
                            At $22.50 total cost, AWS migration pays for itself with just ONE enterprise client inquiry ($12,500 deal size). The SBIR credibility boost alone justifies the minimal investment.
                        </AlertDescription>
                    </Alert>
                </CardContent>
            </Card>
        </div>
    );
}
