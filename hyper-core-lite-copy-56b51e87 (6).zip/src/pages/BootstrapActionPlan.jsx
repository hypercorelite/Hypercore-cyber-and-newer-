
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Zap, Target, Rocket, ArrowRight, BookOpen, Bot, AlertTriangle, CheckCircle, X, Users } from 'lucide-react';
import { motion } from "framer-motion";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";

const productLedPrinciples = [
    {
        principle: "AI Does the Work, Not You",
        description: "The MVP must deliver value autonomously. Clients get results from the software, not from your time.",
        example: "Gap analysis, SSP generation, and compliance scoring happen automatically when they upload their data."
    },
    {
        principle: "Scale Without Human Bottlenecks", 
        description: "Every feature must work for 1 client or 1,000 clients with the same effort from you.",
        example: "One AI model serves all clients. No custom configurations, no client-specific consulting calls."
    },
    {
        principle: "Self-Service by Design",
        description: "Clients must be able to get value without talking to you. The product teaches them what they need to know.",
        example: "Interactive tutorials, built-in explanations, and automated recommendations guide them through implementation."
    },
    {
        principle: "Revenue Without Labor",
        description: "Pricing model should generate income while you sleep, not when you're working.",
        example: "$200/month SaaS subscription vs. $200/hour consulting calls."
    }
];

export default function BootstrapActionPlan() {
    return (
        <div className="space-y-8">
            <BreadcrumbNav currentPageName="BootstrapActionPlan" />

            <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="text-center">
                <Badge className="mb-4 bg-green-100 text-green-800">PRODUCT-LED STRATEGY</Badge>
                <h1 className="text-4xl font-bold text-gray-900 mb-4">Bootstrap Action Plan: AI-First, Not Service-First</h1>
                <p className="text-xl text-gray-600 max-w-4xl mx-auto">
                    Build a product that scales without you being personally involved in every client delivery.
                </p>
            </motion.div>

            <Alert className="bg-red-50 border-red-200">
                <AlertTriangle className="h-4 w-4 text-red-600" />
                <AlertTitle className="text-red-800">Avoid the Consultant Trap</AlertTitle>
                <AlertDescription className="text-red-700">
                    <strong>Wrong Approach:</strong> Build basic tool → Fill gaps with manual consulting → Get overwhelmed with service delivery → Never improve the product.<br/>
                    <strong>Right Approach:</strong> Build AI that replaces consulting from Day 1 → Clients get value from software, not your time → Scale without human bottlenecks.
                </AlertDescription>
            </Alert>

            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                        <Bot className="w-8 h-8 text-blue-600" />
                        Product-Led Growth Principles
                    </CardTitle>
                    <CardDescription>
                        These principles guide every MVP feature decision to ensure scalability without manual intervention.
                    </CardDescription>
                </CardHeader>
                <CardContent className="grid md:grid-cols-2 gap-6">
                    {productLedPrinciples.map((item, index) => (
                        <motion.div key={item.principle} initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: index * 0.1 }}>
                            <div className="p-6 bg-gray-50 rounded-lg border h-full">
                                <h3 className="text-lg font-semibold text-gray-800 mb-2">{item.principle}</h3>
                                <p className="text-sm text-gray-600 mb-3">{item.description}</p>
                                <div className="text-xs text-blue-700 bg-blue-50 p-2 rounded">
                                    <strong>Example:</strong> {item.example}
                                </div>
                            </div>
                        </motion.div>
                    ))}
                </CardContent>
            </Card>

            {/* NEW: Human-in-the-Loop Clarification */}
            <Card className="bg-gradient-to-r from-blue-50 to-purple-50">
                <CardHeader>
                    <CardTitle className="flex items-center gap-3"><Users className="w-8 h-8 text-purple-600" />The "Human-in-the-Loop" Strategy</CardTitle>
                    <CardDescription>
                        AI-First doesn't mean "human-free." It means leveraging humans for what they do best: strategy, review, and complex problem-solving.
                    </CardDescription>
                </CardHeader>
                <CardContent className="grid md:grid-cols-2 gap-6">
                    <div className="p-4 bg-white rounded-lg border">
                        <h4 className="font-semibold text-gray-800 mb-2">✅ Where the Human Excels (High-Value Tasks)</h4>
                        <ul className="space-y-2 text-sm text-gray-600 list-disc list-inside">
                            <li><strong>Strategic Review:</strong> Approving AI-generated remediation plans.</li>
                            <li><strong>Contextual Validation:</strong> Confirming AI's understanding of the client's unique environment.</li>
                            <li><strong>Complex Escalations:</strong> Solving novel technical issues the AI hasn't seen before.</li>
                            <li><strong>Client Relationship:</strong> Building trust and managing expectations.</li>
                        </ul>
                    </div>
                     <div className="p-4 bg-white rounded-lg border">
                        <h4 className="font-semibold text-gray-800 mb-2">🤖 Where the AI Excels (Scalable Tasks)</h4>
                        <ul className="space-y-2 text-sm text-gray-600 list-disc list-inside">
                            <li><strong>Gap Analysis:</strong> Analyzing thousands of pages of documentation in seconds.</li>
                            <li><strong>Document Generation:</strong> Creating SSPs and policies 95% faster than a human.</li>
                            <li><strong>Repetitive Tasks:</strong> Tracking compliance status across 110 controls continuously.</li>
                            <li><strong>Initial Support:</strong> Answering common questions and providing standard guidance 24/7.</li>
                        </ul>
                    </div>
                </CardContent>
            </Card>

            <div className="grid md:grid-cols-2 gap-8">
                <Card className="bg-green-50 border-green-200">
                    <CardHeader>
                        <CardTitle className="text-green-800">✅ MVP Must-Haves (AI-Powered)</CardTitle>
                        <CardDescription className="text-green-700">Features that deliver value without human intervention</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <ul className="space-y-3 text-sm">
                            <li className="flex items-start gap-2">
                                <CheckCircle className="w-4 h-4 text-green-600 mt-1 flex-shrink-0" />
                                <span><strong>Automated Gap Analysis:</strong> Upload configs → Get scored compliance report</span>
                            </li>
                            <li className="flex items-start gap-2">
                                <CheckCircle className="w-4 h-4 text-green-600 mt-1 flex-shrink-0" />
                                <span><strong>AI-Generated SSP:</strong> Input org details → Get customized System Security Plan</span>
                            </li>
                            <li className="flex items-start gap-2">
                                <CheckCircle className="w-4 h-4 text-green-600 mt-1 flex-shrink-0" />
                                <span><strong>Self-Service Dashboard:</strong> Progress tracking, next steps, compliance score</span>
                            </li>
                            <li className="flex items-start gap-2">
                                <CheckCircle className="w-4 h-4 text-green-600 mt-1 flex-shrink-0" />
                                <span><strong>Automated Recommendations:</strong> AI suggests specific fixes for failed controls</span>
                            </li>
                            <li className="flex items-start gap-2">
                                <CheckCircle className="w-4 h-4 text-green-600 mt-1 flex-shrink-0" />
                                <span><strong>Evidence Package Export:</strong> One-click C3PAO-ready documentation</span>
                            </li>
                        </ul>
                    </CardContent>
                </Card>

                <Card className="bg-red-50 border-red-200">
                    <CardHeader>
                        <CardTitle className="text-red-800">❌ Avoid These Service Traps</CardTitle>
                        <CardDescription className="text-red-700">Activities that don't scale and create bottlenecks</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <ul className="space-y-3 text-sm">
                            <li className="flex items-start gap-2">
                                <X className="w-4 h-4 text-red-600 mt-1 flex-shrink-0" />
                                <span><strong>Custom Consulting Calls:</strong> Every client wants "just one quick call"</span>
                            </li>
                            <li className="flex items-start gap-2">
                                <X className="w-4 h-4 text-red-600 mt-1 flex-shrink-0" />
                                <span><strong>Manual Document Review:</strong> "Can you check if this looks right?"</span>
                            </li>
                            <li className="flex items-start gap-2">
                                <X className="w-4 h-4 text-red-600 mt-1 flex-shrink-0" />
                                <span><strong>Client-Specific Features:</strong> "Can you add this one thing for our industry?"</span>
                            </li>
                            <li className="flex items-start gap-2">
                                <X className="w-4 h-4 text-red-600 mt-1 flex-shrink-0" />
                                <span><strong>Implementation Support:</strong> "Help us set this up in our environment"</span>
                            </li>
                            <li className="flex items-start gap-2">
                                <X className="w-4 h-4 text-red-600 mt-1 flex-shrink-0" />
                                <span><strong>Training Sessions:</strong> "Can you train our team on CMMC?"</span>
                            </li>
                        </ul>
                    </CardContent>
                </Card>
            </div>

            <Card className="bg-gradient-to-r from-blue-600 to-indigo-700 text-white">
                <CardContent className="p-8">
                    <div className="text-center space-y-4">
                        <h2 className="text-3xl font-bold">The Real Bootstrap Strategy</h2>
                        <p className="text-xl text-blue-100">
                            Build AI so good that clients prefer it to human consultants
                        </p>
                        <div className="grid md:grid-cols-3 gap-6 text-center mt-8">
                            <div className="bg-white/20 p-4 rounded-lg">
                                <div className="text-2xl font-bold">$0</div>
                                <div className="text-sm opacity-90">Variable costs per client</div>
                            </div>
                            <div className="bg-white/20 p-4 rounded-lg">
                                <div className="text-2xl font-bold">24/7</div>
                                <div className="text-sm opacity-90">AI availability</div>
                            </div>
                            <div className="bg-white/20 p-4 rounded-lg">
                                <div className="text-2xl font-bold">∞</div>
                                <div className="text-sm opacity-90">Concurrent clients</div>
                            </div>
                        </div>
                    </div>
                </CardContent>
            </Card>

            <div className="text-center">
                <Button asChild size="lg" className="bg-green-600 hover:bg-green-700">
                    <Link to={createPageUrl('DailyAchievementSchedule')}>
                        Start Building the AI-First MVP <ArrowRight className="w-5 h-5 ml-2" />
                    </Link>
                </Button>
            </div>
        </div>
    );
}
