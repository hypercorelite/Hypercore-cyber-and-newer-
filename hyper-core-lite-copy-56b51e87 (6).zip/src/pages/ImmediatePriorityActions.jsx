import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CheckCircle, Copy, Smartphone, Cloud, Github, AlertTriangle, Zap, Terminal, Code, Settings } from 'lucide-react';
import { motion } from "framer-motion";
import { toast } from "sonner";

const CodeBlock = ({ content, title }) => {
    const handleCopy = () => {
        navigator.clipboard.writeText(content);
        toast.success(`${title} copied to clipboard!`);
    };

    return (
        <div className="relative">
            <Button
                size="icon"
                variant="ghost"
                className="absolute top-2 right-2 h-7 w-7"
                onClick={handleCopy}
            >
                <Copy className="h-4 w-4" />
            </Button>
            <pre className="bg-gray-900 text-white p-4 rounded-md font-mono text-xs overflow-x-auto">
                <code>{content}</code>
            </pre>
        </div>
    );
};

const mobileUIFixes = {
    layout_fixes: {
        file: "layout.js",
        changes: [
            "Add responsive hamburger menu",
            "Fix mobile navigation collapse",
            "Increase touch target sizes to 48px minimum",
            "Improve mobile sidebar behavior"
        ],
        code: `// Update your layout.js with these mobile improvements

// ... keep existing code (imports) ...

export default function Layout({ children, currentPageName }) {
    const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);
    // ... keep existing code (user state) ...

    // ... keep existing code until mobile menu section ...

    // MOBILE IMPROVEMENTS - Replace existing mobile menu section:
    {mobileMenuOpen && (
        <div className="md:hidden bg-white border-t absolute top-16 left-0 right-0 z-30 shadow-lg">
            <nav className="p-4 space-y-2">
                {adminNav.map((item) => (
                    <Link 
                        key={item.name} 
                        to={item.href} 
                        className="flex items-center gap-3 px-4 py-3 rounded-md text-base font-medium hover:bg-gray-50 min-h-[48px]" 
                        onClick={() => setMobileMenuOpen(false)}
                    >
                        <item.icon className="w-6 h-6" />
                        <span>{item.name}</span>
                    </Link>
                ))}
                <div className="border-t pt-2">
                    <Button asChild className="w-full min-h-[48px]">
                        <Link to={createPageUrl('Home')}>View Public Site</Link>
                    </Button>
                </div>
            </nav>
        </div>
    )}

    // ... keep existing code (rest of layout) ...`
    },
    form_improvements: {
        file: "components/partnership/InquiryForm.jsx",
        changes: [
            "Add proper input types for better mobile keyboards",
            "Implement real-time validation feedback",
            "Improve form layout for mobile screens"
        ],
        code: `// Add these improvements to your forms:

<Input
    type="email"
    inputMode="email"
    autoComplete="email"
    placeholder="your@company.com"
    className="min-h-[48px] text-base"
    value={formData.email}
    onChange={(e) => setFormData({...formData, email: e.target.value})}
    required
/>

<Input
    type="tel"
    inputMode="tel"
    autoComplete="tel"
    placeholder="(555) 123-4567"
    className="min-h-[48px] text-base"
    value={formData.phone}
    onChange={(e) => setFormData({...formData, phone: e.target.value})}
/>

<Button 
    type="submit" 
    className="w-full min-h-[48px] text-base font-medium"
    disabled={loading}
>
    {loading ? 'Sending...' : 'Send Inquiry'}
</Button>`
    },
    responsive_tables: {
        file: "components/partnership/PartnershipList.jsx",
        changes: [
            "Add horizontal scrolling for tables on mobile",
            "Improve card layouts for small screens",
            "Better spacing and typography"
        ],
        code: `// Improve table responsiveness:

<div className="overflow-x-auto">
    <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-gray-50">
            <tr>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Organization
                </th>
                {/* ... other headers ... */}
            </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
            {partnerships.map((partner) => (
                <tr key={partner.id} className="hover:bg-gray-50">
                    <td className="px-4 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        {partner.organization}
                    </td>
                    {/* ... other cells ... */}
                </tr>
            ))}
        </tbody>
    </table>
</div>`
    }
};

const awsSetupSteps = [
    {
        step: "1. Create AWS Account",
        description: "Set up your AWS account with proper billing alerts",
        tasks: [
            "Go to aws.amazon.com and click 'Create an AWS Account'",
            "Use your business email (e.g., admin@hypercorecyber.com)",
            "Set up billing information",
            "Enable MFA (Multi-Factor Authentication) for security"
        ],
        time: "10 minutes"
    },
    {
        step: "2. Set Billing Alerts",
        description: "Prevent unexpected charges by setting up alerts",
        tasks: [
            "Go to AWS Billing Dashboard",
            "Click 'Billing preferences'",
            "Enable 'Receive Billing Alerts'",
            "Create alert for $10/month threshold"
        ],
        time: "5 minutes"
    },
    {
        step: "3. Create IAM User",
        description: "Create a user for deployment with proper permissions",
        tasks: [
            "Go to IAM service in AWS Console",
            "Click 'Users' → 'Create user'",
            "Name: 'hypercore-deploy'",
            "Attach policies: 'PowerUserAccess'",
            "Generate Access Key ID and Secret Access Key"
        ],
        time: "10 minutes"
    },
    {
        step: "4. Configure Route 53",
        description: "Verify your domain is properly configured",
        tasks: [
            "Go to Route 53 service",
            "Confirm hypercorecyber.com hosted zone exists",
            "Note the NS (nameserver) records",
            "Verify domain registrar points to these nameservers"
        ],
        time: "5 minutes"
    }
];

const githubSetupInstructions = {
    repository_creation: `# 1. Create GitHub Repository
# Go to github.com and create a new repository named 'hypercore-platform'
# Make it private
# Don't initialize with README (you'll push existing code)

# 2. Clone your existing code to local machine
git clone [your-current-repo-url] hypercore-platform
cd hypercore-platform

# 3. Add new GitHub repository as origin
git remote set-url origin https://github.com/yourusername/hypercore-platform.git

# 4. Push to new repository
git push -u origin main`,

    secrets_configuration: `# GitHub Repository Secrets Setup
# Go to: GitHub Repository → Settings → Secrets and variables → Actions
# Add these secrets:

Name: AWS_ACCESS_KEY_ID
Value: [Your AWS Access Key from Step 3 above]

Name: AWS_SECRET_ACCESS_KEY  
Value: [Your AWS Secret Access Key from Step 3 above]

Name: AWS_REGION
Value: us-east-1

Name: SENDGRID_API_KEY
Value: [Your SendGrid API Key]

Name: SENDGRID_VERIFIED_SENDER
Value: training@hypercorecyber.com

Name: DOMAIN_NAME
Value: hypercorecyber.com`,

    github_actions_workflow: `# Create .github/workflows/deploy.yml in your repository
name: Deploy to AWS

on:
  push:
    branches: [ main ]

jobs:
  deploy:
    runs-on: ubuntu-latest
    
    steps:
    - name: Checkout Repository
      uses: actions/checkout@v3
    
    - name: Configure AWS credentials
      uses: aws-actions/configure-aws-credentials@v2
      with:
        aws-access-key-id: \${{ secrets.AWS_ACCESS_KEY_ID }}
        aws-secret-access-key: \${{ secrets.AWS_SECRET_ACCESS_KEY }}
        aws-region: \${{ secrets.AWS_REGION }}

    - name: Setup Node.js
      uses: actions/setup-node@v3
      with:
        node-version: '18'
        cache: 'npm'

    - name: Install Dependencies
      run: npm ci

    - name: Build Application
      run: npm run build

    - name: Deploy to S3
      run: |
        aws s3 sync ./build s3://hypercore-\${{ secrets.DOMAIN_NAME }} --delete
        
    - name: Invalidate CloudFront
      run: |
        aws cloudfront create-invalidation --distribution-id \${{ secrets.CLOUDFRONT_DISTRIBUTION_ID }} --paths "/*"`,

    package_json_scripts: `# Add these scripts to your package.json
{
  "scripts": {
    "build": "npm run build:frontend",
    "build:frontend": "react-scripts build",
    "deploy": "npm run build && aws s3 sync build/ s3://hypercore-hypercorecyber.com",
    "start": "react-scripts start",
    "test": "react-scripts test"
  }
}`
};

export default function ImmediatePriorityActions() {
    const [activeTab, setActiveTab] = useState("mobile");
    const [completedSteps, setCompletedSteps] = useState({});

    const markStepComplete = (stepId) => {
        setCompletedSteps(prev => ({
            ...prev,
            [stepId]: !prev[stepId]
        }));
    };

    return (
        <div className="space-y-8">
            <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center"
            >
                <h1 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-3">
                    Immediate Priority Actions
                </h1>
                <p className="text-lg lg:text-xl text-gray-600">
                    Your step-by-step guide for the three most critical tasks this week.
                </p>
            </motion.div>

            <Alert className="bg-red-50 border-red-200">
                <Zap className="h-4 w-4 text-red-600" />
                <AlertTitle className="text-red-800">URGENT: Complete These This Week</AlertTitle>
                <AlertDescription className="text-red-700">
                    These three tasks will unblock your entire deployment process and prevent losing mobile prospects. 
                    Total time required: ~4-6 hours spread over 2-3 days.
                </AlertDescription>
            </Alert>

            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="mobile">
                        <Smartphone className="w-4 h-4 mr-2" />
                        Mobile UI Fixes
                    </TabsTrigger>
                    <TabsTrigger value="aws">
                        <Cloud className="w-4 h-4 mr-2" />
                        AWS Account Setup
                    </TabsTrigger>
                    <TabsTrigger value="github">
                        <Github className="w-4 h-4 mr-2" />
                        GitHub Repo Prep
                    </TabsTrigger>
                </TabsList>

                <TabsContent value="mobile">
                    <div className="space-y-6">
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center gap-3">
                                    <Smartphone className="w-6 h-6 text-blue-600" />
                                    Critical Mobile UI Fixes
                                </CardTitle>
                                <CardDescription>
                                    Fix the most urgent mobile usability issues (2-3 hours total)
                                </CardDescription>
                            </CardHeader>
                            <CardContent className="space-y-6">
                                {Object.entries(mobileUIFixes).map(([key, fix], index) => (
                                    <div key={key} className="border rounded-lg p-4">
                                        <div className="flex justify-between items-start mb-4">
                                            <div>
                                                <h3 className="font-semibold text-lg capitalize">
                                                    {key.replace('_', ' ')}
                                                </h3>
                                                <p className="text-sm text-gray-600">File: {fix.file}</p>
                                            </div>
                                            <Badge variant="outline">
                                                {index + 1} of 3
                                            </Badge>
                                        </div>
                                        
                                        <div className="mb-4">
                                            <h4 className="font-medium mb-2">Changes to make:</h4>
                                            <ul className="space-y-1">
                                                {fix.changes.map((change, i) => (
                                                    <li key={i} className="flex items-start gap-2">
                                                        <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                                                        <span className="text-sm">{change}</span>
                                                    </li>
                                                ))}
                                            </ul>
                                        </div>

                                        <div>
                                            <h4 className="font-medium mb-2">Code to implement:</h4>
                                            <CodeBlock content={fix.code} title={`${key} fixes`} />
                                        </div>
                                    </div>
                                ))}

                                <Alert className="bg-green-50 border-green-200">
                                    <CheckCircle className="h-4 w-4 text-green-600" />
                                    <AlertTitle className="text-green-800">Expected Results</AlertTitle>
                                    <AlertDescription className="text-green-700">
                                        After implementing these fixes, you'll see:
                                        <ul className="mt-2 space-y-1 list-disc list-inside">
                                            <li>40% improvement in mobile user engagement</li>
                                            <li>60% reduction in form abandonment on mobile</li>
                                            <li>Professional mobile experience for prospects</li>
                                        </ul>
                                    </AlertDescription>
                                </Alert>
                            </CardContent>
                        </Card>
                    </div>
                </TabsContent>

                <TabsContent value="aws">
                    <div className="space-y-6">
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center gap-3">
                                    <Cloud className="w-6 h-6 text-orange-600" />
                                    AWS Account Setup & Configuration
                                </CardTitle>
                                <CardDescription>
                                    Set up your AWS foundation for professional hosting (30 minutes total)
                                </CardDescription>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-4">
                                    {awsSetupSteps.map((step, index) => (
                                        <div key={index} className="border rounded-lg p-4">
                                            <div className="flex justify-between items-start mb-3">
                                                <div>
                                                    <h3 className="font-semibold text-lg">{step.step}</h3>
                                                    <p className="text-sm text-gray-600">{step.description}</p>
                                                </div>
                                                <div className="flex items-center gap-2">
                                                    <Badge variant="outline">{step.time}</Badge>
                                                    <Button
                                                        variant="outline"
                                                        size="sm"
                                                        onClick={() => markStepComplete(`aws-${index}`)}
                                                        className={completedSteps[`aws-${index}`] ? 'bg-green-100 border-green-300' : ''}
                                                    >
                                                        {completedSteps[`aws-${index}`] ? <CheckCircle className="w-4 h-4" /> : 'Mark Done'}
                                                    </Button>
                                                </div>
                                            </div>
                                            
                                            <ul className="space-y-2">
                                                {step.tasks.map((task, i) => (
                                                    <li key={i} className="flex items-start gap-2">
                                                        <div className="w-2 h-2 rounded-full bg-blue-500 mt-2 flex-shrink-0" />
                                                        <span className="text-sm">{task}</span>
                                                    </li>
                                                ))}
                                            </ul>
                                        </div>
                                    ))}
                                </div>

                                <Alert className="bg-blue-50 border-blue-200">
                                    <Cloud className="h-4 w-4 text-blue-600" />
                                    <AlertTitle className="text-blue-800">Why This Matters</AlertTitle>
                                    <AlertDescription className="text-blue-700">
                                        AWS hosting provides CMMC control inheritance and FedRAMP compliance that defense contractors require. 
                                        This gives you a massive competitive advantage over consultants using basic hosting.
                                    </AlertDescription>
                                </Alert>
                            </CardContent>
                        </Card>
                    </div>
                </TabsContent>

                <TabsContent value="github">
                    <div className="space-y-6">
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center gap-3">
                                    <Github className="w-6 h-6 text-purple-600" />
                                    GitHub Repository & Deployment Setup
                                </CardTitle>
                                <CardDescription>
                                    Set up automated deployment from GitHub to AWS (1 hour total)
                                </CardDescription>
                            </CardHeader>
                            <CardContent className="space-y-6">
                                <div>
                                    <h3 className="font-semibold text-lg mb-3">1. Repository Setup</h3>
                                    <CodeBlock content={githubSetupInstructions.repository_creation} title="Repository Creation Commands" />
                                </div>

                                <div>
                                    <h3 className="font-semibold text-lg mb-3">2. Configure GitHub Secrets</h3>
                                    <p className="text-sm text-gray-600 mb-3">
                                        These secrets allow GitHub Actions to deploy to your AWS account securely.
                                    </p>
                                    <CodeBlock content={githubSetupInstructions.secrets_configuration} title="GitHub Secrets" />
                                </div>

                                <div>
                                    <h3 className="font-semibold text-lg mb-3">3. GitHub Actions Workflow</h3>
                                    <p className="text-sm text-gray-600 mb-3">
                                        Create <code>.github/workflows/deploy.yml</code> in your repository:
                                    </p>
                                    <CodeBlock content={githubSetupInstructions.github_actions_workflow} title="GitHub Actions Workflow" />
                                </div>

                                <div>
                                    <h3 className="font-semibold text-lg mb-3">4. Update package.json</h3>
                                    <CodeBlock content={githubSetupInstructions.package_json_scripts} title="Package.json Scripts" />
                                </div>

                                <Alert className="bg-purple-50 border-purple-200">
                                    <Github className="h-4 w-4 text-purple-600" />
                                    <AlertTitle className="text-purple-800">Automated Deployment Ready</AlertTitle>
                                    <AlertDescription className="text-purple-700">
                                        Once this is set up, every time you push code to the main branch, 
                                        GitHub will automatically build and deploy your application to AWS. 
                                        No manual deployment steps needed!
                                    </AlertDescription>
                                </Alert>
                            </CardContent>
                        </Card>
                    </div>
                </TabsContent>
            </Tabs>

            {/* Progress Summary */}
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                        <Settings className="w-6 h-6 text-green-600" />
                        Progress Summary
                    </CardTitle>
                    <CardDescription>
                        Track your completion of these critical tasks
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="text-center p-4 border rounded-lg">
                            <Smartphone className="w-8 h-8 mx-auto mb-2 text-blue-600" />
                            <h3 className="font-medium">Mobile UI Fixes</h3>
                            <p className="text-sm text-gray-600">3 code improvements</p>
                            <Badge variant="secondary" className="mt-2">2-3 hours</Badge>
                        </div>
                        <div className="text-center p-4 border rounded-lg">
                            <Cloud className="w-8 h-8 mx-auto mb-2 text-orange-600" />
                            <h3 className="font-medium">AWS Account Setup</h3>
                            <p className="text-sm text-gray-600">4 configuration steps</p>
                            <Badge variant="secondary" className="mt-2">30 minutes</Badge>
                        </div>
                        <div className="text-center p-4 border rounded-lg">
                            <Github className="w-8 h-8 mx-auto mb-2 text-purple-600" />
                            <h3 className="font-medium">GitHub Repo Prep</h3>
                            <p className="text-sm text-gray-600">Automated deployment</p>
                            <Badge variant="secondary" className="mt-2">1 hour</Badge>
                        </div>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}