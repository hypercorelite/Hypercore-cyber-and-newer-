import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { DataProcessingAgreement } from "@/api/entities";
import { AITrainingSession } from "@/api/entities";
import { ComplianceReport } from "@/api/entities";
import { 
    Shield, 
    FileText, 
    Bot, 
    Lock,
    TrendingUp,
    CheckCircle,
    AlertTriangle
} from "lucide-react";
import { motion } from "framer-motion";

export default function FederalPartnerPortal() {
    const [agreements, setAgreements] = useState([]);
    const [trainingSessions, setTrainingSessions] = useState([]);
    const [reports, setReports] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        loadData();
    }, []);

    const loadData = async () => {
        try {
            const [agreementData, trainingData, reportData] = await Promise.all([
                DataProcessingAgreement.list('-created_date', 10),
                AITrainingSession.list('-created_date', 10),
                ComplianceReport.list('-created_date', 10)
            ]);

            setAgreements(agreementData);
            setTrainingSessions(trainingData);
            setReports(reportData);
        } catch (error) {
            console.error('Failed to load partner portal data:', error);
        } finally {
            setLoading(false);
        }
    };

    const getStatusColor = (status) => {
        const colors = {
            draft: "bg-gray-100 text-gray-800",
            pending_signature: "bg-yellow-100 text-yellow-800",
            active: "bg-green-100 text-green-800",
            expired: "bg-red-100 text-red-800",
            collecting: "bg-blue-100 text-blue-800",
            training: "bg-purple-100 text-purple-800",
            complete: "bg-green-100 text-green-800"
        };
        return colors[status] || "bg-gray-100 text-gray-800";
    };

    return (
        <div className="min-h-screen bg-gradient-to-br from-gray-50 to-indigo-50 p-6">
            <div className="max-w-7xl mx-auto">
                <motion.div
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="mb-8"
                >
                    <h1 className="text-4xl font-bold text-gray-900 mb-2 flex items-center gap-3">
                        <Shield className="w-10 h-10 text-indigo-600" />
                        Federal Partner Portal
                    </h1>
                    <p className="text-lg text-gray-600">
                        Secure collaboration hub for federal contractor partnerships and AI model training
                    </p>
                </motion.div>

                {/* Key Metrics */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                    <Card className="bg-gradient-to-br from-green-50 to-green-100">
                        <CardContent className="p-6 text-center">
                            <Lock className="w-12 h-12 text-green-600 mx-auto mb-4" />
                            <div className="text-3xl font-bold text-green-600">
                                {agreements.filter(a => a.status === 'active').length}
                            </div>
                            <div className="text-green-700 font-semibold">Active Agreements</div>
                        </CardContent>
                    </Card>

                    <Card className="bg-gradient-to-br from-blue-50 to-blue-100">
                        <CardContent className="p-6 text-center">
                            <Bot className="w-12 h-12 text-blue-600 mx-auto mb-4" />
                            <div className="text-3xl font-bold text-blue-600">
                                {trainingSessions.filter(t => t.status === 'complete').length}
                            </div>
                            <div className="text-blue-700 font-semibold">AI Training Sessions</div>
                        </CardContent>
                    </Card>

                    <Card className="bg-gradient-to-br from-purple-50 to-purple-100">
                        <CardContent className="p-6 text-center">
                            <FileText className="w-12 h-12 text-purple-600 mx-auto mb-4" />
                            <div className="text-3xl font-bold text-purple-600">
                                {reports.filter(r => r.report_status === 'delivered').length}
                            </div>
                            <div className="text-purple-700 font-semibold">Reports Delivered</div>
                        </CardContent>
                    </Card>

                    <Card className="bg-gradient-to-br from-orange-50 to-orange-100">
                        <CardContent className="p-6 text-center">
                            <TrendingUp className="w-12 h-12 text-orange-600 mx-auto mb-4" />
                            <div className="text-3xl font-bold text-orange-600">
                                {trainingSessions.reduce((acc, t) => acc + (t.data_points_collected || 0), 0)}
                            </div>
                            <div className="text-orange-700 font-semibold">Data Points Collected</div>
                        </CardContent>
                    </Card>
                </div>

                {/* Partnership Readiness Status */}
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.2 }}
                    className="mb-8"
                >
                    <Card className="bg-gradient-to-r from-green-50 to-blue-50 border-green-200">
                        <CardHeader>
                            <CardTitle className="text-2xl text-green-700">
                                🎯 HyperCore Federal Partnership Readiness: 95%
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                                <div className="text-center">
                                    <CheckCircle className="w-16 h-16 text-green-600 mx-auto mb-2" />
                                    <h3 className="font-semibold text-green-700">CMMC Workflow Engine</h3>
                                    <p className="text-sm text-gray-600">Fully automated AI assessment pipeline</p>
                                </div>
                                <div className="text-center">
                                    <CheckCircle className="w-16 h-16 text-green-600 mx-auto mb-2" />
                                    <h3 className="font-semibold text-green-700">Data Security Framework</h3>
                                    <p className="text-sm text-gray-600">Federal-grade encryption & audit trails</p>
                                </div>
                                <div className="text-center">
                                    <CheckCircle className="w-16 h-16 text-green-600 mx-auto mb-2" />
                                    <h3 className="font-semibold text-green-700">AI Training Pipeline</h3>
                                    <p className="text-sm text-gray-600">Systematic model improvement from contractor data</p>
                                </div>
                            </div>
                            <div className="text-center mt-6">
                                <Button className="bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-8 text-lg">
                                    🚀 READY FOR FEDERAL PARTNERSHIPS
                                </Button>
                            </div>
                        </CardContent>
                    </Card>
                </motion.div>

                {/* Data Processing Agreements */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <Lock className="w-5 h-5 text-green-600" />
                                Data Processing Agreements
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-4">
                                {agreements.slice(0, 5).map((agreement, index) => (
                                    <div key={agreement.id || index} className="border rounded-lg p-4">
                                        <div className="flex justify-between items-start mb-2">
                                            <h3 className="font-semibold">{agreement.contractor_name}</h3>
                                            <Badge className={getStatusColor(agreement.status)}>
                                                {agreement.status.replace('_', ' ')}
                                            </Badge>
                                        </div>
                                        <div className="text-sm text-gray-600 space-y-1">
                                            <div>Classification: {agreement.data_classification?.toUpperCase()}</div>
                                            <div>Encryption: {agreement.encryption_level}</div>
                                            <div>AI Training Consent: {agreement.ai_training_consent ? 'Yes' : 'No'}</div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <Bot className="w-5 h-5 text-blue-600" />
                                AI Training Progress
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-4">
                                {trainingSessions.slice(0, 5).map((session, index) => (
                                    <div key={session.id || index} className="border rounded-lg p-4">
                                        <div className="flex justify-between items-start mb-2">
                                            <h3 className="font-semibold">{session.session_name}</h3>
                                            <Badge className={getStatusColor(session.status)}>
                                                {session.status}
                                            </Badge>
                                        </div>
                                        <div className="text-sm text-gray-600 space-y-1">
                                            <div>Data Points: {session.data_points_collected || 0}</div>
                                            {session.model_accuracy_before && session.model_accuracy_after && (
                                                <div>Accuracy: {session.model_accuracy_before}% → {session.model_accuracy_after}%</div>
                                            )}
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>
                </div>
            </div>
        </div>
    );
}