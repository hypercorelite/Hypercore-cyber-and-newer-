import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Code, GitBranch, FlaskConical, TestTube, CheckCircle, ArrowRight } from 'lucide-react';
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const fileStructure = `
cmmc_pdf_generator/
├── cmmc_pdf_generator/
│   ├── __init__.py
│   ├── app.py             # Flask app setup
│   ├── config.py          # Configuration (AI API, DB)
│   ├── models.py          # SQLAlchemy models
│   ├── utils/
│   │   ├── __init__.py
│   │   ├── pdf.py         # PDF generation logic
│   │   ├── ai.py          # AI content generation
│   └── routes/
│       ├── __init__.py
│       ├── ssp.py         # SSP generation
│       ├── controls.py    # Controls implementation
│       ├── policy.py      # Policy generation
│       └── report.py      # Compliance report
├── tests/
│   ├── __init__.py
│   ├── test_ssp.py
│   ├── test_controls.py
│   ├── test_policy.py
│   └── test_report.py
├── setup.py               # Package setup
├── requirements.txt
├── README.md
└── .env.example
`.trim();

const ArchitectureComponent = ({ icon: Icon, title, description }) => (
    <div className="flex items-start gap-4 p-4 bg-gray-50 rounded-lg">
        <Icon className="w-8 h-8 text-blue-600 mt-1 flex-shrink-0" />
        <div>
            <h4 className="font-semibold text-gray-900">{title}</h4>
            <p className="text-sm text-gray-600">{description}</p>
        </div>
    </div>
);

export default function CompleteExecutionRoadmap() {
    return (
        <div className="space-y-8">
            <BreadcrumbNav currentPageName="CompleteExecutionRoadmap" />

            <div className="text-center">
                <Badge className="mb-4 bg-green-100 text-green-800">PRODUCTION BLUEPRINT</Badge>
                <h1 className="text-4xl font-bold text-gray-900 mb-4">Complete Python Execution Roadmap</h1>
                <p className="text-xl text-gray-600 max-w-4xl mx-auto">
                    The official architecture for migrating from Base44 to a scalable, testable, and production-ready Python (Flask) application on AWS.
                </p>
            </div>

            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                        <GitBranch className="w-6 h-6 text-purple-600" />
                        Target Application Architecture
                    </CardTitle>
                    <CardDescription>
                        A modular Flask application designed for maintainability, scalability, and robust testing.
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <pre className="bg-slate-900 text-white p-4 rounded-lg text-sm font-mono overflow-x-auto">
                        <code>{fileStructure}</code>
                    </pre>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>Architectural Components Explained</CardTitle>
                    <CardDescription>
                        This structure separates concerns, making the application easier to manage and scale.
                    </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    <ArchitectureComponent
                        icon={FlaskConical}
                        title="Core Application (app.py, config.py, models.py)"
                        description="Initializes the Flask app, manages configuration (like database connections and API keys), and defines the data structure using SQLAlchemy models."
                    />
                    <ArchitectureComponent
                        icon={Code}
                        title="Routes (routes/)"
                        description="Handles incoming web requests. Each file (e.g., ssp.py, policy.py) defines API endpoints for a specific feature, mapping directly to the PDF generation functions currently on Base44."
                    />
                    <ArchitectureComponent
                        icon={Code}
                        title="Utilities (utils/)"
                        description="Contains reusable logic. ai.py will centralize calls to the AI content generation service, and pdf.py will contain all the jsPDF logic for creating documents, keeping the routes clean."
                    />
                    <ArchitectureComponent
                        icon={TestTube}
                        title="Testing (tests/)"
                        description="A dedicated suite of tests for each route ensures that any changes to one part of the application don't break another. This is critical for reliable, production-grade software."
                    />
                </CardContent>
            </Card>
            
            <Card className="bg-gradient-to-r from-blue-600 to-indigo-700 text-white">
                <CardHeader>
                    <CardTitle>From Blueprint to Production</CardTitle>
                    <CardDescription className="text-blue-200">This architecture is the key to your AWS migration and long-term success.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4 text-blue-100">
                     <div className="flex items-center gap-3">
                        <CheckCircle className="w-5 h-5 text-green-300" />
                        <p><strong>Scalability:</strong> Ready to be deployed on AWS Lambda or ECS Fargate to handle thousands of users.</p>
                    </div>
                    <div className="flex items-center gap-3">
                        <CheckCircle className="w-5 h-5 text-green-300" />
                        <p><strong>Maintainability:</strong> Clean, separated code makes it easy to add new features or fix bugs.</p>
                    </div>
                     <div className="flex items-center gap-3">
                        <CheckCircle className="w-5 h-5 text-green-300" />
                        <p><strong>SEO-Ready:</strong> Provides the foundation for building the blog and content pages outlined in the SEO strategy.</p>
                    </div>
                    <div className="pt-4">
                        <Button asChild variant="secondary" className="bg-white/90 text-blue-700 hover:bg-white">
                            <Link to={createPageUrl('AWSMigrationExecutionPlan')}>
                                View AWS Migration Plan <ArrowRight className="w-4 h-4 ml-2" />
                            </Link>
                        </Button>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}