import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button"; // Added Button import
import { Clock, DollarSign, Target, CheckCircle, Rocket, User, HardDrive, TestTube, FileText, BookOpen, GitBranch, Code, Database, Zap, ArrowRight } from 'lucide-react'; // Added Code, Database, Zap, ArrowRight
import { motion } from "framer-motion";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';


export default function MVPSBIRAlignment() {
    return (
        <div className="space-y-8">
            <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="text-center">
                <Badge className="mb-4 bg-blue-100 text-blue-800">INTERNAL STRATEGY</Badge>
                <h1 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-3 flex items-center justify-center gap-3">
                    <Target className="w-8 h-8 text-blue-600" />
                    16-Week Learning + Building Sprint to SBIR MVP
                </h1>
                <p className="text-lg lg:text-xl text-gray-600 max-w-4xl mx-auto">
                    Learn by building: Master each technology while creating your CMMC AI tool piece by piece.
                </p>
            </motion.div>

            <Alert className="bg-green-50 border-green-200">
                <Code className="h-4 w-4" />
                <AlertTitle className="text-green-800 font-semibold">Your Primary Build Plan is Ready</AlertTitle>
                <AlertDescription>
                    This page provides the high-level budget and strategy. For the detailed week-by-week plan with training links and implementation steps, please use the dedicated guide.
                    <Button asChild variant="link" className="p-0 h-auto ml-1 text-green-700 font-bold">
                        <Link to={createPageUrl('LocalDevelopmentGuide')}>
                           Go to the 16-Week Learn & Build Plan <ArrowRight className="w-4 h-4 ml-1" />
                        </Link>
                    </Button>
                </AlertDescription>
            </Alert>

            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2"><DollarSign className="text-green-600" />Budget for Learning-by-Building Approach</CardTitle>
                    <CardDescription>Costs optimized for a learning developer building incrementally.</CardDescription>
                </CardHeader>
                <CardContent className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <div className="p-4 bg-gray-50 rounded-lg border border-green-200">
                        <h4 className="font-semibold mb-2 flex items-center gap-2"><User className="text-green-600"/>Learning Investment (Sweat Equity)</h4>
                        <p className="text-sm text-gray-600 mb-2">16 weeks × 20-30 hours/week of focused learning and building</p>
                        <ul className="text-sm space-y-1">
                            <li><strong>Skill Development Value:</strong> $15,000</li>
                            <li><strong>MVP Development Value:</strong> $25,000</li>
                            <li><strong>Cash Cost:</strong> $0</li>
                        </ul>
                        <Badge className="mt-3 bg-green-100 text-green-800">Total Sweat Equity: $40,000</Badge>
                    </div>
                    <div className="p-4 bg-gray-50 rounded-lg border border-blue-200">
                        <h4 className="font-semibold mb-2 flex items-center gap-2"><Database className="text-blue-600"/>Technology & APIs (4 months)</h4>
                        <ul className="text-sm space-y-1">
                            <li><strong>Pinecone (Vector DB):</strong> ~$200</li>
                            <li><strong>OpenAI API calls:</strong> ~$150</li>
                            <li><strong>AWS services:</strong> ~$50</li>
                            <li><strong>Learning platforms:</strong> ~$100</li>
                        </ul>
                         <Badge className="mt-3 bg-blue-100 text-blue-800">Total Tech Cost: ~$500</Badge>
                    </div>
                     <div className="p-4 bg-gray-50 rounded-lg border border-red-200">
                        <h4 className="font-semibold mb-2 flex items-center gap-2"><TestTube className="text-red-600"/>Testing & Validation</h4>
                        <ul className="text-sm space-y-1">
                            <li><strong>Demo recording tools:</strong> ~$30</li>
                            <li><strong>User feedback tools:</strong> ~$50</li>
                            <li><strong>Pilot incentives:</strong> ~$200</li>
                        </ul>
                        <Badge className="mt-3 bg-red-100 text-red-800">Total Validation: ~$280</Badge>
                    </div>
                </CardContent>
                 <div className="p-6 pt-0">
                    <Alert>
                        <CheckCircle className="h-4 w-4" />
                        <AlertTitle>Total Investment for SBIR-Ready MVP</AlertTitle>
                        <AlertDescription>
                            <div className="flex flex-wrap gap-x-4 gap-y-1 mt-2">
                                <span className="font-semibold">Total Cash Needed: <span className="text-green-700 font-bold">~$780</span></span>
                                <span className="font-semibold">Total Project Value: <span className="text-blue-700 font-bold">~$40,780</span></span>
                            </div>
                            <p className="text-xs text-gray-600 mt-2">This demonstrates extreme capital efficiency: every $1 spent is backed by ~$52 of learning and development value.</p>
                        </AlertDescription>
                    </Alert>
                </div>
            </Card>
        </div>
    );
}