import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Shield, AlertTriangle, Clock, DollarSign, Users, CheckCircle, TrendingUp, Target, BookOpen, ArrowRight } from 'lucide-react';
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";

const challengeData = [
    {
        challenge: "Complexity and Expertise Gaps",
        description: "NIST 800-171A is 76 pages covering 320+ assessment objectives for 110 controls. 70-80% of SMBs lack dedicated IT/security staff.",
        mockBenefit: "Expert-guided gap analysis, SSP templates, and POA&M prioritization reduce errors by 50-70%.",
        skipRisk: "Missing 10-20 controls leads to C3PAO audit failure. Only ~85 SMBs certified by April 2025.",
        cost: "$10K-30K mock prevents $50K-118K re-audits"
    },
    {
        challenge: "No Guarantee, But Risk Reduction",
        description: "C3PAOs apply subjective judgment requiring specific evidence formats. SMBs misjudge scope/evidence in ~60% of self-assessments.",
        mockBenefit: "Simulates C3PAO process, boosts pass rates by ~80% compared to unprepared firms.",
        skipRisk: "Failed C3PAO audit costs $50K-118K (non-recoverable) and delays certification 6-12 months.",
        cost: "Mock assessment saves $20K-50K in post-failure remediation"
    },
    {
        challenge: "Assessor Shortages and Backlogs",
        description: "Only ~250 C3PAOs and ~500-1,000 CCAs for 5,000-7,000 needed audits in Phase 2 (2026-2027).",
        mockBenefit: "Conducted 3-6 months earlier, allows C3PAO scheduling in Phase 1 (1-3 month waits vs Phase 2 bottlenecks).",
        skipRisk: "Direct C3PAO audits without prep risk failure, pushing SMBs to back of 6-12 month queue.",
        cost: "Mock costs ~20% of total Level 2 expenses but saves 6-12 months"
    },
    {
        challenge: "Prime Contractor Flow-Down Pressure",
        description: "Primes enforce Level 2 certification even in Phase 1 to ensure subcontractor reliability. Self-assessments may not satisfy primes.",
        mockBenefit: "Validates SSPs and POA&Ms for prime verification, ensuring DFARS 252.204-7021 compliance.",
        skipRisk: "Going straight to C3PAO risks incomplete documentation, failing prime audits, delaying $70B in 2025 subcontracts.",
        cost: "75% of compliant SMBs report faster contract wins"
    },
    {
        challenge: "Resource Constraints and Documentation",
        description: "Creating SSP, POA&Ms, and evidence for 110 controls requires ~168 hours ($20K-40K labor).",
        mockBenefit: "Provides templates, scoping guidance, staff training, reducing labor by 20-30%.",
        skipRisk: "Self-guided efforts often produce incomplete SSPs, rejected by C3PAOs, requiring $20K-50K rework.",
        cost: "Tools integration saves $10K-20K in preparation costs"
    }
];

const alternativeOptions = [
    {
        option: "Free DoD Resources",
        description: "Project Spectrum and DAU offer 800-171A-based checklists and training",
        cost: "$5K-10K labor savings",
        benefit: "300,000+ trained by July 2025, saves 20-30% on prep costs",
        limitation: "Lacks personalized feedback, risks errors"
    },
    {
        option: "AI Tools (SBIR-Funded)",
        description: "Emerging solutions automate 800-171A assessments",
        cost: "$10K-30K",
        benefit: "Mimics mock benefits with 50-70% time savings",
        limitation: "New technology, limited track record",
        highlight: true
    },
    {
        option: "Self-Assessments (Phase 1)",
        description: "Allowed for lower-risk CUI contracts until November 2026",
        cost: "$0-5K labor",
        benefit: "Suitable for early prep",
        limitation: "Insufficient for prime flow-down or Phase 2 audits"
    },
    {
        option: "MSPs with Built-In Prep",
        description: "Providers bundle 800-171A-guided prep with managed services",
        cost: "$30K-60K",
        benefit: "Reduces need for separate mocks",
        limitation: "Higher ongoing costs"
    }
];

export default function MockAssessmentStrategy() {
    return (
        <div className="space-y-8">
            <BreadcrumbNav currentPageName="MockAssessmentStrategy" />
            
            <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center"
            >
                <Badge className="mb-4 bg-blue-100 text-blue-800">MARKET ANALYSIS</Badge>
                <h1 className="text-4xl font-bold text-gray-900 mb-4">
                    Mock Assessments vs. Direct C3PAO Audits
                </h1>
                <p className="text-xl text-gray-600 max-w-4xl mx-auto">
                    Strategic analysis of why SMBs choose mock assessments over relying solely on NIST 800-171A before C3PAO audits.
                </p>
            </motion.div>

            <Alert className="bg-yellow-50 border-yellow-200">
                <AlertTriangle className="h-4 w-4 text-yellow-600" />
                <AlertTitle className="text-yellow-800">Market Reality Check</AlertTitle>
                <AlertDescription className="text-yellow-700">
                    While NIST 800-171A provides the assessment framework, 70-80% of SMBs lack the cybersecurity expertise to apply it correctly without guidance. This creates a $2.3B market opportunity for preparation services.
                </AlertDescription>
            </Alert>

            <Tabs defaultValue="challenges" className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="challenges">Why Mock Assessments Win</TabsTrigger>
                    <TabsTrigger value="alternatives">Alternative Approaches</TabsTrigger>
                    <TabsTrigger value="positioning">Our Market Position</TabsTrigger>
                </TabsList>

                <TabsContent value="challenges" className="space-y-6">
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-3">
                                <Shield className="text-red-600" />
                                5 Key Challenges with Direct C3PAO Audits
                            </CardTitle>
                            <CardDescription>
                                Why 31,500 SMBs in the Defense Industrial Base prefer mock assessments over self-guided NIST 800-171A implementation.
                            </CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-6">
                            {challengeData.map((item, index) => (
                                <motion.div
                                    key={item.challenge}
                                    initial={{ opacity: 0, y: 20 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    transition={{ delay: index * 0.1 }}
                                    className="p-6 bg-gray-50 rounded-lg border"
                                >
                                    <h3 className="text-lg font-semibold text-gray-800 mb-3">{item.challenge}</h3>
                                    <div className="grid md:grid-cols-2 gap-4 text-sm">
                                        <div>
                                            <h4 className="font-medium text-red-700 mb-2">The Problem:</h4>
                                            <p className="text-gray-600 mb-3">{item.description}</p>
                                            <h4 className="font-medium text-red-700 mb-2">Risk of Skipping Mock:</h4>
                                            <p className="text-red-600">{item.skipRisk}</p>
                                        </div>
                                        <div>
                                            <h4 className="font-medium text-green-700 mb-2">Mock Assessment Benefit:</h4>
                                            <p className="text-gray-600 mb-3">{item.mockBenefit}</p>
                                            <h4 className="font-medium text-green-700 mb-2">Economic Impact:</h4>
                                            <p className="text-green-600 font-semibold">{item.cost}</p>
                                        </div>
                                    </div>
                                </motion.div>
                            ))}
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="alternatives" className="space-y-6">
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-3">
                                <Target className="text-blue-600" />
                                Alternatives to Traditional Mock Assessments
                            </CardTitle>
                            <CardDescription>
                                Cost-effective options for SMBs seeking to avoid $10K-30K mock assessment fees.
                            </CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            {alternativeOptions.map((option, index) => (
                                <motion.div
                                    key={option.option}
                                    initial={{ opacity: 0, x: -20 }}
                                    animate={{ opacity: 1, x: 0 }}
                                    transition={{ delay: index * 0.1 }}
                                    className={`p-4 rounded-lg border-2 ${
                                        option.highlight 
                                            ? 'border-blue-500 bg-blue-50' 
                                            : 'border-gray-200 bg-white'
                                    }`}
                                >
                                    <div className="flex justify-between items-start mb-2">
                                        <h3 className="font-semibold text-gray-800">{option.option}</h3>
                                        <Badge className={option.highlight ? 'bg-blue-600' : 'bg-gray-500'}>
                                            {option.cost}
                                        </Badge>
                                    </div>
                                    <p className="text-sm text-gray-600 mb-2">{option.description}</p>
                                    <div className="grid md:grid-cols-2 gap-2 text-xs">
                                        <div>
                                            <span className="font-medium text-green-600">Benefit:</span> {option.benefit}
                                        </div>
                                        <div>
                                            <span className="font-medium text-red-600">Limitation:</span> {option.limitation}
                                        </div>
                                    </div>
                                </motion.div>
                            ))}
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="positioning" className="space-y-6">
                    <Card className="bg-gradient-to-r from-purple-50 to-blue-50">
                        <CardHeader>
                            <CardTitle className="flex items-center gap-3">
                                <TrendingUp className="text-purple-600" />
                                HyperCore's Strategic Position in This Market
                            </CardTitle>
                            <CardDescription>
                                How AI-powered preparation services address the gaps in traditional mock assessments and direct audits.
                            </CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-6">
                            <Alert className="bg-purple-50 border-purple-200">
                                <CheckCircle className="h-4 w-4 text-purple-600" />
                                <AlertTitle className="text-purple-800">Our Unique Position</AlertTitle>
                                <AlertDescription className="text-purple-700">
                                    We deliver the benefits of a $10K-30K mock assessment at $4.5K-24.5K, with AI automation providing 50-70% time savings while maintaining expert validation.
                                </AlertDescription>
                            </Alert>

                            <div className="grid md:grid-cols-2 gap-6">
                                <div className="space-y-4">
                                    <h3 className="text-lg font-semibold text-gray-800">Traditional Mock Assessment Problems We Solve:</h3>
                                    <ul className="space-y-2 text-sm">
                                        <li className="flex items-start gap-2">
                                            <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                                            <span><strong>Cost:</strong> Reduce $10K-30K to $4.5K-24.5K fixed fee</span>
                                        </li>
                                        <li className="flex items-start gap-2">
                                            <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                                            <span><strong>Speed:</strong> 90 days vs 6-18 months traditional prep</span>
                                        </li>
                                        <li className="flex items-start gap-2">
                                            <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                                            <span><strong>Scalability:</strong> AI automation serves 31,500 SMBs simultaneously</span>
                                        </li>
                                        <li className="flex items-start gap-2">
                                            <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                                            <span><strong>Accuracy:</strong> Automated 800-171A compliance reduces human error</span>
                                        </li>
                                    </ul>
                                </div>
                                <div className="space-y-4">
                                    <h3 className="text-lg font-semibold text-gray-800">Direct C3PAO Audit Risks We Mitigate:</h3>
                                    <ul className="space-y-2 text-sm">
                                        <li className="flex items-start gap-2">
                                            <Shield className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                                            <span><strong>Preparation:</strong> Expert-guided vs self-guided 800-171A application</span>
                                        </li>
                                        <li className="flex items-start gap-2">
                                            <Shield className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                                            <span><strong>Evidence:</strong> C3PAO-ready documentation and formatting</span>
                                        </li>
                                        <li className="flex items-start gap-2">
                                            <Shield className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                                            <span><strong>Scoping:</strong> Proper CUI boundary identification</span>
                                        </li>
                                        <li className="flex items-start gap-2">
                                            <Shield className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                                            <span><strong>Timing:</strong> Avoid 6-12 month Phase 2 backlogs</span>
                                        </li>
                                    </ul>
                                </div>
                            </div>

                            <div className="p-6 bg-white rounded-lg border-2 border-purple-200">
                                <h3 className="text-lg font-semibold text-purple-800 mb-3">Market Opportunity Validation</h3>
                                <div className="grid md:grid-cols-3 gap-4 text-center">
                                    <div>
                                        <div className="text-2xl font-bold text-purple-600">31,500</div>
                                        <div className="text-sm text-gray-600">Underserved SMBs</div>
                                    </div>
                                    <div>
                                        <div className="text-2xl font-bold text-purple-600">$2.3B</div>
                                        <div className="text-sm text-gray-600">Market Opportunity</div>
                                    </div>
                                    <div>
                                        <div className="text-2xl font-bold text-purple-600">75%</div>
                                        <div className="text-sm text-gray-600">Choose Preparation Services</div>
                                    </div>
                                </div>
                            </div>
                        </CardContent>
                    </Card>

                    <div className="text-center">
                        <Button asChild size="lg" className="bg-purple-600 hover:bg-purple-700">
                            <Link to={createPageUrl('SBIRTimelineAlignment')}>
                                View SBIR Strategy Alignment <ArrowRight className="w-4 h-4 ml-2" />
                            </Link>
                        </Button>
                    </div>
                </TabsContent>
            </Tabs>
        </div>
    );
}