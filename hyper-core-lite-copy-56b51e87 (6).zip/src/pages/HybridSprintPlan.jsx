
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Calendar, CheckCircle, Cloud, Code, FileText, Zap, ArrowRight, Shield, AlertCircle, AlertTriangle } from 'lucide-react';
import { motion } from "framer-motion";
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

const sprintPlan = {
    week1: {
        title: "Foundation & Core AI Completion",
        status: "COMPLETE",
        progress: 100,
        color: "bg-green-500",
        outcomes: ["✅ AI Gap Analysis Engine working", "✅ Core entities defined", "✅ User authentication system", "✅ Support ticket system"],
        focus: "Your Base44 prototype is the proof of concept. This week validates the AI-first approach works."
    },
    week2: {
        title: "Frontend Polish & Integration",
        status: "COMPLETE",
        progress: 100,
        color: "bg-green-500",
        outcomes: ["✅ Professional client dashboard", "✅ Policy generation system", "✅ PDF report generation", "✅ Email automation"],
        focus: "Client-facing interface completed. The user experience proves professional viability."
    },
    week3: {
        title: "Prepare Staging Server & Install MGN Agent",
        status: "NEXT",
        progress: 0,
        color: "bg-blue-500",
        outcomes: ["🎯 Export Base44 code & data schema", "🎯 Deploy exported application to existing EC2 instance", "🎯 Install AWS Application Migration Service Agent", "🎯 Begin continuous server replication to AWS"],
        focus: "CRITICAL PIVOT: Create the 'source server' for our migration. This turns your Base44 app into a standard server that AWS MGN can clone."
    },
    week4: {
        title: "MGN Replication & Non-Disruptive Testing",
        status: "PLANNED",
        progress: 0,
        color: "bg-blue-400",
        outcomes: ["🎯 Monitor MGN replication progress", "🎯 Launch a non-disruptive 'Test Instance' from MGN", "🎯 Conduct full end-to-end testing of the CMMC app on the test instance", "🎯 Validate all AI features and data integrity"],
        focus: "Verify that the entire application works perfectly on AWS infrastructure before committing to the final move. This step is zero-risk to the live prototype."
    },
    week5: {
        title: "Execute Cutover & Go-Live on AWS",
        status: "PLANNED",
        progress: 0,
        color: "bg-blue-400",
        outcomes: ["🎯 Launch final 'Cutover Instance' via MGN", "🎯 Update Route 53 DNS to point to the new production EC2 IP", "🎯 Decommission the old staging EC2 instance", "🎯 Application is now fully live on your own AWS infrastructure"],
        focus: "The final step. With a single click in the MGN console, your tested, validated application becomes the new production environment."
    },
    week6: {
        title: "Security & Compliance Hardening",
        status: "PLANNED",
        progress: 0,
        color: "bg-blue-400",
        outcomes: ["🎯 IAM policies & WAF", "🎯 Encryption at rest/transit", "🎯 Compliance documentation", "🎯 Security scanning"],
        focus: "Federal-grade security implementation. Document everything for SBIR technical volume."
    },
    week7: {
        title: "Performance & Production Readiness",
        status: "PLANNED",
        progress: 0,
        color: "bg-blue-400",
        outcomes: ["🎯 Load testing & optimization", "🎯 Monitoring & alerting", "🎯 Backup & recovery", "🎯 Documentation"],
        focus: "Production deployment readiness. Prove the system can handle real client loads."
    },
    week8: {
        title: "Launch & SBIR Documentation",
        status: "PLANNED",
        progress: 0,
        color: "bg-blue-400",
        outcomes: ["🎯 Production deployment", "🎯 Client onboarding live", "🎯 SBIR technical documentation", "🎯 Performance metrics"],
        focus: "Go-live with paying clients. Complete SBIR Phase I technical documentation."
    }
};

const realityCheck = {
    achievable: [
        { point: "Not Starting From Scratch", details: "You have a validated, working prototype. This is a migration, not a greenfield project." },
        { point: "True Lift & Shift Model", details: "AWS MGN directly copies the server, eliminating the need to refactor code for serverless environments." },
        { point: "Automated Infrastructure Setup", details: "MGN handles the complex parts of setting up the target AWS environment automatically." },
        { point: "Free Migration Path", details: "The 90-day free tier for MGN covers the entire sprint, making the migration process itself free of charge." }
    ],
    risks: [
        { risk: "No Buffer Time", details: "The 8-week schedule is packed. Any 3-4 day delay on a critical task jeopardizes the SBIR deadline." },
        { risk: "AWS Learning Curve", details: "While CDK helps, services like IAM, Cognito, and VPC networking can have a steep learning curve." },
        { risk: "Solo Founder Bottleneck", details: "You are the single point of failure. Burnout is a serious risk during an 8-week, high-intensity sprint." },
        { risk: "Integration 'Gotchas'", details: "Connecting disparate services (Lambda, API Gateway, Cognito, RDS) always uncovers unexpected issues." }
    ]
};


const sbirAlignment = [
    { week: "Week 1-2", deliverable: "Proof of Concept Validation", sbirSection: "Technical Innovation", impact: "Demonstrates AI-first CMMC automation works" },
    { week: "Week 3-4", deliverable: "AWS Architecture Documentation", sbirSection: "Technical Approach", impact: "Shows federal-ready infrastructure design" },
    { week: "Week 5-6", deliverable: "Security & Compliance Evidence", sbirSection: "Technical Risk Assessment", impact: "Documents security posture for federal use" },
    { week: "Week 7-8", deliverable: "Performance Data & Scaling Plan", sbirSection: "Commercialization Strategy", impact: "Proves system can scale to serve DoD contractors" }
];

const budgetBreakdown = {
    base44_investment: { amount: "$0", description: "Completed - Pure sweat equity" },
    aws_migration: { amount: "$50", description: "Weeks 3-8 infrastructure costs (EC2, EBS, data)" },
    total_cash: { amount: "$50", description: "Total cash required for migration" },
    sweat_equity: { amount: "$20,000", description: "160 hours @ $125/hr value" },
    total_value: { amount: "$20,050", description: "Total project value for SBIR" }
};

export default function HybridSprintPlan() {
    const overallProgress = Math.round(Object.values(sprintPlan).reduce((acc, week) => acc + week.progress, 0) / 8);

    return (
        <div className="space-y-8">
            <BreadcrumbNav currentPageName="HybridSprintPlan" />

            <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="text-center">
                <Badge className="mb-4 bg-blue-100 text-blue-800">UPDATED SPRINT PLAN</Badge>
                <h1 className="text-4xl font-bold text-gray-900 mb-4">8-Week Hybrid Sprint: Base44 → AWS</h1>
                <p className="text-xl text-gray-600 max-w-4xl mx-auto">
                    The perfect balance: Leverage your Base44 foundation, migrate to AWS infrastructure, maintain 25-30 hours/week pace, achieve SBIR readiness by November 10.
                </p>
            </motion.div>

            <Alert className="bg-gradient-to-r from-orange-500 to-red-600 text-white border-0 shadow-lg">
                <AlertCircle className="h-5 w-5 text-white" />
                <AlertTitle className="text-2xl font-bold">TIMELINE REALISM CHECK: Aggressive but Achievable</AlertTitle>
                <AlertDescription className="text-lg mt-2">
                    This 8-week plan is your fastest path to federal readiness but requires intense focus. Success hinges on leveraging the Base44 export and AI tools to accelerate the AWS rebuild.
                </AlertDescription>
            </Alert>

            <Card>
                <CardHeader>
                    <CardTitle>Timeline Feasibility Analysis</CardTitle>
                </CardHeader>
                <CardContent className="grid md:grid-cols-2 gap-6">
                    <div className="p-4 bg-green-50 rounded-lg">
                        <h3 className="font-bold text-green-800 mb-3 flex items-center gap-2"><CheckCircle/>Why It's Achievable</h3>
                        <ul className="space-y-3">
                            {realityCheck.achievable.map((item, index) => (
                                <li key={index} className="text-sm">
                                    <strong className="text-green-700">{item.point}:</strong>
                                    <p className="text-gray-600">{item.details}</p>
                                </li>
                            ))}
                        </ul>
                    </div>
                    <div className="p-4 bg-red-50 rounded-lg">
                        <h3 className="font-bold text-red-800 mb-3 flex items-center gap-2"><AlertTriangle/>Critical Risks</h3>
                         <ul className="space-y-3">
                            {realityCheck.risks.map((item, index) => (
                                <li key={index} className="text-sm">
                                    <strong className="text-red-700">{item.risk}:</strong>
                                    <p className="text-gray-600">{item.details}</p>
                                </li>
                            ))}
                        </ul>
                    </div>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                        <Calendar className="w-6 h-6 text-blue-600" />
                        Overall Sprint Progress
                    </CardTitle>
                    <CardDescription>8-week journey from Base44 prototype to AWS production deployment</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="space-y-4">
                        <div>
                            <div className="flex justify-between items-center mb-2">
                                <span className="font-semibold">Sprint Completion</span>
                                <span className="text-lg font-bold text-blue-600">{overallProgress}%</span>
                            </div>
                            <Progress value={overallProgress} className="h-3" />
                        </div>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                            <div>
                                <div className="text-2xl font-bold text-green-600">2</div>
                                <div className="text-sm text-gray-600">Weeks Complete</div>
                            </div>
                            <div>
                                <div className="text-2xl font-bold text-blue-600">6</div>
                                <div className="text-sm text-gray-600">Weeks Remaining</div>
                            </div>
                            <div>
                                <div className="text-2xl font-bold text-orange-600">35</div>
                                <div className="text-sm text-gray-600">Days to Launch</div>
                            </div>
                            <div>
                                <div className="text-2xl font-bold text-purple-600">Nov 10</div>
                                <div className="text-sm text-gray-600">Target Date</div>
                            </div>
                        </div>
                    </div>
                </CardContent>
            </Card>

            <div className="space-y-6">
                {Object.entries(sprintPlan).map(([weekKey, week]) => (
                    <motion.div
                        key={weekKey}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.1 * parseInt(weekKey.replace('week', '')) }}
                    >
                        <Card className={`border-l-4 ${week.color.replace('bg-', 'border-')}`}>
                            <CardHeader>
                                <div className="flex justify-between items-center">
                                    <div>
                                        <CardTitle className="flex items-center gap-2">
                                            {week.status === 'COMPLETE' ? <CheckCircle className="w-5 h-5 text-green-600" /> :
                                             week.status === 'NEXT' ? <Zap className="w-5 h-5 text-blue-600" /> :
                                             <Calendar className="w-5 h-5 text-gray-400" />}
                                            {weekKey.replace('week', 'Week ').toUpperCase()}: {week.title}
                                        </CardTitle>
                                        <CardDescription>{week.focus}</CardDescription>
                                    </div>
                                    <Badge className={
                                        week.status === 'COMPLETE' ? 'bg-green-100 text-green-800' :
                                        week.status === 'NEXT' ? 'bg-blue-100 text-blue-800' :
                                        'bg-gray-100 text-gray-800'
                                    }>
                                        {week.status}
                                    </Badge>
                                </div>
                            </CardHeader>
                            <CardContent>
                                <div className="grid md:grid-cols-2 gap-4">
                                    <div>
                                        <h4 className="font-semibold mb-2">Deliverables:</h4>
                                        <ul className="space-y-1">
                                            {week.outcomes.map((outcome, index) => (
                                                <li key={index} className="text-sm flex items-start gap-2">
                                                    <span className="text-xs mt-0.5">{outcome.slice(0, 2)}</span>
                                                    <span>{outcome.slice(3)}</span>
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                                    <div>
                                        <h4 className="font-semibold mb-2">Progress:</h4>
                                        <Progress value={week.progress} className="mb-2" />
                                        <div className="text-sm text-gray-600">{week.progress}% complete</div>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    </motion.div>
                ))}
            </div>

            <Card>
                <CardHeader>
                    <CardTitle>SBIR Phase I Alignment</CardTitle>
                    <CardDescription>How each sprint week directly contributes to your SBIR proposal</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="space-y-4">
                        {sbirAlignment.map((item, index) => (
                            <div key={index} className="p-4 bg-blue-50 rounded-lg border-l-4 border-blue-400">
                                <div className="flex justify-between items-start mb-2">
                                    <h4 className="font-semibold">{item.week}</h4>
                                    <Badge variant="outline">{item.sbirSection}</Badge>
                                </div>
                                <h5 className="font-medium text-blue-800">{item.deliverable}</h5>
                                <p className="text-sm text-gray-600 mt-1">{item.impact}</p>
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2"><span className="text-2xl">💰</span> Updated Budget Analysis</CardTitle>
                    <CardDescription>Total investment required for SBIR-ready AWS deployment</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="grid md:grid-cols-2 gap-6">
                        <div>
                            <h4 className="font-semibold mb-3">Cash Investment:</h4>
                            <div className="space-y-2">
                                <div className="flex justify-between">
                                    <span>Base44 Foundation (Weeks 1-2)</span>
                                    <span className="font-semibold text-green-600">{budgetBreakdown.base44_investment.amount}</span>
                                </div>
                                <div className="flex justify-between">
                                    <span>AWS Migration (Weeks 3-8)</span>
                                    <span className="font-semibold text-blue-600">{budgetBreakdown.aws_migration.amount}</span>
                                </div>
                                <div className="border-t pt-2 flex justify-between font-bold">
                                    <span>Total Cash Required</span>
                                    <span className="text-green-600">{budgetBreakdown.total_cash.amount}</span>
                                </div>
                            </div>
                        </div>
                        <div>
                            <h4 className="font-semibold mb-3">Total Project Value:</h4>
                            <div className="space-y-2">
                                <div className="flex justify-between">
                                    <span>Development Time Value</span>
                                    <span className="font-semibold">{budgetBreakdown.sweat_equity.amount}</span>
                                </div>
                                <div className="flex justify-between">
                                    <span>Infrastructure Costs</span>
                                    <span className="font-semibold">{budgetBreakdown.aws_migration.amount}</span>
                                </div>
                                <div className="border-t pt-2 flex justify-between font-bold">
                                    <span>Total Project Value</span>
                                    <span className="text-blue-600">{budgetBreakdown.total_value.amount}</span>
                                </div>
                            </div>
                            <p className="text-xs text-gray-500 mt-2">Demonstrates excellent capital efficiency to SBIR reviewers</p>
                        </div>
                    </div>
                </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-gray-900 to-blue-900 text-white">
                <CardHeader>
                    <CardTitle className="text-2xl">The Hybrid Advantage</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <p className="text-lg"><strong>Why This Plan Works:</strong></p>
                    <div className="grid md:grid-cols-2 gap-4">
                        <div>
                            <h4 className="font-semibold mb-2 flex items-center gap-2"><CheckCircle className="w-4 h-4" /> Base44 Benefits Preserved:</h4>
                            <ul className="text-sm space-y-1">
                                <li>• Rapid prototyping and validation ✅</li>
                                <li>• AI integration patterns proven ✅</li>
                                <li>• User authentication working ✅</li>
                                <li>• Client workflow validated ✅</li>
                            </ul>
                        </div>
                        <div>
                            <h4 className="font-semibold mb-2 flex items-center gap-2"><Cloud className="w-4 h-4" /> AWS Advantages Added:</h4>
                            <ul className="text-sm space-y-1">
                                <li>• Federal agency credibility 🎯</li>
                                <li>• GovCloud compliance ready 🎯</li>
                                <li>• Unlimited scalability 🎯</li>
                                <li>• Enterprise security posture 🎯</li>
                            </ul>
                        </div>
                    </div>
                    <div className="pt-4 flex flex-col sm:flex-row gap-4">
                        <Button asChild size="lg" className="bg-green-600 hover:bg-green-700 flex-1">
                            <Link to={createPageUrl('DailyAchievementSchedule')}>
                                Execute Today's Tasks <ArrowRight className="w-5 h-5 ml-2" />
                            </Link>
                        </Button>
                        <Button asChild size="lg" variant="secondary" className="flex-1">
                            <Link to={createPageUrl('AWSMigrationStrategy')}>
                                View Migration Cost & Strategy <Cloud className="w-5 h-5 ml-2" />
                            </Link>
                        </Button>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}
