import React, { useState, useEffect } from 'react';
import { User } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { UserCircle, Save, Loader2, AlertTriangle } from 'lucide-react';
import { LoadingSpinner } from '@/components/ui/LoadingSpinner';

export default function ProfileSettings() {
    const [user, setUser] = useState(null);
    const [fullName, setFullName] = useState('');
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);

    useEffect(() => {
        const fetchUser = async () => {
            try {
                const currentUser = await User.me();
                setUser(currentUser);
                setFullName(currentUser.full_name || '');
            } catch (error) {
                toast.error("You must be logged in to view this page.");
            } finally {
                setLoading(false);
            }
        };
        fetchUser();
    }, []);

    const handleSave = async (e) => {
        e.preventDefault();
        if (!fullName.trim()) {
            toast.error("Full Name cannot be empty.");
            return;
        }
        setSaving(true);
        try {
            await User.updateMyUserData({ full_name: fullName });
            toast.success("Profile updated successfully!");
            // Force a reload to update the name in the layout
            window.location.reload();
        } catch (error) {
            toast.error("Failed to update profile.");
            console.error(error);
        } finally {
            setSaving(false);
        }
    };

    if (loading) {
        return <LoadingSpinner text="Loading profile..." />;
    }

    if (!user) {
        return <div className="text-center p-8">Please log in to manage your profile.</div>;
    }

    return (
        <div className="max-w-2xl mx-auto">
            <CardHeader className="px-0">
                <CardTitle className="text-3xl font-bold flex items-center gap-3">
                    <UserCircle className="w-8 h-8 text-blue-600" />
                    Profile Settings
                </CardTitle>
                <CardDescription>
                    Manage your personal profile information. This name is displayed throughout the platform when you are logged in.
                </CardDescription>
            </CardHeader>

            <Card>
                <CardHeader>
                    <CardTitle>Your Details</CardTitle>
                </CardHeader>
                <CardContent>
                    <form onSubmit={handleSave} className="space-y-6">
                        <div className="space-y-2">
                            <label htmlFor="email" className="font-medium">Email Address</label>
                            <Input id="email" type="email" value={user.email} disabled className="bg-gray-100" />
                            <p className="text-xs text-gray-500">Your email address is your unique identifier and cannot be changed.</p>
                        </div>
                        <div className="space-y-2">
                            <label htmlFor="fullName" className="font-medium">Full Name</label>
                            <Input id="fullName" value={fullName} onChange={(e) => setFullName(e.target.value)} placeholder="Enter your full name" />
                        </div>
                        <Button type="submit" disabled={saving} className="w-full">
                            {saving ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Saving...</> : <><Save className="mr-2 h-4 w-4" /> Save Changes</>}
                        </Button>
                    </form>
                </CardContent>
            </Card>
            
            <div className="mt-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                 <div className="flex items-center gap-3">
                    <AlertTriangle className="h-5 w-5 text-yellow-600"/>
                    <h4 className="font-bold text-yellow-800">Recommendation: Create a New Admin User</h4>
                </div>
                <p className="text-sm text-yellow-700 mt-2">
                    For maximum professionalism, we strongly recommend creating a new admin user with a professional email address (e.g., `admin@hypercorecyber.com`). You can do this from the **User Management** page. After creating the new user, log out and log back in with the new credentials.
                </p>
            </div>
        </div>
    );
}