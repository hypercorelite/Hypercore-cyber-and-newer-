import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Briefcase, GraduationCap, Code, Mail, Linkedin, Star } from 'lucide-react';
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";

const resumeData = {
    name: "Christine Boes",
    title: "Founder, CEO & AI Engineer",
    contact: {
        email: "christine.boes@hypercorecyber.com",
        linkedin: "linkedin.com/in/christineboes"
    },
    summary: "A seasoned systems and compliance expert with over 20 years of experience deploying and monitoring secure data and compliance systems within highly regulated government sectors. Now applying this deep domain expertise as an AI Engineer to solve national security challenges in the Defense Industrial Base through HyperCore Cyber Security LLC, a company founded to automate and democratize CMMC compliance for SMBs.",
    coreCompetencies: [
        "Compliance Automation Strategy", "Federal Regulatory Analysis", "AI/ML Application (RAG)",
        "Secure Systems Architecture", "Data Security & Governance", "Program Management",
        "Technology Implementation & Deployment", "Legal & Regulatory Compliance", "Risk Management"
    ],
    experience: [
        {
            company: "HyperCore Cyber Security LLC",
            location: "Virginia",
            title: "Founder, CEO & AI Engineer",
            dates: "September 2025 – Present",
            responsibilities: [
                "Architected and developed an AI-driven platform to automate CMMC Level 2 compliance, reducing documentation and assessment time by over 90%.",
                "Engineered an AI-driven RAG pipeline using advanced language models to interpret and apply complex federal regulations to specific contractor environments.",
                "Translated complex federal regulations (NIST SP 800-171, CMMC 2.0) into automated, actionable compliance workflows and machine-readable policies.",
                "Authored comprehensive market analysis and go-to-market strategy, securing dozens of Letters of Intent from defense contractors, validating urgent market need."
            ]
        },
        {
            company: "Government Education Sector Technology & Compliance",
            location: "Virginia",
            title: "Senior Technology & Compliance Strategist",
            dates: "2001 – 2025",
            responsibilities: [
                "Oversaw the implementation and continuous monitoring of federally mandated compliance programs (e.g., related to Individualized Education Plans) across multiple agencies.",
                "Deployed and monitored secure data tracking systems on government networks to ensure compliance with federal regulations, data privacy, and security protocols.",
                "Authored and enforced policies based on deep analysis of federal regulations, serving as the subject matter expert for technology-supported compliance implementation.",
                "Pioneered the use of emerging technology to automate data collection, streamline documentation for legal audits, and improve the delivery of equitable support services.",
                "Managed the full lifecycle of technology solutions, from development and deployment to user support and continuous improvement, ensuring robust system uptime and data integrity."
            ]
        }
    ],
    education: [
        {
            institution: "Regent University",
            location: "Virginia Beach, VA",
            degree: "Master of Education (M.Ed.), Educational Technology",
            description: "Focus on leveraging technology to improve systems, training, and operational efficiency."
        },
        {
            institution: "Regent University",
            location: "Virginia Beach, VA",
            degree: "Master of Arts (M.A.), Government",
            description: "Focus on public policy, federal regulations, and government operations."
        }
    ],
    technicalProficiencies: [
        "AI/ML: LangChain, RAG Pipelines, Vector Databases (Pinecone), OpenAI API",
        "Cloud: AWS GovCloud, Lambda, DynamoDB, S3",
        "Languages: Python, JavaScript",
        "Frameworks: React, Node.js",
        "DevOps: Git, Docker, CI/CD"
    ]
};

export default function KeyPersonnelResume() {
    return (
        <div className="bg-gray-50 p-4 md:p-8">
            <BreadcrumbNav currentPageName="KeyPersonnelResume" />
            <Card className="max-w-4xl mx-auto my-8">
                <CardHeader className="bg-gray-100 p-6">
                    <div className="flex flex-col sm:flex-row justify-between items-start">
                        <div>
                            <h1 className="text-4xl font-bold text-gray-900">{resumeData.name}</h1>
                            <p className="text-xl text-blue-600 font-medium">{resumeData.title}</p>
                        </div>
                        <div className="text-sm text-gray-600 mt-4 sm:mt-0 sm:text-right">
                            <p className="flex items-center justify-end gap-2"><Mail className="w-4 h-4" /> {resumeData.contact.email}</p>
                            <p className="flex items-center justify-end gap-2"><Linkedin className="w-4 h-4" /> {resumeData.contact.linkedin}</p>
                        </div>
                    </div>
                </CardHeader>
                <CardContent className="p-6 space-y-8">
                    <section>
                        <h2 className="text-lg font-semibold border-b pb-2 mb-3">PROFESSIONAL SUMMARY</h2>
                        <p className="text-gray-700">{resumeData.summary}</p>
                    </section>
                    
                    <section>
                        <h2 className="text-lg font-semibold border-b pb-2 mb-3">CORE COMPETENCIES</h2>
                        <div className="flex flex-wrap gap-2">
                            {resumeData.coreCompetencies.map(skill => <Badge key={skill} variant="secondary">{skill}</Badge>)}
                        </div>
                    </section>

                    <section>
                        <h2 className="text-lg font-semibold border-b pb-2 mb-3 flex items-center gap-2"><Briefcase /> PROFESSIONAL EXPERIENCE</h2>
                        <div className="space-y-6">
                            {resumeData.experience.map(job => (
                                <div key={job.title}>
                                    <div className="flex justify-between items-baseline">
                                        <h3 className="font-bold text-base">{job.title}</h3>
                                        <p className="text-sm text-gray-500">{job.dates}</p>
                                    </div>
                                    <p className="text-sm font-medium text-gray-700">{job.company} | {job.location}</p>
                                    <ul className="list-disc list-inside mt-2 space-y-1 text-sm text-gray-600">
                                        {job.responsibilities.map((resp, i) => <li key={i}>{resp}</li>)}
                                    </ul>
                                </div>
                            ))}
                        </div>
                    </section>

                    <section>
                        <h2 className="text-lg font-semibold border-b pb-2 mb-3 flex items-center gap-2"><GraduationCap /> EDUCATION</h2>
                        <div className="space-y-4">
                            {resumeData.education.map(edu => (
                                <div key={edu.degree}>
                                    <h3 className="font-bold">{edu.degree}</h3>
                                    <p className="text-sm text-gray-700">{edu.institution} | {edu.location}</p>
                                    <p className="text-xs text-gray-500 italic mt-1">{edu.description}</p>
                                </div>
                            ))}
                        </div>
                    </section>
                    
                     <section>
                        <h2 className="text-lg font-semibold border-b pb-2 mb-3 flex items-center gap-2"><Code /> TECHNICAL PROFICIENCIES</h2>
                        <div className="flex flex-wrap gap-2">
                            {resumeData.technicalProficiencies.map(tech => <Badge key={tech} variant="outline">{tech}</Badge>)}
                        </div>
                    </section>
                </CardContent>
            </Card>
        </div>
    );
}