
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Gavel, Shield, Info, CheckCircle, Award } from 'lucide-react';
import { motion } from "framer-motion";

export default function LegalPage() {
    const legalPoints = [
        {
            title: "Scope of Service: Training and Guidance, Not Certification",
            content: "HyperCore CMMC Training, LLC provides CMMC preparation training, guidance, and educational services. Our role is to train your team and provide implementation guidance to help prepare for an official CMMC assessment. We are not a Certified Third-Party Assessment Organization (C3PAO) and DO NOT conduct official audits, assessments, or grant certifications."
        },
        {
            title: "Client Implementation Responsibilities",
            content: "The success of our training program is contingent upon your team's implementation of the guidance provided. This includes designating technical personnel, implementing recommended controls, and completing all implementation tasks. Our role is limited to training and guidance - your team must perform the actual implementation work."
        },
        {
            title: "Limitation of Liability",
            content: "Our liability is limited to the fees paid for the training services rendered. We are not responsible for any direct or indirect damages, loss of contracts, assessment outcomes, or other business impacts resulting from C3PAO assessment results or implementation decisions made by your team."
        }
    ];

    const guaranteeText = `**90-Day Money-Back Satisfaction Guarantee**
HyperCore CMMC Training, LLC ("HyperCore") offers a 100% money-back satisfaction guarantee for fees paid within 90 days from purchase, provided Client completes 80% of the 90-Day Success Plan milestones, verified by audit logs from api.hypercorecyber.com/v1/analyzer. Client must submit a written dissatisfaction claim within 90 days, detailing platform engagement. Refunds exclude dissatisfaction due to Client errors or non-implementation. HyperCore is not a C3PAO and does not conduct CMMC assessments, audits, or certifications. Refunds are capped at 10% of HyperCore's monthly revenue. Clients must sign this MSA to activate the guarantee.

**Client Finalization Clause**
Client is solely responsible for reviewing, customizing, finalizing, and submitting all AI-generated materials (e.g., SSP, POA&M) to any government entity or C3PAO. HyperCore is not liable for client modifications, submissions, or resulting FCA claims.`;

    return (
        <div className="min-h-screen bg-gray-50 p-4 sm:p-6 lg:p-8">
            <div className="max-w-4xl mx-auto">
                <motion.div 
                    className="text-center mb-12"
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                >
                    <Gavel className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                    <h1 className="text-4xl font-bold text-gray-900 mb-2">Legal Terms & Service Guarantee</h1>
                    <p className="text-lg text-gray-600">Our commitment to transparency and your success.</p>
                </motion.div>

                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1, transition: { delay: 0.2 } }}>
                    <Card className="mb-8 border-blue-300 bg-gradient-to-r from-blue-50 to-indigo-50 shadow-lg">
                        <CardHeader>
                            <CardTitle className="flex items-center gap-3 text-blue-900">
                                <Award className="w-6 h-6" />
                                Official 90-Day Satisfaction Guarantee (MSA Clause)
                            </CardTitle>
                             <CardDescription className="text-blue-800">
                                This is the official Master Service Agreement (MSA) language for our risk-free training guarantee.
                            </CardDescription>
                        </CardHeader>
                        <CardContent>
                            <pre className="text-sm text-gray-800 whitespace-pre-wrap leading-relaxed font-sans p-4 bg-white/50 rounded-md">{guaranteeText}</pre>
                        </CardContent>
                    </Card>
                </motion.div>

                <div className="space-y-6">
                    {legalPoints.map((point, index) => (
                        <motion.div
                            key={index}
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: 0.4 + index * 0.1 }}
                        >
                            <Card>
                                <CardHeader>
                                    <CardTitle className="flex items-center gap-3">
                                        <Shield className="w-5 h-5 text-gray-500" />
                                        {point.title}
                                    </CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <p className="text-gray-700 leading-relaxed">{point.content}</p>
                                </CardContent>
                            </Card>
                        </motion.div>
                    ))}
                </div>
            </div>
        </div>
    );
}
