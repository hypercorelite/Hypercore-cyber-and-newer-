import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Mail, Upload, Rocket, Loader2, BarChart, FileText, Users } from 'lucide-react';
import { toast } from 'sonner';
import { sendEngagementEmail } from '@/api/functions';
import BreadcrumbNav from '../components/navigation/BreadcrumbNav';

export default function PartnershipEmailCampaign() {
    const [subject, setSubject] = useState("100% CMMC Level 3 Accuracy—Cut $50K Costs to $2K");
    const [body, setBody] = useState(`Hi {Name},

CMMC compliance costs are approaching $50,000 for most SMBs.

Our AI platform just achieved 100% accuracy on all 130 CMMC Level 3 controls in a live validation test. We deliver full compliance in 87 days for a fraction of the cost.

Unlike Vanta (85% accuracy) or Drata (80%), our platform guarantees its results.

Would you be open to a 15-minute demo next week to see how we can save you over $30,000?

Best,
The HyperCore Team`);
    const [recipients, setRecipients] = useState("");
    const [isSending, setIsSending] = useState(false);

    const handleFileChange = (event) => {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (e) => {
                const text = e.target.result;
                // Assuming CSV with a header, and emails in a column named 'email'
                const lines = text.split('\n');
                const header = lines[0].split(',').map(h => h.trim().toLowerCase());
                const emailIndex = header.indexOf('email');
                
                if (emailIndex === -1) {
                    toast.error("CSV must have an 'email' column.");
                    return;
                }

                const emails = lines.slice(1)
                    .map(line => line.split(',')[emailIndex]?.trim())
                    .filter(email => email)
                    .join(', ');
                setRecipients(emails);
                toast.success(`${lines.length - 1} contacts imported successfully.`);
            };
            reader.readAsText(file);
        }
    };

    const handleSendCampaign = async () => {
        const emailList = recipients.split(',').map(e => e.trim()).filter(e => e);
        if (emailList.length === 0) {
            toast.warning("Please provide at least one recipient email.");
            return;
        }

        setIsSending(true);
        toast.info(`Sending campaign to ${emailList.length} recipients...`);

        try {
            const { data } = await sendEngagementEmail({
                to: emailList,
                subject,
                html: body.replace(/\n/g, '<br>')
            });

            if (data.success) {
                toast.success(data.message);
            } else {
                throw new Error(data.error || "An unknown error occurred.");
            }
        } catch (error) {
            toast.error(`Campaign failed: ${error.message}`);
        } finally {
            setIsSending(false);
        }
    };

    return (
        <div className="space-y-6">
            <BreadcrumbNav currentPageName="PartnershipEmailCampaign" />
            <div className="text-center">
                <h1 className="text-3xl font-bold text-gray-900 flex items-center justify-center gap-3">
                    <Rocket className="w-8 h-8 text-purple-600" />
                    SMB CMMC Breakthrough Campaign
                </h1>
                <p className="text-lg text-gray-600 mt-2">
                    Launch email campaigns to SMB subcontractors highlighting your 100% accuracy advantage.
                </p>
            </div>
            
            <div className="grid md:grid-cols-3 gap-4">
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2"><BarChart className="text-blue-600"/> Campaign Stats</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p><strong>Audience Size:</strong> {recipients.split(',').filter(e => e).length}</p>
                        <p><strong>Est. Open Rate:</strong> 25%</p>
                        <p><strong>Est. Trial Conversions:</strong> {(recipients.split(',').filter(e => e).length * 0.1).toFixed(0)}</p>
                    </CardContent>
                </Card>
                 <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2"><FileText className="text-green-600"/> Key Messaging</CardTitle>
                    </CardHeader>
                    <CardContent className="text-sm space-y-1">
                        <p>✓ 100% CMMC Level 3 Accuracy</p>
                        <p>✓ Cut $50K Costs to $2K</p>
                        <p>✓ 87 Days to Compliance</p>
                    </CardContent>
                </Card>
                 <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2"><Users className="text-yellow-600"/> Target Audience</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p>NoVA SMB Subcontractors</p>
                        <p className="text-sm text-gray-500">(e.g., from Virginia Cyber Partnership lists)</p>
                    </CardContent>
                </Card>
            </div>

            <Card>
                <CardHeader>
                    <CardTitle>Campaign Composer</CardTitle>
                    <CardDescription>
                        Load your recipient list via CSV, customize the template, and launch the campaign.
                    </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div>
                        <Label htmlFor="recipients">Recipients (CSV or comma-separated)</Label>
                        <div className="flex gap-2 mt-1">
                            <Textarea
                                id="recipients"
                                placeholder="example1@company.com, example2@company.com..."
                                value={recipients}
                                onChange={(e) => setRecipients(e.target.value)}
                                className="flex-grow"
                            />
                            <Button asChild variant="outline" className="h-auto">
                                <Label htmlFor="csv-upload" className="cursor-pointer flex items-center gap-2">
                                    <Upload className="w-4 h-4" /> Upload CSV
                                </Label>
                            </Button>
                            <Input id="csv-upload" type="file" accept=".csv" className="hidden" onChange={handleFileChange} />
                        </div>
                    </div>
                    <div>
                        <Label htmlFor="subject">Subject</Label>
                        <Input
                            id="subject"
                            value={subject}
                            onChange={(e) => setSubject(e.target.value)}
                        />
                    </div>
                    <div>
                        <Label htmlFor="body">Body</Label>
                        <Textarea
                            id="body"
                            value={body}
                            onChange={(e) => setBody(e.target.value)}
                            rows={12}
                        />
                    </div>
                    <Button onClick={handleSendCampaign} disabled={isSending} size="lg">
                        {isSending ? <Loader2 className="w-5 h-5 animate-spin mr-2" /> : <Mail className="w-5 h-5 mr-2" />}
                        Launch Campaign to {recipients.split(',').filter(e => e).length} Recipients
                    </Button>
                </CardContent>
            </Card>
        </div>
    );
}