
import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Network as SitemapIcon, FileText, BookOpen, Home, Layers, GanttChartSquare, Award, HelpCircle, Rocket } from 'lucide-react';

export default function Sitemap() {
    const mainPages = [
        { name: 'Home', href: createPageUrl('Home'), icon: Home },
        { name: 'How We\'re Different', href: createPageUrl('CompetitiveComparison'), icon: Layers },
        { name: '90-Day Success Plan', href: createPageUrl('SuccessPlan'), icon: GanttChartSquare },
        { name: 'Customer Stories', href: createPageUrl('CustomerSuccessStories'), icon: Award },
        { name: 'Resource Center', href: createPageUrl('Resources'), icon: BookOpen },
        { name: 'Knowledge Hub', href: createPageUrl('KnowledgeHub'), icon: BookOpen },
        { name: 'SBIR Marketing', href: createPageUrl('SBIRPublicMarketing'), icon: Rocket },
        { name: 'FAQ', href: createPageUrl('ClientFAQ'), icon: HelpCircle }
    ];

    const articlePages = [
        { name: 'The SMB Playbook for CMMC Compliance', href: createPageUrl('BlogPost?slug=the-smb-playbook-for-cmmc-compliance') },
        { name: 'Fixing CMMC Flow-Down Errors for Primes', href: createPageUrl('BlogPost?slug=fixing-cmmc-flow-down-errors-for-primes') },
        { name: 'Automating DFARS 7012 in 2025', href: createPageUrl('BlogPost?slug=automating-dfars-7012-in-2025') }
    ];
    
    const legalPages = [
        { name: 'Legal Terms & Conditions', href: createPageUrl('Legal') },
        { name: 'Help Center', href: createPageUrl('HelpCenter') },
        { name: 'Admin Portal', href: createPageUrl('Admin') }
    ];

    return (
        <div className="container mx-auto py-12 px-4">
            <header className="text-center mb-12">
                <SitemapIcon className="mx-auto h-12 w-12 text-blue-600 mb-4" />
                <h1 className="text-4xl font-extrabold text-gray-900">Sitemap</h1>
                <p className="mt-2 text-lg text-gray-600">An overview of our platform's pages and resources.</p>
            </header>

            <div className="grid md:grid-cols-3 gap-8">
                <Card>
                    <CardHeader><CardTitle>Main Pages</CardTitle></CardHeader>
                    <CardContent className="space-y-2">
                        {mainPages.map(page => (
                            <Link key={page.name} to={page.href} className="flex items-center gap-3 p-2 rounded hover:bg-gray-100">
                                <page.icon className="w-5 h-5 text-gray-500" />
                                <span className="font-medium text-gray-800">{page.name}</span>
                            </Link>
                        ))}
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader><CardTitle>Knowledge Hub Articles</CardTitle></CardHeader>
                    <CardContent className="space-y-2">
                        {articlePages.map(page => (
                            <Link key={page.name} to={page.href} className="flex items-center gap-3 p-2 rounded hover:bg-gray-100">
                                <FileText className="w-5 h-5 text-gray-500" />
                                <span className="font-medium text-gray-800">{page.name}</span>
                            </Link>
                        ))}
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader><CardTitle>Legal & Support</CardTitle></CardHeader>
                    <CardContent className="space-y-2">
                        {legalPages.map(page => (
                            <Link key={page.name} to={page.href} className="flex items-center gap-3 p-2 rounded hover:bg-gray-100">
                                <SitemapIcon className="w-5 h-5 text-gray-500" />
                                <span className="font-medium text-gray-800">{page.name}</span>
                            </Link>
                        ))}
                    </CardContent>
                </Card>
            </div>
            
            <div className="text-center mt-12">
                 <Button asChild>
                    <a href="/sitemap.xml" target="_blank" rel="noopener noreferrer">
                        View XML Sitemap for Search Engines
                    </a>
                </Button>
            </div>
        </div>
    );
}
