import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { AuditLog } from "@/api/entities";
import { TestingLog } from "@/api/entities";
import { History, Search, FileText, FlaskConical, AlertTriangle, CheckCircle } from 'lucide-react';
import { motion } from "framer-motion";

const LogViewer = ({ logs, type }) => {
    if (!logs || logs.length === 0) {
        return <div className="text-center py-10 text-gray-500">No logs found for this category.</div>;
    }

    const renderDetails = (details) => {
        try {
            const parsed = JSON.parse(details);
            return <pre className="text-xs bg-gray-100 p-2 rounded-md overflow-x-auto">{JSON.stringify(parsed, null, 2)}</pre>;
        } catch {
            return <p className="text-xs">{details}</p>;
        }
    };

    return (
        <div className="space-y-3 max-h-[600px] overflow-y-auto pr-2">
            {logs.map(log => (
                <motion.div 
                    key={log.id} 
                    className="border rounded-lg p-4 bg-white"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                >
                    {type === 'system' && (
                        <div>
                            <div className="flex justify-between items-center mb-2">
                                <div className="font-semibold text-gray-800 flex items-center gap-2">
                                    {log.status === 'SUCCESS' ? <CheckCircle className="w-4 h-4 text-green-500" /> : <AlertTriangle className="w-4 h-4 text-red-500" />}
                                    {log.event_name}
                                </div>
                                <Badge variant={log.status === 'SUCCESS' ? 'default' : 'destructive'}>{log.status}</Badge>
                            </div>
                            <div className="text-sm text-gray-600">User: {log.user_email}</div>
                            <div className="text-xs text-gray-400">Timestamp: {new Date(log.created_date).toLocaleString()}</div>
                            <div className="mt-2">
                                <h4 className="text-xs font-semibold mb-1">Details:</h4>
                                {renderDetails(log.details)}
                            </div>
                        </div>
                    )}
                    {type === 'testing' && (
                         <div>
                            <div className="flex justify-between items-center mb-2">
                                <div className="font-semibold text-gray-800 flex items-center gap-2">
                                    <FlaskConical className="w-4 h-4 text-blue-500" />
                                    {log.test_name} ({log.test_type.replace('_', ' ')})
                                </div>
                                <Badge variant={log.status === 'SUCCESS' ? 'default' : 'destructive'}>{log.status}</Badge>
                            </div>
                            <div className="text-sm text-gray-600">Run by: {log.run_by}</div>
                            <div className="text-xs text-gray-400">Timestamp: {new Date(log.created_date).toLocaleString()}</div>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-2">
                                <div>
                                    <h4 className="text-xs font-semibold mb-1">Parameters:</h4>
                                    {renderDetails(log.parameters)}
                                </div>
                                <div>
                                    <h4 className="text-xs font-semibold mb-1">Results Summary:</h4>
                                    {renderDetails(log.results_summary)}
                                </div>
                            </div>
                        </div>
                    )}
                </motion.div>
            ))}
        </div>
    );
};

export default function AuditTrailDashboard() {
    const [systemLogs, setSystemLogs] = useState([]);
    const [testingLogs, setTestingLogs] = useState([]);
    const [searchTerm, setSearchTerm] = useState("");
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        loadLogs();
    }, []);

    const loadLogs = async () => {
        setLoading(true);
        try {
            const [systemData, testingData] = await Promise.all([
                AuditLog.list('-created_date', 100),
                TestingLog.list('-created_date', 100)
            ]);
            setSystemLogs(systemData);
            setTestingLogs(testingData);
        } catch (error) {
            console.error("Failed to load audit logs:", error);
        } finally {
            setLoading(false);
        }
    };
    
    const filterLogs = (logs, term) => {
        if (!term) return logs;
        const lowercasedTerm = term.toLowerCase();
        return logs.filter(log => 
            Object.values(log).some(val => 
                String(val).toLowerCase().includes(lowercasedTerm)
            )
        );
    };

    return (
        <div className="min-h-screen bg-gradient-to-br from-gray-50 to-slate-100 p-6">
            <div className="max-w-7xl mx-auto">
                <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
                    <h1 className="text-4xl font-bold text-gray-900 mb-2 flex items-center gap-3">
                        <History className="w-10 h-10 text-slate-600" />
                        Audit Trail Command Center
                    </h1>
                    <p className="text-lg text-gray-600">
                        Comprehensive and immutable logs for testing, documentation, and system events.
                    </p>
                </motion.div>

                <Card>
                    <CardHeader>
                        <div className="flex justify-between items-center">
                            <CardTitle>Log Explorer</CardTitle>
                            <div className="relative w-1/3">
                                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                                <Input 
                                    placeholder="Search all logs..." 
                                    className="pl-10"
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                />
                            </div>
                        </div>
                    </CardHeader>
                    <CardContent>
                        <Tabs defaultValue="system">
                            <TabsList>
                                <TabsTrigger value="system">
                                    <CheckCircle className="w-4 h-4 mr-2" />
                                    System Events ({filterLogs(systemLogs, searchTerm).length})
                                </TabsTrigger>
                                <TabsTrigger value="testing">
                                    <FlaskConical className="w-4 h-4 mr-2" />
                                    Testing Logs ({filterLogs(testingLogs, searchTerm).length})
                                </TabsTrigger>
                            </TabsList>
                            <TabsContent value="system" className="pt-4">
                                <LogViewer logs={filterLogs(systemLogs, searchTerm)} type="system" />
                            </TabsContent>
                            <TabsContent value="testing" className="pt-4">
                                <LogViewer logs={filterLogs(testingLogs, searchTerm)} type="testing" />
                            </TabsContent>
                        </Tabs>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}