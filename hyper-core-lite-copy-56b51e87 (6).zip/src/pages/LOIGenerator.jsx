
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { submitLOI } from "@/api/functions";
import { toast } from "sonner";
import { FileSignature, Loader2, Download } from "lucide-react";
import { jsPDF } from 'jspdf';

export default function LOIGenerator() {
    const [formData, setFormData] = useState({
        companyName: '',
        cageCode: '',
        uei: '',
        contractNumbers: '',
        repName: '',
        repTitle: '',
        repEmail: '',
        commitmentLevel: 'Pilot Participant (Phase I Beta, Free)',
        intentStatement: 'As a DoD contractor, we intend to use HyperCore Cyber\'s AI platform to prepare for CMMC Level 2 compliance, including SSP generation, policy development, and 3PAO audit readiness, to meet DFARS 252.204-7021 requirements.',
        likeFeedback: '',
        loveFeedback: '',
        improveFeedback: '',
        priorityFeatures: 'Automated SSP Generation',
        signatureName: '',
        signatureDate: new Date().toISOString().split('T')[0],
        digitalSignatureConsent: false
    });

    const [isSubmitting, setIsSubmitting] = useState(false);

    const handleInputChange = (field, value) => {
        setFormData(prev => ({ ...prev, [field]: value }));
    };

    const validateForm = () => {
        const required = ['companyName', 'cageCode', 'uei', 'repName', 'repTitle', 'repEmail', 'signatureName'];
        const missing = required.filter(field => !formData[field]);
        
        if (missing.length > 0) {
            toast.error(`Please fill in: ${missing.join(', ')}`);
            return false;
        }
        
        if (!formData.digitalSignatureConsent) {
            toast.error('Digital signature consent is required');
            return false;
        }
        
        return true;
    };

    const generatePdf = () => {
        if (!validateForm()) return;

        const doc = new jsPDF();
        
        // Header
        doc.setFontSize(18);
        doc.text('Letter of Intent', 20, 20);
        doc.setFontSize(12);
        doc.text('HyperCore Cyber CMMC Compliance Platform', 20, 30);
        doc.text(`Date: ${formData.signatureDate}`, 20, 40);
        
        // Company Information
        doc.setFontSize(14);
        doc.text('Company Information', 20, 60);
        doc.setFontSize(10);
        doc.text(`Company Name: ${formData.companyName}`, 20, 70);
        doc.text(`CAGE Code: ${formData.cageCode}`, 20, 80);
        doc.text(`UEI: ${formData.uei}`, 20, 90);
        
        // Intent Statement
        doc.setFontSize(14);
        doc.text('Letter of Intent', 20, 110);
        doc.setFontSize(10);
        const intentLines = doc.splitTextToSize(formData.intentStatement, 170);
        doc.text(intentLines, 20, 120);
        
        // Signature
        doc.setFontSize(12);
        doc.text('Digital Signature:', 20, 200);
        doc.text(formData.signatureName, 20, 210);
        doc.text(`Date: ${formData.signatureDate}`, 20, 220);
        
        doc.save(`LOI_${formData.companyName.replace(/\s+/g, '_')}.pdf`);
    };

    const handleSubmit = async () => {
        if (!validateForm()) return;
        
        setIsSubmitting(true);
        try {
            await submitLOI(formData);
            toast.success('LOI submitted successfully! This data will strengthen our SBIR proposal.');
            
            // Generate PDF after successful submission
            generatePdf();
            
            // Reset form
            setFormData({
                companyName: '', cageCode: '', uei: '', contractNumbers: '',
                repName: '', repTitle: '', repEmail: '',
                commitmentLevel: 'Pilot Participant (Phase I Beta, Free)',
                intentStatement: 'As a DoD contractor, we intend to use HyperCore Cyber\'s AI platform to prepare for CMMC Level 2 compliance, including SSP generation, policy development, and 3PAO audit readiness, to meet DFARS 252.204-7021 requirements.',
                likeFeedback: '', loveFeedback: '', improveFeedback: '',
                priorityFeatures: 'Automated SSP Generation',
                signatureName: '', signatureDate: new Date().toISOString().split('T')[0],
                digitalSignatureConsent: false
            });
            
        } catch (error) {
            toast.error('Submission failed. Check console for details.');
            console.error("LOI Submission Error:", error);
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <div className="max-w-4xl mx-auto p-6 space-y-8">
            <Card className="border-blue-200 bg-gradient-to-r from-blue-50 to-indigo-50">
                <CardHeader>
                    <CardTitle className="flex items-center gap-3 text-blue-900">
                        <FileSignature className="w-8 h-8" />
                        Executive Letter of Intent Generator
                    </CardTitle>
                    <p className="text-blue-700">For DoD contractors committing to HyperCore Cyber's CMMC AI Platform</p>
                </CardHeader>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>Contractor Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="grid md:grid-cols-2 gap-4">
                        <div>
                            <Label>Company Name *</Label>
                            <Input 
                                value={formData.companyName}
                                onChange={(e) => handleInputChange('companyName', e.target.value)}
                                placeholder="Enter your company name"
                            />
                        </div>
                        <div>
                            <Label>CAGE Code *</Label>
                            <Input 
                                value={formData.cageCode}
                                onChange={(e) => handleInputChange('cageCode', e.target.value)}
                                placeholder="Enter CAGE Code (e.g., 1ABC2)"
                            />
                        </div>
                        <div>
                            <Label>UEI *</Label>
                            <Input 
                                value={formData.uei}
                                onChange={(e) => handleInputChange('uei', e.target.value)}
                                placeholder="Enter UEI"
                            />
                        </div>
                        <div>
                            <Label>DoD Contract Numbers</Label>
                            <Input 
                                value={formData.contractNumbers}
                                onChange={(e) => handleInputChange('contractNumbers', e.target.value)}
                                placeholder="List relevant DoD contracts"
                            />
                        </div>
                    </div>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>Authorized Representative</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="grid md:grid-cols-3 gap-4">
                        <div>
                            <Label>Full Name *</Label>
                            <Input 
                                value={formData.repName}
                                onChange={(e) => handleInputChange('repName', e.target.value)}
                                placeholder="Enter full name"
                            />
                        </div>
                        <div>
                            <Label>Title *</Label>
                            <Input 
                                value={formData.repTitle}
                                onChange={(e) => handleInputChange('repTitle', e.target.value)}
                                placeholder="Enter title"
                            />
                        </div>
                        <div>
                            <Label>Email *</Label>
                            <Input 
                                type="email"
                                value={formData.repEmail}
                                onChange={(e) => handleInputChange('repEmail', e.target.value)}
                                placeholder="Enter email"
                            />
                        </div>
                    </div>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>Platform Commitment</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div>
                        <Label>Commitment Level</Label>
                        <Select value={formData.commitmentLevel} onValueChange={(value) => handleInputChange('commitmentLevel', value)}>
                            <SelectTrigger>
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="Pilot Participant (Phase I Beta, Free)">Pilot Participant (Phase I Beta, Free)</SelectItem>
                                <SelectItem value="Early Adopter (Post-Phase I, Freemium)">Early Adopter (Post-Phase I, Freemium)</SelectItem>
                                <SelectItem value="Paid Subscriber ($99/month Post-Phase II)">Paid Subscriber ($99/month Post-Phase II)</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                    <div>
                        <Label>Intent Statement</Label>
                        <Textarea 
                            value={formData.intentStatement}
                            onChange={(e) => handleInputChange('intentStatement', e.target.value)}
                            rows={4}
                        />
                    </div>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>Platform Feedback</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div>
                        <Label>What You Like</Label>
                        <Textarea 
                            value={formData.likeFeedback}
                            onChange={(e) => handleInputChange('likeFeedback', e.target.value)}
                            placeholder="Describe features you like"
                            rows={3}
                        />
                    </div>
                    <div>
                        <Label>What You Love</Label>
                        <Textarea 
                            value={formData.loveFeedback}
                            onChange={(e) => handleInputChange('loveFeedback', e.target.value)}
                            placeholder="Highlight standout features"
                            rows={3}
                        />
                    </div>
                    <div>
                        <Label>What to Improve</Label>
                        <Textarea 
                            value={formData.improveFeedback}
                            onChange={(e) => handleInputChange('improveFeedback', e.target.value)}
                            placeholder="Suggest enhancements"
                            rows={3}
                        />
                    </div>
                    <div>
                        <Label>Top Priority Feature</Label>
                        <Select value={formData.priorityFeatures} onValueChange={(value) => handleInputChange('priorityFeatures', value)}>
                            <SelectTrigger>
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="Automated SSP Generation">Automated SSP Generation</SelectItem>
                                <SelectItem value="Policy and Procedure Templates">Policy and Procedure Templates</SelectItem>
                                <SelectItem value="110-Control Mapping and Scoring">110-Control Mapping and Scoring</SelectItem>
                                <SelectItem value="POA&M and SPRS Reporting">POA&M and SPRS Reporting</SelectItem>
                                <SelectItem value="Implementation Guidance">Implementation Guidance</SelectItem>
                                <SelectItem value="Mock 3PAO Audit Simulator">Mock 3PAO Audit Simulator</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>Digital Signature</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="grid md:grid-cols-2 gap-4">
                        <div>
                            <Label>Signature Name *</Label>
                            <Input 
                                value={formData.signatureName}
                                onChange={(e) => handleInputChange('signatureName', e.target.value)}
                                placeholder="Type your full name to sign"
                            />
                        </div>
                        <div>
                            <Label>Date *</Label>
                            <Input 
                                type="date"
                                value={formData.signatureDate}
                                onChange={(e) => handleInputChange('signatureDate', e.target.value)}
                            />
                        </div>
                    </div>
                    <div className="flex items-center space-x-2">
                        <Checkbox 
                            id="digitalSignatureConsent"
                            checked={formData.digitalSignatureConsent}
                            onCheckedChange={(checked) => handleInputChange('digitalSignatureConsent', checked)}
                        />
                        <Label htmlFor="digitalSignatureConsent" className="text-sm">
                            I agree to the terms and consent to this digital signature. *
                        </Label>
                    </div>
                </CardContent>
            </Card>

            <div className="flex gap-4 justify-center">
                <Button 
                    onClick={generatePdf}
                    variant="outline"
                    disabled={isSubmitting}
                >
                    <Download className="w-4 h-4 mr-2" />
                    Preview PDF
                </Button>
                <Button 
                    onClick={handleSubmit}
                    disabled={isSubmitting}
                    className="bg-blue-600 hover:bg-blue-700"
                >
                    {isSubmitting ? (
                        <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Submitting...</>
                    ) : (
                        <>Submit LOI & Generate Evidence</>
                    )}
                </Button>
            </div>
        </div>
    );
}
