import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import BreadcrumbNav from '../components/navigation/BreadcrumbNav';
import { Calendar, Download, CheckSquare, Layers, Shield } from 'lucide-react';
import { jsPDF } from 'jspdf';
import 'jspdf-autotable';

const timelineTemplate = {
    'Phase 1: Foundation (Weeks 1-4)': [
        'Perform Gap Assessment & Create POA&M',
        'Define CUI System Boundaries',
        'Draft Core Policies (AC, AU, IR, SC)',
        'Implement Basic Access Controls (AC.L2-3.1.1)',
        'Setup Security Awareness Training Program (AT.L2-3.2.3)'
    ],
    'Phase 2: Technical Implementation (Weeks 5-8)': [
        'Deploy Multifactor Authentication (IA.L2-3.5.3)',
        'Configure Centralized Logging/SIEM (AU.L2-3.3.1)',
        'Implement Endpoint Detection & Response (EDR)',
        'Enforce Mobile Device Encryption (AC.L2-3.1.19)',
        'Configure Network Firewalls and Segmentation (SC.L2-3.13.1)'
    ],
    'Phase 3: Review & Refine (Weeks 9-12)': [
        'Conduct Internal Audit & Review Evidence',
        'Perform Vulnerability Scanning & Penetration Testing',
        'Finalize System Security Plan (SSP)',
        'Train Personnel on Incident Response Plan (IR.L2-3.6.1)',
        'Prepare for C3PAO Assessment'
    ]
};

export default function ImplementationTimeline() {
    const [companySize, setCompanySize] = useState('11-50');
    const [complexity, setComplexity] = useState('Medium');

    const generatePdf = () => {
        const doc = new jsPDF();
        
        doc.setFontSize(18);
        doc.text('CMMC Implementation Timeline', 20, 20);
        doc.setFontSize(12);
        doc.text(`Company Size: ${companySize} employees`, 20, 30);
        doc.text(`Complexity: ${complexity}`, 20, 40);

        let yPos = 50;
        Object.entries(timelineTemplate).forEach(([phase, tasks]) => {
            if (yPos > 250) {
                doc.addPage();
                yPos = 20;
            }
            doc.setFontSize(14);
            doc.text(phase, 20, yPos);
            yPos += 10;
            
            doc.setFontSize(10);
            tasks.forEach(task => {
                doc.text(`- ${task}`, 25, yPos);
                yPos += 7;
            });
            yPos += 5;
        });

        doc.save('CMMC_Implementation_Timeline.pdf');
    };

    return (
        <div className="space-y-6">
            <BreadcrumbNav currentPageName="ImplementationTimeline" />
            
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                        <Calendar className="w-6 h-6 text-blue-600" />
                        SMB Implementation Timeline Generator
                    </CardTitle>
                    <CardDescription>
                        Generate a customized 12-week project plan to guide your CMMC compliance journey, broken down into manageable phases and tasks.
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="grid md:grid-cols-3 gap-4 mb-6">
                        <div>
                            <label className="text-sm font-medium">Company Size</label>
                            <select value={companySize} onChange={e => setCompanySize(e.target.value)} className="w-full mt-1 p-2 border rounded-md">
                                <option>1-10</option>
                                <option>11-50</option>
                                <option>51-200</option>
                            </select>
                        </div>
                        <div>
                            <label className="text-sm font-medium">System Complexity</label>
                             <select value={complexity} onChange={e => setComplexity(e.target.value)} className="w-full mt-1 p-2 border rounded-md">
                                <option>Low</option>
                                <option>Medium</option>
                                <option>High</option>
                            </select>
                        </div>
                        <div className="self-end">
                            <Button onClick={generatePdf} className="w-full flex items-center gap-2">
                                <Download className="w-4 h-4" />
                                Export Timeline PDF
                            </Button>
                        </div>
                    </div>

                    <div className="space-y-6">
                        {Object.entries(timelineTemplate).map(([phase, tasks]) => (
                            <Card key={phase}>
                                <CardHeader>
                                    <CardTitle className="flex items-center gap-2">
                                        {phase.includes('Foundation') && <Layers className="w-5 h-5 text-gray-600" />}
                                        {phase.includes('Implementation') && <Shield className="w-5 h-5 text-gray-600" />}
                                        {phase.includes('Review') && <CheckSquare className="w-5 h-5 text-gray-600" />}
                                        {phase}
                                    </CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <ul className="space-y-3">
                                        {tasks.map(task => (
                                            <li key={task} className="flex items-center gap-3 text-sm">
                                                <div className="w-5 h-5 bg-gray-200 rounded-full flex-shrink-0" />
                                                <span>{task}</span>
                                            </li>
                                        ))}
                                    </ul>
                                </CardContent>
                            </Card>
                        ))}
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}