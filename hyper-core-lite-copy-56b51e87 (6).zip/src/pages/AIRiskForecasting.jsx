import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { TrendingUp, Brain, AlertTriangle, Target, Calendar } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { motion } from "framer-motion";

const riskTrendData = [
    { month: 'Jan', riskScore: 15, complianceScore: 92 },
    { month: 'Feb', riskScore: 18, complianceScore: 89 },
    { month: 'Mar', riskScore: 22, complianceScore: 87 },
    { month: 'Apr', riskScore: 28, complianceScore: 84 },
    { month: 'May', riskScore: 35, complianceScore: 78 },
    { month: 'Jun', riskScore: 32, complianceScore: 82 }
];

const predictiveInsights = [
    {
        title: "Audit Readiness Declining",
        prediction: "Based on current trends, your audit readiness score will drop to 72% by December 2025",
        confidence: 87,
        urgency: "High",
        recommendation: "Immediate focus on Access Control and Incident Response controls needed"
    },
    {
        title: "Staff Training Gap Emerging",
        prediction: "AI detects 23% of new employees lack required CMMC awareness training",
        confidence: 94,
        urgency: "Medium",
        recommendation: "Deploy automated training program for all new hires within 30 days"
    },
    {
        title: "Technology Refresh Risk",
        prediction: "Legacy systems approaching end-of-life will create compliance gaps in Q1 2026",
        confidence: 76,
        urgency: "Low",
        recommendation: "Begin planning technology refresh with CMMC-compliant alternatives"
    }
];

export default function AIRiskForecasting() {
    const [forecastPeriod, setForecastPeriod] = useState('6-months');

    const urgencyConfig = {
        'High': 'bg-red-100 text-red-800 border-red-300',
        'Medium': 'bg-yellow-100 text-yellow-800 border-yellow-300', 
        'Low': 'bg-blue-100 text-blue-800 border-blue-300'
    };

    return (
        <div className="space-y-8">
            <div className="text-center">
                <h1 className="text-3xl font-bold text-gray-900 mb-4 flex items-center justify-center gap-3">
                    <Brain className="w-8 h-8 text-purple-600" />
                    AI Risk Forecasting & Predictive Analytics
                </h1>
                <p className="text-lg text-gray-600 max-w-4xl mx-auto">
                    Don't just react to compliance issues - predict and prevent them with AI-powered forecasting.
                </p>
            </div>

            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <TrendingUp className="w-5 h-5 text-blue-600" />
                        Compliance Risk Trend Analysis
                    </CardTitle>
                    <CardDescription>AI analysis of your compliance trajectory over the past 6 months</CardDescription>
                </CardHeader>
                <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                        <LineChart data={riskTrendData}>
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="month" />
                            <YAxis />
                            <Tooltip />
                            <Line 
                                type="monotone" 
                                dataKey="riskScore" 
                                stroke="#ef4444" 
                                strokeWidth={3}
                                name="Risk Score"
                            />
                            <Line 
                                type="monotone" 
                                dataKey="complianceScore" 
                                stroke="#10b981" 
                                strokeWidth={3}
                                name="Compliance Score"
                            />
                        </LineChart>
                    </ResponsiveContainer>
                    <Alert className="mt-4 bg-orange-50 border-orange-200">
                        <AlertTriangle className="h-4 w-4 text-orange-600" />
                        <AlertTitle className="text-orange-800">Trend Analysis</AlertTitle>
                        <AlertDescription className="text-orange-700">
                            Risk score trending upward (+133% in 6 months). Primary drivers: Access control drift and incident response gaps.
                        </AlertDescription>
                    </Alert>
                </CardContent>
            </Card>

            <div className="grid gap-6">
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <Target className="w-5 h-5 text-green-600" />
                            AI Predictive Insights
                        </CardTitle>
                        <CardDescription>Machine learning predictions based on your current compliance patterns</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-6">
                            {predictiveInsights.map((insight, index) => (
                                <motion.div
                                    key={index}
                                    initial={{ opacity: 0, y: 20 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    transition={{ delay: index * 0.2 }}
                                    className={`p-4 rounded-lg border-2 ${urgencyConfig[insight.urgency]}`}
                                >
                                    <div className="flex justify-between items-start mb-3">
                                        <h3 className="font-semibold text-lg">{insight.title}</h3>
                                        <div className="flex items-center gap-2">
                                            <Badge variant="outline">{insight.confidence}% Confidence</Badge>
                                            <Badge className={urgencyConfig[insight.urgency]}>{insight.urgency}</Badge>
                                        </div>
                                    </div>
                                    <p className="text-sm mb-3 font-medium">{insight.prediction}</p>
                                    <div className="bg-white/50 p-3 rounded border">
                                        <p className="text-sm"><strong>AI Recommendation:</strong> {insight.recommendation}</p>
                                    </div>
                                </motion.div>
                            ))}
                        </div>
                    </CardContent>
                </Card>
            </div>

            <Alert className="bg-purple-50 border-purple-200">
                <Brain className="h-4 w-4 text-purple-600" />
                <AlertTitle className="text-purple-800 font-bold">The Power of Predictive Compliance</AlertTitle>
                <AlertDescription className="text-purple-700">
                    While competitors like TrustCloud offer basic risk scoring, our AI goes further - predicting future compliance failures weeks or months in advance. 
                    This gives you time to take corrective action before you drift out of compliance, protecting you from audit failures and False Claims Act risks.
                </AlertDescription>
            </Alert>
        </div>
    );
}