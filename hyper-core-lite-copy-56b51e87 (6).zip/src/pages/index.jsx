import Layout from "./Layout.jsx";

import Dashboard from "./Dashboard";

import Incidents from "./Incidents";

import Analytics from "./Analytics";

import SecureVirtualMachines from "./SecureVirtualMachines";

import Subscription from "./Subscription";

import ComplianceCenter from "./ComplianceCenter";

import ComplianceWorkflows from "./ComplianceWorkflows";

import CMMCReadiness from "./CMMCReadiness";

import ResponseAutomation from "./ResponseAutomation";

import CMMCMarketplace from "./CMMCMarketplace";

import CMMCDashboard from "./CMMCDashboard";

import FederalPartnerPortal from "./FederalPartnerPortal";

import BusinessFormation from "./BusinessFormation";

import PartnershipHub from "./PartnershipHub";

import CyberInsuranceGateway from "./CyberInsuranceGateway";

import PublicPortal from "./PublicPortal";

import SectorDashboard from "./SectorDashboard";

import CompetitiveAdvantage from "./CompetitiveAdvantage";

import DeploymentActionPlan from "./DeploymentActionPlan";

import PartnerPortal from "./PartnerPortal";

import Legal from "./Legal";

import LegalStrategy from "./LegalStrategy";

import LoadTesting from "./LoadTesting";

import AuditTrailDashboard from "./AuditTrailDashboard";

import BackupManager from "./BackupManager";

import EmailTester from "./EmailTester";

import PartnershipEmailCampaign from "./PartnershipEmailCampaign";

import ProfessionalMarketEntry from "./ProfessionalMarketEntry";

import ProfessionalTransformation from "./ProfessionalTransformation";

import AITrainingPipeline from "./AITrainingPipeline";

import CurrentStateAssessment from "./CurrentStateAssessment";

import HyperCoreCMMCAssessment from "./HyperCoreCMMCAssessment";

import MVPRealityCheck from "./MVPRealityCheck";

import PlatformLimitations from "./PlatformLimitations";

import PartnershipImplementation from "./PartnershipImplementation";

import PartnershipTrial from "./PartnershipTrial";

import PublicDataTraining from "./PublicDataTraining";

import PartnershipInquiry from "./PartnershipInquiry";

import ComplianceDocumentation from "./ComplianceDocumentation";

import CMMCComplianceGaps from "./CMMCComplianceGaps";

import AWSCMMCInheritance from "./AWSCMMCInheritance";

import CriticalInfrastructureAI from "./CriticalInfrastructureAI";

import InternalBusinessStrategy from "./InternalBusinessStrategy";

import AWSMigrationExecutionPlan from "./AWSMigrationExecutionPlan";

import ImplementationCodePackage from "./ImplementationCodePackage";

import MinimalViableDeployment from "./MinimalViableDeployment";

import WeeklyImplementationPlan from "./WeeklyImplementationPlan";

import Home from "./Home";

import DefenseSubcontractorStrategy from "./DefenseSubcontractorStrategy";

import SupportDashboard from "./SupportDashboard";

import AutomatedCMMCWorkflow from "./AutomatedCMMCWorkflow";

import SBIRTechnicalStrategy from "./SBIRTechnicalStrategy";

import LegacyIntegrationStrategy from "./LegacyIntegrationStrategy";

import ClientOnboarding from "./ClientOnboarding";

import BusinessOperationsAssessment from "./BusinessOperationsAssessment";

import ComplianceMarketStrategy from "./ComplianceMarketStrategy";

import ComplianceSolutions from "./ComplianceSolutions";

import CMMCAutomation from "./CMMCAutomation";

import MicrosoftCMMCIntegration from "./MicrosoftCMMCIntegration";

import AWSCustomerSolutions from "./AWSCustomerSolutions";

import LocalDevelopmentGuide from "./LocalDevelopmentGuide";

import HyperCoreCMMCReadiness from "./HyperCoreCMMCReadiness";

import AWSCMMCIntegration from "./AWSCMMCIntegration";

import PreClientLaunchPrep from "./PreClientLaunchPrep";

import EmailInfrastructure from "./EmailInfrastructure";

import AWSImplementationGuide from "./AWSImplementationGuide";

import CMMCReadinessAssessment from "./CMMCReadinessAssessment";

import CMMCMarketIntelligence from "./CMMCMarketIntelligence";

import CMMCThreatDetectionCompliance from "./CMMCThreatDetectionCompliance";

import PlatformAssessment from "./PlatformAssessment";

import AWSMigrationStrategy from "./AWSMigrationStrategy";

import ClientLifecycleInfrastructure from "./ClientLifecycleInfrastructure";

import DeploymentOptimization from "./DeploymentOptimization";

import ImmediatePriorityActions from "./ImmediatePriorityActions";

import StrategicPriorityRoadmap from "./StrategicPriorityRoadmap";

import NavigationOptimization from "./NavigationOptimization";

import CompetitiveComparison from "./CompetitiveComparison";

import CustomerSupport from "./CustomerSupport";

import CMMCImplementationGuide from "./CMMCImplementationGuide";

import CMMCOptimizationGuide from "./CMMCOptimizationGuide";

import NinetyDayDeliveryReality from "./NinetyDayDeliveryReality";

import ServiceExpectationsDisclosure from "./ServiceExpectationsDisclosure";

import ProgramDetails from "./ProgramDetails";

import ClientServicePortal from "./ClientServicePortal";

import SystemAudit from "./SystemAudit";

import SBIRDemoPortal from "./SBIRDemoPortal";

import TechnologyVision from "./TechnologyVision";

import CostAnalysis from "./CostAnalysis";

import CMMCGitWorkflow from "./CMMCGitWorkflow";

import TechnicalWorkflow from "./TechnicalWorkflow";

import RPOEvaluationStrategy from "./RPOEvaluationStrategy";

import MVPSBIRAlignment from "./MVPSBIRAlignment";

import ProgramDeploymentReadiness from "./ProgramDeploymentReadiness";

import BootstrapActionPlan from "./BootstrapActionPlan";

import AWSInfrastructureRoadmap from "./AWSInfrastructureRoadmap";

import ClientFAQ from "./ClientFAQ";

import OurTutoringModel from "./OurTutoringModel";

import SBIRGrantRequirements from "./SBIRGrantRequirements";

import SBIRTimelineAlignment from "./SBIRTimelineAlignment";

import StreamlinedActionPlan from "./StreamlinedActionPlan";

import RealisticTimelineAssessment from "./RealisticTimelineAssessment";

import InternalAdminTimeline from "./InternalAdminTimeline";

import CMMCMarketAnalysis from "./CMMCMarketAnalysis";

import GrantFueledScalingStrategy from "./GrantFueledScalingStrategy";

import MockCMMCAssessment from "./MockCMMCAssessment";

import DesktopEnvironmentSetup from "./DesktopEnvironmentSetup";

import DailyAchievementSchedule from "./DailyAchievementSchedule";

import HybridSprintPlan from "./HybridSprintPlan";

import SBIRFundingStrategy from "./SBIRFundingStrategy";

import MobileStudyGuide from "./MobileStudyGuide";

import RealisticSBIRTimeline from "./RealisticSBIRTimeline";

import SBIRBackupStrategy from "./SBIRBackupStrategy";

import SBIRCommercialStrategy from "./SBIRCommercialStrategy";

import ScalingAnalysis from "./ScalingAnalysis";

import MockAssessmentStrategy from "./MockAssessmentStrategy";

import AIToolsAdvantage from "./AIToolsAdvantage";

import ScalableCoachingSystem from "./ScalableCoachingSystem";

import StrategicMarketAssessment from "./StrategicMarketAssessment";

import CurrentMVPStatus from "./CurrentMVPStatus";

import MVPReadinessStatus from "./MVPReadinessStatus";

import PaymentIntegrationPlan from "./PaymentIntegrationPlan";

import UserRolesAndViews from "./UserRolesAndViews";

import SystemTests from "./SystemTests";

import ClientOnboardingFlow from "./ClientOnboardingFlow";

import AdminClientAnalytics from "./AdminClientAnalytics";

import ClientPipelineTests from "./ClientPipelineTests";

import AIGapAnalysis from "./AIGapAnalysis";

import ExpertSupport from "./ExpertSupport";

import ImplementationPlan from "./ImplementationPlan";

import BetaExpiration from "./BetaExpiration";

import SBIRProgressAssessment from "./SBIRProgressAssessment";

import ClientAcquisitionHub from "./ClientAcquisitionHub";

import Blog from "./Blog";

import BlogPost from "./BlogPost";

import SBIRProposalStrategy from "./SBIRProposalStrategy";

import RealisticAWSMigrationCosts from "./RealisticAWSMigrationCosts";

import StreamlinedAWSMigration from "./StreamlinedAWSMigration";

import CompleteExecutionRoadmap from "./CompleteExecutionRoadmap";

import ReportGenerator from "./ReportGenerator";

import CMMCGenerator from "./CMMCGenerator";

import CMMCLevel2Compliance from "./CMMCLevel2Compliance";

import PythonPackageStructure from "./PythonPackageStructure";

import ComprehensiveSystemTest from "./ComprehensiveSystemTest";

import Last24HourAssessment from "./Last24HourAssessment";

import SuccessPlan from "./SuccessPlan";

import KnowledgeHub from "./KnowledgeHub";

import AdminCommandCenter from "./AdminCommandCenter";

import HelpCenter from "./HelpCenter";

import Resources from "./Resources";

import TraceabilityMatrix from "./TraceabilityMatrix";

import AuthenticationTest from "./AuthenticationTest";

import SPRSScoreCalculator from "./SPRSScoreCalculator";

import EvidenceCollectionTracker from "./EvidenceCollectionTracker";

import ToolValueTest from "./ToolValueTest";

import POAMGenerator from "./POAMGenerator";

import ImplementationTimeline from "./ImplementationTimeline";

import ControlPrioritizationMatrix from "./ControlPrioritizationMatrix";

import UserManagement from "./UserManagement";

import Register from "./Register";

import PreviewTraceabilityMatrix from "./PreviewTraceabilityMatrix";

import PreviewSPRSCalculator from "./PreviewSPRSCalculator";

import AdminAccess from "./AdminAccess";

import Admin from "./Admin";

import PricingStrategy from "./PricingStrategy";

import CodeExportAndBackup from "./CodeExportAndBackup";

import LOIGenerator from "./LOIGenerator";

import GenerateLOI from "./GenerateLOI";

import AnalyticsDashboard from "./AnalyticsDashboard";

import RevisedSBIRStrategy from "./RevisedSBIRStrategy";

import DailyExecutionTracker from "./DailyExecutionTracker";

import CompetitiveMarketAnalysis from "./CompetitiveMarketAnalysis";

import SBIRAlignmentStrategy from "./SBIRAlignmentStrategy";

import SBIRImplementationStrategy from "./SBIRImplementationStrategy";

import CompetitiveScoringAnalysis from "./CompetitiveScoringAnalysis";

import MarketDisruptorAssessment from "./MarketDisruptorAssessment";

import SBIRMarketingAppendix from "./SBIRMarketingAppendix";

import SBIRTechnicalAppendix from "./SBIRTechnicalAppendix";

import LinkedInCampaignStrategy from "./LinkedInCampaignStrategy";

import StrategicValueProposition from "./StrategicValueProposition";

import CurrentCapabilitiesVsProjections from "./CurrentCapabilitiesVsProjections";

import SEOOptimizationStrategy from "./SEOOptimizationStrategy";

import SBIRProposalEvidence from "./SBIRProposalEvidence";

import KeyPersonnelResume from "./KeyPersonnelResume";

import SBIRCostProposal from "./SBIRCostProposal";

import CompleteSBIRProposal from "./CompleteSBIRProposal";

import CustomerSuccessStories from "./CustomerSuccessStories";

import SBIRAppendixAnonymized from "./SBIRAppendixAnonymized";

import Real48HourAssessment from "./Real48HourAssessment";

import SEOMetricsDashboard from "./SEOMetricsDashboard";

import Sitemap from "./Sitemap";

import ConversionTrackingDashboard from "./ConversionTrackingDashboard";

import ABTestingDashboard from "./ABTestingDashboard";

import LOITrackingDashboard from "./LOITrackingDashboard";

import ContinuousComplianceWorkflow from "./ContinuousComplianceWorkflow";

import StrategicPartnershipDashboard from "./StrategicPartnershipDashboard";

import PartnershipOutreachCenter from "./PartnershipOutreachCenter";

import RealTimeDriftDetection from "./RealTimeDriftDetection";

import AIRiskForecasting from "./AIRiskForecasting";

import SmartContractAnalyzer from "./SmartContractAnalyzer";

import DFARSCompetitiveAssessment from "./DFARSCompetitiveAssessment";

import SEOActionPlan from "./SEOActionPlan";

import DFARSMarketingStrategy from "./DFARSMarketingStrategy";

import DFARSRiskCalculator from "./DFARSRiskCalculator";

import AffordableWebinarStrategy from "./AffordableWebinarStrategy";

import ChatbotDemo from "./ChatbotDemo";

import AdvancedChatbotStrategy from "./AdvancedChatbotStrategy";

import EnhancedChatbotStrategy from "./EnhancedChatbotStrategy";

import AdvancedCMMCAnalytics from "./AdvancedCMMCAnalytics";

import LinkedinCampaignStrategy from "./LinkedinCampaignStrategy";

import PrimeContractorOutreach from "./PrimeContractorOutreach";

import WebinarPlatformStrategy from "./WebinarPlatformStrategy";

import ImmediateExecutionToday from "./ImmediateExecutionToday";

import LinkedInGroupPosts from "./LinkedInGroupPosts";

import PrimeContractorInspection from "./PrimeContractorInspection";

import LiveSecurityScanGuide from "./LiveSecurityScanGuide";

import JMeterLoadTestingGuide from "./JMeterLoadTestingGuide";

import NISTAccuracyValidation from "./NISTAccuracyValidation";

import PrimeContractorReport from "./PrimeContractorReport";

import ConciergePrimeOutreach from "./ConciergePrimeOutreach";

import ProfessionalContractCenter from "./ProfessionalContractCenter";

import PrimeOutreachExecution from "./PrimeOutreachExecution";

import EmailSystemTest from "./EmailSystemTest";

import ProfileSettings from "./ProfileSettings";

import ROICalculator from "./ROICalculator";

import roi_calculator from "./roi_calculator";

import CodeExportAndMigration from "./CodeExportAndMigration";

import MGNAgentSetupGuide from "./MGNAgentSetupGuide";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Dashboard: Dashboard,
    
    Incidents: Incidents,
    
    Analytics: Analytics,
    
    SecureVirtualMachines: SecureVirtualMachines,
    
    Subscription: Subscription,
    
    ComplianceCenter: ComplianceCenter,
    
    ComplianceWorkflows: ComplianceWorkflows,
    
    CMMCReadiness: CMMCReadiness,
    
    ResponseAutomation: ResponseAutomation,
    
    CMMCMarketplace: CMMCMarketplace,
    
    CMMCDashboard: CMMCDashboard,
    
    FederalPartnerPortal: FederalPartnerPortal,
    
    BusinessFormation: BusinessFormation,
    
    PartnershipHub: PartnershipHub,
    
    CyberInsuranceGateway: CyberInsuranceGateway,
    
    PublicPortal: PublicPortal,
    
    SectorDashboard: SectorDashboard,
    
    CompetitiveAdvantage: CompetitiveAdvantage,
    
    DeploymentActionPlan: DeploymentActionPlan,
    
    PartnerPortal: PartnerPortal,
    
    Legal: Legal,
    
    LegalStrategy: LegalStrategy,
    
    LoadTesting: LoadTesting,
    
    AuditTrailDashboard: AuditTrailDashboard,
    
    BackupManager: BackupManager,
    
    EmailTester: EmailTester,
    
    PartnershipEmailCampaign: PartnershipEmailCampaign,
    
    ProfessionalMarketEntry: ProfessionalMarketEntry,
    
    ProfessionalTransformation: ProfessionalTransformation,
    
    AITrainingPipeline: AITrainingPipeline,
    
    CurrentStateAssessment: CurrentStateAssessment,
    
    HyperCoreCMMCAssessment: HyperCoreCMMCAssessment,
    
    MVPRealityCheck: MVPRealityCheck,
    
    PlatformLimitations: PlatformLimitations,
    
    PartnershipImplementation: PartnershipImplementation,
    
    PartnershipTrial: PartnershipTrial,
    
    PublicDataTraining: PublicDataTraining,
    
    PartnershipInquiry: PartnershipInquiry,
    
    ComplianceDocumentation: ComplianceDocumentation,
    
    CMMCComplianceGaps: CMMCComplianceGaps,
    
    AWSCMMCInheritance: AWSCMMCInheritance,
    
    CriticalInfrastructureAI: CriticalInfrastructureAI,
    
    InternalBusinessStrategy: InternalBusinessStrategy,
    
    AWSMigrationExecutionPlan: AWSMigrationExecutionPlan,
    
    ImplementationCodePackage: ImplementationCodePackage,
    
    MinimalViableDeployment: MinimalViableDeployment,
    
    WeeklyImplementationPlan: WeeklyImplementationPlan,
    
    Home: Home,
    
    DefenseSubcontractorStrategy: DefenseSubcontractorStrategy,
    
    SupportDashboard: SupportDashboard,
    
    AutomatedCMMCWorkflow: AutomatedCMMCWorkflow,
    
    SBIRTechnicalStrategy: SBIRTechnicalStrategy,
    
    LegacyIntegrationStrategy: LegacyIntegrationStrategy,
    
    ClientOnboarding: ClientOnboarding,
    
    BusinessOperationsAssessment: BusinessOperationsAssessment,
    
    ComplianceMarketStrategy: ComplianceMarketStrategy,
    
    ComplianceSolutions: ComplianceSolutions,
    
    CMMCAutomation: CMMCAutomation,
    
    MicrosoftCMMCIntegration: MicrosoftCMMCIntegration,
    
    AWSCustomerSolutions: AWSCustomerSolutions,
    
    LocalDevelopmentGuide: LocalDevelopmentGuide,
    
    HyperCoreCMMCReadiness: HyperCoreCMMCReadiness,
    
    AWSCMMCIntegration: AWSCMMCIntegration,
    
    PreClientLaunchPrep: PreClientLaunchPrep,
    
    EmailInfrastructure: EmailInfrastructure,
    
    AWSImplementationGuide: AWSImplementationGuide,
    
    CMMCReadinessAssessment: CMMCReadinessAssessment,
    
    CMMCMarketIntelligence: CMMCMarketIntelligence,
    
    CMMCThreatDetectionCompliance: CMMCThreatDetectionCompliance,
    
    PlatformAssessment: PlatformAssessment,
    
    AWSMigrationStrategy: AWSMigrationStrategy,
    
    ClientLifecycleInfrastructure: ClientLifecycleInfrastructure,
    
    DeploymentOptimization: DeploymentOptimization,
    
    ImmediatePriorityActions: ImmediatePriorityActions,
    
    StrategicPriorityRoadmap: StrategicPriorityRoadmap,
    
    NavigationOptimization: NavigationOptimization,
    
    CompetitiveComparison: CompetitiveComparison,
    
    CustomerSupport: CustomerSupport,
    
    CMMCImplementationGuide: CMMCImplementationGuide,
    
    CMMCOptimizationGuide: CMMCOptimizationGuide,
    
    NinetyDayDeliveryReality: NinetyDayDeliveryReality,
    
    ServiceExpectationsDisclosure: ServiceExpectationsDisclosure,
    
    ProgramDetails: ProgramDetails,
    
    ClientServicePortal: ClientServicePortal,
    
    SystemAudit: SystemAudit,
    
    SBIRDemoPortal: SBIRDemoPortal,
    
    TechnologyVision: TechnologyVision,
    
    CostAnalysis: CostAnalysis,
    
    CMMCGitWorkflow: CMMCGitWorkflow,
    
    TechnicalWorkflow: TechnicalWorkflow,
    
    RPOEvaluationStrategy: RPOEvaluationStrategy,
    
    MVPSBIRAlignment: MVPSBIRAlignment,
    
    ProgramDeploymentReadiness: ProgramDeploymentReadiness,
    
    BootstrapActionPlan: BootstrapActionPlan,
    
    AWSInfrastructureRoadmap: AWSInfrastructureRoadmap,
    
    ClientFAQ: ClientFAQ,
    
    OurTutoringModel: OurTutoringModel,
    
    SBIRGrantRequirements: SBIRGrantRequirements,
    
    SBIRTimelineAlignment: SBIRTimelineAlignment,
    
    StreamlinedActionPlan: StreamlinedActionPlan,
    
    RealisticTimelineAssessment: RealisticTimelineAssessment,
    
    InternalAdminTimeline: InternalAdminTimeline,
    
    CMMCMarketAnalysis: CMMCMarketAnalysis,
    
    GrantFueledScalingStrategy: GrantFueledScalingStrategy,
    
    MockCMMCAssessment: MockCMMCAssessment,
    
    DesktopEnvironmentSetup: DesktopEnvironmentSetup,
    
    DailyAchievementSchedule: DailyAchievementSchedule,
    
    HybridSprintPlan: HybridSprintPlan,
    
    SBIRFundingStrategy: SBIRFundingStrategy,
    
    MobileStudyGuide: MobileStudyGuide,
    
    RealisticSBIRTimeline: RealisticSBIRTimeline,
    
    SBIRBackupStrategy: SBIRBackupStrategy,
    
    SBIRCommercialStrategy: SBIRCommercialStrategy,
    
    ScalingAnalysis: ScalingAnalysis,
    
    MockAssessmentStrategy: MockAssessmentStrategy,
    
    AIToolsAdvantage: AIToolsAdvantage,
    
    ScalableCoachingSystem: ScalableCoachingSystem,
    
    StrategicMarketAssessment: StrategicMarketAssessment,
    
    CurrentMVPStatus: CurrentMVPStatus,
    
    MVPReadinessStatus: MVPReadinessStatus,
    
    PaymentIntegrationPlan: PaymentIntegrationPlan,
    
    UserRolesAndViews: UserRolesAndViews,
    
    SystemTests: SystemTests,
    
    ClientOnboardingFlow: ClientOnboardingFlow,
    
    AdminClientAnalytics: AdminClientAnalytics,
    
    ClientPipelineTests: ClientPipelineTests,
    
    AIGapAnalysis: AIGapAnalysis,
    
    ExpertSupport: ExpertSupport,
    
    ImplementationPlan: ImplementationPlan,
    
    BetaExpiration: BetaExpiration,
    
    SBIRProgressAssessment: SBIRProgressAssessment,
    
    ClientAcquisitionHub: ClientAcquisitionHub,
    
    Blog: Blog,
    
    BlogPost: BlogPost,
    
    SBIRProposalStrategy: SBIRProposalStrategy,
    
    RealisticAWSMigrationCosts: RealisticAWSMigrationCosts,
    
    StreamlinedAWSMigration: StreamlinedAWSMigration,
    
    CompleteExecutionRoadmap: CompleteExecutionRoadmap,
    
    ReportGenerator: ReportGenerator,
    
    CMMCGenerator: CMMCGenerator,
    
    CMMCLevel2Compliance: CMMCLevel2Compliance,
    
    PythonPackageStructure: PythonPackageStructure,
    
    ComprehensiveSystemTest: ComprehensiveSystemTest,
    
    Last24HourAssessment: Last24HourAssessment,
    
    SuccessPlan: SuccessPlan,
    
    KnowledgeHub: KnowledgeHub,
    
    AdminCommandCenter: AdminCommandCenter,
    
    HelpCenter: HelpCenter,
    
    Resources: Resources,
    
    TraceabilityMatrix: TraceabilityMatrix,
    
    AuthenticationTest: AuthenticationTest,
    
    SPRSScoreCalculator: SPRSScoreCalculator,
    
    EvidenceCollectionTracker: EvidenceCollectionTracker,
    
    ToolValueTest: ToolValueTest,
    
    POAMGenerator: POAMGenerator,
    
    ImplementationTimeline: ImplementationTimeline,
    
    ControlPrioritizationMatrix: ControlPrioritizationMatrix,
    
    UserManagement: UserManagement,
    
    Register: Register,
    
    PreviewTraceabilityMatrix: PreviewTraceabilityMatrix,
    
    PreviewSPRSCalculator: PreviewSPRSCalculator,
    
    AdminAccess: AdminAccess,
    
    Admin: Admin,
    
    PricingStrategy: PricingStrategy,
    
    CodeExportAndBackup: CodeExportAndBackup,
    
    LOIGenerator: LOIGenerator,
    
    GenerateLOI: GenerateLOI,
    
    AnalyticsDashboard: AnalyticsDashboard,
    
    RevisedSBIRStrategy: RevisedSBIRStrategy,
    
    DailyExecutionTracker: DailyExecutionTracker,
    
    CompetitiveMarketAnalysis: CompetitiveMarketAnalysis,
    
    SBIRAlignmentStrategy: SBIRAlignmentStrategy,
    
    SBIRImplementationStrategy: SBIRImplementationStrategy,
    
    CompetitiveScoringAnalysis: CompetitiveScoringAnalysis,
    
    MarketDisruptorAssessment: MarketDisruptorAssessment,
    
    SBIRMarketingAppendix: SBIRMarketingAppendix,
    
    SBIRTechnicalAppendix: SBIRTechnicalAppendix,
    
    LinkedInCampaignStrategy: LinkedInCampaignStrategy,
    
    StrategicValueProposition: StrategicValueProposition,
    
    CurrentCapabilitiesVsProjections: CurrentCapabilitiesVsProjections,
    
    SEOOptimizationStrategy: SEOOptimizationStrategy,
    
    SBIRProposalEvidence: SBIRProposalEvidence,
    
    KeyPersonnelResume: KeyPersonnelResume,
    
    SBIRCostProposal: SBIRCostProposal,
    
    CompleteSBIRProposal: CompleteSBIRProposal,
    
    CustomerSuccessStories: CustomerSuccessStories,
    
    SBIRAppendixAnonymized: SBIRAppendixAnonymized,
    
    Real48HourAssessment: Real48HourAssessment,
    
    SEOMetricsDashboard: SEOMetricsDashboard,
    
    Sitemap: Sitemap,
    
    ConversionTrackingDashboard: ConversionTrackingDashboard,
    
    ABTestingDashboard: ABTestingDashboard,
    
    LOITrackingDashboard: LOITrackingDashboard,
    
    ContinuousComplianceWorkflow: ContinuousComplianceWorkflow,
    
    StrategicPartnershipDashboard: StrategicPartnershipDashboard,
    
    PartnershipOutreachCenter: PartnershipOutreachCenter,
    
    RealTimeDriftDetection: RealTimeDriftDetection,
    
    AIRiskForecasting: AIRiskForecasting,
    
    SmartContractAnalyzer: SmartContractAnalyzer,
    
    DFARSCompetitiveAssessment: DFARSCompetitiveAssessment,
    
    SEOActionPlan: SEOActionPlan,
    
    DFARSMarketingStrategy: DFARSMarketingStrategy,
    
    DFARSRiskCalculator: DFARSRiskCalculator,
    
    AffordableWebinarStrategy: AffordableWebinarStrategy,
    
    ChatbotDemo: ChatbotDemo,
    
    AdvancedChatbotStrategy: AdvancedChatbotStrategy,
    
    EnhancedChatbotStrategy: EnhancedChatbotStrategy,
    
    AdvancedCMMCAnalytics: AdvancedCMMCAnalytics,
    
    LinkedinCampaignStrategy: LinkedinCampaignStrategy,
    
    PrimeContractorOutreach: PrimeContractorOutreach,
    
    WebinarPlatformStrategy: WebinarPlatformStrategy,
    
    ImmediateExecutionToday: ImmediateExecutionToday,
    
    LinkedInGroupPosts: LinkedInGroupPosts,
    
    PrimeContractorInspection: PrimeContractorInspection,
    
    LiveSecurityScanGuide: LiveSecurityScanGuide,
    
    JMeterLoadTestingGuide: JMeterLoadTestingGuide,
    
    NISTAccuracyValidation: NISTAccuracyValidation,
    
    PrimeContractorReport: PrimeContractorReport,
    
    ConciergePrimeOutreach: ConciergePrimeOutreach,
    
    ProfessionalContractCenter: ProfessionalContractCenter,
    
    PrimeOutreachExecution: PrimeOutreachExecution,
    
    EmailSystemTest: EmailSystemTest,
    
    ProfileSettings: ProfileSettings,
    
    ROICalculator: ROICalculator,
    
    roi_calculator: roi_calculator,
    
    CodeExportAndMigration: CodeExportAndMigration,
    
    MGNAgentSetupGuide: MGNAgentSetupGuide,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Dashboard />} />
                
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/Incidents" element={<Incidents />} />
                
                <Route path="/Analytics" element={<Analytics />} />
                
                <Route path="/SecureVirtualMachines" element={<SecureVirtualMachines />} />
                
                <Route path="/Subscription" element={<Subscription />} />
                
                <Route path="/ComplianceCenter" element={<ComplianceCenter />} />
                
                <Route path="/ComplianceWorkflows" element={<ComplianceWorkflows />} />
                
                <Route path="/CMMCReadiness" element={<CMMCReadiness />} />
                
                <Route path="/ResponseAutomation" element={<ResponseAutomation />} />
                
                <Route path="/CMMCMarketplace" element={<CMMCMarketplace />} />
                
                <Route path="/CMMCDashboard" element={<CMMCDashboard />} />
                
                <Route path="/FederalPartnerPortal" element={<FederalPartnerPortal />} />
                
                <Route path="/BusinessFormation" element={<BusinessFormation />} />
                
                <Route path="/PartnershipHub" element={<PartnershipHub />} />
                
                <Route path="/CyberInsuranceGateway" element={<CyberInsuranceGateway />} />
                
                <Route path="/PublicPortal" element={<PublicPortal />} />
                
                <Route path="/SectorDashboard" element={<SectorDashboard />} />
                
                <Route path="/CompetitiveAdvantage" element={<CompetitiveAdvantage />} />
                
                <Route path="/DeploymentActionPlan" element={<DeploymentActionPlan />} />
                
                <Route path="/PartnerPortal" element={<PartnerPortal />} />
                
                <Route path="/Legal" element={<Legal />} />
                
                <Route path="/LegalStrategy" element={<LegalStrategy />} />
                
                <Route path="/LoadTesting" element={<LoadTesting />} />
                
                <Route path="/AuditTrailDashboard" element={<AuditTrailDashboard />} />
                
                <Route path="/BackupManager" element={<BackupManager />} />
                
                <Route path="/EmailTester" element={<EmailTester />} />
                
                <Route path="/PartnershipEmailCampaign" element={<PartnershipEmailCampaign />} />
                
                <Route path="/ProfessionalMarketEntry" element={<ProfessionalMarketEntry />} />
                
                <Route path="/ProfessionalTransformation" element={<ProfessionalTransformation />} />
                
                <Route path="/AITrainingPipeline" element={<AITrainingPipeline />} />
                
                <Route path="/CurrentStateAssessment" element={<CurrentStateAssessment />} />
                
                <Route path="/HyperCoreCMMCAssessment" element={<HyperCoreCMMCAssessment />} />
                
                <Route path="/MVPRealityCheck" element={<MVPRealityCheck />} />
                
                <Route path="/PlatformLimitations" element={<PlatformLimitations />} />
                
                <Route path="/PartnershipImplementation" element={<PartnershipImplementation />} />
                
                <Route path="/PartnershipTrial" element={<PartnershipTrial />} />
                
                <Route path="/PublicDataTraining" element={<PublicDataTraining />} />
                
                <Route path="/PartnershipInquiry" element={<PartnershipInquiry />} />
                
                <Route path="/ComplianceDocumentation" element={<ComplianceDocumentation />} />
                
                <Route path="/CMMCComplianceGaps" element={<CMMCComplianceGaps />} />
                
                <Route path="/AWSCMMCInheritance" element={<AWSCMMCInheritance />} />
                
                <Route path="/CriticalInfrastructureAI" element={<CriticalInfrastructureAI />} />
                
                <Route path="/InternalBusinessStrategy" element={<InternalBusinessStrategy />} />
                
                <Route path="/AWSMigrationExecutionPlan" element={<AWSMigrationExecutionPlan />} />
                
                <Route path="/ImplementationCodePackage" element={<ImplementationCodePackage />} />
                
                <Route path="/MinimalViableDeployment" element={<MinimalViableDeployment />} />
                
                <Route path="/WeeklyImplementationPlan" element={<WeeklyImplementationPlan />} />
                
                <Route path="/Home" element={<Home />} />
                
                <Route path="/DefenseSubcontractorStrategy" element={<DefenseSubcontractorStrategy />} />
                
                <Route path="/SupportDashboard" element={<SupportDashboard />} />
                
                <Route path="/AutomatedCMMCWorkflow" element={<AutomatedCMMCWorkflow />} />
                
                <Route path="/SBIRTechnicalStrategy" element={<SBIRTechnicalStrategy />} />
                
                <Route path="/LegacyIntegrationStrategy" element={<LegacyIntegrationStrategy />} />
                
                <Route path="/ClientOnboarding" element={<ClientOnboarding />} />
                
                <Route path="/BusinessOperationsAssessment" element={<BusinessOperationsAssessment />} />
                
                <Route path="/ComplianceMarketStrategy" element={<ComplianceMarketStrategy />} />
                
                <Route path="/ComplianceSolutions" element={<ComplianceSolutions />} />
                
                <Route path="/CMMCAutomation" element={<CMMCAutomation />} />
                
                <Route path="/MicrosoftCMMCIntegration" element={<MicrosoftCMMCIntegration />} />
                
                <Route path="/AWSCustomerSolutions" element={<AWSCustomerSolutions />} />
                
                <Route path="/LocalDevelopmentGuide" element={<LocalDevelopmentGuide />} />
                
                <Route path="/HyperCoreCMMCReadiness" element={<HyperCoreCMMCReadiness />} />
                
                <Route path="/AWSCMMCIntegration" element={<AWSCMMCIntegration />} />
                
                <Route path="/PreClientLaunchPrep" element={<PreClientLaunchPrep />} />
                
                <Route path="/EmailInfrastructure" element={<EmailInfrastructure />} />
                
                <Route path="/AWSImplementationGuide" element={<AWSImplementationGuide />} />
                
                <Route path="/CMMCReadinessAssessment" element={<CMMCReadinessAssessment />} />
                
                <Route path="/CMMCMarketIntelligence" element={<CMMCMarketIntelligence />} />
                
                <Route path="/CMMCThreatDetectionCompliance" element={<CMMCThreatDetectionCompliance />} />
                
                <Route path="/PlatformAssessment" element={<PlatformAssessment />} />
                
                <Route path="/AWSMigrationStrategy" element={<AWSMigrationStrategy />} />
                
                <Route path="/ClientLifecycleInfrastructure" element={<ClientLifecycleInfrastructure />} />
                
                <Route path="/DeploymentOptimization" element={<DeploymentOptimization />} />
                
                <Route path="/ImmediatePriorityActions" element={<ImmediatePriorityActions />} />
                
                <Route path="/StrategicPriorityRoadmap" element={<StrategicPriorityRoadmap />} />
                
                <Route path="/NavigationOptimization" element={<NavigationOptimization />} />
                
                <Route path="/CompetitiveComparison" element={<CompetitiveComparison />} />
                
                <Route path="/CustomerSupport" element={<CustomerSupport />} />
                
                <Route path="/CMMCImplementationGuide" element={<CMMCImplementationGuide />} />
                
                <Route path="/CMMCOptimizationGuide" element={<CMMCOptimizationGuide />} />
                
                <Route path="/NinetyDayDeliveryReality" element={<NinetyDayDeliveryReality />} />
                
                <Route path="/ServiceExpectationsDisclosure" element={<ServiceExpectationsDisclosure />} />
                
                <Route path="/ProgramDetails" element={<ProgramDetails />} />
                
                <Route path="/ClientServicePortal" element={<ClientServicePortal />} />
                
                <Route path="/SystemAudit" element={<SystemAudit />} />
                
                <Route path="/SBIRDemoPortal" element={<SBIRDemoPortal />} />
                
                <Route path="/TechnologyVision" element={<TechnologyVision />} />
                
                <Route path="/CostAnalysis" element={<CostAnalysis />} />
                
                <Route path="/CMMCGitWorkflow" element={<CMMCGitWorkflow />} />
                
                <Route path="/TechnicalWorkflow" element={<TechnicalWorkflow />} />
                
                <Route path="/RPOEvaluationStrategy" element={<RPOEvaluationStrategy />} />
                
                <Route path="/MVPSBIRAlignment" element={<MVPSBIRAlignment />} />
                
                <Route path="/ProgramDeploymentReadiness" element={<ProgramDeploymentReadiness />} />
                
                <Route path="/BootstrapActionPlan" element={<BootstrapActionPlan />} />
                
                <Route path="/AWSInfrastructureRoadmap" element={<AWSInfrastructureRoadmap />} />
                
                <Route path="/ClientFAQ" element={<ClientFAQ />} />
                
                <Route path="/OurTutoringModel" element={<OurTutoringModel />} />
                
                <Route path="/SBIRGrantRequirements" element={<SBIRGrantRequirements />} />
                
                <Route path="/SBIRTimelineAlignment" element={<SBIRTimelineAlignment />} />
                
                <Route path="/StreamlinedActionPlan" element={<StreamlinedActionPlan />} />
                
                <Route path="/RealisticTimelineAssessment" element={<RealisticTimelineAssessment />} />
                
                <Route path="/InternalAdminTimeline" element={<InternalAdminTimeline />} />
                
                <Route path="/CMMCMarketAnalysis" element={<CMMCMarketAnalysis />} />
                
                <Route path="/GrantFueledScalingStrategy" element={<GrantFueledScalingStrategy />} />
                
                <Route path="/MockCMMCAssessment" element={<MockCMMCAssessment />} />
                
                <Route path="/DesktopEnvironmentSetup" element={<DesktopEnvironmentSetup />} />
                
                <Route path="/DailyAchievementSchedule" element={<DailyAchievementSchedule />} />
                
                <Route path="/HybridSprintPlan" element={<HybridSprintPlan />} />
                
                <Route path="/SBIRFundingStrategy" element={<SBIRFundingStrategy />} />
                
                <Route path="/MobileStudyGuide" element={<MobileStudyGuide />} />
                
                <Route path="/RealisticSBIRTimeline" element={<RealisticSBIRTimeline />} />
                
                <Route path="/SBIRBackupStrategy" element={<SBIRBackupStrategy />} />
                
                <Route path="/SBIRCommercialStrategy" element={<SBIRCommercialStrategy />} />
                
                <Route path="/ScalingAnalysis" element={<ScalingAnalysis />} />
                
                <Route path="/MockAssessmentStrategy" element={<MockAssessmentStrategy />} />
                
                <Route path="/AIToolsAdvantage" element={<AIToolsAdvantage />} />
                
                <Route path="/ScalableCoachingSystem" element={<ScalableCoachingSystem />} />
                
                <Route path="/StrategicMarketAssessment" element={<StrategicMarketAssessment />} />
                
                <Route path="/CurrentMVPStatus" element={<CurrentMVPStatus />} />
                
                <Route path="/MVPReadinessStatus" element={<MVPReadinessStatus />} />
                
                <Route path="/PaymentIntegrationPlan" element={<PaymentIntegrationPlan />} />
                
                <Route path="/UserRolesAndViews" element={<UserRolesAndViews />} />
                
                <Route path="/SystemTests" element={<SystemTests />} />
                
                <Route path="/ClientOnboardingFlow" element={<ClientOnboardingFlow />} />
                
                <Route path="/AdminClientAnalytics" element={<AdminClientAnalytics />} />
                
                <Route path="/ClientPipelineTests" element={<ClientPipelineTests />} />
                
                <Route path="/AIGapAnalysis" element={<AIGapAnalysis />} />
                
                <Route path="/ExpertSupport" element={<ExpertSupport />} />
                
                <Route path="/ImplementationPlan" element={<ImplementationPlan />} />
                
                <Route path="/BetaExpiration" element={<BetaExpiration />} />
                
                <Route path="/SBIRProgressAssessment" element={<SBIRProgressAssessment />} />
                
                <Route path="/ClientAcquisitionHub" element={<ClientAcquisitionHub />} />
                
                <Route path="/Blog" element={<Blog />} />
                
                <Route path="/BlogPost" element={<BlogPost />} />
                
                <Route path="/SBIRProposalStrategy" element={<SBIRProposalStrategy />} />
                
                <Route path="/RealisticAWSMigrationCosts" element={<RealisticAWSMigrationCosts />} />
                
                <Route path="/StreamlinedAWSMigration" element={<StreamlinedAWSMigration />} />
                
                <Route path="/CompleteExecutionRoadmap" element={<CompleteExecutionRoadmap />} />
                
                <Route path="/ReportGenerator" element={<ReportGenerator />} />
                
                <Route path="/CMMCGenerator" element={<CMMCGenerator />} />
                
                <Route path="/CMMCLevel2Compliance" element={<CMMCLevel2Compliance />} />
                
                <Route path="/PythonPackageStructure" element={<PythonPackageStructure />} />
                
                <Route path="/ComprehensiveSystemTest" element={<ComprehensiveSystemTest />} />
                
                <Route path="/Last24HourAssessment" element={<Last24HourAssessment />} />
                
                <Route path="/SuccessPlan" element={<SuccessPlan />} />
                
                <Route path="/KnowledgeHub" element={<KnowledgeHub />} />
                
                <Route path="/AdminCommandCenter" element={<AdminCommandCenter />} />
                
                <Route path="/HelpCenter" element={<HelpCenter />} />
                
                <Route path="/Resources" element={<Resources />} />
                
                <Route path="/TraceabilityMatrix" element={<TraceabilityMatrix />} />
                
                <Route path="/AuthenticationTest" element={<AuthenticationTest />} />
                
                <Route path="/SPRSScoreCalculator" element={<SPRSScoreCalculator />} />
                
                <Route path="/EvidenceCollectionTracker" element={<EvidenceCollectionTracker />} />
                
                <Route path="/ToolValueTest" element={<ToolValueTest />} />
                
                <Route path="/POAMGenerator" element={<POAMGenerator />} />
                
                <Route path="/ImplementationTimeline" element={<ImplementationTimeline />} />
                
                <Route path="/ControlPrioritizationMatrix" element={<ControlPrioritizationMatrix />} />
                
                <Route path="/UserManagement" element={<UserManagement />} />
                
                <Route path="/Register" element={<Register />} />
                
                <Route path="/PreviewTraceabilityMatrix" element={<PreviewTraceabilityMatrix />} />
                
                <Route path="/PreviewSPRSCalculator" element={<PreviewSPRSCalculator />} />
                
                <Route path="/AdminAccess" element={<AdminAccess />} />
                
                <Route path="/Admin" element={<Admin />} />
                
                <Route path="/PricingStrategy" element={<PricingStrategy />} />
                
                <Route path="/CodeExportAndBackup" element={<CodeExportAndBackup />} />
                
                <Route path="/LOIGenerator" element={<LOIGenerator />} />
                
                <Route path="/GenerateLOI" element={<GenerateLOI />} />
                
                <Route path="/AnalyticsDashboard" element={<AnalyticsDashboard />} />
                
                <Route path="/RevisedSBIRStrategy" element={<RevisedSBIRStrategy />} />
                
                <Route path="/DailyExecutionTracker" element={<DailyExecutionTracker />} />
                
                <Route path="/CompetitiveMarketAnalysis" element={<CompetitiveMarketAnalysis />} />
                
                <Route path="/SBIRAlignmentStrategy" element={<SBIRAlignmentStrategy />} />
                
                <Route path="/SBIRImplementationStrategy" element={<SBIRImplementationStrategy />} />
                
                <Route path="/CompetitiveScoringAnalysis" element={<CompetitiveScoringAnalysis />} />
                
                <Route path="/MarketDisruptorAssessment" element={<MarketDisruptorAssessment />} />
                
                <Route path="/SBIRMarketingAppendix" element={<SBIRMarketingAppendix />} />
                
                <Route path="/SBIRTechnicalAppendix" element={<SBIRTechnicalAppendix />} />
                
                <Route path="/LinkedInCampaignStrategy" element={<LinkedInCampaignStrategy />} />
                
                <Route path="/StrategicValueProposition" element={<StrategicValueProposition />} />
                
                <Route path="/CurrentCapabilitiesVsProjections" element={<CurrentCapabilitiesVsProjections />} />
                
                <Route path="/SEOOptimizationStrategy" element={<SEOOptimizationStrategy />} />
                
                <Route path="/SBIRProposalEvidence" element={<SBIRProposalEvidence />} />
                
                <Route path="/KeyPersonnelResume" element={<KeyPersonnelResume />} />
                
                <Route path="/SBIRCostProposal" element={<SBIRCostProposal />} />
                
                <Route path="/CompleteSBIRProposal" element={<CompleteSBIRProposal />} />
                
                <Route path="/CustomerSuccessStories" element={<CustomerSuccessStories />} />
                
                <Route path="/SBIRAppendixAnonymized" element={<SBIRAppendixAnonymized />} />
                
                <Route path="/Real48HourAssessment" element={<Real48HourAssessment />} />
                
                <Route path="/SEOMetricsDashboard" element={<SEOMetricsDashboard />} />
                
                <Route path="/Sitemap" element={<Sitemap />} />
                
                <Route path="/ConversionTrackingDashboard" element={<ConversionTrackingDashboard />} />
                
                <Route path="/ABTestingDashboard" element={<ABTestingDashboard />} />
                
                <Route path="/LOITrackingDashboard" element={<LOITrackingDashboard />} />
                
                <Route path="/ContinuousComplianceWorkflow" element={<ContinuousComplianceWorkflow />} />
                
                <Route path="/StrategicPartnershipDashboard" element={<StrategicPartnershipDashboard />} />
                
                <Route path="/PartnershipOutreachCenter" element={<PartnershipOutreachCenter />} />
                
                <Route path="/RealTimeDriftDetection" element={<RealTimeDriftDetection />} />
                
                <Route path="/AIRiskForecasting" element={<AIRiskForecasting />} />
                
                <Route path="/SmartContractAnalyzer" element={<SmartContractAnalyzer />} />
                
                <Route path="/DFARSCompetitiveAssessment" element={<DFARSCompetitiveAssessment />} />
                
                <Route path="/SEOActionPlan" element={<SEOActionPlan />} />
                
                <Route path="/DFARSMarketingStrategy" element={<DFARSMarketingStrategy />} />
                
                <Route path="/DFARSRiskCalculator" element={<DFARSRiskCalculator />} />
                
                <Route path="/AffordableWebinarStrategy" element={<AffordableWebinarStrategy />} />
                
                <Route path="/ChatbotDemo" element={<ChatbotDemo />} />
                
                <Route path="/AdvancedChatbotStrategy" element={<AdvancedChatbotStrategy />} />
                
                <Route path="/EnhancedChatbotStrategy" element={<EnhancedChatbotStrategy />} />
                
                <Route path="/AdvancedCMMCAnalytics" element={<AdvancedCMMCAnalytics />} />
                
                <Route path="/LinkedinCampaignStrategy" element={<LinkedinCampaignStrategy />} />
                
                <Route path="/PrimeContractorOutreach" element={<PrimeContractorOutreach />} />
                
                <Route path="/WebinarPlatformStrategy" element={<WebinarPlatformStrategy />} />
                
                <Route path="/ImmediateExecutionToday" element={<ImmediateExecutionToday />} />
                
                <Route path="/LinkedInGroupPosts" element={<LinkedInGroupPosts />} />
                
                <Route path="/PrimeContractorInspection" element={<PrimeContractorInspection />} />
                
                <Route path="/LiveSecurityScanGuide" element={<LiveSecurityScanGuide />} />
                
                <Route path="/JMeterLoadTestingGuide" element={<JMeterLoadTestingGuide />} />
                
                <Route path="/NISTAccuracyValidation" element={<NISTAccuracyValidation />} />
                
                <Route path="/PrimeContractorReport" element={<PrimeContractorReport />} />
                
                <Route path="/ConciergePrimeOutreach" element={<ConciergePrimeOutreach />} />
                
                <Route path="/ProfessionalContractCenter" element={<ProfessionalContractCenter />} />
                
                <Route path="/PrimeOutreachExecution" element={<PrimeOutreachExecution />} />
                
                <Route path="/EmailSystemTest" element={<EmailSystemTest />} />
                
                <Route path="/ProfileSettings" element={<ProfileSettings />} />
                
                <Route path="/ROICalculator" element={<ROICalculator />} />
                
                <Route path="/roi_calculator" element={<roi_calculator />} />
                
                <Route path="/CodeExportAndMigration" element={<CodeExportAndMigration />} />
                
                <Route path="/MGNAgentSetupGuide" element={<MGNAgentSetupGuide />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}