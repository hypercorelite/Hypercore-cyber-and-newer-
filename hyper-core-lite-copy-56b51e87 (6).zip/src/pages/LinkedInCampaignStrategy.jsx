
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CheckCircle, Calendar, Target, Copy, Users, FileText, TrendingUp, Star, Linkedin, BookOpen, Mic } from 'lucide-react';
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";
import { motion } from "framer-motion";
import { toast } from "sonner";

// New publicationContent object with detailed article information
const publicationContent = {
    "ndia": {
        name: "National Defense (NDIA)",
        ease: 8,
        pitchSubject: "Op-Ed: AI-First CMMC: Slashing $50K Costs for DIB SMBs in 2025.",
        articleTitle: "AI-First CMMC Compliance: Cutting Costs and Risks for DIB SMBs in 2025",
        content: `In the Defense Industrial Base (DIB), where 300,000+ subcontractors handle Controlled Unclassified Information (CUI), the CMMC 2.0 Final Rule—effective November 10, 2025—poses a stark challenge: $20K-50K initial costs and $5K-10K annual maintenance, excluding 68% of SMBs from $150B in DoD awards (Department of Defense, Office of Small Business Programs, 2025; Forrester, 2025). Traditional consulting—manual audits and documentation—delays readiness 6-12 months, with 70% flow-down errors and FCA fines up to $4.6M (Cyber AB, 2025; U.S. Department of Justice, 2024). AI-first platforms like HyperCore Cyber disrupt this, reducing costs 50-70%, speeding compliance to 90 days, achieving 95% NIST 800-171 accuracy, and enabling continuous monitoring for SPRS affirmations—outpacing generic GRC tools like Drata (20% escalation rate) and high-price consultants (Forrester, 2025; Deloitte, 2025).\n\n**Cost Value Proposition:** Traditional Level 2 audits cost $35K-75K, with $40K for SSPs/POA&Ms (Cyber AB, 2025). HyperCore's AI automates these for $2K-5K/year, saving 50-70% by generating SPRS-ready docs in minutes—vs. consultants' 20-50% annual fees (Cyber Defense Magazine, 2025). For a NoVA sub with 20 employees, this means $15K savings, unlocking contracts without debt.\n\n**Speed and Accuracy:** Manual processes take 6-12 months, with 75% overestimation in self-assessments (PreVeil, 2025; ISACA, 2025). HyperCore's NLP-driven Analyzer extracts DFARS clauses with 95% accuracy, mapping to NIST 800-171 in 90 days—40% faster than Drata's hybrid scans (Concentric AI, 2025). Predictive modeling forecasts gaps 3-6 months ahead, reducing 70% flow-down errors (Cyber AB, 2025).\n\n**Continuous Compliance:** CMMC demands 24/7 monitoring for 180-day POA&Ms (Department of Defense, 2024). HyperCore's drift detection ensures real-time NIST adherence, outperforming Vanta's basic templates with 99% uptime—critical for avoiding $1M FCA fines like Raytheon's (U.S. Department of Justice, 2023; Deloitte, 2025).\n\nFor DIB SMBs, HyperCore isn't just compliance—it's a competitive edge. As Phase 1 hits Q4 2025, AI-first tools will define winners. Explore HyperCore at hypercorecyber.com/trial.`,
        status: "Draft Ready",
    },
    "military-review": {
        name: "Military Review",
        ease: 7,
        pitchSubject: "Article Submission: AI-First CMMC: Strategic Tool for DIB Readiness in 2025",
        articleTitle: "AI-First CMMC Compliance: A Strategic Imperative for DIB Supply Chain Resilience in 2025",
        content: `The Cybersecurity Maturity Model Certification (CMMC) 2.0, effective November 10, 2025, mandates verifiable cybersecurity for the DIB's 300,000+ entities, with Phase 1 requiring Level 2 in 15% of contracts by Q4 2025 (Department of Defense, 2024). For SMBs—68% of the DIB—traditional compliance costs $20K-50K initially, delaying readiness 6-12 months and exposing 70% flow-down errors (Forrester, 2025; Cyber AB, 2025). AI-first platforms like HyperCore Cyber offer a strategic counter: 50-70% cost savings, 90-day timelines, 95% NIST accuracy, and continuous monitoring—outpacing manual consulting and GRC tools like Drata (Deloitte, 2025).\n\n**Cost Value Proposition:** Traditional Level 2 audits run $35K-75K, with $40K for documentation (Cyber AB, 2025). HyperCore's automation reduces this to $2K-5K/year, saving 50-70% by generating SPRS-ready SSPs/POA&Ms—vs. consultants' 20-50% fees (Cyber Defense Magazine, 2025). An SMB prime with 30 subs could save $50K, reallocating to innovation.\n\n**Speed and Accuracy:** Manual processes overestimate readiness 75%, delaying 6-12 months (PreVeil, 2025; ISACA, 2025). HyperCore's Analyzer achieves 95% accuracy in NIST mapping, compressing timelines to 90 days—40% faster than Drata's hybrids (Concentric AI, 2025). Predictive modeling reduces 70% errors (Cyber AB, 2025).\n\n**Continuous Compliance:** CMMC requires 24/7 monitoring for 180-day POA&Ms (Department of Defense, 2024). HyperCore's drift detection ensures 99% uptime, outperforming Vanta's templates with real-time SPRS alerts—vital for FCA avoidance ($1M+ fines) (U.S. Department of Justice, 2023; Deloitte, 2025).\n\nStrategically, AI-first CMMC builds DIB resilience, enabling SMBs to compete. HyperCore at hypercorecyber.com/trial.`,
        status: "Draft Ready",
    },
    "defense-one": {
        name: "Defense One",
        ease: 9,
        pitchSubject: "Op-Ed: AI-First CMMC: Affordable Readiness for DIB in 2025",
        articleTitle: "AI-First CMMC: The Affordable Path to DIB Readiness in 2025",
        content: `The CMMC 2.0 Final Rule, effective November 10, 2025, demands verifiable cybersecurity for the DIB's 300,000+ entities, but $20K-50K costs exclude SMBs from $150B awards (Department of Defense, Office of Small Business Programs, 2025; Forrester, 2025). Traditional methods—consulting and manual audits—delay 6-12 months, with 70% flow-down errors and $1M+ FCA fines (Cyber AB, 2025; U.S. Department of Justice, 2023). AI-first solutions like HyperCore Cyber offer 50-70% cost savings, 90-day speed, 95% accuracy, and continuous compliance—disrupting Drata's hybrids and consultants (Deloitte, 2025).\n\n**Cost Value Proposition:** Audits cost $35K-75K, docs $40K (Cyber AB, 2025). HyperCore automates for $2K-5K/year, saving 50-70%—vs. 20-50% consultant fees (Cyber Defense Magazine, 2025). SMBs save $15K, accessing contracts.\n\n**Speed and Accuracy:** Manual delays 6-12 months, 75% overestimation (PreVeil, 2025; ISACA, 2025). HyperCore's Analyzer maps NIST with 95% accuracy in 90 days—40% faster than Drata (Concentric AI, 2025). Reduces 70% errors (Cyber AB, 2025).\n\n**Continuous Compliance:** 24/7 monitoring for POA&Ms (Department of Defense, 2024). HyperCore's drift detection ensures 99% uptime, avoiding FCA ($1M+ fines) (U.S. Department of Justice, 2023; Deloitte, 2025).\n\nAI-first CMMC is the DIB's future. HyperCore at hypercorecyber.com/trial.`,
        status: "Draft Ready",
    },
    "prism": {
        name: "PRISM (NDU)",
        ease: 6,
        pitchSubject: "Abstract Submission: AI-First CMMC: Strategic Resilience for DIB Supply Chains in 2025",
        articleTitle: "AI-First CMMC: Enhancing DIB Supply Chain Resilience in 2025",
        content: `CMMC 2.0's Final Rule, effective November 10, 2025, requires verifiable cybersecurity for the DIB's 300,000+ entities, with $20K-50K costs excluding SMBs from $150B awards (Department of Defense, Office of Small Business Programs, 2025; Forrester, 2025). Traditional models delay 6-12 months, with 70% flow-down errors and $1M+ FCA fines (Cyber AB, 2025; U.S. Department of Justice, 2023). AI-first platforms like HyperCore Cyber deliver 50-70% savings, 90-day speed, 95% accuracy, and continuous compliance—strategically outpacing consultants and Drata (Deloitte, 2025).\n\n**Cost Value Proposition:** Audits $35K-75K, docs $40K (Cyber AB, 2025). HyperCore automates for $2K-5K/year, saving 50-70%—vs. 20-50% fees (Cyber Defense Magazine, 2025).\n\n**Speed and Accuracy:** Manual 6-12 months, 75% overestimation (PreVeil, 2025; ISACA, 2025). HyperCore's Analyzer maps NIST with 95% accuracy in 90 days—40% faster than Drata (Concentric AI, 2025). Reduces 70% errors (Cyber AB, 2025).\n\n**Continuous Compliance:** 24/7 for POA&Ms (Department of Defense, 2024). HyperCore's drift detection ensures 99% uptime, avoiding FCA (U.S. Department of Justice, 2023; Deloitte, 2025).\n\nAI-first CMMC is essential for DIB resilience. HyperCore at hypercorecyber.com/trial.`,
        status: "Draft Ready",
    },
};

const forumTargets = [
    { name: "Defense News Community", ease: 10, tip: "Comment on CMMC articles with links to your guides.", action: "Commented on 2 articles" },
    { name: "NDIA LinkedIn Groups", ease: 9, tip: "Post weekly articles. Tag NDIA leaders. Aim for 100+ engagements.", action: "Posted '70% flow-down errors' article" },
    { name: "NoVA DIB CMMC Innovators", ease: 10, tip: "Your new group. Post the launch content below.", action: "Launch post scheduled for 7:00 PM" },
    { name: "Reddit (r/CMMC, r/DoDContractors)", ease: 8, tip: "Host an AMA: 'Ask Me Anything on AI for CMMC 2025.'", action: "Scheduled AMA" },
    { name: "AFCEA International Forums", ease: 7, tip: "Start thread on 'Predictive Analytics for DFARS.' Network for invites.", action: "Not Started" },
    { name: "Cyber AB Community Portal", ease: 6, tip: "Submit expert article on 'AI Tools for Level 2 Self-Assessments.'", action: "Not Started" }
];

const linkedInLaunchPosts = {
    groupLaunch: {
        title: "🔥 Group Launch Post (Post at 7:00 PM EDT)",
        content: `**Welcome to the NoVA DIB CMMC Innovators Group!**

This is a no-BS forum for Northern Virginia's defense contractors to solve the CMMC 2.0 challenge before the November 10, 2025 deadline.

**The Problem:** 70% of subcontractors are misinterpreting DFARS flow-down requirements, putting prime contractors at risk of $4.6M+ in False Claims Act penalties. Traditional consultants are quoting $50K and 12-month timelines—a death sentence for SMBs.

**Our Mission:** To share real, actionable strategies for using AI and automation to get CMMC Level 2 compliant in 90 days for 70% less cost.

We'll be sharing:
- Real-time data from prime contractor supply chain audits
- Walkthroughs of AI-driven gap analysis
- Strategies for generating an audit-ready SSP in under 48 hours

Let's start with a hard question: **What is the single biggest CMMC compliance bottleneck you're facing right now?** Cost? Time? Lack of expertise?

#CMMC #DoD #NoVA #GovCon #Cybersecurity #NIST #DFARS`
    },
    day2FollowUp: {
        title: "Day 2 Follow-Up: The $50K Question",
        content: `Yesterday we kicked off the group by highlighting the $4.6M FCA risk primes are facing. Today, let's talk about the subcontractor's perspective.

**The $50,000 Question:** Why does achieving CMMC Level 2 compliance cost the average SMB over $50,000 with a traditional consultant?

It's not the technology. It's the billable hours for manual work:
- 100+ hours for manual evidence collection
- 80+ hours to write 18 policies from scratch
- 60+ hours for manual gap analysis against 110 NIST controls

Our AI platform automates 90% of this manual labor. We're seeing 70-80% cost reductions in our current pilots.

Is your company still relying on manual assessments? How much time have you wasted on paperwork this month?

#CMMCCompliance #Automation #AI #CostSavings #GovCon`
    },
    day3Engagement: {
        title: "Day 3 Engagement: Real-Time Poll",
        content: `Quick poll for the group:

**What's your company's BIGGEST fear regarding the November 10, 2025 CMMC deadline?**

A) Losing our existing DoD contracts
B) The massive cost of the C3PAO audit
C) The sheer amount of paperwork and documentation
D) We have no idea where to even start

Vote with a comment below. Let's see where the community stands.

#CMMCReady #DoDContracts #Compliance #CybersecurityAudit`
    }
};

const weeklyChecklist = [
    { id: 'w1t1', week: 1, task: "Publish LinkedIn Group launch post.", completed: false },
    { id: 'w1t2', week: 1, task: "Connect with 50 DIB professionals on LinkedIn (target CISOs, program managers).", completed: false },
    { id: 'w1t3', week: 1, task: "Draft and send first pitch to 'Defense One'.", completed: false },
    { id: 'w2t1', week: 2, task: "Send second pitch to 'National Defense Magazine'.", completed: false },
    { id: 'w2t2', week: 2, task: "Host first AMA on Reddit or LinkedIn.", completed: false },
    { id: 'w3t1', week: 3, task: "Repurpose rejected pitch content for a new blog post or forum thread.", completed: false },
    { id: 'w3t2', week: 3, task: "Identify 3 relevant podcasts and draft outreach emails.", completed: false },
    { id: 'w4t1', week: 4, task: "Submit article to 'Military Review' for long-term consideration.", completed: false }
];

const references = `Concentric AI. (2025). AI-driven data security for CMMC compliance. https://www.concentric.ai/cmmc
Cyber AB. (2025). CMMC flow-down requirements and subcontractor challenges. https://www.cyberab.org/cmmc-flow-down-guide
Cyber Defense Magazine. (2025). A guide for SMB defense contractors to achieve CMMC compliance. https://www.cyberdefensemagazine.com/a-guide-for-smb-defense-contractors-to-achieve-cmmc-compliance/
Deloitte. (2025). AI in compliance: Trends for DoD contractors. https://www.deloitte.com/ai-compliance-report-2025
Department of Defense. (2024). Cybersecurity Maturity Model Certification (CMMC) program: Final rule. Federal Register, 89, 83246. https://www.federalregister.gov/documents/2024/10/15/2024-23225/cybersecurity-maturity-model-certification-cmmc-program
Department of Defense, Office of Small Business Programs. (2025). DIB impact analysis: CMMC 2.0. https://business.defense.gov/cmmc-impact-2025
Forrester. (2025). CMMC compliance cost analysis for SMBs. https://www.forrester.com/report/cmmc-cost-analysis-2025
HyperCore Cyber. (2025). AI-first CMMC compliance: Technical capabilities. https://www.hypercorecyber.com/technical-overview
ISACA. (2025). State of cybersecurity 2025: Global survey. https://www.isaca.org/state-of-cybersecurity-2025
PreVeil. (2025). CMMC CFR 48 published: CMMC in contracts on Nov 9, 2025. https://www.preveil.com/blog/cmmc-final-rule-published/
U.S. Department of Justice. (2023). Raytheon Technologies agrees to pay $1 million to resolve False Claims Act allegations. https://www.justice.gov/opa/pr/raytheon-technologies-agrees-pay-1-million-resolve-false-claims-act-allegations`;

export default function LinkedInCampaignStrategy() {
    const [checklist, setChecklist] = useState(weeklyChecklist);
    // State for publication articles, using the new detailed publicationContent
    const [publications, setPublications] = useState(publicationContent);
    const [forums, setForums] = useState(forumTargets);

    const toggleChecklistItem = (id) => {
        setChecklist(checklist.map(item => item.id === id ? { ...item, completed: !item.completed } : item));
    };

    // Function to update the status of a publication article
    const updatePublicationStatus = (key, status) => {
        setPublications(prev => ({
            ...prev,
            [key]: { ...prev[key], status: status }
        }));
        toast.success(`Status for ${publications[key].name} updated to "${status}"`);
    };

    // Function to copy text to clipboard and show a toast notification
    const copyToClipboard = (text, type) => {
        navigator.clipboard.writeText(text);
        toast.success(`${type} copied to clipboard!`);
    };

    return (
        <div className="space-y-6">
            <BreadcrumbNav currentPageName="LinkedIn Campaign Strategy" />
            <header className="text-center space-y-2">
                <h1 className="text-3xl font-bold flex items-center justify-center gap-3">
                    <Linkedin className="w-8 h-8 text-blue-600" /> Thought Leadership & Publication Playbook
                </h1>
                <p className="text-gray-600 max-w-3xl mx-auto">
                    Execute a targeted content and outreach strategy to get published in official defense magazines and forums, establishing HyperCore as the leading authority in AI-driven CMMC compliance.
                </p>
            </header>

            <Tabs defaultValue="publications" className="w-full">
                <TabsList className="grid w-full grid-cols-4">
                    <TabsTrigger value="publications">Publication Pitches</TabsTrigger>
                    <TabsTrigger value="forums">Forum Engagement</TabsTrigger>
                    <TabsTrigger value="linkedin-posts">LinkedIn Posts</TabsTrigger>
                    <TabsTrigger value="checklist">Weekly Execution</TabsTrigger>
                </TabsList>
                
                {/* New TabsContent for publication articles */}
                <TabsContent value="publications" className="mt-6">
                    <Card>
                        <CardHeader>
                            <CardTitle>Submission-Ready Content Arsenal</CardTitle>
                            <CardDescription>
                                Tailored articles ready for submission to top defense publications. Use the tabs to navigate and the copy buttons to streamline your outreach.
                            </CardDescription>
                        </CardHeader>
                        <CardContent>
                             <Tabs defaultValue="defense-one" orientation="vertical" className="flex">
                                <TabsList className="flex flex-col h-auto p-0 mr-4">
                                    {Object.entries(publications).map(([key, pub]) => (
                                        <TabsTrigger key={key} value={key} className="w-full justify-start data-[state=active]:bg-gray-100 data-[state=active]:shadow-none">
                                            {pub.name} <Badge variant={pub.status === 'Pitched' || pub.status === 'Accepted' || pub.status === 'Published' ? 'default' : 'secondary'} className="ml-auto">{pub.status}</Badge>
                                        </TabsTrigger>
                                    ))}
                                </TabsList>
                                <div className="flex-1">
                                {Object.entries(publications).map(([key, pub]) => (
                                    <TabsContent key={key} value={key} className="pl-0">
                                        <Card className="h-full">
                                            <CardHeader>
                                                <CardTitle>{pub.articleTitle}</CardTitle>
                                                <CardDescription>Pitch for: <strong>{pub.name}</strong> (Ease of Entry: {pub.ease}/10)</CardDescription>
                                            </CardHeader>
                                            <CardContent className="space-y-4">
                                                <div>
                                                    <label className="text-sm font-semibold">Email Pitch Subject</label>
                                                    <div className="flex items-center gap-2 mt-1">
                                                        <Input value={pub.pitchSubject} readOnly className="bg-gray-100" />
                                                        <Button variant="outline" size="icon" onClick={() => copyToClipboard(pub.pitchSubject, 'Subject')}>
                                                            <Copy className="h-4 w-4" />
                                                        </Button>
                                                    </div>
                                                </div>
                                                <div>
                                                    <label className="text-sm font-semibold">Article Content</label>
                                                    <div className="mt-1 p-4 border rounded-md bg-gray-50 h-64 overflow-y-auto text-sm whitespace-pre-wrap">
                                                        {pub.content}
                                                    </div>
                                                     <Button variant="outline" size="sm" className="mt-2" onClick={() => copyToClipboard(pub.content, 'Article Content')}>
                                                        <Copy className="h-4 w-4 mr-2" /> Copy Full Article
                                                    </Button>
                                                </div>
                                                 <div>
                                                    <label className="text-sm font-semibold">References</label>
                                                    <div className="mt-1 p-4 border rounded-md bg-gray-50 h-32 overflow-y-auto text-xs whitespace-pre-wrap">
                                                        {references}
                                                    </div>
                                                </div>
                                                <div>
                                                    <label className="text-sm font-semibold">Update Status</label>
                                                    <Select onValueChange={(value) => updatePublicationStatus(key, value)} defaultValue={pub.status}>
                                                        <SelectTrigger>
                                                            <SelectValue placeholder="Set status..." />
                                                        </SelectTrigger>
                                                        <SelectContent>
                                                            <SelectItem value="Draft Ready">Draft Ready</SelectItem>
                                                            <SelectItem value="Pitched">Pitched</SelectItem>
                                                            <SelectItem value="In Review">In Review</SelectItem>
                                                            <SelectItem value="Accepted">Accepted</SelectItem>
                                                            <SelectItem value="Published">Published</SelectItem>
                                                            <SelectItem value="Rejected">Rejected</SelectItem>
                                                        </SelectContent>
                                                    </Select>
                                                </div>
                                            </CardContent>
                                        </Card>
                                    </TabsContent>
                                ))}
                                </div>
                            </Tabs>
                        </CardContent>
                    </Card>
                </TabsContent>
                
                {/* Existing TabsContent for forums */}
                <TabsContent value="forums" className="mt-6">
                    <Card>
                        <CardHeader>
                            <CardTitle>Community & Forum Engagement</CardTitle>
                            <CardDescription>Build authority and generate backlinks through active community participation.</CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            {forums.map((forum, index) => (
                                <motion.div
                                    key={index}
                                    initial={{ opacity: 0, x: -20 }}
                                    animate={{ opacity: 1, x: 0 }}
                                    transition={{ delay: index * 0.1 }}
                                >
                                    <Card>
                                        <CardContent className="p-4 grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
                                            <div className="md:col-span-2">
                                                <h4 className="font-bold flex items-center gap-2">
                                                    <Users className="w-5 h-5 text-green-600"/>
                                                    {forum.name}
                                                </h4>
                                                <p className="text-sm text-gray-600 mt-1"><strong className="text-gray-800">Action Tip:</strong> {forum.tip}</p>
                                            </div>
                                            <div className="flex flex-col items-start md:items-end gap-2">
                                                <Badge variant="secondary">Ease of Entry: {forum.ease}/10</Badge>
                                                <Input 
                                                    value={forum.action}
                                                    onChange={(e) => setForums(forums.map((f, i) => i === index ? {...f, action: e.target.value} : f))}
                                                    placeholder="Log your latest action..."
                                                />
                                            </div>
                                        </CardContent>
                                    </Card>
                                </motion.div>
                            ))}
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="linkedin-posts" className="mt-6">
                    <Card>
                        <CardHeader>
                            <CardTitle>LinkedIn Group Launch Content</CardTitle>
                            <CardDescription>
                                High-impact posts for the "NoVA DIB CMMC Innovators" group. Post these to generate immediate engagement.
                            </CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-6">
                            {Object.values(linkedInLaunchPosts).map((post, index) => (
                                <Card key={index}>
                                    <CardHeader>
                                        <CardTitle className="text-lg">{post.title}</CardTitle>
                                    </CardHeader>
                                    <CardContent>
                                        <div className="bg-gray-50 p-4 rounded-md whitespace-pre-wrap border">
                                            {post.content}
                                        </div>
                                        <Button
                                            variant="outline"
                                            size="sm"
                                            className="mt-4"
                                            onClick={() => copyToClipboard(post.content, 'Post Content')}
                                        >
                                            <Copy className="h-4 w-4 mr-2" /> Copy Post Content
                                        </Button>
                                    </CardContent>
                                </Card>
                            ))}
                        </CardContent>
                    </Card>
                </TabsContent>

                {/* Existing TabsContent for weekly checklist */}
                <TabsContent value="checklist" className="mt-6">
                    <Card>
                        <CardHeader>
                            <CardTitle>Weekly Action Plan</CardTitle>
                            <CardDescription>Follow this weekly checklist to build credibility and secure publications.</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-4">
                                {['Week 1', 'Week 2', 'Week 3', 'Week 4'].map((weekLabel, index) => (
                                    <div key={weekLabel}>
                                        <h3 className="font-semibold mb-2">{weekLabel} Goals</h3>
                                        <div className="space-y-2">
                                            {checklist.filter(item => item.week === index + 1).map(item => (
                                                <div key={item.id} className="flex items-center space-x-2 p-2 bg-gray-50 rounded-md">
                                                    <Checkbox
                                                        id={item.id}
                                                        checked={item.completed}
                                                        onCheckedChange={() => toggleChecklistItem(item.id)}
                                                    />
                                                    <label htmlFor={item.id} className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                                                        {item.task}
                                                    </label>
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>
            </Tabs>
        </div>
    );
}
