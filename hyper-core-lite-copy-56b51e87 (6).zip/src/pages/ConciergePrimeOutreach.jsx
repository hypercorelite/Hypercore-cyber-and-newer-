
import React, { useState, useEffect } from 'react';
import { PrimeContractorLead } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Mail, CheckCircle, Clock, DollarSign, Users, Loader2, Target, Rocket, Zap, ExternalLink } from 'lucide-react';
import { toast } from 'sonner';
import { sendTargetedPrimeEmail } from '@/api/functions';
import BreadcrumbNav from '../components/navigation/BreadcrumbNav';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

const primes = [
    { company_name: "SAIC", contact_person: "Michael Daniels", contact_email: "michael.daniels@saic.com", subcontractor_count: 750, estimated_fca_risk: 4600000, pilot_value: 75000, priority: 'critical' },
    { company_name: "General Dynamics IT (GDIT)", contact_person: "Daniel Johnson", contact_email: "daniel.johnson@gdit.com", subcontractor_count: 500, estimated_fca_risk: 3500000, pilot_value: 60000, priority: 'critical' },
    { company_name: "Leidos", contact_person: "Gerry Fasano", contact_email: "gerry.fasano@leidos.com", subcontractor_count: 1000, estimated_fca_risk: 5000000, pilot_value: 100000, priority: 'high' },
    { company_name: "Booz Allen Hamilton", contact_person: "Karen Dahut", contact_email: "karen.dahut@bah.com", subcontractor_count: 800, estimated_fca_risk: 4000000, pilot_value: 80000, priority: 'high' },
    { company_name: "Systems Planning & Analysis (SPA)", contact_person: "Mark Testoni", contact_email: "mark.testoni@spa.com", subcontractor_count: 200, estimated_fca_risk: 1500000, pilot_value: 35000, priority: 'medium' }
];

export default function ConciergePrimeOutreach() {
    const [leads, setLeads] = useState([]);
    const [loading, setLoading] = useState(true);
    const [sendingEmailId, setSendingEmailId] = useState(null);

    useEffect(() => {
        const initializeLeads = async () => {
            setLoading(true);
            try {
                let existingLeads = await PrimeContractorLead.list();
                const existingCompanies = new Set(existingLeads.map(l => l.company_name));

                const newLeadsData = primes.filter(p => !existingCompanies.has(p.company_name));
                if (newLeadsData.length > 0) {
                    await PrimeContractorLead.bulkCreate(newLeadsData.map(p => ({
                        ...p,
                        outreach_status: 'target',
                        ab_test_version: Math.random() < 0.5 ? 'A' : 'B' // Assign A/B randomly for new leads
                    })));
                }
                
                const allLeads = await PrimeContractorLead.list({sort: '-priority'});
                setLeads(allLeads);
            } catch (error) {
                toast.error("Failed to load or create prime leads.");
                console.error(error);
            } finally {
                setLoading(false);
            }
        };
        initializeLeads();
    }, []);

    const handleSendEmail = async (lead) => {
        setSendingEmailId(lead.id);
        toast.info(`Sending targeted email to ${lead.company_name}...`);
        try {
            const { data } = await sendTargetedPrimeEmail({ primeTarget: lead });
            if (data.success) {
                toast.success(data.message);
                const updatedLeads = await PrimeContractorLead.list({sort: '-priority'});
                setLeads(updatedLeads);
            } else {
                throw new Error(data.error || 'Failed to send email.');
            }
        } catch (error) {
            toast.error(`Failed to send email to ${lead.company_name}: ${error.message}`);
        } finally {
            setSendingEmailId(null);
        }
    };

    const statusBadge = (status, abTestVersion) => {
        const versionBadge = abTestVersion ? (
            <Badge variant="secondary" className="ml-2 text-xs">v{abTestVersion}</Badge>
        ) : null;

        let mainBadge;
        switch (status) {
            case 'contacted': 
                mainBadge = <Badge variant="default" className="bg-blue-600">Contacted</Badge>;
                break;
            case 'demo_scheduled': 
                mainBadge = <Badge variant="default" className="bg-green-600">Demo Scheduled</Badge>;
                break;
            case 'closed_won': 
                mainBadge = <Badge variant="default" className="bg-purple-600">Pilot Active</Badge>;
                break;
            case 'target': 
                mainBadge = <Badge variant="outline">Target</Badge>;
                break;
            default: 
                mainBadge = <Badge variant="secondary">{status}</Badge>;
                break;
        }

        return <div className="flex items-center">{mainBadge}{versionBadge}</div>;
    };

    if (loading) {
        return <div className="flex items-center justify-center h-64"><Loader2 className="w-8 h-8 animate-spin" /></div>;
    }

    return (
        <div className="space-y-6">
            <BreadcrumbNav currentPageName="ConciergePrimeOutreach" />
            <div className="text-center">
                <h1 className="text-3xl font-bold text-gray-900 flex items-center justify-center gap-3">
                    <Rocket className="w-8 h-8 text-blue-600" />
                    Prime Contractor "Compliance Concierge" Outreach
                </h1>
                <p className="text-lg text-gray-600 mt-2">
                    Execute the "Compliance Concierge" campaign to secure 2-3 prime pilots by derisking their supply chains.
                </p>
            </div>

            <Alert className="bg-green-50 border-green-200">
                <Zap className="h-5 w-5 text-green-700" />
                <AlertTitle className="font-bold text-green-800">Your Unfair Advantage is LIVE</AlertTitle>
                <AlertDescription className="text-green-700">
                    Your 100% Level 3 accuracy validation is now embedded in the outreach email. Each email sent from this dashboard includes verifiable proof of your platform's superiority. Click "Send Outreach Email" to execute.
                </AlertDescription>
            </Alert>
            
            <Card>
                <CardHeader>
                    <CardTitle>Top 5 NoVA Prime Targets</CardTitle>
                    <CardDescription>
                        These primes control 80% of DIB contracts in the region. One deal can secure 50+ SMB clients.
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Prime Contractor</TableHead>
                                <TableHead>Contact</TableHead>
                                <TableHead>FCA Risk</TableHead>
                                <TableHead>Status</TableHead>
                                <TableHead>Action</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {leads.map((lead) => (
                                <TableRow key={lead.id}>
                                    <TableCell>
                                        <div className="font-medium">{lead.company_name}</div>
                                        <div className="text-sm text-gray-500">{lead.subcontractor_count} Subs</div>
                                    </TableCell>
                                    <TableCell>
                                        <div>{lead.contact_person}</div>
                                        <a href={`mailto:${lead.contact_email}`} className="text-xs text-blue-600 hover:underline">{lead.contact_email}</a>
                                    </TableCell>
                                    <TableCell className="font-mono text-red-600">${(lead.estimated_fca_risk / 1000000).toFixed(1)}M</TableCell>
                                    <TableCell>{statusBadge(lead.outreach_status, lead.ab_test_version)}</TableCell>
                                    <TableCell>
                                        <Button
                                            onClick={() => handleSendEmail(lead)}
                                            disabled={sendingEmailId === lead.id || lead.outreach_status !== 'target'}
                                            size="sm"
                                        >
                                            {sendingEmailId === lead.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <Mail className="w-4 h-4 mr-2" />}
                                            Send Outreach Email
                                        </Button>
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </CardContent>
            </Card>
        </div>
    );
}
