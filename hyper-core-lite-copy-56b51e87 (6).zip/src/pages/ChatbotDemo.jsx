
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Bot, MessageSquare, Zap, Shield, Target } from 'lucide-react';
// HyperCoreChatbot import removed, it's now global
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";

export default function ChatbotDemo() {
    // State management for chatbot is removed, as it's now handled globally in Layout.js
    
    const sampleQuestions = [
        "What are the key DFARS 252.204-7012 requirements?",
        "How does CMMC Level 2 differ from Level 1?",
        "What NIST 800-171 controls are most critical?",
        "How can HyperCore's AI tools help with compliance?",
        "What's the typical cost of CMMC compliance?",
        "How do I handle flow-down requirements from primes?"
    ];

    return (
        <div className="space-y-8">
            <BreadcrumbNav currentPageName="Chatbot Demo" />

            <div className="text-center">
                <h1 className="text-4xl font-bold text-gray-900 mb-4">
                    HyperCore AI Assistant Demo
                </h1>
                <p className="text-xl text-gray-600 max-w-4xl mx-auto">
                    Experience our AI-powered chatbot trained on DFARS/CMMC compliance. Get instant, personalized answers to your defense contractor questions.
                </p>
            </div>

            <Alert className="bg-green-50 border-green-200">
                <Bot className="h-5 w-5 text-green-600" />
                <AlertTitle className="text-green-800 font-bold">Live AI Assistant</AlertTitle>
                <AlertDescription className="text-green-700">
                    This is a fully functional AI chatbot powered by HyperCore's infrastructure. It knows about your organization and can provide personalized compliance guidance.
                </AlertDescription>
            </Alert>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <Card>
                    <CardHeader>
                        <MessageSquare className="h-8 w-8 text-blue-600 mb-2" />
                        <CardTitle>DFARS Expertise</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-gray-600">
                            Trained on the latest DFARS requirements, flow-down clauses, and compliance strategies specifically for defense contractors.
                        </p>
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader>
                        <Shield className="h-8 w-8 text-green-600 mb-2" />
                        <CardTitle>CMMC Level 2 Ready</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-gray-600">
                            Understands all 110 NIST SP 800-171 controls and can guide you through CMMC 2.0 preparation and certification.
                        </p>
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader>
                        <Target className="h-8 w-8 text-purple-600 mb-2" />
                        <CardTitle>Personalized Guidance</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-gray-600">
                            Knows your organization type and role to provide relevant, actionable advice tailored to your specific situation.
                        </p>
                    </CardContent>
                </Card>
            </div>

            <Card>
                <CardHeader>
                    <CardTitle>Try These Sample Questions</CardTitle>
                    <CardDescription>
                        Click any question below to start a conversation with the AI assistant in the bottom-right corner.
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {sampleQuestions.map((question, index) => (
                            <Button
                                key={index}
                                variant="outline"
                                className="justify-start text-left h-auto p-4"
                                // The onClick here is now a visual cue. The user interacts with the global chatbot.
                            >
                                <span className="text-sm">{question}</span>
                            </Button>
                        ))}
                    </div>
                </CardContent>
            </Card>

            <div className="text-center">
                <p className="text-gray-600 mb-4">Click the bot icon in the bottom-right corner to open the chat window.</p>
            </div>

            <Alert className="bg-blue-50 border-blue-200">
                <Zap className="h-5 w-5 text-blue-600" />
                <AlertTitle className="text-blue-800 font-bold">Integration Ready</AlertTitle>
                <AlertDescription className="text-blue-700">
                    This chatbot can be embedded on any page of your website. It maintains conversation context and can escalate complex issues to human experts when needed.
                </AlertDescription>
            </Alert>

            {/* The HyperCoreChatbot component instance is removed from here. */}
        </div>
    );
}
