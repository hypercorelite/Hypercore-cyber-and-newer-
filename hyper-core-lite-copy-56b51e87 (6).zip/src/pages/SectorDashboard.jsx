
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"; // Corrected syntax here
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AuditLog } from "@/api/entities";
import { TestingLog } from "@/api/entities";
import {
    Zap,
    Shield,
    Satellite,
    Landmark,
    Server,
    Banknote,
    Rocket, // Added Rocket icon for the new button
    Download,
    Eye,
    EyeOff
} from 'lucide-react';
import { motion } from "framer-motion";

const SECTOR_CONFIGURATIONS = {
    energy_utilities: {
        title: "Energy & Utilities Demonstration",
        icon: Zap,
        color: "from-yellow-500 to-orange-500",
        description: "AI-Powered Grid Security & Operational Intelligence",
        demo_capabilities: [
            "NERC-CIP Compliance Automation",
            "Grid Vulnerability Prediction",
            "OT/IT Security Convergence",
            "Energy-for-Security Partnerships"
        ],
        sample_metrics: {
            threats_blocked: "2,847",
            compliance_automation: "89%",
            grid_uptime: "99.97%",
            cost_savings: "$2.1M"
        }
    },
    defense_contractor: {
        title: "Defense Contractor Demonstration",
        icon: Shield,
        color: "from-blue-600 to-indigo-600",
        description: "CMMC Assessment & DoD Contract Readiness",
        demo_capabilities: [
            "Automated CMMC Level 2/3 Assessment",
            "System Security Plan Generation",
            "Continuous Compliance Monitoring",
            "Audit Trail Management"
        ],
        sample_metrics: {
            cmmc_domains: "17/17",
            compliance_score: "94%",
            audit_readiness: "12 days",
            cost_reduction: "$150K"
        }
    },
    insurance_carrier: {
        title: "Insurance Carrier Demonstration",
        icon: Shield,
        color: "from-green-500 to-emerald-500",
        description: "AI-Powered Risk Assessment & Underwriting",
        demo_capabilities: [
            "Real-time Cyber Risk Scoring",
            "Premium Optimization Analysis",
            "Claims Prediction Modeling",
            "Portfolio Risk Assessment"
        ],
        sample_metrics: {
            risk_accuracy: "96.2%",
            loss_ratio_improvement: "23%",
            underwriting_speed: "80% faster",
            portfolio_value: "$50M+"
        }
    },
    municipal_government: {
        title: "Municipal Government Demonstration",
        icon: Landmark,
        color: "from-purple-500 to-violet-500",
        description: "Cyber-Financial Risk & Bond Rating Protection",
        demo_capabilities: [
            "Municipal Cyber Risk Assessment",
            "Bond Rating Impact Analysis",
            "Critical Infrastructure Protection",
            "Regulatory Compliance Automation"
        ],
        sample_metrics: {
            cyber_resilience_score: "87/100",
            bond_rating_protection: "AA+ maintained",
            infrastructure_coverage: "100%",
            annual_savings: "$1.8M"
        }
    },
    telecom_satcom: {
        title: "Telecom & Satellite Communications",
        icon: Satellite,
        color: "from-cyan-500 to-blue-500",
        description: "5G Security & Satellite Constellation Protection",
        demo_capabilities: [
            "Real-time Network Threat Detection",
            "5G Security Validation",
            "Satellite Communication Security",
            "Spectrum Interference Detection"
        ],
        sample_metrics: {
            network_uptime: "99.99%",
            threat_detection_speed: "< 60 seconds",
            spectrum_efficiency: "15% improvement",
            security_incidents: "Zero breaches"
        }
    },
    data_centers: {
        title: "Data Center & Cloud Infrastructure",
        icon: Server,
        color: "from-gray-600 to-slate-600",
        description: "Hyperscale Security & Operational Intelligence",
        demo_capabilities: [
            "Multi-Tenant Security Isolation",
            "Predictive Infrastructure Monitoring",
            "Automated Incident Response",
            "Compliance Across Regulations"
        ],
        sample_metrics: {
            uptime_guarantee: "99.995%",
            security_incidents: "Zero in 18 months",
            energy_efficiency: "25% improvement",
            tenant_satisfaction: "98.7%"
        }
    }
};

const SeedDataButton = ({ onDataSeeded }) => {
    const [isLoading, setIsLoading] = useState(false);
    const [isSuccess, setIsSuccess] = useState(false);
    const [error, setError] = useState(null);

    const sampleAuditLogs = [
        {
            user_email: "alice@example.com",
            event_name: "Grid Sensor Data Accessed",
            status: "SUCCESS",
            client_type: "internal_ops",
            sector_category: "energy_utilities",
            details: JSON.stringify({ resource: "Sensor_2345", action: "READ", source_ip: "192.168.1.10" }),
            demonstration_safe: true,
            created_date: new Date().toISOString()
        },
        {
            user_email: "bob@example.com",
            event_name: "CMMC Assessment Generated",
            status: "SUCCESS",
            client_type: "demo_prospect",
            sector_category: "defense_contractor",
            details: JSON.stringify({ assessment_id: "CMMC-2023-001", level: "L3" }),
            demonstration_safe: true,
            created_date: new Date(Date.now() - 60000).toISOString()
        },
        {
            user_email: "charlie@example.com",
            event_name: "Risk Profile Updated",
            status: "SUCCESS",
            client_type: "partner_api",
            sector_category: "insurance_carrier",
            details: JSON.stringify({ policy_id: "POL-7890", risk_score_change: "+5" }),
            demonstration_safe: true,
            created_date: new Date(Date.now() - 120000).toISOString()
        },
        {
            user_email: "diana@example.com",
            event_name: "Budget System Access Attempt",
            status: "FAILED",
            client_type: "external_consultant",
            sector_category: "municipal_government",
            details: JSON.stringify({ system: "Financial_Ledger", reason: "Unauthorized IP" }),
            demonstration_safe: true,
            created_date: new Date(Date.now() - 180000).toISOString()
        },
        {
            user_email: "eve@example.com",
            event_name: "5G Network Configuration Change",
            status: "SUCCESS",
            client_type: "internal_dev",
            sector_category: "telecom_satcom",
            details: JSON.stringify({ component: "5G_Core_Router_1", change_type: "firmware_update" }),
            demonstration_safe: true,
            created_date: new Date(Date.now() - 240000).toISOString()
        },
        {
            user_email: "frank@example.com",
            event_name: "Virtual Machine Provisioned",
            status: "SUCCESS",
            client_type: "client_portal",
            sector_category: "data_centers",
            details: JSON.stringify({ vm_id: "DC-VM-001", region: "us-east-1" }),
            demonstration_safe: true,
            created_date: new Date(Date.now() - 300000).toISOString()
        },
        {
            user_email: "grace@example.com",
            event_name: "NERC-CIP Scan Initiated",
            status: "SUCCESS",
            client_type: "demo_prospect",
            sector_category: "energy_utilities",
            details: JSON.stringify({ scan_type: "vulnerability", target: "Substation_Alpha" }),
            demonstration_safe: true,
            created_date: new Date(Date.now() - 360000).toISOString()
        }
    ];

    const sampleTestingLogs = [
        {
            test_name: "Energy_Utilities_Load_Test_Grid_Sensors",
            status: "PASSED",
            run_by: "Automated Performance Suite",
            parameters: JSON.stringify({ concurrent_users: 500, test_duration_min: 10, data_points_per_sec: 1000 }),
            results_summary: JSON.stringify({ avg_latency_ms: 75, max_latency_ms: 120, throughput_ops_sec: 980, error_rate_percent: 0.01 }),
            created_date: new Date().toISOString()
        },
        {
            test_name: "Defense_Contractor_CMMC_Compliance_Simulation",
            status: "PASSED",
            run_by: "Security Validation Team",
            parameters: JSON.stringify({ cmmc_level: 3, num_controls_tested: 110, num_users: 1000 }),
            results_summary: JSON.stringify({ compliance_score_percent: 97, findings_critical: 0, findings_major: 2, avg_test_time_sec: 300 }),
            created_date: new Date(Date.now() - 60000).toISOString()
        },
        {
            test_name: "Insurance_Carrier_Risk_Assessment_API_Load",
            status: "PASSED",
            run_by: "API Testing Framework",
            parameters: JSON.stringify({ requests_per_min: 2000, dataset_size_gb: 50, prediction_models: ["ML_V1", "DL_V2"] }),
            results_summary: JSON.stringify({ api_uptime_percent: 99.9, avg_response_time_ms: 250, p99_response_time_ms: 400, data_integrity_checks: "ALL_PASSED" }),
            created_date: new Date(Date.now() - 120000).toISOString()
        },
        {
            test_name: "Municipal_Government_Financial_System_Stress",
            status: "PASSED",
            run_by: "System Integration Test",
            parameters: JSON.stringify({ transactions_per_sec: 500, data_volume_gb: 20 }),
            results_summary: JSON.stringify({ database_cpu_utilization_percent: 60, transaction_success_rate_percent: 99.8 }),
            created_date: new Date(Date.now() - 180000).toISOString()
        },
        {
            test_name: "Telecom_Satcom_5G_Latency_Test",
            status: "PASSED",
            run_by: "Network Performance Lab",
            parameters: JSON.stringify({ data_packets_mbps: 100, distance_km: 50, protocol: "5G_NR" }),
            results_summary: JSON.stringify({ avg_latency_ms: 5, packet_loss_percent: 0.001, jiter_ms: 2 }),
            created_date: new Date(Date.now() - 240000).toISOString()
        },
        {
            test_name: "Data_Center_VM_Provisioning_Benchmark",
            status: "PASSED",
            run_by: "CloudOps Automation",
            parameters: JSON.stringify({ num_vms: 100, vm_size_gb: 8, storage_type: "SSD" }),
            results_summary: JSON.stringify({ avg_provisioning_time_sec: 15, success_rate_percent: 100 }),
            created_date: new Date(Date.now() - 300000).toISOString()
        }
    ];

    const handleSeedData = async () => {
        setIsLoading(true);
        setIsSuccess(false);
        setError(null);
        try {
            // Seed Audit Logs
            for (const log of sampleAuditLogs) {
                await AuditLog.create(log);
            }
            // Seed Testing Logs
            for (const log of sampleTestingLogs) {
                await TestingLog.create(log);
            }
            setIsSuccess(true);
            // Trigger data reload in parent component
            if (onDataSeeded) {
                onDataSeeded();
            }
            setTimeout(() => setIsSuccess(false), 3000); // Hide success message after 3 seconds
        } catch (err) {
            console.error("Failed to seed data:", err);
            setError("Failed to seed data. Check console for details.");
            setIsSuccess(false);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <Button onClick={handleSeedData} disabled={isLoading} className="flex items-center gap-2">
            {isLoading ? (
                <>
                    <span className="animate-spin">🚀</span> Seeding...
                </>
            ) : isSuccess ? (
                <>
                    <span className="text-green-500">✅</span> Seeded!
                </>
            ) : (
                <>
                    <Rocket className="w-4 h-4" /> Seed Demo Data
                </>
            )}
            {error && <span className="text-red-500 text-sm ml-2">{error}</span>}
        </Button>
    );
};

const DemoAuditTrail = ({ sector, logs, testingLogs }) => {
    const [showSensitiveData, setShowSensitiveData] = useState(false);

    const sectorConfig = SECTOR_CONFIGURATIONS[sector];

    if (!sectorConfig) return <div className="text-gray-400">Select a sector to view demonstration data</div>; // Changed text color

    const filteredLogs = logs.filter(log =>
        log.sector_category === sector && log.demonstration_safe
    );

    const filteredTestLogs = testingLogs.filter(log =>
        log.test_name.toLowerCase().includes(sector.split('_')[0])
    );

    return (
        <div className="space-y-6">
            {/* Sector Header */}
            <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                className={`bg-gradient-to-r ${sectorConfig.color} p-6 rounded-xl text-white`}
            >
                <div className="flex items-center gap-4">
                    <sectorConfig.icon className="w-12 h-12" />
                    <div>
                        <h2 className="text-2xl font-bold">{sectorConfig.title}</h2>
                        <p className="text-white/90">{sectorConfig.description}</p>
                    </div>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
                    {Object.entries(sectorConfig.sample_metrics).map(([key, value]) => (
                        <div key={key} className="bg-white/20 backdrop-blur-sm rounded-lg p-3">
                            <div className="text-2xl font-bold">{value}</div>
                            <div className="text-sm capitalize">{key.replace('_', ' ')}</div>
                        </div>
                    ))}
                </div>
            </motion.div>

            {/* Capabilities Matrix */}
            <Card className="bg-gray-800 text-white border-gray-700"> {/* Added dark mode styling */}
                <CardHeader>
                    <CardTitle>Demonstrated Capabilities</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {sectorConfig.demo_capabilities.map((capability, index) => (
                            <div key={index} className="flex items-center gap-2 p-3 bg-green-900/30 text-green-200 rounded-lg"> {/* Adjusted for dark mode */}
                                <Shield className="w-5 h-5 text-green-400" /> {/* Adjusted for dark mode */}
                                <span className="font-medium">{capability}</span>
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>

            {/* Performance Testing Results */}
            <Card className="bg-gray-800 text-white border-gray-700"> {/* Added dark mode styling */}
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Server className="w-5 h-5" />
                        Load Testing Results - {sectorConfig.title}
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="space-y-3">
                        {filteredTestLogs.map((test, index) => (
                            <div key={index} className="border rounded-lg p-4 bg-gray-900 border-gray-700"> {/* Adjusted for dark mode */}
                                <div className="flex justify-between items-center mb-2">
                                    <div className="font-semibold">{test.test_name}</div>
                                    <Badge>{test.status}</Badge>
                                </div>
                                <div className="text-sm text-gray-400 mb-2"> {/* Adjusted for dark mode */}
                                    Run by: {test.run_by} • {new Date(test.created_date).toLocaleString()}
                                </div>
                                <div className="grid grid-cols-2 gap-4 text-sm">
                                    <div>
                                        <strong>Parameters:</strong>
                                        <pre className="bg-gray-800 p-2 rounded text-xs mt-1 overflow-x-auto text-gray-300"> {/* Adjusted for dark mode */}
                                            {JSON.stringify(JSON.parse(test.parameters), null, 2)}
                                        </pre>
                                    </div>
                                    <div>
                                        <strong>Results Summary:</strong>
                                        <pre className="bg-gray-800 p-2 rounded text-xs mt-1 overflow-x-auto text-gray-300"> {/* Adjusted for dark mode */}
                                            {JSON.stringify(JSON.parse(test.results_summary), null, 2)}
                                        </pre>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>

            {/* Audit Trail */}
            <Card className="bg-gray-800 text-white border-gray-700"> {/* Added dark mode styling */}
                <CardHeader>
                    <div className="flex justify-between items-center">
                        <CardTitle>Sector-Specific Audit Trail</CardTitle>
                        <div className="flex items-center gap-2">
                            <Button
                                variant="outline"
                                size="sm"
                                onClick={() => setShowSensitiveData(!showSensitiveData)}
                                className="border-gray-600 text-gray-300 hover:bg-gray-700" // Adjusted for dark mode
                            >
                                {showSensitiveData ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                                {showSensitiveData ? 'Hide Details' : 'Show Details'}
                            </Button>
                            <Button size="sm" className="bg-blue-600 hover:bg-blue-700"> {/* Adjusted for dark mode */}
                                <Download className="w-4 h-4 mr-2" />
                                Export Report
                            </Button>
                        </div>
                    </div>
                    <CardDescription className="text-gray-400"> {/* Adjusted for dark mode */}
                        Demonstration-safe audit events for {sectorConfig.title}
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="space-y-3 max-h-96 overflow-y-auto">
                        {filteredLogs.map((log, index) => (
                            <div key={index} className="border rounded-lg p-4 bg-gray-900 border-gray-700"> {/* Adjusted for dark mode */}
                                <div className="flex justify-between items-center mb-2">
                                    <div className="font-semibold">{log.event_name}</div>
                                    <div className="flex gap-2">
                                        <Badge variant={log.client_type === 'demo_prospect' ? 'secondary' : 'default'}>
                                            {log.client_type}
                                        </Badge>
                                        <Badge variant={log.status === 'SUCCESS' ? 'default' : 'destructive'}>
                                            {log.status}
                                        </Badge>
                                    </div>
                                </div>
                                <div className="text-sm text-gray-400 mb-2"> {/* Adjusted for dark mode */}
                                    User: {log.user_email} • {new Date(log.created_date).toLocaleString()}
                                </div>
                                {showSensitiveData && (
                                    <div className="bg-gray-700 p-3 rounded mt-2"> {/* Adjusted for dark mode */}
                                        <strong className="text-sm text-gray-300">Event Details:</strong> {/* Adjusted for dark mode */}
                                        <pre className="text-xs mt-1 overflow-x-auto text-gray-200"> {/* Adjusted for dark mode */}
                                            {JSON.stringify(JSON.parse(log.details || '{}'), null, 2)}
                                        </pre>
                                    </div>
                                )}
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>
        </div>
    );
};

export default function SectorDashboard() {
    const [selectedSector, setSelectedSector] = useState('energy_utilities');
    const [auditLogs, setAuditLogs] = useState([]);
    const [testingLogs, setTestingLogs] = useState([]);
    const [loading, setLoading] = useState(true);
    const [showRealData, setShowRealData] = useState(true); // New state as per outline

    useEffect(() => {
        const urlParams = new URLSearchParams(window.location.search);
        const sectorFromUrl = urlParams.get('sector');
        if (sectorFromUrl && SECTOR_CONFIGURATIONS[sectorFromUrl]) {
            setSelectedSector(sectorFromUrl);
        }
    }, []);

    const loadDemoData = async () => {
        setLoading(true);
        try {
            const [logs, tests] = await Promise.all([
                AuditLog.list('-created_date', 100),
                TestingLog.list('-created_date', 50)
            ]);
            setAuditLogs(logs);
            setTestingLogs(tests);
        } catch (error) {
            console.error('Failed to load demo data:', error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        loadDemoData();
    }, [selectedSector]); // Added selectedSector to dependencies

    const currentConfig = SECTOR_CONFIGURATIONS[selectedSector]; // Defined currentConfig

    return (
        <div className="min-h-screen bg-gray-900 p-6 text-white"> {/* Changed background and text color */}
            <div className="max-w-7xl mx-auto">
                <motion.div
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="mb-8"
                >
                    <div className="flex justify-between items-start"> {/* Changed to items-start */}
                        <div>
                            <div className="flex items-center gap-3 mb-2">
                                <span className={`p-3 rounded-lg bg-gradient-to-br ${currentConfig.color}`}>
                                    <currentConfig.icon className="w-8 h-8 text-white" />
                                </span>
                                <h1 className="text-4xl font-bold">{currentConfig.title}</h1>
                            </div>
                            <p className="text-lg text-gray-400 ml-16">{currentConfig.description}</p>
                        </div>

                        {/* Combined SeedDataButton and Select into a single flex container */}
                        <div className="flex items-center gap-4">
                            <SeedDataButton onDataSeeded={loadDemoData} />
                            <Select onValueChange={setSelectedSector} value={selectedSector}>
                                <SelectTrigger className="w-[280px] bg-gray-800 border-gray-600 text-white">
                                    <SelectValue placeholder="Change Sector Demo" />
                                </SelectTrigger>
                                <SelectContent className="bg-gray-800 border-gray-600 text-white">
                                    {Object.keys(SECTOR_CONFIGURATIONS).map(key => (
                                        <SelectItem key={key} value={key} className="focus:bg-gray-700">
                                            {SECTOR_CONFIGURATIONS[key].title}
                                        </SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>
                    </div>
                </motion.div>

                {loading ? (
                    <div className="text-center py-12">
                        <div className="text-gray-400">Loading demonstration data...</div> {/* Changed text color */}
                    </div>
                ) : (
                    <DemoAuditTrail
                        sector={selectedSector}
                        logs={auditLogs}
                        testingLogs={testingLogs}
                    />
                )}
            </div>
        </div>
    );
}
