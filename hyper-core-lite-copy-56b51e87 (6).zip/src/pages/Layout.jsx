

import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { User } from '@/api/entities';
import { Button } from "@/components/ui/button";
import { 
  Shield, 
  AlertTriangle, 
  BarChart3, 
  Server, 
  CreditCard, 
  FileCheck,
  Workflow,
  Award,
  Zap,
  Building,
  Briefcase,
  Handshake,
  FileText,
  Users,
  Settings,
  Home,
  Command,
  Clock,
  Rocket,
  Calendar,
  Linkedin,
  Mail,
  FlaskConical,
  TestTube,
  BookOpen,
  HelpCircle,
  FileSearch,
  Activity,
  TrendingUp,
  Target,
  CheckCircle,
  GitBranch,
  Database,
  Globe,
  UserCheck,
  Layers,
  PieChart,
  MessageSquare,
  Bell,
  Search,
  Filter,
  Download,
  Upload,
  Eye,
  Edit,
  Trash2,
  Plus,
  Minus,
  ArrowRight,
  ArrowLeft,
  ChevronDown,
  ChevronUp,
  X,
  Menu,
  DollarSign, // Added for AWS Migration Strategy
  Bot, // Added for AI-assisted migration
  HardDrive // Added for MGN Agent Setup Guide
} from 'lucide-react';
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";

const adminNav = [
  {
    group: 'Core',
    items: [
      { name: 'Command Center', icon: Command, href: createPageUrl('AdminCommandCenter') },
      { name: '⏰ Last 24 Hours', icon: Clock, href: createPageUrl('Last24HourAssessment') },
      { name: '🗓️ Daily Execution Tracker', icon: Calendar, href: createPageUrl('DailyExecutionTracker') },
      { name: '📊 Analytics Dashboard', icon: BarChart3, href: createPageUrl('AnalyticsDashboard') },
      { name: '📊 Client Analytics', icon: PieChart, href: createPageUrl('AdminClientAnalytics') },
    ]
  },
  {
    group: 'Testing & Validation',
    items: [
      { name: '🚀 AI Core System Test', icon: TestTube, href: createPageUrl('ComprehensiveSystemTest') },
      { name: '⚡ System Tests', icon: Activity, href: createPageUrl('SystemTests') },
      { name: '🧪 Email System Test', icon: FlaskConical, href: createPageUrl('EmailSystemTest') },
      { name: '🔄 Client Pipeline Tests', icon: GitBranch, href: createPageUrl('ClientPipelineTests') },
      { name: '🧪 A/B Testing', icon: TestTube, href: createPageUrl('ABTestingDashboard') },
    ]
  },
  {
    group: 'SBIR & Growth',
    items: [
      { name: '🚀 11-Week SBIR Plan', icon: Rocket, href: createPageUrl('RevisedSBIRStrategy') },
      { name: 'Hybrid Sprint Plan', icon: Zap, href: createPageUrl('HybridSprintPlan') },
      { name: '🏆 LOI Generator', icon: Award, href: createPageUrl('LOIGenerator') },
      { name: '📈 SEO Metrics', icon: TrendingUp, href: createPageUrl('SEOMetricsDashboard') },
      { name: '🔍 Conversion Tracking', icon: Target, href: createPageUrl('ConversionTrackingDashboard') },
      { name: '📋 LOI Tracking', icon: CheckCircle, href: createPageUrl('LOITrackingDashboard') },
    ]
  },
  {
    group: 'Outreach',
    items: [
      { name: '📣 LinkedIn Campaign', icon: Linkedin, href: createPageUrl('LinkedInCampaignStrategy') },
      { name: '📱 LinkedIn Posts Ready', icon: Mail, href: createPageUrl('LinkedInGroupPosts') },
      { name: '🤝 Strategic Partners', icon: Handshake, href: createPageUrl('StrategicPartnershipDashboard') },
      { name: '📧 Partnership Outreach', icon: Mail, href: createPageUrl('PartnershipOutreachCenter') },
      { name: '🎯 Prime Concierge Outreach', icon: Rocket, href: createPageUrl('ConciergePrimeOutreach') },
    ]
  },
  {
    group: 'Infrastructure',
    items: [
      { name: 'AWS Migration Strategy', icon: DollarSign, href: createPageUrl('AWSMigrationStrategy') },
      { name: 'AWS Migration Execution', icon: Bot, href: createPageUrl('AWSMigrationExecutionPlan') },
      { name: 'MGN Agent Setup', icon: HardDrive, href: createPageUrl('MGNAgentSetupGuide') },
      { name: '📨 Email Infrastructure', icon: Mail, href: createPageUrl('EmailInfrastructure') },
      { name: '💳 Payment Integration', icon: CreditCard, href: createPageUrl('PaymentIntegrationPlan') },
      { name: '💾 Code Export & Backup', icon: Download, href: createPageUrl('CodeExportAndBackup') },
      { name: '🌐 Sitemap', icon: Globe, href: createPageUrl('Sitemap') },
      { name: '👥 User Management', icon: UserCheck, href: createPageUrl('UserManagement') },
    ]
  },
];

const clientNav = [
  { name: 'Dashboard', icon: Home, href: createPageUrl('Dashboard') },
  { name: 'Security Incidents', icon: AlertTriangle, href: createPageUrl('Incidents') },
  { name: 'Analytics', icon: BarChart3, href: createPageUrl('Analytics') },
  { name: 'Virtual Machines', icon: Server, href: createPageUrl('SecureVirtualMachines') },
  { name: 'Subscription', icon: CreditCard, href: createPageUrl('Subscription') },
  { name: 'Compliance Center', icon: FileCheck, href: createPageUrl('ComplianceCenter') },
  { name: 'CMMC Workflows', icon: Workflow, href: createPageUrl('ComplianceWorkflows') },
  { name: 'CMMC Readiness', icon: Award, href: createPageUrl('CMMCReadiness') },
  { name: 'Response Automation', icon: Zap, href: createPageUrl('ResponseAutomation') },
  { name: 'CMMC Marketplace', icon: Building, href: createPageUrl('CMMCMarketplace') },
  { name: 'Partnership Hub', icon: Handshake, href: createPageUrl('PartnershipHub') },
  { name: 'Business Formation', icon: Briefcase, href: createPageUrl('BusinessFormation') },
  { name: 'Support', icon: HelpCircle, href: createPageUrl('SupportDashboard') },
  { name: 'Knowledge Hub', icon: BookOpen, href: createPageUrl('KnowledgeHub') },
  { name: 'Help Center', icon: HelpCircle, href: createPageUrl('HelpCenter') },
  { name: 'Resources', icon: FileText, href: createPageUrl('Resources') }
];

export default function Layout({ children, currentPageName }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const currentUser = await User.me();
        setUser(currentUser);
      } catch (error) {
        console.log('User not authenticated');
      } finally {
        setLoading(false);
      }
    };

    fetchUser();
  }, []);

  useEffect(() => {
    // Add Google verification meta tag
    const metaTag = document.createElement('meta');
    metaTag.name = 'google-site-verification';
    metaTag.content = '7JdaNLUbr6jkliCpbN0eWkBV5D23-xn7BkM4vP9zF2s';
    document.head.appendChild(metaTag);
    
    return () => {
      // Clean up on unmount
      const existingTag = document.querySelector('meta[name="google-site-verification"]');
      if (existingTag) {
        document.head.removeChild(existingTag);
      }
    };
  }, []);

  const handleLogout = async () => {
    await User.logout();
    window.location.reload();
  };

  const isAdmin = user?.role === 'admin';
  
  // Create a mutable copy of the navigation array for the current user type
  let currentNavigation = isAdmin ? [...adminNav] : [...clientNav];

  // If the user is an admin, ensure "Profile Settings" is in their navigation
  if (isAdmin) {
    const hasProfileSettings = currentNavigation.some(group => group.items?.some(item => item.name === 'Profile Settings'));
    if (!hasProfileSettings) {
        // Add to a new 'Settings' group at the end
        currentNavigation.push({
            group: 'Settings',
            items: [{ name: 'Profile Settings', icon: Settings, href: createPageUrl('ProfileSettings') }]
        });
    }
  }

  // Use currentNavigation for rendering
  const navigation = currentNavigation;

  const sidebarContent = (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between p-6 border-b bg-slate-900">
        <div className="flex items-center gap-2">
          <Shield className="w-8 h-8 text-blue-400" />
          <span className="text-xl font-bold text-white">HyperCore</span>
        </div>
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setSidebarOpen(false)}
          className="text-gray-400 hover:text-white lg:hidden"
        >
          <X className="w-5 h-5" />
        </Button>
      </div>

      <nav className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-900">
        {navigation.map((groupOrItem, groupIndex) => {
          // It's a group (for admin nav)
          if (groupOrItem.group) {
            return (
              <div key={groupIndex} className="space-y-2">
                <h3 className="px-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                  {groupOrItem.group}
                </h3>
                {groupOrItem.items.map((item) => {
                  const Icon = item.icon;
                  return (
                    <Link
                      key={item.name}
                      to={item.href}
                      className="flex items-center gap-3 px-3 py-2 text-sm font-medium text-gray-300 rounded-md hover:text-white hover:bg-slate-800 transition-colors"
                      onClick={() => setSidebarOpen(false)}
                    >
                      <Icon className="w-5 h-5" />
                      {item.name}
                    </Link>
                  );
                })}
              </div>
            );
          }
          // It's a standalone item (for client nav)
          const Icon = groupOrItem.icon;
          return (
            <Link
              key={groupOrItem.name}
              to={groupOrItem.href}
              className="flex items-center gap-3 px-3 py-2 text-sm font-medium text-gray-300 rounded-md hover:text-white hover:bg-slate-800 transition-colors"
              onClick={() => setSidebarOpen(false)}
            >
              <Icon className="w-5 h-5" />
              {groupOrItem.name}
            </Link>
          );
        })}
      </nav>

      {user && (
        <div className="border-t p-4 bg-slate-900">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
              <span className="text-white text-sm font-medium">
                {user.full_name?.charAt(0) || 'U'}
              </span>
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium text-white">{user.full_name}</p>
              <p className="text-xs text-gray-400">{user.email}</p>
              {user.role === 'admin' && (
                <span className="inline-block px-2 py-0.5 text-xs bg-blue-600 text-white rounded-full mt-1">
                  Admin
                </span>
              )}
            </div>
          </div>
          <Button
            onClick={handleLogout}
            variant="outline"
            size="sm"
            className="w-full text-gray-300 border-gray-600 hover:bg-slate-800"
          >
            Sign out
          </Button>
        </div>
      )}
    </div>
  );

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Desktop Sidebar */}
      <div className="hidden lg:block lg:w-64 lg:fixed lg:h-full">
        {sidebarContent}
      </div>

      {/* Mobile Sidebar */}
      <Sheet open={sidebarOpen} onOpenChange={setSidebarOpen}>
        <SheetContent side="left" className="p-0 w-64">
          {sidebarContent}
        </SheetContent>
      </Sheet>

      {/* Main Content */}
      <div className="flex-1 lg:ml-64">
        {/* Top Bar */}
        <div className="bg-white shadow-sm border-b px-4 py-3 lg:px-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setSidebarOpen(true)}
                className="lg:hidden"
              >
                <Menu className="w-5 h-5" />
              </Button>
              <h1 className="text-lg font-semibold text-gray-900">
                {currentPageName || 'Dashboard'}
              </h1>
            </div>

            {user && (
              <div className="flex items-center gap-3">
                <div className="hidden sm:block text-right">
                  <p className="text-sm font-medium text-gray-900">{user.full_name}</p>
                  <p className="text-xs text-gray-500">{user.email}</p>
                </div>
                <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                  <span className="text-white text-sm font-medium">
                    {user.full_name?.charAt(0) || 'U'}
                  </span>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Page Content */}
        <main className="p-4 lg:p-6">
          {children}
        </main>
      </div>
    </div>
  );
}

