import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { CheckCircle, XCircle, Zap, Target, Shield, FileText, BarChart, BrainCircuit } from 'lucide-react';
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";

const dfarsSuite = [
    {
        tool: "Smart Contract Flow-Down Analyzer",
        description: "NLP parsing of DoD contracts, automatic DFARS clause identification, deadline extraction, risk assessment",
        uniqueValue: "ONLY tool that reads actual contract language to extract exact CMMC requirements",
        competitorEquivalent: "None - No competitor offers contract clause intelligence",
        advantage: "100% unique market position",
        icon: FileText
    },
    {
        tool: "SPRS Score Calculator", 
        description: "Automated calculation and submission-ready formatting of NIST SP 800-171 assessment scores",
        uniqueValue: "Generates defensible SPRS scores with audit trail and confidence metrics",
        competitorEquivalent: "TrustCloud: Real-time compliance scoring (but not SPRS-specific)",
        advantage: "DoD-native vs. generic compliance scoring",
        icon: BarChart
    },
    {
        tool: "CMMC Traceability Matrix",
        description: "Maps all 110 NIST controls to policies, evidence, and implementation status",
        uniqueValue: "Live, auditable control-to-evidence mapping with gap identification",
        competitorEquivalent: "StrikeGraph: Evidence mapping; Risk Cognizance: Control tracking",
        advantage: "Real-time updates vs. static snapshots",
        icon: Target
    },
    {
        tool: "Real-Time Drift Detection",
        description: "Continuous monitoring of control implementations with instant alert system",
        uniqueValue: "Minutes-level detection of compliance drift vs. quarterly/annual checks",
        competitorEquivalent: "TrustCloud: Periodic risk forecasting; Rackspace-SMPL-C: Cloud monitoring only",
        advantage: "True continuous monitoring across all systems",
        icon: Zap
    },
    {
        tool: "AI Risk Forecasting",
        description: "Predictive analytics for compliance failures 3-6 months in advance",
        uniqueValue: "CMMC-trained models predict specific control failures with remediation timelines",
        competitorEquivalent: "TrustCloud: Predictive risk forecasting (general); Concentric AI: Vulnerability scanning",
        advantage: "DFARS-specific predictions vs. generic risk assessment",
        icon: BrainCircuit
    },
    {
        tool: "Automated POA&M Generator",
        description: "AI-generated Plans of Action & Milestones with 180-day compliance timelines",
        uniqueValue: "DFARS 252.204-7021 compliant POA&Ms with automatic milestone tracking",
        competitorEquivalent: "CMMC2.AI: POA&M automation (180-day plans)",
        advantage: "Direct competitor - need differentiation on quality/automation level",
        icon: Shield
    }
];

const competitorAnalysis = [
    {
        competitor: "TrustCloud",
        strengths: ["Predictive risk forecasting", "Real-time compliance scoring", "Evidence collection automation"],
        weaknesses: ["No contract intelligence", "Generic scoring (not SPRS)", "Periodic scans only"],
        dfarsCoverage: "Partial - covers monitoring but lacks DoD-specific tools",
        verdict: "Strong in general compliance, weak in DFARS specifics"
    },
    {
        competitor: "Concentric AI", 
        strengths: ["Data discovery/classification", "110 NIST control mapping", "Vulnerability scanning"],
        weaknesses: ["Finds problems, doesn't solve them", "No continuous monitoring", "Enterprise-only pricing"],
        dfarsCoverage: "Minimal - data focus, not compliance workflow",
        verdict: "Complementary tool, not direct DFARS competitor"
    },
    {
        competitor: "CMMC2.AI",
        strengths: ["SMB-friendly pricing", "POA&M automation", "AI guidance"],
        weaknesses: ["Guidance-only approach", "No continuous monitoring", "Limited automation depth"],
        dfarsCoverage: "Good - covers POA&M but lacks real-time capabilities",
        verdict: "Direct competitor for POA&M, but less comprehensive"
    },
    {
        competitor: "StrikeGraph",
        strengths: ["SSP/document generation", "Evidence mapping", "NLP policy analysis"],
        weaknesses: ["Static documents", "Event-based monitoring only", "No contract intelligence"],
        dfarsCoverage: "Good - strong document focus but weak on ongoing compliance",
        verdict: "Document competitor, but missing continuous monitoring"
    },
    {
        competitor: "Risk Cognizance GRC",
        strengths: ["Control tracking", "Pre-loaded CMMC templates", "Risk automation"],
        weaknesses: ["GRC-first (not AI-native)", "Periodic monitoring", "Enterprise complexity"],
        dfarsCoverage: "Strong - comprehensive but traditional approach",
        verdict: "Most similar overall offering, key competitor"
    }
];

const marketGaps = [
    {
        gap: "Contract Clause Intelligence",
        description: "No competitor analyzes actual DoD contract language to extract DFARS requirements",
        hypercoreAdvantage: "100% unique - Smart Contract Flow-Down Analyzer",
        marketImpact: "Addresses 70% of subcontractor confusion per DoD surveys"
    },
    {
        gap: "True Continuous DFARS Monitoring", 
        description: "Most tools use periodic scans; few offer minute-level drift detection",
        hypercoreAdvantage: "Real-time across all 110 controls, not just cloud/network",
        marketImpact: "Critical for annual CMMC affirmations and FCA risk reduction"
    },
    {
        gap: "SPRS-Native Scoring",
        description: "Generic compliance scores don't match DoD SPRS submission requirements",
        hypercoreAdvantage: "Purpose-built for SPRS with audit trails and confidence metrics", 
        marketImpact: "Essential for all DoD contractors submitting assessments"
    },
    {
        gap: "Affordable SMB Solutions",
        description: "Most AI tools price out SMBs ($6K-22K/year) who make up 80% of DIB",
        hypercoreAdvantage: "$297/month positions us 75% below market average",
        marketImpact: "Unlocks 240,000+ SMB subcontractors currently priced out"
    }
];

export default function DFARSCompetitiveAssessment() {
    return (
        <div className="space-y-8">
            <BreadcrumbNav currentPageName="DFARSCompetitiveAssessment" />
            
            <div className="text-center">
                <h1 className="text-4xl font-bold text-gray-900">DFARS Tools: Competitive Assessment</h1>
                <p className="text-xl text-gray-600 max-w-4xl mx-auto mt-4">
                    Analysis of HyperCore's DFARS-specific AI tools versus competitor offerings in the $1.2B DIB compliance market.
                </p>
            </div>

            <Alert className="bg-green-50 border-green-200">
                <CheckCircle className="h-4 w-4 text-green-600" />
                <AlertTitle className="text-green-800">Market Position Summary</AlertTitle>
                <AlertDescription className="text-green-700">
                    <strong>HyperCore has 2 completely unique tools (Contract Analyzer, SPRS Calculator) and superior implementation of 3 common tools (Traceability, Monitoring, Forecasting).</strong> Only CMMC2.AI directly competes on POA&M automation.
                </AlertDescription>
            </Alert>

            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                        <Shield className="w-6 h-6 text-blue-600" />
                        HyperCore DFARS Tool Suite Analysis
                    </CardTitle>
                    <CardDescription>
                        Detailed comparison of each HyperCore tool against competitor equivalents
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="space-y-6">
                        {dfarsSuite.map((tool, index) => {
                            const Icon = tool.icon;
                            const isUnique = tool.competitorEquivalent.includes("None");
                            return (
                                <div key={index} className="border rounded-lg p-4">
                                    <div className="flex items-start gap-4">
                                        <Icon className="w-6 h-6 text-blue-600 mt-1" />
                                        <div className="flex-1">
                                            <div className="flex items-center gap-3 mb-2">
                                                <h3 className="text-lg font-semibold">{tool.tool}</h3>
                                                {isUnique && (
                                                    <Badge className="bg-green-100 text-green-800">100% Unique</Badge>
                                                )}
                                            </div>
                                            <p className="text-gray-700 mb-2">{tool.description}</p>
                                            <div className="grid md:grid-cols-3 gap-4 text-sm">
                                                <div className="p-3 bg-blue-50 rounded">
                                                    <h4 className="font-semibold text-blue-800">Unique Value</h4>
                                                    <p className="text-blue-700">{tool.uniqueValue}</p>
                                                </div>
                                                <div className="p-3 bg-gray-50 rounded">
                                                    <h4 className="font-semibold text-gray-800">Competitor Equivalent</h4>
                                                    <p className="text-gray-700">{tool.competitorEquivalent}</p>
                                                </div>
                                                <div className="p-3 bg-green-50 rounded">
                                                    <h4 className="font-semibold text-green-800">Our Advantage</h4>
                                                    <p className="text-green-700">{tool.advantage}</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>Competitor DFARS Coverage Analysis</CardTitle>
                    <CardDescription>How well each competitor addresses DFARS-specific requirements</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="overflow-x-auto">
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Competitor</TableHead>
                                    <TableHead>Strengths</TableHead>
                                    <TableHead>Weaknesses</TableHead>
                                    <TableHead>DFARS Coverage</TableHead>
                                    <TableHead>Competitive Verdict</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {competitorAnalysis.map((comp, index) => (
                                    <TableRow key={index}>
                                        <TableCell className="font-semibold">{comp.competitor}</TableCell>
                                        <TableCell>
                                            <ul className="text-xs space-y-1">
                                                {comp.strengths.map((strength, i) => (
                                                    <li key={i} className="flex items-center gap-2">
                                                        <CheckCircle className="w-3 h-3 text-green-500" />
                                                        {strength}
                                                    </li>
                                                ))}
                                            </ul>
                                        </TableCell>
                                        <TableCell>
                                            <ul className="text-xs space-y-1">
                                                {comp.weaknesses.map((weakness, i) => (
                                                    <li key={i} className="flex items-center gap-2">
                                                        <XCircle className="w-3 h-3 text-red-500" />
                                                        {weakness}
                                                    </li>
                                                ))}
                                            </ul>
                                        </TableCell>
                                        <TableCell className="text-sm">{comp.dfarsCoverage}</TableCell>
                                        <TableCell className="text-sm font-medium">{comp.verdict}</TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </div>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                        <Target className="w-6 h-6 text-purple-600" />
                        Market Gaps HyperCore Fills
                    </CardTitle>
                    <CardDescription>
                        Critical gaps in the DFARS compliance market that HyperCore uniquely addresses
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="grid md:grid-cols-2 gap-6">
                        {marketGaps.map((gap, index) => (
                            <div key={index} className="p-4 border rounded-lg">
                                <h3 className="font-semibold text-lg mb-2">{gap.gap}</h3>
                                <p className="text-gray-700 mb-3">{gap.description}</p>
                                <div className="space-y-2">
                                    <div className="p-2 bg-blue-50 rounded">
                                        <h4 className="font-semibold text-blue-800 text-sm">HyperCore Advantage</h4>
                                        <p className="text-blue-700 text-sm">{gap.hypercoreAdvantage}</p>
                                    </div>
                                    <div className="p-2 bg-green-50 rounded">
                                        <h4 className="font-semibold text-green-800 text-sm">Market Impact</h4>
                                        <p className="text-green-700 text-sm">{gap.marketImpact}</p>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>

            <Alert className="bg-blue-50 border-blue-200">
                <Zap className="h-4 w-4 text-blue-600" />
                <AlertTitle className="text-blue-800">Strategic Recommendation</AlertTitle>
                <AlertDescription className="text-blue-700">
                    <strong>Lead with Contract Intelligence and SPRS tools in all marketing.</strong> These are 100% unique to HyperCore. 
                    Position Real-Time Monitoring and Traceability as "superior implementations" of common features. 
                    Only compete directly with CMMC2.AI on POA&M automation by emphasizing deeper AI integration.
                </AlertDescription>
            </Alert>
        </div>
    );
}