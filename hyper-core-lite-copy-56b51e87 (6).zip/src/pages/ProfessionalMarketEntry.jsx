import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { CheckCircle, Shield, Zap, FileText, ArrowRight, DollarSign, Target, Rocket } from 'lucide-react';

const MARKET_ENTRY_PLAN = {
    phase1: {
        title: "Phase 1: Secure Your First Contract (The 'Value-for-Capital' Swap)",
        timeline: "Weeks 1-2",
        objective: "Sign one client for a 6-month CMMC readiness project for ~$50,000, with 50% ($25,000) paid upfront.",
        what_you_sell: "A CMMC readiness assessment and implementation service, powered by an AI-accelerated toolkit.",
        key_actions: [
            { name: "The Demo: Use Existing Toolkit", description: "Demonstrate immediate value with the CMMC Assessment and AWS Inheritance tools.", icon: Target, page: "HyperCoreCMMCAssessment" },
            { name: "The Proposal: Structure the Deal", description: "Offer a fixed-price project with 50% upfront payment.", icon: DollarSign },
            { name: "The Legal: Minimum Viable Contract", description: "Use a simple Master Service Agreement (MSA) and Statement of Work (SOW).", icon: FileText, page: "LegalStrategy" },
        ]
    },
    phase2: {
        title: "Phase 2: Deliver on Contract & Build the Real AI",
        timeline: "Weeks 3-8 (In Parallel)",
        objective: "Use client revenue to deliver services AND fund your AI development and internal compliance.",
        client_delivery: [
            { name: "Deliver Client Services", description: "Use the Compliance Documentation Center to provide templates and checklists.", icon: FileText, page: "ComplianceDocumentation" },
            { name: "Show Progress", description: "Use the Audit Trail Dashboard to provide transparency and build trust.", icon: Shield, page: "AuditTrailDashboard" }
        ],
        internal_development: [
            { name: "Fund Real AI Training", description: "Allocate the $25k upfront payment to AWS GPU instances and Hugging Face Pro.", icon: DollarSign },
            { name: "Execute Real Training", description: "Fine-tune LLaMA models using the real methodology. This is your IP.", icon: Zap, page: "AITrainingPipeline" },
        ]
    },
    phase3: {
        title: "Phase 3: Scale & Dominate",
        timeline: "Week 9+",
        objective: "Leverage your first success story, a genuinely powerful AI asset, and full compliance to win larger contracts.",
        outcome: [
            { name: "First Client is a Case Study", description: "You have a referenceable, successful project.", icon: CheckCircle },
            { name: "Proprietary AI Model is Live", description: "Your fine-tuned model is a unique, defensible asset.", icon: Zap },
            { name: "You Are Now CMMC Compliant", description: "You can now subcontract to larger primes and handle CUI directly.", icon: Shield },
            { name: "Market Expansion", description: "Attack the broader defense market, insurance carriers, and critical infrastructure.", icon: Rocket }
        ]
    }
};

export default function ProfessionalMarketEntry() {
    return (
        <div className="min-h-screen bg-gray-50 p-6">
            <div className="max-w-7xl mx-auto">
                <div className="text-center mb-8">
                    <h1 className="text-4xl font-bold text-gray-900 mb-3">
                        Go-to-Market Action Plan: From Demo to Dominance
                    </h1>
                    <p className="text-xl text-gray-600">
                        A definitive three-phase strategy to enter the market, secure funding, and build a real AI-powered CMMC consultancy.
                    </p>
                </div>

                <Alert className="mb-8 bg-green-50 border-green-200">
                    <Rocket className="h-4 w-4 text-green-600" />
                    <AlertTitle className="text-green-800">The Core Strategy: Swap Your Service for R&D Capital</AlertTitle>
                    <AlertDescription className="text-green-700">
                        Stop thinking about finding investors. Your first client is your investor. You will trade your valuable, ready-to-use CMMC assessment service for the upfront capital needed to build your proprietary AI engine and achieve full compliance.
                    </AlertDescription>
                </Alert>

                <div className="space-y-8">
                    {Object.values(MARKET_ENTRY_PLAN).map((phase, index) => (
                        <Card key={index} className="shadow-lg">
                            <CardHeader>
                                <CardTitle className="text-2xl">{phase.title}</CardTitle>
                                <CardDescription><strong>Timeline:</strong> {phase.timeline} | <strong>Objective:</strong> {phase.objective}</CardDescription>
                            </CardHeader>
                            <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div>
                                    <h4 className="font-semibold mb-2">What You Do:</h4>
                                    <ul className="space-y-3">
                                        {(phase.key_actions || phase.client_delivery).map((action, i) => (
                                            <li key={i} className="flex items-start gap-3">
                                                <action.icon className="w-5 h-5 text-blue-600 mt-1" />
                                                <div>
                                                    <h5 className="font-bold">{action.name}</h5>
                                                    <p className="text-sm text-gray-600">{action.description}</p>
                                                    {action.page && <Link to={createPageUrl(action.page)} className="text-sm text-blue-500 hover:underline">View Tool <ArrowRight className="w-3 h-3 inline"/></Link>}
                                                </div>
                                            </li>
                                        ))}
                                    </ul>
                                </div>
                                <div>
                                    <h4 className="font-semibold mb-2">How It Works:</h4>
                                    <ul className="space-y-3">
                                        {(phase.internal_development || phase.outcome || phase.key_actions.slice(1,3)).map((action, i) => (
                                             <li key={i} className="flex items-start gap-3">
                                                <action.icon className="w-5 h-5 text-green-600 mt-1" />
                                                <div>
                                                    <h5 className="font-bold">{action.name}</h5>
                                                    <p className="text-sm text-gray-600">{action.description}</p>
                                                     {action.page && <Link to={createPageUrl(action.page)} className="text-sm text-green-500 hover:underline">View Details <ArrowRight className="w-3 h-3 inline"/></Link>}
                                                </div>
                                            </li>
                                        ))}
                                    </ul>
                                </div>
                            </CardContent>
                        </Card>
                    ))}
                </div>
            </div>
        </div>
    );
}