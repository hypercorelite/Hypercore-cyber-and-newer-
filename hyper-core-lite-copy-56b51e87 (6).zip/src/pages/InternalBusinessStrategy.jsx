import React from 'react';
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { ArrowRight, Zap } from 'lucide-react';
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';

export default function InternalBusinessStrategy() {
    return (
        <div className="p-4 md:p-8 flex flex-col items-center justify-center text-center h-full">
            <Card className="max-w-2xl">
                <CardHeader>
                    <CardTitle className="text-2xl font-bold">Strategy Has Been Updated</CardTitle>
                </CardHeader>
                <CardContent>
                     <Alert className="bg-blue-50 border-blue-200 text-left">
                        <Zap className="h-4 w-4" />
                        <AlertTitle className="font-semibold text-blue-800">This plan is now superseded.</AlertTitle>
                        <AlertDescription className="text-blue-700 mt-2">
                           Our Go-to-Market strategy has evolved to a Product-Led Growth model. Please refer to the new "Hyperspeed Action Plan" for the current strategy.
                        </AlertDescription>
                    </Alert>
                    <Button asChild className="mt-6">
                        <Link to={createPageUrl('StreamlinedActionPlan')}>
                            Go to the New Hyperspeed Action Plan <ArrowRight className="w-4 h-4 ml-2" />
                        </Link>
                    </Button>
                </CardContent>
            </Card>
        </div>
    );
}