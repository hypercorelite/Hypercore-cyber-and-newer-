import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { CheckCircle, AlertTriangle, ArrowRight } from "lucide-react";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function CMMCComplianceGaps() {

    const commonGaps = [
        {
            title: "Access Control (AC) Policies",
            description: "Contractors often lack formally documented policies that define who can access what information and under what circumstances. This is a foundational CMMC requirement.",
            impact: "High - Failure to meet this control can cascade into failures across multiple CMMC domains."
        },
        {
            title: "Incident Response (IR) Planning",
            description: "Many have informal response ideas but lack a documented, tested plan for how to respond to a breach, including communication and recovery steps.",
            impact: "High - A poor incident response can turn a minor event into a major financial and reputational disaster."
        },
        {
            title: "System and Information Integrity (SI)",
            description: "A lack of regular, automated vulnerability scanning and remediation means security flaws can go undetected for months, leaving systems exposed.",
            impact: "Critical - This is a common attack vector for ransomware and data breaches."
        },
        {
            title: "Configuration Management (CM)",
            description: "Systems are often configured inconsistently, without a secure baseline or a formal process for managing changes, leading to security drift.",
            impact: "Medium - Inconsistent configurations create hard-to-track vulnerabilities."
        }
    ];

    return (
        <div className="min-h-screen bg-gray-50 p-6">
            <div className="max-w-4xl mx-auto">
                <div className="text-center mb-12">
                    <h1 className="text-4xl font-bold text-gray-900 mb-3">
                        The Four Gaps That Derail Most CMMC Audits
                    </h1>
                    <p className="text-lg text-gray-600">
                        Our AI has analyzed thousands of compliance data points. These four areas are where most defense contractors fail.
                    </p>
                </div>

                <Alert className="mb-8 bg-yellow-50 border-yellow-200">
                    <AlertTriangle className="h-4 w-4 text-yellow-700" />
                    <AlertTitle className="text-yellow-800">The Problem with Legacy Systems</AlertTitle>
                    <AlertDescription className="text-yellow-700">
                        Most of these gaps exist because contractors struggle to apply modern security principles to their existing (legacy) infrastructure. Manual assessments often miss how these systems truly operate, leading to surprise findings during the formal C3PAO audit.
                    </AlertDescription>
                </Alert>

                <div className="space-y-6">
                    {commonGaps.map((gap, index) => (
                        <Card key={index}>
                            <CardHeader>
                                <CardTitle>{gap.title}</CardTitle>
                                <CardDescription>{gap.description}</CardDescription>
                            </CardHeader>
                            <CardContent>
                                <div className="flex justify-between items-center text-sm">
                                    <span className="font-semibold">Business Impact:</span>
                                    <span className={`font-bold ${gap.impact === 'High' || gap.impact === 'Critical' ? 'text-red-600' : 'text-yellow-600'}`}>{gap.impact}</span>
                                </div>
                            </CardContent>
                        </Card>
                    ))}
                </div>

                <Card className="mt-12 bg-gradient-to-r from-blue-600 to-indigo-700 text-white">
                    <CardHeader>
                        <CardTitle>Don't Let These Gaps Cost You Contracts</CardTitle>
                        <CardDescription className="text-blue-200">Our free, automated analysis checks for these common failure points and more, giving you a clear picture of your readiness in minutes.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <Button asChild size="lg" variant="secondary" className="text-blue-700 hover:bg-gray-200">
                            <Link to={createPageUrl('PartnershipTrial')}>
                                Get Your Free Gap Analysis <ArrowRight className="w-5 h-5 ml-2" />
                            </Link>
                        </Button>
                    </CardContent>
                </Card>

            </div>
        </div>
    );
}