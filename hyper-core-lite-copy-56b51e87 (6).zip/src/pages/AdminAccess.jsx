import React, { useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { createPageUrl } from '@/utils';
import { Shield, ArrowRight } from 'lucide-react';

export default function AdminAccess() {
    
    const enableAdminMode = () => {
        const dashboardUrl = createPageUrl('Dashboard');
        // Construct the full URL with the secret key and redirect
        window.location.href = `${dashboardUrl}?admin=hypercore2025admin`;
    };

    return (
        <div className="flex items-center justify-center min-h-screen bg-gray-100">
            <Card className="w-full max-w-md">
                <CardHeader className="text-center">
                    <Shield className="w-12 h-12 mx-auto text-red-500" />
                    <CardTitle className="text-2xl mt-4">Admin Portal Access</CardTitle>
                    <CardDescription>
                        This will activate administrator privileges for your browser session.
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <Button 
                        className="w-full bg-red-600 hover:bg-red-700" 
                        size="lg"
                        onClick={enableAdminMode}
                    >
                        Enter Admin Mode <ArrowRight className="w-5 h-5 ml-2" />
                    </Button>
                    <p className="text-xs text-gray-500 mt-4 text-center">
                        You will be redirected to the main admin dashboard.
                    </p>
                </CardContent>
            </Card>
        </div>
    );
}