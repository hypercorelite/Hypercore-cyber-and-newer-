
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CheckCircle, ArrowRight, FileText, DollarSign, Users, Award, AlertTriangle, Clock, Download, Video, Bot, Shield, BarChart } from 'lucide-react'; // Added BarChart
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function CompleteSBIRProposal() {
    const [activeTab, setActiveTab] = useState("overview");

    const proposalOverview = {
        title: "AI-Driven CMMC Compliance Automation Platform",
        piName: "Christine Boes, CEO & AI Engineer",
        organization: "HyperCore Cyber Security LLC",
        totalBudget: "$260,500",
        projectPeriod: "12 months",
        submissionDeadline: "October 29, 2025"
    };

    const technicalVolume = {
        problemStatement: `The Cybersecurity Maturity Model Certification (CMMC) enforcement creates an unprecedented compliance crisis for Small and Medium-sized Businesses (SMBs) in the Defense Industrial Base. With 31,500+ SMB defense contractors required to achieve CMMC Level 2 compliance, current solutions are prohibitively expensive ($50K-$200K), time-consuming (12-18 months), and require specialized expertise most SMBs lack.

**Market Gap Analysis:**
- Manual compliance: $60K-$200K cost, 12-18 months timeline
- GRC SaaS platforms: $5K-$15K/year, still require 6-12 months and moderate expertise
- Non-3PAO consultants: $10K-$50K, 6-12 months, varying quality
- **Market Need:** 90% cost reduction and 75% time savings for Level 2 compliance

**The HyperCore Solution:**
An AI-first platform that automates the complete CMMC Level 2 compliance workflow, reducing implementation time from 12-18 months to 90 days and costs from $50K+ to under $5K total.`,

        technicalObjectives: [
            "Develop an AI-driven gap analysis engine capable of processing all 110 NIST SP 800-171 controls with 90%+ accuracy",
            "Create automated System Security Plan (SSP) generation reducing documentation time by 85%",
            "Build intelligent policy generation system covering all 14 CMMC domains",
            "Implement real-time compliance scoring and POA&M automation",
            "Establish scalable cloud architecture serving 100+ SMB clients concurrently"
        ],

        workPlan: `**Phase I Work Plan (12 Months):**

**Months 1-3: Foundation & Core AI Development**
- Implement RAG (Retrieval-Augmented Generation) pipeline for NIST SP 800-171
- Develop control mapping and gap analysis algorithms
- Create initial SSP template generation system
- Build secure AWS GovCloud infrastructure

**Months 4-6: Platform Development & Integration**
- Complete automated policy generation for 14 CMMC domains
- Implement real-time compliance scoring dashboard
- Develop POA&M automation and tracking system
- Integrate with common SMB technology stacks

**Months 7-9: Pilot Testing & Validation**
- Deploy with 5-10 pilot SMB defense contractors
- Collect user feedback and system performance metrics
- Refine AI accuracy and user experience
- Conduct security audits and compliance verification

**Months 10-12: Commercial Readiness & Scale Preparation**
- Optimize platform for 100+ concurrent users
- Complete automated onboarding and support systems
- Finalize pricing model and go-to-market strategy
- Prepare Phase II proposal with validated metrics`
    };

    const commercializationPlan = {
        marketOpportunity: `**Total Addressable Market:**
- 31,500 SMB defense contractors requiring CMMC Level 2
- Current market size: $2.3B annual compliance spend
- Target market penetration: 10% (3,150 clients) by Year 3
- Revenue projection: $39.4M by Year 3, $125M by Year 5

**Customer Segments:**
1. **Primary:** SMB defense contractors (50-500 employees)
2. **Secondary:** Defense subcontractors and suppliers  
3. **Tertiary:** Mid-market primes managing supply chain compliance`,

        valueProposition: `**Competitive Advantage Analysis:**
- **90% Cost Reduction:** $5K total vs. $50K-$200K traditional approaches
- **75% Time Savings:** 90-day implementation vs. 12-18 months
- **Zero Expertise Required:** AI handles technical complexity
- **Continuous Compliance:** Real-time monitoring vs. point-in-time assessments

**Unique Differentiators:**
1. Only AI-first CMMC platform with 24+ years domain expertise
2. Complete automation of all 110 controls, not just documentation
3. Founded by compliance expert, not generic cybersecurity company
4. Exponential scaling model: each client improves AI for all clients`,

        // Updated goToMarketStrategy as per outline
        goToMarketStrategy: `**Phase III Commercialization Strategy:**
- **Go-to-Market:** Target the 31,500 SMB defense contractors via SEO, direct outreach, and partnerships with prime contractors.
- **Revenue Model:** Transition from a free trial to a tiered subscription model ($297/mo Pro, $997/mo Enterprise).
- **Team Growth:** Use Phase I success and Phase II funding to hire a lead engineer and a customer success manager, mitigating single-founder risk.
- **IP Strategy:** Secure patents for the core AI compliance engine and automated documentation algorithms.`,

        revenueModel: `**Tiered SaaS Pricing:**
- **Starter:** $0/month (limited assessments, lead generation)
- **Professional:** $297/month (full CMMC Level 2 platform)  
- **Enterprise:** $12,500/year (multi-location, custom integration)

**Revenue Projections:**
- Year 1: $1.25M (100 clients average $297/month)
- Year 2: $6.25M (500 clients)
- Year 3: $39.4M (3,150 clients, 10% market penetration)
- Year 5: $125M (10,000 clients, 32% market share)`
    };

    const costProposal = {
        directCosts: [
            { category: "Direct Labor", amount: 150000, description: "Principal Investigator (Christine Boes) - 12 months @ 100% effort" },
            { category: "Fringe Benefits", amount: 37500, description: "25% of direct labor for health insurance, payroll taxes, retirement" },
            { category: "Technology Infrastructure", amount: 18000, description: "AWS GovCloud ($7.2K), AI APIs ($9.6K), Development Tools ($1.2K)" },
            { category: "Other Direct Costs", amount: 50000, description: "Technical Acceleration Fund ($40K), Legal/IP ($5K), Security Audit ($3K), Documentation ($2K)" }
        ],
        totalDirect: 255500,
        indirectRate: 0.10,
        indirectCosts: 25550,
        totalProject: 281050,
        budgetJustification: `**Founder-Led, Capital-Efficient Model:**

This budget reflects a lean, AI-first approach that maximizes technology investment while minimizing overhead. The single expert + AI model is a strategic advantage, not a limitation:

**Key Strategic Decisions:**
1. **No Travel Costs:** PI located 1 hour from Pentagon/DoD, married to defense contractor at Ft. Belvoir
2. **Technical Acceleration Fund:** $40K flexible fund for specialized expertise and model training
3. **Realistic Infrastructure Costs:** Based on actual AWS GovCloud pricing for 100+ client scale
4. **Domain Expertise Premium:** 24+ years government compliance experience impossible to hire quickly`
    };

    // New costProposalSummary added as per outline
    const costProposalSummary = {
        totalBudget: 260500,
        breakdown: [
            { category: "Direct Labor (Founder/PI @ 100%)", amount: 150000 },
            { category: "Fringe Benefits (25%)", amount: 37500 },
            { category: "Technical Acceleration & Scaling Fund", amount: 40000 },
            { category: "Cloud & AI Services", amount: 16800 },
            { category: "Professional & Admin Services", amount: 10000 },
            { category: "Indirect Costs (10% De Minimis)", amount: 25430 },
            { category: "Unallocated / Contingency", amount: 770 },
        ]
    };

    // Extracted original detailed data for Key Personnel and Letters of Intent
    // to preserve existing functionality after supportingDocuments is redefined as an array.
    const keyPersonnelData = {
        name: "Christine Boes",
        qualifications: [
            "24+ years government sector compliance and technology implementation",
            "Master of Arts (M.A.), Government - Regent University",
            "Master of Education (M.Ed.), Educational Technology - Regent University",
            "Expert in federal regulatory compliance (IEPs, FERPA, NIST frameworks)",
            "Founder & CEO, HyperCore Cyber Security LLC (September 2025)",
            "AI Engineer specializing in regulatory compliance automation"
        ]
    };

    const lettersOfIntentData = {
        count: "12 submitted",
        companies: [
            "Defense contractors with active DoD contracts",
            "SMBs requiring CMMC Level 2 compliance",
            "Mix of pilot participants and paid subscribers committed"
        ]
    };

    // Updated supportingDocuments to be an array as per outline
    const supportingDocuments = [
        { name: "Appendix A: Letters of Intent", description: "Letters of Intent from potential customers and partners, demonstrating clear market demand and commercialization potential.", link: createPageUrl('SBIRProposalEvidence') },
        { name: "Appendix B: Key Personnel Resume", description: "Detailed resume for the Principal Investigator, Christine Boes, highlighting over 20 years of relevant expertise in technology and compliance.", link: createPageUrl('KeyPersonnelResume') },
        { name: "Appendix C: Risk Mitigation & Scaling Strategy", description: "A comprehensive narrative addressing the 'single founder' risk and detailing the AI-first model for realistic, capital-efficient scaling.", link: createPageUrl('SBIRImplementationStrategy') },
        { name: "Appendix D: Real-World Market Validation", description: "Anonymized case studies from real DoD contractors currently using the platform, proving product-market fit and immediate impact.", link: createPageUrl('SBIRMarketingAppendix') },
        { name: "Appendix E: Competitive Scoring Analysis", description: "Data-driven analysis showing HyperCore's 9x advantage in cost and time savings over traditional compliance methods.", link: createPageUrl('CompetitiveScoringAnalysis') },
    ];

    const competitiveScoring = {
        criteria: [
            { factor: "Cost Efficiency", weight: 30, hyperCoreScore: 95, competitorAvg: 45 },
            { factor: "Time to Compliance", weight: 25, hyperCoreScore: 90, competitorAvg: 40 },
            { factor: "Technical Innovation", weight: 20, hyperCoreScore: 95, competitorAvg: 60 },
            { factor: "Market Understanding", weight: 15, hyperCoreScore: 90, competitorAvg: 50 },
            { factor: "Scalability", weight: 10, hyperCoreScore: 95, competitorAvg: 35 }
        ],
        overallScore: 93,
        marketPositioning: "Revolutionary disruption through AI-first approach with deep domain expertise"
    };

    const videoSuggestions = [
        {
            tool: "Descript",
            description: "AI-powered video editing with screen recording and automatic transcription",
            pros: "Easy to use, AI removes 'ums', good for technical demos",
            pricing: "$12/month",
            bestFor: "Screen recordings of platform in action"
        },
        {
            tool: "Loom",
            description: "Simple screen and webcam recording with AI-generated summaries",
            pros: "Quick setup, automatic captions, good for short demos",
            pricing: "$8/month", 
            bestFor: "5-minute platform walkthrough"
        },
        {
            tool: "Synthesia",
            description: "AI avatar creation for professional presentations",
            pros: "Professional appearance, no need to be on camera",
            pricing: "$30/month",
            bestFor: "Executive summary presentation"
        },
        {
            tool: "RunwayML",
            description: "Advanced AI video generation and editing",
            pros: "Cutting-edge AI capabilities, professional output",
            pricing: "$35/month",
            bestFor: "High-production value demonstration"
        }
    ];

    return (
        <div className="space-y-8 p-4 md:p-6">
            <BreadcrumbNav currentPageName="CompleteSBIRProposal" />
            
            <div className="text-center">
                <Badge className="mb-4 bg-blue-100 text-blue-800 text-lg px-6 py-2">COMPLETE SBIR PROPOSAL PACKAGE</Badge>
                <h1 className="text-4xl font-bold text-gray-900 mb-4">
                    {proposalOverview.title}
                </h1>
                <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 max-w-4xl mx-auto text-sm">
                    <div><strong>PI:</strong> {proposalOverview.piName}</div>
                    <div><strong>Budget:</strong> {proposalOverview.totalBudget}</div>
                    <div><strong>Period:</strong> {proposalOverview.projectPeriod}</div>
                    <div><strong>Deadline:</strong> {proposalOverview.submissionDeadline}</div>
                </div>
            </div>

            <Alert className="bg-green-50 border-green-200">
                <CheckCircle className="h-4 w-4 text-green-700" />
                <AlertTitle className="font-bold text-green-800">Proposal Status: 95% Complete</AlertTitle>
                <AlertDescription className="text-green-700">
                    All written components are finalized and submission-ready. Only the 5-minute video demonstration remains to be produced.
                </AlertDescription>
            </Alert>

            <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="grid grid-cols-5 w-full">
                    <TabsTrigger value="overview">Overview</TabsTrigger>
                    <TabsTrigger value="technical">Technical</TabsTrigger>
                    <TabsTrigger value="commercial">Commercial</TabsTrigger>
                    <TabsTrigger value="budget">Budget</TabsTrigger>
                    <TabsTrigger value="appendix">Appendix</TabsTrigger>
                </TabsList>

                <TabsContent value="overview" className="space-y-6">
                    <Card>
                        <CardHeader>
                            <CardTitle>Executive Summary</CardTitle>
                            <CardDescription>High-level proposal overview and competitive positioning</CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div className="bg-blue-50 p-6 rounded-lg">
                                <h3 className="font-bold text-blue-800 mb-3">Revolutionary Value Proposition</h3>
                                <p className="text-blue-700">
                                    HyperCore's AI-first CMMC compliance platform delivers what the defense industrial base desperately needs: 
                                    <strong> 90% cost reduction, 75% time savings, and zero expertise requirements</strong> for CMMC Level 2 compliance. 
                                    Founded by a compliance expert with 24+ years of government sector experience, this is the only solution that combines 
                                    deep domain knowledge with cutting-edge AI automation.
                                </p>
                            </div>
                            
                            <div className="grid md:grid-cols-2 gap-6">
                                <div>
                                    <h4 className="font-semibold mb-3">Market Disruption Metrics</h4>
                                    <ul className="space-y-2 text-sm">
                                        <li>• <strong>31,500 SMB contractors</strong> need CMMC Level 2</li>
                                        <li>• <strong>$2.3B annual</strong> compliance market</li>
                                        <li>• <strong>90% cost reduction</strong> vs. traditional methods</li>
                                        <li>• <strong>90-day implementation</strong> vs. 12-18 months</li>
                                    </ul>
                                </div>
                                <div>
                                    <h4 className="font-semibold mb-3">Technical Innovation</h4>
                                    <ul className="space-y-2 text-sm">
                                        <li>• <strong>AI-driven gap analysis</strong> for all 110 NIST controls</li>
                                        <li>• <strong>Automated SSP generation</strong> with 90%+ accuracy</li>
                                        <li>• <strong>Real-time compliance scoring</strong> and monitoring</li>
                                        <li>• <strong>Scalable cloud architecture</strong> for 31,500+ clients</li>
                                    </ul>
                                </div>
                            </div>

                            <Alert className="bg-purple-50 border-purple-200">
                                <Bot className="h-4 w-4 text-purple-600" />
                                <AlertTitle className="text-purple-800">Competitive Scoring Analysis</AlertTitle>
                                <AlertDescription className="text-purple-700">
                                    <div className="grid md:grid-cols-3 gap-4 mt-3 text-center">
                                        <div>
                                            <div className="text-2xl font-bold text-purple-800">{competitiveScoring.overallScore}/100</div>
                                            <div className="text-sm">Overall Score</div>
                                        </div>
                                        <div>
                                            <div className="text-2xl font-bold text-purple-800">95/100</div>
                                            <div className="text-sm">Cost Efficiency</div>
                                        </div>
                                        <div>
                                            <div className="text-2xl font-bold text-purple-800">90/100</div>
                                            <div className="text-sm">Time to Market</div>
                                        </div>
                                    </div>
                                </AlertDescription>
                            </Alert>
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="technical" className="space-y-6">
                    <Card>
                        <CardHeader>
                            <CardTitle>Volume 1: Technical Approach</CardTitle>
                            <CardDescription>Problem identification, objectives, and detailed work plan</CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-6">
                            <div>
                                <h3 className="text-xl font-semibold mb-4">Problem Statement & Market Gap</h3>
                                <div className="prose max-w-none">
                                    <p className="whitespace-pre-line">{technicalVolume.problemStatement}</p>
                                </div>
                            </div>

                            <div>
                                <h3 className="text-xl font-semibold mb-4">Phase I Technical Objectives</h3>
                                <ul className="space-y-3">
                                    {technicalVolume.technicalObjectives.map((objective, index) => (
                                        <li key={index} className="flex items-start gap-3">
                                            <CheckCircle className="w-5 h-5 text-green-600 mt-0.5 flex-shrink-0" />
                                            <span>{objective}</span>
                                        </li>
                                    ))}
                                </ul>
                            </div>

                            <div>
                                <h3 className="text-xl font-semibold mb-4">Detailed Work Plan</h3>
                                <div className="prose max-w-none">
                                    <p className="whitespace-pre-line">{technicalVolume.workPlan}</p>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="commercial" className="space-y-6">
                    <Card>
                        <CardHeader>
                            <CardTitle>Volume 2: Commercialization Plan</CardTitle>
                            <CardDescription>Market opportunity, value proposition, and go-to-market strategy</CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-6">
                            <div className="grid md:grid-cols-2 gap-6">
                                <div>
                                    <h3 className="text-lg font-semibold mb-3">Market Opportunity</h3>
                                    <div className="prose prose-sm">
                                        <p className="whitespace-pre-line text-sm">{commercializationPlan.marketOpportunity}</p>
                                    </div>
                                </div>
                                <div>
                                    <h3 className="text-lg font-semibold mb-3">Value Proposition</h3>
                                    <div className="prose prose-sm">
                                        <p className="whitespace-pre-line text-sm">{commercializationPlan.valueProposition}</p>
                                    </div>
                                </div>
                            </div>

                            <div>
                                <h3 className="text-lg font-semibold mb-3">Go-to-Market Strategy</h3>
                                <div className="prose prose-sm">
                                    {/* Using dangerouslySetInnerHTML to correctly render markdown formatting from the updated string */}
                                    <p className="whitespace-pre-line text-sm" dangerouslySetInnerHTML={{ __html: commercializationPlan.goToMarketStrategy.replace(/\n/g, '<br/>').replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>') }}></p>
                                </div>
                            </div>

                            <div className="bg-green-50 p-6 rounded-lg">
                                <h3 className="text-lg font-semibold text-green-800 mb-3">Revenue Model & Projections</h3>
                                <div className="prose prose-sm text-green-700">
                                    <p className="whitespace-pre-line text-sm">{commercializationPlan.revenueModel}</p>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="budget" className="space-y-6">
                    <Card>
                        {/* Updated CardTitle to use the totalBudget from costProposalSummary */}
                        <CardHeader>
                            <CardTitle>Volume 3: Cost Proposal - ${costProposalSummary.totalBudget.toLocaleString()}</CardTitle>
                            <CardDescription>Detailed budget breakdown and justification</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-6">
                                <div className="overflow-x-auto">
                                    <table className="w-full border-collapse border border-gray-300">
                                        <thead>
                                            <tr className="bg-gray-50">
                                                <th className="border border-gray-300 px-4 py-3 text-left">Cost Category</th>
                                                <th className="border border-gray-300 px-4 py-3 text-right">Amount</th>
                                                <th className="border border-gray-300 px-4 py-3 text-left">Justification</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {costProposal.directCosts.map((cost, index) => (
                                                <tr key={index}>
                                                    <td className="border border-gray-300 px-4 py-3 font-medium">{cost.category}</td>
                                                    <td className="border border-gray-300 px-4 py-3 text-right font-mono">${cost.amount.toLocaleString()}</td>
                                                    <td className="border border-gray-300 px-4 py-3 text-sm">{cost.description}</td>
                                                </tr>
                                            ))}
                                            <tr className="bg-blue-50">
                                                <td className="border border-gray-300 px-4 py-3 font-bold">Total Direct Costs</td>
                                                <td className="border border-gray-300 px-4 py-3 text-right font-mono font-bold">${costProposal.totalDirect.toLocaleString()}</td>
                                                <td className="border border-gray-300 px-4 py-3"></td>
                                            </tr>
                                            <tr>
                                                <td className="border border-gray-300 px-4 py-3">Indirect Costs (10%)</td>
                                                <td className="border border-gray-300 px-4 py-3 text-right font-mono">${costProposal.indirectCosts.toLocaleString()}</td>
                                                <td className="border border-gray-300 px-4 py-3 text-sm">De minimis indirect rate</td>
                                            </tr>
                                            <tr className="bg-green-50">
                                                <td className="border border-gray-300 px-4 py-3 font-bold text-lg">TOTAL PROJECT COST</td>
                                                <td className="border border-gray-300 px-4 py-3 text-right font-mono font-bold text-lg">${costProposal.totalProject.toLocaleString()}</td>
                                                <td className="border border-gray-300 px-4 py-3"></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>

                                <div className="bg-yellow-50 p-6 rounded-lg">
                                    <h4 className="font-semibold text-yellow-800 mb-3">Budget Justification Summary</h4>
                                    <p className="text-yellow-700 text-sm whitespace-pre-line">{costProposal.budgetJustification}</p>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="appendix" className="space-y-6">
                    {/* New card to list all appendices from the supportingDocuments array */}
                    <Card>
                        <CardHeader>
                            <CardTitle>Proposal Appendices</CardTitle>
                            <CardDescription>Comprehensive supporting documentation for the proposal</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <div className="grid gap-4">
                                {supportingDocuments.map((doc, index) => (
                                    <div key={index} className="p-4 border rounded-lg bg-gray-50 flex items-start space-x-3">
                                        <FileText className="w-5 h-5 text-blue-600 flex-shrink-0 mt-1" />
                                        <div className="flex-grow">
                                            <h4 className="font-semibold text-lg text-gray-800">{doc.name}</h4>
                                            <p className="text-sm text-gray-600 mb-2">{doc.description}</p>
                                            <Button asChild variant="link" className="p-0 h-auto text-blue-600 hover:text-blue-800">
                                                <Link to={doc.link} className="flex items-center">
                                                    View Document <ArrowRight className="w-4 h-4 ml-1" />
                                                </Link>
                                            </Button>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    {/* Original detailed cards, now using extracted data (`keyPersonnelData`, `lettersOfIntentData`) 
                        and updated links to correspond with the new `supportingDocuments` array. */}
                    <div className="grid md:grid-cols-2 gap-6">
                        <Card>
                            <CardHeader>
                                <CardTitle>Key Personnel Qualifications</CardTitle>
                                <CardDescription>Principal Investigator expertise and credentials</CardDescription>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-4">
                                    <div>
                                        <h4 className="font-semibold text-lg">{keyPersonnelData.name}</h4>
                                        <p className="text-gray-600 text-sm">Founder, CEO & AI Engineer</p>
                                    </div>
                                    
                                    <div>
                                        <h5 className="font-medium mb-2">Key Qualifications:</h5>
                                        <ul className="space-y-1 text-sm">
                                            {keyPersonnelData.qualifications.map((qual, index) => (
                                                <li key={index} className="flex items-start gap-2">
                                                    <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                                                    <span>{qual}</span>
                                                </li>
                                            ))}
                                        </ul>
                                    </div>

                                    <Alert className="bg-blue-50 border-blue-200">
                                        <Users className="h-4 w-4 text-blue-600" />
                                        <AlertDescription className="text-blue-700 text-sm">
                                            <strong>Unique Advantage:</strong> The only CMMC AI platform founded by someone with 24+ years of 
                                            government compliance experience. This domain expertise cannot be hired or replicated quickly.
                                        </AlertDescription>
                                    </Alert>
                                </div>
                            </CardContent>
                        </Card>

                        <Card>
                            <CardHeader>
                                <CardTitle>Supporting Evidence</CardTitle>
                                <CardDescription>Letters of Intent and market validation</CardDescription>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-4">
                                    <div>
                                        <h4 className="font-semibold">Letters of Intent</h4>
                                        <p className="text-gray-600 text-sm mb-3">{lettersOfIntentData.count} from potential clients</p>
                                        
                                        <div className="bg-green-50 p-4 rounded">
                                            <ul className="space-y-2 text-sm">
                                                {lettersOfIntentData.companies.map((company, index) => (
                                                    <li key={index} className="flex items-start gap-2">
                                                        <Award className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                                                        <span>{company}</span>
                                                    </li>
                                                ))}
                                            </ul>
                                        </div>
                                    </div>

                                    <Button asChild className="w-full">
                                        {/* Find the correct link from the new supportingDocuments array */}
                                        <Link to={supportingDocuments.find(doc => doc.name.includes("Letters of Intent"))?.link || '#'} >
                                            View Complete Evidence Package <ArrowRight className="w-4 h-4 ml-2" />
                                        </Link>
                                    </Button>
                                </div>
                            </CardContent>
                        </Card>
                    </div>

                    <Card>
                        <CardHeader>
                            {/* Renamed card title to avoid conflict with new appendix manifest item "Appendix C" */}
                            <CardTitle>Appendix: Single Expert + AI Model Risk Analysis</CardTitle> 
                            <CardDescription>Addressing reviewer concerns about founder-led approach</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <Alert className="bg-purple-50 border-purple-200 mb-4">
                                <Shield className="h-4 w-4 text-purple-600" />
                                <AlertTitle className="text-purple-800">Strategic Advantage, Not Risk</AlertTitle>
                                <AlertDescription className="text-purple-700">
                                    The single expert + AI model represents superior scalability and risk mitigation compared to traditional 
                                    multi-person teams. Every process is automated and documented in code, eliminating "tribal knowledge" risks 
                                    common in consulting firms.
                                </AlertDescription>
                            </Alert>
                            
                            <Button asChild className="w-full">
                                {/* Find the correct link from the new supportingDocuments array */}
                                <Link to={supportingDocuments.find(doc => doc.name.includes("Risk Mitigation"))?.link || '#'}>
                                    Read Complete Risk Mitigation Analysis <ArrowRight className="w-4 h-4 ml-2" />
                                </Link>
                            </Button>
                        </CardContent>
                    </Card>
                </TabsContent>
            </Tabs>

            <Card className="bg-red-50 border-red-200">
                <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                        <Video className="w-6 h-6 text-red-600" />
                        Missing Component: 5-Minute Video Demonstration
                    </CardTitle>
                    <CardDescription>AI-powered video creation tools for your technical demonstration</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="grid md:grid-cols-2 gap-4 mb-6">
                        {videoSuggestions.map((tool, index) => (
                            <div key={index} className="p-4 bg-white rounded-lg border">
                                <div className="flex justify-between items-start mb-2">
                                    <h4 className="font-semibold">{tool.tool}</h4>
                                    <Badge variant="outline">{tool.pricing}</Badge>
                                </div>
                                <p className="text-sm text-gray-600 mb-2">{tool.description}</p>
                                <p className="text-sm text-green-600 mb-2"><strong>Best for:</strong> {tool.bestFor}</p>
                                <p className="text-sm text-gray-500">{tool.pros}</p>
                            </div>
                        ))}
                    </div>
                    
                    <Alert>
                        <Bot className="h-4 w-4" />
                        <AlertTitle>Recommended Approach</AlertTitle>
                        <AlertDescription>
                            Use <strong>Loom</strong> for a quick 5-minute screen recording showing the platform in action, 
                            combined with <strong>Descript</strong> for professional editing and automatic captions. 
                            Total cost: ~$20/month, professional results in 2-3 hours.
                        </AlertDescription>
                    </Alert>
                </CardContent>
            </Card>

            <div className="text-center">
                <Card className="bg-green-50 border-green-300">
                    <CardContent className="p-8">
                        <h2 className="text-2xl font-bold text-green-800 mb-4">Proposal Status: Ready for Final Review</h2>
                        <p className="text-green-700 mb-6">
                            This complete SBIR proposal package represents a comprehensive, competitive submission. 
                            All written components are finalized. Only the video demonstration remains to complete the package.
                        </p>
                        <div className="flex flex-col sm:flex-row gap-4 justify-center">
                            <Button asChild size="lg" className="bg-green-600 hover:bg-green-700">
                                <Link to={createPageUrl('SBIRProposalStrategy')}>
                                    Return to Proposal Hub <ArrowRight className="w-5 h-5 ml-2" />
                                </Link>
                            </Button>
                            <Button asChild size="lg" variant="outline">
                                <a href="#" onClick={() => window.print()}>
                                    <Download className="w-5 h-5 mr-2" />
                                    Print Complete Proposal
                                </a>
                            </Button>
                        </div>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}
