import React, { useState, useEffect } from 'react';
import { User } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { toast } from "sonner";
import { PlusCircle, Send, UserPlus, Shield, RefreshCw } from 'lucide-react';
import BreadcrumbNav from '../components/navigation/BreadcrumbNav';

export default function UserManagement() {
    const [users, setUsers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [currentUser, setCurrentUser] = useState(null);
    const [showInviteForm, setShowInviteForm] = useState(false);
    const [newUser, setNewUser] = useState({ email: '', fullName: '', partnership_role: 'prospect' });

    const loadUsers = async () => {
        setLoading(true);
        try {
            const user = await User.me();
            setCurrentUser(user);

            // Corrected check: Use 'partnership_role' to determine admin status
            if (user.partnership_role === 'admin') {
                const userList = await User.list();
                setUsers(userList);
            } else {
                // If not admin, just show the current user to avoid permission errors
                setUsers([user]);
            }
        } catch (error) {
            toast.error("Failed to load user data.");
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        loadUsers();
    }, []);

    const handleInviteUser = async (e) => {
        e.preventDefault();
        if (!newUser.email || !newUser.fullName) {
            toast.error("Email and Full Name are required.");
            return;
        }

        try {
            await User.create({
                email: newUser.email,
                full_name: newUser.fullName,
                partnership_role: newUser.partnership_role,
            });
            toast.success(`User ${newUser.fullName} created. They can now log in.`);
            setNewUser({ email: '', fullName: '', partnership_role: 'prospect' });
            setShowInviteForm(false);
            loadUsers();
        } catch (error) {
            toast.error(`Failed to invite user: ${error.message}`);
        }
    };

    const handleRoleChange = async (userId, newRole) => {
        try {
            await User.update(userId, { partnership_role: newRole });
            toast.success("User role updated successfully.");
            loadUsers();
        } catch (error) {
            toast.error("Failed to update user role.");
            console.error(error);
        }
    };

    // Permission check: If current user is not an admin, display a clear access denied message.
    // Corrected check to use 'partnership_role'.
    if (currentUser && currentUser.partnership_role !== 'admin') {
        return (
            <div className="space-y-6">
                <BreadcrumbNav currentPageName="User Management" />
                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6">
                    <h2 className="text-xl font-bold text-yellow-800 mb-2 flex items-center gap-2">
                        <Shield className="w-6 h-6" /> Admin Access Required
                    </h2>
                    <p className="text-yellow-700 mb-4">
                        You need administrator privileges to manage users. You are currently logged in as: <strong>{currentUser.full_name}</strong> with role: <strong>{currentUser.partnership_role}</strong>
                    </p>
                    <p className="text-sm text-yellow-600">
                        To access user management, please log in with your admin account (`hypercorelit3z3r0day@gmail.com`) or contact support to upgrade your permissions.
                    </p>
                </div>
            </div>
        );
    }

    return (
        <div className="space-y-6">
            <BreadcrumbNav currentPageName="User Management" />
            <CardHeader className="px-0">
                <CardTitle className="text-3xl font-bold flex items-center gap-3">
                    <UserPlus className="w-8 h-8 text-blue-600" />
                    User Invitation & Role Management
                </CardTitle>
                <CardDescription>
                    Securely invite new users to the platform and manage their roles. Only admins can access this page.
                </CardDescription>
            </CardHeader>

            <Card>
                <CardHeader>
                    <CardTitle className="flex justify-between items-center">
                        <span>Invite New User</span>
                        <Button variant="ghost" size="sm" onClick={() => setShowInviteForm(!showInviteForm)}>
                            {showInviteForm ? 'Cancel' : <><PlusCircle className="w-4 h-4 mr-2"/> Add User</>}
                        </Button>
                    </CardTitle>
                </CardHeader>
                {showInviteForm && (
                    <CardContent>
                        <form onSubmit={handleInviteUser} className="flex flex-col md:flex-row items-end gap-4">
                            <div className="flex-grow w-full">
                                <label className="text-sm font-medium">Full Name</label>
                                <Input placeholder="John Doe" value={newUser.fullName} onChange={(e) => setNewUser({...newUser, fullName: e.target.value})} required />
                            </div>
                            <div className="flex-grow w-full">
                                <label className="text-sm font-medium">Email Address</label>
                                <Input type="email" placeholder="user@company.com" value={newUser.email} onChange={(e) => setNewUser({...newUser, email: e.target.value})} required />
                            </div>
                            <div className="w-full md:w-auto">
                                <label className="text-sm font-medium">Assign Role</label>
                                <Select value={newUser.partnership_role} onValueChange={(value) => setNewUser({...newUser, partnership_role: value})}>
                                    <SelectTrigger>
                                        <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="prospect">Client (Prospect)</SelectItem>
                                        <SelectItem value="admin">Admin</SelectItem>
                                        <SelectItem value="legal_partner">Legal Partner</SelectItem>
                                        <SelectItem value="auditor">Auditor</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                            <Button type="submit" className="w-full md:w-auto"><Send className="w-4 h-4 mr-2" />Invite User</Button>
                        </form>
                    </CardContent>
                )}
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle className="flex justify-between items-center">
                        <span>Current Users</span>
                        <Button variant="outline" size="sm" onClick={loadUsers} disabled={loading}>
                            <RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`}/> Refresh
                        </Button>
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Full Name</TableHead>
                                <TableHead>Email</TableHead>
                                <TableHead>Current Role</TableHead>
                                <TableHead className="w-48">Change Role</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {users.map(user => (
                                <TableRow key={user.id}>
                                    <TableCell className="font-medium">{user.full_name}</TableCell>
                                    <TableCell>{user.email}</TableCell>
                                    <TableCell><Badge variant={user.partnership_role === 'admin' ? 'destructive' : 'secondary'}>{user.partnership_role}</Badge></TableCell>
                                    <TableCell>
                                        <Select
                                            defaultValue={user.partnership_role}
                                            onValueChange={(newRole) => handleRoleChange(user.id, newRole)}
                                            // Corrected check for disabling role change
                                            disabled={currentUser?.partnership_role !== 'admin' || user.id === currentUser?.id}
                                        >
                                            <SelectTrigger>
                                                <SelectValue />
                                            </SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="prospect">Client</SelectItem>
                                                <SelectItem value="admin">Admin</SelectItem>
                                                <SelectItem value="legal_partner">Legal Partner</SelectItem>
                                                <SelectItem value="auditor">Auditor</SelectItem>
                                            </SelectContent>
                                        </Select>
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </CardContent>
            </Card>
        </div>
    );
}