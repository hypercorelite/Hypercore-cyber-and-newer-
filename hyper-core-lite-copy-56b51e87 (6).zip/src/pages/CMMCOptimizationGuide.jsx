
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CheckCircle, AlertTriangle, DollarSign, Users, FileText, Shield, Zap, Target, TrendingUp, Clock, ArrowRight } from 'lucide-react';
import { motion } from "framer-motion";

const optimizationStrategies = [
    {
        category: "Resource & Financial Optimization",
        icon: DollarSign,
        challenges: [
            "High implementation and ongoing costs",
            "Limited internal security expertise", 
            "Sustained investment requirements"
        ],
        solutions: [
            {
                strategy: "Phased Budget Allocation",
                description: "Split CMMC costs across fiscal periods to avoid budget shock",
                implementation: "Year 1: Gap assessment & critical controls ($15K-25K), Year 2: Remaining controls & assessment ($20K-30K)",
                cost_savings: "40-50% cash flow improvement",
                timeline: "Spreads costs over 18-24 months"
            },
            {
                strategy: "Shared Resource Model",
                description: "Pool resources with other small contractors or use expert guidance services",
                implementation: "Engage expert-guided services like HyperCore's 90-day program vs. hiring full-time security staff",
                cost_savings: "70-80% vs. internal hiring",
                timeline: "Immediate access to expertise"
            },
            {
                strategy: "Technology Leverage Strategy",
                description: "Use cloud-native security tools that scale with your needs",
                implementation: "AWS Security Hub, Config Rules, CloudTrail - pay only for what you use",
                cost_savings: "60-70% vs. on-premise solutions",
                timeline: "Scales from $100/month to enterprise"
            }
        ]
    },
    {
        category: "Complexity & Implementation Optimization",
        icon: Shield,
        challenges: [
            "Confusing NIST SP 800-171 requirements",
            "Inadequate environment scoping",
            "Documentation burden"
        ],
        solutions: [
            {
                strategy: "Control Mapping Automation",
                description: "Use AI-powered tools to map your environment to CMMC controls",
                implementation: "Automated policy generation, control mapping, and evidence collection templates",
                cost_savings: "90% faster documentation",
                timeline: "Days instead of months"
            },
            {
                strategy: "Simplified Scoping Methodology", 
                description: "Use data flow diagrams and automated discovery to define CUI boundaries",
                implementation: "Network mapping tools + data classification automation",
                cost_savings: "Prevents over-scoping costs",
                timeline: "2-3 weeks for complete scope definition"
            },
            {
                strategy: "Progressive Implementation",
                description: "Implement controls in order of impact and difficulty",
                implementation: "Start with high-impact, low-effort controls (MFA, encryption) then build complexity",
                cost_savings: "60% faster time to basic compliance",
                timeline: "Immediate security improvements"
            }
        ]
    },
    {
        category: "Supply Chain Optimization",
        icon: Users,
        challenges: [
            "Downstream contractor accountability",
            "Subcontractor readiness gaps",
            "CUI flow across fragmented systems"
        ],
        solutions: [
            {
                strategy: "Supply Chain Risk Assessment Automation",
                description: "Automated vendor risk scoring and compliance tracking",
                implementation: "Questionnaire automation, continuous monitoring, automated compliance reports",
                cost_savings: "80% reduction in manual oversight",
                timeline: "Real-time compliance visibility"
            },
            {
                strategy: "Subcontractor Readiness Program",
                description: "Proactive subcontractor compliance assistance",
                implementation: "Shared training programs, template sharing, group C3PAO assessments",
                cost_savings: "50-60% reduction in supply chain disruption",
                timeline: "6-month subcontractor readiness"
            },
            {
                strategy: "CUI Flow Automation",
                description: "Automated CUI tagging and tracking across systems",
                implementation: "Data loss prevention (DLP) tools with automated CUI classification",
                cost_savings: "Eliminates manual data tracking",
                timeline: "Continuous automated monitoring"
            }
        ]
    },
    {
        category: "Assessment & Readiness Optimization",
        icon: FileText,
        challenges: [
            "Proving compliance with adequate evidence",
            "Limited internal assessment capabilities",
            "C3PAO availability and costs"
        ],
        solutions: [
            {
                strategy: "Continuous Evidence Collection",
                description: "Automated evidence gathering and organization",
                implementation: "Log aggregation, automated screenshots, policy compliance tracking",
                cost_savings: "90% reduction in audit preparation time",
                timeline: "Always audit-ready"
            },
            {
                strategy: "Mock Assessment Program",
                description: "Regular internal assessments using C3PAO methodology",
                implementation: "Quarterly self-assessments with external validation",
                cost_savings: "Identifies >95% of potential audit findings before the official assessment",
                timeline: "Continuous readiness validation"
            },
            {
                strategy: "C3PAO Relationship Management",
                description: "Early engagement and relationship building with assessors",
                implementation: "Join C3PAO waitlists early, build relationships before need",
                cost_savings: "Priority scheduling, better rates",
                timeline: "6-month advance planning"
            }
        ]
    },
    {
        category: "Strategic & Cultural Optimization",
        icon: Target,
        challenges: [
            "Lack of management buy-in",
            "Reactive compliance culture",
            "Change management resistance"
        ],
        solutions: [
            {
                strategy: "Business Case Development",
                description: "Frame CMMC as competitive advantage, not compliance burden",
                implementation: "ROI calculations, competitive differentiation metrics, contract opportunity analysis",
                cost_savings: "Justifies investment through revenue protection",
                timeline: "Immediate business case clarity"
            },
            {
                strategy: "Proactive Compliance Culture",
                description: "Embed security into business processes from the start",
                implementation: "Security awareness training, regular assessments, celebration of security achievements",
                cost_savings: "Prevents reactive crisis spending",
                timeline: "Cultural transformation over 6-12 months"
            },
            {
                strategy: "Change Management Framework",
                description: "Structured approach to organizational change",
                implementation: "Executive sponsorship, change champions, communication plan, success metrics",
                cost_savings: "85% higher implementation success rate",
                timeline: "Smooth transition over implementation period"
            }
        ]
    }
];

const quickWins = [
    {
        action: "Implement Multi-Factor Authentication (MFA)",
        effort: "Low",
        cost: "$5-10/user/month",
        impact: "Addresses multiple CMMC controls immediately",
        timeline: "1-2 weeks"
    },
    {
        action: "Enable Comprehensive Logging",
        effort: "Medium", 
        cost: "$50-200/month",
        impact: "Critical for audit evidence and incident response",
        timeline: "2-4 weeks"
    },
    {
        action: "Conduct Data Classification Exercise",
        effort: "Medium",
        cost: "$2,000-5,000",
        impact: "Properly scopes your CMMC environment",
        timeline: "4-6 weeks"
    },
    {
        action: "Implement Automated Patching",
        effort: "High",
        cost: "$100-500/month",
        impact: "Addresses vulnerability management requirements",
        timeline: "6-8 weeks"
    }
];

export default function CMMCOptimizationGuide() {
    const [activeTab, setActiveTab] = useState("resources");

    return (
        <div className="space-y-8">
            <CardHeader className="px-0">
                <CardTitle className="text-3xl font-bold">CMMC Implementation Optimization Guide</CardTitle>
                <CardDescription className="text-lg">
                    Strategic solutions to overcome the most common CMMC implementation challenges
                </CardDescription>
            </CardHeader>

            <Alert className="bg-green-50 border-green-200">
                <TrendingUp className="h-4 w-4 text-green-600" />
                <AlertTitle className="text-green-800">Optimization Impact</AlertTitle>
                <AlertDescription className="text-green-700">
                    Companies using these optimization strategies typically see 60-80% cost reduction, 70% faster implementation, and dramatically improved C3PAO audit preparedness.
                </AlertDescription>
            </Alert>

            <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="grid w-full grid-cols-5">
                    <TabsTrigger value="resources">Resources</TabsTrigger>
                    <TabsTrigger value="complexity">Complexity</TabsTrigger>
                    <TabsTrigger value="supply-chain">Supply Chain</TabsTrigger>
                    <TabsTrigger value="assessment">Assessment</TabsTrigger>
                    <TabsTrigger value="culture">Culture</TabsTrigger>
                </TabsList>

                {optimizationStrategies.map((category, categoryIndex) => (
                    <TabsContent 
                        key={category.category}
                        value={["resources", "complexity", "supply-chain", "assessment", "culture"][categoryIndex]}
                    >
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center gap-3">
                                    <category.icon className="w-6 h-6 text-blue-600" />
                                    {category.category}
                                </CardTitle>
                                <CardDescription>
                                    Common challenges: {category.challenges.join(", ")}
                                </CardDescription>
                            </CardHeader>
                            <CardContent className="space-y-6">
                                {category.solutions.map((solution, index) => (
                                    <motion.div
                                        key={index}
                                        initial={{ opacity: 0, y: 20 }}
                                        animate={{ opacity: 1, y: 0 }}
                                        transition={{ delay: index * 0.1 }}
                                    >
                                        <Card className="border-l-4 border-blue-500">
                                            <CardHeader>
                                                <CardTitle className="text-lg">{solution.strategy}</CardTitle>
                                                <CardDescription>{solution.description}</CardDescription>
                                            </CardHeader>
                                            <CardContent>
                                                <div className="grid md:grid-cols-2 gap-4 mb-4">
                                                    <div>
                                                        <h5 className="font-semibold text-sm mb-2">Implementation:</h5>
                                                        <p className="text-sm text-gray-600">{solution.implementation}</p>
                                                    </div>
                                                    <div className="space-y-2">
                                                        <div className="flex justify-between">
                                                            <span className="text-sm font-medium">Cost Savings:</span>
                                                            <Badge className="bg-green-100 text-green-800">{solution.cost_savings}</Badge>
                                                        </div>
                                                        <div className="flex justify-between">
                                                            <span className="text-sm font-medium">Timeline:</span>
                                                            <Badge variant="outline">{solution.timeline}</Badge>
                                                        </div>
                                                    </div>
                                                </div>
                                            </CardContent>
                                        </Card>
                                    </motion.div>
                                ))}
                            </CardContent>
                        </Card>
                    </TabsContent>
                ))}
            </Tabs>

            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                        <Zap className="w-6 h-6 text-yellow-600" />
                        Quick Wins: Immediate Impact Actions
                    </CardTitle>
                    <CardDescription>
                        High-impact actions you can start immediately while developing your comprehensive strategy
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="space-y-4">
                        {quickWins.map((win, index) => (
                            <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                                <div className="flex-grow">
                                    <h4 className="font-semibold">{win.action}</h4>
                                    <p className="text-sm text-gray-600">{win.impact}</p>
                                </div>
                                <div className="flex gap-2">
                                    <Badge variant={win.effort === 'Low' ? 'default' : win.effort === 'Medium' ? 'secondary' : 'destructive'}>
                                        {win.effort} Effort
                                    </Badge>
                                    <Badge variant="outline">{win.cost}</Badge>
                                    <Badge variant="outline">{win.timeline}</Badge>
                                </div>
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>

            <Alert>
                <Target className="h-4 w-4" />
                <AlertTitle>Ready to Optimize Your CMMC Implementation?</AlertTitle>
                <AlertDescription>
                    <div className="mt-2 space-y-2">
                        <p>These optimization strategies can significantly reduce your costs, timeline, and risk. The key is starting with a structured approach.</p>
                        <Button asChild className="mt-2">
                            <a href={`mailto:partnerships@hypercorecyber.com?subject=CMMC Optimization Consultation&body=I'm interested in learning how to optimize our CMMC implementation using the strategies outlined in your guide.`}>
                                Schedule Optimization Consultation <ArrowRight className="w-4 h-4 ml-2" />
                            </a>
                        </Button>
                    </div>
                </AlertDescription>
            </Alert>
        </div>
    );
}
