import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';
import { getAnalyticsReport } from '@/api/functions';
import { LoadingSpinner } from '@/components/ui/LoadingSpinner';
import { Users, AlertTriangle, TrendingUp, Activity, FileText, BarChart } from 'lucide-react';
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert";

export default function AnalyticsDashboard() {
    const [analytics, setAnalytics] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchData = async () => {
            setLoading(true); // Reset loading state to true
            setError(null); // Clear any previous errors
            try {
                const { data } = await getAnalyticsReport();
                if (data.error || !data.success) { // Hardening: check for !data.success as well
                    throw new Error(data.error || "Failed to fetch analytics.");
                }
                setAnalytics(data);
            } catch (err) {
                setError(err.message);
                console.error(err);
            } finally {
                setLoading(false);
            }
        };
        fetchData();
    }, []);

    if (loading) {
        return <LoadingSpinner text="Loading Real Analytics Data..." />;
    }

    if (error) {
        return (
            <div className="text-center p-8 text-red-600">
                <AlertTriangle className="w-12 h-12 mx-auto mb-4" />
                <h2 className="text-xl font-bold">Failed to load analytics</h2>
                <p>{error}</p>
            </div>
        );
    }

    // Ensure analytics and its nested properties are available before rendering
    if (!analytics || !analytics.summary) {
        return (
            <div className="text-center p-8 text-gray-600">
                <p>No analytics data available. Please try again later.</p>
            </div>
        );
    }

    return (
        <div className="space-y-6">
            <h1 className="text-3xl font-bold">Real Platform Analytics Dashboard</h1>
            <CardDescription>Authentic user interaction data since platform launch. No sample or demo data included.</CardDescription>
            
            <Alert className="bg-blue-50 border-blue-200">
                <BarChart className="h-4 w-4 text-blue-700" />
                <AlertTitle className="font-bold text-blue-800">Real Data Guarantee</AlertTitle>
                <AlertDescription className="text-blue-700">
                    {analytics.real_data_disclaimer} All metrics shown reflect genuine user behavior on your platform.
                </AlertDescription>
            </Alert>
            
            {/* Current Reality Metrics */}
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                <Card>
                    <CardHeader><CardTitle className="flex items-center text-sm gap-2"><Users /> Total Users</CardTitle></CardHeader>
                    <CardContent><p className="text-4xl font-bold text-blue-600">{analytics.summary.unique_users}</p><p className="text-sm text-gray-600">authentic users tracked</p></CardContent>
                </Card>
                <Card>
                    <CardHeader><CardTitle className="flex items-center text-sm gap-2"><Activity /> Platform Events</CardTitle></CardHeader>
                    <CardContent><p className="text-4xl font-bold text-green-600">{analytics.summary.total_events}</p><p className="text-sm text-gray-600">real interactions logged</p></CardContent>
                </Card>
                <Card>
                    <CardHeader><CardTitle className="flex items-center text-sm gap-2"><FileText /> LOIs Signed</CardTitle></CardHeader>
                    <CardContent><p className="text-4xl font-bold text-purple-600">{analytics.summary.lois_signed}</p><p className="text-sm text-gray-600">authentic commitments</p></CardContent>
                </Card>
                <Card>
                    <CardHeader><CardTitle className="flex items-center text-sm gap-2"><TrendingUp /> Success Rate</CardTitle></CardHeader>
                    <CardContent><p className="text-4xl font-bold text-orange-600">{analytics.summary.success_rate}%</p><p className="text-sm text-gray-600">of operations successful</p></CardContent>
                </Card>
            </div>

            {/* Real Activity Timeline */}
            <Card>
                <CardHeader><CardTitle>Daily Activity (Last 7 Days - Real Data Only)</CardTitle></CardHeader>
                <CardContent>
                    {analytics.daily_activity && analytics.daily_activity.length > 0 ? (
                        <ResponsiveContainer width="100%" height={300}>
                            <LineChart data={analytics.daily_activity}>
                                <XAxis dataKey="date" />
                                <YAxis />
                                <Tooltip />
                                <Line type="monotone" dataKey="events" stroke="#8884d8" strokeWidth={2} name="Events" />
                                <Line type="monotone" dataKey="users" stroke="#82ca9d" strokeWidth={2} name="Users" />
                            </LineChart>
                        </ResponsiveContainer>
                    ) : (
                        <div className="text-center py-8 text-gray-500">
                            <p>No activity data yet. Analytics will populate as users interact with the platform.</p>
                        </div>
                    )}
                </CardContent>
            </Card>

            {/* Top Events */}
            <Card>
                <CardHeader><CardTitle>Most Common User Actions</CardTitle></CardHeader>
                <CardContent>
                    {analytics.top_events && analytics.top_events.length > 0 ? (
                        <div className="space-y-2">
                            {analytics.top_events.map((event, i) => (
                                <div key={i} className="flex justify-between items-center p-3 bg-gray-50 rounded">
                                    <span className="font-medium">{event.event}</span>
                                    <span className="text-gray-600">{event.count} times</span>
                                </div>
                            ))}
                        </div>
                    ) : (
                        <div className="text-center py-8 text-gray-500">
                            <p>Event tracking will populate as users interact with the platform.</p>
                        </div>
                    )}
                </CardContent>
            </Card>

            {/* Platform Performance */}
            <Card>
                <CardHeader><CardTitle>Platform Performance Metrics</CardTitle></CardHeader>
                <CardContent>
                    <div className="grid md:grid-cols-3 gap-4">
                        <div className="text-center p-4 bg-gray-50 rounded">
                            <p className="text-2xl font-bold">{analytics.summary.average_response_time_ms}ms</p>
                            <p className="text-sm text-gray-600">Average Response Time</p>
                        </div>
                        <div className="text-center p-4 bg-gray-50 rounded">
                            <p className="text-2xl font-bold">{analytics.summary.ai_accuracy_percentage}%</p>
                            <p className="text-sm text-gray-600">AI Accuracy Score</p>
                        </div>
                        <div className="text-center p-4 bg-gray-50 rounded">
                            <p className="text-2xl font-bold">{analytics.summary.recent_activity_7_days}</p>
                            <p className="text-sm text-gray-600">Actions Last 7 Days</p>
                        </div>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}