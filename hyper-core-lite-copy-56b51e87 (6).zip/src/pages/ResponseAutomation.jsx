import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { SecurityPlaybook } from "@/api/entities";
import { Plus, Zap, Shield, ToggleRight } from 'lucide-react';
import { motion } from "framer-motion";

export default function ResponseAutomation() {
    const [playbooks, setPlaybooks] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const loadPlaybooks = async () => {
            try {
                const fetchedPlaybooks = await SecurityPlaybook.list('-created_date');
                setPlaybooks(fetchedPlaybooks);
            } catch (error) {
                console.error("Failed to load playbooks:", error);
            } finally {
                setLoading(false);
            }
        };
        loadPlaybooks();
    }, []);

    const getSeverityColor = (severity) => {
        const colors = {
            low: "bg-blue-100 text-blue-800",
            medium: "bg-yellow-100 text-yellow-800", 
            high: "bg-orange-100 text-orange-800",
            critical: "bg-red-100 text-red-800"
        };
        return colors[severity] || "bg-gray-100 text-gray-800";
    };

    return (
        <div className="min-h-screen bg-gray-50 p-6">
            <div className="max-w-7xl mx-auto">
                <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
                    <h1 className="text-4xl font-bold text-gray-900 mb-2 flex items-center gap-3">
                        <Zap className="w-10 h-10 text-yellow-600" />
                        Security Response Automation
                    </h1>
                    <p className="text-lg text-gray-600">
                        Automated security playbooks for instant threat response
                    </p>
                </motion.div>

                <div className="grid gap-6">
                    {playbooks.map((playbook) => (
                        <Card key={playbook.id} className="border-l-4 border-l-yellow-500">
                            <CardHeader>
                                <div className="flex justify-between items-start">
                                    <div>
                                        <CardTitle className="flex items-center gap-2">
                                            <Shield className="w-5 h-5 text-yellow-600" />
                                            {playbook.name}
                                        </CardTitle>
                                        <p className="text-gray-600 mt-1">{playbook.description}</p>
                                    </div>
                                    <Badge variant={playbook.is_active ? "default" : "secondary"}>
                                        {playbook.is_active ? "Active" : "Inactive"}
                                    </Badge>
                                </div>
                            </CardHeader>
                            <CardContent>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div>
                                        <h4 className="font-medium text-gray-900 mb-2">Trigger Conditions</h4>
                                        <div className="space-y-1">
                                            <Badge className="mr-2">{playbook.trigger_condition.threat_type}</Badge>
                                            <Badge className={getSeverityColor(playbook.trigger_condition.severity)}>
                                                {playbook.trigger_condition.severity} severity
                                            </Badge>
                                        </div>
                                    </div>
                                    <div>
                                        <h4 className="font-medium text-gray-900 mb-2">Response Actions</h4>
                                        <div className="space-y-1">
                                            {playbook.response_actions.map((action, idx) => (
                                                <Badge key={idx} variant="outline" className="mr-1 mb-1">
                                                    {action}
                                                </Badge>
                                            ))}
                                        </div>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    ))}
                </div>

                {loading && (
                    <div className="text-center py-12">
                        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-yellow-600 mx-auto"></div>
                        <p className="mt-4 text-gray-600">Loading security playbooks...</p>
                    </div>
                )}
            </div>
        </div>
    );
}