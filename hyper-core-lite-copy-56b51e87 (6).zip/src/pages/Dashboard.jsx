import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { LoadingSpinner, PageLoadingSpinner } from "../components/ui/LoadingSpinner";
import AdminDashboardView from "../components/dashboard/AdminDashboardView";
import ClientDashboardView from "../components/dashboard/ClientDashboardView";
import { Button } from "@/components/ui/button";
import { Eye } from "lucide-react";

export default function Dashboard() {
    const [currentUser, setCurrentUser] = useState(null);
    const [loading, setLoading] = useState(true);
    const [viewAsClient, setViewAsClient] = useState(false);

    useEffect(() => {
        const fetchUser = async () => {
            try {
                const user = await User.me();
                setCurrentUser(user);
            } catch (e) {
                console.error("User not logged in or fetch failed:", e);
                // The layout should handle redirects for non-logged-in users.
            } finally {
                setLoading(false);
            }
        };
        fetchUser();
    }, []);

    if (loading) {
        return <PageLoadingSpinner />;
    }

    const isAdmin = currentUser?.partnership_role === 'admin';
    const effectiveView = isAdmin && !viewAsClient ? 'admin' : 'client';

    const toggleView = () => setViewAsClient(prev => !prev);

    return (
        <div className="space-y-6">
            {isAdmin && (
                <div className="fixed bottom-4 right-4 z-50">
                    <Button onClick={toggleView} className="flex items-center gap-2 shadow-lg">
                        <Eye className="w-5 h-5" />
                        {effectiveView === 'admin' ? "View as Client" : "View as Admin"}
                    </Button>
                </div>
            )}
            
            {effectiveView === 'admin' ? (
                <AdminDashboardView user={currentUser} />
            ) : (
                <ClientDashboardView user={currentUser} />
            )}
        </div>
    );
}