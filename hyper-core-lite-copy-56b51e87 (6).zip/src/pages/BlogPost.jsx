import React, { useState, useEffect } from 'react';
import { BlogPost } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import ReactMarkdown from 'react-markdown';
import { Clock, User, Tag, AlertTriangle, ArrowRight, Loader2, Frown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';

export default function BlogPostPage() {
    const [post, setPost] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchPost = async () => {
            const params = new URLSearchParams(window.location.search);
            const slug = params.get('slug');
            if (!slug) {
                setLoading(false);
                return;
            }

            try {
                const results = await BlogPost.filter({ slug });
                if (results && results.length > 0) {
                    setPost(results[0]);
                }
            } catch (error) {
                console.error("Failed to fetch blog post:", error);
            } finally {
                setLoading(false);
            }
        };

        fetchPost();
    }, []);

    useEffect(() => {
        if (!post) return;

        // Full SEO optimization
        document.title = post.meta_title;
        document.querySelector('meta[name="description"]')?.setAttribute('content', post.meta_description);
        
        // Clean up previous schema/meta tags before adding new ones
        document.querySelectorAll('script[type="application/ld+json"]').forEach(e => e.remove());
        document.querySelectorAll('meta[name="keywords"], meta[property^="og:"], meta[name^="twitter:"]').forEach(e => e.remove());

        // Schema markup for better search visibility
        const script = document.createElement('script');
        script.type = 'application/ld+json';
        script.textContent = JSON.stringify({
            "@context": "https://schema.org",
            "@type": "Article",
            "headline": post.title,
            "description": post.meta_description,
            "author": { "@type": "Organization", "name": post.author },
            "publisher": { "@type": "Organization", "name": "HyperCore CMMC Training", "logo": { "@type": "ImageObject", "url": "https://hypercorecyber.com/logo.png" } },
            "keywords": post.primary_keywords?.join(', '),
            "articleSection": post.category,
            "mainEntityOfPage": { "@type": "WebPage", "@id": window.location.href },
            "image": post.featured_image_url
        });
        document.head.appendChild(script);
        
        const keywordsMeta = document.createElement('meta');
        keywordsMeta.name = 'keywords';
        keywordsMeta.content = post.primary_keywords?.join(', ');
        document.head.appendChild(keywordsMeta);
        
        // Open Graph and Twitter Card meta tags for social sharing  
        const metaTags = [
            { property: 'og:title', content: post.meta_title },
            { property: 'og:description', content: post.meta_description },
            { property: 'og:image', content: post.featured_image_url },
            { property: 'og:type', content: 'article' },
            { name: 'twitter:card', content: 'summary_large_image' },
            { name: 'twitter:title', content: post.meta_title },
            { name: 'twitter:description', content: post.meta_description },
            { name: 'twitter:image', content: post.featured_image_url }
        ];
        
        metaTags.forEach(tagData => {
            const meta = document.createElement('meta');
            if (tagData.property) meta.setAttribute('property', tagData.property);
            if (tagData.name) meta.setAttribute('name', tagData.name);
            meta.setAttribute('content', tagData.content);
            document.head.appendChild(meta);
        });

    }, [post]);

    if (loading) {
        return (
            <div className="flex justify-center items-center h-96">
                <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
                <span className="ml-4 text-lg text-gray-600">Loading Article...</span>
            </div>
        );
    }

    if (!post) {
        return (
            <div className="text-center py-20">
                <Frown className="w-16 h-16 mx-auto text-gray-400 mb-4" />
                <h1 className="text-2xl font-bold text-gray-800">Article Not Found</h1>
                <p className="text-gray-600 mt-2">The requested blog post could not be found.</p>
                <Button asChild className="mt-6">
                    <Link to={createPageUrl('KnowledgeHub')}>Back to Knowledge Hub</Link>
                </Button>
            </div>
        );
    }

    return (
        <div className="bg-white py-12 md:py-20">
            <div className="container mx-auto px-4 max-w-5xl">
                <article>
                    <header className="mb-12">
                        <Badge variant="outline" className="mb-4 bg-blue-100 text-blue-800 border-blue-300">
                            {post.category}
                        </Badge>
                        <h1 className="text-4xl md:text-5xl font-extrabold text-gray-900 mb-4">{post.title}</h1>
                        <div className="flex items-center gap-6 text-sm text-gray-500">
                            <div className="flex items-center gap-2">
                                <User className="w-4 h-4" />
                                <span>{post.author}</span>
                            </div>
                            <div className="flex items-center gap-2">
                                <Clock className="w-4 h-4" />
                                <span>{post.reading_time_minutes} min read</span>
                            </div>
                        </div>
                    </header>

                    {post.featured_image_url && (
                        <img src={post.featured_image_url} alt={post.featured_image_alt || post.title} className="w-full h-auto rounded-lg mb-8 object-cover aspect-[16/9]" />
                    )}

                    <Alert className="mb-8 bg-yellow-50 border-yellow-200">
                        <AlertTriangle className="h-4 w-4 text-yellow-600" />
                        <AlertTitle className="text-yellow-800 font-bold">Research-Based Analysis</AlertTitle>
                        <AlertDescription className="text-yellow-700">
                           This analysis synthesizes findings from DoD publications, industry reports, and federal regulations to provide evidence-based insights into CMMC compliance.
                        </AlertDescription>
                    </Alert>
                    
                    <div className="prose prose-lg max-w-none mx-auto prose-headings:font-bold prose-a:text-blue-600 hover:prose-a:text-blue-800 prose-table:text-sm prose-p:leading-relaxed prose-li:my-1">
                        <ReactMarkdown>{post.content}</ReactMarkdown>
                    </div>

                    <Card className="mt-12 bg-gradient-to-r from-blue-600 to-purple-700 text-white">
                        <CardHeader>
                            <CardTitle>AI Automation is Essential for CMMC</CardTitle>
                            <CardDescription className="text-blue-200">The evidence confirms manual compliance approaches are too costly and slow for SMBs.</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <p className="text-blue-100 mb-6">Our analysis shows AI can reduce CMMC compliance costs by 50-70% and cut timelines from over a year to just 90 days. This is no longer optional—it's essential for competing in the DIB.</p>
                            <Button asChild size="lg" className="bg-white text-blue-700 hover:bg-gray-100">
                                <Link to={createPageUrl('PartnershipTrial')}>
                                    Experience AI-Driven Compliance <ArrowRight className="w-5 h-5 ml-2" />
                                </Link>
                            </Button>
                        </CardContent>
                    </Card>

                     {post.primary_keywords && post.primary_keywords.length > 0 && (
                        <div className="mt-12 pt-8 border-t">
                            <h3 className="text-lg font-semibold flex items-center gap-2 mb-4 text-gray-800">
                                <Tag className="w-5 h-5"/>
                                Article Keywords
                            </h3>
                            <div className="flex flex-wrap gap-2">
                                {post.primary_keywords.map(keyword => (
                                    <Badge key={keyword} variant="secondary">{keyword}</Badge>
                                ))}
                            </div>
                        </div>
                    )}
                </article>
            </div>
        </div>
    );
}