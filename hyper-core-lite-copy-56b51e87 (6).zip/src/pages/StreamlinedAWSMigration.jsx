import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Shield, Zap, Bot, CheckCircle, Package, AlertTriangle, ArrowRight } from 'lucide-react';
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";
import { motion } from "framer-motion";

const whyAmplifyAndQ = [
    { title: "Ease of Migration", description: "Amplify’s wizard auto-configures hosting, APIs, and CI/CD, cutting setup errors by 80%." },
    { title: "Minimal Screw-Ups", description: "Guided workflows and AI validation catch IAM, networking, and CMMC compliance issues early." },
    { title: "Massive Cost Savings", description: "$0-50 migration cost and $0-3/month ongoing, all within AWS Free Tier." },
    { title: "Seamless Base44 Compatibility", description: "Handles Base44’s ZIP exports (React UI, JSON schemas) and refactors proprietary code." },
    { title: "Built-in CMMC Alignment", description: "Q ensures NIST 800-171 controls (encryption, audit logs) are built into the refactored code." },
    { title: "Drastic Time Efficiency", description: "Complete the migration in 1-2 weeks, not 3-6, by leveraging AI for 90%+ of the work." }
];

const migrationWorkflow = [
    { day: "Day 1", title: "Export Base44 App", cost: "$0", details: "Use a paid plan (~$50) to export the full project ZIP. Validate one page to confirm assets." },
    { day: "Days 2-3", title: "Refactor with Amazon Q", cost: "$0", details: "In VS Code, use Q Developer to convert the Base44 app to an Amplify-compatible, Flask-like Lambda backend with a DynamoDB schema." },
    { day: "Days 4-5", title: "Deploy with Amplify", cost: "$0-20", details: "Run 'amplify init' and 'amplify push'. Amplify auto-sets hosting, APIs, HTTPS, and CI/CD." },
    { day: "Day 6", title: "Migrate Data", cost: "$0-10", details: "Use AWS Glue (serverless ETL) to map the exported Base44 JSON/CSV data into your new DynamoDB table." },
    { day: "Days 7-10", title: "Test & Optimize", cost: "$0-10", details: "Simulate CMMC API calls and use AWS Config to audit NIST controls. Monitor logs in CloudWatch." },
    { day: "Week 2", title: "Go-Live", cost: "$0-3/mo", details: "Point domain to Amplify via Route 53, submit sitemap to Google, and set a $5/month AWS Budget alert." }
];

const packageOutput = `
hypercore_cmmc/
├── app.py             # Refactored Base44 APIs (Flask-like)
├── templates/         # Jinja UI (from React export)
├── models.py          # DynamoDB models
├── amplify.yml        # Amplify build/deploy config
├── requirements.txt   # Flask, boto3, etc.
└── README.md          # Deployment guide from Q
`;

const errorProofing = [
    "Amplify Wizard: Auto-configures IAM, VPC, and HTTPS, avoiding 90% of permission errors.",
    "Q Validation: AI checks code against CMMC controls (e.g., FIPS encryption).",
    "Free Tier Limits: Billing console tracks usage and alerts at your $5 cap.",
    "Incremental Testing: 'amplify mock api' allows local testing before deployment."
];

export default function StreamlinedAWSMigration() {
    return (
        <div className="space-y-8">
            <BreadcrumbNav currentPageName="StreamlinedAWSMigration" />

            <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="text-center">
                <Badge className="mb-4 bg-green-100 text-green-800">DEFINITIVE MIGRATION PLAYBOOK</Badge>
                <h1 className="text-4xl font-bold text-gray-900 mb-4">The AWS Amplify + Amazon Q Migration Strategy</h1>
                <p className="text-xl text-gray-600 max-w-4xl mx-auto">
                    The official, lowest-risk path from Base44 to a production-ready AWS Serverless environment for federal credibility.
                </p>
            </motion.div>

            <Alert className="bg-blue-50 border-blue-200">
                <Shield className="h-5 w-5 text-blue-600" />
                <AlertTitle className="text-blue-800 font-bold">This is the Recommended Path</AlertTitle>
                <AlertDescription className="text-blue-700 mt-2">
                    This strategy is the best fit because it maximizes automation and minimizes manual error. It leverages AWS's most user-friendly tools to deliver a CMMC-aligned, production-grade application in <strong>under 2 weeks</strong> for less than <strong>$50</strong>.
                </AlertDescription>
            </Alert>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {whyAmplifyAndQ.map((item, index) => (
                    <Card key={index}>
                        <CardHeader className="flex flex-row items-center gap-4 space-y-0">
                            <Zap className="w-6 h-6 text-green-500" />
                            <CardTitle>{item.title}</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="text-sm text-gray-600">{item.description}</p>
                        </CardContent>
                    </Card>
                ))}
            </div>

            <Card>
                <CardHeader>
                    <CardTitle>The 1-2 Week Streamlined Workflow</CardTitle>
                    <CardDescription>Step-by-step execution plan from Base44 export to AWS go-live.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    {migrationWorkflow.map((step, index) => (
                        <motion.div key={index} initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: index * 0.1 }}>
                            <div className="flex items-start gap-4 p-4 bg-gray-50 rounded-lg">
                                <Badge className="text-lg font-bold bg-gray-200 text-gray-700">{step.day}</Badge>
                                <div className="flex-grow">
                                    <h4 className="font-semibold text-gray-800">{step.title}</h4>
                                    <p className="text-sm text-gray-600">{step.details}</p>
                                </div>
                                <Badge variant="outline" className="text-green-700 border-green-200 bg-green-50">{step.cost}</Badge>
                            </div>
                        </motion.div>
                    ))}
                </CardContent>
            </Card>

            <div className="grid md:grid-cols-2 gap-6">
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2"><Package className="w-5 h-5 text-blue-600" /> Final Package Structure</CardTitle>
                        <CardDescription>The Flask-like project structure generated by AI.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <pre className="bg-gray-100 p-4 rounded-md text-xs text-gray-700 overflow-x-auto">
                            <code>{packageOutput.trim()}</code>
                        </pre>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2"><AlertTriangle className="w-5 h-5 text-red-600" /> Error-Proofing Guardrails</CardTitle>
                        <CardDescription>How this process prevents common migration failures.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-3">
                        {errorProofing.map((item, index) => (
                            <div key={index} className="flex items-start gap-3">
                                <CheckCircle className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                                <p className="text-sm text-gray-600">{item}</p>
                            </div>
                        ))}
                    </CardContent>
                </Card>
            </div>

            <Alert className="bg-green-50 border-green-200">
                <Bot className="h-5 w-5 text-green-600" />
                <AlertTitle className="text-green-800 font-bold">Next Step: Execute the Quick Start</AlertTitle>
                <AlertDescription className="text-green-700 mt-2">
                    Your immediate action is to perform a test run: Export one Base44 page, initialize a new Amplify project (`amplify init`), and use the Amazon Q extension in VS Code to refactor its API. This validates the entire workflow in a single day.
                </AlertDescription>
            </Alert>
        </div>
    );
}