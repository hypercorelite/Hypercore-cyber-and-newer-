import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { BlogPost } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ArrowRight, Calendar, User } from 'lucide-react';
import { LoadingSpinner } from '@/components/ui/LoadingSpinner';

export default function Blog() {
    const [posts, setPosts] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        document.title = "CMMC Compliance & AI Blog | HyperCore Cyber";
        document.querySelector('meta[name="description"]')?.setAttribute('content', 
            'Explore insights on CMMC 2.0, AI for compliance, and cybersecurity tips for DoD contractors. Stay informed with expert analysis from HyperCore Cyber.');

        const fetchPosts = async () => {
            setLoading(true);
            try {
                const publishedPosts = await BlogPost.filter({ status: 'published' }, '-created_date');
                setPosts(publishedPosts);
            } catch (error) {
                console.error("Failed to fetch blog posts:", error);
            } finally {
                setLoading(false);
            }
        };

        fetchPosts();
    }, []);

    return (
        <div className="bg-gray-50 min-h-screen">
            <div className="container mx-auto px-4 py-12 md:py-20">
                <div className="text-center mb-12">
                    <h1 className="text-4xl md:text-5xl font-extrabold text-gray-900">HyperCore AI Blog</h1>
                    <p className="mt-4 text-lg text-gray-600 max-w-2xl mx-auto">
                        Expert insights on CMMC, AI-driven compliance, and cybersecurity for the Defense Industrial Base.
                    </p>
                </div>

                {loading ? (
                    <LoadingSpinner text="Loading articles..." />
                ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                        {posts.map((post) => (
                            <Link to={createPageUrl(`BlogPost?slug=${post.slug}`)} key={post.id} className="block group">
                                <Card className="h-full hover:shadow-lg transition-shadow duration-300 flex flex-col">
                                    {post.featured_image_url && (
                                        <div className="aspect-video overflow-hidden rounded-t-lg">
                                            <img 
                                                src={post.featured_image_url} 
                                                alt={post.featured_image_alt || post.title}
                                                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                                            />
                                        </div>
                                    )}
                                    <CardHeader>
                                        <div className="flex flex-wrap gap-2 mb-2">
                                            <Badge variant="secondary">{post.category}</Badge>
                                            {post.keywords?.slice(0, 2).map(kw => <Badge key={kw} variant="outline">{kw}</Badge>)}
                                        </div>
                                        <CardTitle className="text-xl font-bold group-hover:text-blue-600 transition-colors">{post.title}</CardTitle>
                                    </CardHeader>
                                    <CardContent className="flex-grow flex flex-col">
                                        <p className="text-gray-600 text-sm mb-4 flex-grow">{post.meta_description}</p>
                                        <div className="text-xs text-gray-500 flex items-center justify-between mt-auto pt-4 border-t">
                                            <div className="flex items-center gap-2">
                                                <User className="w-3 h-3" /> {post.author}
                                            </div>
                                            <div className="flex items-center gap-2">
                                                <Calendar className="w-3 h-3" /> {new Date(post.created_date).toLocaleDateString()}
                                            </div>
                                        </div>
                                    </CardContent>
                                </Card>
                            </Link>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
}