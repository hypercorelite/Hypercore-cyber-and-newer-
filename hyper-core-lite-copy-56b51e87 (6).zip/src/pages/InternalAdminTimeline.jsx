import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, DollarSign, Target, Zap, ArrowRight, Shield, Rocket } from 'lucide-react';
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";

const phases = [
    {
        phase: "Phase 1: MVP Launch Readiness",
        timeline: "Sep 15 - Nov 10 (8 weeks)",
        budget: "$175 cash + sweat equity",
        outcome: "Live MVP + first paying clients + SBIR submitted",
        pricing: "$2,500-$7,500 MVP program",
        icon: Target,
        color: "border-green-500 bg-green-50",
        details: [
            "AI-powered gap analysis tool (manual upload)",
            "3-5 core policy templates generation", 
            "Basic SSP framework generation",
            "Email-based expert escalation",
            "PDF report generation",
            "First 5-10 beta clients acquired",
            "SBIR Phase I proposal submitted"
        ]
    },
    {
        phase: "Phase 2: SBIR Award & Scale Preparation",
        timeline: "Nov 10 - Apr 15 (6 months)",
        budget: "Bootstrap revenue + SBIR Phase I ($50K-$275K)",
        outcome: "Proven product-market fit + Phase II ready",
        pricing: "$12,500 full program launch",
        icon: Shield,
        color: "border-blue-500 bg-blue-50",
        details: [
            "Scale to 50+ clients on MVP platform",
            "Add 24/7 AI monitoring capabilities",
            "Implement automated evidence collection",
            "Build full 14-document policy suite",
            "Add real-time expert chat support",
            "SBIR Phase II proposal development ($750K-$1.5M)",
            "Partnership expansion (insurance, legal)"
        ]
    },
    {
        phase: "Phase 3: Commercial Scale & Automation",
        timeline: "Apr 15 - Dec 31 (9 months)",
        budget: "SBIR Phase II funding + commercial revenue",
        outcome: "Full platform automation + enterprise sales",
        pricing: "$25,000+ enterprise packages",
        icon: Rocket,
        color: "border-purple-500 bg-purple-50",
        details: [
            "Fully automated 'Dark CUI' discovery",
            "Enterprise multi-framework support",
            "White-label partner solutions",
            "C3PAO integration partnerships",
            "Federal marketplace presence",
            "International expansion planning",
            "IPO/acquisition positioning"
        ]
    }
];

export default function InternalAdminTimeline() {
    return (
        <div className="space-y-8">
            <BreadcrumbNav currentPageName="InternalAdminTimeline" />
            
            <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="text-center">
                <Badge className="mb-4 bg-red-100 text-red-800">ADMIN ONLY - STRATEGIC TIMELINE</Badge>
                <h1 className="text-4xl font-bold text-gray-900 mb-4">
                    The 3-Phase Scale Plan: MVP → SBIR → Commercial
                </h1>
                <p className="text-xl text-gray-600 max-w-4xl mx-auto">
                    Your complete roadmap from November 10 MVP launch to enterprise-scale platform. Each phase builds on the previous with clear financial and technical milestones.
                </p>
            </motion.div>

            <Alert className="bg-yellow-50 border-yellow-300">
                <Zap className="h-4 w-4 text-yellow-600" />
                <AlertTitle className="text-yellow-800">Current Status: Phase 1 Execution</AlertTitle>
                <AlertDescription className="text-yellow-700">
                    You are currently in the 8-week MVP sprint. Marketing is live, research is complete, and you're building the AI-first platform for November 10 launch.
                </AlertDescription>
            </Alert>

            <div className="space-y-8">
                {phases.map((phase, index) => (
                    <motion.div
                        key={index}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.2 }}
                    >
                        <Card className={`${phase.color} border-2`}>
                            <CardHeader>
                                <div className="flex items-center gap-4">
                                    <phase.icon className={`w-8 h-8 ${index === 0 ? 'text-green-600' : index === 1 ? 'text-blue-600' : 'text-purple-600'}`} />
                                    <div className="flex-grow">
                                        <CardTitle className="text-2xl">{phase.phase}</CardTitle>
                                        <CardDescription className="text-lg">
                                            {phase.timeline} • {phase.budget}
                                        </CardDescription>
                                    </div>
                                    <Badge className={`${index === 0 ? 'bg-green-600' : index === 1 ? 'bg-blue-600' : 'bg-purple-600'} text-white`}>
                                        {phase.pricing}
                                    </Badge>
                                </div>
                            </CardHeader>
                            <CardContent>
                                <div className="mb-4">
                                    <h4 className="font-semibold text-gray-800 mb-2">Target Outcome:</h4>
                                    <p className="text-gray-600">{phase.outcome}</p>
                                </div>
                                <div>
                                    <h4 className="font-semibold text-gray-800 mb-3">Key Deliverables:</h4>
                                    <div className="grid md:grid-cols-2 gap-2">
                                        {phase.details.map((detail, detailIndex) => (
                                            <div key={detailIndex} className="flex items-start gap-2">
                                                <div className={`w-2 h-2 rounded-full mt-2 ${index === 0 ? 'bg-green-500' : index === 1 ? 'bg-blue-500' : 'bg-purple-500'}`}></div>
                                                <span className="text-sm text-gray-700">{detail}</span>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    </motion.div>
                ))}
            </div>

            <Card className="bg-gray-900 text-white">
                <CardHeader>
                    <CardTitle className="text-2xl">Phase Integration Strategy</CardTitle>
                    <CardDescription className="text-gray-300">How each phase builds on the previous to create exponential growth</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="grid md:grid-cols-3 gap-6">
                        <div>
                            <h4 className="font-semibold mb-2">Phase 1 → Phase 2</h4>
                            <p className="text-sm text-gray-300">MVP proves product-market fit. SBIR funding enables automation features that justify premium pricing.</p>
                        </div>
                        <div>
                            <h4 className="font-semibold mb-2">Phase 2 → Phase 3</h4>
                            <p className="text-sm text-gray-300">Automated platform attracts enterprise clients. Proven ROI enables international expansion and acquisition discussions.</p>
                        </div>
                        <div>
                            <h4 className="font-semibold mb-2">Risk Mitigation</h4>
                            <p className="text-sm text-gray-300">Each phase is financially self-sustaining. If SBIR funding is delayed, revenue from previous phase funds continued development.</p>
                        </div>
                    </div>
                    <div className="pt-4 border-t border-gray-700">
                        <Button asChild size="lg" className="bg-white text-gray-900 hover:bg-gray-200">
                            <Link to={createPageUrl('DailyAchievementSchedule')}>
                                View Day-by-Day Phase 1 Execution Plan <ArrowRight className="w-4 h-4 ml-2" />
                            </Link>
                        </Button>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}