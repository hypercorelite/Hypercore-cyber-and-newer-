import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { CheckCircle, AlertTriangle, DollarSign, Users, ArrowRight, ExternalLink } from 'lucide-react';
import { motion } from "framer-motion";
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

const readinessAssessment = {
    technical_ready: [
        { feature: "AI Gap Analysis Tool", status: "✅ READY", details: "Working document upload & AI analysis" },
        { feature: "AI Policy Document Generator", status: "✅ READY", details: "Generates Access Control, IR, System Security policies" },
        { feature: "Basic SSP Framework", status: "✅ READY", details: "AI-generated System Security Plan templates" },
        { feature: "PDF Report Generation", status: "✅ READY", details: "Professional compliance reports for clients" },
        { feature: "Email Support System", status: "✅ READY", details: "Ticket system with admin escalation" },
        { feature: "8-Week Implementation Checklist", status: "✅ READY", details: "Structured task breakdown for clients" }
    ],
    customer_onboarding_gaps: [
        { gap: "No Payment Processing", impact: "CRITICAL", solution: "Need Stripe integration for $2,500/$7,500 tiers" },
        { gap: "No Clear Signup Flow", impact: "HIGH", solution: "Landing page links to PartnershipTrial, not paid signup" },
        { gap: "Manual Client Setup", impact: "MEDIUM", solution: "Onboarding requires admin intervention vs. self-service" },
        { gap: "No Tiered Access Control", impact: "MEDIUM", solution: "Can't differentiate $2,500 vs $7,500 feature access" }
    ],
    current_customer_flow: [
        { step: "1. Website Visit", status: "✅ WORKING", path: "Home page with MVP pricing" },
        { step: "2. Demo Request", status: "✅ WORKING", path: "PartnershipTrial page (free demo)" },
        { step: "3. Payment & Signup", status: "❌ MISSING", path: "No payment gateway - manual process" },
        { step: "4. Service Delivery", status: "⚠️ MANUAL", path: "Admin manually sets up client account" }
    ]
};

const immediateActions = [
    { action: "Add Stripe Payment Integration", timeline: "2-3 days", priority: "CRITICAL", why: "Can't charge customers without it" },
    { action: "Create Paid Signup Flow", timeline: "1-2 days", priority: "HIGH", why: "Bridge from demo to paid service" },
    { action: "Implement Service Tier Logic", timeline: "3-4 days", priority: "MEDIUM", why: "Differentiate $2,500 vs $7,500 access" },
    { action: "Automate Client Provisioning", timeline: "2-3 days", priority: "MEDIUM", why: "Scale beyond manual setup" }
];

export default function MVPReadinessStatus() {
    const technicalReadiness = Math.round((readinessAssessment.technical_ready.length / (readinessAssessment.technical_ready.length + readinessAssessment.customer_onboarding_gaps.length)) * 100);
    const customerReadiness = Math.round(((readinessAssessment.current_customer_flow.filter(step => step.status === "✅ WORKING").length) / readinessAssessment.current_customer_flow.length) * 100);

    return (
        <div className="space-y-8">
            <BreadcrumbNav currentPageName="MVPReadinessStatus" />

            <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="text-center">
                <Badge className="mb-4 bg-orange-100 text-orange-800">CUSTOMER READINESS ASSESSMENT</Badge>
                <h1 className="text-4xl font-bold text-gray-900 mb-4">MVP Technical vs. Commercial Readiness</h1>
                <p className="text-xl text-gray-600 max-w-4xl mx-auto">
                    Your technology works, but customer onboarding has critical gaps preventing paid signups.
                </p>
            </motion.div>

            <Alert className="bg-gradient-to-r from-yellow-500 to-orange-600 text-white border-0 shadow-lg">
                <AlertTriangle className="h-5 w-5 text-white" />
                <AlertTitle className="text-2xl font-bold">REALITY CHECK: You Can Demo, But Can't Take Money</AlertTitle>
                <AlertDescription className="text-lg mt-2">
                    Your AI engine is fully functional and impressive, but there's no payment system. Customers can try your demo, but can't buy the $2,500/$7,500 programs you're advertising.
                    <div className="mt-3 p-3 bg-white/20 rounded-lg">
                        <strong>The Gap:</strong> Your website promises paid tiers, but the signup flow leads to a free demo instead of a purchase.
                    </div>
                </AlertDescription>
            </Alert>

            <div className="grid md:grid-cols-2 gap-8">
                <Card className="bg-green-50 border-green-200">
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2 text-green-800">
                            <CheckCircle className="w-5 h-5" />
                            ✅ Technology: Ready for Customers
                        </CardTitle>
                        <CardDescription>Your core product functionality is complete</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-3">
                            {readinessAssessment.technical_ready.map((item, index) => (
                                <div key={index} className="p-3 bg-white rounded-lg border border-green-200">
                                    <div className="flex justify-between items-center mb-1">
                                        <h4 className="font-semibold text-green-800">{item.feature}</h4>
                                        <Badge className="bg-green-100 text-green-800 text-xs">READY</Badge>
                                    </div>
                                    <p className="text-sm text-gray-600">{item.details}</p>
                                </div>
                            ))}
                        </div>
                        <div className="mt-4 p-3 bg-green-100 rounded-lg">
                            <h4 className="font-bold text-green-800">Technical Readiness: {technicalReadiness}%</h4>
                            <p className="text-sm text-green-700">All advertised features are working and demonstrable</p>
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-orange-50 border-orange-200">
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2 text-orange-800">
                            <DollarSign className="w-5 h-5" />
                            ❌ Customer Onboarding: Critical Gaps
                        </CardTitle>
                        <CardDescription>Missing pieces preventing paid customers</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-3">
                            {readinessAssessment.customer_onboarding_gaps.map((item, index) => (
                                <div key={index} className="p-3 bg-white rounded-lg border border-orange-200">
                                    <div className="flex justify-between items-center mb-1">
                                        <h4 className="font-semibold text-orange-800">{item.gap}</h4>
                                        <Badge className={item.impact === 'CRITICAL' ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800'}>
                                            {item.impact}
                                        </Badge>
                                    </div>
                                    <p className="text-sm text-gray-600">{item.solution}</p>
                                </div>
                            ))}
                        </div>
                        <div className="mt-4 p-3 bg-orange-100 rounded-lg">
                            <h4 className="font-bold text-orange-800">Customer Readiness: {customerReadiness}%</h4>
                            <p className="text-sm text-orange-700">Can demo but cannot process paid customers</p>
                        </div>
                    </CardContent>
                </Card>
            </div>

            <Card>
                <CardHeader>
                    <CardTitle>Current Customer Journey Analysis</CardTitle>
                    <CardDescription>What happens when someone visits your website</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="space-y-4">
                        {readinessAssessment.current_customer_flow.map((step, index) => (
                            <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                                <div className="flex items-center gap-4">
                                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                                        step.status === '✅ WORKING' ? 'bg-green-100 text-green-800' :
                                        step.status === '❌ MISSING' ? 'bg-red-100 text-red-800' :
                                        'bg-yellow-100 text-yellow-800'
                                    }`}>
                                        {index + 1}
                                    </div>
                                    <div>
                                        <h4 className="font-semibold">{step.step}</h4>
                                        <p className="text-sm text-gray-600">{step.path}</p>
                                    </div>
                                </div>
                                <Badge className={
                                    step.status === '✅ WORKING' ? 'bg-green-100 text-green-800' :
                                    step.status === '❌ MISSING' ? 'bg-red-100 text-red-800' :
                                    'bg-yellow-100 text-yellow-800'
                                }>
                                    {step.status}
                                </Badge>
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>Immediate Actions to Enable Customer Onboarding</CardTitle>
                    <CardDescription>Priority fixes to start taking paid customers</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="space-y-4">
                        {immediateActions.map((action, index) => (
                            <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                                <div>
                                    <h4 className="font-semibold">{action.action}</h4>
                                    <p className="text-sm text-gray-600">{action.why}</p>
                                </div>
                                <div className="text-right">
                                    <Badge className={action.priority === 'CRITICAL' ? 'bg-red-100 text-red-800 mb-1' : 'bg-yellow-100 text-yellow-800 mb-1'}>
                                        {action.priority}
                                    </Badge>
                                    <p className="text-sm text-gray-500">{action.timeline}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-blue-900 to-purple-900 text-white">
                <CardHeader>
                    <CardTitle className="text-2xl">Bottom Line: Close to Launch, But Need Payment System</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <p className="text-lg"><strong>What Works:</strong> Your AI compliance engine is genuinely impressive and ready for customers. The demo experience is professional.</p>
                    
                    <p className="text-lg"><strong>What's Missing:</strong> You're advertising $2,500/$7,500 programs but have no way to collect payment or differentiate service tiers.</p>
                    
                    <p className="text-lg"><strong>Time to Fix:</strong> About 1 week of focused work to add Stripe integration and paid signup flow.</p>
                    
                    <div className="pt-4 flex flex-col sm:flex-row gap-4">
                        <Button asChild size="lg" className="bg-green-600 hover:bg-green-700 flex-1">
                            <Link to={createPageUrl('PaymentIntegrationPlan')}>
                                🚀 Plan Payment System Integration <ArrowRight className="w-5 h-5 ml-2" />
                            </Link>
                        </Button>
                        <Button asChild size="lg" variant="secondary" className="flex-1">
                            <Link to={createPageUrl('PartnershipTrial')}>
                                View Current Demo Flow <ExternalLink className="w-5 h-5 ml-2" />
                            </Link>
                        </Button>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}