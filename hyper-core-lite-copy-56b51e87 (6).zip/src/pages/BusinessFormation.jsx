
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { FileText, Landmark, Gavel, Shield, Users, Handshake } from 'lucide-react'; // Updated Lucide imports
import { motion } from "framer-motion";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

// Import all the formation components
import LLCPrepForm from '../components/formation/LLCPrepForm';
import OperatingAgreementGenerator from '../components/formation/OperatingAgreementGenerator';
import EINPrep from '../components/formation/EINPrep';
import SAMPrep from '../components/formation/SAMPrep';
import BankingConversionKit from '../components/formation/BankingConversionKit';
import StrategicPartnershipAgreement from "../components/partnership/StrategicPartnershipAgreement";

export default function BusinessFormation() {
    const [samStatus, setSamStatus] = useState('pending'); // 'pending', 'validated'

    return (
        <div className="min-h-screen bg-gray-50 p-6"> {/* Changed background and removed gradient */}
            <div className="max-w-7xl mx-auto"> {/* Changed max-w-6xl to max-w-7xl */}
                <motion.div
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="mb-8"
                >
                    <h1 className="text-4xl font-bold text-gray-900 mb-2 flex items-center gap-3">
                        {/* Briefcase icon removed as it's not in the new Lucide imports for the general layout */}
                        Minimum Viable Company Formation
                    </h1>
                    <p className="text-lg text-gray-600">
                        Bootstrap from $0 to SBIR-eligible defense contractor in 30 days
                    </p>
                </motion.div>

                <Tabs defaultValue="llc" className="space-y-6"> {/* Default value changed to llc, added space-y-6 */}
                    <TabsList className="grid w-full grid-cols-5"> {/* Adjusted grid-cols for better responsiveness */}
                        <TabsTrigger value="llc">
                            <FileText className="w-4 h-4 mr-2" />
                            LLC Articles
                        </TabsTrigger>
                        <TabsTrigger value="agreement">
                            <Gavel className="w-4 h-4 mr-2" />
                            Operating Agreement
                        </TabsTrigger>
                        <TabsTrigger value="ein">
                            <Shield className="w-4 h-4 mr-2" />
                            EIN / Tax ID
                        </TabsTrigger>
                        <TabsTrigger value="sam">
                            <Users className="w-4 h-4 mr-2" />
                            SAM.gov
                        </TabsTrigger>
                        <TabsTrigger value="partnership_agreement">
                            <Handshake className="w-4 h-4 mr-2" />
                            Partnership Agreements
                        </TabsTrigger>
                    </TabsList>

                    <TabsContent value="llc">
                        <LLCPrepForm />
                    </TabsContent>
                    <TabsContent value="agreement">
                        <OperatingAgreementGenerator />
                    </TabsContent>
                    <TabsContent value="ein">
                        <EINPrep />
                    </TabsContent>
                    <TabsContent value="sam">
                        <SAMPrep samStatus={samStatus} setSamStatus={setSamStatus} />
                    </TabsContent>
                    <TabsContent value="partnership_agreement">
                        <StrategicPartnershipAgreement />
                    </TabsContent>
                </Tabs>

                <Card className="mt-8">
                    <CardHeader>
                        <CardTitle className="text-lg">Banking Conversion Kit</CardTitle>
                        <CardDescription>Guidance and resources for setting up your business bank accounts.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <BankingConversionKit />
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}
