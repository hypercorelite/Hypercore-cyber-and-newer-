
import React, { useState, useEffect } from 'react';
import { BlogPost } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Search, BookOpen, Star, ChevronsRight, ArrowRight } from "lucide-react";
import { toast } from "sonner";
import { LoadingSpinner } from '../components/ui/LoadingSpinner';
import { Badge } from "@/components/ui/badge";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from "@/components/ui/button";

const PageLoadingSpinner = ({ text }) => (
    <div className="flex flex-col items-center justify-center min-h-[calc(10vh-20px)]">
        <LoadingSpinner />
        <p className="mt-4 text-lg text-gray-600">{text}</p>
    </div>
);

export default function KnowledgeHub() {
    const [posts, setPosts] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchPosts = async () => {
            try {
                const fetchedPosts = await BlogPost.list('-created_date');
                setPosts(fetchedPosts.filter(p => p.publish_status === 'published'));
            } catch (error) {
                console.error("Failed to load blog posts:", error);
                toast.error("Failed to load knowledge hub articles.");
            } finally {
                setLoading(false);
            }
        };
        fetchPosts();
    }, []);

    const filteredPosts = posts.filter(post =>
        post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (post.content && post.content.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (post.category && post.category.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (post.primary_keywords && post.primary_keywords.join(' ').toLowerCase().includes(searchTerm.toLowerCase()))
    );
    
    if (loading) {
        return <PageLoadingSpinner text="Loading Knowledge Hub..."/>;
    }

    const featuredPost = filteredPosts.find(p => p.slug === 'the-smb-playbook-for-cmmc-compliance') || (filteredPosts.length > 0 ? filteredPosts[0] : null);
    const otherPosts = filteredPosts.filter(p => p.id !== featuredPost?.id);

    return (
        <div className="bg-gradient-to-b from-gray-50 to-white py-12 md:py-20">
            <div className="container mx-auto px-4 max-w-6xl">
                <div className="text-center mb-12">
                    <BookOpen className="mx-auto h-12 w-12 text-blue-600 mb-4" />
                    <h1 className="text-4xl md:text-5xl font-extrabold text-gray-900 mb-4">
                        CMMC Knowledge Hub
                    </h1>
                    <p className="text-xl text-gray-600">
                        Expert articles, guides, and analysis on CMMC, AI, and DoD contracting.
                    </p>
                </div>

                <div className="relative mb-12 max-w-2xl mx-auto">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <Input
                        type="text"
                        placeholder="Search CMMC articles (e.g., 'DIY', 'SPRS', 'NIST 800-171')..."
                        className="pl-12 text-lg py-7 rounded-full"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                    />
                </div>

                {filteredPosts.length === 0 && !loading && (
                    <p className="text-center text-gray-500 py-12">No articles found matching your search. Try a different term.</p>
                )}

                {featuredPost && (
                     <Card className="mb-12 grid md:grid-cols-2 overflow-hidden shadow-xl border-blue-200 bg-gradient-to-r from-blue-50 to-white">
                        <div className="p-8 flex flex-col justify-center">
                            <Badge className="mb-4 w-fit bg-blue-100 text-blue-800"><Star className="w-3 h-3 mr-1"/> Featured Article</Badge>
                            <h2 className="text-3xl font-bold text-gray-900 mb-4">{featuredPost.title}</h2>
                            <CardDescription className="text-base text-gray-600 mb-6 line-clamp-3">
                                {featuredPost.meta_description}
                            </CardDescription>
                            <p className="text-sm text-gray-500 mb-2">By {featuredPost.author} • {featuredPost.reading_time_minutes} min read</p>
                            <Link to={createPageUrl(`BlogPost?slug=${featuredPost.slug}`)} className="text-blue-600 font-semibold hover:underline flex items-center gap-1">
                                Read Full Article <ArrowRight className="w-4 h-4" />
                            </Link>
                        </div>
                        {featuredPost.featured_image_url && (
                             <div className="h-64 md:h-auto bg-cover bg-center" style={{backgroundImage: `url(${featuredPost.featured_image_url})`}}></div>
                        )}
                    </Card>
                )}

                {otherPosts.length > 0 &&
                    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                        {otherPosts.map(post => (
                            <Link key={post.id} to={createPageUrl(`BlogPost?slug=${post.slug}`)} className="block">
                                <Card className="h-full hover:shadow-lg transition-shadow flex flex-col">
                                    {post.featured_image_url && (
                                        <img src={post.featured_image_url} alt={post.featured_image_alt || post.title} className="w-full h-40 object-cover rounded-t-lg"/>
                                    )}
                                    <CardHeader>
                                        <Badge variant="outline" className="mb-2 w-fit">{post.category}</Badge>
                                        <CardTitle>{post.title}</CardTitle>
                                    </CardHeader>
                                    <CardContent className="flex-grow">
                                        <p className="text-sm text-gray-600 line-clamp-3">
                                            {post.meta_description}
                                        </p>
                                    </CardContent>
                                    <div className="p-6 pt-0 text-xs text-gray-500">
                                        <span>By {post.author} • {post.reading_time_minutes} min read</span>
                                    </div>
                                </Card>
                            </Link>
                        ))}
                    </div>
                }
                <div className="mt-12 text-center">
                    <Button asChild variant="outline">
                        <Link to={createPageUrl('Resources')}>
                            View All Tools & Templates <ChevronsRight className="w-4 h-4 ml-2" />
                        </Link>
                    </Button>
                </div>
            </div>
        </div>
    );
}
