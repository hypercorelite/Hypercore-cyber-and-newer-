import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ArrowRight, FileText, Target, Calendar, AlertTriangle } from 'lucide-react';
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

const sbirCycles = [
    { cycle: "DoD SBIR 25.4 / STTR 25.D", preRelease: "Sep 24, 2025", release: "Oct 1, 2025", deadline: "Oct 29, 2025", notes: "URGENT: PRIMARY TARGET. Submission due mid-sprint. Proposal must be based on MVP progress.", status: "critical" },
    { cycle: "DoD SBIR 25.5 / STTR 25.E", preRelease: "Oct 22, 2025", release: "Nov 5, 2025", deadline: "Dec 3, 2025", notes: "First full cycle post-CMMC enforcement. Strong secondary target.", status: "high" },
    { cycle: "DoD SBIR 25.6 / STTR 25.F", preRelease: "Nov 19, 2025", release: "Dec 3, 2025", deadline: "Jan 28, 2026", notes: "Follow-on if 25.4 is missed. Leverages post-launch traction.", status: "medium" },
    { cycle: "DoD SBIR 26.1 / STTR 26.A", preRelease: "Dec 17, 2025", release: "Jan 7, 2026", deadline: "Feb 4, 2026", notes: "FY2026 funding cycle. Good for Phase II proposals.", status: "medium" }
];

const alignedTopics = [
    { id: "HR0011SB20254-12", title: "Assessing Security of Encrypted Messaging Applications (ASEMA)", agency: "DARPA", alignment: "Extends to AI for CMMC control monitoring (e.g., access/encryption under NIST 800-171), automating vulnerability scans for CUI protection.", deadline: "Closes: Oct 22, 2025", focus: true },
    { id: "A244-P037 (Example)", title: "AI/ML for Cybersecurity Anomaly Detection", agency: "Army (Open Topic)", alignment: "Directly supports CMMC continuous monitoring (e.g., AC-2, AU-6 controls); propose AI for automated compliance dashboards.", deadline: "Next cycle closes: Oct 29, 2025", focus: true },
    { id: "N242-XXX (Anticipated)", title: "ML-Based Compliance Automation", agency: "Navy", alignment: "Fits CMMC flow-down requirements for subcontractors, using ML for NIST mapping and audit prep.", deadline: "Submit by Dec 3, 2025", focus: false },
    { id: "HR0011SB20254-10", title: "Predictive Psychological Architectures for Decision-Making (PPADM)", agency: "DARPA", alignment: "Use for AI-driven risk assessments in CMMC POA&Ms or compliance decision support, enhancing Level 2/3 human-AI workflows.", deadline: "Closed: Sep 22, 2025 (Use as template for future topics)", focus: false },
];

export default function SBIRFundingStrategy() {
    return (
        <div className="space-y-8">
            <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center"
            >
                <Badge className="mb-4 bg-red-100 text-red-800">URGENT ACTION REQUIRED</Badge>
                <h1 className="text-4xl font-bold text-gray-900 mb-4">
                    SBIR Funding Strategy & Timeline
                </h1>
                <p className="text-xl text-gray-600 max-w-4xl mx-auto">
                    Actionable plan to secure Phase I SBIR funding in parallel with the 56-day MVP sprint.
                </p>
            </motion.div>

            <Alert variant="destructive">
                <AlertTriangle className="h-4 w-4" />
                <AlertTitle className="font-bold">Critical Deadline: October 29, 2025</AlertTitle>
                <AlertDescription>
                    The DoD SBIR 25.4 submission is due in 45 days. All MVP development and proposal writing must align with this deadline. This is your primary funding target.
                </AlertDescription>
            </Alert>

             <Card className="border-yellow-300 bg-yellow-50">
                <CardHeader>
                    <CardTitle>Official Registration Status (SAM.gov)</CardTitle>
                    <CardDescription>Status of your entity registration, a prerequisite for submission.</CardDescription>
                </CardHeader>
                <CardContent>
                    <h3 className="font-semibold text-lg">HYPERCORE LITE CYBERSECURITY ECOSYSTEM LLC</h3>
                    <Badge className="bg-yellow-500 text-white mt-1">Pending ID Assignment</Badge>
                    <p className="text-sm text-gray-700 mt-3">
                        You originally submitted documentation on Sep. 04, 2025.
                    </p>
                    <Alert className="mt-4 bg-blue-50 border-blue-200">
                        <AlertTriangle className="h-4 w-4 text-blue-600"/>
                        <AlertTitle className="text-blue-800 font-bold">Action Required</AlertTitle>
                        <AlertDescription className="text-blue-700">
                            Monitor your email for instructions from the entity validation service (EVS) to complete your Unique Entity ID assignment. This must be completed before you can submit the proposal.
                        </AlertDescription>
                    </Alert>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>Upcoming SBIR/STTR Cycles</CardTitle>
                    <CardDescription>Key dates and strategic notes for each relevant cycle. Focus is on 25.4.</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="space-y-4">
                        {sbirCycles.map((cycle) => (
                            <div key={cycle.cycle} className={`p-4 rounded-lg border-2 ${cycle.status === 'critical' ? 'border-red-500 bg-red-50' : 'border-gray-200'}`}>
                                <div className="flex flex-col sm:flex-row justify-between sm:items-center">
                                    <h3 className="font-semibold text-lg text-gray-800">{cycle.cycle}</h3>
                                    <Badge className={`${cycle.status === 'critical' ? 'bg-red-600' : 'bg-gray-600'} text-white`}>{cycle.deadline}</Badge>
                                </div>
                                <p className="text-sm text-gray-600 mt-2">{cycle.notes}</p>
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>Aligned Proposal Topics</CardTitle>
                    <CardDescription>Tailor your MVP's capabilities to these or similar upcoming topics.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    {alignedTopics.map((topic) => (
                        <div key={topic.id} className={`p-4 rounded-lg border ${topic.focus ? 'bg-blue-50 border-blue-200' : ''}`}>
                            <h4 className="font-bold text-blue-800">{topic.title} ({topic.agency})</h4>
                            <p className="text-sm text-gray-700 mt-2"><span className="font-semibold">Alignment:</span> {topic.alignment}</p>
                            <p className="text-xs text-gray-500 mt-2">Status: {topic.deadline}</p>
                        </div>
                    ))}
                </CardContent>
            </Card>

            <Card className="bg-gray-50">
                <CardHeader>
                    <CardTitle>Dual-Track Strategy: Build & Propose</CardTitle>
                    <CardDescription>How the 56-day sprint directly feeds the SBIR 25.4 proposal.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="grid md:grid-cols-2 gap-6">
                        <div>
                            <h4 className="font-semibold flex items-center gap-2"><Target className="text-green-600"/>MVP Development (Weeks 1-6)</h4>
                            <p className="text-sm text-gray-600 mt-2">Focus on building a functional demonstration of AI-driven gap analysis, SSP generation, and control mapping. This becomes the technical core of your proposal.</p>
                             <Button asChild variant="secondary" className="mt-3">
                                <Link to={createPageUrl('DailyAchievementSchedule')}>View Sprint Plan <ArrowRight className="w-4 h-4 ml-2"/></Link>
                            </Button>
                        </div>
                        <div>
                            <h4 className="font-semibold flex items-center gap-2"><FileText className="text-blue-600"/>Proposal Writing (Parallel)</h4>
                            <p className="text-sm text-gray-600 mt-2">Use the documentation, architecture diagrams, and preliminary results from your MVP to write the technical volume. Draft the commercialization plan based on your GTM strategy.</p>
                             <Button asChild variant="secondary" className="mt-3">
                                <Link to={createPageUrl('SBIRGrantRequirements')}>View Proposal Checklist <ArrowRight className="w-4 h-4 ml-2"/></Link>
                            </Button>
                        </div>
                    </div>
                </CardContent>
            </Card>

        </div>
    );
}