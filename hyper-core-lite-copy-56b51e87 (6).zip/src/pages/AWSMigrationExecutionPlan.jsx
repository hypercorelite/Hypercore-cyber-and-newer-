import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Download, Server, HardDrive, TestTube, CheckCircle, ArrowRight } from 'lucide-react';
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";

const migrationPhases = [
    {
        phase: "Phase 1: Prepare the Source Server (Your EC2 Instance)",
        effort: "1-2 days",
        steps: [
            "Export full application code from Base44.",
            "Set up the exported React frontend and backend services on your existing EC2 instance.",
            "Install the AWS Application Migration Service (MGN) agent on the EC2 instance.",
            "Initiate continuous data replication from the MGN console."
        ],
        icon: HardDrive
    },
    {
        phase: "Phase 2: Replicate & Test with MGN",
        effort: "2-3 days",
        steps: [
            "Allow MGN to complete its initial sync and maintain continuous replication.",
            "From the MGN console, launch a non-disruptive 'Test Instance'.",
            "Thoroughly test all CMMC AI features and application functionality on the test instance.",
            "Terminate the test instance once validation is complete. Your source server is unaffected."
        ],
        icon: TestTube
    },
    {
        phase: "Phase 3: Execute Cutover & Finalize",
        effort: "2-4 hours",
        steps: [
            "Schedule a maintenance window for the cutover.",
            "From the MGN console, launch a 'Cutover Instance'. This will be your new production server.",
            "MGN automatically converts the server to run natively on AWS as a new EC2 instance.",
            "Update your Route 53 DNS records to point `hypercorecyber.com` to the new production instance's IP address."
        ],
        icon: CheckCircle
    }
];

export default function AWSMigrationExecutionPlan() {
    return (
        <div className="space-y-8">
            <BreadcrumbNav currentPageName="AWSMigrationExecutionPlan" />

            <div className="text-center">
                <Badge className="mb-4 bg-purple-100 text-purple-800">EXECUTION PLAYBOOK</Badge>
                <h1 className="text-4xl font-bold text-gray-900 mb-4">Base44 to AWS EC2: The MGN 'Lift & Shift' Plan</h1>
                <p className="text-xl text-gray-600 max-w-4xl mx-auto">
                    A step-by-step guide to migrating your application using AWS Application Migration Service (MGN) for a fast, reliable, and low-risk transition to a standard EC2 environment.
                </p>
            </div>
            
            <Alert className="bg-blue-50 border-blue-200">
                <Server className="h-5 w-5 text-blue-600" />
                <AlertTitle className="text-blue-800 font-bold">Core Strategy: Staging Server to Production</AlertTitle>
                <AlertDescription className="text-blue-700 mt-2">
                    We will configure your exported Base44 application on your **existing EC2 instance**, which will act as our 'source server'. We will then use AWS MGN to create a perfect, production-ready clone of it as a new EC2 instance. This isolates and de-risks the entire migration process.
                </AlertDescription>
            </Alert>

            <Card>
                <CardHeader>
                    <CardTitle>The 3-Phase Migration Workflow</CardTitle>
                    <CardDescription>From Base44 export to live on AWS in under a week.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    {migrationPhases.map((p, i) => (
                        <div key={i} className="flex items-start gap-6 p-4 bg-gray-50 rounded-lg">
                            <div className="flex-shrink-0 w-12 h-12 bg-gray-200 rounded-full flex items-center justify-center">
                                <p.icon className="w-6 h-6 text-gray-600" />
                            </div>
                            <div>
                                <h4 className="font-bold text-gray-800 text-lg">{p.phase} <Badge variant="secondary" className="ml-2">{p.effort}</Badge></h4>
                                <ul className="mt-2 space-y-2 text-sm text-gray-700">
                                    {p.steps.map((step, stepIndex) => (
                                        <li key={stepIndex} className="flex items-start gap-2">
                                            <ArrowRight className="w-4 h-4 text-blue-500 mt-0.5 flex-shrink-0" />
                                            <span>{step}</span>
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        </div>
                    ))}
                </CardContent>
            </Card>

            <Alert>
                <CheckCircle className="h-4 w-4" />
                <AlertTitle>Next Steps</AlertTitle>
                <AlertDescription>
                    The first action is to export the Base44 application and begin setting it up on your staging EC2 instance. This is the primary task for Week 3 of the sprint plan.
                </AlertDescription>
            </Alert>
        </div>
    );
}