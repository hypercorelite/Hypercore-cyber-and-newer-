import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CheckCircle, Download, Database, Code, ArrowRight } from 'lucide-react';
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";

const keyFindings = [
    { title: "Current Official Version", text: "Revision 2 (June 2018) is the current, active, and final version of NIST SP 800-171A.", icon: CheckCircle, color: "text-green-600" },
    { title: "No Newer Revision", text: "No updates or superseding documents have been issued since 2018. Revision 3 is pending the finalization of NIST SP 800-171 Rev. 3.", icon: CheckCircle, color: "text-green-600" },
    { title: "Free & Public Access", text: "The document is freely available from NIST.gov, confirming no licensing costs for integration.", icon: CheckCircle, color: "text-green-600" },
    { title: "CMMC 2.0 Authoritative Baseline", text: "CMMC 2.0 (enforced Nov 10, 2025) explicitly references NIST SP 800-171 Rev. 2, making this assessment guide fully valid for DoD compliance.", icon: CheckCircle, color: "text-green-600" }
];

const nextSteps = [
    { step: 1, title: "Download & Ingest", description: "Download the official Rev. 2 PDF to serve as the ground-truth document for the AI." },
    { step: 2, title: "Parse & Structure", description: "Use AI tools (e.g., Grok 3) to extract the 1,200+ assessment procedures into a structured format (JSON/CSV)." },
    { step: 3, title: "Embed in Database", description: "Store the parsed procedures in DynamoDB, making them queryable for the CMMCAI gap analysis engine." },
    { step: 4, title: "Update Compliance Matrix", description: "Explicitly reference NIST SP 800-171A Rev. 2 in all SBIR proposals and technical documentation to demonstrate alignment." }
];

export default function SBIRTechnicalStrategy() {
    return (
        <div className="space-y-8">
            <BreadcrumbNav currentPageName="SBIRTechnicalStrategy" />
            
            <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="text-center">
                <Badge className="mb-4 bg-blue-100 text-blue-800">TECHNICAL STRATEGY</Badge>
                <h1 className="text-4xl font-bold text-gray-900 mb-4">NIST SP 800-171A: Technical Baseline & Implementation</h1>
                <p className="text-xl text-gray-600 max-w-4xl mx-auto">
                    Assessment of the current NIST standard for CUI, confirming the technical foundation for the CMMCAI platform and SBIR proposals.
                </p>
            </motion.div>

            <Card>
                <CardHeader>
                    <CardTitle>Key Findings: NIST SP 800-171A Status</CardTitle>
                    <CardDescription>As of September 15, 2025</CardDescription>
                </CardHeader>
                <CardContent className="grid md:grid-cols-2 gap-4">
                    {keyFindings.map((item) => (
                         <div key={item.title} className="flex items-start gap-3 p-3 bg-gray-50 rounded-md border">
                            <item.icon className={`w-5 h-5 mt-1 flex-shrink-0 ${item.color}`} />
                            <div>
                                <h4 className="font-semibold">{item.title}</h4>
                                <p className="text-sm text-gray-600">{item.text}</p>
                            </div>
                        </div>
                    ))}
                </CardContent>
            </Card>

            <Alert className="bg-green-50 border-green-200">
                <Download className="h-4 w-4 text-green-700" />
                <AlertTitle className="font-semibold text-green-800">Official Source Confirmed</AlertTitle>
                <AlertDescription className="text-green-700 mt-2">
                    The document is verified to be freely and publicly available from the official NIST repository.
                    <Button asChild variant="outline" size="sm" className="ml-4 bg-white">
                        <a href="https://nvlpubs.nist.gov/nistpubs/SpecialPublications/NIST.SP.800-171Arev2.pdf" target="_blank" rel="noopener noreferrer">
                            Download PDF <ArrowRight className="w-4 h-4 ml-2" />
                        </a>
                    </Button>
                </AlertDescription>
            </Alert>
            
            <div className="grid md:grid-cols-2 gap-8">
                <Card>
                    <CardHeader>
                        <CardTitle>Relevance to CMMCAI Platform</CardTitle>
                        <CardDescription>How this standard directly informs MVP development.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div className="flex items-start gap-3">
                            <Database className="w-5 h-5 text-blue-600 mt-1" />
                            <div>
                                <h4 className="font-semibold">Automated Gap Analysis</h4>
                                <p className="text-sm text-gray-600">Provides 1,200+ specific assessment procedures that the AI can use to score client compliance against the 110 NIST controls.</p>
                            </div>
                        </div>
                        <div className="flex items-start gap-3">
                            <Code className="w-5 h-5 text-blue-600 mt-1" />
                            <div>
                                <h4 className="font-semibold">C3PAO-Ready Evidence</h4>
                                <p className="text-sm text-gray-600">Ensures the AI's recommendations and SSP/POA&M generation align with how official auditors will evaluate evidence.</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader>
                        <CardTitle>Actionable Implementation Plan</CardTitle>
                        <CardDescription>The step-by-step process for integrating this standard.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        {nextSteps.map(step => (
                             <div key={step.step} className="flex items-start gap-4">
                                <div className="flex-shrink-0 w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center font-bold text-gray-700">{step.step}</div>
                                <div>
                                    <h4 className="font-semibold">{step.title}</h4>
                                    <p className="text-sm text-gray-600">{step.description}</p>
                                </div>
                            </div>
                        ))}
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}