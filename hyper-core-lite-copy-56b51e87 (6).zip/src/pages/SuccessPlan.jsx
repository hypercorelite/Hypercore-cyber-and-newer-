
import React, { useState, useEffect } from 'react';
import { ComplianceActionItem } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { Link } from 'react-router-dom';
import { Progress } from "@/components/ui/progress";
import { ArrowRight, CheckCircle, Clock, GanttChartSquare } from 'lucide-react'; // Added GanttChartSquare
import { toast } from "sonner";
import { LoadingSpinner } from '../components/ui/LoadingSpinner';

const PageLoadingSpinner = ({ text }) => (
    <div className="flex flex-col items-center justify-center min-h-[calc(100vh-200px)]">
        <LoadingSpinner />
        <p className="mt-4 text-lg text-gray-600">{text}</p>
    </div>
);

export default function SuccessPlan() {
    const [actionItems, setActionItems] = useState([]);
    const [completedTasks, setCompletedTasks] = useState({});
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        // OPTIMIZED Meta Tags for 90-Day Success Plan
        document.title = "AI-Powered 90-Day CMMC Success Plan for Defense Subs | HyperCore";
        document.querySelector('meta[name="description"]')?.setAttribute('content',
            'Achieve CMMC Level 2 compliance fast with our AI-first 90-day plan: Automated docs, 3PAO audit prep, and free trial for DoD contractors.');

        // Enhanced HowTo Schema WITHOUT fake ratings (platform just launched)
        const structuredData = {
            "@context": "https://schema.org",
            "@type": "HowTo",
            "name": "90-Day CMMC Level 2 Compliance Success Plan",
            "description": "Complete AI-powered implementation guide for achieving CMMC Level 2 compliance in 90 days with 3PAO audit preparation",
            "image": "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=1200&h=630&fit=crop",
            "totalTime": "P90D",
            "estimatedCost": {
                "@type": "MonetaryAmount",
                "currency": "USD",
                "value": "0"
            },
            "supply": [
                {
                    "@type": "HowToSupply",
                    "name": "HyperCore AI Platform Access"
                },
                {
                    "@type": "HowToSupply",
                    "name": "Current IT Infrastructure Documentation"
                },
                {
                    "@type": "HowToSupply",
                    "name": "NIST 800-171 Gap Analysis Results"
                }
            ],
            "tool": [
                {
                    "@type": "HowToTool",
                    "name": "AI-Powered CMMC Assessment Tool"
                },
                {
                    "@type": "HowToTool",
                    "name": "Automated Document Generator"
                }
            ],
            "step": [
                {
                    "@type": "HowToStep",
                    "position": 1,
                    "name": "Foundation Phase (Days 1-30)",
                    "text": "Complete AI gap analysis, generate core documentation, and establish compliance framework with automated NIST 800-171 control mapping",
                    "url": "https://hypercorecyber.com/SuccessPlan#week-1"
                },
                {
                    "@type": "HowToStep",
                    "position": 2,
                    "name": "Implementation Phase (Days 31-60)",
                    "text": "Deploy technical controls, implement security measures, and prepare 3PAO audit documentation with AI assistance",
                    "url": "https://hypercorecyber.com/SuccessPlan#week-5"
                },
                {
                    "@type": "HowToStep",
                    "position": 3,
                    "name": "Validation Phase (Days 61-90)",
                    "text": "Conduct mock 3PAO assessments, finalize evidence collection, and achieve full CMMC Level 2 readiness",
                    "url": "https://hypercorecyber.com/SuccessPlan#week-9"
                }
            ]
        };

        // BreadcrumbList for better navigation understanding
        const breadcrumbData = {
            "@context": "https://schema.org",
            "@type": "BreadcrumbList",
            "itemListElement": [
                {
                    "@type": "ListItem",
                    "position": 1,
                    "name": "Home",
                    "item": "https://hypercorecyber.com/"
                },
                {
                    "@type": "ListItem",
                    "position": 2,
                    "name": "90-Day CMMC Success Plan",
                    "item": "https://hypercorecyber.com/SuccessPlan"
                }
            ]
        };

        const script1 = document.createElement('script');
        script1.type = 'application/ld+json';
        script1.textContent = JSON.stringify(structuredData);
        document.head.appendChild(script1);

        const script2 = document.createElement('script');
        script2.type = 'application/ld+json';
        script2.textContent = JSON.stringify(breadcrumbData);
        document.head.appendChild(script2);

        // Cleanup function for structured data and meta tags
        return () => {
            if (script1.parentNode) {
                script1.parentNode.removeChild(script1);
            }
            if (script2.parentNode) {
                script2.parentNode.removeChild(script2);
            }
            // Reset title and description if necessary, or rely on other routes to set them
            document.title = "HyperCore"; // Or a default title for the app
            document.querySelector('meta[name="description"]')?.setAttribute('content', ''); // Or default description
        };
    }, []);


    useEffect(() => {
        const fetchActionItems = async () => {
            try {
                const items = await ComplianceActionItem.list();
                const groupedByWeek = items.reduce((acc, item) => {
                    (acc[item.week] = acc[item.week] || []).push(item);
                    return acc;
                }, {});
                setActionItems(groupedByWeek);
            } catch (error) {
                console.error("Failed to load action items:", error);
                toast.error("Failed to load success plan.");
            } finally {
                setLoading(false);
            }
        };

        fetchActionItems();

        // Load completion status from local storage
        const savedProgress = localStorage.getItem('complianceProgress');
        if (savedProgress) {
            setCompletedTasks(JSON.parse(savedProgress));
        }
    }, []); // This useEffect remains separate as it has different dependencies and purpose.

    const handleTaskToggle = (taskId) => {
        const newCompletedTasks = {
            ...completedTasks,
            [taskId]: !completedTasks[taskId]
        };
        setCompletedTasks(newCompletedTasks);
        localStorage.setItem('complianceProgress', JSON.stringify(newCompletedTasks));
    };

    const totalTasks = Object.values(actionItems).flat().length;
    const completedCount = Object.values(completedTasks).filter(Boolean).length;
    const progressPercentage = totalTasks > 0 ? (completedCount / totalTasks) * 100 : 0;

    if (loading) {
        return <PageLoadingSpinner text="Building Your Success Plan..." />;
    }

    return (
        <div className="bg-white py-12 md:py-20">
            <div className="container mx-auto px-4 max-w-5xl">
                <div className="text-center mb-12">
                    <GanttChartSquare className="mx-auto h-12 w-12 text-blue-600 mb-4" />
                    <h1 className="text-4xl md:text-5xl font-extrabold text-gray-900 mb-4">
                        The 90-Day CMMC Success Plan for Virginia Contractors
                    </h1>
                    <p className="text-xl text-gray-600">
                        A structured, week-by-week roadmap to get your company audit-ready for CMMC Level 2, specifically tailored for the Northern Virginia DIB.
                    </p>
                </div>

                <Card className="mb-8">
                    <CardHeader>
                        <CardTitle>Overall Progress</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <Progress value={progressPercentage} className="w-full" />
                        <p className="text-center text-sm text-gray-600 mt-2">
                            {completedCount} of {totalTasks} tasks completed ({Math.round(progressPercentage)}%)
                        </p>
                    </CardContent>
                </Card>

                <Accordion type="single" collapsible defaultValue="week-1" className="w-full">
                    {Object.entries(actionItems).map(([week, tasks]) => (
                        <AccordionItem key={week} value={`week-${week}`}>
                            <AccordionTrigger className="text-xl font-bold">Week {week}</AccordionTrigger>
                            <AccordionContent>
                                <div className="space-y-4 p-4">
                                    {tasks.map(task => (
                                        <Card key={task.id} className="flex items-start p-4 gap-4">
                                            <Checkbox
                                                id={`task-${task.id}`}
                                                checked={!!completedTasks[task.id]}
                                                onCheckedChange={() => handleTaskToggle(task.id)}
                                                className="mt-1"
                                            />
                                            <div className="flex-grow">
                                                <label htmlFor={`task-${task.id}`} className="font-semibold text-gray-800 cursor-pointer">{task.title}</label>
                                                <p className="text-sm text-gray-600">{task.description}</p>
                                                <div className="flex items-center gap-4 mt-2">
                                                    <Badge variant="outline">{task.category}</Badge>
                                                    <div className="flex items-center text-xs text-gray-500 gap-1">
                                                        <Clock className="w-3 h-3" />
                                                        <span>{task.estimated_time_hours} hrs</span>
                                                    </div>
                                                </div>
                                            </div>
                                            {task.link_to_resource && (
                                                <Button asChild variant="outline" size="sm">
                                                    <Link to={task.link_to_resource}>
                                                        Go to Tool <ArrowRight className="w-4 h-4 ml-2" />
                                                    </Link>
                                                </Button>
                                            )}
                                        </Card>
                                    ))}
                                </div>
                            </AccordionContent>
                        </AccordionItem>
                    ))}
                </Accordion>
            </div>
        </div>
    );
}
