import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Clock, Banknote, Mail, ArrowRight } from 'lucide-react';

export default function PaymentIntegrationPlan() {
    return (
        <div className="min-h-screen bg-gray-50 flex items-center justify-center p-6">
            <Card className="max-w-3xl w-full">
                <CardHeader className="text-center">
                    <Clock className="w-12 h-12 mx-auto text-blue-600 mb-4" />
                    <CardTitle className="text-3xl">The Free Beta Ends December 5, 2025</CardTitle>
                    <CardDescription className="text-lg text-gray-600">
                        Here's what to expect as we transition to our paid program.
                    </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    <div className="p-6 bg-blue-50 rounded-lg border border-blue-200">
                        <h3 className="text-xl font-bold text-blue-800 mb-2">Continue Uninterrupted Service</h3>
                        <p className="text-blue-700">
                            To thank you for your participation, we are offering an exclusive "Early Adopter" pricing plan. 
                            You will receive an official quote via email before December 5th.
                        </p>
                    </div>

                    <div className="grid md:grid-cols-2 gap-6">
                        <div className="flex items-start gap-4">
                            <Banknote className="w-8 h-8 text-green-600 mt-1 flex-shrink-0" />
                            <div>
                                <h4 className="font-semibold">Payment Terms: Net 30 via Wire Transfer</h4>
                                <p className="text-sm text-gray-600">
                                    Our initial commercial contracts will be handled via standard corporate invoicing. 
                                    We will provide wire transfer details with your first invoice.
                                </p>
                            </div>
                        </div>
                        <div className="flex items-start gap-4">
                            <Mail className="w-8 h-8 text-purple-600 mt-1 flex-shrink-0" />
                            <div>
                                <h4 className="font-semibold">What to Expect</h4>
                                <p className="text-sm text-gray-600">
                                    You will receive an email with your personalized quote and a simple service agreement. No action is needed until then.
                                </p>
                            </div>
                        </div>
                    </div>

                    <div className="text-center pt-4">
                         <Button asChild size="lg">
                            <Link to={createPageUrl('CostAnalysis')}>
                                View Beta Program Data (Admin) <ArrowRight className="w-4 h-4 ml-2" />
                            </Link>
                        </Button>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}