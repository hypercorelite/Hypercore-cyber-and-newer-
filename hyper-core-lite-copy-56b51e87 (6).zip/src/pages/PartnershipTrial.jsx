
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowRight, Download, Loader2, Zap, Award, FileSignature } from 'lucide-react';
import { motion } from 'framer-motion';
import { toast } from "sonner";
import TrialConsentForm from '../components/partnership/TrialConsentForm';
import QuickAssessmentForm from '../components/partnership/QuickAssessmentForm';
import AIGapAnalysisResults from '../components/partnership/AIGapAnalysisResults';
import { performAIGapAnalysis } from '@/api/functions';
import { generateCMMCReport } from '@/api/functions';
import FeedbackWidget from '../components/support/FeedbackWidget';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';
import SEONarrativeHighlight from '../components/competitive/SEONarrativeHighlight';
import { Link } from 'react-router-dom';

// Entity imports for data collection
import { ClientOnboarding } from "@/api/entities";
import { ClientEngagement } from "@/api/entities";

// PDF generation imports
import { jsPDF } from 'jspdf';

// Import the celebration component
import CelebrationMessage from '../components/workflow/CelebrationMessage';

// Client-side PDF generation logic removed as it over-promised a full SSP.

// Helper to download base64 encoded PDFs
const downloadBase64Pdf = (base64String, fileName) => {
    try {
        const blob = new Blob([Uint8Array.from(atob(base64String), c => c.charCodeAt(0))], { type: 'application/pdf' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = fileName;
        document.body.appendChild(a);
        a.click();
        a.remove();
        window.URL.revokeObjectURL(url);
    } catch(e) {
        console.error("Error downloading base64 PDF", e);
        toast.error("Failed to decode and download PDF.");
    }
};

// Placeholder for createPageUrl function - In a real application, this would come from a routing utility or context
const createPageUrl = (pageName) => {
    switch (pageName) {
        case 'LOIGenerator':
            return '/loi-generator'; 
        case 'TraceabilityMatrix':
            return '/tools/cmmc-traceability'; 
        default:
            return `/${pageName.toLowerCase()}`;
    }
};

export default function PartnershipTrial() {
    const [currentStep, setCurrentStep] = useState('consent'); // 'consent', 'assessment', 'analysis', 'results', 'generating_pdfs', 'celebration'
    const [clientDetails, setClientDetails] = useState(null);
    const [assessmentAnswers, setAssessmentAnswers] = useState(null);
    const [analysisResult, setAnalysisResult] = useState(null);
    const [isProcessing, setIsProcessing] = useState(false);

    useEffect(() => {
        document.title = "Free CMMC Gap Analysis & Action Plan | HyperCore AI";
        document.querySelector('meta[name="description"]')?.setAttribute('content', 
            'Get your CMMC gap analysis, SPRS score estimate, and a prioritized action plan in minutes. Our AI provides your roadmap to CMMC readiness in 90 days.');
    }, []);

    const handleConsentGiven = async (details) => {
        setClientDetails(details);
        setCurrentStep('assessment');
        try {
             await ClientOnboarding.create({
                client_email: details.email,
                client_name: details.name, // Fixed: Added required field
                company_name: details.organizationName,
                onboarding_stage: 'profile_completed',
                sbir_case_study_consent: true,
                company_size: details.userCount,
            });
            toast.success("Profile created. Let's start the assessment.");
        } catch (e) { 
            console.error("Onboarding log failed:", e); 
            // Don't block user flow if logging fails
        }
    };
    
    const handleAssessmentSubmit = async (answers) => {
        console.log('Assessment submitted with answers:', answers);
        setAssessmentAnswers(answers);
        setIsProcessing(true);
        setCurrentStep('analysis');
        
        try {
            const { data: analysis } = await performAIGapAnalysis({ assessmentAnswers: answers });
            console.log('Analysis result received:', analysis);
            
            if (analysis && (analysis.gaps || analysis.summary)) {
                setAnalysisResult(analysis);
                setCurrentStep('results');
                toast.success("AI analysis complete! Review your results below.");
                
                try {
                    await ClientEngagement.create({
                        client_email: clientDetails.email,
                        engagement_type: 'assessment_completed',
                        assessment_score: analysis.overall_score || 0,
                        pdf_report_generated: false
                    });
                } catch (logError) {
                    console.error("Engagement logging failed:", logError);
                }
            } else {
                console.error("Invalid analysis results:", analysis);
                throw new Error("Analysis returned incomplete results");
            }

        } catch (error) {
            console.error("Analysis failed:", error);
            toast.error("Analysis failed. Please try again.", { 
                description: error.message 
            });
            setCurrentStep('assessment'); // Go back to assessment on error
        } finally {
            setIsProcessing(false);
        }
    };

    const handleGeneratePdfs = async () => {
        setIsProcessing(true);
        setCurrentStep('generating_pdfs');
        const pdfToast = toast.loading("Generating your Gap Analysis & Action Plan PDF...");

        try {
            const clientInfo = { ...clientDetails, companyName: clientDetails.organizationName };
            
            // Only generate the CMMC report, which will serve as the gap analysis action plan.
            const { data: reportResult, error } = await generateCMMCReport({ clientInfo, assessmentAnswers, analysisResult });

            if (reportResult && reportResult.pdfBase64) {
                 downloadBase64Pdf(reportResult.pdfBase64, `CMMC-Action-Plan_${clientInfo.companyName.replace(/\s+/g, '_')}.pdf`);
                 toast.success("Your Gap Analysis & Action Plan has been generated!", { id: pdfToast });
                 await ClientEngagement.create({ client_email: clientDetails.email, engagement_type: 'pdf_downloaded', pdf_report_generated: true });
                 setCurrentStep('celebration');
            } else {
                 toast.error("Failed to generate your action plan.", { id: pdfToast, description: error || "An unknown error occurred." });
                 setCurrentStep('results'); // Go back to results on error
            }

        } catch (error) {
            toast.error("Failed to generate PDF. Please try again.", { id: pdfToast, description: error.message });
            setCurrentStep('results'); // Go back to results on error
        } finally {
            setIsProcessing(false);
        }
    };

    const renderCurrentStep = () => {
        if (isProcessing) {
            return (
                <div className="text-center p-12">
                    <Loader2 className="w-16 h-16 animate-spin text-blue-600 mx-auto mb-6" />
                    <h2 className="text-2xl font-bold text-gray-800">
                        {currentStep === 'analysis' ? "Performing AI Analysis..." : "Generating Your Custom Documentation..."}
                    </h2>
                    <p className="text-gray-600">
                        {currentStep === 'analysis' 
                            ? "Our AI is analyzing your responses to identify compliance gaps and generate personalized recommendations..."
                            : "Creating personalized SSP, policies, and compliance reports based on your specific requirements..."
                        }
                    </p>
                </div>
            );
        }

        switch(currentStep) {
            case 'consent':
                return <TrialConsentForm onConsentGiven={handleConsentGiven} />;
            case 'assessment':
                return <QuickAssessmentForm onSubmit={handleAssessmentSubmit} />;
            case 'analysis':
                return (
                    <div className="text-center p-12">
                        <Loader2 className="w-16 h-16 animate-spin text-blue-600 mx-auto mb-6" />
                        <h2 className="text-2xl font-bold text-gray-800">Performing AI Analysis...</h2>
                        <p className="text-gray-600">Analyzing your CMMC readiness and generating personalized recommendations...</p>
                    </div>
                );
            case 'results':
            case 'generating_pdfs': 
                return (
                    <AIGapAnalysisResults 
                        analysis={analysisResult} 
                        onGeneratePdfs={handleGeneratePdfs} 
                    />
                );
            case 'celebration':
                return (
                    <div>
                        <CelebrationMessage 
                            documentType="Gap Analysis & Action Plan" 
                            onContinueJourney={() => setCurrentStep('results')}
                        />
                        <div className="mt-8">
                            <FeedbackWidget context="partnership_trial_completion" />
                        </div>
                    </div>
                );
            default:
                return <TrialConsentForm onConsentGiven={handleConsentGiven} />;
        }
    }

    const stepTitles = {
        consent: { title: "Join our Free Assessment Program", description: "Provide a few details to get a free CMMC gap analysis and prioritized action plan." },
        assessment: { title: "Step 2: CMMC Readiness Assessment", description: "Answer these questions so our AI can analyze your current compliance posture." },
        analysis: { title: "Performing AI Gap Analysis", description: "Our AI is analyzing your responses to identify compliance gaps and create your action plan." },
        results: { title: "Step 3: Your AI-Generated Gap Analysis", description: "Review your personalized findings and download your CMMC action plan." },
        generating_pdfs: { title: "Step 3: Generating Your Action Plan", description: "Creating your personalized gap analysis and roadmap..." },
        celebration: { title: "🎉 Success! Your Action Plan is Ready 🎉", description: "Congratulations! You now have a clear roadmap for CMMC compliance." }
    }

    return (
        <div className="bg-gray-50 py-12 md:py-20">
            <div className="container mx-auto px-4 max-w-4xl">
                <div className="text-center mb-12">
                    <Zap className="mx-auto h-12 w-12 text-blue-600 mb-4" />
                    <h1 className="text-4xl md:text-5xl font-extrabold text-gray-900 mb-4">
                        Get Your Free CMMC Action Plan in Minutes
                    </h1>
                    <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                        Our AI performs a comprehensive gap analysis to provide a prioritized roadmap and cost estimates—the first step to achieving compliance in 90 days.
                    </p>
                </div>
                
                {renderCurrentStep()}
                
                {currentStep === 'consent' && (
                    <div className="mt-12">
                         <SEONarrativeHighlight />
                    </div>
                )}
                
                {currentStep === 'results' && (
                  <div className="mt-12 space-y-8">
                    <Alert className="bg-green-50 border-green-200">
                        <Zap className="h-5 w-5 text-green-600" />
                        <AlertTitle className="text-green-800 font-bold">This is Your 90-Day Roadmap</AlertTitle>
                        <AlertDescription className="text-green-700">
                            This free analysis provides the exact blueprint our team uses to get contractors audit-ready in 90 days. It's the same process that saves companies $50K-$200K compared to traditional consultants. Your participation helps validate our SBIR grant proposal to scale this solution.
                        </AlertDescription>
                    </Alert>
                    
                    {/* SBIR Validation CTA */}
                    <Card className="bg-gradient-to-r from-purple-50 to-blue-50 border-purple-200">
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2 text-purple-800">
                                <Award className="w-6 h-6" />
                                Complete Your SBIR Validation Partnership
                            </CardTitle>
                            <CardDescription className="text-purple-700">
                                Submit a Letter of Intent to help us win SBIR funding and scale this solution across the entire DIB supply chain.
                            </CardDescription>
                        </CardHeader>
                        <CardContent>
                            <div className="flex flex-col sm:flex-row gap-4">
                                <Button asChild className="bg-purple-600 hover:bg-purple-700">
                                    <Link to={createPageUrl('LOIGenerator')}>
                                        Submit SBIR Validation LOI <FileSignature className="w-4 h-4 ml-2" />
                                    </Link>
                                </Button>
                                <Button asChild variant="outline">
                                    <Link to={createPageUrl('TraceabilityMatrix')}>
                                        Explore All CMMC Tools <ArrowRight className="w-4 h-4 ml-2" />
                                    </Link>
                                </Button>
                            </div>
                        </CardContent>
                    </Card>
                    
                    <FeedbackWidget context="partnership_trial_completion" />
                  </div>
                )}
            </div>
        </div>
    );
}
