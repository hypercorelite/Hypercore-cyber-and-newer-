import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ComplianceTask } from "@/api/entities";
import { ComplianceFramework } from "@/api/entities";
import { 
    Workflow, 
    Bot, 
    User, 
    CheckCircle2, 
    Clock, 
    AlertCircle,
    FileText,
    Plus,
    Search
} from "lucide-react";
import { motion } from "framer-motion";

export default function ComplianceWorkflows() {
    const [tasks, setTasks] = useState([]);
    const [frameworks, setFrameworks] = useState([]);
    const [loading, setLoading] = useState(true);
    const [selectedFramework, setSelectedFramework] = useState("all");
    const [searchTerm, setSearchTerm] = useState("");

    useEffect(() => {
        loadData();
    }, []);

    const loadData = async () => {
        try {
            const [taskData, frameworkData] = await Promise.all([
                ComplianceTask.list('-created_date', 50),
                ComplianceFramework.list('-updated_date', 10)
            ]);
            setTasks(taskData);
            setFrameworks(frameworkData);
        } catch (error) {
            console.error('Failed to load workflow data:', error);
        } finally {
            setLoading(false);
        }
    };

    const updateTaskStatus = async (taskId, newStatus, reviewerNotes = "") => {
        await ComplianceTask.update(taskId, { 
            status: newStatus, 
            reviewer_notes: reviewerNotes,
            completion_date: newStatus === 'completed' ? new Date().toISOString() : null
        });
        loadData();
    };

    const getStatusIcon = (status) => {
        const icons = {
            pending: <Clock className="w-4 h-4 text-gray-500" />,
            in_progress: <Bot className="w-4 h-4 text-blue-500 animate-spin" />,
            ai_completed: <Bot className="w-4 h-4 text-green-500" />,
            human_review_required: <User className="w-4 h-4 text-yellow-500" />,
            approved: <CheckCircle2 className="w-4 h-4 text-green-500" />,
            completed: <CheckCircle2 className="w-4 h-4 text-green-600" />,
            rejected: <AlertCircle className="w-4 h-4 text-red-500" />
        };
        return icons[status] || <Clock className="w-4 h-4 text-gray-500" />;
    };

    const getStatusColor = (status) => {
        const colors = {
            pending: "bg-gray-100 text-gray-800",
            in_progress: "bg-blue-100 text-blue-800",
            ai_completed: "bg-green-100 text-green-800",
            human_review_required: "bg-yellow-100 text-yellow-800",
            approved: "bg-green-100 text-green-800",
            completed: "bg-green-100 text-green-800",
            rejected: "bg-red-100 text-red-800"
        };
        return colors[status] || "bg-gray-100 text-gray-800";
    };

    const getPriorityColor = (priority) => {
        const colors = {
            low: "border-l-blue-500",
            medium: "border-l-yellow-500",
            high: "border-l-orange-500",
            critical: "border-l-red-500"
        };
        return colors[priority] || "border-l-gray-500";
    };

    const filteredTasks = tasks.filter(task => {
        const matchesFramework = selectedFramework === "all" || task.framework_id === selectedFramework;
        const matchesSearch = task.task_title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                             task.requirement_section.toLowerCase().includes(searchTerm.toLowerCase());
        return matchesFramework && matchesSearch;
    });

    return (
        <div className="min-h-screen bg-gradient-to-br from-gray-50 to-purple-50 p-6">
            <div className="max-w-7xl mx-auto">
                <motion.div
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="mb-8"
                >
                    <h1 className="text-4xl font-bold text-gray-900 mb-2 flex items-center gap-3">
                        <Workflow className="w-10 h-10 text-purple-600" />
                        Compliance Workflows
                    </h1>
                    <p className="text-lg text-gray-600">
                        Human-in-the-Loop AI Automation for HIPAA, FERPA & CMMC
                    </p>
                </motion.div>

                {/* Filters */}
                <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.2 }}
                    className="flex gap-4 mb-6"
                >
                    <div className="relative flex-1">
                        <Search className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                        <Input
                            placeholder="Search tasks..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="pl-10"
                        />
                    </div>
                    <Select value={selectedFramework} onValueChange={setSelectedFramework}>
                        <SelectTrigger className="w-64">
                            <SelectValue placeholder="Select Framework" />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="all">All Frameworks</SelectItem>
                            {frameworks.map(framework => (
                                <SelectItem key={framework.id} value={framework.id}>
                                    {framework.framework_name} - {framework.organization_name}
                                </SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                    <Button className="bg-purple-600 hover:bg-purple-700">
                        <Plus className="w-4 h-4 mr-2" />
                        New Task
                    </Button>
                </motion.div>

                {/* Workflow Stats */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
                    <Card className="bg-gradient-to-br from-blue-50 to-blue-100">
                        <CardContent className="p-4 text-center">
                            <Bot className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                            <div className="text-2xl font-bold text-blue-600">
                                {filteredTasks.filter(t => t.status === 'ai_completed').length}
                            </div>
                            <div className="text-sm text-blue-700">AI Completed</div>
                        </CardContent>
                    </Card>
                    
                    <Card className="bg-gradient-to-br from-yellow-50 to-yellow-100">
                        <CardContent className="p-4 text-center">
                            <User className="w-8 h-8 text-yellow-600 mx-auto mb-2" />
                            <div className="text-2xl font-bold text-yellow-600">
                                {filteredTasks.filter(t => t.status === 'human_review_required').length}
                            </div>
                            <div className="text-sm text-yellow-700">Needs Review</div>
                        </CardContent>
                    </Card>
                    
                    <Card className="bg-gradient-to-br from-green-50 to-green-100">
                        <CardContent className="p-4 text-center">
                            <CheckCircle2 className="w-8 h-8 text-green-600 mx-auto mb-2" />
                            <div className="text-2xl font-bold text-green-600">
                                {filteredTasks.filter(t => t.status === 'completed').length}
                            </div>
                            <div className="text-sm text-green-700">Completed</div>
                        </CardContent>
                    </Card>
                    
                    <Card className="bg-gradient-to-br from-purple-50 to-purple-100">
                        <CardContent className="p-4 text-center">
                            <Clock className="w-8 h-8 text-purple-600 mx-auto mb-2" />
                            <div className="text-2xl font-bold text-purple-600">
                                {filteredTasks.filter(t => t.status === 'in_progress').length}
                            </div>
                            <div className="text-sm text-purple-700">In Progress</div>
                        </CardContent>
                    </Card>
                </div>

                {/* Tasks List */}
                <div className="space-y-4">
                    {filteredTasks.map((task, index) => (
                        <motion.div
                            key={task.id}
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: index * 0.05 }}
                        >
                            <Card className={`border-l-4 ${getPriorityColor(task.priority)} hover:shadow-lg transition-shadow`}>
                                <CardHeader className="pb-3">
                                    <div className="flex justify-between items-start">
                                        <div>
                                            <CardTitle className="text-lg">{task.task_title}</CardTitle>
                                            <div className="text-sm text-gray-600 mt-1">
                                                {task.requirement_section} • {task.task_type.replace('_', ' ')}
                                            </div>
                                        </div>
                                        <div className="flex items-center gap-2">
                                            <Badge className={getStatusColor(task.status)}>
                                                {getStatusIcon(task.status)}
                                                <span className="ml-1">{task.status.replace('_', ' ')}</span>
                                            </Badge>
                                            <Badge variant="outline" className={task.priority === 'critical' ? 'border-red-500 text-red-700' : ''}>
                                                {task.priority}
                                            </Badge>
                                        </div>
                                    </div>
                                </CardHeader>
                                <CardContent>
                                    <p className="text-gray-700 mb-4">{task.task_description}</p>
                                    
                                    {task.ai_agent_suggestions && (
                                        <div className="bg-blue-50 rounded-lg p-3 mb-4 border border-blue-200">
                                            <div className="flex items-center gap-2 mb-2">
                                                <Bot className="w-4 h-4 text-blue-600" />
                                                <span className="text-sm font-semibold text-blue-700">AI Suggestion:</span>
                                            </div>
                                            <p className="text-sm text-blue-800">{task.ai_agent_suggestions}</p>
                                        </div>
                                    )}

                                    <div className="flex items-center justify-between">
                                        <div className="text-sm text-gray-600">
                                            <span>Assigned to: </span>
                                            <span className="font-medium">{task.assigned_to || 'Unassigned'}</span>
                                            {task.due_date && (
                                                <span className="ml-4">
                                                    Due: {new Date(task.due_date).toLocaleDateString()}
                                                </span>
                                            )}
                                        </div>
                                        
                                        {task.status === 'human_review_required' && (
                                            <div className="flex gap-2">
                                                <Button 
                                                    size="sm" 
                                                    className="bg-green-600 hover:bg-green-700"
                                                    onClick={() => updateTaskStatus(task.id, 'approved', 'Approved by reviewer')}
                                                >
                                                    <CheckCircle2 className="w-4 h-4 mr-1" />
                                                    Approve
                                                </Button>
                                                <Button 
                                                    size="sm" 
                                                    variant="outline"
                                                    onClick={() => updateTaskStatus(task.id, 'rejected', 'Needs revision')}
                                                >
                                                    Request Changes
                                                </Button>
                                            </div>
                                        )}

                                        {task.status === 'approved' && (
                                            <Button 
                                                size="sm" 
                                                className="bg-blue-600 hover:bg-blue-700"
                                                onClick={() => updateTaskStatus(task.id, 'completed')}
                                            >
                                                Mark Complete
                                            </Button>
                                        )}
                                    </div>

                                    {task.reviewer_notes && (
                                        <div className="mt-3 p-3 bg-gray-50 rounded-lg border">
                                            <div className="text-sm font-semibold text-gray-700 mb-1">Reviewer Notes:</div>
                                            <p className="text-sm text-gray-600">{task.reviewer_notes}</p>
                                        </div>
                                    )}
                                </CardContent>
                            </Card>
                        </motion.div>
                    ))}
                </div>

                {filteredTasks.length === 0 && !loading && (
                    <div className="text-center py-12">
                        <FileText className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                        <h3 className="text-lg font-semibold text-gray-600 mb-2">
                            No Tasks Found
                        </h3>
                        <p className="text-gray-500 mb-4">
                            Create your first compliance workflow to get started.
                        </p>
                        <Button className="bg-purple-600 hover:bg-purple-700">
                            <Plus className="w-4 h-4 mr-2" />
                            Create First Task
                        </Button>
                    </div>
                )}
            </div>
        </div>
    );
}