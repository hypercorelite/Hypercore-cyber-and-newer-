import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Calculator, AlertTriangle, CheckCircle, Zap, FileText } from 'lucide-react';
import { motion } from "framer-motion";
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";

const riskFactors = [
    {
        id: "contract_value",
        question: "What is your contract value with DoD?",
        type: "radio",
        options: [
            { value: "under_100k", label: "Under $100K", risk: 1 },
            { value: "100k_1m", label: "$100K - $1M", risk: 2 },
            { value: "1m_10m", label: "$1M - $10M", risk: 3 },
            { value: "over_10m", label: "Over $10M", risk: 4 }
        ]
    },
    {
        id: "cui_handling",
        question: "Do you handle Controlled Unclassified Information (CUI)?",
        type: "radio", 
        options: [
            { value: "no_cui", label: "No CUI", risk: 0 },
            { value: "minimal_cui", label: "Minimal CUI", risk: 2 },
            { value: "regular_cui", label: "Regular CUI handling", risk: 3 },
            { value: "extensive_cui", label: "Extensive CUI operations", risk: 4 }
        ]
    },
    {
        id: "nist_compliance",
        question: "Current NIST SP 800-171 compliance level?",
        type: "radio",
        options: [
            { value: "none", label: "Not started", risk: 4 },
            { value: "planning", label: "Planning phase", risk: 3 },
            { value: "implementing", label: "Implementation in progress", risk: 2 },
            { value: "complete", label: "Fully compliant", risk: 0 }
        ]
    },
    {
        id: "incident_reporting",
        question: "Do you have 72-hour incident reporting capability?",
        type: "radio",
        options: [
            { value: "no_process", label: "No process in place", risk: 3 },
            { value: "manual_process", label: "Manual process", risk: 2 },
            { value: "automated", label: "Automated reporting", risk: 0 }
        ]
    },
    {
        id: "subcontractor_oversight",
        question: "How many subcontractors do you manage?",
        type: "radio",
        options: [
            { value: "none", label: "No subcontractors", risk: 0 },
            { value: "1_5", label: "1-5 subcontractors", risk: 1 },
            { value: "6_20", label: "6-20 subcontractors", risk: 2 },
            { value: "over_20", label: "20+ subcontractors", risk: 3 }
        ]
    }
];

export default function DFARSRiskCalculator() {
    const [responses, setResponses] = useState({});
    const [showResults, setShowResults] = useState(false);
    const [emailCapture, setEmailCapture] = useState('');

    const handleResponseChange = (factorId, value) => {
        setResponses(prev => ({ ...prev, [factorId]: value }));
    };

    const calculateRisk = () => {
        let totalRisk = 0;
        let maxRisk = 0;

        riskFactors.forEach(factor => {
            const response = responses[factor.id];
            if (response) {
                const option = factor.options.find(opt => opt.value === response);
                if (option) {
                    totalRisk += option.risk;
                }
            }
            maxRisk += Math.max(...factor.options.map(opt => opt.risk));
        });

        return Math.round((totalRisk / maxRisk) * 100);
    };

    const getRiskLevel = (score) => {
        if (score <= 25) return { level: "Low", color: "text-green-600", bg: "bg-green-100" };
        if (score <= 50) return { level: "Medium", color: "text-yellow-600", bg: "bg-yellow-100" };
        if (score <= 75) return { level: "High", color: "text-orange-600", bg: "bg-orange-100" };
        return { level: "Critical", color: "text-red-600", bg: "bg-red-100" };
    };

    const handleSubmit = () => {
        if (Object.keys(responses).length < riskFactors.length) {
            alert("Please answer all questions to calculate your risk score.");
            return;
        }
        setShowResults(true);
    };

    const riskScore = showResults ? calculateRisk() : 0;
    const riskLevel = getRiskLevel(riskScore);

    return (
        <div className="space-y-8">
            <BreadcrumbNav currentPageName="DFARS Risk Calculator" />
            
            <div className="text-center">
                <h1 className="text-4xl font-bold text-gray-900 mb-4 flex items-center justify-center gap-3">
                    <Calculator className="w-8 h-8 text-blue-600" />
                    Free DFARS Risk Assessment
                </h1>
                <p className="text-xl text-gray-600 max-w-4xl mx-auto">
                    Calculate your organization's DFARS compliance risk in under 3 minutes. Get personalized recommendations to avoid FCA penalties.
                </p>
            </div>

            <div className="max-w-4xl mx-auto grid lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2">
                    <Card>
                        <CardHeader>
                            <CardTitle>DFARS Risk Assessment Questions</CardTitle>
                            <CardDescription>Answer all questions to get your personalized risk score and recommendations</CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-8">
                            {riskFactors.map((factor, index) => (
                                <motion.div
                                    key={factor.id}
                                    initial={{ opacity: 0, y: 20 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    transition={{ delay: index * 0.1 }}
                                    className="space-y-4"
                                >
                                    <Label className="text-lg font-semibold">
                                        {index + 1}. {factor.question}
                                    </Label>
                                    <RadioGroup
                                        value={responses[factor.id]}
                                        onValueChange={(value) => handleResponseChange(factor.id, value)}
                                    >
                                        {factor.options.map((option) => (
                                            <div key={option.value} className="flex items-center space-x-2">
                                                <RadioGroupItem value={option.value} id={option.value} />
                                                <Label htmlFor={option.value} className="cursor-pointer">
                                                    {option.label}
                                                </Label>
                                            </div>
                                        ))}
                                    </RadioGroup>
                                </motion.div>
                            ))}

                            <div className="pt-6 border-t">
                                <div className="space-y-4">
                                    <Label htmlFor="email" className="text-lg font-semibold">
                                        Email Address (Required for Results)
                                    </Label>
                                    <Input
                                        id="email"
                                        type="email"
                                        placeholder="your.email@company.com"
                                        value={emailCapture}
                                        onChange={(e) => setEmailCapture(e.target.value)}
                                        required
                                    />
                                    <p className="text-sm text-gray-600">
                                        We'll send you a detailed risk report and DFARS compliance guide. No spam, ever.
                                    </p>
                                </div>
                            </div>

                            <Button 
                                onClick={handleSubmit}
                                className="w-full bg-blue-600 hover:bg-blue-700"
                                size="lg"
                                disabled={!emailCapture || Object.keys(responses).length < riskFactors.length}
                            >
                                Calculate My DFARS Risk Score
                            </Button>
                        </CardContent>
                    </Card>
                </div>

                <div className="lg:col-span-1">
                    <Card className="sticky top-6">
                        <CardHeader>
                            <CardTitle>Your Risk Assessment</CardTitle>
                            <CardDescription>Real-time score calculation</CardDescription>
                        </CardHeader>
                        <CardContent>
                            {!showResults ? (
                                <div className="text-center py-8">
                                    <Calculator className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                                    <p className="text-gray-600">Complete the assessment to see your DFARS risk score</p>
                                    <Progress value={(Object.keys(responses).length / riskFactors.length) * 100} className="mt-4" />
                                    <p className="text-sm text-gray-500 mt-2">
                                        {Object.keys(responses).length}/{riskFactors.length} questions answered
                                    </p>
                                </div>
                            ) : (
                                <motion.div
                                    initial={{ scale: 0.8, opacity: 0 }}
                                    animate={{ scale: 1, opacity: 1 }}
                                    className="text-center space-y-6"
                                >
                                    <div className={`rounded-full w-32 h-32 mx-auto flex items-center justify-center ${riskLevel.bg}`}>
                                        <div className="text-center">
                                            <div className={`text-3xl font-bold ${riskLevel.color}`}>{riskScore}</div>
                                            <div className="text-sm font-semibold">Risk Score</div>
                                        </div>
                                    </div>

                                    <Alert className={riskLevel.bg}>
                                        <AlertTriangle className="h-4 w-4" />
                                        <AlertTitle>Risk Level: {riskLevel.level}</AlertTitle>
                                        <AlertDescription>
                                            {riskScore <= 25 && "Your DFARS compliance risk is low. Maintain current practices and monitor for changes."}
                                            {riskScore > 25 && riskScore <= 50 && "Moderate risk detected. Consider implementing additional safeguards."}
                                            {riskScore > 50 && riskScore <= 75 && "High risk of DFARS non-compliance. Immediate action recommended."}
                                            {riskScore > 75 && "Critical risk! You need urgent DFARS compliance assistance to avoid penalties."}
                                        </AlertDescription>
                                    </Alert>

                                    <div className="space-y-3 text-left">
                                        <h4 className="font-semibold flex items-center gap-2">
                                            <Zap className="w-4 h-4 text-blue-600" />
                                            Recommended Next Steps:
                                        </h4>
                                        <ul className="space-y-2 text-sm">
                                            <li className="flex items-center gap-2">
                                                <CheckCircle className="w-3 h-3 text-green-600" />
                                                Schedule a free DFARS consultation
                                            </li>
                                            <li className="flex items-center gap-2">
                                                <CheckCircle className="w-3 h-3 text-green-600" />
                                                Try HyperCore's AI gap analysis tool
                                            </li>
                                            <li className="flex items-center gap-2">
                                                <CheckCircle className="w-3 h-3 text-green-600" />
                                                Download our 90-day DFARS compliance plan
                                            </li>
                                        </ul>
                                    </div>

                                    <div className="space-y-2">
                                        <Button className="w-full bg-green-600 hover:bg-green-700">
                                            Get My Free Consultation
                                        </Button>
                                        <Button variant="outline" className="w-full">
                                            <FileText className="w-4 h-4 mr-2" />
                                            Download Full Report
                                        </Button>
                                    </div>
                                </motion.div>
                            )}
                        </CardContent>
                    </Card>
                </div>
            </div>
        </div>
    );
}