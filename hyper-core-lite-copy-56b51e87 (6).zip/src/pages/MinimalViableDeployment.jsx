import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Server, Globe, Mail, Handshake, ShieldCheck, ArrowRight, CheckCircle, Users } from 'lucide-react';

export default function MinimalViableDeployment() {
    
    const steps = [
        {
            title: "Finalize EC2 & Route 53 Connection",
            icon: Server,
            description: "Your EC2 instance and Route 53 are set up, which is excellent. This final step makes your application live on your domain.",
            details: [
                "Ensure an Elastic IP is attached to your EC2 instance for a permanent IP address.",
                "Confirm your Route 53 'A' record for `hypercorecyber.com` points to that Elastic IP.",
                "Verify your EC2 Security Group allows inbound traffic on Port 80 (HTTP) and Port 443 (HTTPS)."
            ],
            cta: {
                text: "View Full Deployment Guide",
                href: createPageUrl("AWSImplementationGuide")
            }
        },
        {
            title: "Email Infrastructure (Minimal Cost)",
            icon: Mail,
            description: "Use a free, reliable service for initial client communication, invoicing, and support notifications.",
            details: [
                "Primary: Use the SendGrid Free Tier (up to 100 emails/day). It's easy to set up and highly reliable.",
                "Secondary (Future): Plan to use AWS SES for bulk marketing once you have revenue. It's cheaper at scale but requires getting out of the sandbox.",
                "Immediate Action: Configure and test your SendGrid secrets."
            ],
            cta: {
                text: "Configure & Test Email",
                href: createPageUrl("EmailInfrastructure")
            }
        },
        {
            title: "CRM & Customer Support (Zero Cost)",
            icon: Users,
            description: "Leverage the tools already built into your platform instead of paying for expensive SaaS products like Salesforce or Zendesk.",
            details: [
                "CRM: Use the 'Partnership Hub' to track all leads, partners, and sales communications.",
                "Customer Support: Use the 'Support Dashboard' to manage all client tickets.",
                "AI Support: The built-in 'support_agent' will handle common questions, reducing your workload automatically."
            ],
            cta: {
                text: "Go to Partnership CRM",
                href: createPageUrl("PartnershipHub")
            }
        },
        {
            title: "AWS Support (Zero Cost)",
            icon: ShieldCheck,
            description: "You do not need to pay for AWS support at this stage. The free tier is more than sufficient.",
            details: [
                "Use the 'AWS Basic Support' plan, which is included for free with your account.",
                "For technical issues, rely on AWS Documentation, community forums, and Stack Overflow.",
                "Only consider a paid support plan if you face a critical, revenue-impacting outage you cannot solve."
            ]
        }
    ];

    return (
        <div className="space-y-8">
            <div className="text-center">
                <h1 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-3">
                    Minimal Viable Deployment Plan
                </h1>
                <p className="text-lg lg:text-xl text-gray-600">
                    Your streamlined, cost-effective checklist to become client-ready.
                </p>
            </div>

            <Alert className="bg-blue-50 border-blue-200">
                <ShieldCheck className="h-4 w-4 text-blue-600" />
                <AlertTitle className="text-blue-800">The Strategy: Efficiency and Zero Cost</AlertTitle>
                <AlertDescription className="text-blue-700">
                    This plan focuses on using the AWS Free Tier and your platform's existing features to keep your monthly costs under $5 while you acquire your first clients. Avoid paying for external software.
                </AlertDescription>
            </Alert>
            
            <div className="space-y-6">
                {steps.map((step, index) => (
                    <Card key={index}>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-3">
                                <step.icon className="w-6 h-6 text-gray-700" />
                                {step.title}
                            </CardTitle>
                            <CardDescription>{step.description}</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <ul className="space-y-2 text-sm text-gray-800 mb-4">
                                {step.details.map((detail, i) => (
                                    <li key={i} className="flex items-start gap-2">
                                        <CheckCircle className="w-4 h-4 mt-0.5 text-green-500 flex-shrink-0" />
                                        <span>{detail}</span>
                                    </li>
                                ))}
                            </ul>
                            {step.cta && (
                                <Button asChild>
                                    <Link to={step.cta.href}>
                                        {step.cta.text} <ArrowRight className="w-4 h-4 ml-2" />
                                    </Link>
                                </Button>
                            )}
                        </CardContent>
                    </Card>
                ))}
            </div>

            <Card className="bg-green-50 border-green-200">
                <CardHeader>
                    <CardTitle>Your Immediate Next Steps</CardTitle>
                    <CardDescription>Follow this order to get fully operational.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                   <p><strong>1. Finalize Server Configuration:</strong> Follow the <Link to={createPageUrl("AWSImplementationGuide")} className="font-semibold underline text-blue-600">AWS Implementation Guide</Link> to get your site live on `hypercorecyber.com`.</p>
                   <p><strong>2. Set up and Test Email:</strong> Use the <Link to={createPageUrl("EmailInfrastructure")} className="font-semibold underline text-blue-600">Email Infrastructure</Link> page to configure SendGrid and send a test email to yourself.</p>
                   <p><strong>3. Begin Client Outreach:</strong> With your tech ready, immediately start executing the <Link to={createPageUrl("DeploymentActionPlan")} className="font-semibold underline text-blue-600">Deployment Action Plan</Link> to find your expert partner and pilot client.</p>
                </CardContent>
            </Card>

        </div>
    );
}