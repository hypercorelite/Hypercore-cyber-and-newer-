import React from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { ArrowRight, FileText, Shield, Zap } from 'lucide-react';
import BreadcrumbNav from '../components/navigation/BreadcrumbNav';

export default function ClientAcquisitionHub() {
    const tools = [
        {
            name: 'AI SSP Builder',
            description: 'Generate a complete System Security Plan tailored to a client\'s specific system in minutes. A core deliverable for CMMC.',
            href: createPageUrl('SSPBuilder'),
            icon: Shield,
        },
        {
            name: 'AI Policy Generator',
            description: 'Instantly create a suite of CMMC-compliant policy documents for an organization, saving dozens of hours of manual work.',
            href: createPageUrl('PolicyGenerator'),
            icon: FileText,
        },
    ];

    return (
        <div className="space-y-8">
            <BreadcrumbNav currentPageName="ClientAcquisitionHub" />
            <CardHeader className="px-0">
                <CardTitle className="text-3xl font-bold flex items-center gap-3">
                    <Zap className="w-8 h-8 text-green-600" />
                    Client Acquisition & Demo Hub
                </CardTitle>
                <CardDescription className="text-lg">
                    This is your central point for running live demos and onboarding new clients into the free beta program. All systems are operational.
                </CardDescription>
            </CardHeader>

            <Card className="bg-gradient-to-r from-green-50 to-blue-50">
                <CardHeader>
                    <CardTitle>Live Demo Tools</CardTitle>
                    <CardDescription>
                        Use these links to demonstrate the core AI capabilities to prospective clients. Each use generates valuable data for your SBIR proposal.
                    </CardDescription>
                </CardHeader>
                <CardContent className="grid md:grid-cols-2 gap-6">
                    {tools.map((tool) => (
                        <Link to={tool.href} key={tool.name} className="block">
                            <Card className="hover:shadow-lg hover:border-blue-400 transition-all h-full bg-white">
                                <CardHeader className="flex flex-row items-start gap-4">
                                    <div className="bg-blue-100 p-3 rounded-lg">
                                        <tool.icon className="w-6 h-6 text-blue-600" />
                                    </div>
                                    <div>
                                        <CardTitle>{tool.name}</CardTitle>
                                        <CardDescription>{tool.description}</CardDescription>
                                    </div>
                                </CardHeader>
                                <CardContent>
                                    <Button variant="outline" className="w-full">
                                        Open Tool <ArrowRight className="w-4 h-4 ml-2" />
                                    </Button>
                                </CardContent>
                            </Card>
                        </Link>
                    ))}
                </CardContent>
            </Card>

             <Card>
                <CardHeader>
                    <CardTitle>Next Steps & Strategy</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4 text-sm text-gray-700">
                    <p>
                        <strong>1. Conduct Demos:</strong> Use the tools above with sample client data to showcase the platform's power during sales calls.
                    </p>
                    <p>
                        <strong>2. Collect Data:</strong> Every generated document and assessment contributes to the `DemoDataCollection` entity, strengthening your SBIR Phase I proposal with tangible proof of capability.
                    </p>
                    <p>
                        <strong>3. Onboard Beta Users:</strong> Direct prospects to these tools to let them experience the value firsthand. You can track their journey and engagement via the `ClientOnboarding` and `ClientEngagement` data tables in the dashboard.
                    </p>
                </CardContent>
            </Card>
        </div>
    );
}