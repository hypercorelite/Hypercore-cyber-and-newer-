import React, { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Loader2, Target, FileText, BarChart, X, Copy, Check } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { toast } from "sonner";
import { ComplianceFramework } from '@/api/entities';

// Import the AI functions
import { aiGapAnalysis } from '@/api/functions';
import { generateSSP } from '@/api/functions';
import { generatePOAM } from '@/api/functions';

const demoScenarios = [
    {
        id: 'gap_analysis',
        title: 'AI Gap Analysis Engine',
        description: 'Automated NIST 800-171 compliance gap identification with risk-based prioritization.',
        icon: Target,
        sbir_relevance: 'Core Phase I Deliverable - Demonstrates AI-powered assessment vs. manual consulting.'
    },
    {
        id: 'ssp_generation',
        title: 'Automated SSP Generation',
        description: 'AI-generated System Security Plan based on client environment and implemented controls.',
        icon: FileText,
        sbir_relevance: 'Key Innovation - Reduces 40+ hour manual process to 15 minutes.'
    },
    {
        id: 'poam_creation',
        title: 'POA&M Automation',
        description: 'Intelligent Plan of Action & Milestones with timeline and resource estimation.',
        icon: BarChart,
        sbir_relevance: 'Measurable Efficiency - Automates complex remediation planning.'
    }
];

function DemoResults({ results, demoId, onCopy }) {
    if (!results) return null;

    const copyContent = (content) => {
        navigator.clipboard.writeText(content);
        toast.success("Content copied to clipboard!");
    };
    
    let renderContent;

    switch(demoId) {
        case 'gap_analysis':
            const { analysis } = results;
            renderContent = (
                <div className="space-y-4">
                    <Card>
                        <CardHeader>
                            <CardTitle>Overall Compliance Score: {analysis.overall_compliance_score}%</CardTitle>
                            <CardDescription>Predicted C3PAO Assessment Outcome: <Badge>{analysis.predicted_assessment_outcome}</Badge></CardDescription>
                        </CardHeader>
                    </Card>
                    <Card>
                        <CardHeader><CardTitle>Critical Gaps</CardTitle></CardHeader>
                        <CardContent><ul>{analysis.critical_gaps.map((gap, i) => <li key={i} className="list-disc ml-4">{gap}</li>)}</ul></CardContent>
                    </Card>
                    <Card>
                        <CardHeader><CardTitle>Implementation Roadmap (Quick Wins)</CardTitle></CardHeader>
                        <CardContent><ul>{analysis.quick_wins.map((win, i) => <li key={i} className="list-disc ml-4">{win}</li>)}</ul></CardContent>
                    </Card>
                     <Card>
                        <CardHeader><CardTitle>Cost Analysis</CardTitle></CardHeader>
                        <CardContent>
                            <p><strong>Traditional Consulting Cost:</strong> {analysis.cost_analysis.traditional_cost}</p>
                            <p><strong>AI-Assisted Cost:</strong> {analysis.cost_analysis.ai_assisted_cost}</p>
                            <p className="font-bold text-green-600">Time Savings: {analysis.cost_analysis.time_savings}</p>
                        </CardContent>
                    </Card>
                </div>
            );
            break;
        case 'ssp_generation':
            renderContent = (
                 <div>
                    <div className="flex justify-between items-center mb-2">
                        <h3 className="font-semibold text-lg">System Security Plan (SSP)</h3>
                        <Button variant="outline" size="sm" onClick={() => copyContent(results.ssp)}><Copy className="w-4 h-4 mr-2"/>Copy SSP</Button>
                    </div>
                    <div className="prose prose-sm max-w-none h-96 overflow-y-auto bg-gray-50 p-4 rounded-md border">
                        <ReactMarkdown>{results.ssp}</ReactMarkdown>
                    </div>
                </div>
            );
            break;
        case 'poam_creation':
             renderContent = (
                 <div>
                    <div className="flex justify-between items-center mb-2">
                        <h3 className="font-semibold text-lg">Plan of Action & Milestones (POA&M)</h3>
                         <Button variant="outline" size="sm" onClick={() => copyContent(results.poam)}><Copy className="w-4 h-4 mr-2"/>Copy POA&M</Button>
                    </div>
                    <div className="prose prose-sm max-w-none h-96 overflow-y-auto bg-gray-50 p-4 rounded-md border">
                        <ReactMarkdown>{results.poam}</ReactMarkdown>
                    </div>
                    <Card className="mt-4">
                        <CardHeader><CardTitle>POA&M Summary</CardTitle></CardHeader>
                        <CardContent>
                            <p><strong>High Priority Items:</strong> {results.high_priority.join(', ')}</p>
                            <p><strong>Estimated Completion:</strong> {results.completion_date}</p>
                            <p><strong>Estimated Cost:</strong> {results.cost_estimate}</p>
                        </CardContent>
                    </Card>
                </div>
            );
            break;
        default:
            renderContent = <p>No results to display.</p>;
    }

    return <div className="mt-6">{renderContent}</div>;
}

export default function SBIRDemoPortal() {
    const [activeDemo, setActiveDemo] = useState(null);
    const [demoResults, setDemoResults] = useState(null);
    const [loading, setLoading] = useState(false);
    const [demoFrameworkId, setDemoFrameworkId] = useState(null);

    // Ensure a demo framework exists on page load
    useEffect(() => {
        const setupDemoEnvironment = async () => {
            try {
                // Check if a demo framework already exists
                const existing = await ComplianceFramework.filter({ organization_name: 'SBIR_DEMO_CLIENT' });
                if (existing.length > 0) {
                    setDemoFrameworkId(existing[0].id);
                } else {
                    // If not, create one
                    const framework = await ComplianceFramework.create({
                        framework_name: 'CMMC',
                        organization_name: 'SBIR_DEMO_CLIENT',
                        compliance_status: 'in_progress'
                    });
                    setDemoFrameworkId(framework.id);
                    toast.info("Demo environment prepared.");
                }
            } catch (error) {
                toast.error("Could not prepare demo environment.");
                console.error(error);
            }
        };
        setupDemoEnvironment();
    }, []);
    
    const handleRunDemo = async (demoId) => {
        if (!demoFrameworkId) {
            toast.error("Demo environment not ready. Please refresh.");
            return;
        }

        setActiveDemo(demoId);
        setLoading(true);
        setDemoResults(null);
        
        try {
            let response;
            const mockOrgData = { name: "SBIR Demo Client", systemType: "Hybrid Cloud" };

            switch(demoId) {
                case 'gap_analysis':
                    response = await aiGapAnalysis({ frameworkId: demoFrameworkId, organizationProfile: mockOrgData });
                    break;
                case 'ssp_generation':
                    response = await generateSSP({ frameworkId: demoFrameworkId, organizationData: mockOrgData });
                    break;
                case 'poam_creation':
                    response = await generatePOAM({ frameworkId: demoFrameworkId });
                    break;
                default:
                    throw new Error("Invalid demo ID");
            }

            if (response.error) {
                throw new Error(response.error);
            }
            
            setDemoResults(response);
            toast.success("AI Analysis Complete!");

        } catch (error) {
            toast.error(`Demo failed: ${error.message}`);
            console.error(error);
        } finally {
            setLoading(false);
        }
    };
    
    return (
        <div className="p-4 sm:p-6 lg:p-8 bg-gray-50 min-h-screen">
            <div className="max-w-6xl mx-auto">
                <header className="text-center mb-12">
                    <Badge variant="secondary" className="mb-4">SBIR Interactive Demo</Badge>
                    <h1 className="text-4xl font-bold tracking-tight">AI-Powered CMMC Tutoring Platform</h1>
                    <p className="text-lg text-gray-600 mt-2 max-w-3xl mx-auto">
                        This interactive portal demonstrates the core AI capabilities outlined in our Phase I proposal.
                    </p>
                </header>

                <Alert className="mb-8 bg-blue-50 border-blue-200">
                    <Target className="h-4 w-4 text-blue-700" />
                    <AlertTitle className="font-bold text-blue-800">Instructions for Reviewers</AlertTitle>
                    <AlertDescription className="text-blue-700">
                        Select a capability below to run a live AI analysis. Each demo showcases a key innovation that reduces cost and complexity for DoD suppliers.
                    </AlertDescription>
                </Alert>

                <div className="grid md:grid-cols-3 gap-6">
                    {demoScenarios.map(demo => (
                        <Card key={demo.id} className={`transition-all ${activeDemo === demo.id ? 'border-blue-500 ring-2 ring-blue-500' : 'hover:shadow-lg'}`}>
                            <CardHeader>
                                <div className="flex items-center gap-3 mb-2">
                                    <demo.icon className="w-8 h-8 text-blue-600" />
                                    <CardTitle>{demo.title}</CardTitle>
                                </div>
                                <CardDescription>{demo.description}</CardDescription>
                            </CardHeader>
                            <CardContent>
                                <p className="text-xs text-gray-500 mb-4 p-2 bg-gray-50 rounded-md">
                                    <strong>SBIR Relevance:</strong> {demo.sbir_relevance}
                                </p>
                                <Button className="w-full" onClick={() => handleRunDemo(demo.id)} disabled={loading}>
                                    {loading && activeDemo === demo.id ? <><Loader2 className="w-4 h-4 animate-spin mr-2"/>Running...</> : 'Run Live Demo'}
                                </Button>
                            </CardContent>
                        </Card>
                    ))}
                </div>

                {(loading || demoResults) && (
                    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mt-8">
                        <Card className="relative">
                            <CardHeader>
                                <div className="flex justify-between items-center">
                                    <CardTitle>AI Analysis Results</CardTitle>
                                    <Button variant="ghost" size="icon" onClick={() => { setActiveDemo(null); setDemoResults(null); }}>
                                        <X className="w-4 h-4"/>
                                    </Button>
                                </div>
                            </CardHeader>
                            <CardContent>
                                {loading ? <div className="flex justify-center items-center h-48"><Loader2 className="w-8 h-8 animate-spin text-blue-600"/></div> : <DemoResults results={demoResults} demoId={activeDemo} />}
                            </CardContent>
                        </Card>
                    </motion.div>
                )}
            </div>
        </div>
    );
}