import React, { useState, useEffect } from 'react';
import { User } from '@/api/entities';
import { ComplianceFramework } from '@/api/entities';
import { UploadFile } from '@/api/integrations';
import { analyzeCMMCDocument } from '@/api/functions';
import { createComplianceTasksFromAnalysis } from '@/api/functions';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Progress } from "@/components/ui/progress";
import { toast } from "sonner";
import { Loader2, ArrowRight, UserPlus, FileUp, Bot, CheckCircle } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const STEPS = [
    { id: 1, name: "Create Account", description: "Sign up to start the process." },
    { id: 2, name: "Company Profile", description: "Tell us about your organization." },
    { id: 3, name: "AI Analysis", description: "Upload a document for instant analysis." },
    { id: 4, name: "Action Plan", description: "Review your AI-generated tasks." }
];

export default function ClientOnboarding() {
    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(true);
    const [currentStep, setCurrentStep] = useState(1);
    const navigate = useNavigate();

    const [profileData, setProfileData] = useState({
        organization_name: '',
        industry: '',
        size: '',
        location: '',
        cmmc_level: 'Level 2'
    });
    
    const [file, setFile] = useState(null);
    const [isProcessing, setIsProcessing] = useState(false);

    useEffect(() => {
        const fetchUser = async () => {
            try {
                const currentUser = await User.me();
                setUser(currentUser);
                if (currentUser.organization_name) {
                    setCurrentStep(3); // Already has a profile, skip to upload
                    setProfileData({
                        organization_name: currentUser.organization_name,
                        industry: currentUser.industry || '',
                        size: currentUser.size || '',
                        location: currentUser.location || '',
                        cmmc_level: currentUser.cmmc_level || 'Level 2'
                    });
                } else {
                    setCurrentStep(2); // Logged in, needs profile
                }
            } catch (error) {
                // Not logged in
                setCurrentStep(1);
            } finally {
                setLoading(false);
            }
        };
        fetchUser();
    }, []);

    const handleProfileSubmit = async (e) => {
        e.preventDefault();
        setIsProcessing(true);
        try {
            await User.updateMyUserData(profileData);
            const updatedUser = await User.me();
            setUser(updatedUser);
            setCurrentStep(3);
            toast.success("Profile saved! Now let's run your first analysis.");
        } catch (error) {
            toast.error("Failed to save profile. Please try again.");
            console.error(error);
        } finally {
            setIsProcessing(false);
        }
    };
    
    const handleAnalysisSubmit = async () => {
        if (!file) {
            toast.error("Please select a document to analyze.");
            return;
        }
        setIsProcessing(true);
        try {
            // 1. Create a compliance framework for the user
            toast.info("Creating your compliance workspace...");
            const framework = await ComplianceFramework.create({
                framework_name: "CMMC",
                framework_version: "2.0",
                organization_name: user.organization_name,
                assigned_compliance_officer: user.email,
            });

            // 2. Upload the document
            toast.info("Uploading document...");
            const { file_url } = await UploadFile({ file });
            
            // 3. Analyze the document
            toast.info("AI is analyzing your document...");
            const { data: analysisResult } = await analyzeCMMCDocument({ fileUrl: file_url });

            // 4. Create tasks based on the analysis
            toast.info("Generating your action plan...");
            await createComplianceTasksFromAnalysis({
                analysisResult,
                frameworkId: framework.id,
                userEmail: user.email,
            });

            toast.success("Onboarding complete! Redirecting to your dashboard...");
            setCurrentStep(4);
            
            // 5. Redirect to the new dashboard
            setTimeout(() => {
                navigate(createPageUrl(`CMMCReadinessAssessment?id=${framework.id}`));
            }, 2000);

        } catch (error) {
            toast.error("An error occurred during analysis. Please try again.");
            console.error(error);
        } finally {
            setIsProcessing(false);
        }
    };

    if (loading) {
        return <div className="flex justify-center items-center h-screen"><Loader2 className="w-8 h-8 animate-spin" /></div>;
    }
    
    return (
        <div className="min-h-screen bg-gray-50 flex items-center justify-center p-6">
            <Card className="w-full max-w-2xl shadow-xl">
                <CardHeader>
                    <CardTitle className="text-2xl font-bold text-center">HyperCore AI Onboarding</CardTitle>
                    <CardDescription className="text-center">Your streamlined path to CMMC compliance starts here.</CardDescription>
                    <div className="pt-4">
                        <Progress value={(currentStep / STEPS.length) * 100} />
                        <div className="flex justify-between text-xs text-gray-500 mt-2">
                            {STEPS.map(step => (
                                <span key={step.id} className={currentStep >= step.id ? 'font-bold' : ''}>{step.name}</span>
                            ))}
                        </div>
                    </div>
                </CardHeader>
                <CardContent>
                    {currentStep === 1 && (
                        <div className="text-center space-y-4">
                            <UserPlus className="mx-auto h-12 w-12 text-blue-600" />
                            <h3 className="text-xl font-semibold">Welcome to HyperCore AI</h3>
                            <p>Please log in or create an account to begin your CMMC compliance journey.</p>
                            <Button size="lg" onClick={() => User.login()}>
                                Login or Sign Up <ArrowRight className="ml-2 h-4 w-4" />
                            </Button>
                        </div>
                    )}
                    {currentStep === 2 && (
                        <form onSubmit={handleProfileSubmit} className="space-y-4">
                            <h3 className="text-xl font-semibold text-center">Tell Us About Your Company</h3>
                            <Input placeholder="Organization Name" value={profileData.organization_name} onChange={(e) => setProfileData({...profileData, organization_name: e.target.value})} required />
                            <Input placeholder="Industry (e.g., Aerospace, Manufacturing)" value={profileData.industry} onChange={(e) => setProfileData({...profileData, industry: e.target.value})} required />
                            <div className="grid grid-cols-2 gap-4">
                                <Input type="number" placeholder="Number of Employees" value={profileData.size} onChange={(e) => setProfileData({...profileData, size: e.target.value})} required />
                                <Input placeholder="Location (e.g., Miami, FL)" value={profileData.location} onChange={(e) => setProfileData({...profileData, location: e.target.value})} required />
                            </div>
                            <Select onValueChange={(value) => setProfileData({...profileData, cmmc_level: value})} defaultValue={profileData.cmmc_level}>
                                <SelectTrigger><SelectValue placeholder="Select CMMC Level" /></SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="Level 1">CMMC Level 1</SelectItem>
                                    <SelectItem value="Level 2">CMMC Level 2</SelectItem>
                                    <SelectItem value="Level 3">CMMC Level 3</SelectItem>
                                </SelectContent>
                            </Select>
                            <Button type="submit" className="w-full" disabled={isProcessing}>
                                {isProcessing ? <Loader2 className="animate-spin h-4 w-4 mr-2" /> : null}
                                Save & Continue <ArrowRight className="ml-2 h-4 w-4" />
                            </Button>
                        </form>
                    )}
                    {currentStep === 3 && (
                         <div className="space-y-4 text-center">
                            <FileUp className="mx-auto h-12 w-12 text-blue-600" />
                            <h3 className="text-xl font-semibold">Run Your First AI Analysis</h3>
                            <p>Upload an existing policy, system diagram, or SSP to get an instant compliance gap analysis.</p>
                            <Input type="file" accept=".pdf,.txt,.docx" onChange={(e) => setFile(e.target.files[0])} disabled={isProcessing} className="file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"/>
                            <Button onClick={handleAnalysisSubmit} className="w-full" disabled={isProcessing || !file}>
                                {isProcessing ? <Loader2 className="animate-spin h-4 w-4 mr-2" /> : <Bot className="h-4 w-4 mr-2" />}
                                Start AI Analysis <ArrowRight className="ml-2 h-4 w-4" />
                            </Button>
                        </div>
                    )}
                     {currentStep === 4 && (
                        <div className="text-center space-y-4 py-8">
                            <CheckCircle className="mx-auto h-16 w-16 text-green-600 animate-pulse" />
                            <h3 className="text-2xl font-bold">Onboarding Complete!</h3>
                            <p className="text-gray-600">Your AI-generated action plan is ready. We are now redirecting you to your personalized compliance dashboard.</p>
                             <Loader2 className="mx-auto w-6 h-6 animate-spin text-gray-400" />
                        </div>
                    )}
                </CardContent>
            </Card>
        </div>
    );
}