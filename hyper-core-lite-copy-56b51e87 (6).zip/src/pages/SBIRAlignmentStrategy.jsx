import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { CheckCircle, Target, DollarSign, Calendar, FileText, Zap, TrendingUp } from "lucide-react";

const SBIRTopics = [
    {
        topic: "AFWERX Open Topic (25.5/E Release 10)",
        alignment: "Dual-use AI for cyber resilience in DIB; no specific scope—propose for SMB CMMC onboarding",
        hyperCoreFit: "AI SSP/policy gen and control mapping automate 110 NIST controls; analytics dashboard quantifies risk gaps (e.g., predictive POA&Ms)",
        enhancement: "Emphasize 5–10 SMB pilots for 85% satisfaction; target $75K Phase I to refine 3PAO simulator",
        funding: "$75K Phase I",
        deadline: "Rolling quarterly",
        winProbability: "High (70-80%)"
    },
    {
        topic: "DARPA HR0011SB20254-12 (ASEMA)",
        alignment: "AI modeling of security risks and defensive recommendations for critical platforms (e.g., encrypted comms in DIB)",
        hyperCoreFit: "Extend control mapping to risk scoring (e.g., ML on audit data for AU/SC families); Base64 PDF exports for secure SPRS reporting",
        enhancement: "Adapt for DIB-wide risk modeling; cite CMMC's 422 assessment objectives as 'defensive measures'",
        funding: "$1.5M Phase II potential",
        deadline: "Active - check DSIP",
        winProbability: "Medium-High (60-70%)"
    },
    {
        topic: "DoD SBIR 25.4 BAA (Cybersecurity Focus)",
        alignment: "Monthly releases on AI/cyber; aligns with CMMC program rule (32 C.F.R. Part 170)",
        hyperCoreFit: "Backend analytics for efficiency (e.g., 50% savings vs. manual docs); LOI form for user feedback integration",
        enhancement: "Propose under Release 3 (closes February 5, 2025); highlight zero-cost stack for SMB scalability",
        funding: "$175K Phase I",
        deadline: "February 5, 2025",
        winProbability: "High (75%)"
    },
    {
        topic: "Navy SBIR 25.4 (Conventional/Open Topics)",
        alignment: "3 open topics for SYSCOMs; cyber tools for supply chain",
        hyperCoreFit: "Implementation guidance (e.g., MFA/encryption workflows) for Navy subs; analytics for adoption metrics",
        enhancement: "Use for flow-down compliance; attend August 25–28, 2025, workshops for TPOC feedback",
        funding: "$140K Phase I",
        deadline: "Various rolling",
        winProbability: "Medium (50-60%)"
    }
];

const FeatureAlignments = [
    {
        feature: "AI-Driven SSP and Policy Generation",
        alignment: "AFWERX's 'Trusted AI and Autonomy' CTA by automating 14-domain templates (e.g., AC/IR policies)",
        phaseISuggestion: "Fine-tune LLMs on NIST 800-171A AOs for 95% traceability; demonstrate via pilot data showing 12-hour SSP creation (vs. 168 hours manual)",
        marketValue: "$3.1M ARR potential"
    },
    {
        feature: "110-Control Mapping and Scoring",
        alignment: "DARPA's risk modeling—use ML for predictive gaps (e.g., 90% accuracy on AU.L2-3.3.1 logging)",
        phaseISuggestion: "Integrate with SPRS exports; propose analytics endpoint for real-time scoring, reducing 3PAO prep by 40%",
        marketValue: "40% audit prep reduction"
    },
    {
        feature: "Reporting and POA&M (jsPDF/Base64 PDFs)",
        alignment: "CMMC's SPRS affirmations; secure encoding ensures SC.L2-3.13.8 compliance",
        phaseISuggestion: "Add hash verification for 6-year retention; highlight in commercialization plan for $5M ARR via $99/month subscriptions",
        marketValue: "$5M ARR target"
    },
    {
        feature: "Backend Analytics and API Router",
        alignment: "DoD's data-driven cyber tools; demonstrates speed/efficiency (JWT-secured, 320ms response)",
        phaseISuggestion: "Log metrics (e.g., SQLite for LOI feedback) to evidence 50% cost savings; propose Phase I expansion to Redis caching for 1,000-user scalability",
        marketValue: "50% cost savings demonstrated"
    },
    {
        feature: "3PAO Audit Guidance and Mock Simulator",
        alignment: "SMB audit fears; fits Open Topic's DIB resilience",
        phaseISuggestion: "Develop interactive checklists with AI confidence filters; pilot with 5 SMBs to generate LOIs, boosting Volume 4 commitment",
        marketValue: "85% user satisfaction"
    }
];

const ProposalRefinements = [
    {
        volume: "Technical Volume (Volume 1)",
        refinement: "Update milestones to include feature pilots (e.g., Month 3: Analytics validation on 20 controls). Add table of alignments to show merit.",
        priority: "Critical"
    },
    {
        volume: "Commercialization (Volume 3)",
        refinement: "Project $500M market for 31,500 SMB contracts; cite dual-use for HIPAA to meet dual-use mandates.",
        priority: "High"
    },
    {
        volume: "Budget Tweaks",
        refinement: "Allocate $20K of $174.5K Phase I to AI fine-tuning; emphasize zero-capital baseline.",
        priority: "Medium"
    },
    {
        volume: "Risk Mitigation",
        refinement: "Address AI 'death' concerns in Open Topics by focusing on quality metrics (e.g., human-in-loop reviews).",
        priority: "High"
    }
];

export default function SBIRAlignmentStrategy() {
    const [selectedTopic, setSelectedTopic] = useState(0);

    return (
        <div className="space-y-8 p-6">
            <div className="text-center mb-8">
                <Badge className="mb-4 bg-red-100 text-red-800">SBIR STRATEGY INTELLIGENCE</Badge>
                <h1 className="text-4xl font-bold text-gray-900 mb-4">
                    HyperCore SBIR Alignment Strategy Dashboard
                </h1>
                <p className="text-xl text-gray-600 max-w-4xl mx-auto">
                    Strategic intelligence for maximizing SBIR funding success through precise topic alignment and feature positioning
                </p>
            </div>

            <Alert className="bg-green-50 border-green-200">
                <Target className="h-4 w-4 text-green-600" />
                <AlertTitle className="text-green-800">Strategic Positioning</AlertTitle>
                <AlertDescription className="text-green-700">
                    <strong>70-80% Win Probability:</strong> HyperCore's AI-first platform perfectly aligns with DoD SBIR priorities, 
                    offering quantifiable solutions to the $1B CMMC compliance crisis while supporting AFWERX cyber resilience objectives.
                </AlertDescription>
            </Alert>

            <Tabs defaultValue="topics" className="w-full">
                <TabsList className="grid w-full grid-cols-4">
                    <TabsTrigger value="topics">SBIR Topics</TabsTrigger>
                    <TabsTrigger value="features">Feature Alignment</TabsTrigger>
                    <TabsTrigger value="proposal">Proposal Strategy</TabsTrigger>
                    <TabsTrigger value="execution">Execution Plan</TabsTrigger>
                </TabsList>

                <TabsContent value="topics" className="space-y-6">
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <Target className="w-5 h-5 text-blue-600" />
                                Priority SBIR Topic Alignments
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="grid gap-4">
                                {SBIRTopics.map((topic, index) => (
                                    <Card key={index} className={`cursor-pointer transition-all ${selectedTopic === index ? 'border-blue-500 bg-blue-50' : 'hover:bg-gray-50'}`}
                                          onClick={() => setSelectedTopic(index)}>
                                        <CardContent className="p-4">
                                            <div className="flex justify-between items-start mb-3">
                                                <h3 className="font-semibold text-lg text-blue-800">{topic.topic}</h3>
                                                <div className="flex gap-2">
                                                    <Badge variant="outline">{topic.funding}</Badge>
                                                    <Badge className={topic.winProbability.includes('High') ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}>
                                                        {topic.winProbability}
                                                    </Badge>
                                                </div>
                                            </div>
                                            <p className="text-sm text-gray-600 mb-2"><strong>Alignment:</strong> {topic.alignment}</p>
                                            <p className="text-sm text-blue-700 mb-2"><strong>HyperCore Fit:</strong> {topic.hyperCoreFit}</p>
                                            <p className="text-sm text-green-700"><strong>Enhancement:</strong> {topic.enhancement}</p>
                                            <div className="mt-3 flex justify-between items-center text-xs text-gray-500">
                                                <span><strong>Deadline:</strong> {topic.deadline}</span>
                                            </div>
                                        </CardContent>
                                    </Card>
                                ))}
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="features" className="space-y-6">
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <Zap className="w-5 h-5 text-purple-600" />
                                Feature-to-Grant Alignment Matrix
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-6">
                                {FeatureAlignments.map((feature, index) => (
                                    <div key={index} className="border rounded-lg p-4">
                                        <div className="flex justify-between items-start mb-3">
                                            <h3 className="font-semibold text-purple-800">{feature.feature}</h3>
                                            <Badge className="bg-purple-100 text-purple-800">{feature.marketValue}</Badge>
                                        </div>
                                        <div className="grid md:grid-cols-2 gap-4 text-sm">
                                            <div>
                                                <h4 className="font-medium text-gray-700 mb-1">SBIR Alignment</h4>
                                                <p className="text-gray-600">{feature.alignment}</p>
                                            </div>
                                            <div>
                                                <h4 className="font-medium text-gray-700 mb-1">Phase I Suggestion</h4>
                                                <p className="text-gray-600">{feature.phaseISuggestion}</p>
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="proposal" className="space-y-6">
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <FileText className="w-5 h-5 text-green-600" />
                                Proposal Refinement Strategy
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-4">
                                {ProposalRefinements.map((refinement, index) => (
                                    <div key={index} className="flex items-start gap-4 p-4 border rounded-lg">
                                        <div className={`w-2 h-2 rounded-full mt-2 ${
                                            refinement.priority === 'Critical' ? 'bg-red-500' :
                                            refinement.priority === 'High' ? 'bg-yellow-500' : 'bg-blue-500'
                                        }`}></div>
                                        <div className="flex-1">
                                            <div className="flex justify-between items-start mb-2">
                                                <h3 className="font-semibold">{refinement.volume}</h3>
                                                <Badge variant="outline" className={
                                                    refinement.priority === 'Critical' ? 'border-red-500 text-red-700' :
                                                    refinement.priority === 'High' ? 'border-yellow-500 text-yellow-700' : 'border-blue-500 text-blue-700'
                                                }>
                                                    {refinement.priority}
                                                </Badge>
                                            </div>
                                            <p className="text-sm text-gray-600">{refinement.refinement}</p>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    <Card>
                        <CardHeader>
                            <CardTitle>Quantifiable Success Metrics</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="grid md:grid-cols-3 gap-4">
                                <div className="text-center p-4 bg-blue-50 rounded-lg">
                                    <div className="text-2xl font-bold text-blue-800">90%</div>
                                    <div className="text-sm text-blue-600">AI Accuracy Target</div>
                                </div>
                                <div className="text-center p-4 bg-green-50 rounded-lg">
                                    <div className="text-2xl font-bold text-green-800">320ms</div>
                                    <div className="text-sm text-green-600">API Response Time</div>
                                </div>
                                <div className="text-center p-4 bg-purple-50 rounded-lg">
                                    <div className="text-2xl font-bold text-purple-800">80%</div>
                                    <div className="text-sm text-purple-600">Documentation Effort Reduction</div>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="execution" className="space-y-6">
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <Calendar className="w-5 h-5 text-orange-600" />
                                Immediate Action Plan
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-4">
                                <Alert>
                                    <CheckCircle className="h-4 w-4" />
                                    <AlertTitle>Priority Action Items (Next 30 Days)</AlertTitle>
                                    <AlertDescription>
                                        <ul className="list-disc pl-6 space-y-1 mt-2">
                                            <li>Submit to AFWERX Open Topic (25.5/E Release 10) - Rolling deadline</li>
                                            <li>Secure 3 additional LOIs via your existing form for Volume 5 evidence</li>
                                            <li>Join upcoming AFWERX AMA webinars for direct TPOC feedback</li>
                                            <li>Register for Navy SBIR workshops (August 25-28, 2025 format)</li>
                                        </ul>
                                    </AlertDescription>
                                </Alert>

                                <div className="grid md:grid-cols-2 gap-4">
                                    <Card>
                                        <CardHeader>
                                            <CardTitle className="text-lg">Phase I Milestones</CardTitle>
                                        </CardHeader>
                                        <CardContent className="text-sm space-y-2">
                                            <p><strong>Month 1-2:</strong> AI algorithm development and validation</p>
                                            <p><strong>Month 3:</strong> Analytics validation on 20 controls</p>
                                            <p><strong>Month 4-5:</strong> SMB pilot deployments (5-10 clients)</p>
                                            <p><strong>Month 6:</strong> Performance metrics and Phase II proposal</p>
                                        </CardContent>
                                    </Card>

                                    <Card>
                                        <CardHeader>
                                            <CardTitle className="text-lg">Budget Allocation</CardTitle>
                                        </CardHeader>
                                        <CardContent className="text-sm space-y-2">
                                            <p><strong>AI Fine-tuning:</strong> $20K (11.5% of $174.5K Phase I)</p>
                                            <p><strong>SMB Pilots:</strong> $30K for incentives and data collection</p>
                                            <p><strong>Development:</strong> $90K for core platform enhancement</p>
                                            <p><strong>Validation:</strong> $34.5K for testing and metrics</p>
                                        </CardContent>
                                    </Card>
                                </div>

                                <Card>
                                    <CardHeader>
                                        <CardTitle>Key Success Factors</CardTitle>
                                    </CardHeader>
                                    <CardContent>
                                        <div className="grid md:grid-cols-3 gap-4 text-sm">
                                            <div>
                                                <h4 className="font-semibold text-blue-800 mb-2">Technical Merit</h4>
                                                <ul className="space-y-1 text-blue-700">
                                                    <li>• Novel AI approach to compliance</li>
                                                    <li>• Quantifiable performance metrics</li>
                                                    <li>• Existing MVP demonstrates feasibility</li>
                                                </ul>
                                            </div>
                                            <div>
                                                <h4 className="font-semibold text-green-800 mb-2">Market Impact</h4>
                                                <ul className="space-y-1 text-green-700">
                                                    <li>• $1B+ addressable market</li>
                                                    <li>• 31,500 SMB contractors served</li>
                                                    <li>• 90% cost reduction vs. consultants</li>
                                                </ul>
                                            </div>
                                            <div>
                                                <h4 className="font-semibold text-purple-800 mb-2">Federal Alignment</h4>
                                                <ul className="space-y-1 text-purple-700">
                                                    <li>• Direct AFWERX cyber resilience fit</li>
                                                    <li>• DIB supply chain protection</li>
                                                    <li>• Dual-use commercialization path</li>
                                                </ul>
                                            </div>
                                        </div>
                                    </CardContent>
                                </Card>
                            </div>
                        </CardContent>
                    </Card>
                </CardContent>
            </Tabs>

            <Card className="bg-gradient-to-r from-green-50 to-blue-50">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <TrendingUp className="w-5 h-5 text-green-600" />
                        Strategic Competitive Advantage
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <p className="text-lg mb-4">
                        <strong>HyperCore is uniquely positioned</strong> as the only AI-first platform specifically designed for CMMC Level 2 compliance, 
                        with live user validation, quantifiable performance metrics, and direct alignment to multiple SBIR priorities.
                    </p>
                    <div className="flex flex-wrap gap-2">
                        <Badge className="bg-green-100 text-green-800">Working MVP with Live Users</Badge>
                        <Badge className="bg-blue-100 text-blue-800">Quantified Performance (320ms API)</Badge>
                        <Badge className="bg-purple-100 text-purple-800">$1B+ Market Opportunity</Badge>
                        <Badge className="bg-orange-100 text-orange-800">70-80% Win Probability</Badge>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}