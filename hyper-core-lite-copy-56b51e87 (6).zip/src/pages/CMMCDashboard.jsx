import React, { useState, useEffect } from 'react';
import { User } from '@/api/entities';
import CMMCGenerator from '../components/cmmc/CMMCGenerator';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Shield, Building, Users, MapPin } from 'lucide-react';

export default function CMMCDashboard() {
    const [user, setUser] = useState(null);
    const [clientDetails, setClientDetails] = useState({
        company_name: 'Defense Solutions Inc.',
        industry: 'Defense Contracting',
        size: '50-100',
        location: 'Virginia',
        cmmc_level: 'Level 2'
    });

    useEffect(() => {
        // SEO Optimization
        document.title = "CMMC Level 2 Compliance Dashboard | AI-Powered SSP & Controls";
        document.querySelector('meta[name="description"]')?.setAttribute('content', 
            'Complete CMMC Level 2 compliance dashboard. Generate SSP, policies, and controls with AI assistance. NIST 800-171 implementation for DoD contractors.');

        const fetchUser = async () => {
            try {
                const currentUser = await User.me();
                setUser(currentUser);
                if (currentUser.organization_name) {
                    setClientDetails(prev => ({
                        ...prev,
                        company_name: currentUser.organization_name,
                        industry: currentUser.industry || prev.industry,
                        location: currentUser.location || prev.location
                    }));
                }
            } catch (error) {
                console.log("User not logged in or fetch failed");
            }
        };
        
        fetchUser();
    }, []);

    return (
        <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6">
            <div className="max-w-7xl mx-auto">
                <div className="text-center mb-8">
                    <h1 className="text-4xl font-bold text-gray-900 mb-4">
                        CMMC Compliance Dashboard
                    </h1>
                    <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                        AI-powered document generation for CMMC Level 2 compliance. 
                        Generate SSP, controls, policies, and reports instantly.
                    </p>
                </div>

                <CMMCGenerator clientDetails={clientDetails} />
                
                {/* SEO-Friendly Content Section */}
                <div className="mt-12 space-y-8">
                    <Card>
                        <CardHeader>
                            <CardTitle>Why Choose AI-Powered CMMC Compliance?</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="grid md:grid-cols-3 gap-6">
                                <div className="text-center">
                                    <Shield className="w-12 h-12 text-blue-600 mx-auto mb-4" />
                                    <h3 className="font-semibold mb-2">NIST 800-171 Expertise</h3>
                                    <p className="text-sm text-gray-600">
                                        AI trained on all 110 NIST 800-171 controls for accurate implementation guidance.
                                    </p>
                                </div>
                                <div className="text-center">
                                    <Building className="w-12 h-12 text-blue-600 mx-auto mb-4" />
                                    <h3 className="font-semibold mb-2">DoD Contract Ready</h3>
                                    <p className="text-sm text-gray-600">
                                        Generate documentation that meets DoD requirements for federal contracts.
                                    </p>
                                </div>
                                <div className="text-center">
                                    <Users className="w-12 h-12 text-blue-600 mx-auto mb-4" />
                                    <h3 className="font-semibold mb-2">SMB Focused</h3>
                                    <p className="text-sm text-gray-600">
                                        Affordable CMMC compliance designed for small and medium-sized businesses.
                                    </p>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </div>
            </div>
        </div>
    );
}