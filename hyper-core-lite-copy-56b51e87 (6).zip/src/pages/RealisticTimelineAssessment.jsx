import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CheckCircle, AlertTriangle, Clock, Target, Zap, Calendar, X, ArrowRight } from 'lucide-react';
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";

const weekBreakdown = [
    {
        week: "Week 1: Foundation & AI Core",
        hours: 40,
        realistic: [
            "✅ Set up AWS infrastructure (Lambda, S3, DynamoDB) - 8 hours",
            "✅ Create basic user auth system with AI assistance - 6 hours", 
            "✅ Build document upload endpoint - 4 hours",
            "✅ Implement basic CMMC controls database - 6 hours",
            "✅ Create simple gap analysis algorithm - 8 hours",
            "✅ Basic PDF report generation - 4 hours",
            "✅ Deploy to staging environment - 4 hours"
        ],
        aggressive: [
            "❌ Attempting complex UI/UX in parallel with backend",
            "❌ Trying to implement all 110 controls in detail", 
            "❌ Building advanced user management system",
            "❌ Creating sophisticated reporting dashboards"
        ],
        bottlenecks: [
            "AWS account setup and permissions can take 1-2 days",
            "AI code quality varies - debugging can consume 25% of time",
            "Database schema design decisions require careful thought"
        ],
        outcome: "Basic working system that can accept uploads and generate simple reports"
    },
    {
        week: "Week 2: AI Analysis Engine",
        hours: 40,
        realistic: [
            "✅ Implement OpenAI integration for document analysis - 6 hours",
            "✅ Build vector database for CMMC knowledge base - 8 hours",
            "✅ Create AI prompt templates for SSP generation - 6 hours",
            "✅ Implement basic policy document generation - 8 hours",
            "✅ Add compliance scoring logic - 6 hours",
            "✅ Test and refine AI responses - 6 hours"
        ],
        aggressive: [
            "❌ Trying to achieve 95% accuracy on first attempt",
            "❌ Building complex AI training pipelines",
            "❌ Implementing real-time document processing",
            "❌ Creating advanced natural language understanding"
        ],
        bottlenecks: [
            "AI prompt engineering is iterative - takes longer than expected",
            "Vector database performance tuning can be complex",
            "OpenAI API rate limits may require optimization"
        ],
        outcome: "Working AI that can analyze documents and generate basic compliance reports"
    },
    {
        week: "Week 3: Frontend & Integration",
        hours: 40,
        realistic: [
            "✅ Build minimalist React frontend - 12 hours",
            "✅ Create dashboard with basic metrics - 8 hours", 
            "✅ Implement file upload interface - 4 hours",
            "✅ Add report download functionality - 4 hours",
            "✅ Basic user authentication flow - 6 hours",
            "✅ Integration testing and bug fixes - 6 hours"
        ],
        aggressive: [
            "❌ Building polished, production-ready UI",
            "❌ Implementing real-time updates and notifications",
            "❌ Creating complex user onboarding flows",
            "❌ Adding advanced data visualization"
        ],
        bottlenecks: [
            "Frontend-backend integration always takes longer than planned",
            "CSS styling can consume disproportionate time",
            "Cross-browser compatibility issues"
        ],
        outcome: "Functional web application with basic user interface"
    },
    {
        week: "Week 4: SBIR Preparation & Polish",
        hours: 40,
        realistic: [
            "✅ Create demo data and test scenarios - 8 hours",
            "✅ Record product demo video - 4 hours",
            "✅ Write SBIR technical sections - 12 hours",
            "✅ Create business plan and commercialization strategy - 8 hours", 
            "✅ Compile supporting documentation - 4 hours",
            "✅ Final proposal review and submission - 4 hours"
        ],
        aggressive: [
            "❌ Major feature additions or rewrites",
            "❌ Comprehensive user testing and feedback incorporation",
            "❌ Advanced security hardening",
            "❌ Scaling optimizations"
        ],
        bottlenecks: [
            "SBIR writing takes longer than technical development",
            "Demo preparation reveals gaps that need fixing",
            "Proposal requirements may demand additional features"
        ],
        outcome: "Submitted SBIR proposal with working MVP demonstration"
    }
];

const riskAssessment = {
    high: [
        {
            risk: "AI Code Quality Variability",
            probability: "80%",
            impact: "Can double development time",
            mitigation: "Allocate 25% extra time for debugging AI-generated code"
        },
        {
            risk: "Integration Complexity",
            probability: "70%",
            impact: "Frontend-backend integration issues",
            mitigation: "Start with API-first approach, build simple frontend"
        },
        {
            risk: "SBIR Writing Underestimated", 
            probability: "60%",
            impact: "Week 4 becomes 60+ hour week",
            mitigation: "Start SBIR outline in Week 2, write sections incrementally"
        }
    ],
    medium: [
        {
            risk: "AWS Service Limits/Issues",
            probability: "40%",
            impact: "1-2 day delays in deployment",
            mitigation: "Set up AWS account immediately, request limit increases"
        },
        {
            risk: "Scope Creep During Development",
            probability: "50%", 
            impact: "Distraction from core MVP features",
            mitigation: "Strict feature freeze - no additions during 4-week sprint"
        }
    ],
    low: [
        {
            risk: "Complete Technical Failure",
            probability: "15%",
            impact: "No working product",
            mitigation: "Start with simplest possible version, add complexity incrementally"
        }
    ]
};

const alternativeTimelines = [
    {
        option: "6-Week Realistic Sprint",
        timeline: "Add 2 buffer weeks",
        pros: ["More time for AI code refinement", "Better SBIR proposal quality", "Reduced stress and burnout risk"],
        cons: ["Still tight for SBIR deadline", "Less first-mover advantage"],
        recommendation: "Recommended if SBIR deadline can be met"
    },
    {
        option: "8-Week Hybrid Approach",
        timeline: "4 weeks MVP + 4 weeks refinement", 
        pros: ["MVP ready for early customers", "Time for user feedback", "Higher quality SBIR proposal"],
        cons: ["Misses optimal SBIR timing", "May lose market momentum"],
        recommendation: "Best balance of speed and quality"
    },
    {
        option: "4-Week Sprint with Backup Plan",
        timeline: "Attempt 4-week, fallback to 6-week",
        pros: ["Maintains aggressive goal", "Built-in contingency", "Learn from attempt"],
        cons: ["Planning complexity", "Potential for twice the stress"],
        recommendation: "High-risk, high-reward approach"
    }
];

export default function RealisticTimelineAssessment() {
    const [selectedWeek, setSelectedWeek] = useState(0);

    return (
        <div className="space-y-8">
            <BreadcrumbNav currentPageName="RealisticTimelineAssessment" />

            <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="text-center">
                <Badge className="mb-4 bg-yellow-100 text-yellow-800">REALITY CHECK</Badge>
                <h1 className="text-4xl font-bold text-gray-900 mb-4">🎯 TIMELINE REALITY CHECK</h1>
                <p className="text-xl text-gray-600 max-w-4xl mx-auto">
                    The honest assessment: what's actually achievable in 4 weeks as a solo founder + AI. 
                    Phase-by-phase roadmap with backup plans.
                </p>
            </motion.div>

            <Alert className="bg-gradient-to-r from-yellow-50 to-orange-50 border-2 border-orange-300">
                <AlertTriangle className="h-5 w-5 text-orange-600" />
                <AlertTitle className="text-orange-800 text-lg">The Brutal Truth</AlertTitle>
                <AlertDescription className="text-orange-700 mt-2">
                    <strong>4 weeks is aggressive but achievable IF:</strong> You focus exclusively on core functionality, accept "good enough" over "perfect," and have contingency plans for the 30% chance of needing extra time.
                    <br/><br/>
                    <strong>The real question:</strong> Is the market timing so critical that this risk is worth taking?
                </AlertDescription>
            </Alert>

            <Tabs defaultValue="weekly" className="w-full">
                <TabsList className="grid w-full grid-cols-4">
                    <TabsTrigger value="weekly">Weekly Breakdown</TabsTrigger>
                    <TabsTrigger value="risks">Risk Analysis</TabsTrigger>
                    <TabsTrigger value="alternatives">Alternative Timelines</TabsTrigger>
                    <TabsTrigger value="recommendations">Final Recommendations</TabsTrigger>
                </TabsList>

                <TabsContent value="weekly">
                    <div className="grid md:grid-cols-4 gap-4 mb-6">
                        {weekBreakdown.map((week, index) => (
                            <Button
                                key={index}
                                variant={selectedWeek === index ? "default" : "outline"}
                                onClick={() => setSelectedWeek(index)}
                                className="h-auto p-4 flex flex-col items-start"
                            >
                                <span className="font-semibold">Week {index + 1}</span>
                                <span className="text-xs">{week.hours} hours</span>
                            </Button>
                        ))}
                    </div>

                    <Card>
                        <CardHeader>
                            <CardTitle>{weekBreakdown[selectedWeek].week}</CardTitle>
                            <CardDescription>{weekBreakdown[selectedWeek].hours} hours allocated</CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-6">
                            <div>
                                <h4 className="font-semibold text-green-800 mb-3">✅ Realistic Achievements (40 hours)</h4>
                                <ul className="space-y-2 text-sm">
                                    {weekBreakdown[selectedWeek].realistic.map((item, i) => (
                                        <li key={i} className="text-green-700">{item}</li>
                                    ))}
                                </ul>
                            </div>

                            <div>
                                <h4 className="font-semibold text-red-800 mb-3">❌ Overly Aggressive (Would Add 20+ Hours)</h4>
                                <ul className="space-y-2 text-sm">
                                    {weekBreakdown[selectedWeek].aggressive.map((item, i) => (
                                        <li key={i} className="text-red-700">{item}</li>
                                    ))}
                                </ul>
                            </div>

                            <div>
                                <h4 className="font-semibold text-orange-800 mb-3">⚠️ Likely Bottlenecks</h4>
                                <ul className="space-y-2 text-sm">
                                    {weekBreakdown[selectedWeek].bottlenecks.map((item, i) => (
                                        <li key={i} className="text-orange-700">• {item}</li>
                                    ))}
                                </ul>
                            </div>

                            <div className="p-4 bg-blue-50 rounded-lg">
                                <h4 className="font-semibold text-blue-800 mb-2">Week {selectedWeek + 1} Outcome</h4>
                                <p className="text-sm text-blue-700">{weekBreakdown[selectedWeek].outcome}</p>
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="risks">
                    <div className="space-y-6">
                        <Card className="border-red-200 bg-red-50">
                            <CardHeader>
                                <CardTitle className="text-red-800">High-Probability Risks (60-80%)</CardTitle>
                                <CardDescription className="text-red-600">These will almost certainly happen - plan for them</CardDescription>
                            </CardHeader>
                            <CardContent>
                                {riskAssessment.high.map((risk, i) => (
                                    <div key={i} className="mb-4 p-3 bg-white rounded border">
                                        <div className="flex justify-between items-start mb-2">
                                            <h4 className="font-semibold text-red-800">{risk.risk}</h4>
                                            <Badge className="bg-red-100 text-red-800">{risk.probability}</Badge>
                                        </div>
                                        <p className="text-sm text-red-700 mb-2"><strong>Impact:</strong> {risk.impact}</p>
                                        <p className="text-sm text-green-700"><strong>Mitigation:</strong> {risk.mitigation}</p>
                                    </div>
                                ))}
                            </CardContent>
                        </Card>

                        <Card className="border-yellow-200 bg-yellow-50">
                            <CardHeader>
                                <CardTitle className="text-yellow-800">Medium-Probability Risks (40-50%)</CardTitle>
                                <CardDescription className="text-yellow-600">Likely enough to prepare contingencies</CardDescription>
                            </CardHeader>
                            <CardContent>
                                {riskAssessment.medium.map((risk, i) => (
                                    <div key={i} className="mb-4 p-3 bg-white rounded border">
                                        <div className="flex justify-between items-start mb-2">
                                            <h4 className="font-semibold text-yellow-800">{risk.risk}</h4>
                                            <Badge className="bg-yellow-100 text-yellow-800">{risk.probability}</Badge>
                                        </div>
                                        <p className="text-sm text-yellow-700 mb-2"><strong>Impact:</strong> {risk.impact}</p>
                                        <p className="text-sm text-green-700"><strong>Mitigation:</strong> {risk.mitigation}</p>
                                    </div>
                                ))}
                            </CardContent>
                        </Card>

                        <Card className="border-green-200 bg-green-50">
                            <CardHeader>
                                <CardTitle className="text-green-800">Low-Probability Risks (15-25%)</CardTitle>
                                <CardDescription className="text-green-600">Unlikely but worth noting</CardDescription>
                            </CardHeader>
                            <CardContent>
                                {riskAssessment.low.map((risk, i) => (
                                    <div key={i} className="mb-4 p-3 bg-white rounded border">
                                        <div className="flex justify-between items-start mb-2">
                                            <h4 className="font-semibold text-green-800">{risk.risk}</h4>
                                            <Badge className="bg-green-100 text-green-800">{risk.probability}</Badge>
                                        </div>
                                        <p className="text-sm text-green-700 mb-2"><strong>Impact:</strong> {risk.impact}</p>
                                        <p className="text-sm text-blue-700"><strong>Mitigation:</strong> {risk.mitigation}</p>
                                    </div>
                                ))}
                            </CardContent>
                        </Card>
                    </div>
                </TabsContent>

                <TabsContent value="alternatives">
                    <div className="grid gap-6">
                        {alternativeTimelines.map((option, i) => (
                            <Card key={i} className="relative">
                                <CardHeader>
                                    <div className="flex justify-between items-start">
                                        <div>
                                            <CardTitle>{option.option}</CardTitle>
                                            <CardDescription>{option.timeline}</CardDescription>
                                        </div>
                                        <Badge className={option.recommendation.includes('Recommended') ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}>
                                            {option.recommendation.includes('Recommended') ? 'RECOMMENDED' : 'ALTERNATIVE'}
                                        </Badge>
                                    </div>
                                </CardHeader>
                                <CardContent className="grid md:grid-cols-2 gap-4">
                                    <div>
                                        <h4 className="font-semibold text-green-700 mb-2">Pros</h4>
                                        <ul className="text-sm space-y-1">
                                            {option.pros.map((pro, j) => (
                                                <li key={j} className="text-green-600">+ {pro}</li>
                                            ))}
                                        </ul>
                                    </div>
                                    <div>
                                        <h4 className="font-semibold text-red-700 mb-2">Cons</h4>
                                        <ul className="text-sm space-y-1">
                                            {option.cons.map((con, j) => (
                                                <li key={j} className="text-red-600">- {con}</li>
                                            ))}
                                        </ul>
                                    </div>
                                    <div className="md:col-span-2 mt-2 p-2 bg-blue-50 rounded">
                                        <p className="text-sm text-blue-800"><strong>Bottom Line:</strong> {option.recommendation}</p>
                                    </div>
                                </CardContent>
                            </Card>
                        ))}
                    </div>
                </TabsContent>

                <TabsContent value="recommendations">
                    <div className="space-y-6">
                        <Alert className="bg-gradient-to-r from-blue-50 to-green-50 border-2 border-blue-300">
                            <Target className="h-5 w-5 text-blue-600" />
                            <AlertTitle className="text-blue-800 text-lg">Final Recommendation: The Honest 80/20 Sweat Equity Analysis</AlertTitle>
                            <AlertDescription className="text-blue-700 mt-2 space-y-2">
                                <div className="grid md:grid-cols-2 gap-4 mt-4">
                                    <div className="p-4 bg-white rounded border">
                                        <h4 className="font-semibold text-green-800 mb-2">✅ 4-Week Sprint IS Achievable If:</h4>
                                        <ul className="text-sm text-green-700 space-y-1">
                                            <li>• You work 50-60 hours/week (not 40)</li>
                                            <li>• You accept "demo-quality" over "production-ready"</li>
                                            <li>• You have 2-week buffer built into timeline</li>
                                            <li>• You focus ONLY on core AI functionality</li>
                                            <li>• You start SBIR writing in Week 2, not Week 4</li>
                                        </ul>
                                    </div>
                                    <div className="p-4 bg-white rounded border">
                                        <h4 className="font-semibold text-orange-800 mb-2">⚠️ Sweat Equity Reality Check:</h4>
                                        <ul className="text-sm text-orange-700 space-y-1">
                                            <li>• 240 hours (60hrs/week × 4 weeks)</li>
                                            <li>• $30,000 sweat equity @ $125/hr consultant rate</li>
                                            <li>• $175 cash + $30K sweat = $30,175 total investment</li>
                                            <li>• ROI potential: 833x return ($250K SBIR ÷ $30K)</li>
                                            <li>• Stress level: HIGH but manageable for 4 weeks</li>
                                        </ul>
                                    </div>
                                </div>
                            </AlertDescription>
                        </Alert>

                        <Card className="bg-gradient-to-r from-gray-900 to-blue-900 text-white">
                            <CardHeader>
                                <CardTitle className="text-2xl">The Make-or-Break Decision Framework</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                <div className="grid md:grid-cols-3 gap-4">
                                    <div className="p-4 bg-white/10 rounded">
                                        <h4 className="font-bold mb-2">Market Timing Assessment</h4>
                                        <p className="text-sm">DFARS enforcement Nov 10 = 31,500 SMBs need compliance. First-mover advantage worth the risk?</p>
                                        <p className="text-green-300 font-semibold mt-2">✅ YES - Timing is critical</p>
                                    </div>
                                    <div className="p-4 bg-white/10 rounded">
                                        <h4 className="font-bold mb-2">Personal Capacity</h4>
                                        <p className="text-sm">Can you sustain 60hr weeks for 4 weeks? Do you have fallback income if this fails?</p>
                                        <p className="text-yellow-300 font-semibold mt-2">⚠️ YOU DECIDE</p>
                                    </div>
                                    <div className="p-4 bg-white/10 rounded">
                                        <h4 className="font-bold mb-2">Technical Confidence</h4>
                                        <p className="text-sm">Have you built similar systems? Are you comfortable debugging AI-generated code?</p>
                                        <p className="text-blue-300 font-semibold mt-2">? ASSESS HONESTLY</p>
                                    </div>
                                </div>
                                
                                <Alert className="bg-white/20 border-white/30">
                                    <AlertTitle className="text-white">Actionable Decision Point</AlertTitle>
                                    <AlertDescription className="text-gray-100 mt-2">
                                        <strong>Go/No-Go Decision:</strong> If market timing + personal capacity + technical confidence = 3 YES answers, attempt the 4-week sprint with 6-week fallback plan.
                                        <br/><br/>
                                        <strong>If any answer is NO:</strong> Choose the 8-week hybrid approach - still aggressive but much more likely to succeed.
                                    </AlertDescription>
                                </Alert>
                            </CardContent>
                        </Card>

                        <div className="text-center">
                            <Button asChild size="lg" className="bg-green-600 hover:bg-green-700">
                                <Link to={createPageUrl('DailyAchievementSchedule')}>
                                    I'm Ready - Show Me The Daily Action Plan <ArrowRight className="w-5 h-5 ml-2" />
                                </Link>
                            </Button>
                        </div>
                    </div>
                </TabsContent>
            </Tabs>
        </div>
    );
}