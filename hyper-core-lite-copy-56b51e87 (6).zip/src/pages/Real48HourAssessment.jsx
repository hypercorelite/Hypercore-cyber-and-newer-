import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { CheckCircle, AlertTriangle, Clock, Target, Zap, Users, BarChart, FileText, Cloud, DollarSign, Trash2, Loader2, Shield } from 'lucide-react';
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { toast } from "sonner";
import { clearSampleData } from "@/api/functions";
import { clearSampleTrackingData } from "@/api/functions";

const actualStatus = {
    platformDevelopment: {
        achieved: [
            "✅ Fully functional AI-powered CMMC assessment engine",
            "✅ Complete SSP generation capability", 
            "✅ 14 CMMC policy document automation",
            "✅ Gap analysis and SPRS scoring system",
            "✅ LOI collection system with PDF generation",
            "✅ Real-time analytics dashboard", 
            "✅ Professional UI/UX with mobile responsiveness",
            "✅ Authentication and user management",
            "✅ Backend functions for all core operations",
            "✅ Clean, maintainable codebase"
        ],
        timeInvested: "48 hours of intensive AI-assisted development",
        technicalDebt: "Minimal - code is production-ready",
        scalabilityReady: "Yes - built on Base44 platform with auto-scaling"
    },
    
    realUserData: {
        actualUsers: 0,
        authenticLOIs: 0,
        platformInteractions: "Admin testing only",
        conversionFunnel: "Not yet initiated - no traffic",
        lastActivityReal: "Admin functions and system tests",
        marketValidation: "Technical capability proven, market validation pending"
    },
    
    sbirReadiness: {
        strengths: [
            "Working prototype eliminating technical risk",
            "Clear problem definition with quantified market need", 
            "Novel AI-first approach vs traditional consultants",
            "Scalable business model validated technically"
        ],
        gaps: [
            "Zero real user validation data",
            "No performance metrics vs traditional methods",
            "No customer testimonials or feedback",
            "No market penetration proof"
        ],
        timeline: "Need 60-90 days of real user validation for strong Phase I proposal",
        fundingReadiness: "60% ready - strong tech, need market proof"
    }
};

export default function Real48HourAssessment() {
    const [isPurging, setIsPurging] = useState(false);
    const [purgeComplete, setPurgeComplete] = useState(false);

    const handlePurgeData = async () => {
        setIsPurging(true);
        const purgeToast = toast.loading("🔥 EXECUTING CLEAN SLATE PROTOCOL... Purging all sample data...");

        try {
            const results = await Promise.allSettled([
                clearSampleData(),
                clearSampleTrackingData()
            ]);

            const loiResult = results[0];
            const trackingResult = results[1];

            let successMessages = [];
            let failureMessages = [];

            if (loiResult.status === 'fulfilled' && loiResult.value.data.success) {
                successMessages.push(`LOIs: ${loiResult.value.data.deletedCount} sample records purged.`);
            } else {
                failureMessages.push("Failed to purge sample LOIs.");
            }

            if (trackingResult.status === 'fulfilled' && trackingResult.value.data.success) {
                const { audit_logs, usage_metrics, ai_metrics } = trackingResult.value.data.cleared;
                successMessages.push(`Tracking: ${audit_logs} audit, ${usage_metrics} usage, ${ai_metrics} AI metrics purged.`);
            } else {
                failureMessages.push("Failed to purge sample tracking data.");
            }

            if (failureMessages.length > 0) {
                toast.error("Clean Slate Protocol encountered errors.", { 
                    id: purgeToast,
                    description: failureMessages.join(' ') 
                });
            } else {
                toast.success("✅ CLEAN SLATE PROTOCOL COMPLETE. All sample data has been purged.", {
                    id: purgeToast,
                    description: successMessages.join(' ')
                });
                setPurgeComplete(true);
            }

        } catch (error) {
            toast.error("A critical error occurred during the data purge.", { 
                id: purgeToast,
                description: error.message 
            });
        } finally {
            setIsPurging(false);
        }
    };

    return (
        <div className="space-y-8 p-4 md:p-6">
            <BreadcrumbNav currentPageName="Real48HourAssessment" />
            
            {/* Header */}
            <div className="text-center">
                <h1 className="text-4xl font-bold text-gray-900 mb-2">Real 48-Hour Assessment</h1>
                <p className="text-xl text-gray-600">Honest evaluation of progress, market position, and next steps</p>
            </div>

            {/* Clean Slate Protocol Card - PROMINENT */}
            <Card className="border-red-500 border-2 shadow-lg bg-red-50">
                <CardHeader>
                    <CardTitle className="text-red-700 flex items-center gap-3 text-2xl">
                        <Trash2 className="w-8 h-8" />
                        🔥 CLEAN SLATE PROTOCOL (EXECUTE NOW)
                    </CardTitle>
                    <CardDescription className="text-lg">
                        Your database currently contains sample data used for development. To ensure all analytics and evidence for SBIR are 100% authentic, you must purge this data immediately.
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <Alert className="mb-6 border-yellow-500 bg-yellow-50">
                        <AlertTriangle className="h-4 w-4 text-yellow-600" />
                        <AlertTitle className="text-yellow-800">Critical Action Required</AlertTitle>
                        <AlertDescription className="text-yellow-700">
                            Your Last 24 Hours dashboard is showing 11 fake LOIs from companies like "AeroDefense Solutions" and "Maritime Tech Inc." 
                            These must be purged before any SBIR submission or investor presentation.
                        </AlertDescription>
                    </Alert>

                    <div className="bg-white p-6 rounded-lg border-2 border-gray-200 mb-6">
                        <h4 className="font-bold text-lg mb-3">Sample Data to be Purged:</h4>
                        <ul className="list-disc list-inside space-y-2 text-sm text-gray-700 mb-6">
                            <li>11 fake Letters of Intent from sample companies</li>
                            <li>Artificial audit logs with fake user interactions</li>
                            <li>Sample usage metrics and AI performance data</li>
                            <li>Demo client onboarding records</li>
                        </ul>

                        <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                            <h5 className="font-semibold text-green-800 mb-2">After Purge, Your Analytics Will Show:</h5>
                            <ul className="list-disc list-inside space-y-1 text-sm text-green-700">
                                <li>0 real user LOIs (accurate)</li>
                                <li>0 real client onboardings (accurate)</li>
                                <li>Only admin system interactions (accurate)</li>
                                <li>Clean foundation for tracking real user growth</li>
                            </ul>
                        </div>
                    </div>

                    <div className="flex justify-center">
                        <Button 
                            onClick={handlePurgeData}
                            disabled={isPurging || purgeComplete}
                            className={`text-xl px-8 py-4 ${purgeComplete ? 'bg-green-600 hover:bg-green-700' : 'bg-red-600 hover:bg-red-700'}`}
                        >
                            {isPurging ? (
                                <>
                                    <Loader2 className="w-6 h-6 mr-3 animate-spin" />
                                    PURGING SAMPLE DATA...
                                </>
                            ) : purgeComplete ? (
                                <>
                                    <CheckCircle className="w-6 h-6 mr-3" />
                                    CLEAN SLATE ACHIEVED ✅
                                </>
                            ) : (
                                <>
                                    <Trash2 className="w-6 h-6 mr-3" />
                                    🔥 EXECUTE CLEAN SLATE PROTOCOL
                                </>
                            )}
                        </Button>
                    </div>

                    {purgeComplete && (
                        <Alert className="mt-6 border-green-500 bg-green-50">
                            <CheckCircle className="h-4 w-4 text-green-600" />
                            <AlertTitle className="text-green-800">Clean Slate Complete</AlertTitle>
                            <AlertDescription className="text-green-700">
                                All sample data has been purged. Your analytics now show only real interactions. 
                                You can now confidently begin your market validation phase.
                            </AlertDescription>
                        </Alert>
                    )}
                </CardContent>
            </Card>

            {/* 48-Hour Progress Summary */}
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                        <Clock className="w-6 h-6 text-blue-600" />
                        48-Hour Development Sprint: What Was Actually Achieved
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="grid md:grid-cols-2 gap-6">
                        <div>
                            <h4 className="font-bold text-lg mb-3 text-green-700">✅ Completed (Production Ready)</h4>
                            <ul className="space-y-2">
                                {actualStatus.platformDevelopment.achieved.map((item, i) => (
                                    <li key={i} className="text-sm flex items-center gap-2">
                                        <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0" />
                                        {item}
                                    </li>
                                ))}
                            </ul>
                        </div>
                        <div>
                            <h4 className="font-bold text-lg mb-3 text-red-700">🚫 Not Yet Started (Market Validation)</h4>
                            <ul className="space-y-2">
                                {actualStatus.sbirReadiness.gaps.map((item, i) => (
                                    <li key={i} className="text-sm flex items-center gap-2">
                                        <AlertTriangle className="w-4 h-4 text-red-600 flex-shrink-0" />
                                        {item}
                                    </li>
                                ))}
                            </ul>
                        </div>
                    </div>
                </CardContent>
            </Card>

            {/* Current Real Position */}
            <div className="grid md:grid-cols-3 gap-6">
                <Card>
                    <CardHeader>
                        <CardTitle className="text-lg flex items-center gap-2">
                            <Users className="w-5 h-5 text-blue-600" />
                            Real Users
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="text-3xl font-bold">{actualStatus.realUserData.actualUsers}</div>
                        <p className="text-sm text-gray-600">Authentic platform users</p>
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader>
                        <CardTitle className="text-lg flex items-center gap-2">
                            <FileText className="w-5 h-5 text-green-600" />
                            Authentic LOIs
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="text-3xl font-bold">{actualStatus.realUserData.authenticLOIs}</div>
                        <p className="text-sm text-gray-600">Real Letters of Intent</p>
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader>
                        <CardTitle className="text-lg flex items-center gap-2">
                            <Target className="w-5 h-5 text-orange-600" />
                            SBIR Readiness
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="text-3xl font-bold">50%</div>
                        <p className="text-sm text-gray-600">Tech done, need market proof</p>
                    </CardContent>
                </Card>
            </div>

            {/* Next 60 Days Action Plan */}
            <Card>
                <CardHeader>
                    <CardTitle>Next 60 Days: From 0 to SBIR Submission</CardTitle>
                    <CardDescription>Realistic timeline to achieve market validation and submit Phase I proposal</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="space-y-6">
                        <div className="border-l-4 border-red-500 pl-4 bg-red-50 p-4 rounded">
                            <h4 className="font-bold text-red-700">Days 1-30: Market Validation Sprint (CRITICAL)</h4>
                            <ul className="list-disc list-inside text-sm mt-2 space-y-1">
                                <li>Launch LinkedIn content campaign (5 posts/week)</li>
                                <li>Direct outreach to 50 SMB DoD contractors</li>
                                <li>Get 5-10 real users through the platform</li>
                                <li>Collect 2-3 authentic LOIs with feedback</li>
                            </ul>
                            <p className="text-sm text-red-600 mt-2 font-semibold">Success Metric: 3+ real LOIs, 10+ platform users</p>
                        </div>

                        <div className="border-l-4 border-yellow-500 pl-4 bg-yellow-50 p-4 rounded">
                            <h4 className="font-bold text-yellow-700">Days 31-45: Data Collection & Refinement</h4>
                            <ul className="list-disc list-inside text-sm mt-2 space-y-1">
                                <li>Analyze real user behavior and feedback</li>
                                <li>Refine platform based on actual user pain points</li>
                                <li>Document quantified value propositions with real data</li>
                                <li>Prepare SBIR Phase I technical approach</li>
                            </ul>
                            <p className="text-sm text-yellow-600 mt-2 font-semibold">Success Metric: User feedback incorporated, performance metrics documented</p>
                        </div>

                        <div className="border-l-4 border-green-500 pl-4 bg-green-50 p-4 rounded">
                            <h4 className="font-bold text-green-700">Days 46-60: SBIR Preparation & Submission</h4>
                            <ul className="list-disc list-inside text-sm mt-2 space-y-1">
                                <li>Complete Phase I proposal with real user validation data</li>
                                <li>Prepare technical demonstration materials</li>
                                <li>Document commercialization plan with actual user pipeline</li>
                                <li>Submit Phase I application</li>
                            </ul>
                            <p className="text-sm text-green-600 mt-2 font-semibold">Success Metric: Phase I submission completed with authentic market validation</p>
                        </div>
                    </div>
                </CardContent>
            </Card>

            {/* Action Buttons */}
            <div className="flex justify-center gap-4">
                <Button asChild variant="outline">
                    <Link to={createPageUrl('Last24HourAssessment')}>
                        View Analytics Dashboard
                    </Link>
                </Button>
                <Button asChild>
                    <Link to={createPageUrl('RevisedSBIRStrategy')}>
                        View 11-Week SBIR Plan
                    </Link>
                </Button>
            </div>
        </div>
    );
}