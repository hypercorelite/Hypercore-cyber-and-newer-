import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Shield, Target, Zap, Users, DollarSign, TrendingUp, Building, ArrowRight, Bot, CheckCircle } from 'lucide-react';
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";

const currentPosition = {
    assets: [
        { item: "Live Marketing Engine", status: "hypercorecyber.com generating leads", impact: "Market validation complete" },
        { item: "Complete Market Research", status: "Competitor analysis finished", impact: "Strategic advantage identified" },
        { item: "AI-First Architecture", status: "Technical foundation ready", impact: "Scalable model designed" },
        { item: "SBIR Pipeline", status: "Grant draft concurrent with MVP", impact: "Funding strategy aligned" }
    ],
    execution: [
        { task: "MVP Development Sprint", timeline: "8 weeks (Sep 15 - Nov 10)", priority: "CRITICAL" },
        { task: "SBIR Proposal Completion", timeline: "Concurrent with MVP", priority: "HIGH" },
        { task: "First Client Onboarding", timeline: "Nov 11 - Dec 1", priority: "HIGH" },
        { task: "Commercial Scale Preparation", timeline: "Post-SBIR Award", priority: "MEDIUM" }
    ]
};

const marketImpactAnalysis = [
    {
        segment: "Defense Industrial Base (DIB)",
        size: "31,500 SMB contractors",
        pain: "Facing $50K-$200K compliance costs + 6-18 month timelines",
        solution: "75-minute compliance process, $2.5K-$7.5K cost",
        impact: "$1.5B+ market disruption potential",
        timeline: "Immediate (Nov 10, 2025 DFARS deadline)",
        icon: Shield
    },
    {
        segment: "Supply Chain Security",
        size: "Thousands of prime contractors managing subcontractor compliance",
        pain: "Manual verification, inconsistent documentation, compliance delays",
        solution: "Standardized AI-generated compliance packages, consistent quality",
        impact: "Supply chain acceleration, reduced prime contractor risk",
        timeline: "Q1 2026 (post-DFARS enforcement)",
        icon: Building
    },
    {
        segment: "DOD Procurement Efficiency",
        size: "Entire federal acquisition system",
        pain: "Delayed contracts due to subcontractor non-compliance",
        solution: "Predictable 8-week compliance timeline enables faster procurement",
        impact: "National security benefit through accelerated acquisition",
        timeline: "Long-term strategic advantage",
        icon: Target
    },
    {
        segment: "Solopreneur + AI Model",
        size: "Personal competitive advantage",
        pain: "Traditional consulting doesn't scale, GRC tools require large teams",
        solution: "AI workforce enables one person to serve thousands",
        impact: "Category-creating business model with massive scalability",
        timeline: "Immediate execution advantage",
        icon: Bot
    }
];

const scalabilityModel = {
    mvp: {
        capacity: "10-50 clients",
        model: "Founder + AI tools",
        revenue: "$25K - $375K",
        timeline: "Nov 2025 - Jun 2026"
    },
    postSBIR: {
        capacity: "500-1,000 clients", 
        model: "AI-first platform + expert escalation team",
        revenue: "$6.25M - $12.5M",
        timeline: "Jul 2026 - Dec 2027"
    },
    commercial: {
        capacity: "10,000+ clients",
        model: "Fully automated AI platform + subscription tiers",
        revenue: "$125M+ annually",
        timeline: "2028+"
    }
};

export default function StrategicMarketAssessment() {
    return (
        <div className="space-y-8">
            <BreadcrumbNav currentPageName="StrategicMarketAssessment" />

            <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="text-center">
                <Badge className="mb-4 bg-purple-100 text-purple-800">STRATEGIC ASSESSMENT</Badge>
                <h1 className="text-4xl font-bold text-gray-900 mb-4">
                    Market Impact Analysis: AI-First CMMC Model
                </h1>
                <p className="text-xl text-gray-600 max-w-4xl mx-auto">
                    Comprehensive assessment of market position, execution requirements, and ecosystem impact for the AI-first compliance model.
                </p>
            </motion.div>

            {/* Current Position Assessment */}
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                        <CheckCircle className="w-6 h-6 text-green-600" />
                        Current Strategic Position
                    </CardTitle>
                    <CardDescription>Assets in place and execution requirements for MVP launch</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    <div>
                        <h4 className="font-semibold text-green-800 mb-3">✅ Assets Already in Place</h4>
                        <div className="grid md:grid-cols-2 gap-4">
                            {currentPosition.assets.map((asset, index) => (
                                <div key={index} className="p-3 bg-green-50 rounded-lg border border-green-200">
                                    <h5 className="font-semibold text-green-800">{asset.item}</h5>
                                    <p className="text-sm text-green-700">{asset.status}</p>
                                    <p className="text-xs text-green-600 mt-1"><strong>Impact:</strong> {asset.impact}</p>
                                </div>
                            ))}
                        </div>
                    </div>
                    
                    <div>
                        <h4 className="font-semibold text-blue-800 mb-3">🎯 Execution Requirements</h4>
                        <div className="space-y-3">
                            {currentPosition.execution.map((task, index) => (
                                <div key={index} className="flex items-center justify-between p-3 bg-blue-50 rounded-lg border border-blue-200">
                                    <div>
                                        <h5 className="font-semibold text-blue-800">{task.task}</h5>
                                        <p className="text-sm text-blue-700">{task.timeline}</p>
                                    </div>
                                    <Badge className={task.priority === 'CRITICAL' ? 'bg-red-100 text-red-800' : task.priority === 'HIGH' ? 'bg-orange-100 text-orange-800' : 'bg-gray-100 text-gray-800'}>
                                        {task.priority}
                                    </Badge>
                                </div>
                            ))}
                        </div>
                    </div>
                </CardContent>
            </Card>

            {/* Market Impact Analysis */}
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                        <TrendingUp className="w-6 h-6 text-blue-600" />
                        Market Impact Analysis
                    </CardTitle>
                    <CardDescription>How the AI-first model disrupts each segment of the defense ecosystem</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="grid gap-6">
                        {marketImpactAnalysis.map((segment, index) => (
                            <motion.div 
                                key={index}
                                initial={{ opacity: 0, y: 20 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: index * 0.1 }}
                                className="p-6 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg border border-blue-200"
                            >
                                <div className="flex items-start gap-4">
                                    <segment.icon className="w-8 h-8 text-blue-600 mt-1" />
                                    <div className="flex-grow">
                                        <h4 className="text-xl font-bold text-blue-900 mb-2">{segment.segment}</h4>
                                        <div className="grid md:grid-cols-2 gap-4 text-sm">
                                            <div>
                                                <p className="text-blue-800"><strong>Market Size:</strong> {segment.size}</p>
                                                <p className="text-blue-800"><strong>Current Pain:</strong> {segment.pain}</p>
                                            </div>
                                            <div>
                                                <p className="text-green-800"><strong>AI Solution:</strong> {segment.solution}</p>
                                                <p className="text-purple-800"><strong>Market Impact:</strong> {segment.impact}</p>
                                            </div>
                                        </div>
                                        <Badge className="mt-2 bg-orange-100 text-orange-800">Timeline: {segment.timeline}</Badge>
                                    </div>
                                </div>
                            </motion.div>
                        ))}
                    </div>
                </CardContent>
            </Card>

            {/* Scalability Model */}
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                        <Zap className="w-6 h-6 text-purple-600" />
                        AI-First Scalability Model
                    </CardTitle>
                    <CardDescription>How the solopreneur + AI model scales from MVP to market dominance</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="grid md:grid-cols-3 gap-6">
                        <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                            <h4 className="font-bold text-blue-800 mb-3">MVP Phase</h4>
                            <div className="space-y-2 text-sm">
                                <p><strong>Capacity:</strong> {scalabilityModel.mvp.capacity}</p>
                                <p><strong>Model:</strong> {scalabilityModel.mvp.model}</p>
                                <p><strong>Revenue:</strong> {scalabilityModel.mvp.revenue}</p>
                                <p><strong>Timeline:</strong> {scalabilityModel.mvp.timeline}</p>
                            </div>
                        </div>
                        <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                            <h4 className="font-bold text-green-800 mb-3">Post-SBIR</h4>
                            <div className="space-y-2 text-sm">
                                <p><strong>Capacity:</strong> {scalabilityModel.postSBIR.capacity}</p>
                                <p><strong>Model:</strong> {scalabilityModel.postSBIR.model}</p>
                                <p><strong>Revenue:</strong> {scalabilityModel.postSBIR.revenue}</p>
                                <p><strong>Timeline:</strong> {scalabilityModel.postSBIR.timeline}</p>
                            </div>
                        </div>
                        <div className="p-4 bg-purple-50 rounded-lg border border-purple-200">
                            <h4 className="font-bold text-purple-800 mb-3">Commercial Scale</h4>
                            <div className="space-y-2 text-sm">
                                <p><strong>Capacity:</strong> {scalabilityModel.commercial.capacity}</p>
                                <p><strong>Model:</strong> {scalabilityModel.commercial.model}</p>
                                <p><strong>Revenue:</strong> {scalabilityModel.commercial.revenue}</p>
                                <p><strong>Timeline:</strong> {scalabilityModel.commercial.timeline}</p>
                            </div>
                        </div>
                    </div>
                </CardContent>
            </Card>

            {/* Strategic Advantage Summary */}
            <Alert className="bg-gradient-to-r from-green-500 to-blue-600 text-white border-0">
                <Target className="h-5 w-5 text-white" />
                <AlertTitle className="text-2xl font-bold text-white">Strategic Advantage: Category Creation</AlertTitle>
                <AlertDescription className="text-lg text-white mt-2">
                    You are not competing in an existing market—you are creating a new category. The AI-first, human-in-the-loop model delivers:
                    <ul className="list-disc list-inside mt-2 space-y-1">
                        <li><strong>Scalability:</strong> Serve thousands without hiring consultants</li>
                        <li><strong>Market Timing:</strong> Perfect alignment with DFARS enforcement</li>
                        <li><strong>Competitive Moat:</strong> Neither consultants nor GRC tools can match this model</li>
                        <li><strong>National Impact:</strong> Accelerate defense supply chain compliance</li>
                    </ul>
                </AlertDescription>
            </Alert>

            <div className="text-center">
                <Button asChild size="lg" className="bg-purple-600 hover:bg-purple-700">
                    <Link to={createPageUrl('DailyAchievementSchedule')}>
                        Execute the Plan: Daily Achievement Schedule <ArrowRight className="w-5 h-5 ml-2" />
                    </Link>
                </Button>
            </div>
        </div>
    );
}