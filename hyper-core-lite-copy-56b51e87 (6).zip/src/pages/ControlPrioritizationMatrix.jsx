import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Target, Shield, AlertTriangle } from 'lucide-react';
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";

const controls = [
    { name: 'AC.L2-3.1.3 (CUI Flow)', impact: 'High', effort: 'High', quadrant: 'Strategic' },
    { name: 'AU.L2-3.3.1 (Auditing)', impact: 'High', effort: 'Medium', quadrant: 'Quick Wins' },
    { name: 'PE.L2-3.10.3 (Physical Access)', impact: 'Low', effort: 'Low', quadrant: 'Fill-ins' },
    { name: 'SC.L2-3.13.6 (Network Segmentation)', impact: 'Medium', effort: 'High', quadrant: 'Major Projects' },
    { name: 'RA.L2-3.11.2 (Vulnerability Scanning)', impact: 'High', effort: 'Low', quadrant: 'Quick Wins' },
];

const quadrantConfig = {
    'Quick Wins': 'bg-green-100 text-green-800',
    'Strategic': 'bg-blue-100 text-blue-800',
    'Major Projects': 'bg-orange-100 text-orange-800',
    'Fill-ins': 'bg-gray-100 text-gray-800',
};

export default function ControlPrioritizationMatrix() {
    return (
        <div className="space-y-6">
            <BreadcrumbNav currentPageName="ControlPrioritizationMatrix" />
            <div className="text-center">
                <h1 className="text-3xl font-bold">Control Prioritization Matrix</h1>
                <p className="text-lg text-gray-600">Focus your resources on what matters most using an impact vs. effort analysis.</p>
            </div>
            
            <Card>
                <CardHeader>
                    <CardTitle>Compliance Prioritization</CardTitle>
                    <CardDescription>This matrix helps you identify quick wins and plan for major projects, ensuring efficient use of time and budget.</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                        {Object.keys(quadrantConfig).map(quadrant => (
                            <div key={quadrant} className={`p-4 rounded-lg ${quadrantConfig[quadrant]}`}>
                                <h3 className="font-bold text-lg mb-4">{quadrant}</h3>
                                <div className="space-y-3">
                                    {controls.filter(c => c.quadrant === quadrant).map(c => (
                                        <div key={c.name} className="p-3 bg-white rounded-md shadow-sm">
                                            <p className="font-semibold text-sm">{c.name}</p>
                                            <div className="flex justify-between text-xs mt-1">
                                                <span>Impact: <Badge variant="secondary" className="px-1 py-0">{c.impact}</Badge></span>
                                                <span>Effort: <Badge variant="secondary" className="px-1 py-0">{c.effort}</Badge></span>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}