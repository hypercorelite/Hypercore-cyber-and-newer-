import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Loader2, CheckCircle, XCircle, TestTube, Bot, FileText, MessageSquare } from 'lucide-react';
import { toast } from "sonner";
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";

// Import all functions to be tested
import { performAIGapAnalysis } from "@/api/functions";
import { analyzeCMMCDocument } from "@/api/functions";
import { enhancedHyperCoreChatbot } from "@/api/functions";
import { queryHuggingFaceModel } from "@/api/functions";

const TestResultDisplay = ({ result }) => {
    if (!result) return null;
    const isSuccess = result.success;

    return (
        <Alert className={`mt-4 ${isSuccess ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'}`}>
            {isSuccess ? <CheckCircle className="h-5 w-5 text-green-600" /> : <XCircle className="h-5 w-5 text-red-600" />}
            <AlertTitle className={isSuccess ? 'text-green-800' : 'text-red-800'}>
                {isSuccess ? 'Test Passed' : 'Test Failed'}
            </AlertTitle>
            <AlertDescription>
                <pre className="text-xs whitespace-pre-wrap break-all bg-white p-2 rounded-md mt-2 max-h-64 overflow-y-auto">
                    {JSON.stringify(result.data, null, 2)}
                </pre>
            </AlertDescription>
        </Alert>
    );
};

export default function ComprehensiveSystemTest() {
    const [loading, setLoading] = useState({});
    const [results, setResults] = useState({});
    const [chatHistory, setChatHistory] = useState([]);
    const [chatInput, setChatInput] = useState("");

    const runTest = async (testName, testFunction) => {
        setLoading(prev => ({ ...prev, [testName]: true }));
        setResults(prev => ({ ...prev, [testName]: null }));
        toast.info(`Running test: ${testName}...`);
        try {
            const { data, error } = await testFunction();
            if (error) throw new Error(error.message || JSON.stringify(error));
            setResults(prev => ({ ...prev, [testName]: { success: true, data } }));
            toast.success(`✅ Test Passed: ${testName}`);
        } catch (err) {
            setResults(prev => ({ ...prev, [testName]: { success: false, data: { error: err.message } } }));
            toast.error(`❌ Test Failed: ${testName}`);
        } finally {
            setLoading(prev => ({ ...prev, [testName]: false }));
        }
    };

    const testGapAnalysis = () => runTest('Gap Analysis', () => performAIGapAnalysis({
        assessmentAnswers: {
            "Access Control": "We use passwords, but no formal MFA policy.",
            "Incident Response": "We have a basic plan to call our IT guy.",
            "Configuration Management": "Servers are set up manually when needed."
        }
    }));

    const testDocumentAnalysis = () => runTest('Document Analysis', () => analyzeCMMCDocument({
        // Simulate file upload with a publicly accessible URL of a simple text file
        fileUrl: "https://raw.githubusercontent.com/nist-non-gov/oscal-content/main/nist.gov/SP800-53/rev5/xml/NIST_SP-800-53_rev5_catalog.xml"
    }));
    
    const testCoreModelQuery = () => runTest('Core Model Query', () => queryHuggingFaceModel({
        instruction: "Assess this configuration for NIST 800-171 3.1.2 compliance.",
        context: "The system requires multi-factor authentication for all users and locks accounts after 5 failed login attempts for 15 minutes.",
        modelType: "cmmc_specialist"
    }));

    const handleChatSubmit = async (e) => {
        e.preventDefault();
        if (!chatInput.trim()) return;

        const userMessage = { role: 'user', content: chatInput };
        setChatHistory(prev => [...prev, userMessage]);
        setLoading(prev => ({ ...prev, chat: true }));
        
        try {
            const { data, error } = await enhancedHyperCoreChatbot({
                message: chatInput,
                conversationHistory: chatHistory
            });

            if(error) throw new Error(error.message || "Chatbot returned an error");
            
            const botMessage = { role: 'assistant', content: data.response };
            setChatHistory(prev => [...prev, userMessage, botMessage]);

        } catch (err) {
            const errorMessage = { role: 'assistant', content: `Error: ${err.message}` };
            setChatHistory(prev => [...prev, userMessage, errorMessage]);
            toast.error("Chatbot test failed.");
        } finally {
            setLoading(prev => ({...prev, chat: false}));
            setChatInput("");
        }
    };

    return (
        <div className="space-y-8">
            <BreadcrumbNav currentPageName="ComprehensiveSystemTest" />
            <CardHeader className="text-center px-0">
                <TestTube className="w-12 h-12 mx-auto text-blue-600" />
                <CardTitle className="text-3xl font-bold mt-4">AI Core System Test Dashboard</CardTitle>
                <CardDescription className="text-lg text-gray-600">
                    Verify all critical AI functions here before pushing to GitHub.
                </CardDescription>
            </CardHeader>

            <div className="grid md:grid-cols-2 gap-8">
                {/* Test 1: Gap Analysis */}
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <FileText className="w-5 h-5 text-purple-600" /> Gap Analysis Pipeline
                        </CardTitle>
                        <CardDescription>Tests the `performAIGapAnalysis` function with mock assessment data.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <Button onClick={testGapAnalysis} disabled={loading['Gap Analysis']} className="w-full">
                            {loading['Gap Analysis'] ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : 'Run Test'}
                        </Button>
                        <TestResultDisplay result={results['Gap Analysis']} />
                    </CardContent>
                </Card>

                {/* Test 2: Document Analysis */}
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <FileText className="w-5 h-5 text-green-600" /> Document Analysis Pipeline
                        </CardTitle>
                        <CardDescription>Tests `analyzeCMMCDocument` with a sample public document.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <Button onClick={testDocumentAnalysis} disabled={loading['Document Analysis']} className="w-full">
                            {loading['Document Analysis'] ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : 'Run Test'}
                        </Button>
                        <TestResultDisplay result={results['Document Analysis']} />
                    </CardContent>
                </Card>
                
                {/* Test 3: Core Model Query */}
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <Bot className="w-5 h-5 text-blue-600" /> Core Model Query
                        </CardTitle>
                        <CardDescription>Tests the base `queryHuggingFaceModel` function directly.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <Button onClick={testCoreModelQuery} disabled={loading['Core Model Query']} className="w-full">
                            {loading['Core Model Query'] ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : 'Run Test'}
                        </Button>
                        <TestResultDisplay result={results['Core Model Query']} />
                    </CardContent>
                </Card>

                {/* Test 4: Chatbot */}
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <MessageSquare className="w-5 h-5 text-orange-600" /> Enhanced Chatbot
                        </CardTitle>
                        <CardDescription>Tests the `enhancedHyperCoreChatbot` conversational flow.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-3 p-3 border rounded-md bg-gray-50 h-48 overflow-y-auto mb-4">
                            {chatHistory.length === 0 && <p className="text-sm text-center text-gray-500">Chat history will appear here.</p>}
                            {chatHistory.map((msg, index) => (
                                <div key={index} className={`text-sm ${msg.role === 'user' ? 'text-right' : 'text-left'}`}>
                                    <span className={`p-2 rounded-lg inline-block ${msg.role === 'user' ? 'bg-blue-100' : 'bg-gray-200'}`}>{msg.content}</span>
                                </div>
                            ))}
                        </div>
                        <form onSubmit={handleChatSubmit} className="flex gap-2">
                            <Input 
                                value={chatInput}
                                onChange={(e) => setChatInput(e.target.value)}
                                placeholder="Ask a CMMC question..."
                                disabled={loading.chat}
                            />
                            <Button type="submit" disabled={loading.chat}>
                                {loading.chat ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Send'}
                            </Button>
                        </form>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}