import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { CheckCircle, Bot, Zap, Target, ArrowRight, Shield, DollarSign } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const keyAdvantages = [
    {
        title: "AI-Powered Expertise Without Human Overhead",
        description: "Traditional consultants charge $300-500/hour. Our AI provides 24/7 CMMC expertise without the human cost structure.",
        icon: Bot
    },
    {
        title: "No Dependency on Expert Availability",
        description: "Human experts are scarce and expensive. Our platform scales infinitely without bottlenecks.",
        icon: Zap
    },
    {
        title: "Consistent Quality Every Time",
        description: "Human consultants vary in quality. Our AI delivers consistent, comprehensive CMMC guidance for every client.",
        icon: Target
    }
];

export default function DeploymentActionPlan() {
    return (
        <div className="space-y-8">
            <Card>
                <CardHeader>
                    <CardTitle className="text-3xl font-bold">AI-First Market Disruption Strategy</CardTitle>
                    <CardDescription>How we replace expensive human expertise with scalable AI intelligence.</CardDescription>
                </CardHeader>
            </Card>

            <Alert className="bg-green-50 border-green-200">
                <CheckCircle className="h-4 w-4 text-green-600" />
                <AlertTitle className="text-green-800">Strategic Advantage: No Human Expert Dependencies</AlertTitle>
                <AlertDescription className="text-green-700">
                    Unlike traditional consulting firms, we don't need to find, hire, or retain expensive CMMC experts. Our AI-powered platform provides the expertise, making us infinitely scalable and cost-efficient.
                </AlertDescription>
            </Alert>

            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-3"><Bot className="w-6 h-6 text-blue-600" /> The AI-First Competitive Advantage</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="grid md:grid-cols-1 gap-6">
                        {keyAdvantages.map((advantage, index) => (
                            <div key={index} className="flex items-start gap-4 p-4 border rounded-lg">
                                <advantage.icon className="w-8 h-8 text-blue-600 mt-1" />
                                <div>
                                    <h3 className="font-semibold text-lg mb-2">{advantage.title}</h3>
                                    <p className="text-gray-600">{advantage.description}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-3"><Target className="w-6 h-6 text-green-600" /> Implementation Timeline</CardTitle>
                    <CardDescription>Your path to market without dependency on expert partnerships.</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="space-y-6">
                        <div className="flex items-start gap-4">
                            <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center font-semibold text-blue-600">1</div>
                            <div>
                                <h4 className="font-semibold">Refine AI-Powered Documentation Generation</h4>
                                <p className="text-sm text-gray-600">Perfect the AI systems that generate all 14 CMMC policy documents instantly.</p>
                            </div>
                        </div>
                        <div className="flex items-start gap-4">
                            <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center font-semibold text-blue-600">2</div>
                            <div>
                                <h4 className="font-semibold">Build AI-Assisted Evidence Collection Workflows</h4>
                                <p className="text-sm text-gray-600">Create intelligent systems that guide clients through evidence gathering without human oversight.</p>
                            </div>
                        </div>
                        <div className="flex items-start gap-4">
                            <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center font-semibold text-blue-600">3</div>
                            <div>
                                <h4 className="font-semibold">Launch Partnership Outreach</h4>
                                <p className="text-sm text-gray-600">Begin outreach to defense contractors, emphasizing the AI-first advantage and fixed-fee model.</p>
                            </div>
                        </div>
                        <div className="flex items-start gap-4">
                            <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center font-semibold text-blue-600">4</div>
                            <div>
                                <h4 className="font-semibold">Iterate Based on Client Feedback</h4>
                                <p className="text-sm text-gray-600">Use real client engagements to refine AI algorithms and improve service delivery.</p>
                            </div>
                        </div>
                    </div>
                </CardContent>
            </Card>

            <Alert className="bg-blue-50 border-blue-200">
                <Bot className="h-4 w-4 text-blue-600" />
                <AlertTitle className="text-blue-800">Market Disruption Thesis</AlertTitle>
                <AlertDescription className="text-blue-700">
                    The CMMC consulting market is built on expensive human expertise. By replacing that expertise with AI, we can deliver the same outcomes at a fraction of the cost while scaling infinitely. This is true market disruption.
                </AlertDescription>
            </Alert>

            <div className="grid md:grid-cols-2 gap-6">
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2"><Shield className="w-5 h-5" />Competitive Strategy</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <Button asChild className="w-full">
                            <Link to={createPageUrl('CompetitiveAdvantage')}>
                                View Market Analysis <ArrowRight className="w-4 h-4 ml-2" />
                            </Link>
                        </Button>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2"><DollarSign className="w-5 h-5" />Cost Advantage</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <Button asChild className="w-full">
                            <Link to={createPageUrl('MarketEntryCost')}>
                                View Cost Analysis <ArrowRight className="w-4 h-4 ml-2" />
                            </Link>
                        </Button>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}