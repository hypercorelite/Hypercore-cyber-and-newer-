import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { ArrowRight, BookOpen, FileText, Gavel, ShieldAlert, Zap } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import SEONarrativeHighlight from '../components/competitive/SEONarrativeHighlight';

const researchArticles = [
    {
        title: "DoD's 44 FAQs Reveal CMMC's Hidden Complexity",
        description: "An analysis of the DoD's own questions, proving why manual compliance processes are guaranteed to fail under the weight of regulatory complexity.",
        slug: "dod-44-cmmc-faqs-reveal-hidden-complexity-manual-compliance-fails",
        icon: FileText
    },
    {
        title: "Pentagon Memo Confirms CMMC Waivers Are an Illusion",
        description: "A deep dive into the internal DoD memo that eliminates the 'waiver' hope and makes compliance a non-negotiable, immediate requirement.",
        slug: "pentagon-memo-cmmc-waivers-illusion-compliance-non-negotiable",
        icon: Gavel
    },
    {
        title: "CMMC is Law: Prime Contractors Won't Wait For You",
        description: "Industry experts confirm primes are already demanding compliance. We analyze why this makes your compliance timeline today, not November.",
        slug: "cmmc-is-law-prime-contractors-wont-wait",
        icon: ShieldAlert
    }
];

export default function Resources() {
    return (
        <div className="bg-gray-50 py-12 md:py-20">
            <div className="container mx-auto px-4 max-w-6xl">
                <div className="text-center mb-12">
                    <BookOpen className="mx-auto h-12 w-12 text-blue-600 mb-4" />
                    <h1 className="text-4xl md:text-5xl font-extrabold text-gray-900 mb-4">
                        CMMC Resource Center
                    </h1>
                    <p className="text-xl text-gray-600">
                        Turnkey solutions and expert analysis to solve your CMMC challenges.
                    </p>
                </div>

                <div className="mb-16">
                    <SEONarrativeHighlight />
                </div>

                <Card className="mb-16">
                    <CardHeader>
                        <CardTitle className="text-2xl">From Our Research Desk: Key Intelligence Briefings</CardTitle>
                        <CardDescription>
                           Our analysis of official DoD documents and industry reports proves the urgency and why automation is the only viable path forward.
                        </CardDescription>
                    </CardHeader>
                    <CardContent className="grid md:grid-cols-1 lg:grid-cols-3 gap-6">
                        {researchArticles.map((article, index) => (
                            <Card key={index} className="flex flex-col">
                                <CardHeader>
                                    <div className="flex justify-center mb-4">
                                        <div className="bg-blue-100 text-blue-600 rounded-lg w-12 h-12 flex items-center justify-center">
                                            <article.icon className="w-6 h-6" />
                                        </div>
                                    </div>
                                    <CardTitle>{article.title}</CardTitle>
                                </CardHeader>
                                <CardContent className="flex-grow">
                                    <p className="text-sm text-gray-600">{article.description}</p>
                                </CardContent>
                                <div className="p-6 pt-0">
                                    <Button asChild className="w-full">
                                        <Link to={createPageUrl(`BlogPost?slug=${article.slug}`)}>
                                            Read Full Analysis <ArrowRight className="w-4 h-4 ml-2" />
                                        </Link>
                                    </Button>
                                </div>
                            </Card>
                        ))}
                    </CardContent>
                </Card>
                 <div className="text-center">
                    <Button asChild size="lg" variant="outline">
                        <Link to={createPageUrl('KnowledgeHub')}>
                            Explore All Articles in the Knowledge Hub <ArrowRight className="w-4 h-4 ml-2" />
                        </Link>
                    </Button>
                </div>
            </div>
        </div>
    );
}