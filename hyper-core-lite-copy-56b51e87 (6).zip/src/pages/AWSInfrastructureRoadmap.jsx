import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { DollarSign, Cloud, Database, Shield, Code, Clock, CheckCircle } from 'lucide-react';
import { motion } from "framer-motion";

export default function AWSInfrastructureRoadmap() {
    const budgetBreakdown = [
        { service: "Route 53 (DNS)", cost: "$0.50/month", note: "For your domain name." },
        { service: "CloudFront (CDN)", cost: "~$1-2/month", note: "Depends on traffic, low initially." },
        { service: "S3 (Storage)", cost: "~$0.50/month", note: "Very cheap for storing initial assets." },
        { service: "Data Transfer", cost: "~$1-2/month", note: "Minimal initial data out." },
    ];

    const freeTierServices = [
        { service: "AWS Lambda", tier: "1M requests/month", use: "Runs all backend code without a server." },
        { service: "Amazon RDS (PostgreSQL)", tier: "750 hours/month for 12 months", use: "Your primary database for clients and projects." },
        { service: "Amazon S3", tier: "5GB standard storage", use: "Stores user files, document templates." },
        { service: "Amazon SES", tier: "62,000 emails/month", use: "Sends all transactional emails." },
        { service: "API Gateway", tier: "1M API calls/month", use: "Connects your app to Lambda functions." },
        { service: "IAM", tier: "Always Free", use: "Manages all security credentials and access." },
        { service: "CloudWatch", tier: "1M API requests, 5GB logs", use: "Monitors and logs all system activity." },
    ];

    const weeklyPhases = [
        {
            title: "Phase 1: Foundational Setup (Weeks 1-4)",
            description: "Establish the core, non-negotiable services. This is the bedrock of your infrastructure.",
            tasks: [
                "Configure IAM roles for secure, programmatic access.",
                "Set up S3 buckets for static assets and future document storage.",
                "Verify domain in SES to enable email sending from your app.",
                "Deploy a simple 'hello world' Lambda function via API Gateway to test the end-to-end serverless connection."
            ],
            cost_impact: "~$1/month (Route 53, S3 basics)"
        },
        {
            title: "Phase 2: Core Application & Data Layer (Weeks 5-10)",
            description: "Build the logic to manage clients, projects, and documents, using the 12-month free RDS instance.",
            tasks: [
                "Launch a PostgreSQL instance on Amazon RDS Free Tier.",
                "Develop Lambda functions for client/project CRUD operations.",
                "Create logic for storing and retrieving document templates from S3.",
                "Implement the secure invoice generation logic with bank details."
            ],
            cost_impact: "No change. Still within the ~$5 budget on free tiers."
        },
        {
            title: "Phase 3: AI & Workflow Integration (Weeks 11-16)",
            description: "Connect to third-party AI services and start automating the core value proposition.",
            tasks: [
                "Create Lambda functions to call OpenAI or other LLM APIs for document generation.",
                "Build the logic to assemble SSP & POA&M templates based on user inputs.",
                "Develop the client progress tracking system within your RDS database.",
                "Integrate with free-tier tools like Calendly or Airtable via API calls from Lambda."
            ],
            cost_impact: "No change. API calls are pay-per-use and will be funded by initial revenue."
        },
        {
            title: "Phase 4: Hardening & CMMC Readiness (Weeks 17-18)",
            description: "Prepare the architecture for a smooth transition to a fully compliant environment post-funding.",
            tasks: [
                "Implement comprehensive logging with CloudWatch for all services.",
                "Configure strict security groups and network ACLs for your RDS instance.",
                "Create detailed architectural diagrams and documentation for the future GovCloud migration.",
                "Perform load testing on Lambda functions to forecast costs at scale."
            ],
            cost_impact: "No change. All hardening uses built-in, free features."
        }
    ];

    return (
        <div className="space-y-8">
            <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center"
            >
                <h1 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-3">18-Week AWS Backend Roadmap</h1>
                <p className="text-lg lg:text-xl text-gray-600 max-w-3xl mx-auto">
                    A zero-cost bootstrap plan to build a CMMC-ready backend on a ~$5/month budget.
                </p>
            </motion.div>

            <Alert className="bg-blue-50 border-blue-200">
                <Cloud className="h-4 w-4 text-blue-600" />
                <AlertTitle className="text-blue-800">Core Principle: Serverless & CMMC-Ready</AlertTitle>
                <AlertDescription className="text-blue-700">
                    This entire plan uses AWS serverless technologies to keep costs near zero. Every service chosen has a direct equivalent in AWS GovCloud, ensuring a straightforward migration path for full CMMC compliance after you secure funding.
                </AlertDescription>
            </Alert>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2"><DollarSign className="w-5 h-5 text-green-600"/>Your ~$5/Month Budget</CardTitle>
                        <CardDescription>What you are actually paying for.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-2">
                        {budgetBreakdown.map(item => (
                            <div key={item.service} className="flex justify-between items-center text-sm p-2 bg-gray-50 rounded-md">
                                <div>
                                    <span className="font-medium">{item.service}</span>
                                    <p className="text-xs text-gray-500">{item.note}</p>
                                </div>
                                <Badge variant="secondary">{item.cost}</Badge>
                            </div>
                        ))}
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2"><CheckCircle className="w-5 h-5 text-blue-600"/>Leveraging the AWS Free Tier</CardTitle>
                        <CardDescription>How you build for free for the first 12 months.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-2 max-h-60 overflow-y-auto">
                        {freeTierServices.map(item => (
                            <div key={item.service} className="text-sm p-2 bg-gray-50 rounded-md">
                                <span className="font-medium">{item.service}: <Badge variant="outline">{item.tier}</Badge></span>
                                <p className="text-xs text-gray-500 mt-1"><strong>Use Case:</strong> {item.use}</p>
                            </div>
                        ))}
                    </CardContent>
                </Card>
            </div>

            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2"><Clock className="w-6 h-6 text-gray-700"/>18-Week Phased Build-Out Plan</CardTitle>
                    <CardDescription>A week-by-week guide to building your backend infrastructure from scratch.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    {weeklyPhases.map((phase, index) => (
                        <motion.div
                            key={phase.title}
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: index * 0.1 }}
                            className="p-4 border-l-4 border-blue-500 bg-blue-50/50 rounded-r-lg"
                        >
                            <h3 className="font-semibold text-lg text-blue-800">{phase.title}</h3>
                            <p className="text-sm text-blue-700 mb-3">{phase.description}</p>
                            <ul className="space-y-2 text-sm text-gray-700 list-disc list-inside">
                                {phase.tasks.map((task, i) => (
                                    <li key={i}>{task}</li>
                                ))}
                            </ul>
                            <Badge className="mt-3 bg-green-100 text-green-800">Cost Impact: {phase.cost_impact}</Badge>
                        </motion.div>
                    ))}
                </CardContent>
            </Card>

            <Alert>
                <Shield className="h-4 w-4" />
                <AlertTitle>The Path to Full CMMC Compliance</AlertTitle>
                <AlertDescription>
                    This architecture is your launchpad, not the final destination. To achieve full CMMC compliance (handling live CUI), this entire setup will be migrated to <strong>AWS GovCloud (US)</strong>. GovCloud is a physically isolated, ITAR-compliant region with a much higher cost structure and no broad free tier. By building on commercial AWS first, you can generate revenue and secure SBIR funding to finance the critical (and expensive) final migration.
                </AlertDescription>
            </Alert>
        </div>
    );
}