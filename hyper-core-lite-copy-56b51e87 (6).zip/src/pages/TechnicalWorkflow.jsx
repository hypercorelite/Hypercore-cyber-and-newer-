import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Bot, Zap, Shield, Server, Code, Cpu, Layers, FileCode, Terminal, Cloud, Database, ArrowRight } from 'lucide-react';
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";

const CodeBlock = ({ code, language }) => (
    <pre className="bg-gray-900 text-green-400 p-4 rounded-md overflow-x-auto text-sm my-4">
        <code className={`language-${language}`}>{code}</code>
    </pre>
);

export default function TechnicalWorkflow() {
    return (
        <div className="space-y-8">
            <BreadcrumbNav currentPageName="Technical Workflow" />

            <div className="text-center">
                <h1 className="text-4xl font-bold text-gray-900 mb-4">
                    Technical Workflow: Building a CRM-Integrated Chatbot
                </h1>
                <p className="text-xl text-gray-600 max-w-4xl mx-auto">
                    A step-by-step guide for deploying a custom AI agent using HyperCore's existing Hugging Face and AWS Lambda infrastructure.
                </p>
            </div>

            <Alert className="bg-blue-50 border-blue-200">
                <Bot className="h-5 w-5 text-blue-600" />
                <AlertTitle className="text-blue-800 font-bold">Strategic Advantage</AlertTitle>
                <AlertDescription className="text-blue-700">
                    This setup provides a scalable, secure, and cost-effective AI agent that leverages open-source models for DIB-specific queries, with deep CRM integration for lead personalization.
                </AlertDescription>
            </Alert>

            <div className="space-y-6">
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2"><Cpu className="w-6 h-6" /> 1. Choose and Load a Hugging Face Model</CardTitle>
                        <CardDescription>Select a lightweight, instruct-tuned model suitable for chat and efficient inference on AWS Lambda.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <p className="mb-2"><strong>Recommended Model:</strong> <code>HuggingFaceTB/SmolLM2-1.7B-Instruct</code> for its balance of performance and small footprint.</p>
                        <p className="mb-4">Install dependencies locally: <code>pip install transformers torch accelerate</code></p>
                        <CodeBlock language="python" code={`from transformers import AutoTokenizer, AutoModelForCausalLM, pipeline
import torch

# Load model/tokenizer efficiently for Lambda
model_name = "HuggingFaceTB/SmolLM2-1.7B-Instruct"
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForCausalLM.from_pretrained(
    model_name,
    torch_dtype=torch.float16,  # Use half-precision to conserve RAM
    device_map="auto"
)

# Create a text-generation pipeline
chat_pipeline = pipeline(
    "text-generation",
    model=model,
    tokenizer=tokenizer,
    max_new_tokens=512,
    temperature=0.7
)

# Example local test
prompt = "User: Explain DFARS flow-downs for CMMC Level 2. HyperCore Agent:"
response = chat_pipeline(prompt)[0]['generated_text']
print(response.split("HyperCore Agent:")[-1].strip())`} />
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2"><Database className="w-6 h-6" /> 2. Integrate with CRM (e.g., HubSpot)</CardTitle>
                        <CardDescription>Fetch lead data from your CRM to personalize responses within the Lambda function.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <p className="mb-4">Use the HubSpot API client and store your API key securely in Lambda environment variables.</p>
                        <CodeBlock language="python" code={`import json
from hubspot import HubSpot

# API key from Lambda environment variables
HUBSPOT_API_KEY = 'your-hubspot-key'

def lambda_handler(event, context):
    user_email = event.get('user_email', 'default@example.com')
    query = event.get('query', '')

    # Fetch lead status from HubSpot
    hubspot_client = HubSpot(api_key=HUBSPOT_API_KEY)
    try:
        contact_search = hubspot_client.crm.contacts.search_api.do_search(
            public_object_search_request={
                "filter_groups": [{"filters": [{"propertyName": "email", "operator": "EQ", "value": user_email}]}]
            }
        )
        lead_status = contact_search.results[0].properties.get('lifecyclestage', 'Unknown')
    except Exception as e:
        lead_status = 'New Prospect'
    
    # Build a personalized prompt for the model
    prompt = f"User (lead status: {lead_status}): {query}. HyperCore Agent: ..."

    # ... call chat_pipeline from Step 1 ...
    
    response = "..." # model-generated response

    return {
        'statusCode': 200,
        'body': json.dumps({'response': response, 'lead_status': lead_status})
    }`} />
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2"><Code className="w-6 h-6" /> 3. Build the Frontend Chat Interface</CardTitle>
                        <CardDescription>Create a reusable React component for a "native feel" chat widget on your website.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <CodeBlock language="jsx" code={`import React, { useState } from 'react';

const HyperCoreChatbot = () => {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const userEmail = 'user@example.com'; // Get from user session

  const sendMessage = async () => {
    if (!input.trim()) return;
    const newMessages = [...messages, { role: 'user', content: input }];
    setMessages(newMessages);
    setInput('');

    // Call Lambda via API Gateway endpoint
    const res = await fetch('YOUR_API_GATEWAY_ENDPOINT/chat', {
      method: 'POST',
      body: JSON.stringify({ query: input, user_email: userEmail })
    });
    const data = await res.json();
    setMessages([...newMessages, { role: 'agent', content: data.response }]);
  };

  return (
    // ... JSX for chat window, input, and button ...
  );
};

export default HyperCoreChatbot;`} />
                    </CardContent>
                </Card>

                 <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2"><Cloud className="w-6 h-6" /> 4. Deploy on AWS Lambda with a Container Image</CardTitle>
                        <CardDescription>Package the model and dependencies into a Docker container for robust, scalable deployment.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <p className="font-semibold">Dockerfile:</p>
                        <CodeBlock language="dockerfile" code={`FROM public.ecr.aws/lambda/python:3.12

# Copy requirements and install
COPY requirements.txt .
RUN pip install -r requirements.txt

# Copy handler code
COPY lambda_handler.py .

# Pre-download the model into the container image to speed up cold starts
RUN python -c "from transformers import AutoTokenizer, AutoModelForCausalLM; AutoTokenizer.from_pretrained('HuggingFaceTB/SmolLM2-1.7B-Instruct'); AutoModelForCausalLM.from_pretrained('HuggingFaceTB/SmolLM2-1.7B-Instruct', torch_dtype='float16')"

CMD ["lambda_handler.lambda_handler"]`} />
                        <p className="font-semibold mt-4">requirements.txt:</p>
                         <CodeBlock language="text" code={`transformers
torch
accelerate
hubspot-api-client
boto3`} />
                        <p className="mt-4"><strong>Deployment Steps:</strong> Build the Docker image, push it to AWS ECR, create a Lambda function using the container image, and expose it via API Gateway.</p>
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2"><Shield className="w-6 h-6" /> 5. Challenges & Solutions</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <ul className="list-disc list-inside space-y-2">
                            <li><strong>Latency:</strong> Use the <code>accelerate</code> library and half-precision (float16) to ensure responses are under 2-3 seconds.</li>
                            <li><strong>CRM Rate Limits:</strong> HubSpot's free tier offers 1M calls/month, which is ample. Cache common CRM data if needed.</li>
                            <li><strong>Scaling:</strong> Default Lambda concurrency is 1,000. Request a service quota increase from AWS if you anticipate major traffic spikes.</li>
                            <li><strong>Security:</strong> Never hard-code API keys. Use Lambda environment variables encrypted with AWS KMS and strict IAM roles.</li>
                        </ul>
                    </CardContent>
                </Card>

            </div>
        </div>
    );
}`}