import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Gavel, Shield, AlertTriangle, Users, Bot, ArrowRight, CheckCircle } from 'lucide-react';
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

const legalRisks = [
    {
        risk: "Unauthorized Practice of Law (UPL)",
        description: "Providing legal advice without a license. LegalZoom itself has faced class-action suits over this.",
        mitigation: "MSA explicitly states we provide 'templates and guidance, not legal advice.' We recommend clients have their own counsel review.",
        icon: Gavel
    },
    {
        risk: "Liability for Audit Failure",
        description: "A client fails their C3PAO assessment and blames our guidance or AI-generated documents.",
        mitigation: "MSA includes a strong 'no guarantee of compliance' disclaimer and limits liability to the fees paid. We are preparation coaches, not certifiers.",
        icon: AlertTriangle
    },
    {
        risk: "CUI & ITAR Data Spillage",
        description: "Mishandling of Controlled Unclassified Information or export-controlled data through our platform or third-party AI tools.",
        mitigation: "MSA mandates client responsibility for data sanitization before submission. Our platform uses FedRAMP-compliant infrastructure (AWS GovCloud) and secure AI endpoints.",
        icon: Shield
    },
    {
        risk: "AI Model Errors & Hallucinations",
        description: "The AI provides incorrect compliance advice or generates flawed documentation, leading to client non-compliance.",
        mitigation: "Our 'human-in-the-loop' model ensures all critical AI-generated documents are reviewed by a human expert. The MSA clarifies that AI outputs are drafts requiring client validation.",
        icon: Bot
    }
];

export default function LegalStrategy() {
    return (
        <div className="space-y-8 p-4 sm:p-6 lg:p-8">
            <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center"
            >
                <Badge className="mb-4 bg-gray-100 text-gray-800">LEGAL & RISK FRAMEWORK</Badge>
                <h1 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-3">
                    The Legal Architecture of AI-Powered CMMC Compliance
                </h1>
                <p className="text-lg lg:text-xl text-gray-600 max-w-4xl mx-auto">
                    A strategic overview of our Master Service Agreement (MSA) structure, risk mitigation, and the legal guardrails for our CMMC tutoring service.
                </p>
            </motion.div>

            <Alert className="bg-red-50 border-red-200">
                <AlertTriangle className="h-4 w-4 text-red-700" />
                <AlertTitle className="text-red-800 font-bold">Core Principle: We Are Tutors, Not Lawyers or Auditors</AlertTitle>
                <AlertDescription className="text-red-700">
                    Our entire legal framework is built on a clear, honest premise: We provide expert preparation guidance, documentation templates, and AI-powered tools. We do not provide legal advice, and we are not a C3PAO. This conflict-of-interest-free stance is our greatest legal protection.
                </AlertDescription>
            </Alert>

            <Card>
                <CardHeader>
                    <CardTitle>Key Legal Risks & Mitigation Strategies</CardTitle>
                    <CardDescription>How our MSA and operational model address the primary legal challenges in the CMMC space.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    {legalRisks.map((item, index) => (
                        <motion.div
                            key={index}
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: index * 0.1 }}
                            className="flex items-start gap-4"
                        >
                            <div className="flex-shrink-0">
                                <div className="w-10 h-10 rounded-lg bg-gray-100 flex items-center justify-center">
                                    <item.icon className="w-6 h-6 text-gray-600" />
                                </div>
                            </div>
                            <div>
                                <h4 className="font-semibold text-lg">{item.risk}</h4>
                                <p className="text-sm text-gray-600 mb-2">{item.description}</p>
                                <p className="text-sm font-medium text-green-700"><span className="font-bold">Mitigation:</span> {item.mitigation}</p>
                            </div>
                        </motion.div>
                    ))}
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>MSA Structure: From LegalZoom Template to CMMC-Ready Contract</CardTitle>
                    <CardDescription>Our MSA starts with a cost-effective template and is fortified with CMMC-specific clauses.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="flex items-center gap-3"><CheckCircle className="w-5 h-5 text-green-600" /> <div><span className="font-semibold">Base Template:</span> LegalZoom Service Agreement ($99)</div></div>
                    <div className="flex items-center gap-3"><CheckCircle className="w-5 h-5 text-green-600" /> <div><span className="font-semibold">Custom Clause - Scope of Services:</span> Defines roles—we provide guidance, client implements controls.</div></div>
                    <div className="flex items-center gap-3"><CheckCircle className="w-5 h-5 text-green-600" /> <div><span className="font-semibold">Custom Clause - Data Handling:</span> Specifies CUI and ITAR requirements and client duty to anonymize.</div></div>
                    <div className="flex items-center gap-3"><CheckCircle className="w-5 h-5 text-green-600" /> <div><span className="font-semibold">Custom Clause - Disclaimers:</span> No guarantee of compliance, not a C3PAO, AI outputs are drafts.</div></div>
                    <div className="flex items-center gap-3"><CheckCircle className="w-5 h-5 text-green-600" /> <div><span className="font-semibold">Custom Clause - Payment Terms:</span> 50% upfront, 50% on completion via wire transfer (HyperCore model).</div></div>
                    <div className="flex items-center gap-3"><CheckCircle className="w-5 h-5 text-green-600" /> <div><span className="font-semibold">Final Review:</span> Optional review by an attorney specializing in government contracts.</div></div>
                </CardContent>
            </Card>

            <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
            >
                <Card className="text-center bg-gray-900 text-white">
                    <CardContent className="p-8 lg:p-10">
                        <h3 className="text-2xl font-bold mb-4">Ready to Create a Client Agreement?</h3>
                        <p className="text-gray-300 mb-6 max-w-2xl mx-auto">
                            Use our internal tool to generate a service agreement based on this legal framework.
                        </p>
                        <Button asChild size="lg" className="bg-white text-gray-900 hover:bg-gray-200">
                            <Link to={createPageUrl('ServiceExpectationsDisclosure')}>
                                Generate Service Agreement <ArrowRight className="w-4 h-4 ml-2" />
                            </Link>
                        </Button>
                    </CardContent>
                </Card>
            </motion.div>
        </div>
    );
}