import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Database, Bot, Shield, Download, Upload, CheckCircle, AlertTriangle, Zap } from 'lucide-react';
import { motion } from "framer-motion";

import PublicDataIntegrator from "../components/training/PublicDataIntegrator";

const publicDataSources = [
    {
        source: "NIST Cybersecurity Framework",
        description: "Official NIST SP 800-171 and 800-53 control definitions, mappings, and implementation guidance",
        dataType: "Structured compliance requirements",
        lastUpdate: "2024-01-15",
        records: "2,847 controls and sub-controls"
    },
    {
        source: "DoD CMMC Documentation",
        description: "Official CMMC 2.0 assessment guides, practice guides, and reference materials",
        dataType: "Assessment procedures and best practices",
        lastUpdate: "2024-01-10",
        records: "1,203 assessment procedures"
    },
    {
        source: "CERT/CVE Vulnerability Database",
        description: "Common vulnerabilities and exposures affecting defense contractors",
        dataType: "Threat intelligence and remediation guidance",
        lastUpdate: "2024-01-20",
        records: "45,678 vulnerability records"
    },
    {
        source: "AWS Security Best Practices",
        description: "AWS GovCloud security configurations, CloudFormation templates, and compliance guides",
        dataType: "Cloud security configurations",
        lastUpdate: "2024-01-18",
        records: "892 configuration templates"
    },
    {
        source: "Microsoft GCC High Guidelines",
        description: "Microsoft 365 GCC High implementation guides and security baselines",
        dataType: "Platform security configurations",
        lastUpdate: "2024-01-12",
        records: "567 implementation guides"
    }
];

const trainingModels = [
    {
        name: "CMMC Gap Analyzer",
        huggingFaceId: "hypercore/cmmc-gap-analyzer-v1",
        purpose: "Identifies compliance gaps based on organization profile",
        accuracy: "94.2%",
        trainingData: "Public NIST + anonymized client assessments"
    },
    {
        name: "Policy Document Generator", 
        huggingFaceId: "hypercore/policy-generator-v1",
        purpose: "Generates SSP, POA&M, and SOP drafts",
        accuracy: "87.6%",
        trainingData: "Public policy templates + client feedback"
    },
    {
        name: "Implementation Guide Assistant",
        huggingFaceId: "hypercore/implementation-guide-v1", 
        purpose: "Provides step-by-step implementation guidance",
        accuracy: "91.8%",
        trainingData: "Public best practices + implementation logs"
    }
];

export default function PublicDataTraining() {
    const [selectedSource, setSelectedSource] = useState(null);

    return (
        <div className="space-y-8">
            <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center"
            >
                <Badge className="mb-4 bg-blue-100 text-blue-800">AI MODEL TRAINING</Badge>
                <h1 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-3">
                    Public Data AI Training Pipeline
                </h1>
                <p className="text-lg lg:text-xl text-gray-600">
                    Building world-class CMMC AI models using publicly available government and industry data sources.
                </p>
            </motion.div>

            <Alert className="bg-green-50 border-green-200">
                <Shield className="h-4 w-4 text-green-600" />
                <AlertTitle className="text-green-800">Zero-Capital AI Strategy</AlertTitle>
                <AlertDescription className="text-green-700">
                    By training on public data sources and hosting on Hugging Face (free tier), we build sophisticated AI models without expensive proprietary datasets or compute costs. This keeps our service affordable while maintaining competitive AI capabilities.
                </AlertDescription>
            </Alert>

            <Tabs defaultValue="sources" className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="sources">Data Sources</TabsTrigger>
                    <TabsTrigger value="models">AI Models</TabsTrigger>
                    <TabsTrigger value="integration">Live Integration</TabsTrigger>
                </TabsList>

                <TabsContent value="sources">
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-3">
                                <Database className="w-6 h-6" />
                                Public Data Sources for AI Training
                            </CardTitle>
                            <CardDescription>
                                We train our AI models exclusively on publicly available, authoritative sources to ensure accuracy and avoid proprietary data constraints.
                            </CardDescription>
                        </CardHeader>
                        <CardContent>
                            <div className="grid gap-4">
                                {publicDataSources.map((source, index) => (
                                    <div key={index} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                                        <div className="flex justify-between items-start mb-2">
                                            <h3 className="font-semibold text-lg">{source.source}</h3>
                                            <Badge variant="outline">{source.records}</Badge>
                                        </div>
                                        <p className="text-gray-600 text-sm mb-3">{source.description}</p>
                                        <div className="flex justify-between items-center text-xs text-gray-500">
                                            <span>Type: {source.dataType}</span>
                                            <span>Last Updated: {source.lastUpdate}</span>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="models">
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-3">
                                <Bot className="w-6 h-6" />
                                Production AI Models
                            </CardTitle>
                            <CardDescription>
                                Our specialized AI models hosted on Hugging Face, each trained for specific CMMC compliance tasks.
                            </CardDescription>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-6">
                                {trainingModels.map((model, index) => (
                                    <div key={index} className="border rounded-lg p-4">
                                        <div className="flex justify-between items-start mb-3">
                                            <div>
                                                <h3 className="font-semibold text-lg">{model.name}</h3>
                                                <p className="text-sm text-gray-600 font-mono">🤗 {model.huggingFaceId}</p>
                                            </div>
                                            <div className="text-right">
                                                <Badge className="bg-green-100 text-green-800">{model.accuracy} Accuracy</Badge>
                                            </div>
                                        </div>
                                        <p className="text-gray-700 mb-3">{model.purpose}</p>
                                        <div className="text-xs text-gray-500">
                                            <strong>Training Data:</strong> {model.trainingData}
                                        </div>
                                    </div>
                                ))}
                            </div>

                            <Alert className="mt-6 bg-blue-50 border-blue-200">
                                <Download className="h-4 w-4 text-blue-600" />
                                <AlertTitle className="text-blue-800">Open Source Philosophy</AlertTitle>
                                <AlertDescription className="text-blue-700">
                                    All our AI models are publicly available on Hugging Face. This transparency builds trust with government contractors while our continuous training on fresh client data maintains our competitive edge.
                                </AlertDescription>
                            </Alert>
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="integration">
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-3">
                                <Zap className="w-6 h-6" />
                                Live Data Integration System
                            </CardTitle>
                            <CardDescription>
                                Real-time integration and processing of public compliance data sources.
                            </CardDescription>
                        </CardHeader>
                        <CardContent>
                            <PublicDataIntegrator />
                        </CardContent>
                    </Card>
                </TabsContent>
            </Tabs>
        </div>
    );
}