import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Copy, Mail, Target, Users, Calendar, DollarSign, CheckCircle, Zap } from 'lucide-react';
import { toast } from "sonner";
import BreadcrumbNav from "@/components/navigation/BreadcrumbNav";

const C3PAO_TARGETS = [
    { 
        name: "CyberSheath", 
        contact: "Dr. Michael Smith, CEO",
        email: "msmith@cybersheath.com",
        focus: "SMB-focused assessments",
        reputation: "Top-tier C3PAO with 200+ Level 2 assessments"
    },
    { 
        name: "Summit7", 
        contact: "Compliance Team",
        email: "compliance@summit7.us",
        focus: "AI/automation integration",
        reputation: "Innovation-focused C3PAO"
    },
    { 
        name: "Apogee Engineering", 
        contact: "CMMC Practice Lead",
        email: "cmmc@apogee-eng.com",
        focus: "Technical assessments",
        reputation: "Engineering-first approach"
    }
];

const C3PAO_EMAIL_TEMPLATE = `Subject: Partnership Invitation: AI-Enhanced CMMC Level 2 Assessments

Dear ${'{CONTACT}'},

${'{C3PAO}'} is renowned for rigorous CMMC Level 2 assessments. With the November 10, 2025 deadline approaching, we believe our AI platform could enhance your assessment efficiency and accuracy.

**HyperCore's Value to ${'{C3PAO}'}:**
• 95% accuracy in pre-assessment gap analysis (vs. 65% manual methods)
• Reduces assessment prep time by 40% for your clients
• Automated NIST 800-171 evidence mapping
• Real-time compliance drift detection

**Partnership Proposal (Non-Revenue):**
We'd like to offer ${'{C3PAO}'} free access to our platform for:
✓ Pre-assessment client preparation
✓ Evidence validation automation  
✓ Continuous monitoring post-certification
✓ Co-branded "AI-Enhanced Assessment" offering

**What We're Seeking:**
- Technical validation of our AI's assessment accuracy
- Potential co-marketing opportunities
- Testimonial for platform credibility

**Zero Risk Trial:**
30-day pilot with 3-5 of your current Level 2 clients. If our AI doesn't reduce your assessment time by 25%, no further commitment required.

Available for a 20-minute discussion this week?

Best regards,
HyperCore Cyber Research Team
training@hypercorecyber.com

P.S. - Our current accuracy rate matches C3PAO findings in 19 of 20 assessments. Happy to share validation data.`;

export default function WebinarPlatformStrategy() {
    const [selectedC3PAO, setSelectedC3PAO] = useState(null);
    const [customEmail, setCustomEmail] = useState('');

    const handleC3PAOSelect = (c3pao) => {
        setSelectedC3PAO(c3pao);
        const personalizedEmail = C3PAO_EMAIL_TEMPLATE
            .replace(/\${'{C3PAO}'}/g, c3pao.name)
            .replace(/\${'{CONTACT}'}/g, c3pao.contact);
        setCustomEmail(personalizedEmail);
    };

    const copyToClipboard = (text) => {
        navigator.clipboard.writeText(text);
        toast.success('Email template copied to clipboard!');
    };

    return (
        <div className="space-y-6">
            <BreadcrumbNav currentPageName="WebinarPlatformStrategy" />
            
            <Alert className="bg-blue-50 border-blue-200">
                <CheckCircle className="h-5 w-5 text-blue-600" />
                <AlertTitle className="text-blue-800">Fatal Flaw Fix: C3PAO Endorsement Strategy</AlertTitle>
                <AlertDescription className="text-blue-700">
                    Instead of hoping SMBs trust "free" tools, we're securing C3PAO validation. Their endorsement gives us instant credibility with 300,000+ DIB contractors.
                </AlertDescription>
            </Alert>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card>
                    <CardContent className="pt-6">
                        <div className="flex items-center">
                            <Target className="h-8 w-8 text-green-600 mr-3" />
                            <div>
                                <p className="text-2xl font-bold">3</p>
                                <p className="text-sm text-gray-600">Target C3PAOs</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>
                
                <Card>
                    <CardContent className="pt-6">
                        <div className="flex items-center">
                            <Users className="h-8 w-8 text-blue-600 mr-3" />
                            <div>
                                <p className="text-2xl font-bold">600+</p>
                                <p className="text-sm text-gray-600">Their Combined Clients</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>
                
                <Card>
                    <CardContent className="pt-6">
                        <div className="flex items-center">
                            <CheckCircle className="h-8 w-8 text-purple-600 mr-3" />
                            <div>
                                <p className="text-2xl font-bold">30%</p>
                                <p className="text-sm text-gray-600">Trust Boost Expected</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </div>

            <Card>
                <CardHeader>
                    <CardTitle>Priority C3PAO Endorsement Targets</CardTitle>
                    <CardDescription>
                        These C3PAOs can validate our AI and provide instant credibility with their client base
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="grid gap-4">
                        {C3PAO_TARGETS.map((c3pao, index) => (
                            <div
                                key={index}
                                className={`p-4 border rounded-lg cursor-pointer transition-all ${
                                    selectedC3PAO?.name === c3pao.name ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-gray-300'
                                }`}
                                onClick={() => handleC3PAOSelect(c3pao)}
                            >
                                <div className="flex justify-between items-center">
                                    <div>
                                        <h3 className="font-semibold text-lg">{c3pao.name}</h3>
                                        <p className="text-sm text-gray-600">{c3pao.contact} • {c3pao.email}</p>
                                        <div className="flex gap-2 mt-2">
                                            <Badge variant="outline">{c3pao.focus}</Badge>
                                            <Badge className="bg-green-100 text-green-800">High Potential</Badge>
                                        </div>
                                        <p className="text-xs text-gray-500 mt-1">{c3pao.reputation}</p>
                                    </div>
                                    <Button size="sm">
                                        Select for Outreach
                                    </Button>
                                </div>
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>

            {selectedC3PAO && (
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <Mail className="w-5 h-5" />
                            C3PAO Partnership Email - {selectedC3PAO.name}
                        </CardTitle>
                        <CardDescription>
                            Non-revenue partnership pitch focusing on mutual value and validation
                        </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <textarea 
                            value={customEmail}
                            onChange={(e) => setCustomEmail(e.target.value)}
                            rows={20}
                            className="w-full p-3 border rounded-md font-mono text-sm"
                        />
                        <div className="flex gap-2">
                            <Button onClick={() => copyToClipboard(customEmail)}>
                                <Copy className="w-4 h-4 mr-2" />
                                Copy Email Template
                            </Button>
                            <Button 
                                variant="outline"
                                onClick={() => window.open(`mailto:${selectedC3PAO.email}?subject=${encodeURIComponent('Partnership Invitation: AI-Enhanced CMMC Level 2 Assessments')}&body=${encodeURIComponent(customEmail)}`)}
                            >
                                Open in Email Client
                            </Button>
                        </div>
                    </CardContent>
                </Card>
            )}

            <Alert className="bg-green-50 border-green-200">
                <Zap className="h-5 w-5 text-green-600" />
                <AlertTitle className="text-green-800">Next Steps: Execute Today</AlertTitle>
                <AlertDescription className="text-green-700">
                    1. Email all 3 C3PAOs by 5:00 PM EDT<br/>
                    2. Follow up with LinkedIn connections<br/>
                    3. Target: 1 partnership MOU by October 1st<br/>
                    4. Add their logos to KnowledgeHub for instant trust boost
                </AlertDescription>
            </Alert>
        </div>
    );
}