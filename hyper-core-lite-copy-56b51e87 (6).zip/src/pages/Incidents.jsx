import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { SecurityIncident } from "@/api/entities";
import { 
    AlertCircle, 
    Plus, 
    Search,
    Calendar,
    User,
    Shield
} from "lucide-react";
import { motion } from "framer-motion";

export default function Incidents() {
    const [incidents, setIncidents] = useState([]);
    const [loading, setLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState("");

    useEffect(() => {
        loadIncidents();
    }, []);

    const loadIncidents = async () => {
        try {
            const fetchedIncidents = await SecurityIncident.list('-created_date', 20);
            setIncidents(fetchedIncidents);
        } catch (error) {
            console.error('Failed to load incidents:', error);
        } finally {
            setLoading(false);
        }
    };

    const updateIncidentStatus = async (incidentId, newStatus) => {
        await SecurityIncident.update(incidentId, { status: newStatus });
        loadIncidents();
    };

    const filteredIncidents = incidents.filter(incident =>
        incident.incident_title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        incident.incident_description.toLowerCase().includes(searchTerm.toLowerCase())
    );

    const getSeverityColor = (severity) => {
        const colors = {
            low: "bg-blue-100 text-blue-800 border-blue-200",
            medium: "bg-yellow-100 text-yellow-800 border-yellow-200",
            high: "bg-orange-100 text-orange-800 border-orange-200",
            critical: "bg-red-100 text-red-800 border-red-200"
        };
        return colors[severity] || "bg-gray-100 text-gray-800";
    };

    const getStatusColor = (status) => {
        const colors = {
            open: "bg-red-100 text-red-800",
            investigating: "bg-yellow-100 text-yellow-800",
            contained: "bg-blue-100 text-blue-800",
            resolved: "bg-green-100 text-green-800",
            closed: "bg-gray-100 text-gray-800"
        };
        return colors[status] || "bg-gray-100 text-gray-800";
    };

    return (
        <div className="min-h-screen bg-gradient-to-br from-gray-50 to-red-50 p-6">
            <div className="max-w-6xl mx-auto">
                <motion.div
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="flex justify-between items-center mb-8"
                >
                    <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
                        <AlertCircle className="w-8 h-8 text-red-600" />
                        Security Incidents
                    </h1>
                    <Button className="bg-red-600 hover:bg-red-700">
                        <Plus className="w-4 h-4 mr-2" />
                        Report Incident
                    </Button>
                </motion.div>

                <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.2 }}
                    className="mb-6"
                >
                    <div className="relative">
                        <Search className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                        <Input
                            placeholder="Search incidents..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="pl-10"
                        />
                    </div>
                </motion.div>

                <div className="space-y-4">
                    {filteredIncidents.map((incident, index) => (
                        <motion.div
                            key={incident.id}
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: index * 0.1 }}
                        >
                            <Card className="hover:shadow-lg transition-shadow">
                                <CardHeader>
                                    <div className="flex justify-between items-start">
                                        <div>
                                            <CardTitle className="text-xl">
                                                {incident.incident_title}
                                            </CardTitle>
                                            <div className="flex gap-2 mt-2">
                                                <Badge className={getSeverityColor(incident.severity_level)}>
                                                    {incident.severity_level} severity
                                                </Badge>
                                                <Badge className={getStatusColor(incident.status)}>
                                                    {incident.status}
                                                </Badge>
                                                <Badge variant="outline">
                                                    {incident.incident_type.replace('_', ' ')}
                                                </Badge>
                                            </div>
                                        </div>
                                        <div className="text-right text-sm text-gray-500">
                                            <div className="flex items-center gap-1 mb-1">
                                                <Calendar className="w-3 h-3" />
                                                {new Date(incident.created_date).toLocaleDateString()}
                                            </div>
                                            {incident.assigned_analyst && (
                                                <div className="flex items-center gap-1">
                                                    <User className="w-3 h-3" />
                                                    {incident.assigned_analyst}
                                                </div>
                                            )}
                                        </div>
                                    </div>
                                </CardHeader>
                                <CardContent>
                                    <p className="text-gray-700 mb-4">
                                        {incident.incident_description}
                                    </p>
                                    
                                    {incident.affected_systems && (
                                        <div className="mb-4">
                                            <div className="text-sm font-semibold text-gray-600 mb-1">
                                                Affected Systems:
                                            </div>
                                            <div className="text-sm text-gray-700">
                                                {incident.affected_systems}
                                            </div>
                                        </div>
                                    )}

                                    <div className="flex justify-between items-center">
                                        <div className="flex items-center gap-2 text-sm text-gray-600">
                                            <Shield className="w-4 h-4" />
                                            Impact: {incident.estimated_impact || 'Unknown'}
                                        </div>
                                        
                                        {incident.status !== 'resolved' && incident.status !== 'closed' && (
                                            <div className="flex gap-2">
                                                <Button 
                                                    size="sm" 
                                                    variant="outline"
                                                    onClick={() => updateIncidentStatus(incident.id, 'investigating')}
                                                >
                                                    Investigate
                                                </Button>
                                                <Button 
                                                    size="sm"
                                                    onClick={() => updateIncidentStatus(incident.id, 'contained')}
                                                    className="bg-blue-600 hover:bg-blue-700"
                                                >
                                                    Contain
                                                </Button>
                                            </div>
                                        )}
                                    </div>
                                </CardContent>
                            </Card>
                        </motion.div>
                    ))}
                </div>

                {loading && (
                    <div className="text-center py-12">
                        <div className="text-gray-500">Loading security incidents...</div>
                    </div>
                )}
            </div>
        </div>
    );
}