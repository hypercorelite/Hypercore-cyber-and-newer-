import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Code, Download, FileText, Package } from 'lucide-react';
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";

const CodeBlock = ({ title, language, code }) => (
    <Card className="mb-6">
        <CardHeader>
            <CardTitle className="flex items-center gap-2">
                <Code className="w-5 h-5" />
                {title}
            </CardTitle>
        </CardHeader>
        <CardContent>
            <pre className="bg-gray-900 text-green-400 p-4 rounded-lg overflow-x-auto text-sm">
                <code>{code}</code>
            </pre>
        </CardContent>
    </Card>
);

export default function PythonPackageStructure() {
    const setupPy = `from setuptools import setup, find_packages

setup(
    name="cmmc_pdf_generator",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[
        "flask==2.3.3",
        "sqlalchemy==2.0.23",
        "reportlab==4.0.7",
        "requests==2.31.0",
        "python-dotenv==1.0.0",
        "PyPDF2==3.0.1"
    ],
    author="HyperCore Team",
    description="AI-powered PDF generator for CMMC Level 2 compliance (SSP, 110 controls, policies, reports)",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/hypercore/cmmc_pdf_generator",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
)`;

    const appPy = `from flask import Flask, request, jsonify
from cmmc_pdf_generator.utils.pdf import generate_ssp_pdf, generate_policy_pdf
from cmmc_pdf_generator.utils.ai import generate_ssp_content, generate_policy_content
from cmmc_pdf_generator.models import db, ClientData
import os
from dotenv import load_dotenv

load_dotenv()

def create_app():
    app = Flask(__name__)
    app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('DATABASE_URL', 'sqlite:///cmmc.db')
    app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'dev-secret-key')
    
    db.init_app(app)
    
    # Import routes
    from cmmc_pdf_generator.routes.ssp import ssp_bp
    from cmmc_pdf_generator.routes.policy import policy_bp
    from cmmc_pdf_generator.routes.report import report_bp
    
    app.register_blueprint(ssp_bp)
    app.register_blueprint(policy_bp)
    app.register_blueprint(report_bp)
    
    with app.app_context():
        db.create_all()
    
    return app

if __name__ == '__main__':
    app = create_app()
    app.run(debug=True)`;

    const modelsPy = `from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

class ClientData(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    company_name = db.Column(db.String(100), nullable=False)
    industry = db.Column(db.String(50), nullable=False)
    size = db.Column(db.String(20), nullable=False)
    location = db.Column(db.String(100), nullable=False)
    cmmc_level = db.Column(db.String(10), default='Level 2')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'company_name': self.company_name,
            'industry': self.industry,
            'size': self.size,
            'location': self.location,
            'cmmc_level': self.cmmc_level,
            'created_at': self.created_at.isoformat()
        }

class GeneratedDocument(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    client_id = db.Column(db.Integer, db.ForeignKey('client_data.id'), nullable=False)
    document_type = db.Column(db.String(50), nullable=False)  # 'ssp', 'policy', 'report'
    file_path = db.Column(db.String(200), nullable=False)
    ai_content = db.Column(db.Text)  # Store raw AI-generated content
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    client = db.relationship('ClientData', backref=db.backref('documents', lazy=True))`;

    const sspRoutePy = `from flask import Blueprint, request, jsonify, send_file
from cmmc_pdf_generator.utils.pdf import generate_ssp_pdf
from cmmc_pdf_generator.utils.ai import generate_ssp_content
from cmmc_pdf_generator.models import db, ClientData, GeneratedDocument
import os
import tempfile

ssp_bp = Blueprint('ssp', __name__, url_prefix='/api/ssp')

@ssp_bp.route('/generate', methods=['POST'])
def generate_ssp():
    try:
        data = request.get_json()
        
        # Save client data
        client = ClientData(
            company_name=data['company_name'],
            industry=data['industry'],
            size=data['size'],
            location=data['location'],
            cmmc_level=data.get('cmmc_level', 'Level 2')
        )
        db.session.add(client)
        db.session.commit()
        
        # Generate AI content
        ai_content = generate_ssp_content(
            company_name=client.company_name,
            industry=client.industry,
            system_description=data.get('system_description', '')
        )
        
        # Generate PDF
        pdf_path = generate_ssp_pdf(client.to_dict(), ai_content)
        
        # Save document record
        document = GeneratedDocument(
            client_id=client.id,
            document_type='ssp',
            file_path=pdf_path,
            ai_content=ai_content
        )
        db.session.add(document)
        db.session.commit()
        
        return send_file(pdf_path, as_attachment=True, 
                        download_name=f'SSP_{client.company_name.replace(" ", "_")}.pdf')
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500`;

    const aiPy = `import requests
import os
from typing import Dict, Any

class AIContentGenerator:
    def __init__(self):
        self.api_key = os.getenv('CLAUDE_API_KEY')
        self.base_url = 'https://api.anthropic.com/v1/messages'
    
    def generate_ssp_content(self, company_name: str, industry: str, system_description: str) -> str:
        """Generate SSP content using Claude API"""
        prompt = f'''Generate a detailed System Security Plan (SSP) for CMMC Level 2 compliance.
        
Company: {company_name}
Industry: {industry}
System: {system_description}

Generate content for these sections:
1. System Identification and Description
2. Control Implementation Overview (NIST 800-171)
3. Roles and Responsibilities
4. Assessment Procedures (NIST 800-171A)
5. Plan of Action & Milestones (POA&M)

Format as structured text with clear section headers.'''

        headers = {
            'Content-Type': 'application/json',
            'x-api-key': self.api_key,
            'anthropic-version': '2023-06-01'
        }
        
        payload = {
            'model': 'claude-3-sonnet-20240229',
            'max_tokens': 4000,
            'messages': [{'role': 'user', 'content': prompt}]
        }
        
        response = requests.post(self.base_url, headers=headers, json=payload)
        response.raise_for_status()
        
        return response.json()['content'][0]['text']

def generate_ssp_content(company_name: str, industry: str, system_description: str) -> str:
    generator = AIContentGenerator()
    return generator.generate_ssp_content(company_name, industry, system_description)`;

    const pdfPy = `from reportlab.lib.pagesizes import letter, A4
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
from reportlab.lib.units import inch
from datetime import datetime
import os
import tempfile

class CMMCPDFGenerator:
    def __init__(self):
        self.styles = getSampleStyleSheet()
        self.title_style = ParagraphStyle(
            'CustomTitle',
            parent=self.styles['Heading1'],
            fontSize=18,
            spaceAfter=30,
            alignment=1,  # Center alignment
            textColor=colors.darkblue
        )
    
    def generate_ssp_pdf(self, client_data: dict, ai_content: str) -> str:
        """Generate SSP PDF with professional formatting"""
        
        # Create temporary file
        temp_dir = tempfile.mkdtemp()
        filename = f"SSP_{client_data['company_name'].replace(' ', '_')}.pdf"
        file_path = os.path.join(temp_dir, filename)
        
        # Create PDF document
        doc = SimpleDocTemplate(file_path, pagesize=A4)
        story = []
        
        # Cover page
        story.append(Paragraph("System Security Plan (SSP)", self.title_style))
        story.append(Spacer(1, 0.5*inch))
        
        # Company info table
        company_data = [
            ['Company:', client_data['company_name']],
            ['Industry:', client_data['industry']],
            ['Size:', client_data['size']],
            ['Location:', client_data['location']],
            ['CMMC Level:', client_data['cmmc_level']],
            ['Generated:', datetime.now().strftime('%Y-%m-%d')]
        ]
        
        table = Table(company_data, colWidths=[1.5*inch, 4*inch])
        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (0, -1), colors.lightblue),
            ('TEXTCOLOR', (0, 0), (0, -1), colors.darkblue),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 0), (-1, -1), 12),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 12),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        
        story.append(table)
        story.append(PageBreak())
        
        # AI-generated content sections
        sections = ai_content.split('\\n\\n')
        for section in sections:
            if section.strip():
                story.append(Paragraph(section, self.styles['Normal']))
                story.append(Spacer(1, 0.2*inch))
        
        # Build PDF
        doc.build(story)
        return file_path

def generate_ssp_pdf(client_data: dict, ai_content: str) -> str:
    generator = CMMCPDFGenerator()
    return generator.generate_ssp_pdf(client_data, ai_content)`;

    const requirementsTxt = `flask==2.3.3
sqlalchemy==2.0.23
reportlab==4.0.7
requests==2.31.0
python-dotenv==1.0.0
PyPDF2==3.0.1
flask-sqlalchemy==3.0.5
anthropic==0.7.8`;

    const readmeMd = `# CMMC PDF Generator

AI-powered PDF generator for CMMC Level 2 compliance documentation, including System Security Plans (SSP), policy documents, and compliance reports.

## Features

- **System Security Plan (SSP)** generation with NIST 800-171A alignment
- **Policy Documents** for all 14 CMMC domains
- **Compliance Reports** with gap analysis and recommendations
- **AI-Powered Content** using Claude API for realistic, detailed documentation
- **Professional PDF Formatting** with tables, headers, and structured layouts

## Installation

\`\`\`bash
pip install -e .
# or
pip install cmmc_pdf_generator
\`\`\`

## Configuration

Create a \`.env\` file:

\`\`\`
CLAUDE_API_KEY=your_anthropic_api_key
DATABASE_URL=sqlite:///cmmc.db
SECRET_KEY=your_secret_key
\`\`\`

## Usage

### Start the Flask Server

\`\`\`bash
python -m cmmc_pdf_generator.app
\`\`\`

### Generate SSP via API

\`\`\`bash
curl -X POST http://localhost:5000/api/ssp/generate \\
  -H "Content-Type: application/json" \\
  -d '{
    "company_name": "Defense Solutions Inc",
    "industry": "Defense Contracting",
    "size": "100-500",
    "location": "Virginia",
    "system_description": "AWS-based system for CUI processing"
  }'
\`\`\`

### Generate Policies

\`\`\`bash
curl -X POST http://localhost:5000/api/policy/generate \\
  -H "Content-Type: application/json" \\
  -d '{
    "company_name": "Defense Solutions Inc",
    "policy_type": "Access Control"
  }'
\`\`\`

## Architecture

- **Flask REST API** for document generation endpoints
- **SQLAlchemy** for client data and document tracking
- **ReportLab** for professional PDF generation
- **Claude API** for AI content generation
- **Modular design** with separate routes for SSP, policies, and reports

## License

MIT License`;

    return (
        <div className="space-y-6">
            <BreadcrumbNav currentPageName="PythonPackageStructure" />
            
            <div className="text-center">
                <Badge className="mb-4 bg-green-100 text-green-800">PYTHON PACKAGE</Badge>
                <h1 className="text-4xl font-bold text-gray-900 mb-4">Complete Python Package Structure</h1>
                <p className="text-xl text-gray-600 max-w-4xl mx-auto">
                    The full Flask-based cmmc_pdf_generator package with all supporting files, ready for deployment or PyPI distribution.
                </p>
            </div>

            <CodeBlock title="setup.py (Package Configuration)" language="python" code={setupPy} />
            <CodeBlock title="cmmc_pdf_generator/app.py (Flask Application)" language="python" code={appPy} />
            <CodeBlock title="cmmc_pdf_generator/models.py (Database Models)" language="python" code={modelsPy} />
            <CodeBlock title="cmmc_pdf_generator/routes/ssp.py (SSP Route)" language="python" code={sspRoutePy} />
            <CodeBlock title="cmmc_pdf_generator/utils/ai.py (AI Content Generation)" language="python" code={aiPy} />
            <CodeBlock title="cmmc_pdf_generator/utils/pdf.py (PDF Generation)" language="python" code={pdfPy} />
            <CodeBlock title="requirements.txt" language="text" code={requirementsTxt} />
            <CodeBlock title="README.md" language="markdown" code={readmeMd} />

            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Package className="w-5 h-5 text-blue-600" />
                        Package Installation & Usage
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="space-y-4">
                        <div className="p-4 bg-blue-50 rounded-lg">
                            <h4 className="font-semibold text-blue-800">Development Setup</h4>
                            <pre className="text-sm text-blue-600 mt-2">
pip install -e .{'\n'}
python -m cmmc_pdf_generator.app
                            </pre>
                        </div>
                        <div className="p-4 bg-green-50 rounded-lg">
                            <h4 className="font-semibold text-green-800">Production Deployment</h4>
                            <pre className="text-sm text-green-600 mt-2">
pip install cmmc_pdf_generator{'\n'}
gunicorn cmmc_pdf_generator.app:create_app
                            </pre>
                        </div>
                        <div className="p-4 bg-purple-50 rounded-lg">
                            <h4 className="font-semibold text-purple-800">PyPI Distribution</h4>
                            <pre className="text-sm text-purple-600 mt-2">
python setup.py sdist bdist_wheel{'\n'}
twine upload dist/*
                            </pre>
                        </div>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}