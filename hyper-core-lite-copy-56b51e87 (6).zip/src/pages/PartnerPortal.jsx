import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { User } from "@/api/entities";
import { PartnerClient } from "@/api/entities";
import { Handshake, Users, TrendingUp, Plus, FileText } from 'lucide-react';
import { motion } from "framer-motion";
import { toast } from "sonner";

export default function PartnerPortal() {
    const [user, setUser] = useState(null);
    const [clients, setClients] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const currentUser = await User.me();
                setUser(currentUser);
                const partnerClients = await PartnerClient.filter({ partner_id: currentUser.email });
                setClients(partnerClients);
            } catch (error) {
                console.error("Failed to load partner data:", error);
                toast.error("You must be logged in to access the partner portal.");
            } finally {
                setLoading(false);
            }
        };
        fetchData();
    }, []);
    
    if (loading) {
        return <div className="text-center p-12">Loading Partner Portal...</div>;
    }

    if (!user) {
        return <div className="text-center p-12 text-red-600">Access Denied. Please log in.</div>;
    }

    const summaryMetrics = {
        activeClients: clients.length,
        averageRiskScore: clients.length > 0 ? (clients.reduce((acc, c) => acc + (c.latest_risk_score || 60), 0) / clients.length).toFixed(0) : 'N/A',
        prospects: clients.filter(c => c.client_status === 'prospect').length
    };

    return (
        <div className="min-h-screen bg-gray-50 p-6">
            <div className="max-w-7xl mx-auto">
                <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
                    <h1 className="text-4xl font-bold text-gray-900 mb-2 flex items-center gap-3">
                        <Handshake className="w-10 h-10 text-purple-600" />
                        Partner Dashboard
                    </h1>
                    <p className="text-lg text-gray-600">
                        Manage your client pipeline and access HyperCore's risk intelligence tools.
                    </p>
                </motion.div>

                {/* Summary Metrics */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2 text-sm text-gray-500">
                                <Users className="w-4 h-4" /> Client Pipeline
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="text-3xl font-bold">{summaryMetrics.activeClients}</div>
                            <p className="text-xs text-gray-500">{summaryMetrics.prospects} active prospects</p>
                        </CardContent>
                    </Card>
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2 text-sm text-gray-500">
                                <TrendingUp className="w-4 h-4" /> Avg. Portfolio Risk Score
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="text-3xl font-bold">{summaryMetrics.averageRiskScore}</div>
                            <p className="text-xs text-green-600">Lower is better</p>
                        </CardContent>
                    </Card>
                     <Card className="flex flex-col justify-center items-center">
                        <Button><Plus className="w-4 h-4 mr-2" /> Add New Client</Button>
                        <p className="text-xs text-gray-500 mt-2">Manually add a new prospect to your pipeline.</p>
                    </Card>
                </div>

                {/* Client Management Table */}
                <Card>
                    <CardHeader>
                        <CardTitle>Managed Clients</CardTitle>
                        <CardDescription>Your portfolio of prospects and active clients.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Client Name</TableHead>
                                    <TableHead>Status</TableHead>
                                    <TableHead>Risk Score</TableHead>
                                    <TableHead>Actions</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {clients.map(client => (
                                    <TableRow key={client.id}>
                                        <TableCell className="font-medium">{client.client_name}</TableCell>
                                        <TableCell>
                                            <Badge variant={client.client_status === 'prospect' ? 'secondary' : 'default'}>
                                                {client.client_status}
                                            </Badge>
                                        </TableCell>
                                        <TableCell>{client.latest_risk_score || 'Not Scanned'}</TableCell>
                                        <TableCell>
                                            <Button variant="outline" size="sm">
                                                <FileText className="w-3 h-3 mr-2" /> View Report
                                            </Button>
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}