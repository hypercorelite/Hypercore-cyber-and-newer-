
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Copy, Laptop, FolderTree, Package, Key, Github, GitBranch, ArrowRight, Terminal, Cloud, CheckCircle, Rocket, BookOpen, Zap, Code, Clock, Target, DollarSign } from 'lucide-react';
import { toast } from "sonner";
import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge"; // Added Badge import

const weeklyPlan = [
    {
        week: "Week 1-2",
        focus: "Dev Environment & Version Control",
        learning: ["VS Code setup & extensions", "Git basics & GitHub workflow", "Python environment setup"],
        building: ["Initialize your CMMC-AI-Tool repository", "Set up basic project structure", "Create your first Python script"],
        deliverable: "GitHub repo with basic Python 'Hello CMMC' script",
        links: ["https://code.visualstudio.com/docs/getstarted/introvideos", "https://learngitbranching.js.org/", "https://www.kaggle.com/learn/python"]
    },
    {
        week: "Week 3-4",
        focus: "AWS Foundation & Basic APIs",
        learning: ["AWS Free Tier setup", "Lambda functions", "API Gateway basics", "Environment variables"],
        building: ["Deploy your first Lambda function", "Create a simple REST API endpoint", "Store API keys securely"],
        deliverable: "Live API endpoint that returns CMMC control information",
        links: ["https://aws.amazon.com/free/", "https://docs.aws.amazon.com/lambda/latest/dg/getting-started.html"]
    },
    {
        week: "Week 5-6",
        focus: "Vector Databases & Document Ingestion",
        learning: ["Pinecone setup", "Text embeddings", "Document chunking strategies"],
        building: ["Ingest NIST 800-171 controls into Pinecone", "Build document search function", "Test similarity searches"],
        deliverable: "Vector database with CMMC controls that responds to search queries",
        links: ["https://docs.pinecone.io/docs/quickstart", "https://platform.openai.com/docs/guides/embeddings"]
    },
    {
        week: "Week 7-8",
        focus: "RAG Pipeline & AI Analysis",
        learning: ["LangChain basics", "RAG architecture", "Prompt engineering"],
        building: ["Build RAG pipeline function", "Connect vector search to LLM", "Create gap analysis logic"],
        deliverable: "API that analyzes client data and identifies CMMC compliance gaps",
        links: ["https://python.langchain.com/docs/use_cases/question_answering/", "https://huggingface.co/learn/nlp-course/chapter7/1"]
    },
    {
        week: "Week 9-10",
        focus: "React Frontend Basics",
        learning: ["React fundamentals", "Component structure", "API integration"],
        building: ["Create basic React app", "Build input form for client data", "Display AI analysis results"],
        deliverable: "Simple web interface that calls your AI backend",
        links: ["https://react.dev/learn", "https://www.freecodecamp.org/news/how-to-consume-rest-apis-in-react/"]
    },
    {
        week: "Week 11-12",
        focus: "Document Generation Engine",
        learning: ["PDF generation in Python", "Template systems", "File handling"],
        building: ["Build SSP template generator", "Create POAM generator", "Integrate with AI analysis"],
        deliverable: "System that generates compliance documents from AI analysis",
        links: ["https://reportlab.com/docs/reportlab-userguide.pdf", "https://jinja.palletsprojects.com/"]
    },
    {
        week: "Week 13-14",
        focus: "UI Polish & Integration",
        learning: ["Tailwind CSS", "Component libraries", "User experience"],
        building: ["Style your React interface", "Add loading states", "Improve error handling"],
        deliverable: "Professional-looking web app ready for pilot testing",
        links: ["https://tailwindcss.com/docs/installation", "https://ui.shadcn.com/docs"]
    },
    {
        week: "Week 15-16",
        focus: "Pilot Testing & SBIR Preparation",
        learning: ["User feedback collection", "Analytics setup", "Demo recording"],
        building: ["Onboard 3-5 pilot users", "Collect usage data", "Record demo video"],
        deliverable: "Validated MVP with user testimonials and demo materials",
        links: ["https://www.hotjar.com/", "https://www.loom.com/"]
    }
];

const weeklyCodeTemplates = [
    {
        week: "Week 1-2",
        title: "GitHub Repo Setup + Hello CMMC Script",
        commands: `
# Initialize your repository
mkdir cmmc-ai-tool
cd cmmc-ai-tool
git init
echo "# CMMC AI Tool" > README.md

# Create basic project structure
mkdir src tests docs
touch src/__init__.py
touch requirements.txt

# Create your first Python script
cat > src/hello_cmmc.py << 'EOF'
#!/usr/bin/env python3
"""
CMMC AI Tool - Hello World
Week 1-2 Deliverable
"""

def get_cmmc_controls():
    """Returns basic CMMC control information"""
    controls = {
        "AC.L1-3.1.1": "Limit system access to authorized users",
        "AC.L1-3.1.2": "Limit system access to authorized functions",
        "CM.L2-3.4.1": "Establish configuration baselines"
    }
    return controls

def main():
    print("🛡️  CMMC AI Tool - Week 1-2 MVP")
    print("=" * 40)

    controls = get_cmmc_controls()
    for control_id, description in controls.items():
        print(f"{control_id}: {description}")

    print("\\n✅ Week 1-2 Milestone: Basic Python + Git Setup Complete!")

if __name__ == "__main__":
    main()
EOF

# Make it executable and commit
chmod +x src/hello_cmmc.py
git add .
git commit -m "Week 1-2: Initial CMMC AI Tool setup"

# Test your script
python src/hello_cmmc.py`,
        testCommand: `python src/hello_cmmc.py`
    },
    {
        week: "Week 3-4",
        title: "AWS Lambda API Endpoint",
        commands: `
# Create AWS Lambda function
mkdir aws-lambda
cat > aws-lambda/lambda_function.py << 'EOF'
import json

def lambda_handler(event, context):
    """
    CMMC Control Information API
    Week 3-4 Deliverable
    """

    cmmc_controls = {
        "AC.L1-3.1.1": {
            "title": "Limit system access to authorized users",
            "level": "Level 1",
            "description": "Control and limit connections to and use of the system."
        },
        "AC.L1-3.1.2": {
            "title": "Limit system access to authorized functions",
            "level": "Level 1",
            "description": "Control information system access, monitor access attempts."
        },
        "CM.L2-3.4.1": {
            "title": "Establish configuration baselines",
            "level": "Level 2",
            "description": "Develop, document, and maintain configuration baselines."
        }
    }

    # Handle different HTTP methods
    http_method = event.get('httpMethod', 'GET')

    if http_method == 'GET':
        control_id = event.get('queryStringParameters', {}).get('control_id')

        if control_id and control_id in cmmc_controls:
            return {
                'statusCode': 200,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                'body': json.dumps({
                    'control_id': control_id,
                    'control': cmmc_controls[control_id],
                    'week': '3-4',
                    'status': 'success'
                })
            }
        else:
            return {
                'statusCode': 200,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                'body': json.dumps({
                    'controls': cmmc_controls,
                    'total_controls': len(cmmc_controls),
                    'week': '3-4',
                    'status': 'success'
                })
            }

    return {
        'statusCode': 405,
        'body': json.dumps({'error': 'Method not allowed'})
    }
EOF

# Create deployment script
cat > deploy-lambda.sh << 'EOF'
#!/bin/bash
echo "📦 Creating Lambda deployment package..."
cd aws-lambda
zip -r ../cmmc-lambda.zip .
cd ..

echo "🚀 Deploying to AWS Lambda..."
aws lambda create-function \
    --function-name cmmc-api \
    --runtime python3.9 \
    --role arn:aws:iam::YOUR-ACCOUNT:role/lambda-execution-role \
    --handler lambda_function.lambda_handler \
    --zip-file fileb://cmmc-lambda.zip

echo "✅ Lambda function deployed!"
echo "Test with: aws lambda invoke --function-name cmmc-api output.json"
EOF

chmod +x deploy-lambda.sh`,
        testCommand: `python aws-lambda/lambda_function.py # Local test`
    },
    {
        week: "Week 5-6",
        title: "Vector Database with CMMC Controls",
        commands: `
# Install required packages
cat > requirements.txt << 'EOF'
pinecone-client==2.2.4
openai==1.3.0
python-dotenv==1.0.0
pandas==2.1.0
tiktoken==0.5.0
EOF

pip install -r requirements.txt

# Create vector database setup
cat > src/vector_db.py << 'EOF'
import os
import openai
import pinecone
from dotenv import load_dotenv
import json

load_dotenv()

class CMMCVectorDB:
    def __init__(self):
        # Initialize Pinecone
        pinecone.init(
            api_key=os.getenv('PINECONE_API_KEY'),
            environment=os.getenv('PINECONE_ENV', 'us-west1-gcp-free')
        )

        self.index_name = "cmmc-controls"
        self.openai_client = openai.OpenAI(api_key=os.getenv('OPENAI_API_KEY'))

    def create_index(self):
        """Create Pinecone index if it doesn't exist"""
        if self.index_name not in pinecone.list_indexes():
            pinecone.create_index(
                name=self.index_name,
                dimension=1536,  # OpenAI embedding dimension
                metric='cosine'
            )
        return pinecone.Index(self.index_name)

    def get_embedding(self, text):
        """Get OpenAI embedding for text"""
        response = self.openai_client.embeddings.create(
            model="text-embedding-ada-002",
            input=text
        )
        return response.data[0].embedding

    def ingest_cmmc_controls(self):
        """Ingest NIST 800-171 controls into vector database"""
        controls = {
            "AC.L1-3.1.1": {
                "title": "Limit system access to authorized users",
                "description": "Limit information system access to authorized users, processes acting on behalf of authorized users, or devices (including other information systems).",
                "level": "Level 1",
                "family": "Access Control"
            },
            "AC.L1-3.1.2": {
                "title": "Limit system access to the types of transactions and functions",
                "description": "Limit information system access to the types of transactions and functions that authorized users are permitted to execute.",
                "level": "Level 1",
                "family": "Access Control"
            },
            "CM.L2-3.4.1": {
                "title": "Establish and maintain baseline configurations",
                "description": "Establish and maintain baseline configurations and inventories of organizational information systems throughout the respective system development life cycles.",
                "level": "Level 2",
                "family": "Configuration Management"
            }
        }

        index = self.create_index()

        vectors = []
        for control_id, control_data in controls.items():
            # Create searchable text
            text = f"{control_id} {control_data['title']} {control_data['description']}"

            # Get embedding
            embedding = self.get_embedding(text)

            # Prepare vector for upsert
            vectors.append({
                'id': control_id,
                'values': embedding,
                'metadata': {
                    'control_id': control_id,
                    'title': control_data['title'],
                    'description': control_data['description'],
                    'level': control_data['level'],
                    'family': control_data['family'],
                    'searchable_text': text
                }
            })

        # Upsert vectors
        index.upsert(vectors=vectors)
        print(f"✅ Ingested {len(vectors)} CMMC controls into vector database")

    def search_controls(self, query, top_k=3):
        """Search for relevant CMMC controls"""
        index = pinecone.Index(self.index_name)

        # Get query embedding
        query_embedding = self.get_embedding(query)

        # Search
        results = index.query(
            vector=query_embedding,
            top_k=top_k,
            include_metadata=True
        )

        return results

def main():
    print("🔍 CMMC Vector Database - Week 5-6 MVP")
    print("=" * 50)

    db = CMMCVectorDB()

    # Ingest controls
    print("📥 Ingesting CMMC controls...")
    db.ingest_cmmc_controls()

    # Test search
    print("\\n🔍 Testing search functionality...")
    results = db.search_controls("user access control", top_k=2)

    for match in results.matches:
        metadata = match.metadata
        print(f"\\n📋 {metadata['control_id']}: {metadata['title']}")
        print(f"   Score: {match.score:.3f}")
        print(f"   Level: {metadata['level']}")

    print("\\n✅ Week 5-6 Milestone: Vector Database with Search Complete!")

if __name__ == "__main__":
    main()
EOF

# Create environment template
cat > .env.example << 'EOF'
PINECONE_API_KEY=your-pinecone-api-key
PINECONE_ENV=us-west1-gcp-free
OPENAI_API_KEY=your-openai-api-key
EOF

echo "Copy .env.example to .env and add your API keys"`,
        testCommand: `python src/vector_db.py`
    },
    {
        week: "Week 7-8",
        title: "RAG Pipeline for Gap Analysis",
        commands: `
# Install LangChain
echo "langchain==0.0.350" >> requirements.txt
echo "langchain-openai==0.0.2" >> requirements.txt
pip install -r requirements.txt

# Create RAG pipeline
cat > src/rag_pipeline.py << 'EOF'
import os
from langchain.llms import OpenAI
from langchain.chains import RetrievalQA
from langchain.vectorstores import Pinecone
from langchain.embeddings import OpenAIEmbeddings
import pinecone
from dotenv import load_dotenv
import json

load_dotenv()

class CMMCGapAnalyzer:
    def __init__(self):
        # Initialize Pinecone
        pinecone.init(
            api_key=os.getenv('PINECONE_API_KEY'),
            environment=os.getenv('PINECONE_ENV')
        )

        self.embeddings = OpenAIEmbeddings(openai_api_key=os.getenv('OPENAI_API_KEY'))
        self.llm = OpenAI(openai_api_key=os.getenv('OPENAI_API_KEY'), temperature=0)

        # Create vector store
        self.vectorstore = Pinecone.from_existing_index(
            index_name="cmmc-controls",
            embedding=self.embeddings
        )

        # Create retrieval QA chain
        self.qa_chain = RetrievalQA.from_chain_type(
            llm=self.llm,
            chain_type="stuff",
            retriever=self.vectorstore.as_retriever(search_kwargs={"k": 5}),
            return_source_documents=True
        )

    def analyze_client_data(self, client_info):
        """Analyze client information against CMMC requirements"""

        # Create analysis prompt
        prompt = f"""
        Analyze the following client information against CMMC requirements:

        Client Information:
        - Company: {client_info.get('company', 'Unknown')}
        - Industry: {client_info.get('industry', 'Unknown')}
        - Current Security Measures: {client_info.get('current_security', 'None specified')}
        - Systems: {client_info.get('systems', 'Not specified')}
        - Data Types: {client_info.get('data_types', 'Unknown')}

        Based on CMMC requirements, identify:
        1. Which CMMC controls apply to this organization
        2. Potential compliance gaps
        3. Priority recommendations

        Provide specific control references and actionable recommendations.
        """

        # Run analysis
        result = self.qa_chain({"query": prompt})

        return {
            "analysis": result["result"],
            "source_controls": [doc.metadata for doc in result["source_documents"]],
            "gaps_identified": self._extract_gaps(result["result"]),
            "recommendations": self._extract_recommendations(result["result"])
        }

    def _extract_gaps(self, analysis_text):
        """Extract compliance gaps from analysis"""
        gaps = []
        lines = analysis_text.split('\\n')

        for line in lines:
            if 'gap' in line.lower() or 'missing' in line.lower():
                gaps.append(line.strip())

        return gaps

    def _extract_recommendations(self, analysis_text):
        """Extract recommendations from analysis"""
        recommendations = []
        lines = analysis_text.split('\\n')

        for line in lines:
            if 'recommend' in line.lower() or 'should' in line.lower():
                recommendations.append(line.strip())

        return recommendations

def main():
    print("🔬 CMMC Gap Analyzer - Week 7-8 MVP")
    print("=" * 50)

    # Sample client data
    sample_client = {
        "company": "Tech Solutions Inc",
        "industry": "Software Development",
        "current_security": "Basic firewall, antivirus, password policy",
        "systems": "Windows domain, web applications, database server",
        "data_types": "Customer PII, financial records, technical specifications"
    }

    analyzer = CMMCGapAnalyzer()

    print("📊 Analyzing client compliance posture...")
    results = analyzer.analyze_client_data(sample_client)

    print("\\n📋 ANALYSIS RESULTS:")
    print("-" * 30)
    print(results["analysis"][:500] + "..." if len(results["analysis"]) > 500 else results["analysis"])

    print(f"\\n🎯 Source Controls Referenced: {len(results['source_controls'])}")
    for control in results["source_controls"][:3]:
        print(f"   • {control.get('control_id', 'N/A')}: {control.get('title', 'N/A')}")

    print(f"\\n⚠️  Gaps Identified: {len(results['gaps_identified'])}")
    for gap in results["gaps_identified"][:3]:
        print(f"   • {gap}")

    print("\\n✅ Week 7-8 Milestone: RAG Pipeline for Gap Analysis Complete!")

if __name__ == "__main__":
    main()
EOF`,
        testCommand: `python src/rag_pipeline.py`
    },
    {
        week: "Week 9-10",
        title: "React Frontend for AI Analyzer",
        commands: `
# Create React app and install Tailwind CSS
npx create-react-app frontend
cd frontend
npm install -D tailwindcss
npx tailwindcss init

# Configure tailwind.config.js
cat > tailwind.config.js << 'EOF'
/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
EOF

# Configure src/index.css
cat > src/index.css << 'EOF'
@tailwind base;
@tailwind components;
@tailwind utilities;
EOF

# Create the main component
cat > src/CMMCAnalyzer.js << 'EOF'
import React, { useState } from 'react';

export default function CMMCAnalyzer() {
    const [clientData, setClientData] = useState('');
    const [analysis, setAnalysis] = useState(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');

    // IMPORTANT: Replace with your actual API Gateway endpoint URL
    const API_ENDPOINT = 'https://YOUR_API_ID.execute-api.us-east-1.amazonaws.com/prod/analyze';

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        setError('');
        setAnalysis(null);

        try {
            const response = await fetch(API_ENDPOINT, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ client_info: { current_security: clientData } })
            });

            if (!response.ok) {
                throw new Error(\`HTTP error! status: \${response.status}\`);
            }

            const result = await response.json();
            setAnalysis(result);
        } catch (err) {
            setError(err.message);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="max-w-2xl mx-auto p-4">
            <h1 className="text-2xl font-bold mb-4">CMMC AI Gap Analyzer</h1>
            <form onSubmit={handleSubmit}>
                <textarea
                    className="w-full p-2 border rounded"
                    rows="6"
                    value={clientData}
                    onChange={(e) => setClientData(e.target.value)}
                    placeholder="Enter your current security measures, systems, and data types..."
                />
                <button
                    type="submit"
                    className="mt-2 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:bg-blue-300"
                    disabled={loading}
                >
                    {loading ? 'Analyzing...' : 'Analyze Compliance'}
                </button>
            </form>

            {error && <div className="mt-4 p-2 bg-red-100 text-red-700 rounded">{error}</div>}

            {analysis && (
                <div className="mt-6 p-4 border rounded">
                    <h2 className="text-xl font-semibold">Analysis Results</h2>
                    <pre className="mt-2 bg-gray-50 p-2 rounded whitespace-pre-wrap">{analysis.analysis}</pre>

                    <h3 className="text-lg font-semibold mt-4">Referenced Controls:</h3>
                    <ul className="list-disc list-inside">
                        {analysis.source_controls.map(c => <li key={c.control_id}>{c.control_id}: {c.title}</li>)}
                    </ul>
                </div>
            )}
        </div>
    );
}
EOF

# Update App.js
cat > src/App.js << 'EOF'
import React from 'react';
import CMMCAnalyzer from './CMMCAnalyzer';

function App() {
  return (
    <div className="bg-gray-100 min-h-screen py-8">
      <CMMCAnalyzer />
    </div>
  );
}

export default App;
EOF
`,
        testCommand: `cd frontend && npm start`
    },
    {
        week: "Week 11-12",
        title: "PDF Document Generator (SSP/POAM)",
        commands: `
# Install PDF library
pip install fpdf2

# Create document generator script
cat > src/doc_generator.py << 'EOF'
from fpdf import FPDF
import json

class PDF(FPDF):
    def header(self):
        self.set_font('Arial', 'B', 12)
        self.cell(0, 10, 'System Security Plan (SSP)', 0, 1, 'C')
        self.ln(10)

    def footer(self):
        self.set_y(-15)
        self.set_font('Arial', 'I', 8)
        self.cell(0, 10, f'Page {self.page_no()}', 0, 0, 'C')

def generate_ssp(analysis_data, company_name="Your Company"):
    pdf = PDF()
    pdf.add_page()

    # Title
    pdf.set_font('Arial', 'B', 16)
    pdf.cell(0, 10, f'System Security Plan for {company_name}', 0, 1)
    pdf.ln(5)

    # Analysis Summary
    pdf.set_font('Arial', 'B', 12)
    pdf.cell(0, 10, '1. AI Gap Analysis Summary', 0, 1)
    pdf.set_font('Arial', '', 10)
    pdf.multi_cell(0, 5, analysis_data.get('analysis', 'No analysis provided.'))
    pdf.ln(5)

    # Gaps Identified
    pdf.set_font('Arial', 'B', 12)
    pdf.cell(0, 10, '2. Identified Compliance Gaps', 0, 1)
    pdf.set_font('Arial', '', 10)
    gaps = analysis_data.get('gaps_identified', [])
    if gaps:
        for gap in gaps:
            pdf.multi_cell(0, 5, f"- {gap}")
    else:
        pdf.cell(0, 5, "No specific gaps were automatically extracted.")
    pdf.ln(5)

    # Recommendations
    pdf.set_font('Arial', 'B', 12)
    pdf.cell(0, 10, '3. Recommendations', 0, 1)
    pdf.set_font('Arial', '', 10)
    recommendations = analysis_data.get('recommendations', [])
    if recommendations:
        for rec in recommendations:
            pdf.multi_cell(0, 5, f"- {rec}")
    else:
        pdf.cell(0, 5, "No specific recommendations were automatically extracted.")

    output_filename = "ssp_report.pdf"
    pdf.output(output_filename)
    print(f"✅ SSP document generated: {output_filename}")

def main():
    # Sample data from your RAG pipeline
    sample_analysis = {
        "analysis": "The client has a basic firewall and password policy, but lacks multi-factor authentication for remote access (AC.L2-3.1.8) and does not have a formal incident response plan (IR.L2-3.6.1). There is a gap in media protection, as there's no policy for sanitizing media before disposal (MP.L2-3.8.3).",
        "source_controls": [
            {"control_id": "AC.L2-3.1.8", "title": "Implement multi-factor authentication for remote network access."},
            {"control_id": "IR.L2-3.6.1", "title": "Establish and test incident response capabilities."},
            {"control_id": "MP.L2-3.8.3", "title": "Sanitize or destroy system media containing CUI before disposal."}
        ],
        "gaps_identified": [
            "Gap: No multi-factor authentication for remote access.",
            "Gap: No formal incident response plan.",
            "Missing: Media sanitization policy."
        ],
        "recommendations": [
            "Recommendation: Implement an MFA solution for all remote users.",
            "Should create and test an IR plan.",
            "Recommend developing a media protection policy."
        ]
    }

    print("📄 CMMC Document Generator - Week 11-12 MVP")
    print("=" * 50)
    generate_ssp(sample_analysis)

if __name__ == "__main__":
    main()
EOF`,
        testCommand: `python src/doc_generator.py`
    }
];

const timeSavingsAnalysis = [
    {
        week: "Week 1-2",
        skillsGained: "Dev Environment Mastery",
        immediateSavings: "2-3 hours/day on basic coding tasks",
        cumulativeValue: "Saves 15+ hours/week on all future development",
        clientValue: "Fast iteration = responsive client service",
        businessImpact: "Foundation for all automation - 10x productivity multiplier"
    },
    {
        week: "Week 3-4",
        skillsGained: "AWS Lambda + API Development",
        immediateSavings: "Eliminates server management (4-6 hours/week)",
        cumulativeValue: "Serverless = $0 hosting costs for MVP phase",
        clientValue: "24/7 API availability with zero maintenance",
        businessImpact: "Scalable backend that handles 1 or 1000 clients equally"
    },
    {
        week: "Week 5-6",
        skillsGained: "Vector Database + Document Search",
        immediateSavings: "Replaces 20+ hours of manual CMMC research per client",
        cumulativeValue: "Instant access to all compliance knowledge",
        clientValue: "Comprehensive gap analysis in minutes, not weeks",
        businessImpact: "This alone justifies $7,500 engagement fee vs $50k+ consultant"
    },
    {
        week: "Week 7-8",
        skillsGained: "RAG Pipeline + AI Gap Analysis",
        immediateSavings: "Automates 80% of compliance assessment work",
        cumulativeValue: "Replaces $25k+ of manual consultant analysis",
        clientValue: "Precise, personalized compliance roadmap delivered instantly",
        businessImpact: "Core differentiator: AI-powered insights at consultant quality"
    },
    {
        week: "Week 9-10",
        skillsGained: "React Frontend + User Interface",
        immediateSavings: "Eliminates need for custom demos (5+ hours per prospect)",
        cumulativeValue: "Self-service client portal reduces support time by 70%",
        clientValue: "Professional web app builds trust and confidence",
        businessImpact: "Scalable client acquisition: tool sells itself"
    },
    {
        week: "Week 11-12",
        skillsGained: "Automated Document Generation",
        immediateSavings: "Replaces 40+ hours of manual policy writing per client",
        cumulativeValue: "SSP/POAM generation = $5k-15k value delivered instantly",
        clientValue: "Complete compliance documentation package in 24 hours",
        businessImpact: "This feature alone justifies entire engagement cost"
    },
    {
        week: "Week 13-14",
        skillsGained: "Professional UI/UX Polish",
        immediateSavings: "Reduces client onboarding time by 50%",
        cumulativeValue: "Professional appearance = premium pricing power",
        clientValue: "Enterprise-grade experience builds confidence in your expertise",
        businessImpact: "UI quality directly impacts client retention and referrals"
    },
    {
        week: "Week 15-16",
        skillsGained: "Pilot Validation + Testimonials",
        immediateSavings: "Proven ROI metrics eliminate sales friction",
        cumulativeValue: "3-5 pilot testimonials = credibility for next 50+ clients",
        clientValue: "Risk-free engagement backed by proven results",
        businessImpact: "Validation data enables SBIR funding + venture capital"
    }
];

const templateEfficiencyAnalysis = [
    {
        week: "Week 1-2",
        template: "GitHub Repo Setup + Hello CMMC Script",
        scratchTime: "6-8 hours",
        templateTime: "1 hour",
        timeSavings: "5-7 hours",
        costSavingsUSD: "$250-350",
        risksAvoided: ["Git workflow mistakes", "Project structure problems", "Python environment issues"],
        qualityBoost: "Professional project structure from day 1"
    },
    {
        week: "Week 3-4",
        template: "AWS Lambda API Endpoint",
        scratchTime: "12-15 hours",
        templateTime: "3 hours",
        timeSavings: "9-12 hours",
        costSavingsUSD: "$450-600",
        risksAvoided: ["IAM permission errors", "CORS issues", "Lambda cold start problems"],
        qualityBoost: "Production-ready error handling and HTTP responses"
    },
    {
        week: "Week 5-6",
        template: "Vector Database with CMMC Controls",
        scratchTime: "20-25 hours",
        templateTime: "4 hours",
        timeSavings: "16-21 hours",
        costSavingsUSD: "$800-1,050",
        risksAvoided: ["Embedding dimension mismatches", "Vector upsert failures", "Search optimization issues"],
        qualityBoost: "Optimized chunking strategy and metadata structure"
    },
    {
        week: "Week 7-8",
        template: "RAG Pipeline for Gap Analysis",
        scratchTime: "25-30 hours",
        templateTime: "5 hours",
        timeSavings: "20-25 hours",
        costSavingsUSD: "$1,000-1,250",
        risksAvoided: ["Prompt engineering failures", "Context window limits", "Hallucination issues"],
        qualityBoost: "Robust error handling and response validation"
    },
    {
        week: "Week 9-10",
        template: "React Frontend for AI Analyzer",
        scratchTime: "15-20 hours",
        templateTime: "4 hours",
        timeSavings: "11-16 hours",
        costSavingsUSD: "$550-800",
        risksAvoided: ["State management bugs", "API integration errors", "CSS/styling problems"],
        qualityBoost: "Responsive design with loading states and error handling"
    },
    {
        week: "Week 11-12",
        template: "PDF Document Generator (SSP/POAM)",
        scratchTime: "18-22 hours",
        templateTime: "3 hours",
        timeSavings: "15-19 hours",
        costSavingsUSD: "$750-950",
        risksAvoided: ["PDF formatting issues", "Template rendering problems", "File output errors"],
        qualityBoost: "Professional document layout with proper CMMC structure"
    },
    {
        week: "Week 13-14",
        template: "UI Polish & Component Library",
        scratchTime: "12-16 hours",
        templateTime: "3 hours",
        timeSavings: "9-13 hours",
        costSavingsUSD: "$450-650",
        risksAvoided: ["Design inconsistencies", "Mobile responsiveness issues", "Accessibility problems"],
        qualityBoost: "Enterprise-grade UI with consistent design system"
    },
    {
        week: "Week 15-16",
        template: "Pilot Testing & Analytics Setup",
        scratchTime: "10-12 hours",
        templateTime: "2 hours",
        timeSavings: "8-10 hours",
        costSavingsUSD: "$400-500",
        risksAvoided: ["Data collection errors", "User feedback loss", "Demo recording problems"],
        qualityBoost: "Structured feedback collection and compelling demo materials"
    }
];

const CodeBlock = ({ content, title }) => {
    const handleCopy = () => {
        navigator.clipboard.writeText(content);
        toast.success(`${title} copied to clipboard!`);
    };

    return (
        <div className="relative bg-gray-900 text-white p-4 rounded-md font-mono text-xs my-4">
            <Button
                size="icon"
                variant="ghost"
                className="absolute top-2 right-2 h-7 w-7 text-gray-400 hover:bg-gray-700 hover:text-white"
                onClick={handleCopy}
            >
                <Copy className="h-4 w-4" />
            </Button>
            <pre className="overflow-x-auto">
                <code>{content}</code>
            </pre>
        </div>
    );
};

export default function LocalDevelopmentGuide() {
    // Assuming createPageUrl is a globally available helper or defined elsewhere
    // If not, you might need to implement or import it, e.g., for Next.js Link or react-router-dom
    const createPageUrl = (pageName) => {
        // This is a placeholder implementation.
        // In a real application, this would map to your routing system.
        // For example, in Next.js it might be `/path/to/${pageName}`.
        // For simplicity, we'll return a placeholder string or a simple hash link.
        return `#${pageName.toLowerCase()}`;
    };

    return (
        <div className="space-y-8">
            <CardHeader className="px-0">
                <CardTitle className="text-3xl font-bold flex items-center gap-3"><Github className="w-8 h-8 text-blue-600" /> 16-Week Learn & Build Plan</CardTitle>
                <CardDescription>Your week-by-week guide to building the SBIR MVP. Each section combines targeted learning with immediate, practical implementation.</CardDescription>
            </CardHeader>

            <Alert className="bg-purple-50 border-purple-200">
                <BookOpen className="h-4 w-4 text-purple-600" />
                <AlertTitle className="text-purple-800">Purpose of this Plan</AlertTitle>
                <AlertDescription className="text-purple-700">
                    This 16-week guide is the <strong>comprehensive, from-scratch learning path</strong>. It's designed for mastering the technology stack while building. For the hyper-focused SBIR submission timeline, refer to the <a href={createPageUrl('RealisticTimelineAssessment')} className="font-bold underline">80-Hour Sprint Plan</a>.
                </AlertDescription>
            </Alert>

            <Card className="bg-blue-50 border-blue-200">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2"><Rocket className="text-blue-700" /> Your Weekly Sprint Plan</CardTitle>
                    <CardDescription>Follow this plan to build your product and master the tech stack simultaneously.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    {weeklyPlan.map((week, index) => (
                        <motion.div
                            key={week.week}
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: index * 0.05 }}
                            className="border rounded-lg p-6 bg-white shadow-sm"
                        >
                            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-4">
                                <h3 className="text-lg font-bold text-gray-800">{week.week}: {week.focus}</h3>
                                <Badge variant="secondary" className="mt-2 sm:mt-0">{week.deliverable.split(' ')[0]} Milestone</Badge>
                            </div>

                            <div className="grid md:grid-cols-2 gap-6">
                                <div>
                                    <h4 className="font-semibold text-green-700 mb-2 flex items-center gap-2">
                                        <BookOpen className="w-4 h-4" />
                                        Learn This Week
                                    </h4>
                                    <ul className="space-y-1 text-sm">
                                        {week.learning.map((item, i) => (
                                            <li key={i} className="flex items-start gap-2">
                                                <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                                                <span>{item}</span>
                                            </li>
                                        ))}
                                    </ul>
                                </div>

                                <div>
                                    <h4 className="font-semibold text-blue-700 mb-2 flex items-center gap-2">
                                        <Zap className="w-4 h-4" />
                                        Build This Week
                                    </h4>
                                    <ul className="space-y-1 text-sm">
                                        {week.building.map((item, i) => (
                                            <li key={i} className="flex items-start gap-2">
                                                <Rocket className="w-4 h-4 text-blue-500 mt-0.5 flex-shrink-0" />
                                                <span>{item}</span>
                                            </li>
                                        ))}
                                    </ul>
                                </div>
                            </div>

                            <div className="mt-4 p-3 bg-yellow-50 rounded-lg border border-yellow-200">
                                <h5 className="font-semibold text-yellow-800 mb-1">Weekly Deliverable:</h5>
                                <p className="text-sm text-yellow-700">{week.deliverable}</p>
                            </div>

                            <div className="mt-4 flex flex-wrap gap-2">
                                {week.links.map((link, i) => (
                                    <Button key={i} asChild variant="outline" size="sm">
                                        <a href={link} target="_blank" rel="noopener noreferrer" className="flex items-center">
                                            Resource {i + 1} <ArrowRight className="w-3 h-3 ml-1" />
                                        </a>
                                    </Button>
                                ))}
                            </div>
                        </motion.div>
                    ))}
                </CardContent>
            </Card>

            {/* New Time Savings Analysis Section */}
            <Card className="bg-green-50 border-green-200 mt-8">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2"><Zap className="text-green-700" /> Cumulative Time Savings & ROI Analysis</CardTitle>
                    <CardDescription>See how each week's learning investment pays off immediately and compounds over time.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    {timeSavingsAnalysis.map((analysis, index) => (
                        <motion.div
                            key={analysis.week}
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: index * 0.1 }}
                            className="border rounded-lg p-6 bg-white shadow-sm"
                        >
                            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-4">
                                <h3 className="text-lg font-bold text-gray-800">{analysis.week}: {analysis.skillsGained}</h3>
                                <Badge variant="outline" className="mt-2 sm:mt-0 bg-green-100 text-green-800">ROI Multiplier</Badge>
                            </div>

                            <div className="grid md:grid-cols-2 gap-6">
                                <div>
                                    <h4 className="font-semibold text-blue-700 mb-2 flex items-center gap-2">
                                        <Clock className="w-4 h-4" />
                                        Immediate Time Savings
                                    </h4>
                                    <p className="text-sm mb-3">{analysis.immediateSavings}</p>

                                    <h4 className="font-semibold text-purple-700 mb-2 flex items-center gap-2">
                                        <Target className="w-4 h-4" />
                                        Cumulative Value
                                    </h4>
                                    <p className="text-sm">{analysis.cumulativeValue}</p>
                                </div>

                                <div>
                                    <h4 className="font-semibold text-orange-700 mb-2 flex items-center gap-2">
                                        <CheckCircle className="w-4 h-4" />
                                        Client Value Delivered
                                    </h4>
                                    <p className="text-sm mb-3">{analysis.clientValue}</p>

                                    <h4 className="font-semibold text-green-700 mb-2 flex items-center gap-2">
                                        <DollarSign className="w-4 h-4" />
                                        Business Impact
                                    </h4>
                                    <p className="text-sm font-medium">{analysis.businessImpact}</p>
                                </div>
                            </div>
                        </motion.div>
                    ))}

                    <Alert className="bg-yellow-50 border-yellow-200 mt-6">
                        <Rocket className="h-4 w-4 text-yellow-600" />
                        <AlertTitle className="text-yellow-800">Total ROI by Week 16</AlertTitle>
                        <AlertDescription className="text-yellow-700">
                            <strong>Time Investment:</strong> 320 hours (20 hrs/week × 16 weeks)<br/>
                            <strong>Value Created:</strong> $100k+ in automated consulting capabilities<br/>
                            <strong>ROI:</strong> 300%+ return on learning investment<br/>
                            <strong>Ongoing Savings:</strong> 60+ hours saved per client engagement
                        </AlertDescription>
                    </Alert>
                </CardContent>
            </Card>

            {/* Template Efficiency Analysis */}
            <Card className="bg-blue-50 border-blue-200 mt-8">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2"><Code className="text-blue-700" /> Code Template Efficiency Analysis</CardTitle>
                    <CardDescription>Detailed breakdown of time and cost savings for each week's code template.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    {templateEfficiencyAnalysis.map((template, index) => (
                        <motion.div
                            key={template.week}
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: index * 0.1 }}
                            className="border rounded-lg p-6 bg-white shadow-sm"
                        >
                            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-4">
                                <h3 className="text-lg font-bold text-blue-800">{template.week}: {template.template}</h3>
                                <Badge variant="outline" className="mt-2 sm:mt-0 bg-blue-100 text-blue-800">
                                    {template.timeSavings} saved
                                </Badge>
                            </div>

                            <div className="grid md:grid-cols-3 gap-6">
                                <div>
                                    <h4 className="font-semibold text-gray-700 mb-2">⏱️ Time Analysis</h4>
                                    <ul className="text-sm space-y-1">
                                        <li><strong>From Scratch:</strong> {template.scratchTime}</li>
                                        <li><strong>Using Template:</strong> {template.templateTime}</li>
                                        <li className="text-green-700 font-semibold"><strong>Time Saved:</strong> {template.timeSavings}</li>
                                    </ul>
                                </div>

                                <div>
                                    <h4 className="font-semibold text-gray-700 mb-2">💰 Cost Impact</h4>
                                    <ul className="text-sm space-y-1">
                                        <li className="text-green-700 font-semibold"><strong>Cost Savings:</strong> {template.costSavingsUSD}</li>
                                        <li className="text-xs text-gray-500">Based on $50/hour developer rate</li>
                                    </ul>
                                </div>

                                <div>
                                    <h4 className="font-semibold text-gray-700 mb-2">🛡️ Risk Mitigation</h4>
                                    <ul className="text-sm space-y-1">
                                        {template.risksAvoided.map((risk, i) => (
                                            <li key={i} className="text-red-600">• {risk}</li>
                                        ))}
                                    </ul>
                                </div>
                            </div>

                            <div className="mt-4 p-3 bg-green-50 rounded-lg border border-green-200">
                                <h5 className="font-semibold text-green-800 mb-1">✨ Quality Boost:</h5>
                                <p className="text-sm text-green-700">{template.qualityBoost}</p>
                            </div>
                        </motion.div>
                    ))}

                    {/* Summary Card */}
                    <Alert className="bg-green-50 border-green-200">
                        <CheckCircle className="h-4 w-4" />
                        <AlertTitle className="text-green-800">Total Template ROI Summary</AlertTitle>
                        <AlertDescription className="text-green-700">
                            <div className="grid md:grid-cols-2 gap-4 mt-3">
                                <div>
                                    <strong>Total Time Saved:</strong> 93-123 hours<br/>
                                    <strong>Total Cost Savings:</strong> $4,650-6,150<br/>
                                    <strong>Efficiency Gain:</strong> 4-6x faster development
                                </div>
                                <div>
                                    <strong>Risk Reduction:</strong> 20+ common mistakes avoided<br/>
                                    <strong>Quality Improvement:</strong> Production-ready code from day 1<br/>
                                    <strong>SBIR Value:</strong> Demonstrates rapid prototyping capability
                                </div>
                            </div>
                        </AlertDescription>
                    </Alert>
                </CardContent>
            </Card>

            <Card className="bg-green-50 border-green-200">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2"><Code className="text-green-700" /> Ready-to-Use Code Templates</CardTitle>
                    <CardDescription>Copy-paste code for each week's deliverable. Each template is fully functional and ready to deploy.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-8">
                    {weeklyCodeTemplates.map((template, index) => (
                        <motion.div
                            key={template.week}
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: index * 0.1 }}
                            className="border rounded-lg p-6 bg-white shadow-sm"
                        >
                            <div className="flex items-center justify-between mb-4">
                                <h3 className="text-lg font-bold text-green-800">{template.week}: {template.title}</h3>
                                <Badge variant="outline" className="bg-green-100 text-green-800">Production Ready</Badge>
                            </div>

                            <CodeBlock title={`${template.week} Commands`} content={template.commands} />

                            <div className="mt-4 p-3 bg-blue-50 rounded-lg border border-blue-200">
                                <h5 className="font-semibold text-blue-800 mb-2">Test Your Implementation:</h5>
                                <code className="text-sm text-blue-700 bg-blue-100 px-2 py-1 rounded">{template.testCommand}</code>
                            </div>
                        </motion.div>
                    ))}

                    <Alert className="bg-yellow-50 border-yellow-200">
                        <Zap className="h-4 w-4 text-yellow-600" />
                        <AlertTitle className="text-yellow-800">Weeks 13-16 Code Templates</AlertTitle>
                        <AlertDescription className="text-yellow-700">
                            Additional templates for UI polish, integration, and SBIR demo preparation will be added as you progress through the earlier weeks.
                        </AlertDescription>
                    </Alert>
                </CardContent>
            </Card>

            <Tabs defaultValue="foundations" className="w-full">
                <TabsList className="grid w-full grid-cols-2 md:grid-cols-6"> {/* Adjusted grid-cols to accommodate 6 tabs */}
                    <TabsTrigger value="foundations">Dev Foundations</TabsTrigger>
                    <TabsTrigger value="ai-ml">AI & RAG</TabsTrigger>
                    <TabsTrigger value="cloud">AWS & Cloud</TabsTrigger>
                    <TabsTrigger value="frontend">React & UI</TabsTrigger>
                    <TabsTrigger value="project-setup">Project Setup</TabsTrigger>
                    <TabsTrigger value="pricing">Project Pricing</TabsTrigger> {/* Added Pricing Tab Trigger */}
                </TabsList>

                <TabsContent value="foundations">
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2"><Terminal />Reference: Development Foundations</CardTitle>
                            <CardDescription>Master the core tools before diving into AI development.</CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-6">
                            <div className="grid md:grid-cols-2 gap-6">
                                <div className="p-4 border rounded-lg">
                                    <h4 className="font-semibold mb-3">VS Code & Git Basics</h4>
                                    <ul className="space-y-2 text-sm">
                                        <li><strong>VS Code Tutorial:</strong> <br/><a href="https://code.visualstudio.com/docs/getstarted/introvideos" className="text-blue-600 hover:underline" target="_blank">Official VS Code Getting Started</a></li>
                                        <li><strong>Git Fundamentals:</strong> <br/><a href="https://www.freecodecamp.org/news/how-to-consume-rest-apis-in-react/" className="text-blue-600 hover:underline" target="_blank">FreeCodeCamp Git Tutorial</a></li>
                                        <li><strong>GitHub Workflow:</strong> <br/><a href="https://guides.github.com/introduction/flow/" className="text-blue-600 hover:underline" target="_blank">GitHub Flow Guide</a></li>
                                        <li><strong>Interactive Git:</strong> <br/><a href="https://learngitbranching.js.org/" className="text-blue-600 hover:underline" target="_blank">Learn Git Branching (Interactive)</a></li>
                                    </ul>
                                </div>
                                <div className="p-4 border rounded-lg">
                                    <h4 className="font-semibold mb-3">Python Refresher for AI</h4>
                                    <ul className="space-y-2 text-sm">
                                        <li><strong>Python for Data Science:</strong> <br/><a href="https://www.kaggle.com/learn/python" className="text-blue-600 hover:underline" target="_blank">Kaggle Python Course (Free)</a></li>
                                        <li><strong>Python Libraries:</strong> <br/><a href="https://www.kaggle.com/learn/pandas" className="text-blue-600 hover:underline" target="_blank">Pandas on Kaggle</a></li>
                                        <li><strong>API Development:</strong> <br/><a href="https://fastapi.tiangolo.com/tutorial/" className="text-blue-600 hover:underline" target="_blank">FastAPI Tutorial</a></li>
                                        <li><strong>Environment Setup:</strong> <br/><a href="https://docs.conda.io/en/latest/miniconda.html" className="text-blue-600 hover:underline" target="_blank">Miniconda Installation</a></li>
                                    </ul>
                                </div>
                            </div>
                            <Alert>
                                <Terminal className="h-4 w-4" />
                                <AlertTitle>Practical Goal: Week 2</AlertTitle>
                                <AlertDescription>By the end of week 2, you should be able to create a simple Python script, commit it to GitHub, and make changes using VS Code.</AlertDescription>
                            </Alert>
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="ai-ml">
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2"><Package />Reference: AI, RAG, & Vector Databases</CardTitle>
                            <CardDescription>Master the AI technologies at the core of your CMMC solution.</CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-6">
                            <div className="grid gap-6">
                                <div className="p-4 border-l-4 border-blue-500 bg-blue-50">
                                    <h4 className="font-semibold text-blue-800 mb-3">RAG (Retrieval Augmented Generation)</h4>
                                    <ul className="space-y-2 text-sm text-blue-700">
                                        <li><strong>RAG Fundamentals:</strong> <br/><a href="https://huggingface.co/learn/nlp-course/chapter7/1" className="text-blue-600 hover:underline" target="_blank">Hugging Face NLP Course - RAG</a></li>
                                        <li><strong>LangChain RAG Tutorial:</strong> <br/><a href="https://python.langchain.com/docs/use_cases/question_answering/" className="text-blue-600 hover:underline" target="_blank">LangChain Q&A with RAG</a></li>
                                        <li><strong>Practical RAG:</strong> <br/><a href="https://www.deeplearning.ai/short-courses/building-applications-vector-databases/" className="text-blue-600 hover:underline" target="_blank">DeepLearning.AI Vector DB Course</a></li>
                                        <li><strong>RAG with Documents:</strong> <br/><a href="https://github.com/langchain-ai/langchain/blob/master/docs/docs/use_cases/question_answering/how_to/document-context-aware-QA.ipynb" className="text-blue-600 hover:underline" target="_blank">Document Q&A Notebook</a></li>
                                    </ul>
                                </div>

                                <div className="p-4 border-l-4 border-purple-500 bg-purple-50">
                                    <h4 className="font-semibold text-purple-800 mb-3">Vector Databases & Embeddings</h4>
                                    <ul className="space-y-2 text-sm text-purple-700">
                                        <li><strong>Pinecone Tutorial:</b> <br/><a href="https://docs.pinecone.io/docs/quickstart" className="text-purple-600 hover:underline" target="_blank">Pinecone Quickstart</a></li>
                                        <li><strong>Alternative (Weaviate):</strong> <br/><a href="https://weaviate.io/developers/weaviate/quickstart" className="text-purple-600 hover:underline" target="_blank">Weaviate Getting Started</a></li>
                                        <li><strong>Embeddings Explained:</strong> <br/><a href="https://platform.openai.com/docs/guides/embeddings" className="text-purple-600 hover:underline" target="_blank">OpenAI Embeddings Guide</a></li>
                                        <li><strong>Practical Example:</strong> <br/><a href="https://cookbook.openai.com/examples/question_answering_using_embeddings" className="text-purple-600 hover:underline" target="_blank">OpenAI Q&A Cookbook</a></li>
                                    </ul>
                                </div>

                                <div className="p-4 border-l-4 border-green-500 bg-green-50">
                                    <h4 className="font-semibold text-green-800 mb-3">LangChain & LlamaIndex</h4>
                                    <ul className="space-y-2 text-sm text-green-700">
                                        <li><strong>LangChain Basics:</strong> <br/><a href="https://python.langchain.com/docs/get_started/introduction" className="text-green-600 hover:underline" target="_blank">LangChain Introduction</a></li>
                                        <li><strong>LlamaIndex Tutorial:</strong> <br/><a href="https://docs.llamaindex.ai/en/stable/getting_started/starter_example/" className="text-green-600 hover:underline" target="_blank">LlamaIndex Starter Example</a></li>
                                        <li><strong>Choose Your Framework:</strong> <br/><a href="https://blog.langchain.dev/langchain-vs-llamaindex/" className="text-green-600 hover:underline" target="_blank">LangChain vs LlamaIndex Comparison</a></li>
                                        <li><strong>Document Loading:</strong> <br/><a href="https://python.langchain.com/docs/modules/data_connection/document_loaders/" className="text-green-600 hover:underline" target="_blank">LangChain Document Loaders</a></li>
                                    </ul>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="cloud">
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2"><Cloud />Reference: AWS & Cloud Infrastructure</CardTitle>
                            <CardDescription>Learn to deploy and scale your AI application in the cloud.</CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-6">
                            <div className="grid md:grid-cols-2 gap-6">
                                <div className="p-4 border rounded-lg">
                                    <h4 className="font-semibold mb-3">AWS Fundamentals</h4>
                                    <ul className="space-y-2 text-sm">
                                        <li><strong>AWS Free Tier Setup:</strong> <br/><a href="https://aws.amazon.com/free/" className="text-blue-600 hover:underline" target="_blank">Create AWS Free Account</a></li>
                                        <li><strong>AWS Fundamentals Course:</strong> <br/><a href="https://explore.skillbuilder.aws/learn/course/134/play/31418/aws-cloud-practitioner-essentials" className="text-blue-600 hover:underline" target="_blank">AWS Cloud Practitioner Essentials</a></li>
                                        <li><strong>Lambda for Beginners:</strong> <br/><a href="https://docs.aws.amazon.com/lambda/latest/dg/getting-started.html" className="text-blue-600 hover:underline" target="_blank">AWS Lambda Getting Started</a></li>
                                        <li><strong>S3 & IAM:</strong> <br/><a href="https://aws.amazon.com/getting-started/hands-on/backup-files-to-amazon-s3/" className="text-blue-600 hover:underline" target="_blank">S3 Hands-on Tutorial</a></li>
                                    </ul>
                                </div>
                                <div className="p-4 border rounded-lg">
                                    <h4 className="font-semibold mb-3">Serverless AI Deployment</h4>
                                    <ul className="space-y-2 text-sm">
                                        <li><strong>API Gateway + Lambda:</strong> <br/><a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/api-gateway-create-api-as-simple-proxy-for-lambda.html" className="text-blue-600 hover:underline" target="_blank">API Gateway Tutorial</a></li>
                                        <li><strong>SageMaker Basics:</strong> <br/><a href="https://docs.aws.amazon.com/sagemaker/latest/dg/gs.html" className="text-blue-600 hover:underline" target="_blank">SageMaker Getting Started</a></li>
                                        <li><strong>Docker & ECR:</strong> <br/><a href="https://docs.aws.amazon.com/AmazonECR/latest/userguide/getting-started-cli.html" className="text-blue-600 hover:underline" target="_blank">ECR Getting Started</a></li>
                                        <li><strong>Cost Management:</strong> <br/><a href="https://aws.amazon.com/aws-cost-management/aws-budgets/" className="text-blue-600 hover:underline" target="_blank">AWS Budgets Setup</a></li>
                                    </ul>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="frontend">
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2"><Laptop />Reference: React & Frontend Development</CardTitle>
                            <CardDescription>Build the user interface for your AI compliance tool.</CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-6">
                            <div className="grid md:grid-cols-2 gap-6">
                                <div className="p-4 border rounded-lg">
                                    <h4 className="font-semibold mb-3">React Essentials</h4>
                                    <ul className="space-y-2 text-sm">
                                        <li><strong>React Tutorial:</strong> <br/><a href="https://react.dev/learn" className="text-blue-600 hover:underline" target="_blank">Official React Tutorial</a></li>
                                        <li><strong>Interactive Learning:</strong> <br/><a href="https://scrimba.com/learn/learnreact" className="text-blue-600 hover:underline" target="_blank">Scrimba React Course</a></li>
                                        <li><strong>Hooks Deep Dive:</strong> <br/><a href="https://react.dev/reference/react" className="text-blue-600 hover:underline" target="_blank">React Hooks Reference</a></li>
                                        <li><strong>API Integration:</strong> <br/><a href="https://www.freecodecamp.org/news/how-to-consume-rest-apis-in-react/" className="text-blue-600 hover:underline" target="_blank">React API Tutorial</a></li>
                                    </ul>
                                </div>
                                <div className="p-4 border rounded-lg">
                                    <h4 className="font-semibold mb-3">UI Libraries & Styling</h4>
                                    <ul className="space-y-2 text-sm">
                                        <li><strong>Tailwind CSS:</strong> <br/><a href="https://tailwindcss.com/docs/installation" className="text-blue-600 hover:underline" target="_blank">Tailwind CSS Docs</a></li>
                                        <li><strong>shadcn/ui Components:</strong> <br/><a href="https://ui.shadcn.com/docs" className="text-blue-600 hover:underline" target="_blank">shadcn/ui Documentation</a></li>
                                        <li><strong>Form Handling:</strong> <br/><a href="https://react-hook-form.com/get-started" className="text-blue-600 hover:underline" target="_blank">React Hook Form</a></li>
                                        <li><strong>Charts & Visualization:</strong> <br/><a href="https://recharts.org/en-US/" className="text-blue-600 hover:underline" target="_blank">Recharts Documentation</a></li>
                                    </ul>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="project-setup">
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2"><FolderTree />Reference: Complete Project Setup</CardTitle>
                            <CardDescription>Put it all together with a complete development environment.</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-6">
                                <div className="p-4 bg-yellow-50 rounded-lg border-l-4 border-yellow-500">
                                    <h4 className="font-semibold text-yellow-800 mb-2">Complete Full-Stack Tutorial</h4>
                                    <p className="text-sm text-yellow-700 mb-3">This tutorial combines everything above into a working AI application:</p>
                                    <ul className="space-y-2 text-sm text-yellow-700">
                                        <li><strong>Full-Stack AI App:</strong> <br/><a href="https://www.youtube.com/watch?v=yQBw8zBTI6E" className="text-yellow-600 hover:underline" target="_blank">Build AI Chat App (YouTube)</a></li>
                                        <li><strong>RAG Implementation:</strong> <br/><a href="https://www.deeplearning.ai/short-courses/langchain-chat-with-your-data/" className="text-yellow-600 hover:underline" target="_blank">DeepLearning.AI - Chat with Data</a></li>
                                        <li><strong>Deploy to Production:</strong> <br/><a href="https://vercel.com/guides/deploying-react-with-vercel" className="text-yellow-600 hover:underline" target="_blank">Vercel React Deployment</a></li>
                                    </ul>
                                </div>

                                <CodeBlock title="Starter Commands" content={
`# Create your project structure
mkdir cmmc-ai-tool && cd cmmc-ai-tool
git init

# Frontend setup
npx create-react-app frontend
cd frontend && npm install @tailwindcss/forms lucide-react

# Backend setup (Python)
mkdir backend && cd backend
python -m venv venv
source venv/bin/activate  # On Windows: venv\\Scripts\\activate
pip install fastapi uvicorn langchain pinecone-client openai

# First commit
git add .
git commit -m "Initial project setup"`
                                } />

                                <Alert>
                                    <CheckCircle className="h-4 w-4" />
                                    <AlertTitle>Learning Path Summary</AlertTitle>
                                    <AlertDescription>
                                        Follow this sequence: Dev Tools (Weeks 1-2) → AI Foundations (Weeks 3-6) → Cloud Deployment (Weeks 7-8) → Frontend (Weeks 9-10) → Integration & Testing (Weeks 11-12). Budget 2-4 hours per day for consistent progress.
                                    </AlertDescription>
                                </Alert>
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="pricing">
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2"><DollarSign />Reference: Project Pricing</CardTitle>
                            <CardDescription>Understanding the investment and potential returns for your CMMC AI Tool.</CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-6">
                            <div className="p-4 bg-yellow-50 rounded-lg border-l-4 border-yellow-500">
                                <h4 className="font-semibold text-yellow-800 mb-2">Cost Breakdown &amp; Value Proposition</h4>
                                <ul className="text-sm text-yellow-700 space-y-2">
                                    <li><strong>Development Cost:</strong> For 16 weeks, assuming a developer rate of $50/hour and 20 hours/week, the raw development cost is $16,000.</li>
                                    <li><strong>Template Value:</strong> The provided code templates and structured learning significantly reduce this, offering an efficiency gain of 4-6x.</li>
                                    <li><strong>Market Value:</strong> Building a tool that automates CMMC compliance services positions you to charge premium prices (e.g., $7,500 - $25,000 per client engagement).</li>
                                    <li><strong>SBIR Application Advantage:</strong> A working MVP with demonstrated ROI drastically strengthens your SBIR grant application, making you highly competitive for non-dilutive funding.</li>
                                </ul>
                            </div>
                            <div className="grid md:grid-cols-2 gap-6">
                                <div className="p-4 border rounded-lg">
                                    <h4 className="font-semibold mb-3">Potential Revenue Streams</h4>
                                    <ul className="space-y-2 text-sm">
                                        <li><strong>SaaS Subscription:</strong> Monthly/annual fees for using the CMMC AI Tool.</li>
                                        <li><strong>Consulting Services:</strong> Offer bespoke compliance guidance powered by the tool.</li>
                                        <li><strong>Document Generation:</strong> Charge for automated SSP/POAM generation.</li>
                                        <li><strong>Training &amp; Support:</strong> Provide workshops and ongoing support.</li>
                                    </ul>
                                </div>
                                <div className="p-4 border rounded-lg">
                                    <h4 className="font-semibold mb-3">Funding Opportunities</h4>
                                    <ul className="space-y-2 text-sm">
                                        <li><strong>SBIR/STTR Grants:</strong> Highly relevant for government-focused innovation.</li>
                                        <li><strong>Angel Investors / VCs:</strong> Attractive for scalable B2B SaaS.</li>
                                        <li><strong>Self-Funding / Bootstrapping:</strong> Leveraging early client revenue.</li>
                                        <li><strong>Defense Accelerators:</strong> Programs focused on defense tech startups.</li>
                                    </ul>
                                </div>
                            </div>
                            <Alert>
                                <DollarSign className="h-4 w-4" />
                                <AlertTitle>Strategic Financial Goal</AlertTitle>
                                <AlertDescription>
                                    Your objective is to turn this development effort into a profitable business. Focus on demonstrating clear value to potential clients and funders through your MVP.
                                </AlertDescription>
                            </Alert>
                        </CardContent>
                    </Card>
                </TabsContent>
            </Tabs>

            <Card>
                <CardHeader>
                    <CardTitle>Free vs. Paid Resources Budget</CardTitle>
                    <CardDescription>Recommended investment in learning resources</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="grid md:grid-cols-3 gap-4">
                        <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                            <h4 className="font-semibold text-green-800">Free Resources (~$0)</h4>
                            <ul className="text-sm text-green-700 mt-2 space-y-1">
                                <li>• Official documentation</li>
                                <li>• YouTube tutorials</li>
                                <li>• FreeCodeCamp courses</li>
                                <li>• AWS Free Tier</li>
                                <li>• GitHub free account</li>
                            </ul>
                        </div>
                        <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                            <h4 className="font-semibold text-blue-800">Premium Courses (~$100)</h4>
                            <ul className="text-sm text-blue-700 mt-2 space-y-1">
                                <li>• DeepLearning.AI specialization</li>
                                <li>• Scrimba React course</li>
                                <li>• AWS training credits</li>
                                <li>• Pinecone Pro account</li>
                            </ul>
                        </div>
                        <div className="p-4 bg-purple-50 rounded-lg border border-purple-200">
                            <h4 className="font-semibold text-purple-800">Development Tools (~$100)</h4>
                            <ul className="text-sm text-purple-700 mt-2 space-y-1">
                                <li>• GitHub Pro subscription</li>
                                <li>• VS Code extensions</li>
                                <li>• API credits (OpenAI, etc.)</li>
                                <li>• Domain name & hosting</li>
                            </ul>
                        </div>
                    </div>
                </CardContent>
            </Card>
            <Card className="mt-8">
                <CardHeader>
                    <CardTitle className="flex items-center gap-3"><Rocket className="w-6 h-6 text-blue-600"/>Your Strategic Action Plan</CardTitle>
                    <CardDescription>This technical guide is your primary asset. Now, see how it fits into the bigger picture for SBIR success.</CardDescription>
                </CardHeader>
                <CardContent>
                    {/* Using Button asChild with an <a> tag for navigation, consistent with existing external links */}
                    <Button asChild className="w-full text-lg py-6">
                        <a href={createPageUrl('BootstrapActionPlan')}>
                            Go to Bootstrap Action Plan &amp; Timeline Reality Check <ArrowRight className="w-5 h-5 ml-2" />
                        </a>
                    </Button>
                </CardContent>
            </Card>
        </div>
    );
}
