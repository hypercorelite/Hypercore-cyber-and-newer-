import React from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Check, Users, Scale, Umbrella } from "lucide-react";
import { motion } from "framer-motion";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function PartnershipTiers() {
    const partnershipTiers = [
        {
            title: "Client",
            description: "For companies seeking CMMC compliance & cyber-risk solutions.",
            price: "Project-Based",
            features: [
                "CMMC Readiness Assessment",
                "AI-Driven Gap Analysis",
                "Managed Compliance Service",
                "Direct support from HyperCore team",
            ],
            buttonText: "Request a Quote",
            buttonVariant: "outline",
            href: createPageUrl('CMMCDashboard')
        },
        {
            title: "Legal Partner",
            description: "For law firms specializing in government contracts and technology.",
            price: "Trade for Legal Services",
            features: [
                "Unlimited access to Contract Intelligence AI",
                "Co-branded client-facing reports",
                "Priority access to new legal tech tools",
                "Referral network for compliance clients",
            ],
            buttonText: "Propose Partnership",
            buttonVariant: "default",
            bgColor: "bg-purple-50",
            borderColor: "border-purple-600",
            icon: Scale,
            href: createPageUrl('AITrainingPipeline', {tab: 'lawyer-tools'})
        },
        {
            title: "Insurance Partner",
            description: "For brokers and carriers focused on cyber liability.",
            price: "Trade for Insurance Policies",
            features: [
                "Unlimited access to Policy Advisor AI",
                "Data-driven risk reports for underwriting",
                "Reduced loss-ratios for your portfolio",
                "A powerful tool to win and retain clients",
            ],
            buttonText: "Propose Partnership",
            buttonVariant: "default",
            bgColor: "bg-blue-50",
            borderColor: "border-blue-600",
            icon: Umbrella,
            href: createPageUrl('AITrainingPipeline', {tab: 'insurance-tools'})
        },
    ];

    return (
        <div className="min-h-screen bg-gray-50 p-6">
            <div className="max-w-6xl mx-auto">
                <motion.div
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="text-center mb-12"
                >
                    <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-3 flex items-center justify-center gap-3">
                        <Users className="w-10 h-10 text-green-600" />
                        Partner with HyperCore
                    </h1>
                    <p className="text-lg text-gray-600 max-w-3xl mx-auto">
                        We don't sell software. We build valuable AI assets and trade them for the services we need to grow. Join our value-exchange ecosystem.
                    </p>
                </motion.div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-stretch">
                    {partnershipTiers.map((tier, index) => (
                        <motion.div 
                            key={index}
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: index * 0.15 }}
                            className="h-full"
                        >
                            <Card className={`h-full flex flex-col ${tier.borderColor ? `border-2 ${tier.borderColor}` : 'border-gray-200'} ${tier.bgColor || 'bg-white'}`}>
                                <CardHeader>
                                    <div className="flex items-center gap-3">
                                        {tier.icon && <tier.icon className={`w-8 h-8 ${tier.borderColor?.replace('border-', 'text-')}`} />}
                                        <CardTitle className="text-2xl">{tier.title}</CardTitle>
                                    </div>
                                    <CardDescription>{tier.description}</CardDescription>
                                </CardHeader>
                                <CardContent className="flex-grow space-y-4 flex flex-col">
                                    <div className="text-3xl font-bold">
                                        {tier.price}
                                    </div>
                                    <ul className="space-y-2 text-sm text-gray-700 flex-grow">
                                        {tier.features.map((feature, fIndex) => (
                                            <li key={fIndex} className="flex items-start gap-2">
                                                <Check className="w-4 h-4 mt-0.5 text-green-500 flex-shrink-0" />
                                                <span>{feature}</span>
                                            </li>
                                        ))}
                                    </ul>
                                    <Button asChild variant={tier.buttonVariant} className="w-full mt-auto">
                                        <Link to={tier.href}>{tier.buttonText}</Link>
                                    </Button>
                                </CardContent>
                            </Card>
                        </motion.div>
                    ))}
                </div>
            </div>
        </div>
    );
}