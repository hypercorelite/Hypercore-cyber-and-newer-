
import React, { useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { ArrowRight, Bot, DollarSign, Users, GanttChartSquare, Layers, HelpCircle, Zap, Award } from 'lucide-react'; // Added Award
import { motion } from 'framer-motion';
import ValuePropositionComparison from '../components/charts/ValuePropositionComparison';
import ROICalculator from '../components/ROICalculator';
import { Badge } from "@/components/ui/badge";

const traditionalConsulting = {
    title: "Traditional Consultants",
    description: "The old way: slow, expensive, and high-risk.",
    badge: "THE MANUAL MODEL",
    items: [
        { text: "Costs $50,000 - $200,000+ per engagement.", included: false },
        { text: "Takes 12-18 months, missing current deadlines.", included: false },
        { text: "High risk of human error in documentation.", included: false },
        { text: "Creates bottlenecks; knowledge leaves with the consultant.", included: false },
        { text: "Hourly billing model incentivizes slow, inefficient work.", included: false },
        { text: "Produces static documents that are instantly outdated.", included: false }
    ]
};

const grcSoftware = {
    title: "GRC Software Platforms",
    description: "An expensive, empty toolbox requiring an expert.",
    badge: "THE DIY MODEL",
    items: [
        { text: "High annual subscription costs ($24k - $120k).", included: false },
        { text: "Requires a dedicated, expert in-house hire to operate.", included: false },
        { text: "Does NOT generate your policies or SSP for you.", included: false },
        { text: "You still do all the work; it's just a complex spreadsheet.", included: false },
        { text: "Steep learning curve and months-long implementation.", included: false },
        { text: "Support is for the software, not your actual compliance.", included: false }
    ]
};

const hypercoreAI = {
    title: "HyperCore AI Automation",
    description: "The new model: fast, accurate, and cost-effective.",
    badge: "THE AUTOMATION MODEL",
    isFeatured: true,
    items: [
        { text: "Free to use via our SBIR Partnership Program.", included: true },
        { text: "Delivers audit-preparation documents in hours, not months.", included: true },
        { text: "Productized expertise eliminates human error and gaps.", included: true },
        { text: "Instantly generates your SSP drafts, policy templates, and gap analysis.", included: true },
        { text: "Automated 90-Day Success Plan guides implementation.", included: true },
        { text: "Builds a sustainable, internal compliance capability.", included: true }
    ]
};

export default function CompetitiveComparison() {
    useEffect(() => {
        // OPTIMIZED Meta Tags for competitive comparison
        document.title = "CMMC AI vs Consultants vs GRC Tools: Complete Comparison | HyperCore";
        document.querySelector('meta[name="description"]')?.setAttribute('content',
            'Compare CMMC compliance: AI automation vs $200K consultants vs complex GRC tools. See cost, time, and ROI analysis for DoD contractors.');

        // Enhanced Service Schema WITHOUT fake ratings (platform just launched)
        const structuredData = {
            "@context": "https://schema.org",
            "@type": "Service",
            "name": "CMMC Compliance Automation Platform",
            "provider": {
                "@type": "Organization",
                "name": "HyperCore CMMC Training",
                "url": "https://hypercorecyber.com"
            },
            "description": "AI-first CMMC Level 2 compliance automation platform comparison with traditional consultants and GRC software solutions",
            "serviceType": "CMMC Compliance Automation",
            "audience": {
                "@type": "Audience",
                "audienceType": "DoD contractors, defense subcontractors, government contractors"
            },
            "offers": {
                "@type": "Offer",
                "price": "0",
                "priceCurrency": "USD",
                "description": "Free trial until December 5th, 2025",
                "validThrough": "2025-12-05"
            },
            "hasOfferCatalog": {
                "@type": "OfferCatalog",
                "name": "CMMC Compliance Solutions",
                "itemListElement": [
                    {
                        "@type": "Offer",
                        "itemOffered": {
                            "@type": "Service",
                            "name": "AI-Powered CMMC Assessment",
                            "description": "90% faster than consultants"
                        },
                        "priceSpecification": {
                            "@type": "PriceSpecification",
                            "price": "Free during trial",
                            "priceCurrency": "USD"
                        }
                    },
                    {
                        "@type": "Offer", 
                        "itemOffered": {
                            "@type": "Service",
                            "name": "Automated Documentation Generation",
                            "description": "$75K+ potential savings vs traditional consultants"
                        }
                    }
                ]
            }
        };

        const script = document.createElement('script');
        script.type = 'application/ld+json';
        script.textContent = JSON.stringify(structuredData);
        document.head.appendChild(script);

        return () => {
            // Clean up the script tag when the component unmounts
            document.head.removeChild(script);
            // Optionally, revert title and meta description if this component isn't always mounted
            // For a single page app, this might not be strictly necessary if new routes set their own.
            // document.title = "Default Title"; 
            // document.querySelector('meta[name="description"]')?.setAttribute('content', 'Default description');
        };

    }, []);

    return (
        <div className="bg-gray-50 py-12 md:py-20">
            <div className="container mx-auto px-4">
                <motion.div
                    className="text-center mb-16"
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                >
                    <Badge className="mb-6 bg-blue-100 text-blue-800 px-6 py-3 text-xl font-bold">
                        A New Category of Compliance
                    </Badge>
                    <h1 className="text-4xl md:text-5xl font-extrabold text-gray-900 mb-4">
                        Complete DIB Solution: Primes & Subcontractors
                    </h1>
                    <p className="text-xl text-gray-600 max-w-4xl mx-auto">
                        We are not just a cheaper consultant or a smarter GRC tool. We are a technology company that has <strong className="text-gray-800">productized expert knowledge</strong>, delivering a scalable solution for the entire Defense Industrial Base supply chain.
                    </p>
                </motion.div>
                
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1, transition: { delay: 0.2 } }}>
                    <Card className="mb-8 border-blue-300 bg-gradient-to-r from-blue-50 to-indigo-50 shadow-lg max-w-7xl mx-auto">
                        <CardHeader>
                            <CardTitle className="flex items-center gap-3 text-blue-900">
                                <Award className="w-6 h-6" />
                                Zero-Risk CMMC Audit Preparation (90-Day Guarantee)
                            </CardTitle>
                             <CardDescription className="text-blue-800">
                                AI-powered preparation training with money-back guarantee. We prepare you for success - you handle implementation.
                            </CardDescription>
                        </CardHeader>
                        <CardContent>
                            <div className="grid md:grid-cols-2 gap-4">
                                <div>
                                    <p className="text-blue-700 font-semibold">✅ What We Provide:</p>
                                    <ul className="text-blue-700 text-sm space-y-1 ml-4">
                                        <li>• AI-generated SSP templates & policy drafts</li>
                                        <li>• 90-day implementation coaching</li>
                                        <li>• Gap analysis & prioritized action plans</li>
                                        <li>• Preparation guidance for C3PAO readiness</li>
                                    </ul>
                                </div>
                                <div>
                                    <p className="text-blue-700 font-semibold">⚠️ What You Handle:</p>
                                    <ul className="text-blue-700 text-sm space-y-1 ml-4">
                                        <li>• Review & finalize all AI-generated materials</li>
                                        <li>• Implement recommended security controls</li>
                                        <li>• Submit final documents to your C3PAO</li>
                                        <li>• Manage your official audit process</li>
                                    </ul>
                                </div>
                            </div>
                            <p className="text-blue-600 text-xs mt-4 italic">*We provide audit preparation training and guidance. We are not a C3PAO and do not conduct official assessments or certifications.</p>
                        </CardContent>
                    </Card>
                </motion.div>

                <div className="grid lg:grid-cols-3 gap-8 max-w-7xl mx-auto mb-16">
                    <ValuePropositionComparison {...traditionalConsulting} />
                    <ValuePropositionComparison {...hypercoreAI} />
                    <ValuePropositionComparison {...grcSoftware} />
                </div>
                
                {/* Add ROI Calculator Section */}
                <div className="max-w-4xl mx-auto mb-16">
                    <div className="text-center mb-8">
                        <h2 className="text-3xl font-bold text-gray-900 mb-4">Calculate Your Exact Savings</h2>
                        <p className="text-gray-600">See personalized ROI based on your organization size and timeline</p>
                    </div>
                    <ROICalculator embedded={true} />
                </div>

                <Card className="max-w-4xl mx-auto bg-white shadow-lg border mb-16">
                    <CardHeader>
                        <CardTitle className="text-2xl font-bold flex items-center gap-3"><HelpCircle className="text-blue-600" /> How can you offer this for FREE when others charge tens of thousands?</CardTitle>
                        <CardDescription>Our business model is built on productized expertise and AI, not billable hours. Free until December 5th.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6 text-gray-700">
                        <div className="flex items-start gap-4 p-4 bg-gray-50 rounded-lg">
                            <GanttChartSquare className="w-10 h-10 text-blue-600 flex-shrink-0" />
                            <div>
                                <h4 className="font-semibold text-lg">Productized Expertise</h4>
                                <p>We've embedded hundreds of hours of expert knowledge into our automated 90-Day Success Plan and AI Assistant. The software guides you, which is infinitely more scalable than a human consultant holding your hand. You're buying a tool, not manual labor.</p>
                            </div>
                        </div>
                        <div className="flex items-start gap-4 p-4 bg-gray-50 rounded-lg">
                            <DollarSign className="w-10 h-10 text-green-600 flex-shrink-0" />
                            <div>
                                <h4 className="font-semibold text-lg">SBIR Grant Partnership Program</h4>
                                <p>Our primary goal before December 5th is to gather real-world data to support our SBIR grant proposal. By offering a robust free access program, we collect the necessary validation to prove our technology works. It's a win-win: you solve your compliance problem for free, and we get the data to secure federal funding.</p>
                            </div>
                        </div>
                        <div className="flex items-start gap-4 p-4 bg-gray-50 rounded-lg">
                            <Users className="w-10 h-10 text-purple-600 flex-shrink-0" />
                            <div>
                                <h4 className="font-semibold text-lg">Smart Human-in-the-Loop</h4>
                                <p>Our model is "AI-first," not "AI-only." We use human experts for the 5% of tasks that require true strategic oversight, not the 95% of paperwork that can be automated. This keeps our costs low and our value high.</p>
                            </div>
                        </div>
                        <Alert className="bg-blue-50 border-blue-200">
                            <AlertTitle className="text-blue-800 font-bold">What's the Subscription Value After December 5th?</AlertTitle>
                            <AlertDescription className="text-blue-700">
                                You'll be subscribing to a living platform. This includes continuous updates to CMMC controls, an ever-improving AI assistant, and access to our growing Knowledge Hub. You're paying for ongoing compliance assurance, not just a one-time set of documents. All SBIR partners receive preferential pricing.
                            </AlertDescription>
                        </Alert>
                    </CardContent>
                </Card>

                <Card className="max-w-4xl mx-auto bg-purple-50 border-purple-200 shadow-lg">
                    <CardHeader>
                        <CardTitle className="text-2xl font-bold flex items-center gap-3 text-purple-800"><Zap /> The Disruptive Conclusion</CardTitle>
                        <CardDescription className="text-purple-700">Why HyperCore's AI-First model is fundamentally different and superior for SMBs.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4 text-purple-800">
                        <p>
                            Traditional consultants sell time. GRC software sells tools. <strong>HyperCore productizes expertise.</strong>
                        </p>
                        <p>
                            By embedding automated, AI-driven guidance directly into the platform, we eliminate the need for expensive human intervention in 90% of the compliance process. This isn't just a cheaper alternative; it's a new category of service that delivers the expert outcome of a consultant at the scalable price of software.
                        </p>
                    </CardContent>
                </Card>

                <div className="text-center mt-16">
                    <p className="text-lg text-gray-700 mb-6">Ready to experience the AI-First difference? Your compliance documents are minutes away.</p>
                    <div className="flex flex-col sm:flex-row gap-4 justify-center">
                        <Button asChild size="lg" className="bg-blue-600 hover:bg-blue-700 text-lg px-8 py-6">
                            <Link to={createPageUrl('PartnershipTrial')}>
                                Start Your Free SBIR Partnership <ArrowRight className="w-5 h-5 ml-2" />
                            </Link>
                        </Button>
                        <Button asChild size="lg" variant="outline" className="text-lg px-8 py-6">
                            <Link to={createPageUrl('SuccessPlan')}>
                                View the Automated 90-Day Plan
                            </Link>
                        </Button>
                    </div>
                </div>
            </div>
        </div>
    );
}
