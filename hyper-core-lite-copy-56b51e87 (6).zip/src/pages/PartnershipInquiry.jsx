
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { FileText, Banknote, Shield, CheckCircle, Gavel } from 'lucide-react';
import { PartnershipCommunication } from "@/api/entities";
import { sendEmail } from "@/api/functions";
import { toast } from "sonner";
import { motion } from "framer-motion";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function PartnershipInquiryPage() {
    const [formData, setFormData] = useState({
        organization: '',
        contact_person: '',
        email: '',
        phone: '',
        message: '',
        partnership_type: 'defense_contractor'
    });
    const [submitting, setSubmitting] = useState(false);
    const [submitted, setSubmitted] = useState(false);

    const handleFormSubmit = async (e) => {
        e.preventDefault();
        setSubmitting(true);

        try {
            // Save to CRM
            await PartnershipCommunication.create({
                ...formData,
                status: 'target',
                communication_type: 'initial_contact',
                subject: 'CMMC Preparation Engagement Request',
                notes: `Engagement request submitted via website contact form: ${formData.message}`
            });

            // Send notification email
            await sendEmail({
                to: 'partnerships@hypercore.ai', // Replace with your actual email
                subject: `New CMMC Preparation Engagement Request from ${formData.organization}`,
                html: `
                    <h2>New Engagement Request</h2>
                    <p><strong>Organization:</strong> ${formData.organization}</p>
                    <p><strong>Contact:</strong> ${formData.contact_person}</p>
                    <p><strong>Email:</strong> ${formData.email}</p>
                    <p><strong>Phone:</strong> ${formData.phone}</p>
                    <p><strong>Type:</strong> ${formData.partnership_type}</p>
                    <p><strong>Message:</strong></p>
                    <p>${formData.message}</p>
                `
            });

            setSubmitted(true);
            toast.success('Your engagement request has been submitted successfully!');
        } catch (error) {
            console.error('Failed to submit engagement request:', error);
            toast.error('Failed to submit engagement request. Please try again.');
        } finally {
            setSubmitting(false);
        }
    };

    if (submitted) {
        return (
            <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
                <div className="max-w-2xl mx-auto text-center">
                    <motion.div
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className="bg-white rounded-lg shadow-lg p-8"
                    >
                        <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
                        <h1 className="text-3xl font-bold text-gray-900 mb-4">Engagement Request Received!</h1>
                        <p className="text-lg text-gray-600 mb-6">
                            Thank you for initiating your CMMC preparation journey with HyperCore AI. We've received your request.
                        </p>
                        <div className="bg-blue-50 p-4 rounded-md text-left">
                            <p className="text-sm text-blue-800">
                                <strong>What happens next:</strong><br />
                                1. We will review your submission and prepare the formal engagement agreement.<br />
                                2. You will receive the agreement and an invoice for the initial deposit within one business day.<br />
                                3. Once signed and payment is processed, we'll schedule your program kick-off!
                            </p>
                        </div>
                        <div className="mt-8">
                            <p className="text-sm text-gray-600 mb-3">While you wait, learn more about our process and what to expect:</p>
                            <Button asChild>
                                <Link to={createPageUrl('HyperCoreCMMCReadiness')}>
                                    <FileText className="w-4 h-4 mr-2" />
                                    Review Program Details & Your Responsibilities
                                </Link>
                            </Button>
                        </div>
                    </motion.div>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
            <div className="max-w-4xl mx-auto">
                <header className="text-center mb-12">
                    <h1 className="text-4xl font-extrabold text-gray-900 sm:text-5xl">
                        Request Formal Engagement
                    </h1>
                    <p className="mt-4 text-xl text-gray-600">
                        Initiate our 90-day CMMC preparation service. Let's begin the formal process to get your organization audit-ready.
                    </p>
                </header>

                <main className="space-y-8">
                    <Card>
                        <CardHeader>
                            <CardTitle className="text-2xl">The Engagement & Payment Process</CardTitle>
                            <CardDescription>Our process is transparent and aligns with professional government contracting standards.</CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-6">
                            <div className="flex items-start gap-4">
                                <FileText className="w-8 h-8 text-blue-600 mt-1 flex-shrink-0" />
                                <div>
                                    <h3 className="font-semibold text-lg">Step 1: Formal Preparation Agreement</h3>
                                    <p className="text-gray-600">After you submit your inquiry, we will send a formal agreement detailing the scope of services, the 90-day timeline, and the deliverables for our **$12,500 fixed-fee Expert-Guided program**.</p>
                                </div>
                            </div>
                            <div className="flex items-start gap-4">
                                <Banknote className="w-8 h-8 text-green-600 mt-1 flex-shrink-0" />
                                <div>
                                    <h3 className="font-semibold text-lg">Step 2: Invoice & Secure Payment</h3>
                                    <p className="text-gray-600">You will receive an invoice for the initial 50% deposit. We operate on standard Net-30 terms via secure wire transfer to ensure a professional audit trail.</p>
                                </div>
                            </div>
                             <div className="flex items-start gap-4">
                                <Shield className="w-8 h-8 text-indigo-600 mt-1 flex-shrink-0" />
                                <div>
                                    <h3 className="font-semibold text-lg">Step 3: Program Kick-off</h3>
                                    <p className="text-gray-600">Once the agreement is signed and payment is processed, we immediately schedule your kick-off call and deliver the first tranche of AI-generated policy documents.</p>
                                </div>
                            </div>
                        </CardContent>
                    </Card>

                    <Card>
                        <CardHeader>
                            <CardTitle>Submit Your Engagement Request</CardTitle>
                            <CardDescription>Complete this form to begin the CMMC preparation process. We will respond within one business day with the formal agreement.</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <form onSubmit={handleFormSubmit} className="space-y-4">
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                        <Input
                                            placeholder="Organization Name *"
                                            value={formData.organization}
                                            onChange={(e) => setFormData({...formData, organization: e.target.value})}
                                            required
                                            className="min-h-[48px] text-base"
                                        />
                                        <Input
                                            placeholder="Contact Person *"
                                            value={formData.contact_person}
                                            onChange={(e) => setFormData({...formData, contact_person: e.target.value})}
                                            required
                                            className="min-h-[48px] text-base"
                                        />
                                    </div>
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                        {/* MOBILE UI FIX: Add inputMode and autoComplete for better mobile keyboards */}
                                        <Input
                                            type="email"
                                            inputMode="email"
                                            autoComplete="email"
                                            placeholder="Email Address *"
                                            value={formData.email}
                                            onChange={(e) => setFormData({...formData, email: e.target.value})}
                                            required
                                            className="min-h-[48px] text-base"
                                        />
                                        <Input
                                            type="tel"
                                            inputMode="tel"
                                            autoComplete="tel"
                                            placeholder="Phone Number"
                                            value={formData.phone}
                                            onChange={(e) => setFormData({...formData, phone: e.target.value})}
                                            className="min-h-[48px] text-base"
                                        />
                                    </div>
                                    <Textarea
                                        placeholder="Please provide any specific details about your organization, current compliance status, or timeline pressures. This will help us tailor the engagement agreement."
                                        value={formData.message}
                                        onChange={(e) => setFormData({...formData, message: e.target.value})}
                                        rows={4}
                                        required
                                        className="text-base"
                                    />
                                    <div className="flex justify-end gap-3">
                                        <Button type="submit" disabled={submitting} className="min-h-[48px] text-base px-6">
                                            {submitting ? 'Submitting...' : 'Send Engagement Request'}
                                        </Button>
                                    </div>
                                </form>
                        </CardContent>
                    </Card>

                    <Alert className="bg-blue-50 border-blue-200">
                        <Gavel className="h-5 w-5 text-blue-700" />
                        <AlertTitle className="text-blue-800 font-semibold">Preparation Services Only - Clear Expectations</AlertTitle>
                        <AlertDescription className="text-blue-700">
                           HyperCore AI provides expert CMMC preparation guidance and training services designed to help your team prepare for a C3PAO assessment. We are not a C3PAO and do not conduct audits, provide certifications, or guarantee compliance outcomes. Final compliance determination is the sole responsibility of an independent C3PAO. 
                           <div className="mt-2 flex gap-4">
                               <Link to={createPageUrl('Legal')} className="font-semibold underline hover:text-blue-600">
                                    Legal Terms
                                </Link>
                                <Link to={createPageUrl('ServiceExpectationsDisclosure')} className="font-semibold underline hover:text-blue-600">
                                    Service Expectations & Responsibilities
                                </Link>
                           </div>
                        </AlertDescription>
                    </Alert>
                </main>
            </div>
        </div>
    );
}
