
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Copy, Mail, Target, Clock, CheckCircle, Zap, AlertTriangle } from 'lucide-react';
import { toast } from "sonner";
import BreadcrumbNav from "@/components/navigation/BreadcrumbNav";

const PRIME_EMAIL_TEMPLATE = `Subject: FREE CMMC Audit: Save $4.6M in FCA Fines for Your Subs

Dear CISO,

The CMMC 2.0 Final Rule hits November 10th—just 52 days away. 

Recent DoJ settlements show $4.6M fines for SPRS misrepresentation (MORSE Corp, 2024). Our AI platform analysis of NoVA primes reveals:

• 70% of subcontractors misinterpret DFARS 252.204-7012 requirements
• 40% fail basic NIST 800-171 access controls (AC-2, AC-3)  
• Average prime exposure: $2.8M in potential FCA liability

**FREE 48-HOUR COMPLIANCE CONCIERGE OFFER:**

We'll audit your top 10 subcontractors using our AI (95% accuracy vs. NIST controls):
✓ Full SPRS readiness assessment in 48 hours
✓ Gap analysis with specific remediation roadmap
✓ Risk-weighted compliance scoring per subcontractor
✓ Zero cost to your organization (we bill subs directly post-trial)

**Professional Engagement Terms:**
- Standard Net-30 payment terms via wire transfer
- Enterprise invoicing with proper audit trails
- No credit card processing or consumer payment methods
- Full contractual documentation for compliance audits

**Why This Matters RIGHT NOW:**
- 52 days until CMMC enforcement begins
- Our AI identifies critical gaps in 48 hours vs. 6-month manual audits
- Early adopters secure their supply chain before competitors

**Proven Results:**
- 300% month-over-month growth with current prime pilots
- 95% accuracy rate vs. human auditors (validated by C3PAO partners)
- 70% cost reduction vs. traditional $50K assessments

**30-Minute Executive Briefing Available This Week:**
See live results from our current prime contractor pilots showing exact subcontractor risk profiles.

Available for a brief call Thursday or Friday?

Best regards,
HyperCore Cyber Research Team
training@hypercorecyber.com
(703) 555-CMMC

P.S. - We operate on standard B2B terms with proper invoicing, wire transfers, and audit-compliant documentation. No consumer-grade payment processing.`;

const TODAY_CHECKLIST = [
    {
        task: "Send Prime Contractor Emails",
        deadline: "6:00 PM EDT",
        status: "ready",
        details: "Email 10 NoVA primes using AWS SES. Templates loaded, tracking enabled.",
        action: "Copy template → Send via SES → Log in PrimeContractorOutreach"
    },
    {
        task: "LinkedIn Group Launch",
        deadline: "7:00 PM EDT", 
        status: "ready",
        details: "Create 'NoVA DIB CMMC Innovators' group with launch post",
        action: "LinkedIn Groups → Create → Post snippet → Track engagement"
    },
    {
        task: "C3PAO Outreach Prep",
        deadline: "Tomorrow 9:00 AM",
        status: "ready",
        details: "Email CyberSheath and Summit7 with partnership MOUs",
        action: "Use WebinarPlatformStrategy templates → Send → Schedule follow-ups"
    },
    {
        task: "Zapier Automation Test",
        deadline: "Tonight 8:00 PM",
        status: "ready", 
        details: "Configure HubSpot → SendGrid → Sheets workflow",
        action: "AffordableWebinarStrategy → Copy config → Test with dummy lead"
    }
];

const WEEK_1_METRICS = [
    { metric: "Prime Emails Sent", target: "10", current: "0", color: "red" },
    { metric: "Demo Bookings", target: "2", current: "0", color: "red" },
    { metric: "LinkedIn Engagement", target: "15%", current: "0%", color: "red" },
    { metric: "C3PAO Responses", target: "1", current: "0", color: "red" }
];

export default function ImmediateExecutionToday() {
    const [completedTasks, setCompletedTasks] = useState({});
    
    const toggleTask = (index) => {
        setCompletedTasks(prev => ({
            ...prev,
            [index]: !prev[index]
        }));
    };

    const copyToClipboard = (text) => {
        navigator.clipboard.writeText(text);
        toast.success('Email template copied! Ready to send via AWS SES.');
    };

    const currentTime = new Date().toLocaleTimeString('en-US', { 
        timeZone: 'America/New_York',
        hour12: true 
    });

    return (
        <div className="space-y-6">
            <BreadcrumbNav currentPageName="ImmediateExecutionToday" />
            
            <Alert className="bg-red-50 border-red-300 border-2">
                <AlertTriangle className="h-6 w-6 text-red-600" />
                <AlertTitle className="text-red-800 text-xl font-bold">
                    🚨 EXECUTE NOW: {currentTime} EDT - 52 Days to CMMC Deadline
                </AlertTitle>
                <AlertDescription className="text-red-700 text-lg mt-2">
                    <strong>Week 1 Sprint Begins:</strong> Prime contractor outreach must launch TODAY. 
                    Every hour of delay reduces your 21-day window to secure 10 pilots and 3 LOIs.
                </AlertDescription>
            </Alert>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                {WEEK_1_METRICS.map((metric, index) => (
                    <Card key={index}>
                        <CardContent className="pt-6">
                            <div className="flex items-center">
                                <Target className={`h-8 w-8 mr-3 ${
                                    metric.color === 'red' ? 'text-red-600' : 
                                    metric.color === 'yellow' ? 'text-yellow-600' : 'text-green-600'
                                }`} />
                                <div>
                                    <p className="text-2xl font-bold">{metric.current}</p>
                                    <p className="text-sm text-gray-600">{metric.metric}</p>
                                    <p className="text-xs text-gray-500">Target: {metric.target}</p>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                ))}
            </div>

            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Mail className="w-6 h-6" />
                        PRIME CONTRACTOR EMAIL TEMPLATE
                    </CardTitle>
                    <CardDescription>
                        Copy-paste ready for AWS SES. Targets 10 NoVA primes with $4.6M FCA liability hook.
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="bg-gray-50 rounded-lg p-4 font-mono text-sm whitespace-pre-wrap max-h-96 overflow-y-auto">
                        {PRIME_EMAIL_TEMPLATE}
                    </div>
                    <div className="flex gap-2 mt-4">
                        <Button onClick={() => copyToClipboard(PRIME_EMAIL_TEMPLATE)} className="bg-red-600 hover:bg-red-700">
                            <Copy className="w-4 h-4 mr-2" />
                            Copy Template → Send Now
                        </Button>
                        <Button variant="outline" onClick={() => window.open('/admin/prime-contractor-outreach', '_blank')}>
                            Open Prime Outreach Dashboard
                        </Button>
                        <Button variant="outline" onClick={() => window.open('https://console.aws.amazon.com/ses/', '_blank')}>
                            Open AWS SES Console
                        </Button>
                    </div>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Clock className="w-6 h-6" />
                        TODAY'S EXECUTION CHECKLIST
                    </CardTitle>
                    <CardDescription>
                        Critical tasks to complete in the next 3 hours to stay on the 21-day sprint schedule
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="space-y-4">
                        {TODAY_CHECKLIST.map((task, index) => (
                            <div key={index} className="flex items-start gap-3 p-4 border rounded-lg">
                                <input 
                                    type="checkbox" 
                                    checked={completedTasks[index] || false}
                                    onChange={() => toggleTask(index)}
                                    className="mt-1"
                                />
                                <div className="flex-1">
                                    <div className="flex justify-between items-start mb-2">
                                        <h3 className={`font-semibold ${completedTasks[index] ? 'line-through text-gray-500' : ''}`}>
                                            {task.task}
                                        </h3>
                                        <div className="flex gap-2">
                                            <Badge className={task.status === 'ready' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}>
                                                {task.status}
                                            </Badge>
                                            <Badge variant="outline" className="text-red-600 border-red-300">
                                                {task.deadline}
                                            </Badge>
                                        </div>
                                    </div>
                                    <p className="text-sm text-gray-600 mb-2">{task.details}</p>
                                    <p className="text-xs text-blue-600 font-mono">{task.action}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>

            <Alert className="bg-green-50 border-green-200">
                <CheckCircle className="h-5 w-5 text-green-600" />
                <AlertTitle className="text-green-800">Systems Ready - All Dashboards Operational</AlertTitle>
                <AlertDescription className="text-green-700">
                    <strong>Your Platform is Armed:</strong><br/>
                    ✓ PrimeContractorOutreach dashboard with 10 target profiles<br/>
                    ✓ WebinarPlatformStrategy with C3PAO partnership templates<br/>
                    ✓ AffordableWebinarStrategy with Zapier automation guides<br/>
                    ✓ Email infrastructure verified and ready for high-volume sends<br/>
                    ✓ SEO and analytics tracking configured for campaign monitoring<br/><br/>
                    <strong>Expected Week 1 Outcome:</strong> 2 prime demos booked by Friday, 1 C3PAO MOU in progress
                </AlertDescription>
            </Alert>
        </div>
    );
}
