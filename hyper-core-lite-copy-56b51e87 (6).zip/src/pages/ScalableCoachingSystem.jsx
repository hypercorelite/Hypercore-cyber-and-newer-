
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CheckCircle, Video, FileText, Bot, Clock, Users, ArrowRight, Play, Download } from 'lucide-react';
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";

const weeklyModules = [
    {
        week: 1,
        title: "Kickoff & Gap Analysis",
        objective: "Complete initial CMMC readiness assessment",
        videoScript: "Walk through the AI gap analysis tool, interpret results, understand priority areas",
        checklist: ["Upload current security documentation", "Complete automated assessment", "Review gap analysis report", "Identify quick wins vs. long-term projects"],
        deliverable: "Personalized 90-day implementation roadmap"
    },
    {
        week: 2,
        title: "Access Control Implementation", 
        objective: "Implement NIST AC controls for user access management",
        videoScript: "Demo proper access control setup, common mistakes, tool recommendations",
        checklist: ["Audit current user accounts", "Implement least privilege access", "Set up account monitoring", "Document access procedures"],
        deliverable: "Access Control Policy + Implementation Evidence"
    },
    {
        week: 3,
        title: "System Security Planning",
        objective: "Generate and customize your System Security Plan",
        videoScript: "How to use AI SSP generation, what to customize, C3PAO expectations",
        checklist: ["Generate initial SSP", "Customize for your environment", "Review technical accuracy", "Add implementation timeline"],
        deliverable: "Draft System Security Plan (SSP)"
    },
    {
        week: 4,
        title: "Incident Response Setup",
        objective: "Establish incident response procedures and documentation", 
        videoScript: "IR best practices, template customization, testing procedures",
        checklist: ["Customize IR policy template", "Define response team roles", "Set up incident logging", "Conduct tabletop exercise"],
        deliverable: "Incident Response Plan + Playbooks"
    },
    {
        week: 5,
        title: "Data Protection & Encryption",
        objective: "Implement encryption and data protection controls",
        videoScript: "Encryption implementation guide, key management, CUI protection",
        checklist: ["Implement encryption at rest", "Configure encryption in transit", "Set up key management", "Test backup recovery"],
        deliverable: "Data Protection Implementation Evidence"
    },
    {
        week: 6,
        title: "Network Security Controls",
        objective: "Configure network segmentation and monitoring",
        videoScript: "Network architecture for CMMC, segmentation strategies, monitoring setup",
        checklist: ["Implement network segmentation", "Configure firewalls", "Set up network monitoring", "Document network topology"],
        deliverable: "Network Security Documentation Package"
    },
    {
        week: 7,
        title: "Audit Logging & Monitoring",
        objective: "Establish comprehensive audit logging capabilities",
        videoScript: "Log management setup, SIEM configuration, retention policies",
        checklist: ["Configure centralized logging", "Set up log monitoring", "Define retention policies", "Test log analysis"],
        deliverable: "Audit & Accountability Implementation"
    },
    {
        week: 8,
        title: "Security Awareness Training",
        objective: "Implement ongoing security training program",
        videoScript: "Training program setup, content creation, tracking compliance",
        checklist: ["Deploy training platform", "Customize training content", "Schedule recurring training", "Set up tracking dashboard"],
        deliverable: "Security Awareness Program + Records"
    },
    {
        week: 9,
        title: "Vulnerability Management",
        objective: "Establish vulnerability scanning and remediation processes",
        videoScript: "Vulnerability scanning setup, prioritization, remediation tracking",
        checklist: ["Configure vulnerability scanner", "Establish scanning schedule", "Create remediation workflow", "Generate initial scan report"],
        deliverable: "Vulnerability Management Procedures"
    },
    {
        week: 10,
        title: "Supply Chain Security",
        objective: "Implement vendor risk management for CMMC",
        videoScript: "Vendor assessment process, contract requirements, ongoing monitoring",
        checklist: ["Inventory all vendors", "Assess vendor security", "Update contract templates", "Implement monitoring process"],
        deliverable: "Supply Chain Risk Management Plan"
    },
    {
        week: 11,
        title: "Evidence Package Assembly",
        objective: "Compile all documentation for C3PAO readiness",
        videoScript: "Evidence organization, C3PAO expectations, final review process",
        checklist: ["Organize all documentation", "Complete evidence mapping", "Conduct internal review", "Generate final reports"],
        deliverable: "Complete C3PAO Evidence Package"
    },
    {
        week: 12,
        title: "C3PAO Preparation & Next Steps",
        objective: "Final preparation for official CMMC assessment",
        videoScript: "C3PAO selection, assessment process, maintaining compliance",
        checklist: ["Select C3PAO partner", "Schedule assessment", "Brief team on process", "Plan ongoing compliance"],
        deliverable: "C3PAO Readiness Certification"
    }
];

const automationComponents = [
    {
        component: "Video Tutorial Library",
        description: "12 professional instructional videos (15-20 minutes each) covering every aspect of implementation",
        effort: "40-50 hours to produce all videos",
        scalability: "One-time creation serves unlimited clients"
    },
    {
        component: "Interactive Checklists",
        description: "Digital checklists with progress tracking, file uploads, and automatic completion verification",
        effort: "20-30 hours to build interactive system", 
        scalability: "Self-service with automated progress tracking"
    },
    {
        component: "AI Documentation Assistant",
        description: "Chat-based AI that answers implementation questions using your expert knowledge base",
        effort: "15-20 hours to train and deploy",
        scalability: "24/7 support without human intervention"
    },
    {
        component: "Template Library",
        description: "Customizable policy and procedure templates for each CMMC domain",
        effort: "25-35 hours to create comprehensive template set",
        scalability: "Automatic customization based on client profile"
    }
];

export default function ScalableCoachingSystem() {
    const [selectedWeek, setSelectedWeek] = useState(1);

    return (
        <div className="space-y-8">
            <BreadcrumbNav currentPageName="ScalableCoachingSystem" />
            
            <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="text-center">
                <Badge className="mb-4 bg-green-100 text-green-800">SCALABLE PRODUCT FEATURE</Badge>
                <h1 className="text-4xl font-bold text-gray-900 mb-4">12-Week Expert Coaching System</h1>
                <p className="text-xl text-gray-600 max-w-4xl mx-auto">
                    Transform manual consulting into a scalable, self-service coaching experience that delivers expert guidance without expert time.
                </p>
            </motion.div>

            <Alert className="bg-blue-50 border-blue-200">
                <Bot className="h-4 w-4 text-blue-600" />
                <AlertTitle className="text-blue-800">Scalability Strategy</AlertTitle>
                <AlertDescription className="text-blue-700">
                    Instead of 12 live coaching calls (12 hours per client), create 12 self-service modules with video tutorials, interactive checklists, and AI support. 
                    <strong>One-time creation effort serves unlimited clients.</strong>
                </AlertDescription>
            </Alert>

            <Tabs defaultValue="modules" className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="modules">Weekly Modules</TabsTrigger>
                    <TabsTrigger value="automation">Automation Components</TabsTrigger>
                    <TabsTrigger value="implementation">Implementation Plan</TabsTrigger>
                </TabsList>

                <TabsContent value="modules" className="space-y-6">
                    <Card>
                        <CardHeader>
                            <CardTitle>12-Week Structured Coaching Program</CardTitle>
                            <CardDescription>Each week focuses on specific CMMC implementation milestones with video guidance and verification checklists.</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <div className="grid md:grid-cols-4 gap-4 mb-6">
                                {weeklyModules.slice(0, 12).map((module) => (
                                    <Button
                                        key={module.week}
                                        variant={selectedWeek === module.week ? "default" : "outline"}
                                        size="sm"
                                        onClick={() => setSelectedWeek(module.week)}
                                        className="h-auto p-3 text-left"
                                    >
                                        <div>
                                            <div className="font-semibold">Week {module.week}</div>
                                            <div className="text-xs opacity-75">{module.title}</div>
                                        </div>
                                    </Button>
                                ))}
                            </div>

                            {weeklyModules[selectedWeek - 1] && (
                                <motion.div
                                    key={selectedWeek}
                                    initial={{ opacity: 0, y: 20 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    className="bg-gray-50 p-6 rounded-lg"
                                >
                                    <div className="flex items-center gap-3 mb-4">
                                        <Badge className="bg-blue-100 text-blue-800">Week {selectedWeek}</Badge>
                                        <h3 className="text-xl font-semibold">{weeklyModules[selectedWeek - 1].title}</h3>
                                    </div>
                                    
                                    <div className="grid md:grid-cols-2 gap-6">
                                        <div>
                                            <h4 className="font-semibold mb-2 flex items-center gap-2">
                                                <Video className="w-4 h-4" /> Video Tutorial Content
                                            </h4>
                                            <p className="text-sm text-gray-600 mb-4">{weeklyModules[selectedWeek - 1].videoScript}</p>
                                            
                                            <h4 className="font-semibold mb-2 flex items-center gap-2">
                                                <FileText className="w-4 h-4" /> Week Objective
                                            </h4>
                                            <p className="text-sm text-gray-600">{weeklyModules[selectedWeek - 1].objective}</p>
                                        </div>

                                        <div>
                                            <h4 className="font-semibold mb-2 flex items-center gap-2">
                                                <CheckCircle className="w-4 h-4" /> Implementation Checklist
                                            </h4>
                                            <ul className="space-y-1 mb-4">
                                                {weeklyModules[selectedWeek - 1].checklist.map((item, index) => (
                                                    <li key={index} className="text-sm flex items-start gap-2">
                                                        <CheckCircle className="w-3 h-3 mt-1 text-green-600" />
                                                        {item}
                                                    </li>
                                                ))}
                                            </ul>

                                            <div className="bg-green-50 p-3 rounded border border-green-200">
                                                <h5 className="font-semibold text-green-800 mb-1">Week Deliverable</h5>
                                                <p className="text-sm text-green-700">{weeklyModules[selectedWeek - 1].deliverable}</p>
                                            </div>
                                        </div>
                                    </div>
                                </motion.div>
                            )}
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="automation" className="space-y-6">
                    <Card>
                        <CardHeader>
                            <CardTitle>Automation Components</CardTitle>
                            <CardDescription>The technical systems that make expert coaching scalable without manual intervention.</CardDescription>
                        </CardHeader>
                        <CardContent className="grid md:grid-cols-2 gap-6">
                            {automationComponents.map((component, index) => (
                                <motion.div key={component.component} initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: index * 0.1 }}>
                                    <div className="p-6 bg-gray-50 rounded-lg border h-full">
                                        <h3 className="text-lg font-semibold text-gray-800 mb-2">{component.component}</h3>
                                        <p className="text-sm text-gray-600 mb-3">{component.description}</p>
                                        <div className="space-y-2">
                                            <div className="text-xs text-blue-700 bg-blue-50 p-2 rounded">
                                                <strong>Development Effort:</strong> {component.effort}
                                            </div>
                                            <div className="text-xs text-green-700 bg-green-50 p-2 rounded">
                                                <strong>Scalability:</strong> {component.scalability}
                                            </div>
                                        </div>
                                    </div>
                                </motion.div>
                            ))}
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="implementation" className="space-y-6">
                    <Card>
                        <CardHeader>
                            <CardTitle>Implementation Priority & Timeline</CardTitle>
                            <CardDescription>How to build the scalable coaching system during your MVP development.</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-6">
                                <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                                    <h4 className="font-semibold text-green-800 mb-2">Phase 1: MVP Core (Weeks 1-6)</h4>
                                    <p className="text-sm text-green-700 mb-3">Focus on the AI assessment engine and basic compliance tools. Don't build coaching system yet.</p>
                                    <ul className="text-xs text-green-600 space-y-1">
                                        <li>• Build core gap analysis functionality</li>
                                        <li>• Create basic SSP generation</li>
                                        <li>• Develop 90-day implementation templates</li>
                                    </ul>
                                </div>

                                <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                                    <h4 className="font-semibold text-blue-800 mb-2">Phase 2: Coaching System (Weeks 7-12)</h4>
                                    <p className="text-sm text-blue-700 mb-3">Add the scalable coaching components once core MVP proves valuable.</p>
                                    <ul className="text-xs text-blue-600 space-y-1">
                                        <li>• Record first 3-4 video tutorials (highest impact weeks)</li>
                                        <li>• Build interactive checklist system</li>
                                        <li>• Train AI documentation assistant</li>
                                        <li>• Create template library</li>
                                    </ul>
                                </div>

                                <div className="p-4 bg-purple-50 rounded-lg border border-purple-200">
                                    <h4 className="font-semibold text-purple-800 mb-2">Phase 3: Scale & Optimize (Post-MVP)</h4>
                                    <p className="text-sm text-purple-700 mb-3">Complete the full 12-week system based on real client feedback.</p>
                                    <ul className="text-xs text-purple-600 space-y-1">
                                        <li>• Complete all 12 video tutorials</li>
                                        <li>• Add progress tracking and analytics</li>
                                        <li>• Implement automated completion certificates</li>
                                        <li>• Integrate with main compliance platform</li>
                                    </ul>
                                </div>
                            </div>
                        </CardContent>
                    </Card>

                    <Card>
                        <CardHeader>
                            <CardTitle>ROI Analysis: Manual vs. Automated Coaching</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="grid md:grid-cols-2 gap-6">
                                <div className="p-4 bg-red-50 rounded-lg border border-red-200">
                                    <h4 className="font-semibold text-red-800 mb-2">Manual Coaching (Old Way)</h4>
                                    <ul className="text-sm text-red-700 space-y-1">
                                        <li>• 12 hours per client (live calls)</li>
                                        <li>• Cannot serve &gt;5 clients simultaneously</li>
                                        <li>• Revenue caps at ~$60K/month</li>
                                        <li>• High stress, scheduling conflicts</li>
                                        <li>• Quality varies with your energy level</li>
                                    </ul>
                                </div>

                                <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                                    <h4 className="font-semibold text-green-800 mb-2">Automated Coaching (New Way)</h4>
                                    <ul className="text-sm text-green-700 space-y-1">
                                        <li>• 0 hours per client (self-service)</li>
                                        <li>• Can serve unlimited clients</li>
                                        <li>• Revenue scales without time limits</li>
                                        <li>• 24/7 availability, no scheduling</li>
                                        <li>• Consistent quality for every client</li>
                                    </ul>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>
            </Tabs>

            <div className="text-center">
                <Button asChild size="lg">
                    <Link to={createPageUrl('MVPRealityCheck')}>
                        View Complete MVP Scope Analysis <ArrowRight className="w-4 h-4 ml-2" />
                    </Link>
                </Button>
            </div>
        </div>
    );
}
