import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import StreamlinedSupport from '../components/support/StreamlinedSupport';
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";

export default function CustomerSupportPage() {
    return (
        <div className="space-y-6">
            <BreadcrumbNav currentPageName="CustomerSupport" />
            
            <CardHeader className="px-0">
                <CardTitle className="text-3xl font-bold">Customer Support</CardTitle>
            </CardHeader>
            
            <StreamlinedSupport />
        </div>
    );
}