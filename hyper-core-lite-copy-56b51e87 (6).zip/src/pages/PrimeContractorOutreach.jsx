
import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { PrimeContractorLead } from "@/api/entities";
import { testEmailSystem } from "@/api/functions";
import { sendTargetedPrimeEmail } from "@/api/functions";
import { toast } from "sonner";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Mail, Send, Target, Loader2, PlayCircle, Shield, Building, CheckCircle, MessageSquareReply } from 'lucide-react';
import BreadcrumbNav from '../components/navigation/BreadcrumbNav';

export default function PrimeContractorOutreach() {
    const [leads, setLeads] = useState([]);
    const [loading, setLoading] = useState(true);
    const [sending, setSending] = useState({});
    const [testResult, setTestResult] = useState(null);
    const [testing, setTesting] = useState(false);

    const loadLeads = useCallback(async () => {
        setLoading(true);
        try {
            const data = await PrimeContractorLead.list('-priority');
            setLeads(data);
        } catch (error) {
            toast.error("Failed to load prime leads.");
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        loadLeads();
    }, [loadLeads]);

    const handleSendEmail = async (leadId) => {
        setSending(prev => ({ ...prev, [leadId]: true }));
        try {
            await sendTargetedPrimeEmail({ leadId });
            toast.success("Targeted outreach email sent successfully!");
            loadLeads(); // Refresh to show updated status
        } catch (error) {
            toast.error("Failed to send email.", { description: error.message });
        } finally {
            setSending(prev => ({ ...prev, [leadId]: false }));
        }
    };
    
    const handleRunTest = async () => {
        setTesting(true);
        setTestResult(null);
        try {
            await testEmailSystem({});
            setTestResult({ success: true, message: "Live deliverability test successful. A test email has been sent to your account." });
            toast.success("Email system test passed!");
        } catch (error) {
            setTestResult({ success: false, message: `Test failed: ${error.message}` });
            toast.error("Email system test failed.");
        } finally {
            setTesting(false);
        }
    };
    
    const getPriorityBadge = (priority) => {
        switch (priority) {
            case 'critical': return "bg-red-100 text-red-800";
            case 'high': return "bg-orange-100 text-orange-800";
            case 'medium': return "bg-yellow-100 text-yellow-800";
            default: return "bg-gray-100 text-gray-800";
        }
    };

    const getStatusBadge = (status) => {
        switch (status) {
            case 'replied':
                return { 
                    className: "bg-blue-100 text-blue-800",
                    icon: <MessageSquareReply className="w-4 h-4 mr-2" />,
                    text: 'Replied'
                };
            case 'contacted':
                return {
                    className: "bg-green-100 text-green-800",
                    icon: <CheckCircle className="w-4 h-4 mr-2" />,
                    text: 'Sent'
                };
            default: // 'target' or unknown
                 return { 
                    className: "bg-gray-100 text-gray-800",
                    icon: <Send className="w-4 h-4 mr-2" />,
                    text: 'Send Targeted Email'
                };
        }
    };

    return (
        <div className="space-y-6">
            <BreadcrumbNav currentPageName="Prime Contractor Outreach" />
            <CardHeader className="px-0">
                <CardTitle className="text-3xl font-bold flex items-center gap-3">
                    <Target className="w-8 h-8 text-red-600" />
                    Prime Contractor Outreach Center
                </CardTitle>
                <CardDescription>
                    One-click, targeted email campaigns for high-value prime contractors.
                </CardDescription>
            </CardHeader>
            
            <Tabs defaultValue="outreach">
                <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="outreach">Outreach Targets</TabsTrigger>
                    <TabsTrigger value="diagnostics">System Diagnostics</TabsTrigger>
                </TabsList>
                <TabsContent value="outreach" className="mt-6">
                     {loading ? (
                        <div className="flex justify-center items-center h-64">
                            <Loader2 className="w-8 h-8 animate-spin text-gray-500" />
                        </div>
                    ) : (
                        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                            {leads.map((lead) => {
                                const statusInfo = getStatusBadge(lead.outreach_status);
                                return (
                                <Card key={lead.id} className={lead.outreach_status !== 'target' ? "bg-gray-50/50 border-dashed" : "bg-white"}>
                                    <CardHeader>
                                        <div className="flex justify-between items-start">
                                            <div>
                                                <CardTitle className="flex items-center gap-2">
                                                    <Building className="w-5 h-5 text-gray-500" /> {lead.company_name}
                                                </CardTitle>
                                                <CardDescription>{lead.contact_person}</CardDescription>
                                            </div>
                                            <Badge className={getPriorityBadge(lead.priority)}>{lead.priority}</Badge>
                                        </div>
                                    </CardHeader>
                                    <CardContent className="space-y-4">
                                        <p className="text-sm text-gray-600 border-l-2 border-gray-200 pl-3">
                                            {lead.notes}
                                        </p>
                                        <Button 
                                            className="w-full"
                                            onClick={() => handleSendEmail(lead.id)}
                                            disabled={sending[lead.id] || lead.outreach_status !== 'target'}
                                        >
                                            {sending[lead.id] ? (
                                                <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Sending...</>
                                            ) : (
                                                <>{statusInfo.icon} {statusInfo.text}</>
                                            )}
                                        </Button>
                                    </CardContent>
                                </Card>
                            )})}
                        </div>
                    )}
                </TabsContent>
                <TabsContent value="diagnostics" className="mt-6">
                    <Card>
                        <CardHeader>
                            <CardTitle>Email System Health</CardTitle>
                            <CardDescription>Verify that the email sending service is configured correctly before launching a campaign.</CardDescription>
                        </CardHeader>
                        <CardContent className="flex flex-col items-center space-y-4">
                             <Button onClick={handleRunTest} disabled={testing}>
                                {testing ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Running Test...</> : <><PlayCircle className="w-4 h-4 mr-2" /> Run Live Email Deliverability Test</>}
                            </Button>
                            {testResult && (
                                <div className={`p-4 rounded-md text-sm ${testResult.success ? 'bg-green-100 text-green-900' : 'bg-red-100 text-red-900'}`}>
                                    <p className="font-semibold">{testResult.success ? "Test Successful" : "Test Failed"}</p>
                                    <p>{testResult.message}</p>
                                </div>
                            )}
                        </CardContent>
                    </Card>
                </TabsContent>
            </Tabs>
        </div>
    );
}
