
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { TrendingUp, Shield, Brain, DollarSign, Users, Target, Zap, BarChart, AlertTriangle, CheckCircle, Rocket } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";

const marketOverview = {
    marketSize: "$2.5B",
    entitiesImpacted: "337,968",
    smBPercentage: "68%",
    adoptionRate: "60%",
    cagr: "14.2%",
    preparednessRate: "4%"
};

const aiAdoption = {
    currentRate: "40-60%",
    plannedInvestment: "60%",
    workloadReduction: "68%",
    barrierMain: "Integration complexity (30%)",
    breachReduction: "50%"
};

const pricingStructure = [
    {
        category: "Level 1 Assessments",
        traditional: "$3K-15K",
        aiEnabled: "$1.5K-7.5K",
        savings: "50%",
        notes: "Self-assessment for FCI"
    },
    {
        category: "Level 2 Assessments", 
        traditional: "$35K-75K",
        aiEnabled: "$17K-40K",
        savings: "50-70%",
        notes: "C3PAO audits for CUI"
    },
    {
        category: "AI SaaS Tools",
        traditional: "$10K-75K/project",
        aiEnabled: "$2K-15K/year",
        savings: "70-80%",
        notes: "Subscription model"
    },
    {
        category: "Consulting Services",
        traditional: "$10K-75K + 20-50% annual",
        aiEnabled: "$5K-15K total",
        savings: "60-75%",
        notes: "Ongoing maintenance included"
    }
];

const competitorAnalysis = [
    {
        competitor: "TrustCloud",
        pricing: "$5K-15K/year",
        strengths: "Predictive forecasting, Real-time scoring",
        weaknesses: "Periodic scans, Generic scoring (not SPRS)",
        hypercoreAdvantage: "Continuous drift detection, DFARS-specific tools"
    },
    {
        competitor: "Concentric AI",
        pricing: "$10K-25K/year", 
        strengths: "Data discovery, 110 NIST mapping",
        weaknesses: "No remediation, Enterprise-only",
        hypercoreAdvantage: "Full lifecycle automation, SMB-friendly"
    },
    {
        competitor: "CMMC2.AI",
        pricing: "$99-499/month",
        strengths: "SMB pricing, POA&M automation",
        weaknesses: "Guidance-only, No continuous monitoring",
        hypercoreAdvantage: "Real-time monitoring, Contract intelligence"
    },
    {
        competitor: "Rackspace-SMPL-C",
        pricing: "$79+/month per enclave",
        strengths: "Cloud integration, Threat detection",
        weaknesses: "Cloud-dependent, Enclave-limited",
        hypercoreAdvantage: "Platform-agnostic, DFARS-native"
    }
];

const hypercoreEdge = [
    {
        feature: "Smart Contract Flow-Down Analyzer",
        uniqueness: "100% - No competitor offers",
        impact: "70% fewer flow-down errors",
        value: "Eliminates prime-sub compliance gaps"
    },
    {
        feature: "Real-Time Drift Detection",
        uniqueness: "Superior to periodic scans",
        impact: "40% faster than competitors",
        value: "Prevents certification lapses"
    },
    {
        feature: "AI Risk Forecasting",
        uniqueness: "CMMC-trained predictive models",
        impact: "3-6 month advance warnings",
        value: "Proactive POA&M management"
    },
    {
        feature: "90-Day Success Generator",
        uniqueness: "SPRS-ready automation",
        impact: "50% timeline reduction",
        value: "Audit-ready in 90 days vs 6-12 months"
    }
];

export default function CMMCMarketIntelligence() {
    const [activeTab, setActiveTab] = useState("overview");

    return (
        <div className="space-y-6">
            <BreadcrumbNav currentPageName="CMMC Market Intelligence" />
            
            <div className="text-center">
                <h1 className="text-4xl font-bold text-gray-900 mb-4">
                    CMMC Market Intelligence Dashboard (2025)
                </h1>
                <p className="text-xl text-gray-600 max-w-4xl mx-auto">
                    Comprehensive analysis of the $2.5B CMMC compliance market, AI adoption trends, and HyperCore's competitive positioning.
                </p>
            </div>

            <Alert className="bg-blue-50 border-blue-200">
                <Shield className="h-4 w-4" />
                <AlertTitle className="text-blue-800 font-bold">Market Opportunity: $2.5B+ and Growing</AlertTitle>
                <AlertDescription className="text-blue-700">
                    With 337,968 DIB entities impacted and only 4% feeling prepared, the CMMC market represents a massive opportunity for AI-first solutions.
                    <strong> HyperCore's unique DFARS tools position us to capture significant market share.</strong>
                </AlertDescription>
            </Alert>

            <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="grid w-full grid-cols-6">
                    <TabsTrigger value="overview">Market Overview</TabsTrigger>
                    <TabsTrigger value="ai-adoption">AI Adoption</TabsTrigger>
                    <TabsTrigger value="pricing">Pricing Analysis</TabsTrigger>
                    <TabsTrigger value="competitors">Competitors</TabsTrigger>
                    <TabsTrigger value="hypercore">HyperCore Edge</TabsTrigger>
                    <TabsTrigger value="strategy">Strategic Actions</TabsTrigger>
                </TabsList>

                <TabsContent value="overview" className="space-y-6">
                    <div className="grid md:grid-cols-3 gap-6">
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2">
                                    <BarChart className="w-5 h-5 text-blue-600" />
                                    Market Size
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="text-3xl font-bold text-blue-600">{marketOverview.marketSize}</div>
                                <p className="text-sm text-gray-600">CMMC-specific market (2025)</p>
                                <p className="text-xs text-green-600 mt-1">CAGR: {marketOverview.cagr}</p>
                            </CardContent>
                        </Card>

                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2">
                                    <Users className="w-5 h-5 text-green-600" />
                                    Entities Impacted
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="text-3xl font-bold text-green-600">{marketOverview.entitiesImpacted}</div>
                                <p className="text-sm text-gray-600">DIB organizations affected</p>
                                <p className="text-xs text-green-600 mt-1">{marketOverview.smBPercentage} are SMBs</p>
                            </CardContent>
                        </Card>

                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2">
                                    <AlertTriangle className="w-5 h-5 text-red-600" />
                                    Market Gap
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="text-3xl font-bold text-red-600">{marketOverview.preparednessRate}</div>
                                <p className="text-sm text-gray-600">Feel fully prepared</p>
                                <p className="text-xs text-red-600 mt-1">96% need solutions</p>
                            </CardContent>
                        </Card>
                    </div>

                    <Card>
                        <CardHeader>
                            <CardTitle>Key Market Dynamics</CardTitle>
                            <CardDescription>Critical factors shaping the CMMC landscape</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <div className="grid md:grid-cols-2 gap-6">
                                <div>
                                    <h4 className="font-semibold text-green-800 mb-3">Market Drivers</h4>
                                    <ul className="space-y-2 text-sm">
                                        <li className="flex items-center gap-2">
                                            <CheckCircle className="w-4 h-4 text-green-600" />
                                            CMMC 2.0 effective November 10, 2025
                                        </li>
                                        <li className="flex items-center gap-2">
                                            <CheckCircle className="w-4 h-4 text-green-600" />
                                            Phased rollout: 15% Q4 2025, full by 2028
                                        </li>
                                        <li className="flex items-center gap-2">
                                            <CheckCircle className="w-4 h-4 text-green-600" />
                                            $150B+ DoD small business awards
                                        </li>
                                        <li className="flex items-center gap-2">
                                            <CheckCircle className="w-4 h-4 text-green-600" />
                                            Only ~2,000 C3PAOs for 300K+ entities
                                        </li>
                                    </ul>
                                </div>
                                <div>
                                    <h4 className="font-semibold text-red-800 mb-3">Market Challenges</h4>
                                    <ul className="space-y-2 text-sm">
                                        <li className="flex items-center gap-2">
                                            <AlertTriangle className="w-4 h-4 text-red-600" />
                                            3.5M global cybersecurity talent shortage
                                        </li>
                                        <li className="flex items-center gap-2">
                                            <AlertTriangle className="w-4 h-4 text-red-600" />
                                            75% overestimate compliance readiness
                                        </li>
                                        <li className="flex items-center gap-2">
                                            <AlertTriangle className="w-4 h-4 text-red-600" />
                                            70% of breaches originate from subs
                                        </li>
                                        <li className="flex items-center gap-2">
                                            <AlertTriangle className="w-4 h-4 text-red-600" />
                                            FCA penalties up to $1M+ per violation
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="ai-adoption" className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-6">
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2">
                                    <Brain className="w-5 h-5 text-purple-600" />
                                    AI Adoption Metrics
                                </CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                <div className="flex justify-between items-center">
                                    <span>Current AI Adoption Rate:</span>
                                    <Badge className="bg-purple-100 text-purple-800">{aiAdoption.currentRate}</Badge>
                                </div>
                                <div className="flex justify-between items-center">
                                    <span>Planned AI Investment by 2025:</span>
                                    <Badge className="bg-blue-100 text-blue-800">{aiAdoption.plannedInvestment}</Badge>
                                </div>
                                <div className="flex justify-between items-center">
                                    <span>vCISO Workload Reduction:</span>
                                    <Badge className="bg-green-100 text-green-800">{aiAdoption.workloadReduction}</Badge>
                                </div>
                                <div className="flex justify-between items-center">
                                    <span>Breach Reduction:</span>
                                    <Badge className="bg-green-100 text-green-800">{aiAdoption.breachReduction}</Badge>
                                </div>
                            </CardContent>
                        </Card>

                        <Card>
                            <CardHeader>
                                <CardTitle>AI Implementation Barriers</CardTitle>
                                <CardDescription>Key challenges organizations face</CardDescription>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-3">
                                    <div className="flex items-center justify-between">
                                        <span className="text-sm">Integration Complexity</span>
                                        <div className="flex items-center gap-2">
                                            <div className="w-24 bg-gray-200 rounded-full h-2">
                                                <div className="bg-red-500 h-2 rounded-full w-[30%]"></div>
                                            </div>
                                            <span className="text-xs">30%</span>
                                        </div>
                                    </div>
                                    <div className="flex items-center justify-between">
                                        <span className="text-sm">Team Training Needs</span>
                                        <div className="flex items-center gap-2">
                                            <div className="w-24 bg-gray-200 rounded-full h-2">
                                                <div className="bg-orange-500 h-2 rounded-full w-[25%]"></div>
                                            </div>
                                            <span className="text-xs">25%</span>
                                        </div>
                                    </div>
                                    <div className="flex items-center justify-between">
                                        <span className="text-sm">Trust in AI Insights</span>
                                        <div className="flex items-center gap-2">
                                            <div className="w-24 bg-gray-200 rounded-full h-2">
                                                <div className="bg-yellow-500 h-2 rounded-full w-[20%]"></div>
                                            </div>
                                            <span className="text-xs">20%</span>
                                        </div>
                                    </div>
                                </div>
                                <Alert className="mt-4 bg-green-50 border-green-200">
                                    <CheckCircle className="h-4 w-4 text-green-600" />
                                    <AlertDescription className="text-green-700 text-sm">
                                        <strong>HyperCore Advantage:</strong> Our intuitive interface and proven accuracy (25% better than competitors) directly addresses these barriers.
                                    </AlertDescription>
                                </Alert>
                            </CardContent>
                        </Card>
                    </div>
                </TabsContent>

                <TabsContent value="pricing" className="space-y-6">
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <DollarSign className="w-5 h-5 text-green-600" />
                                Pricing Structure Analysis
                            </CardTitle>
                            <CardDescription>Traditional vs. AI-enabled pricing comparison</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <Table>
                                <TableHeader>
                                    <TableRow>
                                        <TableHead>Category</TableHead>
                                        <TableHead>Traditional</TableHead>
                                        <TableHead>AI-Enabled</TableHead>
                                        <TableHead>Savings</TableHead>
                                        <TableHead>Notes</TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {pricingStructure.map((item, index) => (
                                        <TableRow key={index}>
                                            <TableCell className="font-medium">{item.category}</TableCell>
                                            <TableCell>{item.traditional}</TableCell>
                                            <TableCell className="text-green-600 font-semibold">{item.aiEnabled}</TableCell>
                                            <TableCell>
                                                <Badge className="bg-green-100 text-green-800">{item.savings}</Badge>
                                            </TableCell>
                                            <TableCell className="text-sm text-gray-600">{item.notes}</TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </CardContent>
                    </Card>

                    <Alert className="bg-yellow-50 border-yellow-200">
                        <AlertTriangle className="h-4 w-4 text-yellow-600" />
                        <AlertTitle className="text-yellow-800">Total SMB Impact</AlertTitle>
                        <AlertDescription className="text-yellow-700">
                            Traditional approach: <strong>$20K-50K initial + $5K-10K/year ongoing</strong><br/>
                            HyperCore AI approach: <strong>$5K-15K total (60-70% savings)</strong>
                        </AlertDescription>
                    </Alert>
                </TabsContent>

                <TabsContent value="competitors" className="space-y-6">
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <Target className="w-5 h-5 text-red-600" />
                                Competitive Analysis
                            </CardTitle>
                            <CardDescription>Detailed comparison of key market players</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-4">
                                {competitorAnalysis.map((comp, index) => (
                                    <div key={index} className="p-4 border rounded-lg">
                                        <div className="flex justify-between items-start mb-3">
                                            <h4 className="font-semibold text-lg">{comp.competitor}</h4>
                                            <Badge variant="outline">{comp.pricing}</Badge>
                                        </div>
                                        <div className="grid md:grid-cols-3 gap-4 text-sm">
                                            <div>
                                                <h5 className="font-medium text-green-700 mb-1">Strengths:</h5>
                                                <p className="text-gray-600">{comp.strengths}</p>
                                            </div>
                                            <div>
                                                <h5 className="font-medium text-red-700 mb-1">Weaknesses:</h5>
                                                <p className="text-gray-600">{comp.weaknesses}</p>
                                            </div>
                                            <div>
                                                <h5 className="font-medium text-blue-700 mb-1">HyperCore Edge:</h5>
                                                <p className="text-gray-600">{comp.hypercoreAdvantage}</p>
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="hypercore" className="space-y-6">
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <Zap className="w-5 h-5 text-purple-600" />
                                HyperCore's Competitive Edge
                            </CardTitle>
                            <CardDescription>Unique capabilities that set us apart</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-4">
                                {hypercoreEdge.map((feature, index) => (
                                    <div key={index} className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                                        <h4 className="font-semibold text-blue-900 mb-2">{feature.feature}</h4>
                                        <div className="grid md:grid-cols-3 gap-4 text-sm">
                                            <div>
                                                <span className="font-medium text-purple-700">Uniqueness: </span>
                                                <span className="text-gray-700">{feature.uniqueness}</span>
                                            </div>
                                            <div>
                                                <span className="font-medium text-green-700">Impact: </span>
                                                <span className="text-gray-700">{feature.impact}</span>
                                            </div>
                                            <div>
                                                <span className="font-medium text-blue-700">Value: </span>
                                                <span className="text-gray-700">{feature.value}</span>
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    <Alert className="bg-purple-50 border-purple-200">
                        <Zap className="h-4 w-4 text-purple-600" />
                        <AlertTitle className="text-purple-800">Market Positioning</AlertTitle>
                        <AlertDescription className="text-purple-700">
                            HyperCore is the <strong>only platform</strong> offering contract intelligence combined with continuous compliance monitoring. 
                            This unique positioning allows us to capture market share from both consulting firms and static GRC tools.
                        </AlertDescription>
                    </Alert>
                </TabsContent>

                <TabsContent value="strategy" className="space-y-6">
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <TrendingUp className="w-5 h-5 text-green-600" />
                                Strategic Action Plan
                            </CardTitle>
                            <CardDescription>Key recommendations based on market intelligence</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-6">
                                <div className="grid md:grid-cols-2 gap-6">
                                    <div className="p-4 bg-green-50 rounded-lg">
                                        <h4 className="font-semibold text-green-800 mb-3">Immediate Actions (Q4 2025)</h4>
                                        <ul className="space-y-2 text-sm">
                                            <li className="flex items-center gap-2">
                                                <CheckCircle className="w-4 h-4 text-green-600" />
                                                Launch DFARS Risk Calculator lead magnet
                                            </li>
                                            <li className="flex items-center gap-2">
                                                <CheckCircle className="w-4 h-4 text-green-600" />
                                                Execute NoVA ABM campaigns targeting primes
                                            </li>
                                            <li className="flex items-center gap-2">
                                                <CheckCircle className="w-4 h-4 text-green-600" />
                                                Host quarterly DFARS survival webinars
                                            </li>
                                            <li className="flex items-center gap-2">
                                                <CheckCircle className="w-4 h-4 text-green-600" />
                                                Publish DFARS vs CMMC content cluster
                                            </li>
                                        </ul>
                                    </div>
                                    <div className="p-4 bg-blue-50 rounded-lg">
                                        <h4 className="font-semibold text-blue-800 mb-3">Medium-term Goals (2026)</h4>
                                        <ul className="space-y-2 text-sm">
                                            <li className="flex items-center gap-2">
                                                <Target className="w-4 h-4 text-blue-600" />
                                                Capture 5-10% of SMB market ($125-250M opportunity)
                                            </li>
                                            <li className="flex items-center gap-2">
                                                <Target className="w-4 h-4 text-blue-600" />
                                                Partner with 3 major C3PAOs for referrals
                                            </li>
                                            <li className="flex items-center gap-2">
                                                <Target className="w-4 h-4 text-blue-600" />
                                                Launch enterprise tier for prime contractors
                                            </li>
                                            <li className="flex items-center gap-2">
                                                <Target className="w-4 h-4 text-blue-600" />
                                                Achieve top-3 SERP for key CMMC terms
                                            </li>
                                        </ul>
                                    </div>
                                </div>

                                <Alert className="bg-gradient-to-r from-purple-500 to-blue-600 text-white border-0">
                                    <Rocket className="h-4 w-4 text-white" />
                                    <AlertTitle className="text-white font-bold">Strategic Imperative</AlertTitle>
                                    <AlertDescription className="text-white">
                                        The CMMC market window is opening NOW. With only 4% of DIB entities prepared and our unique contract intelligence capabilities, 
                                        we have 6-12 months to establish market dominance before competitors catch up.
                                    </AlertDescription>
                                </Alert>

                                <div className="flex gap-4">
                                    <Button asChild size="lg" className="bg-purple-600 hover:bg-purple-700">
                                        <Link to={createPageUrl('DFARSMarketingStrategy')}>
                                            Execute Marketing Strategy
                                        </Link>
                                    </Button>
                                    <Button asChild size="lg" variant="outline">
                                        <Link to={createPageUrl('SBIRProposalStrategy')}>
                                            Review SBIR Strategy
                                        </Link>
                                    </Button>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>
            </Tabs>
        </div>
    );
}
