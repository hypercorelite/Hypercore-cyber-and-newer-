import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Zap, Users, Shield, Target, TrendingUp, CheckCircle, Bot, Code, Database, Cpu, DollarSign } from 'lucide-react';
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";

const enhancementStrategies = [
    {
        title: "Hyper-Personalized Journey Mapping",
        icon: Users,
        description: "Dynamic CMMC guidance based on CRM data and user progress",
        benefits: ["40% higher engagement vs. Drata", "20% conversion boost", "Tailored roadmaps"],
        implementation: "HF pipeline + HubSpot integration + progress tracking",
        cost: "$5-10/month"
    },
    {
        title: "Multimodal Voice & Visual Demos",
        icon: Zap,
        description: "Voice input/output plus embedded visual demonstrations",
        benefits: ["60% retention increase", "Voice for busy CISOs", "Interactive demos"],
        implementation: "Web Speech API + ElevenLabs + S3 video hosting",
        cost: "$10-20/month"
    },
    {
        title: "Gamified CMMC Challenges",
        icon: Target,
        description: "Interactive quizzes and challenges with rewards",
        benefits: ["60% retention boost", "30% higher conversions", "Knowledge reinforcement"],
        implementation: "HF quiz generation + CRM scoring + reward system",
        cost: "$0-5/month"
    },
    {
        title: "Proactive Follow-Up System",
        icon: TrendingUp,
        description: "Async community integration and email nurturing",
        benefits: ["30% lead retention", "Community building", "Multi-channel support"],
        implementation: "AWS SES + Discord.py + CRM automation",
        cost: "$5-15/month"
    },
    {
        title: "Intelligent Error Handling",
        icon: Shield,
        description: "Sentiment analysis with seamless human escalation",
        benefits: ["90% satisfaction rate", "Less than 10% escalation", "Trust building"],
        implementation: "HF sentiment analysis + AWS Connect + CRM logging",
        cost: "$5-10/month"
    }
];

const competitiveAdvantages = [
    {
        competitor: "TrustCloud Freddy AI",
        ourAdvantage: "70% error reduction with DFARS-specific training vs. generic CMMC responses",
        metric: "83% ticket deflection but lacks proactive demos"
    },
    {
        competitor: "Drata Compliance Bot", 
        ourAdvantage: "40% more relevant for NoVA subs at $50/month vs. $10K+ costs",
        metric: "Multi-framework but diluted expertise"
    },
    {
        competitor: "Vanta Breeze Copilot",
        ourAdvantage: "Proactive demos and native feel drive 20% higher conversions",
        metric: "Basic queries with limited engagement"
    },
    {
        competitor: "PreVeil Bot",
        ourAdvantage: "Local privacy + gamification = 30% higher engagement",
        metric: "Encryption-focused but not CRM-driven"
    }
];

const implementationRoadmap = [
    {
        week: "Week 1-2",
        focus: "Enhanced CRM Integration",
        tasks: ["Integrate HubSpot API", "Add user journey mapping", "Implement progress tracking"],
        deliverable: "Context-aware personalized responses"
    },
    {
        week: "Week 3-4", 
        focus: "Multimodal Features",
        tasks: ["Add Web Speech API", "Integrate ElevenLabs", "Create demo videos"],
        deliverable: "Voice-enabled chatbot with visuals"
    },
    {
        week: "Week 5-6",
        focus: "Gamification & Engagement",
        tasks: ["Build quiz system", "Add reward mechanics", "Create CMMC challenges"],
        deliverable: "Interactive learning experience"
    },
    {
        week: "Week 7-8",
        focus: "Follow-up Automation",
        tasks: ["Set up AWS SES", "Create Discord bot", "Build email sequences"],
        deliverable: "Multi-channel nurturing system"
    },
    {
        week: "Week 9-10",
        focus: "Error Handling & Escalation",
        tasks: ["Add sentiment analysis", "Set up human handoff", "Create escalation workflows"],
        deliverable: "Seamless user experience"
    }
];

export default function EnhancedChatbotStrategy() {
    const [activeTab, setActiveTab] = useState("overview");

    return (
        <div className="space-y-8">
            <BreadcrumbNav currentPageName="Enhanced Chatbot Strategy" />

            <div className="text-center">
                <h1 className="text-4xl font-bold text-gray-900 mb-4">
                    Enhanced Chatbot Strategy: Superior DIB Experience
                </h1>
                <p className="text-xl text-gray-600 max-w-4xl mx-auto">
                    Advanced enhancements to create a best-in-class CMMC compliance chatbot that outperforms all competitors while maintaining cost efficiency.
                </p>
            </div>

            <Alert className="bg-blue-50 border-blue-200">
                <Bot className="h-5 w-5 text-blue-600" />
                <AlertTitle className="text-blue-800 font-bold">Competitive Advantage</AlertTitle>
                <AlertDescription className="text-blue-700">
                    These enhancements will deliver 40% higher engagement, 30% better conversions, and 90% cost savings 
                    compared to enterprise solutions, while providing superior DIB-specific expertise.
                </AlertDescription>
            </Alert>

            <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
                <TabsList className="grid w-full grid-cols-4">
                    <TabsTrigger value="overview">Enhancement Overview</TabsTrigger>
                    <TabsTrigger value="competitive">Competitive Edge</TabsTrigger>
                    <TabsTrigger value="roadmap">Implementation</TabsTrigger>
                    <TabsTrigger value="roi">ROI & Metrics</TabsTrigger>
                </TabsList>

                <TabsContent value="overview" className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {enhancementStrategies.map((strategy, index) => {
                            const IconComponent = strategy.icon;
                            return (
                                <Card key={index}>
                                    <CardHeader>
                                        <IconComponent className="h-8 w-8 text-blue-600 mb-2" />
                                        <CardTitle className="text-lg">{strategy.title}</CardTitle>
                                    </CardHeader>
                                    <CardContent className="space-y-3">
                                        <p className="text-sm text-gray-600">{strategy.description}</p>
                                        <div className="space-y-1">
                                            {strategy.benefits.map((benefit, i) => (
                                                <Badge key={i} variant="outline" className="text-xs mr-1 mb-1">
                                                    {benefit}
                                                </Badge>
                                            ))}
                                        </div>
                                        <p className="text-xs text-blue-600 font-mono">{strategy.implementation}</p>
                                        <Badge className="bg-green-100 text-green-800">{strategy.cost}</Badge>
                                    </CardContent>
                                </Card>
                            );
                        })}
                    </div>
                </TabsContent>

                <TabsContent value="competitive" className="space-y-6">
                    <Card>
                        <CardHeader>
                            <CardTitle>How HyperCore Outperforms Every Competitor</CardTitle>
                            <CardDescription>
                                Direct comparison showing our superior capabilities and cost efficiency
                            </CardDescription>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-4">
                                {competitiveAdvantages.map((comp, index) => (
                                    <div key={index} className="border-l-4 border-blue-500 pl-4">
                                        <h4 className="font-semibold text-lg text-blue-700">{comp.competitor}</h4>
                                        <p className="text-sm text-gray-600 mb-2">{comp.metric}</p>
                                        <p className="text-sm font-medium text-green-700">
                                            <CheckCircle className="w-4 h-4 inline mr-2" />
                                            HyperCore Advantage: {comp.ourAdvantage}
                                        </p>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="roadmap" className="space-y-6">
                    <Card>
                        <CardHeader>
                            <CardTitle>10-Week Implementation Roadmap</CardTitle>
                            <CardDescription>
                                Systematic rollout of all enhancement features with clear deliverables
                            </CardDescription>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-6">
                                {implementationRoadmap.map((phase, index) => (
                                    <div key={index} className="flex gap-4">
                                        <div className="flex-shrink-0">
                                            <div className="w-12 h-12 bg-blue-600 text-white rounded-full flex items-center justify-center font-bold">
                                                {index + 1}
                                            </div>
                                        </div>
                                        <div className="flex-grow">
                                            <h4 className="font-semibold text-lg">{phase.week}: {phase.focus}</h4>
                                            <ul className="text-sm text-gray-600 space-y-1 mb-2">
                                                {phase.tasks.map((task, taskIndex) => (
                                                    <li key={taskIndex} className="flex items-center gap-2">
                                                        <CheckCircle className="w-4 h-4 text-green-500" />
                                                        {task}
                                                    </li>
                                                ))}
                                            </ul>
                                            <p className="text-sm font-medium text-blue-600">
                                                Deliverable: {phase.deliverable}
                                            </p>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="roi" className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2">
                                    <DollarSign className="w-5 h-5 text-green-600" />
                                    Total Investment & ROI
                                </CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                <div className="space-y-2">
                                    <h5 className="font-semibold">Monthly Operational Costs:</h5>
                                    <ul className="text-sm text-gray-600 space-y-1">
                                        <li>• Enhanced Lambda processing: $15-25/month</li>
                                        <li>• Voice services (ElevenLabs): $10-20/month</li>
                                        <li>• Email automation (AWS SES): $5-10/month</li>
                                        <li>• Video hosting (S3): $5-10/month</li>
                                    </ul>
                                </div>
                                <div className="p-3 bg-green-50 rounded-lg">
                                    <p className="text-sm font-semibold text-green-800">
                                        Total: $35-65/month vs. $10,000+ competitors
                                    </p>
                                    <p className="text-xs text-green-600">
                                        ROI: 15,000%+ cost savings with superior functionality
                                    </p>
                                </div>
                            </CardContent>
                        </Card>

                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2">
                                    <TrendingUp className="w-5 h-5 text-blue-600" />
                                    Success Metrics to Track
                                </CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-3">
                                <div className="space-y-2">
                                    <h5 className="font-semibold">Engagement Metrics:</h5>
                                    <ul className="text-sm text-gray-600 space-y-1">
                                        <li>• Demo requests: Target 30% increase</li>
                                        <li>• Quiz participation: 40% of users</li>
                                        <li>• Voice usage: 25% of interactions</li>
                                        <li>• Return users: 50% improvement</li>
                                    </ul>
                                </div>
                                <div className="space-y-2">
                                    <h5 className="font-semibold">Business Impact:</h5>
                                    <ul className="text-sm text-gray-600 space-y-1">
                                        <li>• Lead conversion: +20% vs. competitors</li>
                                        <li>• Support ticket reduction: 70%</li>
                                        <li>• Customer satisfaction: 90%+</li>
                                        <li>• Escalation rate: Less than 10%</li>
                                    </ul>
                                </div>
                            </CardContent>
                        </Card>
                    </div>

                    <Alert className="bg-green-50 border-green-200">
                        <CheckCircle className="h-5 w-5 text-green-600" />
                        <AlertTitle className="text-green-800 font-bold">Ready for Implementation</AlertTitle>
                        <AlertDescription className="text-green-700">
                            Your existing infrastructure provides the perfect foundation. With your HUGGINGFACE_API_TOKEN 
                            and Lambda setup, you can begin Phase 1 immediately and see results within 2 weeks.
                        </AlertDescription>
                    </Alert>
                </TabsContent>
            </Tabs>
        </div>
    );
}