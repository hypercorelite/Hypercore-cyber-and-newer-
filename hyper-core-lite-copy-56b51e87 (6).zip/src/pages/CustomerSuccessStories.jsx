
import React, { useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ArrowRight, Clock, DollarSign, Shield, Zap, Users } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";

const platformCapabilities = [
    {
        profile: "Precision Machining Subcontractors (35-50 employees)",
        challenge: "Face impossible 6-month deadlines and $75,000+ consultant quotes to meet Prime CMMC Level 2 requirements.",
        solution: "Our platform can generate complete, audit-ready SSPs and all 14 required policies in under 2 hours.",
        potentialImpact: {
            cost: "$70,000+ savings",
            time: "4+ months saved", 
            outcome: "Meet deadlines & secure contract eligibility"
        },
        tags: ["DoD Subcontractor", "Manufacturing"]
    },
    {
        profile: "IT Services Prime Contractors (100-200 employees)",
        challenge: "Lack visibility into compliance status of 10-20 subcontractors, risking multi-million dollar contract renewals.",
        solution: "Platform provides unified, real-time dashboard of supply chain compliance posture with automated assessments.",
        potentialImpact: {
            cost: "$100,000+ risk mitigation",
            time: "Real-time visibility",
            outcome: "De-risk prime contract renewals"
        },
        tags: ["DoD Prime Contractor", "IT Services"]
    },
    {
        profile: "New DoD Market Entrants (10-30 employees)",
        challenge: "CMMC compliance is the primary barrier to bidding on first DoD contracts with zero internal cybersecurity expertise.",
        solution: "AI-driven platform can take companies from 0% to 85%+ compliance readiness in one week.",
        potentialImpact: {
            cost: "$50,000+ saved vs consultants",
            time: "1 week vs 6+ months",
            outcome: "Compete against larger firms for first contracts"
        },
        tags: ["New DoD Entrant", "R&D"]
    }
];

const keyMetrics = [
    { icon: Clock, value: "90% Faster", description: "Platform generates audit-ready documentation in hours, not months." },
    { icon: DollarSign, value: "$45K+ Potential Savings", description: "Versus the cost of traditional consultants and manual processes." },
    { icon: Shield, value: "110 NIST Controls", description: "Complete automation of all CMMC Level 2 requirements." }
];

export default function CustomerSuccessStories() {
    useEffect(() => {
        document.title = "CMMC Compliance Platform for DoD Contractors | HyperCore AI";
        document.querySelector('meta[name="description"]')?.setAttribute('content',
            "See how HyperCore's AI-first CMMC compliance platform can help SMB DoD contractors achieve compliance 90% faster and save $45K+ versus traditional consultants."
        );
    }, []);

    return (
        <div className="bg-gray-50">
            <div className="max-w-7xl mx-auto px-4 py-12 sm:px-6 lg:px-8">
                <BreadcrumbNav currentPageName="CustomerSuccessStories" />
                <div className="text-center">
                    <h1 className="text-4xl font-extrabold tracking-tight text-gray-900 sm:text-5xl">
                        How DoD Contractors Can Win with AI-First CMMC Compliance
                    </h1>
                    <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-500">
                        Platform capabilities designed specifically for SMB defense contractors who need to replace expensive consultants and slow GRC tools with AI automation.
                    </p>
                </div>

                <div className="mt-12 grid gap-8 md:grid-cols-3">
                    {keyMetrics.map((metric, index) => {
                        const Icon = metric.icon;
                        return (
                            <Card key={index} className="text-center shadow-lg">
                                <CardContent className="p-6">
                                    <Icon className="mx-auto h-12 w-12 text-blue-600" />
                                    <h3 className="mt-5 text-2xl font-bold text-gray-900">{metric.value}</h3>
                                    <p className="mt-2 text-base text-gray-500">{metric.description}</p>
                                </CardContent>
                            </Card>
                        );
                    })}
                </div>

                <div className="mt-20">
                    <div className="text-center mb-12">
                        <h2 className="text-3xl font-bold text-gray-900">Platform Capabilities for Real DoD Contractor Challenges</h2>
                        <p className="mt-4 text-lg text-gray-600">How our AI-first model addresses the specific compliance challenges SMB contractors face</p>
                    </div>
                    
                    <div className="grid gap-16 lg:grid-cols-2 lg:gap-x-12">
                        {platformCapabilities.map((capability, index) => (
                            <div key={index} className="bg-white p-8 rounded-2xl shadow-xl">
                                <div className="space-y-1">
                                    {capability.tags.map(tag => <Badge key={tag} variant="secondary">{tag}</Badge>)}
                                </div>
                                <h3 className="mt-4 text-2xl font-bold text-gray-900">{capability.profile}</h3>
                                <p className="mt-3 text-gray-600"><strong>Common Challenge:</strong> {capability.challenge}</p>
                                <p className="mt-3 text-gray-600 bg-blue-50 p-3 rounded-lg border border-blue-200">
                                    <strong>How Our Platform Helps:</strong> {capability.solution}
                                </p>
                                <Card className="mt-4 bg-gray-50">
                                    <CardHeader>
                                        <CardTitle className="text-lg">Potential Impact</CardTitle>
                                    </CardHeader>
                                    <CardContent className="grid grid-cols-3 gap-4 text-center">
                                        <div>
                                            <p className="text-sm text-gray-500">Potential Savings</p>
                                            <p className="text-lg font-bold text-green-600">{capability.potentialImpact.cost}</p>
                                        </div>
                                        <div>
                                            <p className="text-sm text-gray-500">Time Advantage</p>
                                            <p className="text-lg font-bold text-blue-600">{capability.potentialImpact.time}</p>
                                        </div>
                                        <div>
                                            <p className="text-sm text-gray-500">Expected Outcome</p>
                                            <p className="text-lg font-bold text-purple-600">{capability.potentialImpact.outcome}</p>
                                        </div>
                                    </CardContent>
                                </Card>
                            </div>
                        ))}
                    </div>
                </div>

                <div className="mt-20 bg-blue-600 rounded-2xl p-12 text-center text-white">
                    <h2 className="text-3xl font-bold">Ready to Test Our Platform with Your Real CMMC Challenge?</h2>
                    <p className="mt-4 text-lg text-blue-100">
                        Join our free trial program and see how AI automation can solve your specific compliance requirements in hours, not months.
                    </p>
                    <Button asChild size="lg" className="mt-8 bg-white text-blue-600 hover:bg-gray-100">
                        <Link to={createPageUrl('PartnershipTrial')}>
                            Start Your Free Compliance Assessment <ArrowRight className="w-4 h-4 ml-2" />
                        </Link>
                    </Button>
                </div>
            </div>
        </div>
    );
}
