
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { User } from '@/api/entities';
import { AuditLog } from '@/api/entities';
import { ClientOnboarding } from '@/api/entities';
import { LetterOfIntent } from '@/api/entities';
import { 
    Command, 
    Users, 
    TrendingUp, 
    Calendar, 
    Clock,
    Target,
    Rocket,
    AlertTriangle,
    CheckCircle,
    DollarSign,
    Mail,
    FileText,
    Settings,
    BarChart3,
    Zap
} from 'lucide-react';
import { toast } from "sonner";
import { motion } from "framer-motion";
import BreadcrumbNav from "@/components/navigation/BreadcrumbNav";

export default function AdminCommandCenter() {
    const [stats, setStats] = useState({
        totalUsers: 0,
        activeTrials: 0,
        loiSubmissions: 0,
        conversionRate: 0,
        daysToDeadline: 52 // Nov 10, 2025 - Sept 19, 2025
    });
    const [recentActivity, setRecentActivity] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        loadDashboardData();
        const interval = setInterval(loadDashboardData, 30000); // Refresh every 30 seconds
        return () => clearInterval(interval);
    }, []);

    const loadDashboardData = async () => {
        try {
            // Load key metrics
            const [users, clients, lois, logs] = await Promise.all([
                User.list(),
                ClientOnboarding.list(),
                LetterOfIntent.list(),
                AuditLog.list('-created_date', 10)
            ]);

            const activeTrials = clients.filter(c => 
                c.onboarding_stage !== 'email_captured' && 
                c.onboarding_stage !== 'conversion_interested'
            ).length;

            const conversionRate = clients.length > 0 
                ? Math.round((lois.length / clients.length) * 100)
                : 0;

            setStats({
                totalUsers: users.length,
                activeTrials,
                loiSubmissions: lois.length,
                conversionRate,
                daysToDeadline: Math.ceil((new Date('2025-11-10') - new Date()) / (1000 * 60 * 60 * 24))
            });

            setRecentActivity(logs.slice(0, 10));
            
        } catch (error) {
            console.error('Failed to load dashboard data:', error);
            toast.error('Failed to load dashboard data');
        } finally {
            setLoading(false);
        }
    };

    const quickActions = [
        { 
            name: 'Review LOI Pipeline', 
            href: '/admin/loi-tracking-dashboard', 
            icon: FileText,
            description: 'Manage incoming Letters of Intent'
        },
        { 
            name: 'Campaign Management', 
            href: '/admin/linkedin-campaign-strategy', 
            icon: Mail,
            description: 'Execute publication and outreach campaigns'
        },
        { 
            name: 'SEO Performance', 
            href: '/admin/seo-metrics-dashboard', 
            icon: TrendingUp,
            description: 'Monitor search visibility and traffic'
        },
        { 
            name: 'Client Analytics', 
            href: '/admin/analytics-dashboard', 
            icon: BarChart3,
            description: 'Deep dive into user behavior and conversions'
        }
    ];

    const urgencyLevel = stats.daysToDeadline <= 60 ? 'critical' : stats.daysToDeadline <= 90 ? 'high' : 'medium';

    return (
        <div className="space-y-6">
            <BreadcrumbNav currentPageName="AdminCommandCenter" />
            
            {/* CMMC Deadline Alert */}
            <Alert className={`border-2 ${
                urgencyLevel === 'critical' ? 'border-red-500 bg-red-50' :
                urgencyLevel === 'high' ? 'border-orange-500 bg-orange-50' :
                'border-yellow-500 bg-yellow-50'
            }`}>
                <AlertTriangle className={`h-5 w-5 ${
                    urgencyLevel === 'critical' ? 'text-red-600' :
                    urgencyLevel === 'high' ? 'text-orange-600' :
                    'text-yellow-600'
                }`} />
                <AlertTitle className="text-xl font-bold">
                    🚨 CMMC 2.0 Rollout: {stats.daysToDeadline} Days Remaining
                </AlertTitle>
                <AlertDescription className="text-lg mt-2">
                    <strong>November 10, 2025</strong> - CMMC compliance becomes mandatory for new DoD contracts. 
                    300,000+ SMBs need solutions. This is your market window.
                </AlertDescription>
            </Alert>

            {/* Key Metrics Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
                    <Card>
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium">Total Users</CardTitle>
                            <Users className="h-4 w-4 text-muted-foreground" />
                        </CardHeader>
                        <CardContent>
                            <div className="text-2xl font-bold">{stats.totalUsers}</div>
                            <p className="text-xs text-muted-foreground">Registered platform users</p>
                        </CardContent>
                    </Card>
                </motion.div>

                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
                    <Card>
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium">Active Trials</CardTitle>
                            <Rocket className="h-4 w-4 text-muted-foreground" />
                        </CardHeader>
                        <CardContent>
                            <div className="text-2xl font-bold text-blue-600">{stats.activeTrials}</div>
                            <p className="text-xs text-muted-foreground">Users in assessment process</p>
                        </CardContent>
                    </Card>
                </motion.div>

                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
                    <Card>
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium">LOI Submissions</CardTitle>
                            <FileText className="h-4 w-4 text-muted-foreground" />
                        </CardHeader>
                        <CardContent>
                            <div className="text-2xl font-bold text-green-600">{stats.loiSubmissions}</div>
                            <p className="text-xs text-muted-foreground">Letters of Intent received</p>
                        </CardContent>
                    </Card>
                </motion.div>

                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
                    <Card>
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium">Conversion Rate</CardTitle>
                            <TrendingUp className="h-4 w-4 text-muted-foreground" />
                        </CardHeader>
                        <CardContent>
                            <div className="text-2xl font-bold text-purple-600">{stats.conversionRate}%</div>
                            <p className="text-xs text-muted-foreground">Trial to LOI conversion</p>
                        </CardContent>
                    </Card>
                </motion.div>
            </div>

            {/* Quick Actions */}
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Command className="h-5 w-5" />
                        Quick Actions
                    </CardTitle>
                    <CardDescription>Key tasks for the next 7 weeks until CMMC rollout</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {quickActions.map((action, index) => (
                            <motion.div
                                key={action.name}
                                initial={{ opacity: 0, x: -20 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ delay: 0.1 * index }}
                            >
                                <Button 
                                    variant="outline" 
                                    className="w-full h-auto p-4 justify-start"
                                    onClick={() => window.location.href = action.href}
                                >
                                    <action.icon className="h-5 w-5 mr-3" />
                                    <div className="text-left">
                                        <div className="font-medium">{action.name}</div>
                                        <div className="text-sm text-muted-foreground">{action.description}</div>
                                    </div>
                                </Button>
                            </motion.div>
                        ))}
                    </div>
                </CardContent>
            </Card>

            {/* Recent Activity */}
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Clock className="h-5 w-5" />
                        Recent Platform Activity
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    {loading ? (
                        <div className="text-center py-4">Loading recent activity...</div>
                    ) : recentActivity.length > 0 ? (
                        <div className="space-y-3">
                            {recentActivity.map((log, index) => (
                                <div key={log.id || index} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                                    <Badge variant="outline">
                                        {log.action_type}
                                    </Badge>
                                    <span className="flex-1 text-sm">{log.event_name}</span>
                                    <span className="text-xs text-muted-foreground">
                                        {new Date(log.created_date).toLocaleString()}
                                    </span>
                                </div>
                            ))}
                        </div>
                    ) : (
                        <div className="text-center py-4 text-muted-foreground">
                            No recent activity found
                        </div>
                    )}
                </CardContent>
            </Card>

            {/* Next Steps */}
            <Card className="border-green-200 bg-green-50">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-green-800">
                        <Target className="h-5 w-5" />
                        Immediate Priorities (Next 7 Days)
                    </CardTitle>
                </CardHeader>
                <CardContent className="text-green-700">
                    <ul className="space-y-2">
                        <li className="flex items-center gap-2">
                            <CheckCircle className="h-4 w-4" />
                            Execute Week 1 of the LinkedIn Campaign Strategy
                        </li>
                        <li className="flex items-center gap-2">
                            <CheckCircle className="h-4 w-4" />
                            Submit first publication pitch to Defense One
                        </li>
                        <li className="flex items-center gap-2">
                            <CheckCircle className="h-4 w-4" />
                            Monitor and optimize SEO performance
                        </li>
                        <li className="flex items-center gap-2">
                            <CheckCircle className="h-4 w-4" />
                            Track trial conversion metrics daily
                        </li>
                    </ul>
                </CardContent>
            </Card>
        </div>
    );
}
