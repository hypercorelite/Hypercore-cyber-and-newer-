
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge"; // Added import for Badge component
import { Calculator, TrendingDown, CheckCircle, Shield } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";

const controlWeights = {
    '5': 3, // Number of controls with weight 5
    '3': 20, // Number of controls with weight 3
    '1': 87  // Number of controls with weight 1
};

export default function SPRSScoreCalculator() {
    const [scores, setScores] = useState({ 5: 0, 3: 0, 1: 0 });
    const [sprsScore, setSprsScore] = useState(null);

    const handleCalculate = () => {
        const totalDeductions = (controlWeights['5'] - scores['5']) * 5 +
                                (controlWeights['3'] - scores['3']) * 3 +
                                (controlWeights['1'] - scores['1']) * 1;
        const finalScore = 110 - totalDeductions;
        setSprsScore(finalScore);
    };

    const handleScoreChange = (weight, value) => {
        const max = controlWeights[weight];
        const val = Math.min(max, Math.max(0, parseInt(value, 10) || 0));
        setScores(prev => ({ ...prev, [weight]: val }));
    };

    return (
        <div className="space-y-6">
            <BreadcrumbNav currentPageName="SPRSScoreCalculator" />
            <div className="text-center">
                <h1 className="text-3xl font-bold">SPRS Score Calculator</h1>
                <p className="text-lg text-gray-600">Calculate your NIST SP 800-171 DoD Assessment Summary Level Score for SPRS submission.</p>
            </div>

            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2"><Calculator /> Enter Implemented Controls</CardTitle>
                    <CardDescription>Input the number of fully implemented controls for each point value. The maximums are pre-filled.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    <div className="grid md:grid-cols-3 gap-6">
                        {Object.entries(controlWeights).map(([weight, max]) => (
                            <div key={weight}>
                                <label className="block text-sm font-bold mb-2">Controls with weight <Badge>{weight}</Badge></label>
                                <div className="flex items-center gap-2">
                                    <input
                                        type="number"
                                        value={scores[weight]}
                                        onChange={(e) => handleScoreChange(weight, e.target.value)}
                                        className="w-24 p-2 border rounded-md text-center"
                                        max={max}
                                        min={0}
                                    />
                                    <span className="text-gray-500">/ {max}</span>
                                </div>
                            </div>
                        ))}
                    </div>
                    <Button onClick={handleCalculate} className="w-full" size="lg">Calculate Score</Button>
                </CardContent>
            </Card>

            <AnimatePresence>
                {sprsScore !== null && (
                    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
                        <Card className={`border-2 ${sprsScore > 0 ? 'border-blue-300 bg-blue-50' : 'border-red-300 bg-red-50'}`}>
                            <CardHeader>
                                <CardTitle>Your Estimated SPRS Score</CardTitle>
                            </CardHeader>
                            <CardContent className="text-center">
                                <p className={`text-6xl font-bold ${sprsScore > 0 ? 'text-blue-600' : 'text-red-600'}`}>{sprsScore}</p>
                                <p className="text-gray-600 mt-2">Maximum possible score is 110. Minimum is -203.</p>
                                <div className="mt-4 flex items-center justify-center gap-2 text-sm text-gray-700">
                                    <Shield className="w-4 h-4" /> This score must be uploaded to the DoD's SPRS portal.
                                </div>
                            </CardContent>
                        </Card>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
}
