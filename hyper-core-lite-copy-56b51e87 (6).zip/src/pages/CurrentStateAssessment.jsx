
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { motion } from "framer-motion";
import { 
    CheckCircle, 
    AlertTriangle, 
    Clock, 
    Shield, 
    Database,
    Server,
    Code,
    DollarSign,
    Users,
    FileText,
    Zap,
    Scale,
    Umbrella,
    Building,
    Rocket
} from 'lucide-react';

// What we actually have TODAY (be brutally honest)
const CURRENT_DELIVERABLES = {
    operational: [
        {
            name: "HyperCore Platform (Base44 Framework)",
            status: "fully_operational",
            description: "User authentication, entity management, responsive UI, secure backend functions",
            demo_ready: true,
            production_ready: true,
            partner_value: "Secure, professional platform infrastructure"
        },
        {
            name: "IP Reputation Analysis (AbuseIPDB Integration)",
            status: "fully_operational", 
            description: "Real-time threat intelligence lookup with professional reporting",
            demo_ready: true,
            production_ready: true,
            partner_value: "Immediate cybersecurity intelligence for legal/insurance risk assessment"
        },
        {
            name: "AI Model Integration (HuggingFace)",
            status: "fully_operational",
            description: "Backend functions can query AI models, process responses, generate insights",
            demo_ready: true,
            production_ready: true,
            partner_value: "Proven AI capability foundation for custom tools"
        },
        {
            name: "Professional Demo Interface",
            status: "fully_operational",
            description: "Clean, branded interface suitable for client presentations",
            demo_ready: true,
            production_ready: true,
            partner_value: "Professional appearance for partnership meetings"
        }
    ],
    in_development: [
        {
            name: "Contract Intelligence Tool",
            status: "framework_ready",
            description: "UI built, backend functions exist, needs specific AI training for contract analysis",
            demo_ready: false,
            production_ready: false,
            weeks_to_complete: 2,
            partner_value: "AI-powered contract analysis for law firms"
        },
        {
            name: "Policy Optimization Advisor", 
            status: "framework_ready",
            description: "Architecture defined, needs implementation of insurance-specific algorithms",
            demo_ready: false,
            production_ready: false,
            weeks_to_complete: 3,
            partner_value: "Risk assessment and policy optimization for insurance carriers"
        },
        {
            name: "CMMC Assessment Engine",
            status: "basic_functional",
            description: "Assessment framework exists, needs refinement for production use",
            demo_ready: true,
            production_ready: false,
            weeks_to_complete: 4,
            partner_value: "Automated CMMC compliance for government contractors"
        }
    ],
    planned: [
        {
            name: "Advanced AI Training Pipeline",
            status: "concept",
            description: "Systematic approach to training industry-specific AI models",
            weeks_to_complete: 8,
            partner_value: "Continuously improving AI capabilities"
        }
    ]
};

// Updated to reflect business formation
const POST_FORMATION_ROADMAP = {
    immediate_actions: {
        title: "Phase 1: Immediate Actions (Sept - Oct 2025)",
        budget: "$5,000",
        actions: [
            {
                task: "Secure First Client ($25k+ upfront)",
                cost: "$500 (marketing/outreach)",
                outcome: "Cash flow to fund all other operations"
            },
            {
                task: "Complete AWS Migration & Initial Setup",
                cost: "$1,500 (dev time + initial services)",
                outcome: "Enterprise-grade platform live"
            },
            {
                task: "Finalize Partnership Agreement Templates",
                cost: "$1,000 (legal review)",
                outcome: "Ready to sign law firm partners"
            }
        ]
    },
    development_sprint: {
        title: "Phase 2: Development & Delivery (Nov 2025 - Jan 2026)",
        budget: "$15,000 (Funded by client revenue)",
        actions: [
            {
                task: "Deliver on First CMMC Client Contract",
                cost: "$0 (operational)",
                outcome: "Successful case study and reference"
            },
            {
                task: "Execute Real AI Model Fine-Tuning",
                cost: "$8,000 (GPU time, data prep)",
                outcome: "Proprietary hypercore/cmmc-expert-v1 model"
            },
            {
                task: "Onboard First Law Firm Partner",
                cost: "$0 (operational)",
                outcome: "New sales channel and recurring revenue"
            }
        ]
    }
};

// AWS Migration Strategy (bootstrap budget)
const AWS_MIGRATION_PLAN = {
    phase1_minimal: {
        title: "Phase 1: Minimal Migration ($100-200/month)",
        services: [
            {
                service: "AWS Lambda",
                purpose: "Backend functions (replacement for Deno Deploy)",
                cost: "$5-20/month",
                migration_effort: "Low - direct port of existing functions"
            },
            {
                service: "Amazon RDS (PostgreSQL)",
                purpose: "Primary database (replacement for Base44 entities)",
                cost: "$25-50/month (t3.micro)",
                migration_effort: "Medium - data migration required"
            },
            {
                service: "S3 + CloudFront",
                purpose: "Static hosting and CDN",
                cost: "$5-15/month",
                migration_effort: "Low - static file hosting"
            },
            {
                service: "AWS SES",
                purpose: "Email service",
                cost: "$1-5/month",
                migration_effort: "Low - replace current email integration"
            }
        ],
        total_monthly: "$36-90/month",
        capabilities: "Full platform functionality with professional infrastructure"
    },
    phase2_growth: {
        title: "Phase 2: Growth Infrastructure ($300-500/month)", 
        services: [
            {
                service: "Amazon ECS/Fargate",
                purpose: "Containerized application hosting",
                cost: "$50-150/month",
                migration_effort: "Medium - containerization required"
            },
            {
                service: "Amazon SageMaker",
                purpose: "AI/ML model training and inference",
                cost: "$100-200/month",
                migration_effort: "High - custom AI pipeline development"
            },
            {
                service: "AWS API Gateway",
                purpose: "Professional API management",
                cost: "$10-30/month",
                migration_effort: "Low - API wrapper"
            },
            {
                service: "AWS KMS + Security Services",
                purpose: "Enterprise security and encryption",
                cost: "$50-100/month",
                migration_effort: "Medium - security implementation"
            }
        ],
        total_monthly: "$210-480/month",
        capabilities: "Enterprise-grade platform suitable for large partnerships"
    }
};

// What you need to secure partnerships
const PARTNERSHIP_REQUIREMENTS = {
    legal_partners: {
        minimum_requirements: [
            {
                requirement: "Professional Liability Insurance (E&O)",
                cost: "$1,500-3,000/year",
                purpose: "Coverage for AI-generated advice/analysis",
                critical: true
            },
            {
                requirement: "Cyber Liability Insurance",
                cost: "$800-1,500/year", 
                purpose: "Protection for data breaches and cyber incidents",
                critical: true
            },
            {
                requirement: "General Liability Insurance",
                cost: "$400-800/year",
                purpose: "Basic business protection",
                critical: false
            },
            {
                requirement: "Working AI Demonstration",
                cost: "$0 (already have)",
                purpose: "Proof of technical capability",
                critical: true
            },
            {
                requirement: "Professional Service Agreement Template",
                cost: "$500-1,000 (one-time legal review)",
                purpose: "Legal framework for value exchange",
                critical: true
            }
        ],
        total_cost: "$3,200-6,300 first year",
        value_proposition: "AI tools worth $50,000+ annually in exchange for legal services"
    },
    insurance_partners: {
        minimum_requirements: [
            {
                requirement: "Same insurance coverage as legal partners",
                cost: "$2,700-5,300/year",
                purpose: "Credibility and protection",
                critical: true
            },
            {
                requirement: "Working Risk Assessment Demo", 
                cost: "$500 (development completion)",
                purpose: "Demonstrate quantifiable value to insurance carriers",
                critical: true
            },
            {
                requirement: "Actuarial Data Sources",
                cost: "$200-500/month",
                purpose: "Real data for accurate risk calculations",
                critical: true
            },
            {
                requirement: "SOC2 Type II Compliance (eventually)",
                cost: "$15,000-25,000 (future requirement)",
                purpose: "Enterprise insurance partner requirements",
                critical: false
            }
        ],
        total_cost: "$3,700-6,800 first year",
        value_proposition: "Risk assessment AI that reduces claim rates by 15-25%"
    }
};

export default function CurrentStateAssessment() {
    const [activeTab, setActiveTab] = useState('current');

    // This function is currently unused by the component's rendering logic,
    // but is preserved as per the outline's instruction.
    const getStatusColor = (status) => {
        switch(status) {
            case 'fully_operational': return 'bg-green-100 text-green-800';
            case 'framework_ready': return 'bg-yellow-100 text-yellow-800';
            case 'basic_functional': return 'bg-blue-100 text-blue-800';
            case 'concept': return 'bg-gray-100 text-gray-800';
            default: return 'bg-gray-100 text-gray-800';
        }
    };

    return (
        <div className="min-h-screen bg-gray-50 p-6">
            <div className="max-w-7xl mx-auto">
                <motion.div
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="text-center mb-8"
                >
                    <h1 className="text-4xl font-bold text-gray-900 mb-3">
                        Current State Assessment - Sept 2025
                    </h1>
                    <p className="text-xl text-gray-600">
                        Honest evaluation of what's ready now vs. what's being built
                    </p>
                </motion.div>

                <Alert className="mb-8 bg-green-50 border-green-200">
                    <Rocket className="h-4 w-4 text-green-600" />
                    <AlertTitle className="text-green-800">Major Milestone Achieved! (Sept 2025)</AlertTitle>
                    <AlertDescription className="text-green-700">
                        <strong>HyperCore AI, LLC is officially formed, with EIN, SAM.gov registration, and business banking in place.</strong> The company has moved from a concept to an operational entity. The focus now shifts entirely to client acquisition and product delivery on AWS.
                    </AlertDescription>
                </Alert>

                <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
                    <TabsList className="grid w-full grid-cols-4">
                        <TabsTrigger value="current">What's Ready Now</TabsTrigger>
                        <TabsTrigger value="roadmap">Next Steps Roadmap</TabsTrigger>
                        <TabsTrigger value="aws">AWS Migration Plan</TabsTrigger>
                        <TabsTrigger value="partnerships">Partnership Requirements</TabsTrigger>
                    </TabsList>

                    <TabsContent value="current">
                        <div className="space-y-6">
                            <Card>
                                <CardHeader>
                                    <CardTitle className="flex items-center gap-2">
                                        <CheckCircle className="w-5 h-5 text-green-600" />
                                        Fully Operational (Ready for Demos TODAY)
                                    </CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <div className="grid gap-4">
                                        {CURRENT_DELIVERABLES.operational.map((item, index) => (
                                            <div key={index} className="border rounded-lg p-4 bg-green-50">
                                                <div className="flex justify-between items-start mb-2">
                                                    <h4 className="font-semibold text-green-900">{item.name}</h4>
                                                    <Badge className="bg-green-100 text-green-800">READY</Badge>
                                                </div>
                                                <p className="text-sm text-green-700 mb-2">{item.description}</p>
                                                <p className="text-xs text-green-600 font-medium">Partner Value: {item.partner_value}</p>
                                            </div>
                                        ))}
                                    </div>
                                </CardContent>
                            </Card>

                            <Card>
                                <CardHeader>
                                    <CardTitle className="flex items-center gap-2">
                                        <Clock className="w-5 h-5 text-yellow-600" />
                                        In Development (2-4 Weeks to Complete)
                                    </CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <div className="grid gap-4">
                                        {CURRENT_DELIVERABLES.in_development.map((item, index) => (
                                            <div key={index} className="border rounded-lg p-4 bg-yellow-50">
                                                <div className="flex justify-between items-start mb-2">
                                                    <h4 className="font-semibold text-yellow-900">{item.name}</h4>
                                                    <Badge className="bg-yellow-100 text-yellow-800">
                                                        {item.weeks_to_complete}W
                                                    </Badge>
                                                </div>
                                                <p className="text-sm text-yellow-700 mb-2">{item.description}</p>
                                                <p className="text-xs text-yellow-600 font-medium">Partner Value: {item.partner_value}</p>
                                            </div>
                                        ))}
                                    </div>
                                </CardContent>
                            </Card>

                            <Card>
                                <CardHeader>
                                    <CardTitle className="flex items-center gap-2">
                                        <Building className="w-5 h-5 text-gray-600" />
                                        Planned Initiatives (Longer Term)
                                    </CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <div className="grid gap-4">
                                        {CURRENT_DELIVERABLES.planned.map((item, index) => (
                                            <div key={index} className="border rounded-lg p-4 bg-gray-50">
                                                <div className="flex justify-between items-start mb-2">
                                                    <h4 className="font-semibold text-gray-900">{item.name}</h4>
                                                    <Badge className="bg-gray-100 text-gray-800">
                                                        {item.weeks_to_complete ? `${item.weeks_to_complete}W` : 'Concept'}
                                                    </Badge>
                                                </div>
                                                <p className="text-sm text-gray-700 mb-2">{item.description}</p>
                                                <p className="text-xs text-gray-600 font-medium">Partner Value: {item.partner_value}</p>
                                            </div>
                                        ))}
                                    </div>
                                </CardContent>
                            </Card>
                        </div>
                    </TabsContent>

                    <TabsContent value="roadmap">
                        <div className="space-y-6">
                            {Object.entries(POST_FORMATION_ROADMAP).map(([key, phase]) => (
                                <motion.div
                                    key={key}
                                    initial={{ opacity: 0, y: 20 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    transition={{ delay: Object.keys(POST_FORMATION_ROADMAP).indexOf(key) * 0.1 }}
                                >
                                    <Card>
                                        <CardHeader>
                                            <div className="flex justify-between items-center">
                                                <CardTitle>{phase.title}</CardTitle>
                                                <Badge className="bg-blue-100 text-blue-800">
                                                    Budget: {phase.budget}
                                                </Badge>
                                            </div>
                                        </CardHeader>
                                        <CardContent>
                                            <div className="space-y-3">
                                                {phase.actions.map((action, index) => (
                                                    <div key={index} className="flex justify-between items-center p-3 bg-gray-50 rounded">
                                                        <div className="flex-1">
                                                            <h4 className="font-medium">{action.task}</h4>
                                                            <p className="text-sm text-gray-600">{action.outcome}</p>
                                                        </div>
                                                        <div className="text-right">
                                                            <div className="font-semibold text-green-600">{action.cost}</div>
                                                        </div>
                                                    </div>
                                                ))}
                                            </div>
                                        </CardContent>
                                    </Card>
                                </motion.div>
                            ))}
                        </div>
                    </TabsContent>

                    <TabsContent value="aws">
                        <div className="space-y-6">
                            {Object.entries(AWS_MIGRATION_PLAN).map(([key, phase]) => (
                                <Card key={key}>
                                    <CardHeader>
                                        <div className="flex justify-between items-center">
                                            <CardTitle className="flex items-center gap-2">
                                                <Server className="w-5 h-5" />
                                                {phase.title}
                                            </CardTitle>
                                            <Badge className="bg-green-100 text-green-800">
                                                {phase.total_monthly}
                                            </Badge>
                                        </div>
                                        <CardDescription>{phase.capabilities}</CardDescription>
                                    </CardHeader>
                                    <CardContent>
                                        <div className="grid gap-3">
                                            {phase.services.map((service, index) => (
                                                <div key={index} className="border rounded p-3">
                                                    <div className="flex justify-between items-start mb-2">
                                                        <h4 className="font-semibold">{service.service}</h4>
                                                        <span className="text-sm font-medium text-green-600">
                                                            {service.cost}
                                                        </span>
                                                    </div>
                                                    <p className="text-sm text-gray-600 mb-1">{service.purpose}</p>
                                                    <p className="text-xs text-gray-500">Migration: {service.migration_effort}</p>
                                                </div>
                                            ))}
                                        </div>
                                    </CardContent>
                                </Card>
                            ))}
                        </div>
                    </TabsContent>

                    <TabsContent value="partnerships">
                        <div className="space-y-6">
                            {Object.entries(PARTNERSHIP_REQUIREMENTS).map(([key, partner]) => (
                                <Card key={key}>
                                    <CardHeader>
                                        <CardTitle className="flex items-center gap-2 capitalize">
                                            {key === 'legal_partners' ? <Scale className="w-5 h-5" /> : <Umbrella className="w-5 h-5" />}
                                            {key.replace('_', ' ')}
                                        </CardTitle>
                                        <CardDescription>
                                            <strong>Value Proposition:</strong> {partner.value_proposition}
                                        </CardDescription>
                                    </CardHeader>
                                    <CardContent>
                                        <div className="space-y-3">
                                            {partner.minimum_requirements.map((req, index) => (
                                                <div key={index} className={`p-3 rounded border ${req.critical ? 'bg-red-50 border-red-200' : 'bg-blue-50 border-blue-200'}`}>
                                                    <div className="flex justify-between items-start mb-2">
                                                        <h4 className="font-semibold flex items-center gap-2">
                                                            {req.critical && <AlertTriangle className="w-4 h-4 text-red-500" />}
                                                            {req.requirement}
                                                        </h4>
                                                        <Badge className={req.critical ? 'bg-red-100 text-red-800' : 'bg-blue-100 text-blue-800'}>
                                                            {req.cost}
                                                        </Badge>
                                                    </div>
                                                    <p className="text-sm text-gray-600">{req.purpose}</p>
                                                </div>
                                            ))}
                                        </div>
                                        <div className="mt-4 p-3 bg-green-50 border border-green-200 rounded">
                                            <div className="flex justify-between items-center">
                                                <span className="font-semibold text-green-800">Total First-Year Investment:</span>
                                                <span className="font-bold text-green-600">{partner.total_cost}</span>
                                            </div>
                                        </div>
                                    </CardContent>
                                </Card>
                            ))}
                        </div>
                    </TabsContent>
                </Tabs>

                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.5 }}
                    className="mt-12"
                >
                    <Card className="bg-gradient-to-r from-blue-50 to-green-50 border-blue-200">
                        <CardContent className="p-8 text-center">
                            <h3 className="text-2xl font-bold text-gray-900 mb-4">The Bottom Line</h3>
                            <div className="grid md:grid-cols-3 gap-6 text-left">
                                <div>
                                    <h4 className="font-semibold text-green-800 mb-2">✅ Ready Today</h4>
                                    <ul className="text-sm text-green-700 space-y-1">
                                        <li>Professional platform</li>
                                        <li>AI integration proven</li>
                                        <li>Security demonstration</li>
                                        <li>Partnership conversations</li>
                                    </ul>
                                </div>
                                <div>
                                    <h4 className="font-semibold text-yellow-800 mb-2">⏳ 2-4 Weeks</h4>
                                    <ul className="text-sm text-yellow-700 space-y-1">
                                        <li>Contract Intelligence MVP</li>
                                        <li>Insurance risk tools</li>
                                        <li>Partnership agreements</li>
                                        <li>First partner meetings</li>
                                    </ul>
                                </div>
                                <div>
                                    <h4 className="font-semibold text-blue-800 mb-2">💰 Investment Needed</h4>
                                    <ul className="text-sm text-blue-700 space-y-1">
                                        <li>$3,000-6,000 (insurance/legal)</li>
                                        <li>$200-500/month (AWS)</li>
                                        <li>$500-1,000 (development)</li>
                                        <li>ROI: $50K+ services/year</li>
                                    </ul>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </motion.div>
            </div>
        </div>
    );
}
