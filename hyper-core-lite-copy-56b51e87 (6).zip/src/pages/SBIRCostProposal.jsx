
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { DollarSign, Calculator, FileText, CheckCircle, AlertTriangle, Download } from 'lucide-react';
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";

const costProposal = {
    projectPeriod: "12 months",
    totalBudget: 275000,
    
    directLabor: {
        personnel: [
            {
                name: "Christine Boes, Principal Investigator/CEO",
                title: "AI Engineer & Founder",
                monthlyEffort: "100% (1.0 FTE)",
                annualSalary: 150000,
                projectMonths: 12,
                totalCost: 150000,
                justification: "As Principal Investigator and sole initial engineer, leading all technical development, AI model training, and regulatory compliance automation with unparalleled domain expertise."
            }
        ],
        subtotal: 150000
    },
    
    fringeBenefits: {
        rate: 0.25, // 25% of direct labor
        calculation: "25% of Direct Labor ($150,000)",
        total: 37500,
        justification: "Standard fringe benefits for the Principal Investigator, including health insurance, payroll taxes, and retirement contributions."
    },
    
    materialsSupplies: {
        items: [
            { item: "Cloud Computing Services (AWS GovCloud)", cost: 7200, justification: "12 months × $600/month for robust development, testing, and initial scaling of Lambda, DynamoDB, and S3 services." },
            { item: "AI API & Model Training Services", cost: 9600, justification: "12 months × $800/month for intensive LLM API usage, model fine-tuning, and vector database operations." },
            { item: "Development Tools & Software Licenses", cost: 1200, justification: "Essential development environment, security testing tools, and productivity software." }
        ],
        subtotal: 18000
    },

    travel: {
        items: [],
        subtotal: 0,
        justification: "Travel costs are eliminated due to the Principal Investigator's strategic proximity to Washington D.C. and key DoD sites, enabling cost-effective, local engagement."
    },
    
    otherDirectCosts: {
        items: [
            { item: "Technical Acceleration & Scaling Fund", cost: 34000, justification: "A flexible fund for on-demand, specialized expertise (e.g., short-term AWS security architecture review), intensive model training compute, or hosting open-source models to reduce long-term API costs. Adjusted to meet budget cap." },
            { item: "Professional Services (Legal/IP)", cost: 5000, justification: "Patent research and intellectual property protection for core AI algorithms." },
            { item: "Cybersecurity Compliance & Auditing", cost: 3000, justification: "Third-party security audit and compliance verification for government systems." },
            { item: "Technical Documentation & Reporting", cost: 2000, justification: "Professional technical writing for deliverable reports and user guides." }
        ],
        subtotal: 44000 // Corrected subtotal: 34000 + 5000 + 3000 + 2000
    }
};

// Calculate totals
const totalDirectCosts = costProposal.directLabor.subtotal + 
                        costProposal.fringeBenefits.total + 
                        costProposal.materialsSupplies.subtotal + 
                        costProposal.travel.subtotal + 
                        costProposal.otherDirectCosts.subtotal;

const indirectCosts = Math.floor(totalDirectCosts * 0.10); // 10% de minimis rate, rounded down
const totalProjectCost = totalDirectCosts + indirectCosts;
const remainingBudget = costProposal.totalBudget - totalProjectCost;

export default function SBIRCostProposal() {
    const [activeTab, setActiveTab] = useState("summary");

    return (
        <div className="space-y-6 p-4 md:p-6">
            <BreadcrumbNav currentPageName="SBIRCostProposal" />
            
            <div className="text-center">
                <h1 className="text-3xl font-bold text-gray-900">SBIR Phase I Cost Proposal (Revised & Optimized)</h1>
                <p className="text-lg text-gray-600 mt-2">
                    A lean, founder-led budget focused on technical acceleration and capital efficiency.
                </p>
            </div>

            <Alert className="bg-blue-50 border-blue-200">
                <Calculator className="h-4 w-4 text-blue-600" />
                <AlertTitle className="text-blue-800">Revised Total Phase I Budget: ${totalProjectCost.toLocaleString()}</AlertTitle>
                <AlertDescription className="text-blue-700">
                    This budget has been strategically realigned to eliminate unnecessary costs, reallocate funds to core technology, and establish a flexible scaling fund, while staying under the $275,000 cap.
                </AlertDescription>
            </Alert>

            <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
                <TabsList className="grid grid-cols-3 w-full">
                    <TabsTrigger value="summary">Budget Summary</TabsTrigger>
                    <TabsTrigger value="detailed">Detailed Breakdown</TabsTrigger>
                    <TabsTrigger value="justification">Cost Justification</TabsTrigger>
                </TabsList>

                <TabsContent value="summary">
                    <Card>
                        <CardHeader>
                            <CardTitle>Cost Summary</CardTitle>
                            <CardDescription>Overview of all budget categories reflecting the revised strategy.</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-4">
                                <div className="grid grid-cols-2 gap-4">
                                    <div className="space-y-3">
                                        <div className="flex justify-between items-center p-3 bg-gray-50 rounded">
                                            <span className="font-medium">Direct Labor</span>
                                            <span className="font-bold">${costProposal.directLabor.subtotal.toLocaleString()}</span>
                                        </div>
                                        <div className="flex justify-between items-center p-3 bg-gray-50 rounded">
                                            <span className="font-medium">Fringe Benefits (25%)</span>
                                            <span className="font-bold">${costProposal.fringeBenefits.total.toLocaleString()}</span>
                                        </div>
                                        <div className="flex justify-between items-center p-3 bg-gray-50 rounded">
                                            <span className="font-medium">Technology Infrastructure</span>
                                            <span className="font-bold">${costProposal.materialsSupplies.subtotal.toLocaleString()}</span>
                                        </div>
                                    </div>
                                    <div className="space-y-3">
                                        <div className="flex justify-between items-center p-3 bg-red-50 rounded">
                                            <span className="font-medium">Travel</span>
                                            <span className="font-bold text-red-600">$0 (Eliminated)</span>
                                        </div>
                                        <div className="flex justify-between items-center p-3 bg-gray-50 rounded">
                                            <span className="font-medium">Other Direct Costs (incl. Scaling Fund)</span>
                                            <span className="font-bold">${costProposal.otherDirectCosts.subtotal.toLocaleString()}</span>
                                        </div>
                                        <div className="flex justify-between items-center p-3 bg-blue-50 rounded border border-blue-200">
                                            <span className="font-medium">Indirect Costs (10%)</span>
                                            <span className="font-bold">${indirectCosts.toLocaleString()}</span>
                                        </div>
                                    </div>
                                </div>
                                <div className="border-t-2 border-gray-300 pt-4 space-y-2">
                                    <div className="flex justify-between items-center p-4 bg-green-50 rounded-lg border border-green-200">
                                        <span className="text-xl font-bold text-green-800">TOTAL PROJECT COST</span>
                                        <span className="text-2xl font-bold text-green-800">${totalProjectCost.toLocaleString()}</span>
                                    </div>
                                     <p className="text-xs text-gray-500 text-center">This leaves a ${remainingBudget.toLocaleString()} buffer within the $275,000 maximum, demonstrating fiscal prudence.</p>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="detailed">
                    <div className="space-y-6">
                        <Card>
                            <CardHeader>
                                <CardTitle>Direct Labor</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-4">
                                    {costProposal.directLabor.personnel.map((person, index) => (
                                        <div key={index} className="p-4 border rounded-lg">
                                            <div className="flex justify-between items-start mb-2">
                                                <div>
                                                    <h4 className="font-semibold">{person.name}</h4>
                                                    <p className="text-sm text-gray-600">{person.title}</p>
                                                </div>
                                                <Badge variant="secondary">${person.totalCost.toLocaleString()}</Badge>
                                            </div>
                                            <p className="text-xs text-gray-600 mt-2">{person.justification}</p>
                                        </div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>

                        <Card>
                            <CardHeader>
                                <CardTitle>Technology Infrastructure (Formerly Materials)</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-3">
                                    {costProposal.materialsSupplies.items.map((item, index) => (
                                        <div key={index} className="flex justify-between items-center p-3 bg-gray-50 rounded">
                                            <div>
                                                <span className="font-medium">{item.item}</span>
                                                <p className="text-xs text-gray-600">{item.justification}</p>
                                            </div>
                                            <span className="font-bold">${item.cost.toLocaleString()}</span>
                                        </div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>
                        
                        <Card>
                            <CardHeader>
                                <CardTitle>Other Direct Costs</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-3">
                                    {costProposal.otherDirectCosts.items.map((item, index) => (
                                        <div key={index} className="flex justify-between items-center p-3 bg-gray-50 rounded">
                                            <div>
                                                <span className="font-medium">{item.item}</span>
                                                <p className="text-xs text-gray-600">{item.justification}</p>
                                            </div>
                                            <span className="font-bold">${item.cost.toLocaleString()}</span>
                                        </div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>
                    </div>
                </TabsContent>

                <TabsContent value="justification">
                    <Card>
                        <CardHeader>
                            <CardTitle>Revised Budget Justification</CardTitle>
                            <CardDescription>Detailed rationale for the new founder-led cost structure.</CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-6">
                            <div>
                                <h4 className="font-semibold mb-2">Founder-Led Labor Strategy</h4>
                                <p className="text-sm text-gray-700 mb-2">
                                    The budget is now centered entirely on the Principal Investigator, reflecting a lean, founder-driven model. This eliminates initial hiring costs and directs capital towards technology and scaling resources.
                                </p>
                            </div>
                            <div>
                                <h4 className="font-semibold mb-2">Technical Acceleration & Scaling Fund ($34,000)</h4>
                                <p className="text-sm text-gray-700">
                                   Instead of hiring a general developer, this flexible fund is established for strategic, high-impact technical needs. It can be deployed for short-term contracts with world-class specialists (e.g., AWS security architects), intensive compute for model fine-tuning, or hosting powerful open-source models to reduce long-term API dependency and costs. This demonstrates superior financial agility, while ensuring the budget remains within the overall cap.
                                </p>
                            </div>
                            <div>
                                <h4 className="font-semibold mb-2">Travel Cost Elimination</h4>
                                <p className="text-sm text-gray-700">
                                    Leveraging the PI's strategic location one hour from the Pentagon and key DoD installations, the $4,000 travel budget has been eliminated. This capital is reallocated to the core technology budget, underscoring a commitment to capital efficiency and local engagement.
                                </p>
                            </div>
                             <div>
                                <h4 className="font-semibold mb-2">Increased Technology Infrastructure Budget</h4>
                                <p className="text-sm text-gray-700">
                                    The Materials budget has been re-labeled 'Technology Infrastructure' and increased to $18,000. This reflects a more realistic forecast for the robust AWS GovCloud services, intensive AI model training, and specialized database usage required to build a scalable, production-ready platform during Phase I.
                                </p>
                            </div>

                            <Alert>
                                <CheckCircle className="h-4 w-4" />
                                <AlertTitle>A More Credible, Defensible Budget</AlertTitle>
                                <AlertDescription>
                                    This revised budget is stronger because it's more realistic. It tells a compelling story of a knowledgeable founder who knows exactly where to allocate capital for maximum impact, avoiding waste and prioritizing scalable technology.
                                </AlertDescription>
                            </Alert>
                        </CardContent>
                    </Card>
                </TabsContent>
            </Tabs>

            <Card className="bg-green-50 border-green-200">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Download className="w-5 h-5 text-green-600" />
                        Ready for Submission
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <p className="text-green-700 mb-4">
                        This revised cost proposal is complete and ready. It accurately reflects your lean operational strategy and provides a powerful justification for every dollar requested.
                    </p>
                    <div className="flex gap-4">
                        <Button className="bg-green-600 hover:bg-green-700">
                            Export Cost Tables for Proposal
                        </Button>
                        <Button variant="outline">
                            Generate Budget Narrative
                        </Button>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}
