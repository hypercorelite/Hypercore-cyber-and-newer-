import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { TestTube, TrendingUp, Users, Target, AlertCircle } from 'lucide-react';
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert";

export default function ABTestingDashboard() {
    const [activeTests, setActiveTests] = useState([
        {
            id: 1,
            name: "Assessment Flow v2",
            description: "Testing streamlined 3-question vs 5-question assessment",
            status: "running",
            variants: [
                { name: "Control (5 questions)", traffic: 50, conversions: 12, visitors: 87 },
                { name: "Test (3 questions)", traffic: 50, conversions: 18, visitors: 93 }
            ],
            startDate: "2024-12-01",
            confidence: 89
        },
        {
            id: 2,
            name: "Gap Analysis Results Page",
            description: "Testing different CTA button text and placement",
            status: "draft",
            variants: [
                { name: "Control: 'Generate Reports'", traffic: 50, conversions: 0, visitors: 0 },
                { name: "Test: 'Get My Custom SSP'", traffic: 50, conversions: 0, visitors: 0 }
            ],
            startDate: null,
            confidence: 0
        }
    ]);

    const [newTest, setNewTest] = useState({
        name: '',
        description: '',
        testType: 'trial_flow',
        variants: [
            { name: 'Control', traffic: 50 },
            { name: 'Variant A', traffic: 50 }
        ]
    });

    const calculateConversionRate = (conversions, visitors) => {
        if (visitors === 0) return 0;
        return ((conversions / visitors) * 100).toFixed(1);
    };

    const getConfidenceColor = (confidence) => {
        if (confidence >= 95) return "text-green-600";
        if (confidence >= 80) return "text-yellow-600";
        return "text-red-600";
    };

    const createTest = () => {
        const test = {
            id: Date.now(),
            ...newTest,
            status: 'draft',
            startDate: null,
            confidence: 0,
            variants: newTest.variants.map(v => ({
                ...v,
                conversions: 0,
                visitors: 0
            }))
        };
        setActiveTests([...activeTests, test]);
        setNewTest({
            name: '',
            description: '',
            testType: 'trial_flow',
            variants: [
                { name: 'Control', traffic: 50 },
                { name: 'Variant A', traffic: 50 }
            ]
        });
    };

    const startTest = (testId) => {
        setActiveTests(tests => tests.map(test => 
            test.id === testId 
                ? { ...test, status: 'running', startDate: new Date().toISOString().split('T')[0] }
                : test
        ));
    };

    const stopTest = (testId) => {
        setActiveTests(tests => tests.map(test => 
            test.id === testId 
                ? { ...test, status: 'completed' }
                : test
        ));
    };

    return (
        <div className="space-y-6">
            <div>
                <h1 className="text-3xl font-bold">A/B Testing Dashboard</h1>
                <p className="text-gray-600">Test different trial flows to optimize conversions</p>
            </div>

            {/* Test Performance Overview */}
            <div className="grid md:grid-cols-3 gap-6">
                <Card>
                    <CardHeader className="pb-2">
                        <CardTitle className="text-sm flex items-center gap-2">
                            <TestTube className="w-4 h-4" />
                            Active Tests
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-3xl font-bold">{activeTests.filter(t => t.status === 'running').length}</p>
                        <p className="text-sm text-gray-600">Currently running</p>
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader className="pb-2">
                        <CardTitle className="text-sm flex items-center gap-2">
                            <TrendingUp className="w-4 h-4" />
                            Avg. Conversion Lift
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-3xl font-bold text-green-600">+23%</p>
                        <p className="text-sm text-gray-600">From successful tests</p>
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader className="pb-2">
                        <CardTitle className="text-sm flex items-center gap-2">
                            <Target className="w-4 h-4" />
                            Statistical Confidence
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-3xl font-bold">89%</p>
                        <p className="text-sm text-gray-600">Best performing test</p>
                    </CardContent>
                </Card>
            </div>

            {/* Active Tests */}
            <Card>
                <CardHeader>
                    <CardTitle>Running & Planned Tests</CardTitle>
                    <CardDescription>Monitor your conversion optimization experiments</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="space-y-6">
                        {activeTests.map(test => (
                            <div key={test.id} className="border rounded-lg p-4">
                                <div className="flex justify-between items-start mb-4">
                                    <div>
                                        <h3 className="text-lg font-semibold">{test.name}</h3>
                                        <p className="text-gray-600">{test.description}</p>
                                        {test.startDate && (
                                            <p className="text-sm text-gray-500">Started: {test.startDate}</p>
                                        )}
                                    </div>
                                    <div className="flex items-center gap-2">
                                        <Badge variant={
                                            test.status === 'running' ? 'default' :
                                            test.status === 'completed' ? 'secondary' : 'outline'
                                        }>
                                            {test.status}
                                        </Badge>
                                        {test.status === 'running' && (
                                            <span className={`text-sm font-semibold ${getConfidenceColor(test.confidence)}`}>
                                                {test.confidence}% confidence
                                            </span>
                                        )}
                                    </div>
                                </div>

                                <div className="grid md:grid-cols-2 gap-4 mb-4">
                                    {test.variants.map((variant, index) => (
                                        <div key={index} className="bg-gray-50 p-3 rounded">
                                            <div className="flex justify-between items-center mb-2">
                                                <h4 className="font-medium">{variant.name}</h4>
                                                <span className="text-sm text-gray-600">{variant.traffic}% traffic</span>
                                            </div>
                                            <div className="flex justify-between text-sm">
                                                <span>Visitors: {variant.visitors}</span>
                                                <span>Conversions: {variant.conversions}</span>
                                                <span className="font-semibold">
                                                    {calculateConversionRate(variant.conversions, variant.visitors)}%
                                                </span>
                                            </div>
                                        </div>
                                    ))}
                                </div>

                                <div className="flex gap-2">
                                    {test.status === 'draft' && (
                                        <Button size="sm" onClick={() => startTest(test.id)}>
                                            Start Test
                                        </Button>
                                    )}
                                    {test.status === 'running' && (
                                        <Button size="sm" variant="outline" onClick={() => stopTest(test.id)}>
                                            Stop Test
                                        </Button>
                                    )}
                                    {test.confidence >= 95 && test.status === 'running' && (
                                        <Alert className="mt-2 bg-green-50 border-green-200">
                                            <AlertCircle className="h-4 w-4 text-green-600" />
                                            <AlertDescription className="text-green-700">
                                                Test reached statistical significance! Consider implementing the winning variant.
                                            </AlertDescription>
                                        </Alert>
                                    )}
                                </div>
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>

            {/* Create New Test */}
            <Card>
                <CardHeader>
                    <CardTitle>Create New A/B Test</CardTitle>
                    <CardDescription>Set up a new conversion optimization experiment</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div>
                        <Label htmlFor="testName">Test Name</Label>
                        <Input
                            id="testName"
                            value={newTest.name}
                            onChange={(e) => setNewTest({...newTest, name: e.target.value})}
                            placeholder="e.g., Assessment Form Optimization"
                        />
                    </div>

                    <div>
                        <Label htmlFor="testDesc">Description</Label>
                        <Input
                            id="testDesc"
                            value={newTest.description}
                            onChange={(e) => setNewTest({...newTest, description: e.target.value})}
                            placeholder="What are you testing and why?"
                        />
                    </div>

                    <div>
                        <Label>Test Type</Label>
                        <Select value={newTest.testType} onValueChange={(value) => setNewTest({...newTest, testType: value})}>
                            <SelectTrigger>
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="trial_flow">Trial Flow Changes</SelectItem>
                                <SelectItem value="cta_button">CTA Button Text/Design</SelectItem>
                                <SelectItem value="results_page">Gap Analysis Results Page</SelectItem>
                                <SelectItem value="pricing_display">Pricing Presentation</SelectItem>
                                <SelectItem value="form_length">Assessment Form Length</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>

                    <div className="space-y-2">
                        <Label>Test Variants</Label>
                        {newTest.variants.map((variant, index) => (
                            <div key={index} className="flex gap-2 items-center">
                                <Input
                                    value={variant.name}
                                    onChange={(e) => {
                                        const updated = [...newTest.variants];
                                        updated[index].name = e.target.value;
                                        setNewTest({...newTest, variants: updated});
                                    }}
                                    placeholder={`Variant ${index + 1} name`}
                                />
                                <Input
                                    type="number"
                                    value={variant.traffic}
                                    onChange={(e) => {
                                        const updated = [...newTest.variants];
                                        updated[index].traffic = parseInt(e.target.value);
                                        setNewTest({...newTest, variants: updated});
                                    }}
                                    className="w-20"
                                    min="0"
                                    max="100"
                                />
                                <span className="text-sm text-gray-600">%</span>
                            </div>
                        ))}
                    </div>

                    <Button onClick={createTest} className="w-full">
                        Create A/B Test
                    </Button>
                </CardContent>
            </Card>

            {/* Test Ideas & Recommendations */}
            <Card>
                <CardHeader>
                    <CardTitle>Test Ideas & Recommendations</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="grid md:grid-cols-2 gap-4">
                        <div className="p-4 border rounded-lg">
                            <h4 className="font-semibold mb-2">High-Impact Tests to Try</h4>
                            <ul className="text-sm space-y-1">
                                <li>• Reduce assessment from 5 to 3 questions</li>
                                <li>• Test "Generate My SSP" vs "Download Reports"</li>
                                <li>• A/B test pricing presentation timing</li>
                                <li>• Test different trial completion rewards</li>
                                <li>• Optimize gap analysis results layout</li>
                            </ul>
                        </div>
                        <div className="p-4 border rounded-lg">
                            <h4 className="font-semibold mb-2">Best Practices</h4>
                            <ul className="text-sm space-y-1">
                                <li>• Run tests for at least 2 weeks</li>
                                <li>• Wait for 95% statistical confidence</li>
                                <li>• Test one element at a time</li>
                                <li>• Focus on high-traffic conversion points</li>
                                <li>• Document learnings for future tests</li>
                            </ul>
                        </div>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}