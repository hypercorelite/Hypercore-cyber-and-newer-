import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Check, X, Rocket, Crosshair, Bot, Users, TrendingUp, Clock, AlertTriangle, Server, ShieldCheck, CheckCircle } from 'lucide-react';
import { motion } from "framer-motion";

const ecosystemAnalysis = [
    {
        category: "Certified Solution Providers",
        examples: "Corporate Information Technologies, PreVeil, Abacode/Red River",
        approach: "Sell managed services or secure platforms",
        pricing: "$50K-200K+ annually for managed infrastructure",
        clientEffort: "Low ongoing effort, but expensive and limited flexibility",
        ourAdvantage: "We deliver the outcome at 1/5th the cost without locking you into specific vendors"
    },
    {
        category: "Registered Provider Organizations (RPOs)",
        examples: "Alluvionic, TealTech, BDO Digital, CohnReznick",
        approach: "Traditional consulting with hourly billing",
        pricing: "$300-500/hour for 200-500 hours ($60K-250K)",
        clientEffort: "High - you manage the consultants and coordinate deliverables",
        ourAdvantage: "Fixed-price outcome with expert guidance, not hourly consulting"
    },
    {
        category: "C3PAO Assessment Organizations",
        examples: "Legato Security, Cybersec Investments",
        approach: "Official assessments only (conflict of interest prevents preparation services)",
        pricing: "$30K-80K for the assessment, but they can't help you prepare",
        clientEffort: "You arrive ready or fail the assessment",
        ourAdvantage: "We prepare you for success before you engage the C3PAO"
    },
    {
        category: "AI-Powered Compliance Platforms",
        examples: "Secureframe, Conductor AI, SecureBERT tools",
        approach: "Self-service platforms with AI assistance",
        pricing: "$2K-10K/month subscription + setup costs",
        clientEffort: "High - you operate the platform and are responsible for complex legacy & IAM integration",
        ourAdvantage: "We deliver a finished result, handling the complex integrations that platforms leave up to you"
    }
];

const smbChallenges = [
    {
        challenge: "AWS CMMC Architecture Complexity",
        description: "Navigating AWS Config Rules, Security Hub integration, GovCloud requirements, and custom rules for legacy systems requires deep expertise.",
        impact: "Most SMBs hire expensive cloud architects or make costly configuration mistakes.",
        ourSolution: "We provide the specific AWS security architecture guidance so your team can implement it correctly the first time."
    },
    {
        challenge: "Limited Budgets",
        impact: "Can't afford the typical $80K-$150K+ total cost for CMMC readiness.",
        hyperCoreResponse: "Fixed $25K price for complete readiness - predictable and accessible"
    },
    {
        challenge: "Expertise Gap",
        impact: "Lack internal cybersecurity teams to manage complex platforms",
        hyperCoreResponse: "Expert team does the work FOR you - no internal expertise required"
    },
    {
        challenge: "Compliance Timelines",
        impact: "Need results fast as CMMC rollout accelerates",
        hyperCoreResponse: "90-day sprint model designed for rapid, guaranteed progress"
    },
    {
        challenge: "Supply Chain Pressure",
        impact: "Primes demanding CMMC readiness even before formal mandate",
        hyperCoreResponse: "Complete evidence package proves readiness to prime contractors immediately"
    }
];

export default function CompetitiveAdvantage() {
    return (
        <div className="space-y-8">
            <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center"
            >
                <Badge className="mb-4 bg-green-100 text-green-800">MARKET ANALYSIS: SMB Defense Contractor Ecosystem</Badge>
                <h1 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-3">
                    Where HyperCore Fits in the CMMC Market
                </h1>
                <p className="text-lg lg:text-xl text-gray-600">
                    A comprehensive ecosystem exists to serve defense subcontractors. Here's why our approach wins.
                </p>
            </motion.div>

            <Alert className="bg-blue-50 border-blue-200">
                <TrendingUp className="h-4 w-4 text-blue-600" />
                <AlertTitle className="text-blue-800">The Market Reality</AlertTitle>
                <AlertDescription className="text-blue-700">
                    The CMMC phased rollout officially begins November 10, 2025. Dozens of CMMC providers serve the SMB market, but they fall into four distinct categories. Each has significant limitations for small defense contractors with limited budgets and internal expertise.
                </AlertDescription>
            </Alert>

            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-3"><Users className="w-6 h-6 text-gray-700" /> SMB CMMC Provider Ecosystem Analysis</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="overflow-x-auto">
                        <table className="w-full text-sm text-left">
                            <thead className="bg-gray-50">
                                <tr>
                                    <th className="p-4 font-semibold">Provider Type</th>
                                    <th className="p-4 font-semibold">Examples</th>
                                    <th className="p-4 font-semibold">Typical Pricing</th>
                                    <th className="p-4 font-semibold">Client Effort Required</th>
                                    <th className="p-4 font-semibold text-green-600">HyperCore Advantage</th>
                                </tr>
                            </thead>
                            <tbody>
                                {ecosystemAnalysis.map((item, index) => (
                                    <tr key={index} className="border-b">
                                        <td className="p-4 font-medium">{item.category}</td>
                                        <td className="p-4 text-gray-600 text-xs">{item.examples}</td>
                                        <td className="p-4 text-red-600 font-medium text-xs">{item.pricing}</td>
                                        <td className="p-4 text-gray-600 text-xs">{item.clientEffort}</td>
                                        <td className="p-4 font-semibold text-green-700 text-xs">{item.ourAdvantage}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-3"><AlertTriangle className="w-6 h-6 text-red-600" /> SMB Contractor Challenges & Our Response</CardTitle>
                    <CardDescription>The four critical challenges facing small defense contractors and how we solve each one.</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="space-y-4">
                        {smbChallenges.map((item, index) => (
                            <div key={index} className="border-l-4 border-l-blue-500 pl-4">
                                <h4 className="font-semibold text-red-700">Challenge: {item.challenge}</h4>
                                {item.description && <p className="text-sm text-gray-600 mb-2">{item.description}</p>}
                                <p className="text-sm text-gray-600 mb-2">{item.impact}</p>
                                <p className="text-sm font-medium text-green-700">✓ Our Response: {item.hyperCoreResponse || item.ourSolution}</p>
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>

            <Alert className="bg-green-50 border-green-200">
                <CheckCircle className="h-4 w-4 text-green-600" />
                <AlertTitle className="text-green-800">Why We Win: The Perfect Market Position</AlertTitle>
                <AlertDescription className="text-green-700">
                    <div className="mt-2 space-y-2">
                        <p><strong>Expert-Driven:</strong> Unlike platforms, you get actual cybersecurity experts doing the work.</p>
                        <p><strong>Fixed-Price:</strong> Unlike consulting, you know exactly what you'll pay upfront.</p>
                        <p><strong>Fast Results:</strong> Unlike managed services, you get complete deliverables in 90 days.</p>
                        <p><strong>No Conflict:</strong> Unlike C3PAOs, we can actually help you prepare for success.</p>
                    </div>
                </AlertDescription>
            </Alert>

            <Card>
                 <CardHeader>
                    <CardTitle className="flex items-center gap-3"><Bot className="w-6 h-6 text-gray-700" /> Market Positioning Matrix</CardTitle>
                    <CardDescription>How we fit into the competitive landscape.</CardDescription>
                </CardHeader>
                <CardContent className="p-6">
                    <div className="relative">
                        {/* Y-Axis */}
                        <div className="absolute -left-16 top-0 bottom-0 flex flex-col justify-between text-xs font-medium text-gray-500">
                            <span>High</span>
                            <span>Low</span>
                        </div>
                        <div className="absolute -left-24 top-1/2 -translate-y-1/2 -rotate-90 font-semibold text-gray-600">Client Effort</div>

                        {/* X-Axis */}
                         <div className="absolute -bottom-10 left-0 right-0 flex justify-between text-xs font-medium text-gray-500">
                            <span>Tool</span>
                            <span>Finished Result</span>
                        </div>
                        <div className="absolute -bottom-16 left-1/2 -translate-x-1/2 font-semibold text-gray-600">Core Deliverable</div>

                        {/* Grid */}
                        <div className="grid grid-cols-2 grid-rows-2 h-80 border-2 border-dashed">
                           <div className="border-r border-b border-dashed p-4 flex items-center justify-center text-center">
                                <Card className="p-3 shadow-md bg-red-50 text-red-700 w-full">
                                    <CardTitle className="text-sm">GRC Platforms</CardTitle>
                                    <CardDescription className="text-xs">High client effort for a complex tool.</CardDescription>
                                </Card>
                           </div>
                           <div className="border-b border-dashed p-4"></div>
                           <div className="border-r border-dashed p-4"></div>
                           <div className="p-4 flex items-center justify-center text-center">
                               <motion.div
                                    initial={{ scale: 0, opacity: 0 }}
                                    animate={{ scale: 1, opacity: 1 }}
                                    transition={{ delay: 0.5, type: 'spring' }}
                                    className="w-full"
                                >
                                    <Card className="p-3 shadow-lg bg-green-100 text-green-800 border-2 border-green-400">
                                        <CardTitle className="text-sm flex items-center gap-1">
                                            <Rocket className="w-4 h-4"/> HyperCore AI
                                        </CardTitle>
                                        <CardDescription className="text-xs">Low client effort for a finished result.</CardDescription>
                                    </Card>
                                </motion.div>
                           </div>
                        </div>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}