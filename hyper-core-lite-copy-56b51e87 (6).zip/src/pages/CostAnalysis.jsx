
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { ClientOnboarding } from "@/api/entities";
import { ClientEngagement } from "@/api/entities";
import { ClientFeedback } from "@/api/entities";
import { Loader2, Users, FileText, Star, BarChart2 } from 'lucide-react';
import { LoadingSpinner } from '../components/ui/LoadingSpinner';

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8'];

export default function CostAnalysis() {
    const [data, setData] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const [onboarding, engagement, feedback] = await Promise.all([
                    ClientOnboarding.list(),
                    ClientEngagement.list(),
                    ClientFeedback.list()
                ]);

                // Process data for charts
                const industryData = onboarding.reduce((acc, client) => {
                    const industry = client.industry_sector || 'other';
                    acc[industry] = (acc[industry] || 0) + 1;
                    return acc;
                }, {});
                const industryChartData = Object.keys(industryData).map(key => ({ name: key, clients: industryData[key] }));

                const engagementData = engagement.reduce((acc, event) => {
                    const type = event.engagement_type;
                    acc[type] = (acc[type] || 0) + 1;
                    return acc;
                }, {});
                const engagementChartData = Object.keys(engagementData).map(key => ({ name: type, count: engagementData[type] }));

                const ratingsData = feedback.reduce((acc, item) => {
                    acc[item.rating] = (acc[item.rating] || 0) + 1;
                    return acc;
                }, { '1': 0, '2': 0, '3': 0, '4': 0, '5': 0 });
                const ratingsChartData = Object.keys(ratingsData).map(key => ({ name: `${key} Star`, count: ratingsData[key] }));

                setData({
                    totalClients: onboarding.length,
                    totalEngagements: engagement.length,
                    totalFeedbacks: feedback.length,
                    industryChartData,
                    engagementChartData,
                    ratingsChartData,
                    latestFeedback: feedback.slice(-5).reverse()
                });
            } catch (error) {
                console.error("Failed to fetch analytics data", error);
            } finally {
                setLoading(false);
            }
        };

        fetchData();
    }, []);

    if (loading) {
        return <LoadingSpinner text="Analyzing Beta Program Data..." />;
    }

    if (!data) {
        return <div className="text-center p-8">Could not load data.</div>;
    }

    return (
        <div className="space-y-8 p-6">
            <CardHeader className="px-0">
                <CardTitle className="text-3xl font-bold flex items-center gap-3">
                    <BarChart2 className="w-8 h-8 text-blue-600" />
                    Beta Program Data & Pricing Analysis
                </CardTitle>
                <CardDescription>
                    Use this data from the free beta to inform your SBIR grant proposal and commercial pricing strategy.
                </CardDescription>
            </CardHeader>
            
            {/* KPI Cards */}
            <div className="grid md:grid-cols-3 gap-6">
                <Card>
                    <CardHeader><CardTitle className="flex items-center gap-2 text-sm"><Users /> Total Clients</CardTitle></CardHeader>
                    <CardContent><p className="text-3xl font-bold">{data.totalClients}</p></CardContent>
                </Card>
                <Card>
                    <CardHeader><CardTitle className="flex items-center gap-2 text-sm"><FileText /> Total Engagements</CardTitle></CardHeader>
                    <CardContent><p className="text-3xl font-bold">{data.totalEngagements}</p></CardContent>
                </Card>
                <Card>
                    <CardHeader><CardTitle className="flex items-center gap-2 text-sm"><Star /> Total Feedbacks</CardTitle></CardHeader>
                    <CardContent><p className="text-3xl font-bold">{data.totalFeedbacks}</p></CardContent>
                </Card>
            </div>

            {/* Charts */}
            <div className="grid lg:grid-cols-2 gap-6">
                <Card>
                    <CardHeader><CardTitle>Clients by Industry</CardTitle></CardHeader>
                    <CardContent>
                        <ResponsiveContainer width="100%" height={300}>
                            <BarChart data={data.industryChartData}>
                                <CartesianGrid strokeDasharray="3 3" />
                                <XAxis dataKey="name" />
                                <YAxis />
                                <Tooltip />
                                <Legend />
                                <Bar dataKey="clients" fill="#8884d8" />
                            </BarChart>
                        </ResponsiveContainer>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader><CardTitle>Engagement by Type</CardTitle></CardHeader>
                    <CardContent>
                        <ResponsiveContainer width="100%" height={300}>
                            <BarChart data={data.engagementChartData} layout="vertical">
                                <CartesianGrid strokeDasharray="3 3" />
                                <XAxis type="number" />
                                <YAxis type="category" dataKey="name" width={150} />
                                <Tooltip />
                                <Bar dataKey="count" fill="#82ca9d" />
                            </BarChart>
                        </ResponsiveContainer>
                    </CardContent>
                </Card>
            </div>
            
            <div className="grid lg:grid-cols-2 gap-6">
                 <Card>
                    <CardHeader><CardTitle>Feedback Ratings</CardTitle></CardHeader>
                    <CardContent>
                        <ResponsiveContainer width="100%" height={300}>
                            <PieChart>
                                <Pie data={data.ratingsChartData} dataKey="count" nameKey="name" cx="50%" cy="50%" outerRadius={100} label>
                                    {data.ratingsChartData.map((entry, index) => (
                                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                    ))}
                                </Pie>
                                <Tooltip />
                                <Legend />
                            </PieChart>
                        </ResponsiveContainer>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader><CardTitle>Recent Feedback</CardTitle></CardHeader>
                    <CardContent className="space-y-3">
                        {data.latestFeedback.map(fb => (
                            <div key={fb.id} className="p-3 bg-gray-50 rounded-md text-sm">
                                <div className="flex justify-between items-center mb-1">
                                    <span className="font-semibold">{fb.client_email}</span>
                                    <span className="flex items-center">{fb.rating} <Star className="w-4 h-4 text-yellow-400 fill-current ml-1"/></span>
                                </div>
                                <p className="text-gray-600 truncate">{fb.feedback_text || "No comment."}</p>
                            </div>
                        ))}
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}
