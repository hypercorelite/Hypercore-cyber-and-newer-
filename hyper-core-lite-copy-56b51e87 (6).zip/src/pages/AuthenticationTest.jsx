import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { User } from '@/api/entities';
import BreadcrumbNav from '../components/navigation/BreadcrumbNav';
import { Shield, CheckCircle, AlertTriangle, Key, Users, Lock } from 'lucide-react';

export default function AuthenticationTest() {
    const [authStatus, setAuthStatus] = useState({
        isAuthenticated: false,
        user: null,
        adminAccess: false,
        error: null,
        loading: true
    });

    const checkAuthentication = async () => {
        setAuthStatus(prev => ({ ...prev, loading: true }));
        
        try {
            // Check if user is authenticated
            const user = await User.me();
            
            // Check admin access
            const urlParams = new URLSearchParams(window.location.search);
            const adminKey = urlParams.get('admin');
            const storedAdminAccess = localStorage.getItem('hypercore_admin_access');
            const ADMIN_KEY = 'hypercore2025admin';
            const adminAccess = adminKey === ADMIN_KEY || storedAdminAccess === 'true';

            setAuthStatus({
                isAuthenticated: true,
                user: user,
                adminAccess: adminAccess,
                error: null,
                loading: false
            });
            
        } catch (error) {
            setAuthStatus({
                isAuthenticated: false,
                user: null,
                adminAccess: false,
                error: error.message,
                loading: false
            });
        }
    };

    useEffect(() => {
        checkAuthentication();
    }, []);

    const triggerLogin = async () => {
        try {
            await User.login();
        } catch (error) {
            setAuthStatus(prev => ({ ...prev, error: error.message }));
        }
    };

    const triggerLogout = async () => {
        try {
            await User.logout();
            localStorage.removeItem('hypercore_admin_access');
            setAuthStatus({
                isAuthenticated: false,
                user: null,
                adminAccess: false,
                error: null,
                loading: false
            });
        } catch (error) {
            setAuthStatus(prev => ({ ...prev, error: error.message }));
        }
    };

    const enableAdminMode = () => {
        localStorage.setItem('hypercore_admin_access', 'true');
        setAuthStatus(prev => ({ ...prev, adminAccess: true }));
    };

    const disableAdminMode = () => {
        localStorage.removeItem('hypercore_admin_access');
        setAuthStatus(prev => ({ ...prev, adminAccess: false }));
    };

    if (authStatus.loading) {
        return (
            <div className="space-y-6">
                <BreadcrumbNav currentPageName="AuthenticationTest" />
                <Card>
                    <CardContent className="p-6">
                        <div className="text-center">Loading authentication status...</div>
                    </CardContent>
                </Card>
            </div>
        );
    }

    return (
        <div className="space-y-6">
            <BreadcrumbNav currentPageName="AuthenticationTest" />
            
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                        <Shield className="w-6 h-6 text-blue-600" />
                        Authentication Status Check
                    </CardTitle>
                    <CardDescription>
                        Test authentication system functionality with Google sign-in disabled
                    </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    {/* Authentication Status */}
                    <div className="grid md:grid-cols-2 gap-4">
                        <Card className={authStatus.isAuthenticated ? 'border-green-200 bg-green-50' : 'border-red-200 bg-red-50'}>
                            <CardContent className="p-4">
                                <div className="flex items-center gap-3">
                                    {authStatus.isAuthenticated ? 
                                        <CheckCircle className="w-5 h-5 text-green-600" /> : 
                                        <AlertTriangle className="w-5 h-5 text-red-600" />
                                    }
                                    <div>
                                        <div className="font-semibold">
                                            {authStatus.isAuthenticated ? 'Authenticated' : 'Not Authenticated'}
                                        </div>
                                        <div className="text-sm text-gray-600">
                                            {authStatus.isAuthenticated ? 'User is logged in' : 'No active session'}
                                        </div>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>

                        <Card className={authStatus.adminAccess ? 'border-purple-200 bg-purple-50' : 'border-gray-200 bg-gray-50'}>
                            <CardContent className="p-4">
                                <div className="flex items-center gap-3">
                                    {authStatus.adminAccess ? 
                                        <Key className="w-5 h-5 text-purple-600" /> : 
                                        <Lock className="w-5 h-5 text-gray-600" />
                                    }
                                    <div>
                                        <div className="font-semibold">
                                            {authStatus.adminAccess ? 'Admin Access' : 'No Admin Access'}
                                        </div>
                                        <div className="text-sm text-gray-600">
                                            {authStatus.adminAccess ? 'Full admin privileges' : 'Public access only'}
                                        </div>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    </div>

                    {/* User Details */}
                    {authStatus.user && (
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2">
                                    <Users className="w-5 h-5" />
                                    User Details
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="grid md:grid-cols-2 gap-4">
                                    <div>
                                        <label className="text-sm font-medium text-gray-500">Email</label>
                                        <p className="text-sm">{authStatus.user.email}</p>
                                    </div>
                                    <div>
                                        <label className="text-sm font-medium text-gray-500">Full Name</label>
                                        <p className="text-sm">{authStatus.user.full_name || 'Not provided'}</p>
                                    </div>
                                    <div>
                                        <label className="text-sm font-medium text-gray-500">Role</label>
                                        <p className="text-sm">{authStatus.user.role || 'user'}</p>
                                    </div>
                                    <div>
                                        <label className="text-sm font-medium text-gray-500">Organization</label>
                                        <p className="text-sm">{authStatus.user.organization_name || 'Not specified'}</p>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    )}

                    {/* Error Display */}
                    {authStatus.error && (
                        <Alert className="border-red-200 bg-red-50">
                            <AlertTriangle className="h-4 w-4 text-red-600" />
                            <AlertDescription className="text-red-800">
                                <strong>Error:</strong> {authStatus.error}
                            </AlertDescription>
                        </Alert>
                    )}

                    {/* Control Buttons */}
                    <div className="flex gap-4 flex-wrap">
                        <Button onClick={checkAuthentication} variant="outline">
                            Refresh Status
                        </Button>
                        
                        {!authStatus.isAuthenticated && (
                            <Button onClick={triggerLogin} className="bg-blue-600 hover:bg-blue-700">
                                Test Login
                            </Button>
                        )}
                        
                        {authStatus.isAuthenticated && (
                            <Button onClick={triggerLogout} variant="destructive">
                                Logout
                            </Button>
                        )}
                        
                        {!authStatus.adminAccess && (
                            <Button onClick={enableAdminMode} className="bg-purple-600 hover:bg-purple-700">
                                Enable Admin Mode
                            </Button>
                        )}
                        
                        {authStatus.adminAccess && (
                            <Button onClick={disableAdminMode} variant="outline">
                                Disable Admin Mode
                            </Button>
                        )}
                    </div>

                    {/* Instructions */}
                    <Alert>
                        <Shield className="h-4 w-4" />
                        <AlertDescription>
                            <strong>Admin Access Note:</strong> Since Google sign-in is disabled, you can enable admin mode manually using the button above or by adding <code>?admin=hypercore2025admin</code> to the URL.
                        </AlertDescription>
                    </Alert>
                </CardContent>
            </Card>
        </div>
    );
}