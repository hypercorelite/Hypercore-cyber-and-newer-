import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { FileText, Download, Zap, Shield, Share2, Cloud, Cpu, Scaling, Bot, ChevronsRight } from 'lucide-react';

export default function SBIRTechnicalAppendix() {
    const exportToPDF = () => {
        window.print();
    };

    return (
        <div className="max-w-5xl mx-auto p-8 bg-white">
            <div className="flex justify-between items-center mb-8 no-print">
                <div>
                    <Badge className="mb-4 bg-blue-100 text-blue-800">SBIR PROPOSAL APPENDIX</Badge>
                    <h1 className="text-3xl font-bold text-gray-900">Technical Architecture & Scalability Plan</h1>
                </div>
                <Button onClick={exportToPDF} className="flex items-center gap-2">
                    <Download className="w-4 h-4" />
                    Export PDF
                </Button>
            </div>

            <div className="space-y-8 text-sm leading-relaxed">
                {/* Appendix Header */}
                <div className="text-center border-b-2 pb-6">
                    <h1 className="text-2xl font-bold mb-2">APPENDIX B</h1>
                    <h2 className="text-xl font-semibold mb-2">Technical Architecture, Security, and Scalability</h2>
                    <p className="text-lg">HyperCore Cyber CMMC AI Compliance Platform</p>
                    <p className="text-base text-gray-600 mt-2">SBIR Phase I Proposal - Technical Feasibility</p>
                    <p className="text-sm text-gray-500">Prepared: {new Date().toLocaleDateString()}</p>
                </div>

                {/* Executive Summary */}
                <section>
                    <h2 className="text-lg font-bold mb-4 border-b pb-2">1. EXECUTIVE SUMMARY</h2>
                    <p className="mb-4">
                        HyperCore Cyber’s technical architecture is engineered for massive scalability, high performance, and minimal operational cost, directly enabling its disruptive, low-touch business model. By leveraging a **serverless-first, GPU-less AI strategy**, the platform is designed to serve the entire 31,500 SMB Defense Industrial Base (DIB) market without the capital expenditure typically associated with AI-powered solutions. This architecture ensures high-speed performance (e.g., 320ms API response times), robust security, and a scalable, AI-driven support system that replaces high-cost, high-touch consulting models.
                    </p>
                </section>

                {/* Core Architectural Principles */}
                <section>
                    <h2 className="text-lg font-bold mb-4 border-b pb-2">2. CORE ARCHITECTURAL PRINCIPLES</h2>
                    <div className="grid md:grid-cols-2 gap-4">
                        <div className="bg-gray-50 p-4 rounded-lg">
                            <h4 className="font-semibold flex items-center gap-2"><Cloud className="w-4 h-4 text-blue-600"/> Serverless-First</h4>
                            <p>Eliminates server management, reduces costs to near-zero for low usage, and scales automatically to meet demand from thousands of concurrent users.</p>
                        </div>
                        <div className="bg-gray-50 p-4 rounded-lg">
                            <h4 className="font-semibold flex items-center gap-2"><Cpu className="w-4 h-4 text-green-600"/> GPU-less AI Strategy</h4>
                            <p>Utilizes highly efficient, CPU-optimized LLMs and vector databases for inference tasks, avoiding expensive GPU infrastructure and enabling a freemium pricing model.</p>
                        </div>
                        <div className="bg-gray-50 p-4 rounded-lg">
                            <h4 className="font-semibold flex items-center gap-2"><Scaling className="w-4 h-4 text-purple-600"/> Stateless & Scalable</h4>
                            <p>Backend functions are stateless, allowing for horizontal scaling to handle unpredictable workloads, critical for serving a diverse SMB market.</p>
                        </div>
                        <div className="bg-gray-50 p-4 rounded-lg">
                            <h4 className="font-semibold flex items-center gap-2"><Shield className="w-4 h-4 text-red-600"/> Security by Design</h4>
                            <p>Integrates security at every layer, from JWT-secured APIs to IAM roles and data encryption, ensuring the platform meets the same CMMC standards it helps clients achieve.</p>
                        </div>
                    </div>
                </section>
                
                {/* System Architecture */}
                <section>
                    <h2 className="text-lg font-bold mb-4 border-b pb-2">3. SYSTEM ARCHITECTURE OVERVIEW</h2>
                    <p className="mb-4">
                        The architecture is a modern, decoupled system designed for performance, security, and scalability.
                    </p>
                    <div className="border p-4 rounded-lg space-y-4">
                        <div className="flex items-center gap-3">
                            <div className="font-bold w-40 text-right">Frontend</div>
                            <div className="flex-1 p-2 bg-blue-50 rounded">React/JS application served from a global CDN (e.g., AWS S3/CloudFront) for low-latency access.</div>
                        </div>
                        <div className="flex items-center gap-3">
                            <div className="font-bold w-40 text-right">API Router</div>
                            <div className="flex-1 p-2 bg-purple-50 rounded">Managed API Gateway (e.g., AWS API Gateway) handles request routing, authentication (JWT), rate limiting, and logging. Ensures <strong>320ms average response time</strong>.</div>
                        </div>
                        <div className="flex items-center gap-3">
                            <div className="font-bold w-40 text-right">Backend</div>
                            <div className="flex-1 p-2 bg-indigo-50 rounded">Stateless, serverless functions (e.g., AWS Lambda, Deno Deploy) execute business logic, such as SSP generation (jsPDF) and secure data encoding (Base64).</div>
                        </div>
                        <div className="flex items-center gap-3">
                            <div className="font-bold w-40 text-right">AI & Data Layer</div>
                            <div className="flex-1 p-2 bg-green-50 rounded">Utilizes Hugging Face Inference APIs and Pinecone (Vector DB) for CPU-based AI tasks. Achieves <strong>90% AI accuracy</strong> on control mapping without dedicated GPUs.</div>
                        </div>
                        <div className="flex items-center gap-3">
                            <div className="font-bold w-40 text-right">Database</div>
                            <div className="flex-1 p-2 bg-yellow-50 rounded">Starts with a simple, file-based DB (SQLite) for the MVP, with a clear path to a scalable, managed NoSQL database (e.g., DynamoDB) for Phase II.</div>
                        </div>
                    </div>
                </section>

                {/* Scalability Plan */}
                <section>
                    <h2 className="text-lg font-bold mb-4 border-b pb-2">4. SCALABILITY PLAN FOR 31,500 SMBs</h2>
                    <p className="mb-3">The serverless architecture is inherently designed to scale from one to thousands of users with no manual intervention. The plan is phased to align with market adoption.</p>
                     <table className="w-full border-collapse border border-gray-300 mb-6">
                        <thead className="bg-gray-100">
                            <tr>
                                <th className="border border-gray-300 p-2 text-left">Phase</th>
                                <th className="border border-gray-300 p-2">Users</th>
                                <th className="border border-gray-300 p-2">Architecture Focus</th>
                                <th className="border border-gray-300 p-2">Key Technologies</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td className="border border-gray-300 p-2 font-semibold">Phase I (Pilot)</td>
                                <td className="border border-gray-300 p-2">1 - 1,000</td>
                                <td className="border border-gray-300 p-2">Validate MVP performance, gather metrics.</td>
                                <td className="border border-gray-300 p-2">AWS Lambda, API Gateway, S3, SQLite, Hugging Face API</td>
                            </tr>
                            <tr>
                                <td className="border border-gray-300 p-2 font-semibold">Phase II (Growth)</td>
                                <td className="border border-gray-300 p-2">1,000 - 10,000</td>
                                <td className="border border-gray-300 p-2">Optimize database performance and add caching.</td>
                                <td className="border border-gray-300 p-2">Migrate to DynamoDB, implement Redis caching.</td>
                            </tr>
                            <tr className="bg-green-50">
                                <td className="border border-gray-300 p-2 font-semibold">Commercial</td>
                                <td className="border border-gray-300 p-2">10,000 - 100,000+</td>
                                <td className="border border-gray-300 p-2">Global distribution and advanced analytics.</td>
                                <td className="border border-gray-300 p-2">Multi-region deployment, data warehousing with Redshift.</td>
                            </tr>
                        </tbody>
                    </table>
                </section>
                
                {/* AI-Powered Low-Touch Support Model */}
                <section>
                    <h2 className="text-lg font-bold mb-4 border-b pb-2">5. SCALABLE LOW-TOUCH SUPPORT ARCHITECTURE</h2>
                    <p className="mb-4">
                        To replace high-touch consulting, HyperCore implements a tiered, AI-driven support model that scales efficiently and improves over time. This is the technical foundation for providing "expertise as a module."
                    </p>
                    <div className="space-y-2">
                         <div className="flex items-start gap-3">
                            <Badge className="w-28 text-center justify-center mt-1">Tier 0</Badge>
                            <div className="flex-1"><strong>AI Self-Service:</strong> In-platform knowledge base, interactive tutorials, and AI-powered help search provide instant answers to common questions.</div>
                        </div>
                        <div className="flex items-start gap-3">
                            <Badge variant="secondary" className="w-28 text-center justify-center mt-1">Tier 1</Badge>
                            <div className="flex-1"><strong>AI Support Agent:</strong> An integrated chatbot (powered by the same CMMC LLM) handles 80-90% of user queries, providing contextual guidance on compliance tasks.</div>
                        </div>
                        <div className="flex items-start gap-3">
                            <Badge variant="outline" className="w-28 text-center justify-center mt-1">Tier 2</Badge>
                             <div className="flex-1"><strong>AI Escalation Agent & CRM:</strong> If the AI agent cannot resolve an issue, it automatically creates a ticket in an AI-powered CRM. This agent analyzes the ticket, categorizes it, and routes it to the correct human expert, minimizing triage time.</div>
                        </div>
                         <div className="flex items-start gap-3">
                            <Badge variant="destructive" className="w-28 text-center justify-center mt-1">Tier 3</Badge>
                            <div className="flex-1"><strong>Human Expert Module:</strong> A small team of human experts handles only the most complex, escalated tickets (the top 1-5%). Their resolutions are fed back into the AI model and knowledge base, creating a continuous improvement loop.</div>
                        </div>
                    </div>
                     <div className="bg-blue-50 p-4 rounded-lg mt-6">
                        <p className="font-semibold text-blue-800 mb-2 flex items-center gap-2"><Zap className="w-4 h-4"/>Continuous Improvement Loop</p>
                        <p className="text-blue-700">
                           User Interactions <ChevronsRight className="inline w-4 h-4"/> AI CRM logs data <ChevronsRight className="inline w-4 h-4"/> Data used to fine-tune AI Agent & update Knowledge Base <ChevronsRight className="inline w-4 h-4"/> Improved Tier 0/1 Support. This virtuous cycle reduces human support load over time, even as the user base grows.
                        </p>
                    </div>
                </section>
                
                {/* Footer */}
                <div className="text-center text-xs text-gray-500 border-t pt-4 mt-8">
                    <p>This appendix details the technical architecture supporting the HyperCore Cyber SBIR proposal, demonstrating feasibility, scalability, and innovation.</p>
                    <p className="mt-2">Document prepared: {new Date().toLocaleDateString()} | Classification: Unclassified</p>
                </div>
            </div>

            <style jsx>{`
                @media print {
                    .no-print { display: none; }
                    body { font-size: 11px; }
                    h1 { font-size: 16px; }
                    h2 { font-size: 14px; }
                    h3 { font-size: 12px; }
                    .page-break { page-break-after: always; }
                }
            `}</style>
        </div>
    );
}