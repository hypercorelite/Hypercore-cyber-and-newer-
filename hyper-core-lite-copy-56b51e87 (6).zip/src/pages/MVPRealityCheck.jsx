
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CheckCircle, AlertTriangle, Cloud, Database, Shield, Target, ArrowRight, X, Zap } from 'lucide-react';
import { motion } from "framer-motion";
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

const mvpScope = {
    phase1_base44: [
        { feature: "Core AI Gap Analysis Engine", status: "✅ COMPLETE", why: "Working on Base44 platform" },
        { feature: "Basic Policy Generation", status: "✅ COMPLETE", why: "AI-powered document generation functional" },
        { feature: "User Authentication & Management", status: "✅ COMPLETE", why: "Base44 handles this natively" },
        { feature: "Support Ticket System", status: "✅ COMPLETE", why: "Integrated email workflow built" },
        { feature: "PDF Report Generation", status: "✅ COMPLETE", why: "Professional reports working" }
    ],
    phase2_aws_migration: [
        { feature: "Export Base44 Frontend & Data", status: "🔄 REQUIRED", timeline: "Week 3", why: "Provides the React/Vite codebase as a starting point for AWS deployment." },
        { feature: "AWS GovCloud Infrastructure Setup (CDK)", status: "🔄 REQUIRED", timeline: "Week 3-4", why: "MANDATORY for SBIR credibility and federal contracts. Use IaC for reliability." },
        { feature: "Refactor Backend to Lambda/API Gateway", status: "🔄 REQUIRED", timeline: "Week 4-6", why: "Replace proprietary Base44 SDK calls with AWS-native serverless functions." },
        { feature: "Migrate Data to AWS RDS/DynamoDB", status: "🔄 REQUIRED", timeline: "Week 5", why: "Move data from Base44 to a scalable, secure AWS database." },
        { feature: "Implement User Auth with AWS Cognito", status: "🔄 REQUIRED", timeline: "Week 6", why: "Replace Base44 authentication with a robust, scalable AWS identity service." },
        { feature: "Deploy & Test on AWS", status: "🔄 REQUIRED", timeline: "Week 7-8", why: "Go live on production AWS infrastructure to validate the migration." }
    ],
    deferred_post_sbir: [
        "Advanced AI Training Pipeline",
        "Real-time Compliance Monitoring",
        "Multi-tenant Architecture",
        "Advanced Analytics Dashboard",
        "Third-party Security Tool Integrations"
    ]
};

const migrationChallenges = {
    technical: [
        { challenge: "Base44 Backend SDK Lock-in", impact: "HIGH", solution: "Export frontend code. Use Amazon Q to accelerate refactoring of proprietary SDK calls into AWS Lambda functions." },
        { challenge: "Partial Export on Free Tier", impact: "LOW", solution: "Temporarily upgrade to a paid plan (~$29) to enable full frontend code export to GitHub/ZIP." },
        { challenge: "Database Schema Translation", impact: "MEDIUM", solution: "Export Base44 entities to JSON/CSV, then import into a newly designed AWS RDS or DynamoDB schema." },
        { challenge: "Authentication System Migration", impact: "MEDIUM", solution: "Migrate user data to AWS Cognito; Base44's built-in user management is not exportable." }
    ],
    timeline: [
        { risk: "8-Week Timeline Too Aggressive", probability: "HIGH", mitigation: "Focus on MVP feature set, defer advanced features to post-SBIR" },
        { risk: "AWS Learning Curve", probability: "MEDIUM", mitigation: "Use AWS templates and focus on basic services initially" },
        { risk: "Data Migration Complexity", probability: "MEDIUM", mitigation: "Start with simple data export/import, optimize later" }
    ]
};

const sbirAlignment = {
    strengths: [
        { point: "Working MVP Demonstrates Technical Feasibility", impact: "Your Base44 prototype proves the concept works" },
        { point: "AI-First Architecture Shows Innovation", impact: "Cutting-edge approach to compliance automation" },
        { point: "AWS GovCloud Migration Shows Federal Readiness", impact: "Critical for DoD and federal agency deployments" },
        { point: "Clear Market Need with DFARS Timing", impact: "31,500 SMBs need compliance by November 10, 2025" }
    ],
    weaknesses: [
        { point: "No Production AWS Deployment Yet", impact: "SBIR reviewers expect cloud-native federal architecture" },
        { point: "Limited Scale Testing", impact: "Need to show system can handle multiple clients simultaneously" },
        { point: "No Federal Compliance Certifications", impact: "FedRAMP or similar certifications strengthen credibility" }
    ]
};

export default function MVPRealityCheck() {
    return (
        <div className="space-y-8">
            <BreadcrumbNav currentPageName="MVPRealityCheck" />

            <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="text-center">
                <Badge className="mb-4 bg-yellow-100 text-yellow-800">UPDATED ASSESSMENT</Badge>
                <h1 className="text-4xl font-bold text-gray-900 mb-4">MVP Readiness: Base44 → AWS Migration Required</h1>
                <p className="text-xl text-blue-700 font-bold max-w-4xl mx-auto">
                    Current Status: Strong foundation built on Base44. AWS migration is now CRITICAL for SBIR credibility and federal readiness.
                </p>
            </motion.div>

            <Alert className="bg-gradient-to-r from-orange-500 to-red-600 text-white border-0 shadow-lg">
                <Cloud className="h-5 w-5 text-white" />
                <AlertTitle className="text-2xl font-bold">CRITICAL UPDATE: AWS Migration is Mandatory for SBIR Success</AlertTitle>
                <AlertDescription className="text-lg mt-2">
                    Your Base44 prototype proves the concept, but SBIR reviewers expect AWS GovCloud deployments. This isn't optional—it's table stakes. The new plan is to **export the frontend, then rebuild the backend on AWS** using AI-assist tools.
                    <div className="mt-3 p-3 bg-white/20 rounded-lg">
                        <strong>The Reality:</strong> Base44 is for prototyping. An AWS-native architecture is for winning federal contracts.
                    </div>
                </AlertDescription>
            </Alert>
            
            <div className="grid md:grid-cols-2 gap-8">
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2"><CheckCircle className="text-green-600"/>Phase 1: Base44 Foundation (COMPLETE)</CardTitle>
                        <CardDescription>What you've built that proves the concept works</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-3">
                            {mvpScope.phase1_base44.map((item, index) => (
                                 <div key={index} className="p-3 bg-green-50 rounded-lg border-l-4 border-green-400">
                                     <div className="flex items-center justify-between">
                                         <h4 className="font-semibold text-green-800">{item.feature}</h4>
                                         <Badge className="bg-green-100 text-green-800 text-xs">{item.status}</Badge>
                                     </div>
                                     <p className="text-sm text-green-700 mt-1">{item.why}</p>
                                 </div>
                            ))}
                        </div>
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2"><Cloud className="text-blue-600"/>Phase 2: AWS Migration (REQUIRED)</CardTitle>
                        <CardDescription>Critical infrastructure migration for SBIR readiness</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-3">
                            {mvpScope.phase2_aws_migration.map((item, index) => (
                                 <div key={index} className="p-3 bg-blue-50 rounded-lg border-l-4 border-blue-400">
                                     <div className="flex items-center justify-between">
                                         <h4 className="font-semibold text-blue-800">{item.feature}</h4>
                                         <Badge className="bg-blue-100 text-blue-800 text-xs">{item.timeline}</Badge>
                                     </div>
                                     <p className="text-sm text-blue-700 mt-1">{item.why}</p>
                                 </div>
                            ))}
                        </div>
                    </CardContent>
                </Card>
            </div>

            <Card>
                <CardHeader>
                    <CardTitle>Migration Challenges & Solutions</CardTitle>
                    <CardDescription>Honest assessment of what needs to be solved</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="grid md:grid-cols-2 gap-6">
                        <div>
                            <h4 className="font-semibold mb-3 text-red-700">Technical Challenges</h4>
                            {migrationChallenges.technical.map((challenge, index) => (
                                <div key={index} className="mb-3 p-2 bg-red-50 rounded-md">
                                    <div className="flex justify-between items-start">
                                        <h5 className="font-medium text-sm">{challenge.challenge}</h5>
                                        <Badge className={challenge.impact === 'HIGH' ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800'}>
                                            {challenge.impact}
                                        </Badge>
                                    </div>
                                    <p className="text-xs text-gray-600 mt-1"><strong>Solution:</strong> {challenge.solution}</p>
                                </div>
                            ))}
                        </div>
                        <div>
                            <h4 className="font-semibold mb-3 text-yellow-700">Timeline Risks</h4>
                            {migrationChallenges.timeline.map((risk, index) => (
                                <div key={index} className="mb-3 p-2 bg-yellow-50 rounded-md">
                                    <div className="flex justify-between items-start">
                                        <h5 className="font-medium text-sm">{risk.risk}</h5>
                                        <Badge className="bg-yellow-100 text-yellow-800">{risk.probability}</Badge>
                                    </div>
                                    <p className="text-xs text-gray-600 mt-1"><strong>Mitigation:</strong> {risk.mitigation}</p>
                                </div>
                            ))}
                        </div>
                    </div>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>SBIR Readiness Analysis</CardTitle>
                    <CardDescription>How the AWS migration affects your grant competitiveness</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="grid md:grid-cols-2 gap-6">
                        <div>
                            <h4 className="font-semibold mb-3 text-green-700 flex items-center gap-2">
                                <CheckCircle className="w-4 h-4" />
                                Current Strengths
                            </h4>
                            {sbirAlignment.strengths.map((strength, index) => (
                                <div key={index} className="mb-3 p-3 bg-green-50 rounded-md border-l-2 border-green-400">
                                    <h5 className="font-medium text-sm text-green-800">{strength.point}</h5>
                                    <p className="text-xs text-green-600 mt-1">{strength.impact}</p>
                                </div>
                            ))}
                        </div>
                        <div>
                            <h4 className="font-semibold mb-3 text-red-700 flex items-center gap-2">
                                <AlertTriangle className="w-4 h-4" />
                                Areas to Address
                            </h4>
                            {sbirAlignment.weaknesses.map((weakness, index) => (
                                <div key={index} className="mb-3 p-3 bg-red-50 rounded-md border-l-2 border-red-400">
                                    <h5 className="font-medium text-sm text-red-800">{weakness.point}</h5>
                                    <p className="text-xs text-red-600 mt-1">{weakness.impact}</p>
                                </div>
                            ))}
                        </div>
                    </div>
                </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-gray-900 to-blue-900 text-white">
                <CardHeader>
                    <CardTitle className="text-2xl">Updated Verdict: AWS Migration is Non-Negotiable</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <p className="text-lg"><strong>Base44 Achievement:</strong> You've proven the AI-first CMMC concept works. This is valuable validation.</p>
                    <p className="text-lg"><strong>Next Critical Step:</strong> AWS migration is mandatory for SBIR credibility and federal client readiness.</p>
                    <p><strong>Timeline Reality Check:</strong> The 8-week timeline is aggressive but achievable if you focus on core AWS services and leverage your existing business logic.</p>
                    <p><strong>SBIR Impact:</strong> An AWS-deployed MVP with GovCloud architecture significantly strengthens your Phase I proposal.</p>
                    <div className="grid md:grid-cols-2 gap-4 mt-6">
                        <Button asChild size="lg" className="bg-blue-600 hover:bg-blue-700">
                            <Link to={createPageUrl('HybridSprintPlan')}>
                                View Updated 8-Week Sprint Plan <ArrowRight className="w-5 h-5 ml-2" />
                            </Link>
                        </Button>
                        <Button asChild size="lg" variant="secondary">
                            <Link to={createPageUrl('AWSMigrationStrategy')}>
                                AWS Migration Strategy <Cloud className="w-5 h-5 ml-2" />
                            </Link>
                        </Button>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}
