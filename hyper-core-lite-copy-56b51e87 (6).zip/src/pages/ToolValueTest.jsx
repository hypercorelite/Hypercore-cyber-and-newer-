import React from 'react';
import BreadcrumbNav from '../components/navigation/BreadcrumbNav';
import ToolValueTest from '../components/testing/ToolValueTest';

export default function ToolValueTestPage() {
    return (
        <div className="space-y-6">
            <BreadcrumbNav currentPageName="ToolValueTest" />
            <ToolValueTest />
        </div>
    );
}