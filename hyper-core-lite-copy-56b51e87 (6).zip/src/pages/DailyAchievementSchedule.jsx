import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ArrowLeft, ArrowRight, Code, Terminal, FileText, ClipboardCheck, Lightbulb, Copy, Zap } from 'lucide-react';
import { motion, AnimatePresence } from "framer-motion";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { toast } from "sonner";
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";

const TaskTypeIcon = ({ type }) => {
    switch (type) {
        case 'CODE': return <Code className="w-5 h-5 text-blue-500" />;
        case 'SETUP': return <Terminal className="w-5 h-5 text-gray-500" />;
        case 'REVIEW': return <ClipboardCheck className="w-5 h-5 text-purple-500" />;
        case 'WORKFLOW': return <FileText className="w-5 h-5 text-green-500" />;
        default: return <Lightbulb className="w-5 h-5 text-yellow-500" />;
    }
};

const TaskItem = ({ task }) => {
    const handleCopy = (text) => {
        navigator.clipboard.writeText(text);
        toast.success("Prompt copied to clipboard!");
    };

    return (
        <div className="p-3 bg-white rounded-lg border hover:shadow-sm transition-shadow">
            <Collapsible>
                <CollapsibleTrigger className="w-full text-left">
                    <div className="flex items-center gap-3">
                        <TaskTypeIcon type={task.type} />
                        <div className="flex-grow">
                            <h4 className="font-semibold text-gray-800">{task.title}</h4>
                            {task.details && <p className="text-xs text-gray-500">{task.details}</p>}
                        </div>
                    </div>
                </CollapsibleTrigger>
                <CollapsibleContent>
                    <div className="mt-3 pt-3 border-t border-gray-200">
                        {task.prompt && (
                            <div className="bg-gray-900 text-white p-3 rounded-md font-mono text-xs relative">
                                <Button
                                    size="icon"
                                    variant="ghost"
                                    className="absolute top-2 right-2 h-6 w-6 text-gray-400 hover:bg-gray-700 hover:text-white"
                                    onClick={() => handleCopy(task.prompt)}
                                >
                                    <Copy className="h-3 w-3" />
                                </Button>
                                <pre className="whitespace-pre-wrap"><code>{task.prompt}</code></pre>
                            </div>
                        )}
                        {task.expected_output && (
                            <div className="mt-2 text-xs text-gray-600 bg-green-50 p-2 rounded-md">
                                <strong>Expected Output:</strong> {task.expected_output}
                            </div>
                        )}
                    </div>
                </CollapsibleContent>
            </Collapsible>
        </div>
    );
};

const schedule = [
    // --- 8-WEEK SPRINT CONSOLIDATED ---
    {
        week: "🎯 THE AI-FIRST SPRINT",
        dates: "Sep 15 - Nov 10 (8 weeks)",
        phase: "MVP Launch Ready",
        burnRate: "$175 total spend",
        goals: ["MVP Launch Nov 10", "SBIR Draft Concurrent", "First Client Ready"],
        urgency: "FINAL TIMELINE", 
        motivator: "Marketing is LIVE on hypercorecyber.com. Research is COMPLETE. Time to build the AI-first MVP that scales.",
        daily: [
            { 
                date: "Week 1 • Setup & Foundation", 
                dailyCost: "$50",
                tasks: [
                    { 
                        type: 'SETUP', 
                        title: "AI Development Environment", 
                        details: "GitHub Copilot Pro, Cursor IDE, Claude API setup",
                        prompt: "Set up the ultimate AI-assisted development environment. Configure GitHub Copilot Pro, Cursor IDE with AI features, and Claude API. Focus on tools that write code, not just assist.",
                        expected_output: "Fully configured AI development stack ready for sprint"
                    },
                    { 
                        type: 'CODE', 
                        title: "Core MVP Database Schema", 
                        details: "User, ComplianceFramework, ComplianceTask entities",
                        prompt: "Generate a comprehensive database schema for CMMC compliance tracking. Include User management, ComplianceFramework (HIPAA, FERPA, CMMC, etc.), ComplianceTask with AI workflow states, and audit logging. Use JSON schema format for Base44 platform.",
                        expected_output: "Complete entity definitions for Base44 platform"
                    },
                    { 
                        type: 'CODE', 
                        title: "AI Gap Analysis Core Engine", 
                        details: "Document upload → AI analysis → gap report pipeline",
                        prompt: "Create a backend function that accepts document uploads, sends them to Claude/GPT for CMMC gap analysis, and returns structured compliance gap data. Include NIST 800-171 control mapping.",
                        expected_output: "Working AI analysis pipeline with test cases"
                    }
                ]
            },
            { 
                date: "Week 2 • Core MVP Features", 
                dailyCost: "$25",
                tasks: [
                    { 
                        type: 'CODE', 
                        title: "Basic Frontend Dashboard", 
                        details: "Client upload interface + results display",
                        prompt: "Generate a React dashboard for CMMC clients. Include file upload component, progress tracking, and results display. Use shadcn/ui components. Focus on professional appearance over complex features.",
                        expected_output: "Functional client interface for MVP"
                    },
                    { 
                        type: 'CODE', 
                        title: "AI Policy Generator", 
                        details: "Generate 3-5 core policy templates based on client data",
                        prompt: "Create an AI-powered policy document generator. Input: client business details. Output: customized policy documents for Access Control, Incident Response, and System Security. Use professional business language.",
                        expected_output: "Working policy generation system"
                    },
                    { 
                        type: 'CODE', 
                        title: "PDF Report Export", 
                        details: "Professional compliance reports for C3PAO/primes",
                        prompt: "Build a PDF generation function that creates professional CMMC compliance reports. Include gap analysis results, recommendations, and implementation timeline. Make it look enterprise-grade.",
                        expected_output: "PDF report generation capability"
                    }
                ]
            },
            { 
                date: "Week 3-4 • MVP Polish & Testing", 
                dailyCost: "$25",
                tasks: [
                    { 
                        type: 'WORKFLOW', 
                        title: "Client Onboarding Flow", 
                        details: "Simple signup → assessment → results workflow",
                        prompt: "Design a streamlined client onboarding workflow. Signup → upload documents → AI analysis → results + next steps. Keep it simple and professional. Include email automation for status updates.",
                        expected_output: "Complete onboarding user experience"
                    },
                    { 
                        type: 'CODE', 
                        title: "Expert Escalation System", 
                        details: "Email-based support ticket system for complex questions",
                        prompt: "Create a simple support ticket system. When clients have complex questions, they can submit tickets that go to admin email. Include basic categorization and priority levels.",
                        expected_output: "Functional expert escalation system"
                    },
                    { 
                        type: 'REVIEW', 
                        title: "MVP User Testing", 
                        details: "Test with 2-3 pilot defense contractors",
                        prompt: "Conduct user testing with actual defense contractors. Focus on: Does the gap analysis provide value? Are the generated policies useful? What's missing for C3PAO readiness?",
                        expected_output: "User feedback and improvement priorities"
                    }
                ]
            },
            { 
                date: "Week 5-6 • Concurrent SBIR Writing", 
                dailyCost: "$25",
                tasks: [
                    { 
                        type: 'WORKFLOW', 
                        title: "SBIR Phase I Technical Abstract", 
                        details: "Leverage MVP as proof of concept for SBIR proposal",
                        prompt: "Write a compelling SBIR Phase I technical abstract. Highlight the working MVP as proof of technical feasibility. Focus on the AI innovation, market need (DFARS mandate), and commercialization potential.",
                        expected_output: "Complete SBIR Phase I draft abstract"
                    },
                    { 
                        type: 'CODE', 
                        title: "MVP Performance Optimization", 
                        details: "Ensure platform handles initial client load",
                        prompt: "Optimize the MVP for production use. Focus on API response times, error handling, and basic scalability. Test with concurrent users and document performance metrics for SBIR.",
                        expected_output: "Production-ready MVP with performance data"
                    },
                    { 
                        type: 'WORKFLOW', 
                        title: "Commercial Strategy Documentation", 
                        details: "Document client acquisition strategy for SBIR commercialization plan",
                        prompt: "Document your go-to-market strategy for the SBIR commercialization plan. Include pricing model ($2,500 MVP, $12,500 full), target market size, and partnership strategy.",
                        expected_output: "Complete commercialization plan for SBIR"
                    }
                ]
            },
            { 
                date: "Week 7-8 • Launch Preparation", 
                dailyCost: "$50",
                tasks: [
                    { 
                        type: 'SETUP', 
                        title: "Production Deployment", 
                        details: "Deploy MVP to production, configure monitoring",
                        prompt: "Deploy the MVP to production infrastructure. Set up monitoring, backup systems, and security configurations. Ensure it can handle the November 10 launch traffic.",
                        expected_output: "Live, monitored production system"
                    },
                    { 
                        type: 'WORKFLOW', 
                        title: "Client Communication Templates", 
                        details: "Email templates for client onboarding and support",
                        prompt: "Create professional email templates for client communication. Include welcome emails, assessment complete notifications, and support response templates. Maintain professional tone throughout.",
                        expected_output: "Complete email communication system"
                    },
                    { 
                        type: 'REVIEW', 
                        title: "Final SBIR Submission", 
                        details: "Submit SBIR Phase I proposal with MVP as proof of concept",
                        prompt: "Complete final review of SBIR Phase I proposal. Ensure the MVP demo is included as technical proof. Submit before November 10 to maximize chances.",
                        expected_output: "SBIR Phase I proposal submitted"
                    },
                    { 
                        type: 'WORKFLOW', 
                        title: "November 10 Launch", 
                        details: "Announce MVP availability, begin client acquisition",
                        prompt: "Execute the November 10 launch plan. Update hypercorecyber.com with MVP availability. Begin converting leads from marketing campaigns into paying clients.",
                        expected_output: "Live MVP with first paying clients"
                    }
                ]
            }
        ]
    }
];

export default function DailyAchievementSchedule() {
    const [selectedWeek, setSelectedWeek] = useState(0);

    return (
        <div className="space-y-6">
            <BreadcrumbNav currentPageName="DailyAchievementSchedule" />
            
            <div className="text-center">
                <Badge className="mb-4 bg-green-100 text-green-800">AI-FIRST EXECUTION PLAN</Badge>
                <h1 className="text-4xl font-bold text-gray-900 mb-4">
                    The Ultimate 8-Week Sprint to Nov 10
                </h1>
                <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                    Your granular, day-by-day execution guide for the AI-first MVP launch. Every task, every prompt, every expected outcome.
                </p>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
                <div className="flex items-center gap-3 mb-2">
                    <Zap className="w-5 h-5 text-blue-600" />
                    <h3 className="font-bold text-blue-800">Strategic Context</h3>
                </div>
                <div className="text-sm text-blue-700 space-y-1">
                    <p>✅ <strong>Marketing:</strong> hypercorecyber.com is live and generating leads</p>
                    <p>✅ <strong>Research:</strong> Competitive analysis complete, market validated</p>
                    <p>🎯 <strong>Goal:</strong> Nov 10 MVP launch concurrent with SBIR Phase I submission</p>
                    <p>💰 <strong>Budget:</strong> $175 total cash, maximum AI leverage for scaling</p>
                </div>
            </div>

            <AnimatePresence mode="wait">
                {schedule.map((week, index) => (
                    <motion.div
                        key={index}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -20 }}
                    >
                        <Card className="border-2 border-green-500">
                            <CardHeader className="bg-green-50">
                                <CardTitle className="text-green-800">{week.week}</CardTitle>
                                <CardDescription>
                                    {week.dates} • {week.burnRate} • {week.phase}
                                </CardDescription>
                                <p className="text-sm text-green-700 font-medium">{week.motivator}</p>
                            </CardHeader>
                            <CardContent className="pt-6">
                                <div className="space-y-4">
                                    {week.daily.map((day, dayIndex) => (
                                        <div key={dayIndex} className="border-l-4 border-gray-300 pl-4">
                                            <h4 className="font-semibold text-gray-800 mb-2">{day.date} • {day.dailyCost}</h4>
                                            <div className="space-y-2">
                                                {day.tasks.map((task, taskIndex) => (
                                                    <TaskItem key={taskIndex} task={task} />
                                                ))}
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>
                    </motion.div>
                ))}
            </AnimatePresence>
        </div>
    );
}