import React from 'react';
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { motion } from "framer-motion";
import { CheckCircle, ArrowRight, Clock, Award, Shield, Zap, Users } from 'lucide-react';
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import DisclaimerBanner from '../components/legal/DisclaimerBanner';

const betaFeatures = [
    { name: "AI-Powered Gap Analysis", description: "Upload your documents and get an instant CMMC readiness score." },
    { name: "AI Policy Generation", description: "Generate 3-5 core policies (Access Control, IR, etc.) in minutes." },
    { name: "Basic SSP Framework", description: "Create a foundational System Security Plan with AI assistance." },
    { name: "Expert Email Support", description: "Our team will answer your questions and provide implementation guidance via email." },
    { name: "8-Week Implementation Checklist", description: "A structured, step-by-step plan to guide you to compliance." },
    { name: "Professional PDF Reporting", description: "Download reports for leadership, primes, or SBIR proposals." }
];

const timeline = [
    { phase: "Today - Dec 5", title: "Free Beta Access", description: "Use all our tools, get compliant, and provide feedback.", icon: Zap },
    { phase: "Oct 29", title: "SBIR Proposal Deadline", description: "Use beta testimonials & data to submit a winning proposal.", icon: Award },
    { phase: "Nov 10", title: "DFARS Enforcement Begins", description: "Meet the deadline with confidence, backed by our tools.", icon: Shield },
    { phase: "Dec 6", title: "Commercial Launch", description: "Beta users get preferential pricing on our full Net-30/Wire Transfer commercial plans.", icon: Clock }
];

export default function ProgramDetails() {
    return (
        <div className="bg-gray-50">
            <div className="container mx-auto px-4 py-16">
                <motion.div 
                    className="text-center mb-12"
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                >
                    <Badge className="mb-4 bg-green-100 text-green-800 px-4 py-2 text-lg">LIMITED TIME</Badge>
                    <h1 className="text-4xl md:text-5xl font-extrabold text-gray-900 mb-4">
                        The HyperCore Free Beta Program
                    </h1>
                    <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                        Full access to our AI-powered CMMC readiness platform at no cost through December 5, 2025.
                    </p>
                </motion.div>

                <Alert className="max-w-4xl mx-auto mb-12 bg-blue-50 border-blue-200">
                    <Shield className="h-5 w-5 text-blue-600" />
                    <AlertTitle className="text-blue-800 font-bold text-xl">Our Strategic Goal: A Win-Win Partnership</AlertTitle>
                    <AlertDescription className="text-blue-700 text-lg mt-2 space-y-2">
                        <p><strong>Your Win:</strong> You get an enterprise-grade compliance toolkit for free, helping you meet the critical November 10th DFARS deadline without a hefty price tag.</p>
                        <p><strong>Our Win:</strong> We get invaluable feedback and real-world case studies from defense contractors like you to strengthen our SBIR grant proposal and perfect our platform.</p>
                    </AlertDescription>
                </Alert>

                <Card className="max-w-4xl mx-auto mb-12">
                    <CardHeader>
                        <CardTitle className="text-2xl">What's Included in the Free Beta?</CardTitle>
                        <CardDescription>You get the complete MVP feature set designed for immediate compliance impact.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <ul className="space-y-4">
                            {betaFeatures.map(feature => (
                                <li key={feature.name} className="flex items-start gap-3">
                                    <CheckCircle className="w-6 h-6 text-green-500 mt-1 flex-shrink-0" />
                                    <div>
                                        <h4 className="font-semibold">{feature.name}</h4>
                                        <p className="text-gray-600">{feature.description}</p>
                                    </div>
                                </li>
                            ))}
                        </ul>
                    </CardContent>
                </Card>

                <div className="text-center mb-12">
                    <h2 className="text-3xl font-bold text-gray-900 mb-8">Program Timeline & Key Dates</h2>
                    <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
                        {timeline.map(item => (
                            <div key={item.phase} className="text-center">
                                <div className="flex items-center justify-center bg-gray-200 rounded-full w-16 h-16 mx-auto mb-4">
                                    <item.icon className="w-8 h-8 text-gray-700" />
                                </div>
                                <h3 className="font-bold">{item.title}</h3>
                                <p className="text-sm text-gray-600">{item.phase}</p>
                                <p className="text-sm text-gray-500 mt-1">{item.description}</p>
                            </div>
                        ))}
                    </div>
                </div>
                
                 <div className="max-w-4xl mx-auto mb-12">
                    <DisclaimerBanner />
                </div>

                <div className="text-center">
                     <Button asChild size="lg" className="bg-blue-600 hover:bg-blue-700 text-lg px-8 py-6">
                        <Link to={createPageUrl('PartnershipTrial')}>
                            Get Free Beta Access Now <ArrowRight className="w-5 h-5 ml-2" />
                        </Link>
                    </Button>
                </div>
            </div>
        </div>
    );
}