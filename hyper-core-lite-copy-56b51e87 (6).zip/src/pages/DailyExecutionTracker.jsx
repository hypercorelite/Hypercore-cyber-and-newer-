
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Check, Calendar, Target, DollarSign, Zap, Users, TrendingUp, Lightbulb } from 'lucide-react';
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";
import { motion } from "framer-motion";

const executionPlan = {
    sprintDuration: 90,
    startDate: "September 26, 2025",
    goal: "$1M ARR by mid-2026",
    budget: 400,
    weeks: [
        // --- WEEKS 1-4: BUILD AUDIENCE & TRACTION ---
        {
            week: 1, theme: "LinkedIn Community Launch",
            tasks: [
                { day: "Fri, Sep 26", task: "Create 'NoVA DIB CMMC Innovators' LinkedIn Group.", completed: false },
                { day: "Mon, Sep 29", task: "Post first article: '70% flow-down errors? AI fixes it'. Invite 20 initial members.", completed: false },
                { day: "Tue, Sep 30", task: "Begin manual outreach to 5 leads from Sales Navigator trial.", completed: false },
                { day: "Wed, Oct 1", task: "Host text-based AMA in the LinkedIn group on 'The True Cost of CMMC'.", completed: false },
                { day: "Thu, Oct 2", task: "Send 'DIB Quick-Win Kit' to the 5 leads contacted.", completed: false }
            ]
        },
        {
            week: 2, theme: "First Pilot Acquisition",
            tasks: [
                { day: "Mon, Oct 6", task: "Follow up with initial 5 leads. Goal: 1 pilot close.", completed: false },
                { day: "Tue, Oct 7", task: "Identify and contact 10 new high-potential leads.", completed: false },
                { day: "Wed, Oct 8", task: "Post 2nd article: 'Why Your SSP Fails Audits'.", completed: false },
                { day: "Fri, Oct 10", task: "Review Week 2 progress against KPI: >10% engagement in LinkedIn group.", completed: false }
            ]
        },
        {
            week: 8, theme: "Amplify & Iterate with PLG",
            tasks: [
                 { day: "Mon, Nov 17", task: "A/B Test 'Referral Spark' prompt on 10% of chatbot users.", completed: false },
                 { day: "Wed, Nov 19", task: "Analyze chatbot referral data. Target: >2% share rate.", completed: false },
                 { day: "Fri, Nov 21", task: "Set up Zapier trigger for lead scoring based on user session time.", completed: false }
            ]
        },
        {
            week: 12, theme: "Scale & Fund",
            tasks: [
                { day: "Mon, Dec 15", task: "Draft SBIR Proposal Section on validated traction (pilot data, community growth).", completed: false },
                { day: "Wed, Dec 17", task: "Seed content on Reddit (r/CMMC) & NDIA forums.", completed: false },
                { day: "Fri, Dec 19", task: "Finalize SBIR draft for January 7 submission target.", completed: false }
            ]
        }
    ]
};

const executionTasks = [
    {
        id: 'linkedin_group_launch',
        category: 'LinkedIn Strategy',
        title: '📱 LinkedIn Group Launch',
        description: 'Create NoVA DIB CMMC Innovators group and post launch content',
        status: 'completed', // UPDATED: You completed this!
        priority: 'critical',
        deadline: 'September 19, 7:00 PM',
        completedAt: new Date().toISOString(),
        nextAction: 'Post Day 2 content and invite 20 DIB professionals',
        evidence: 'LinkedIn group created: NoVA DIB CMMC Innovators, Launch post published',
        impact: 'Foundation for prime contractor trust-building and community engagement'
    },
    {
        id: 'prime_outreach_emails',
        category: 'Prime Strategy', 
        title: '📧 Prime Contractor Outreach',
        description: 'Email 10 NoVA primes using professional Net-30 messaging',
        status: 'in_progress',
        priority: 'critical',
        deadline: 'September 19, 8:00 PM',
        nextAction: 'Send emails to Leidos, SRA, Booz Allen CISOs using template',
        evidence: 'Need to send 10 emails via AWS SES with tracking',
        impact: 'Direct path to 2-3 demo bookings and sub referrals'
    },
    {
        id: 'day_2_linkedin_content',
        category: 'LinkedIn Strategy',
        title: '📝 Day 2 LinkedIn Post',
        description: 'Post "The $50K Question" content to build engagement',
        status: 'ready',
        priority: 'high', 
        deadline: 'September 20, 12:00 PM',
        nextAction: 'Copy content from LinkedInGroupPosts and publish',
        evidence: 'Content ready in LinkedInGroupPosts page',
        impact: 'Build authority on cost savings vs traditional consultants'
    },
    {
        id: 'linkedin_connections',
        category: 'LinkedIn Strategy',
        title: '🤝 Connect with DIB Professionals',
        description: 'Send 20 connection requests to CISOs and program managers',
        status: 'ready',
        priority: 'high',
        deadline: 'September 20, 6:00 PM', 
        nextAction: 'Search "CISO Northern Virginia defense contractor" and connect',
        evidence: 'Target list from LinkedIn Sales Navigator free trial',
        impact: 'Build network for group invitations and direct outreach'
    }
];

export default function DailyExecutionTracker() {
    const [plan, setPlan] = useState(executionPlan);

    const toggleTask = (weekIndex, taskIndex) => {
        const newWeeks = [...plan.weeks];
        newWeeks[weekIndex].tasks[taskIndex].completed = !newWeeks[weekIndex].tasks[taskIndex].completed;
        setPlan({ ...plan, weeks: newWeeks });
    };

    const completedTasks = plan.weeks.flatMap(w => w.tasks).filter(t => t.completed).length;
    const totalTasks = plan.weeks.flatMap(w => w.tasks).length;
    const progress = Math.round((completedTasks / totalTasks) * 100);

    return (
        <div className="space-y-6">
            <BreadcrumbNav currentPageName="Daily Execution Tracker" />
            
            <header className="text-center space-y-2">
                <h1 className="text-3xl font-bold tracking-tight text-gray-900">90-Day Tactical Execution Playbook</h1>
                <p className="text-lg text-gray-600">Your daily command center for achieving market dominance by December 26, 2025.</p>
            </header>

            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-3"><Target className="w-6 h-6 text-blue-600"/> Sprint Goals</CardTitle>
                </CardHeader>
                <CardContent className="grid md:grid-cols-3 gap-4">
                    <div className="p-4 bg-gray-50 rounded-lg text-center">
                        <p className="text-2xl font-bold text-blue-700">5-10</p>
                        <p className="text-sm text-gray-600">Pilot Clients</p>
                    </div>
                    <div className="p-4 bg-gray-50 rounded-lg text-center">
                        <p className="text-2xl font-bold text-green-700">$10-20K</p>
                        <p className="text-sm text-gray-600">Q4 Revenue</p>
                    </div>
                    <div className="p-4 bg-gray-50 rounded-lg text-center">
                        <p className="text-2xl font-bold text-purple-700">$275K</p>
                        <p className="text-sm text-gray-600">SBIR Phase I Target</p>
                    </div>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>Overall Progress</CardTitle>
                    <CardDescription>{completedTasks} of {totalTasks} tasks completed.</CardDescription>
                </CardHeader>
                <CardContent>
                    <Progress value={progress} className="w-full" />
                    <p className="text-center text-lg font-bold mt-2">{progress}% Complete</p>
                </CardContent>
            </Card>
            
            {/* New Card for Today's Critical Tasks */}
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-3"><Zap className="w-6 h-6 text-yellow-600"/> Today's Critical Tasks</CardTitle>
                    <CardDescription>High-priority actions for immediate impact.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    {executionTasks.map((task) => (
                        <div key={task.id} className="p-3 border rounded-md shadow-sm bg-white">
                            <div className="flex items-start justify-between mb-2">
                                <div className="flex items-center gap-2">
                                    <h3 className="font-semibold text-lg">{task.title}</h3>
                                    {task.status === 'completed' && <Check className="w-5 h-5 text-green-500" />}
                                </div>
                                <div className="flex flex-wrap gap-2 justify-end">
                                    {task.status === 'completed' && (
                                        <Badge className="bg-green-100 text-green-700 hover:bg-green-100/80">
                                            Completed
                                        </Badge>
                                    )}
                                    {task.status === 'in_progress' && (
                                        <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-100/80">
                                            In Progress
                                        </Badge>
                                    )}
                                    {task.status === 'ready' && (
                                        <Badge variant="outline">
                                            Ready
                                        </Badge>
                                    )}
                                    <Badge variant={task.priority === 'critical' ? 'destructive' : 'default'}>
                                        {task.priority}
                                    </Badge>
                                </div>
                            </div>
                            <p className="text-gray-700 text-sm mb-2">{task.description}</p>
                            <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-xs text-gray-500">
                                {task.deadline && (
                                    <span className="flex items-center gap-1">
                                        <Calendar className="w-3 h-3" /> Due: {task.deadline}
                                    </span>
                                )}
                                {task.nextAction && (
                                    <span className="flex items-center gap-1">
                                        <Lightbulb className="w-3 h-3" /> Next: {task.nextAction}
                                    </span>
                                )}
                                {task.category && (
                                    <span className="flex items-center gap-1">
                                        <Users className="w-3 h-3" /> {task.category}
                                    </span>
                                )}
                            </div>
                        </div>
                    ))}
                </CardContent>
            </Card>

            <div className="space-y-8">
                {plan.weeks.map((weekData, weekIndex) => (
                    <motion.div key={weekData.week} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: weekIndex * 0.1 }}>
                        <Card>
                            <CardHeader>
                                <CardTitle className="text-xl">Week {weekData.week}: {weekData.theme}</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                {weekData.tasks.map((task, taskIndex) => (
                                    <div 
                                        key={taskIndex} 
                                        className={`flex items-center gap-4 p-3 rounded-md transition-colors ${task.completed ? 'bg-green-50' : 'bg-white'}`}
                                    >
                                        <button onClick={() => toggleTask(weekIndex, taskIndex)} className="flex-shrink-0">
                                            <div className={`w-6 h-6 rounded-full flex items-center justify-center border-2 ${task.completed ? 'bg-green-600 border-green-600' : 'border-gray-300'}`}>
                                                {task.completed && <Check className="w-4 h-4 text-white"/>}
                                            </div>
                                        </button>
                                        <div className="flex-grow">
                                            <p className={`font-medium ${task.completed ? 'text-gray-500 line-through' : 'text-gray-800'}`}>
                                                {task.task}
                                            </p>
                                        </div>
                                        <Badge variant="outline" className={task.completed ? 'text-gray-500' : 'text-gray-600'}>{task.day}</Badge>
                                    </div>
                                ))}
                            </CardContent>
                        </Card>
                    </motion.div>
                ))}
            </div>

            <Alert className="bg-yellow-50 border-yellow-300">
                <Lightbulb className="h-4 w-4 text-yellow-700" />
                <AlertTitle className="font-bold text-yellow-800">Budget & Resource Allocation</AlertTitle>
                <AlertDescription className="text-yellow-700 mt-2">
                    <p><strong>Monthly Budget:</strong> <span className="font-bold">${plan.budget}</span></p>
                    <ul className="list-disc list-inside mt-1">
                        <li><strong>Content Amplification ($150):</strong> Reddit Ads, UGC Challenge assets.</li>
                        <li><strong>Lead Gen Tools ($100):</strong> LinkedIn Sales Navigator (post-trial), AWS SES.</li>
                        <li><strong>Automation ($150):</strong> AWS Lambda, GA4 Freelancer Setup.</li>
                    </ul>
                </AlertDescription>
            </Alert>
        </div>
    );
}
