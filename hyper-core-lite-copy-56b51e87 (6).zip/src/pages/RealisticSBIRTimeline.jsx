import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, CheckCircle, ArrowRight, Target, AlertTriangle, Clock } from 'lucide-react';
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

const phases = [
    {
        phase: "Phase 1: Proof of Concept MVP (Sep 15 - Oct 29, 2025)",
        duration: "45 days",
        goal: "Deliver a working demo for SBIR 25.4 proposal",
        reality: "This is your primary focus. Success here unlocks everything else.",
        deliverables: [
            { item: "Core gap analysis engine", realistic: "✅ Achievable - AI can automate this", difficulty: "medium" },
            { item: "NIST 800-171 control mapping", realistic: "✅ Achievable - data + RAG system", difficulty: "medium" },
            { item: "Basic SSP template generation", realistic: "✅ Achievable - document generation", difficulty: "low" },
            { item: "Simple web interface for demo", realistic: "✅ Achievable - basic React frontend", difficulty: "low" },
            { item: "Working AWS deployment", realistic: "⚠️ Challenging - significant DevOps overhead", difficulty: "high" },
            { item: "Full 110 CMMC controls coverage", realistic: "❌ Unrealistic - focus on 20-30 key controls", difficulty: "impossible" },
            { item: "Production-ready security", realistic: "❌ Unrealistic - demo security sufficient", difficulty: "impossible" }
        ],
        sbirAlignment: "Perfect timing for SBIR 25.4 submission. Demo becomes proof of feasibility.",
        funding: "Target: $250K Phase I award",
        risk: "High risk, high reward. If you miss Oct 29 deadline, you lose 6 months."
    },
    {
        phase: "Phase 2: Enhanced MVP (Nov 1 - Dec 31, 2025)",
        duration: "60 days",
        goal: "Launch commercially viable version post-CMMC enforcement",
        reality: "Leverage CMMC panic buying while building toward Phase II",
        deliverables: [
            { item: "Full 110 control coverage", realistic: "✅ Achievable with 60 days focused work", difficulty: "medium" },
            { item: "Production security hardening", realistic: "✅ Achievable - AWS security best practices", difficulty: "medium" },
            { item: "Customer onboarding workflow", realistic: "✅ Achievable - streamlined process", difficulty: "low" },
            { item: "Basic compliance reporting", realistic: "✅ Achievable - PDF generation", difficulty: "low" },
            { item: "First 10 paying customers", realistic: "⚠️ Challenging - requires sales effort", difficulty: "high" },
            { item: "Automated customer support", realistic: "⚠️ Challenging - AI agent development", difficulty: "high" }
        ],
        sbirAlignment: "Perfect timing for SBIR 25.5 (Dec 3 deadline) with real customer traction",
        funding: "Commercial revenue: $25K-$125K from early customers",
        risk: "Medium risk. Market timing is perfect, execution is challenging."
    },
    {
        phase: "Phase 3: Scale & Phase II (Jan 1 - Dec 31, 2026)",
        duration: "12 months",
        goal: "Scale to 100+ customers, secure Phase II SBIR",
        reality: "This is where the 'Me, Myself & AI' model is truly tested",
        deliverables: [
            { item: "100+ customer milestone", realistic: "✅ Achievable with proven product", difficulty: "medium" },
            { item: "Full automation pipeline", realistic: "✅ Achievable - AI agents mature by 2026", difficulty: "medium" },
            { item: "Advanced analytics/reporting", realistic: "✅ Achievable - data-driven insights", difficulty: "low" },
            { item: "Phase II SBIR award ($1.7M)", realistic: "✅ Achievable with Phase I success", difficulty: "low" },
            { item: "Strategic partnerships", realistic: "✅ Achievable - C3PAOs, MSPs, etc.", difficulty: "low" },
            { item: "National market presence", realistic: "⚠️ Challenging - requires significant marketing", difficulty: "high" }
        ],
        sbirAlignment: "Phase II application in Q3 2026 with strong commercial validation",
        funding: "Commercial: $1M-$5M revenue + $1.7M Phase II SBIR",
        risk: "Lower risk. Market validation reduces uncertainty significantly."
    }
];

const backupPlan = [
    { scenario: "Miss SBIR 25.4 (Oct 29)", action: "Target SBIR 25.5 (Dec 3) with more mature MVP", impact: "6-month delay but stronger proposal" },
    { scenario: "MVP not ready Nov 10", action: "Launch in Q1 2026 during contract inclusion wave", impact: "Later market entry but more polished product" },
    { scenario: "Can't scale solo", action: "Use SBIR Phase I to hire 1-2 key developers", impact: "Higher costs but dramatically increased capability" },
    { scenario: "Technical challenges exceed timeline", action: "Focus on specific CMMC domains (AC, IA, SC) rather than full coverage", impact: "Narrower initial market but faster time to value" }
];

export default function RealisticSBIRTimeline() {
    return (
        <div className="space-y-8">
            <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center"
            >
                <Badge className="mb-4 bg-blue-100 text-blue-800">REALISTIC ASSESSMENT</Badge>
                <h1 className="text-4xl font-bold text-gray-900 mb-4">
                    SBIR-Aligned Development Timeline
                </h1>
                <p className="text-xl text-gray-600 max-w-4xl mx-auto">
                    A phased, realistic approach to building your CMMC AI platform while securing SBIR funding. 
                    Optimized for solo founder + AI assistance execution model.
                </p>
            </motion.div>

            <Alert className="bg-yellow-50 border-yellow-200">
                <AlertTriangle className="h-4 w-4 text-yellow-600" />
                <AlertTitle className="text-yellow-800 font-bold">Reality Check: This Is Extremely Ambitious</AlertTitle>
                <AlertDescription className="text-yellow-700">
                    What you're attempting typically requires a team of 5-10 people and 12-18 months. Success depends on ruthless prioritization, 
                    AI leveraging, and accepting that not everything will be perfect in Phase 1. Focus on proof of concept, not perfection.
                </AlertDescription>
            </Alert>

            <div className="space-y-8">
                {phases.map((phase, index) => (
                    <motion.div
                        key={index}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.2 }}
                    >
                        <Card className="border-l-4 border-blue-500">
                            <CardHeader>
                                <div className="flex justify-between items-start">
                                    <div>
                                        <CardTitle className="text-2xl">{phase.phase}</CardTitle>
                                        <CardDescription className="text-lg mt-1">
                                            Duration: {phase.duration} | Goal: {phase.goal}
                                        </CardDescription>
                                    </div>
                                    <Badge variant="outline" className="text-sm">
                                        Phase {index + 1}
                                    </Badge>
                                </div>
                            </CardHeader>
                            <CardContent className="space-y-6">
                                <div className="p-4 bg-gray-50 rounded-lg">
                                    <h4 className="font-semibold text-gray-800 mb-2">Reality Assessment:</h4>
                                    <p className="text-sm text-gray-700">{phase.reality}</p>
                                </div>

                                <div>
                                    <h4 className="font-semibold text-gray-800 mb-3">Deliverables & Feasibility:</h4>
                                    <div className="space-y-2">
                                        {phase.deliverables.map((deliverable, i) => (
                                            <div key={i} className={`flex items-start gap-3 p-3 rounded-md ${
                                                deliverable.difficulty === 'low' ? 'bg-green-50' :
                                                deliverable.difficulty === 'medium' ? 'bg-yellow-50' :
                                                deliverable.difficulty === 'high' ? 'bg-orange-50' : 'bg-red-50'
                                            }`}>
                                                <div className="flex-shrink-0 mt-1">
                                                    {deliverable.realistic.includes('✅') && <CheckCircle className="w-4 h-4 text-green-600" />}
                                                    {deliverable.realistic.includes('⚠️') && <AlertTriangle className="w-4 h-4 text-yellow-600" />}
                                                    {deliverable.realistic.includes('❌') && <AlertTriangle className="w-4 h-4 text-red-600" />}
                                                </div>
                                                <div>
                                                    <p className="font-semibold text-sm">{deliverable.item}</p>
                                                    <p className="text-xs text-gray-600">{deliverable.realistic}</p>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>

                                <div className="grid md:grid-cols-2 gap-4">
                                    <div className="p-4 bg-blue-50 rounded-lg">
                                        <h5 className="font-semibold text-blue-800 mb-2">SBIR Alignment</h5>
                                        <p className="text-sm text-blue-700">{phase.sbirAlignment}</p>
                                    </div>
                                    <div className="p-4 bg-green-50 rounded-lg">
                                        <h5 className="font-semibold text-green-800 mb-2">Funding Target</h5>
                                        <p className="text-sm text-green-700">{phase.funding}</p>
                                    </div>
                                </div>

                                <div className="p-4 bg-red-50 rounded-lg border border-red-200">
                                    <h5 className="font-semibold text-red-800 mb-2">Risk Assessment</h5>
                                    <p className="text-sm text-red-700">{phase.risk}</p>
                                </div>
                            </CardContent>
                        </Card>
                    </motion.div>
                ))}
            </div>

            <Card>
                <CardHeader>
                    <CardTitle>Backup Plans & Risk Mitigation</CardTitle>
                    <CardDescription>Contingency strategies for when things don't go according to plan</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="space-y-4">
                        {backupPlan.map((backup, index) => (
                            <div key={index} className="p-4 border rounded-lg">
                                <h4 className="font-semibold text-red-700 mb-2">If: {backup.scenario}</h4>
                                <p className="text-sm text-gray-700 mb-1"><strong>Action:</strong> {backup.action}</p>
                                <p className="text-sm text-gray-600"><strong>Impact:</strong> {backup.impact}</p>
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>

            <Card className="bg-gray-800 text-white">
                <CardHeader>
                    <CardTitle>The Bottom Line: Focus on Phase 1 Success</CardTitle>
                    <CardDescription className="text-gray-300">Everything else depends on nailing the first 45 days</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="p-4 bg-gray-700 rounded-lg">
                        <h4 className="font-bold mb-2">Success Probability Assessment:</h4>
                        <ul className="space-y-1 text-sm">
                            <li>• <strong>Phase 1 MVP by Oct 29:</strong> 60% (challenging but doable)</li>
                            <li>• <strong>SBIR 25.4 award:</strong> 40% (competitive landscape)</li>
                            <li>• <strong>Commercial launch by Dec 31:</strong> 75% (with or without SBIR)</li>
                            <li>• <strong>100 customers by Dec 2026:</strong> 85% (if Phase 1 succeeds)</li>
                        </ul>
                    </div>
                    <div className="flex flex-col sm:flex-row gap-4">
                        <Button asChild size="lg" variant="secondary" className="flex-1">
                            <Link to={createPageUrl('DailyAchievementSchedule')}>
                                View Day-by-Day Sprint Plan <ArrowRight className="w-4 h-4 ml-2" />
                            </Link>
                        </Button>
                        <Button asChild size="lg" variant="secondary" className="flex-1">
                            <Link to={createPageUrl('SBIRFundingStrategy')}>
                                SBIR Strategy & Topics <ArrowRight className="w-4 h-4 ml-2" />
                            </Link>
                        </Button>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}