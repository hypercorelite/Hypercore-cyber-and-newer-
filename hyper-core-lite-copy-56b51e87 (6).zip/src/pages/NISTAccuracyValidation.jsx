import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { CheckCircle, AlertTriangle, Zap, DollarSign, Clock, GitBranch } from 'lucide-react';

const validationResults = [
    { control: 'AC.L2-3.1.3', simulated: '100% Match', real_world: '92% Match' },
    { control: 'IR.L2-3.6.1', simulated: '100% Match', real_world: '95% Match' },
    { control: 'SC.L2-3.13.2', simulated: '100% Match', real_world: '88% Match' },
];

export default function NISTAccuracyValidation() {
    return (
        <div className="container mx-auto py-12 px-4">
            <header className="text-center mb-12">
                <h1 className="text-4xl font-extrabold text-gray-900">NIST 800-171 AI Accuracy Validation</h1>
                <p className="mt-2 text-lg text-gray-600">Verifying HyperCore's AI (Mistral-7B) against official NIST controls.</p>
            </header>

            {/* NEW BANNER */}
            <div className="bg-gradient-to-r from-blue-600 to-green-500 text-white rounded-lg p-6 text-center mb-12 shadow-lg">
                <h2 className="text-2xl font-bold">100% Simulation Accuracy • 85-95% Real-World Results</h2>
                <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-4 text-lg">
                    <div className="flex flex-col"><span className="font-bold">$5K-$12K</span><span className="text-sm opacity-80">Affordable Cost</span></div>
                    <div className="flex flex-col"><span className="font-bold">70% Savings</span><span className="text-sm opacity-80">vs. Competitors</span></div>
                    <div className="flex flex-col"><span className="font-bold">90-Day</span><span className="text-sm opacity-80">Compliance</span></div>
                    <div className="flex flex-col"><span className="font-bold">Mistral-7B AI</span><span className="text-sm opacity-80">Powered</span></div>
                </div>
            </div>

            <Alert className="mb-8">
                <AlertTriangle className="h-4 w-4" />
                <AlertTitle>Validation Methodology</AlertTitle>
                <AlertDescription>
                    We compare AI-generated control implementations against a government-validated baseline in a simulated environment (100% accuracy) and against real-world, anonymized client data (85-95% accuracy) to ensure both theoretical correctness and practical effectiveness.
                </AlertDescription>
            </Alert>
            
            <div className="grid md:grid-cols-2 gap-8">
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2"><CheckCircle className="text-green-500" /> Simulated Environment</CardTitle>
                        <CardDescription>Perfect-state, lab conditions to test core logic.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <p className="text-4xl font-bold text-green-600 mb-2">100%</p>
                        <p className="text-gray-600">The AI perfectly maps all 110 NIST 800-171 controls to their requirements in a sanitized, ideal environment.</p>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2"><GitBranch className="text-blue-500" /> Real-World Data</CardTitle>
                        <CardDescription>Anonymized data from real SMBs with messy, incomplete documentation.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <p className="text-4xl font-bold text-blue-600 mb-2">85-95%</p>
                        <p className="text-gray-600">The AI correctly identifies and maps controls with high accuracy, flagging ambiguities for human review. This is where the 90-day guarantee adds value.</p>
                    </CardContent>
                </Card>
            </div>

            <Card className="mt-8">
                <CardHeader>
                    <CardTitle>Sample Validation Results</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="overflow-x-auto">
                        <table className="min-w-full divide-y divide-gray-200">
                            <thead className="bg-gray-50">
                                <tr>
                                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Control ID</th>
                                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Simulated Accuracy</th>
                                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Real-World Accuracy</th>
                                </tr>
                            </thead>
                            <tbody className="bg-white divide-y divide-gray-200">
                                {validationResults.map((result) => (
                                    <tr key={result.control}>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{result.control}</td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-green-600"><Badge variant="outline" className="bg-green-100 text-green-800">{result.simulated}</Badge></td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-blue-600"><Badge variant="outline" className="bg-blue-100 text-blue-800">{result.real_world}</Badge></td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}