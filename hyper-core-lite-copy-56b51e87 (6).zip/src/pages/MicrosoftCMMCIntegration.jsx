import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { CheckCircle, Shield, Users, Lock, Eye, FileText, DollarSign, Zap } from 'lucide-react';
import { motion } from "framer-motion";

const microsoftIntegrations = {
    accessControl: [
        {
            service: "Microsoft Entra ID Governance",
            cmmcControls: ["AC.L2-3.1.2", "AC.L2-3.1.5", "AC.L2-3.1.7"],
            description: "Automated user lifecycle management and access reviews",
            hypercoreIntegration: "Real-time sync with HyperCore's compliance dashboard for automated access auditing",
            implementation: {
                complexity: "Medium",
                timeframe: "2-3 weeks",
                cost: "$2,000-4,000",
                api: "Microsoft Graph API"
            },
            evidenceAutomation: [
                "Automated user provisioning/deprovisioning logs",
                "Access review completion reports", 
                "Least privilege enforcement verification",
                "Account usage monitoring dashboards"
            ]
        },
        {
            service: "Microsoft Entra Privileged Identity Management (PIM)",
            cmmcControls: ["AC.L2-3.1.2", "AC.L2-3.1.3"],
            description: "Just-in-time privileged access with comprehensive auditing",
            hypercoreIntegration: "Automated privileged access reports and anomaly detection",
            implementation: {
                complexity: "High",
                timeframe: "3-4 weeks",
                cost: "$4,000-6,000",
                api: "Microsoft Graph API + PIM API"
            },
            evidenceAutomation: [
                "Time-bound privileged access logs",
                "Administrative role activation reports",
                "Privileged access review attestations",
                "Emergency access procedure documentation"
            ]
        },
        {
            service: "Microsoft Intune",
            cmmcControls: ["CM.L2-3.4.1", "CM.L2-3.4.7"],
            description: "Endpoint configuration management and compliance enforcement",
            hypercoreIntegration: "Device compliance dashboard with real-time policy enforcement status",
            implementation: {
                complexity: "Medium", 
                timeframe: "2-3 weeks",
                cost: "$3,000-5,000",
                api: "Microsoft Graph API (Intune endpoints)"
            },
            evidenceAutomation: [
                "Device configuration compliance reports",
                "Endpoint encryption verification",
                "Mobile device management policies",
                "Application protection policy enforcement"
            ]
        },
        {
            service: "Microsoft Conditional Access",
            cmmcControls: ["IA.L2-3.5.3", "AC.L2-3.1.1"],
            description: "Policy-based access control with MFA enforcement",
            hypercoreIntegration: "Continuous MFA compliance monitoring and reporting",
            implementation: {
                complexity: "Low",
                timeframe: "1-2 weeks", 
                cost: "$1,000-2,000",
                api: "Microsoft Graph API (Conditional Access)"
            },
            evidenceAutomation: [
                "MFA enforcement verification reports",
                "Location-based access policy compliance",
                "Device compliance gating reports",
                "Application access control logs"
            ]
        }
    ],
    dataProtection: [
        {
            service: "Microsoft Purview Information Protection (MPIP)",
            cmmcControls: ["MP.L2-3.8.3", "SC.L2-3.13.11"],
            description: "Automated CUI discovery, classification, and protection",
            hypercoreIntegration: "AI-enhanced CUI detection with compliance scoring",
            implementation: {
                complexity: "High",
                timeframe: "4-6 weeks",
                cost: "$6,000-10,000",
                api: "Microsoft Graph API + Purview APIs"
            },
            evidenceAutomation: [
                "Automated CUI classification reports", 
                "Sensitivity label application statistics",
                "Data protection policy enforcement logs",
                "Encryption coverage verification"
            ]
        },
        {
            service: "Microsoft Purview Data Loss Prevention (DLP)",
            cmmcControls: ["MP.L2-3.8.4", "SC.L2-3.13.5"],
            description: "Prevents unauthorized CUI sharing and exfiltration",
            hypercoreIntegration: "Real-time DLP incident correlation with threat intelligence",
            implementation: {
                complexity: "Medium",
                timeframe: "3-4 weeks",
                cost: "$4,000-6,000",
                api: "Microsoft Graph API (Security)"
            },
            evidenceAutomation: [
                "DLP policy violation reports",
                "CUI exfiltration prevention logs",
                "Incident response automation records",
                "Data sovereignty compliance verification"
            ]
        },
        {
            service: "Azure Key Vault",
            cmmcControls: ["SC.L2-3.13.11", "SC.L2-3.13.16"],
            description: "Centralized cryptographic key management",
            hypercoreIntegration: "Automated key rotation monitoring and compliance verification",
            implementation: {
                complexity: "Medium",
                timeframe: "2-3 weeks",
                cost: "$2,000-4,000",
                api: "Azure Key Vault API"
            },
            evidenceAutomation: [
                "Key lifecycle management reports",
                "Cryptographic operations audit logs",
                "Key rotation compliance verification", 
                "Hardware security module (HSM) usage reports"
            ]
        },
        {
            service: "Microsoft Defender for Cloud Apps",
            cmmcControls: ["AU.L2-3.3.1", "SI.L2-3.14.2"],
            description: "Cloud application security and activity monitoring",
            hypercoreIntegration: "Unified threat detection across cloud applications",
            implementation: {
                complexity: "Medium",
                timeframe: "2-3 weeks",
                cost: "$3,000-5,000",
                api: "Microsoft Graph Security API"
            },
            evidenceAutomation: [
                "Cloud application activity monitoring",
                "Anomalous behavior detection reports",
                "Data governance compliance verification",
                "Third-party application risk assessments"
            ]
        }
    ]
};

const implementationRoadmap = {
    phase1: {
        title: "Foundation (Weeks 1-4)",
        services: ["Microsoft Conditional Access", "Azure Key Vault"],
        budget: "$3,000-6,000",
        outcome: "Basic MFA enforcement and encryption key management evidence"
    },
    phase2: {
        title: "Access Control (Weeks 5-8)", 
        services: ["Microsoft Entra ID Governance", "Microsoft Intune"],
        budget: "$5,000-9,000",
        outcome: "Comprehensive access control and endpoint management automation"
    },
    phase3: {
        title: "Data Protection (Weeks 9-16)",
        services: ["Microsoft Purview Information Protection", "Microsoft Purview DLP"],
        budget: "$10,000-16,000",
        outcome: "Full CUI lifecycle protection and compliance automation"
    },
    phase4: {
        title: "Advanced Security (Weeks 17-20)",
        services: ["Microsoft Entra PIM", "Microsoft Defender for Cloud Apps"],
        budget: "$7,000-11,000",
        outcome: "Advanced threat detection and privileged access management"
    }
};

const competitiveAdvantage = {
    singleCloudLimitations: [
        "AWS-only solutions miss Microsoft 365 environments where most CUI is created",
        "Microsoft-only solutions lack AWS infrastructure security inheritance",
        "Traditional consultants can't integrate both ecosystems effectively"
    ],
    hypercoreUniqueness: [
        "Only platform providing unified AWS + Microsoft compliance automation",
        "Cross-cloud threat correlation and incident response",
        "Seamless evidence collection from both environments",
        "Unified compliance dashboard spanning all client infrastructure"
    ]
};

export default function MicrosoftCMMCIntegration() {
    const [selectedPhase, setSelectedPhase] = useState('phase1');
    
    return (
        <div className="min-h-screen bg-gray-50 p-6">
            <div className="max-w-7xl mx-auto">
                <motion.div
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="text-center mb-8"
                >
                    <h1 className="text-4xl font-bold text-gray-900 mb-3">
                        Microsoft CMMC Integration Strategy
                    </h1>
                    <p className="text-xl text-gray-600">
                        The only platform offering unified AWS + Microsoft compliance automation for comprehensive CMMC coverage.
                    </p>
                </motion.div>

                <Alert className="mb-8 bg-blue-50 border-blue-200">
                    <Shield className="h-4 w-4 text-blue-600" />
                    <AlertTitle className="text-blue-800">Competitive Advantage</AlertTitle>
                    <AlertDescription className="text-blue-700">
                        Most defense contractors use Microsoft 365 for daily operations AND AWS for infrastructure. HyperCore is the only platform that automatically collects CMMC evidence from both environments, providing complete coverage that neither AWS-only nor Microsoft-only solutions can match.
                    </AlertDescription>
                </Alert>

                <Tabs defaultValue="integrations" className="space-y-6">
                    <TabsList className="grid w-full grid-cols-4">
                        <TabsTrigger value="integrations">Service Integrations</TabsTrigger>
                        <TabsTrigger value="roadmap">Implementation Roadmap</TabsTrigger>
                        <TabsTrigger value="evidence">Evidence Automation</TabsTrigger>
                        <TabsTrigger value="advantage">Competitive Position</TabsTrigger>
                    </TabsList>

                    <TabsContent value="integrations">
                        <div className="space-y-6">
                            <Card>
                                <CardHeader>
                                    <CardTitle className="flex items-center gap-2">
                                        <Users className="w-5 h-5 text-blue-600" />
                                        Access Control Services
                                    </CardTitle>
                                    <CardDescription>Automated identity and access management evidence collection</CardDescription>
                                </CardHeader>
                                <CardContent className="space-y-4">
                                    {microsoftIntegrations.accessControl.map((service, i) => (
                                        <div key={i} className="border rounded-lg p-4">
                                            <div className="flex justify-between items-start mb-2">
                                                <h4 className="font-semibold text-lg">{service.service}</h4>
                                                <div className="flex gap-1">
                                                    {service.cmmcControls.map(control => (
                                                        <Badge key={control} variant="outline">{control}</Badge>
                                                    ))}
                                                </div>
                                            </div>
                                            <p className="text-gray-600 mb-3">{service.description}</p>
                                            <div className="grid md:grid-cols-2 gap-4">
                                                <div>
                                                    <h5 className="font-medium mb-2">HyperCore Integration:</h5>
                                                    <p className="text-sm text-gray-700">{service.hypercoreIntegration}</p>
                                                </div>
                                                <div>
                                                    <h5 className="font-medium mb-2">Implementation:</h5>
                                                    <div className="text-sm space-y-1">
                                                        <div>Complexity: <Badge variant="secondary">{service.implementation.complexity}</Badge></div>
                                                        <div>Timeline: {service.implementation.timeframe}</div>
                                                        <div>Cost: {service.implementation.cost}</div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    ))}
                                </CardContent>
                            </Card>

                            <Card>
                                <CardHeader>
                                    <CardTitle className="flex items-center gap-2">
                                        <Lock className="w-5 h-5 text-green-600" />
                                        Data Protection Services
                                    </CardTitle>
                                    <CardDescription>Automated CUI protection and compliance verification</CardDescription>
                                </CardHeader>
                                <CardContent className="space-y-4">
                                    {microsoftIntegrations.dataProtection.map((service, i) => (
                                        <div key={i} className="border rounded-lg p-4">
                                            <div className="flex justify-between items-start mb-2">
                                                <h4 className="font-semibold text-lg">{service.service}</h4>
                                                <div className="flex gap-1">
                                                    {service.cmmcControls.map(control => (
                                                        <Badge key={control} variant="outline">{control}</Badge>
                                                    ))}
                                                </div>
                                            </div>
                                            <p className="text-gray-600 mb-3">{service.description}</p>
                                            <div className="grid md:grid-cols-2 gap-4">
                                                <div>
                                                    <h5 className="font-medium mb-2">HyperCore Enhancement:</h5>
                                                    <p className="text-sm text-gray-700">{service.hypercoreIntegration}</p>
                                                </div>
                                                <div>
                                                    <h5 className="font-medium mb-2">Evidence Generated:</h5>
                                                    <ul className="text-sm space-y-1">
                                                        {service.evidenceAutomation.slice(0, 3).map((evidence, j) => (
                                                            <li key={j} className="flex items-center gap-2">
                                                                <CheckCircle className="w-3 h-3 text-green-500" />
                                                                {evidence}
                                                            </li>
                                                        ))}
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    ))}
                                </CardContent>
                            </Card>
                        </div>
                    </TabsContent>

                    <TabsContent value="roadmap">
                        <Card>
                            <CardHeader>
                                <CardTitle>20-Week Implementation Roadmap</CardTitle>
                                <CardDescription>Phased approach to minimize risk and maximize early wins</CardDescription>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-6">
                                    {Object.entries(implementationRoadmap).map(([phase, details]) => (
                                        <div key={phase} className="border rounded-lg p-4">
                                            <div className="flex justify-between items-center mb-3">
                                                <h4 className="text-lg font-semibold text-blue-700">{details.title}</h4>
                                                <Badge variant="outline">{details.budget}</Badge>
                                            </div>
                                            <div className="grid md:grid-cols-2 gap-4">
                                                <div>
                                                    <h5 className="font-medium mb-2">Services Implemented:</h5>
                                                    <ul className="space-y-1">
                                                        {details.services.map(service => (
                                                            <li key={service} className="flex items-center gap-2">
                                                                <Zap className="w-3 h-3 text-orange-500" />
                                                                <span className="text-sm">{service}</span>
                                                            </li>
                                                        ))}
                                                    </ul>
                                                </div>
                                                <div>
                                                    <h5 className="font-medium mb-2">Key Outcome:</h5>
                                                    <p className="text-sm text-gray-700">{details.outcome}</p>
                                                </div>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                                
                                <Alert className="mt-6 bg-green-50 border-green-200">
                                    <DollarSign className="h-4 w-4 text-green-600" />
                                    <AlertTitle className="text-green-800">Total Investment</AlertTitle>
                                    <AlertDescription className="text-green-700">
                                        <strong>$25,000 - $42,000</strong> over 20 weeks for complete Microsoft integration. 
                                        ROI achieved with first client engagement ($50K+ value).
                                    </AlertDescription>
                                </Alert>
                            </CardContent>
                        </Card>
                    </TabsContent>

                    <TabsContent value="evidence">
                        <Card>
                            <CardHeader>
                                <CardTitle>Automated Evidence Collection</CardTitle>
                                <CardDescription>What auditors see when you integrate Microsoft services with HyperCore</CardDescription>
                            </CardHeader>
                            <CardContent>
                                <div className="grid md:grid-cols-2 gap-6">
                                    <div>
                                        <h4 className="font-semibold mb-3 text-blue-700">Access Control Evidence</h4>
                                        <div className="space-y-2">
                                            {microsoftIntegrations.accessControl.map(service => (
                                                service.evidenceAutomation.map((evidence, i) => (
                                                    <div key={`${service.service}-${i}`} className="flex items-center gap-2">
                                                        <CheckCircle className="w-4 h-4 text-green-500" />
                                                        <span className="text-sm">{evidence}</span>
                                                    </div>
                                                ))
                                            ))}
                                        </div>
                                    </div>
                                    <div>
                                        <h4 className="font-semibold mb-3 text-green-700">Data Protection Evidence</h4>
                                        <div className="space-y-2">
                                            {microsoftIntegrations.dataProtection.map(service => (
                                                service.evidenceAutomation.map((evidence, i) => (
                                                    <div key={`${service.service}-${i}`} className="flex items-center gap-2">
                                                        <CheckCircle className="w-4 h-4 text-green-500" />
                                                        <span className="text-sm">{evidence}</span>
                                                    </div>
                                                ))
                                            ))}
                                        </div>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    </TabsContent>

                    <TabsContent value="advantage">
                        <div className="grid md:grid-cols-2 gap-6">
                            <Card>
                                <CardHeader>
                                    <CardTitle className="text-red-700">Single-Cloud Limitations</CardTitle>
                                </CardHeader>
                                <CardContent className="space-y-3">
                                    {competitiveAdvantage.singleCloudLimitations.map((limitation, i) => (
                                        <div key={i} className="flex items-start gap-2">
                                            <AlertTriangle className="w-4 h-4 text-red-500 mt-1" />
                                            <span className="text-sm">{limitation}</span>
                                        </div>
                                    ))}
                                </CardContent>
                            </Card>
                            
                            <Card>
                                <CardHeader>
                                    <CardTitle className="text-green-700">HyperCore Advantage</CardTitle>
                                </CardHeader>
                                <CardContent className="space-y-3">
                                    {competitiveAdvantage.hypercoreUniqueness.map((advantage, i) => (
                                        <div key={i} className="flex items-start gap-2">
                                            <CheckCircle className="w-4 h-4 text-green-500 mt-1" />
                                            <span className="text-sm">{advantage}</span>
                                        </div>
                                    ))}
                                </CardContent>
                            </Card>
                        </div>
                    </TabsContent>
                </Tabs>
            </div>
        </div>
    );
}