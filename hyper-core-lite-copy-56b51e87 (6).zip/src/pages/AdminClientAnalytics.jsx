
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { ClientOnboarding } from "@/api/entities";
import { ClientEngagement } from "@/api/entities";
import { ClientFeedback } from "@/api/entities";
import { Download } from 'lucide-react';
import { toast } from "sonner";
import { exportSBIRClientData } from "@/api/functions";
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8'];

export default function AdminClientAnalytics() {
    const [analytics, setAnalytics] = useState({
        totalClients: 0,
        onboardingFunnel: [],
        engagementByType: [],
        avgAssessmentScore: 0,
        feedbackRatings: [],
        conversionLikelihood: []
    });
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        fetchAnalyticsData();
    }, []);

    const fetchAnalyticsData = async () => {
        setLoading(true);
        try {
            const [onboarding, engagements, feedback] = await Promise.all([
                ClientOnboarding.list(),
                ClientEngagement.list(),
                ClientFeedback.list()
            ]);

            // Total Clients
            const totalClients = onboarding.length;

            // Onboarding Funnel
            const funnelStages = ["email_captured", "profile_completed", "assessment_started", "report_generated", "feedback_provided", "conversion_interested"];
            const onboardingFunnel = funnelStages.map(stage => ({
                name: stage.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()),
                count: onboarding.filter(c => c.onboarding_stage === stage).length
            }));

            // Engagement by Type
            const engagementCounts = engagements.reduce((acc, e) => {
                acc[e.engagement_type] = (acc[e.engagement_type] || 0) + 1;
                return acc;
            }, {});
            const engagementByType = Object.keys(engagementCounts).map(key => ({
                name: key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()),
                count: engagementCounts[key]
            }));

            // Avg Assessment Score
            const assessments = engagements.filter(e => e.engagement_type === 'assessment_completed' && e.assessment_score);
            const avgAssessmentScore = assessments.length > 0
                ? assessments.reduce((sum, a) => sum + a.assessment_score, 0) / assessments.length
                : 0;

            // Feedback Ratings
            const ratingCounts = feedback.reduce((acc, f) => {
                acc[f.rating] = (acc[f.rating] || 0) + 1;
                return acc;
            }, {});
            const feedbackRatings = Object.keys(ratingCounts).map(key => ({
                name: `${key} Star`,
                count: ratingCounts[key]
            }));

            // Conversion Likelihood
            const likelihoodCounts = onboarding.reduce((acc, c) => {
                 if (c.conversion_likelihood) {
                    acc[c.conversion_likelihood] = (acc[c.conversion_likelihood] || 0) + 1;
                 }
                return acc;
            }, {});
            const conversionLikelihood = Object.keys(likelihoodCounts).map(key => ({
                name: key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()),
                value: likelihoodCounts[key]
            }));


            setAnalytics({
                totalClients,
                onboardingFunnel,
                engagementByType,
                avgAssessmentScore: avgAssessmentScore.toFixed(1),
                feedbackRatings,
                conversionLikelihood
            });

        } catch (error) {
            console.error("Failed to load analytics data:", error);
            toast.error("Could not load client analytics data.");
        } finally {
            setLoading(false);
        }
    };
    
    const handleExport = async () => {
        try {
            const { data, headers } = await exportSBIRClientData({});
            
            const contentType = headers.get('content-type');
            if (!contentType || !contentType.includes('text/csv')) {
                 toast.info("No SBIR data to export yet. Clients need to complete the beta and consent.");
                 return;
            }

            const blob = new Blob([data], { type: 'text/csv' });
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'sbir_case_study_data.csv';
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
            a.remove();
            toast.success("SBIR data exported successfully!");
        } catch (error) {
            toast.error("Failed to export SBIR data.");
            console.error(error);
        }
    };

    if (loading) {
        return <div className="p-8 text-center">Loading client analytics...</div>;
    }

    return (
        <div className="space-y-8">
            <BreadcrumbNav currentPageName="AdminClientAnalytics" />
            <div className="flex justify-between items-center">
                <CardHeader className="px-0">
                    <CardTitle className="text-3xl font-bold flex items-center gap-3">
                        <BarChart className="w-8 h-8 text-blue-600" />
                        Client Analytics & SBIR Data
                    </CardTitle>
                    <CardDescription>
                        Analyze client onboarding, engagement, and export anonymized data for your SBIR proposal.
                    </CardDescription>
                </CardHeader>
                <Button onClick={handleExport}>
                    <Download className="w-4 h-4 mr-2" />
                    Export SBIR Data (CSV)
                </Button>
            </div>

            {/* Key Metrics */}
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                <Card>
                    <CardHeader>
                        <CardTitle>Total Beta Clients</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-4xl font-bold">{analytics.totalClients}</p>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader>
                        <CardTitle>Avg. Assessment Score</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-4xl font-bold">{analytics.avgAssessmentScore}%</p>
                    </CardContent>
                </Card>
            </div>

            {/* Charts */}
            <div className="grid lg:grid-cols-2 gap-6">
                <Card>
                    <CardHeader>
                        <CardTitle>Client Onboarding Funnel</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <ResponsiveContainer width="100%" height={300}>
                            <BarChart data={analytics.onboardingFunnel}>
                                <CartesianGrid strokeDasharray="3 3" />
                                <XAxis dataKey="name" />
                                <YAxis />
                                <Tooltip />
                                <Legend />
                                <Bar dataKey="count" fill="#8884d8" />
                            </BarChart>
                        </ResponsiveContainer>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader>
                        <CardTitle>Conversion Likelihood (Post-Beta)</CardTitle>
                    </CardHeader>
                    <CardContent>
                         <ResponsiveContainer width="100%" height={300}>
                            <PieChart>
                                <Pie
                                    data={analytics.conversionLikelihood}
                                    cx="50%"
                                    cy="50%"
                                    labelLine={false}
                                    outerRadius={80}
                                    fill="#8884d8"
                                    dataKey="value"
                                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                                >
                                    {analytics.conversionLikelihood.map((entry, index) => (
                                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                    ))}
                                </Pie>
                                <Tooltip />
                            </PieChart>
                        </ResponsiveContainer>
                    </CardContent>
                </Card>
            </div>
             <Card>
                <CardHeader>
                    <CardTitle>Client Engagement by Type</CardTitle>
                </CardHeader>
                <CardContent>
                    <ResponsiveContainer width="100%" height={400}>
                        <BarChart layout="vertical" data={analytics.engagementByType}>
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis type="number" />
                            <YAxis dataKey="name" type="category" width={150} />
                            <Tooltip />
                            <Legend />
                            <Bar dataKey="count" fill="#00C49F" />
                        </BarChart>
                    </ResponsiveContainer>
                </CardContent>
            </Card>
        </div>
    );
}
