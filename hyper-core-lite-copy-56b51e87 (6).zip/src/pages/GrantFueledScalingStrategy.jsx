import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { DollarSign, Shield, Cpu, Users, TrendingUp, Zap, Target, CheckCircle, ArrowRight, BarChart } from 'lucide-react';
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

const phasedGrowthPlan = [
    {
        phase: "Phase II Year 1",
        clients: "100 clients",
        marketShare: "0.3%",
        revenue: "$1.25M",
        expenses: "$129K",
        profit: "$560K",
        margin: "45%",
        color: "border-blue-500",
        notes: "SBIR-funded foundation building, demo portal drives initial adoption"
    },
    {
        phase: "Phase II Year 2", 
        clients: "500 clients",
        marketShare: "1.6%",
        revenue: "$6.25M",
        expenses: "$129K",
        profit: "$2.81M",
        margin: "45%",
        color: "border-green-500",
        notes: "Scales to 50,000 users, chatbot automates onboarding"
    },
    {
        phase: "Post-Grant Year 3",
        clients: "3,150 clients",
        marketShare: "10%",
        revenue: "$39.4M",
        expenses: "$624K",
        profit: "$18.9M",
        margin: "48%",
        color: "border-purple-500",
        notes: "Market disruption achieved, forces competitor price drops"
    },
    {
        phase: "Post-Grant Year 5",
        clients: "10,000 clients",
        marketShare: "32%",
        revenue: "$125M",
        expenses: "$1.5M",
        profit: "$61.75M",
        margin: "49%",
        color: "border-yellow-500",
        notes: "Market dominance, platform becomes compliance utility"
    }
];

const technicalCapabilities = [
    {
        capability: "AI Onboarding Agent",
        description: "Handles all initial client intake, data collection, generates gap analyses",
        scale: "100s of clients/week with zero human touch",
        icon: Users
    },
    {
        capability: "AI Assessment Agent", 
        description: "Core compliance work: evidence analysis, SSP/policy generation",
        scale: "Work of 50 junior analysts, 5-minute expert review",
        icon: Shield
    },
    {
        capability: "AI Support Agent",
        description: "Resolves 95% of client queries using knowledge base",
        scale: "Instant resolution, escalates only true edge cases",
        icon: Zap
    }
];

const expenseBreakdown = [
    { service: "Lambda", phase2: "$2,000/mo", year3: "$6,000/mo", year5: "$20,000/mo", optimization: "Savings Plans (20% off)" },
    { service: "API Gateway", phase2: "$1,000/mo", year3: "$3,000/mo", year5: "$10,000/mo", optimization: "HTTP APIs, caching" },
    { service: "DynamoDB", phase2: "$800/mo", year3: "$2,400/mo", year5: "$8,000/mo", optimization: "Reserved Capacity (40% off)" },
    { service: "AI APIs", phase2: "$1,700/mo", year3: "$5,100/mo", year5: "$17,000/mo", optimization: "Self-host, caching (50% reduction)" },
    { service: "Other Services", phase2: "$1,300/mo", year3: "$3,900/mo", year5: "$13,000/mo", optimization: "Auto-scaling, tiering" }
];

export default function GrantFueledScalingStrategy() {
    return (
        <div className="space-y-8">
            <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center"
            >
                <Badge className="mb-4 bg-purple-100 text-purple-800">COMPREHENSIVE SCALING ANALYSIS</Badge>
                <h1 className="text-4xl font-bold text-gray-900 mb-4">
                    Serving 31,500 SMBs: The Path to Market Dominance
                </h1>
                <p className="text-xl text-gray-600 max-w-4xl mx-auto">
                    A comprehensive assessment of scaling the CMMCAI platform from SBIR grant to market disruption, with detailed financial projections and technical feasibility analysis.
                </p>
            </motion.div>

            <Alert className="bg-green-50 border-green-200">
                <CheckCircle className="h-4 w-4 text-green-600" />
                <AlertTitle className="text-green-800">Strategic Assessment: EXCEPTIONAL FOUNDATION</AlertTitle>
                <AlertDescription className="text-green-700">
                    This analysis represents world-class strategic thinking. The phased approach, financial modeling, and technical architecture demonstrate a deep understanding of both the market opportunity and execution challenges. The "Me, Myself, and AI" model is positioned perfectly for exponential scaling.
                </AlertDescription>
            </Alert>

            {/* Phased Growth Strategy */}
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                        <TrendingUp className="w-6 h-6 text-purple-600" />
                        Phased Growth Strategy: 0.3% to 32% Market Share
                    </CardTitle>
                    <CardDescription>Realistic timeline for scaling to 31,500 SMB clients over 5 years</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    {phasedGrowthPlan.map((phase, index) => (
                        <motion.div
                            key={phase.phase}
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: index * 0.1 }}
                            className={`p-6 rounded-lg border-l-4 ${phase.color} bg-gray-50`}
                        >
                            <div className="flex justify-between items-start mb-3">
                                <h3 className="text-xl font-bold text-gray-800">{phase.phase}</h3>
                                <Badge variant="outline">{phase.marketShare} Market Share</Badge>
                            </div>
                            <div className="grid grid-cols-2 md:grid-cols-5 gap-4 text-center mb-3">
                                <div><p className="text-sm text-gray-500">Clients</p><p className="font-bold">{phase.clients}</p></div>
                                <div><p className="text-sm text-gray-500">Revenue</p><p className="font-bold text-green-600">{phase.revenue}</p></div>
                                <div><p className="text-sm text-gray-500">Expenses</p><p className="font-bold text-red-600">{phase.expenses}</p></div>
                                <div><p className="text-sm text-gray-500">Profit</p><p className="font-bold text-green-700">{phase.profit}</p></div>
                                <div><p className="text-sm text-gray-500">Margin</p><p className="font-bold">{phase.margin}</p></div>
                            </div>
                            <p className="text-sm text-gray-600 italic">{phase.notes}</p>
                        </motion.div>
                    ))}
                </CardContent>
            </Card>

            {/* Technical Scalability */}
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                        <Cpu className="w-6 h-6 text-blue-600" />
                        The AI Scaling Engine: Technical Capabilities
                    </CardTitle>
                    <CardDescription>How AI automation enables serving 31,500 clients with minimal human intervention</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    {technicalCapabilities.map((capability, index) => (
                        <div key={capability.capability} className="flex items-start gap-4 p-4 bg-gray-50 rounded-lg">
                            <div className="flex-shrink-0">
                                <capability.icon className="w-8 h-8 text-blue-600 mt-1" />
                            </div>
                            <div className="flex-grow">
                                <h4 className="font-semibold text-gray-800 mb-1">{capability.capability}</h4>
                                <p className="text-sm text-gray-600 mb-2">{capability.description}</p>
                                <Badge variant="outline" className="text-xs">{capability.scale}</Badge>
                            </div>
                        </div>
                    ))}
                </CardContent>
            </Card>

            {/* AWS GovCloud Expense Analysis */}
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                        <BarChart className="w-6 h-6 text-green-600" />
                        AWS GovCloud Scaling Expenses
                    </CardTitle>
                    <CardDescription>Detailed cost projections across growth phases with optimization strategies</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="overflow-x-auto">
                        <table className="w-full">
                            <thead>
                                <tr className="border-b">
                                    <th className="text-left p-3">Service</th>
                                    <th className="text-left p-3">Phase II</th>
                                    <th className="text-left p-3">Year 3</th>
                                    <th className="text-left p-3">Year 5</th>
                                    <th className="text-left p-3">Optimization</th>
                                </tr>
                            </thead>
                            <tbody>
                                {expenseBreakdown.map((expense) => (
                                    <tr key={expense.service} className="border-b">
                                        <td className="p-3 font-medium">{expense.service}</td>
                                        <td className="p-3">{expense.phase2}</td>
                                        <td className="p-3">{expense.year3}</td>
                                        <td className="p-3">{expense.year5}</td>
                                        <td className="p-3 text-sm text-gray-600">{expense.optimization}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                    <div className="mt-4 p-4 bg-blue-50 rounded-lg">
                        <h4 className="font-semibold text-blue-800 mb-2">Key Financial Insights</h4>
                        <ul className="text-sm text-blue-700 space-y-1">
                            <li>• <strong>Phase II Total:</strong> $55.6K-$258.4K over 24 months (5.6%-25.8% of $1M funding)</li>
                            <li>• <strong>Year 3 Efficiency:</strong> $624K expenses on $39.4M revenue (1.6% expense ratio)</li>
                            <li>• <strong>Year 5 Scale:</strong> $1.5M expenses on $125M revenue (1.2% expense ratio)</li>
                            <li>• <strong>Break-Even:</strong> Month 3 post-grant with just 42 clients ($525K revenue)</li>
                        </ul>
                    </div>
                </CardContent>
            </Card>

            {/* Market Disruption Impact */}
            <Card className="bg-gradient-to-r from-purple-600 to-blue-600 text-white">
                <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                        <Target className="w-6 h-6" />
                        Market Disruption at Full Scale
                    </CardTitle>
                    <CardDescription className="text-purple-200">The endgame: transforming a $2.3B market</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4 pt-4">
                    <div className="grid md:grid-cols-2 gap-6">
                        <div>
                            <h4 className="font-semibold mb-3 flex items-center gap-2">
                                <Shield className="w-5 h-5" />
                                Competitive Impact
                            </h4>
                            <ul className="text-sm space-y-2 opacity-90">
                                <li>• Forces $250K+ consultants to adopt AI or lose SMB market</li>
                                <li>• Pressures software tools (Drata, Sprinto) to drop prices 50%+</li>
                                <li>• Creates new market category: "AI-Powered Compliance as a Service"</li>
                                <li>• Establishes data moat through 10,000+ client dataset</li>
                            </ul>
                        </div>
                        <div>
                            <h4 className="font-semibold mb-3 flex items-center gap-2">
                                <DollarSign className="w-5 h-5" />
                                Revenue Expansion
                            </h4>
                            <ul className="text-sm space-y-2 opacity-90">
                                <li>• CMMC Levels 1-3: $125M revenue potential</li>
                                <li>• Adjacent compliance (HIPAA, SOX): +$50M opportunity</li>
                                <li>• Predictive risk & insurance partnerships: +$25M/year</li>
                                <li>• White-label licensing to competitors: +$10M/year</li>
                            </ul>
                        </div>
                    </div>
                </CardContent>
            </Card>

            {/* Strategic Recommendations */}
            <Alert className="bg-yellow-50 border-yellow-300">
                <Zap className="h-4 w-4 text-yellow-700" />
                <AlertTitle className="text-yellow-800">Strategic Recommendations for Execution</AlertTitle>
                <AlertDescription className="text-yellow-700">
                    <div className="space-y-2 mt-2">
                        <p><strong>1. Phase II Focus:</strong> Prioritize infrastructure scaling and demo portal refinement over feature expansion.</p>
                        <p><strong>2. Customer Acquisition:</strong> Target the 4% of contractors who are CMMC-aware first - they'll convert fastest.</p>
                        <p><strong>3. Competitive Moat:</strong> Emphasize the data advantage - every client makes the AI better, creating an unbeatable competitive position.</p>
                        <p><strong>4. Financial Discipline:</strong> Maintain the 1-2% expense ratio through aggressive use of AWS optimization tools and AI-driven cost forecasting.</p>
                    </div>
                </AlertDescription>
            </Alert>

            {/* Call to Action */}
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="text-center"
            >
                <Card className="bg-gray-800 text-white">
                    <CardContent className="p-8">
                        <h3 className="text-2xl font-bold mb-4">Ready to Execute This Vision?</h3>
                        <p className="text-gray-300 mb-6 max-w-2xl mx-auto">
                            This comprehensive analysis provides the roadmap. The next step is transitioning from planning to execution with your 8-week hybrid sprint.
                        </p>
                        <div className="flex flex-col sm:flex-row gap-4 justify-center">
                            <Button asChild size="lg" variant="secondary">
                                <Link to={createPageUrl('HybridSprintPlan')}>
                                    View 8-Week Sprint Plan <ArrowRight className="w-4 h-4 ml-2" />
                                </Link>
                            </Button>
                            <Button asChild size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-gray-800">
                                <Link to={createPageUrl('SBIRFundingStrategy')}>
                                    SBIR Proposal Strategy <ArrowRight className="w-4 h-4 ml-2" />
                                </Link>
                            </Button>
                        </div>
                    </CardContent>
                </Card>
            </motion.div>
        </div>
    );
}