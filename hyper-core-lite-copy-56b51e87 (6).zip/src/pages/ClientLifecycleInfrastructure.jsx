
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Calendar, Clock, Bot, Users, CheckCircle, ArrowRight, Phone, Mail, FileText, Target } from 'lucide-react';
import { motion } from "framer-motion";

const automationWorkflow = [
    {
        phase: "Pre-Call Automation",
        icon: Calendar,
        automations: [
            "Calendly automatically schedules calls based on client's week in program",
            "AI generates week-specific agenda based on client's progress and POA&M status",
            "Automated email 24 hours before with agenda, outstanding items, and prep materials",
            "Client dashboard shows current week assignments and submission status"
        ],
        tools: ["Calendly Business", "AWS Lambda", "SendGrid", "Client Portal"],
        timesSaved: "15 minutes per client per week"
    },
    {
        phase: "Call Execution",
        icon: Phone,
        automations: [
            "Standardized call templates based on program week (1-12)",
            "AI-generated talking points based on client's specific environment",
            "Real-time evidence checklist during calls",
            "Automatic call recording and AI-generated summary"
        ],
        tools: ["Zoom", "Call recording", "AI transcription", "CRM integration"],
        timesSaved: "10 minutes per call in prep + 5 minutes post-call"
    },
    {
        phase: "Post-Call Follow-up",
        icon: FileText,
        automations: [
            "AI generates action items and next week's assignments",
            "Automated email to client within 2 hours with summary and tasks",
            "CRM automatically updates with progress notes and status changes",
            "Next week's calendar invite sent automatically"
        ],
        tools: ["AI transcription", "Email automation", "CRM", "Calendar integration"],
        timesSaved: "20 minutes per client per week"
    }
];

const scalingMetrics = [
    { clients: "1-5 clients", manualTime: "5-25 hours/week", automatedTime: "3-15 hours/week", savings: "40%" },
    { clients: "10 clients", manualTime: "50 hours/week", automatedTime: "25 hours/week", savings: "50%" },
    { clients: "20 clients", manualTime: "100 hours/week", automatedTime: "40 hours/week", savings: "60%" },
    { clients: "50 clients", manualTime: "250 hours/week", automatedTime: "75 hours/week", savings: "70%" }
];

const weeklyCallTemplates = [
    {
        week: "Week 1-2",
        focus: "Discovery & Foundation",
        agenda: [
            "Review system inventory and architecture",
            "Validate AI-generated policies against client environment",
            "Assign initial evidence collection tasks (5-7 items)",
            "Set expectations for Week 3 deliverables"
        ],
        automatedPrep: "AI analyzes client's initial assessment data and generates environment-specific talking points"
    },
    {
        week: "Week 3-6",
        focus: "Implementation Sprint 1",
        agenda: [
            "Review submitted evidence and provide feedback",
            "Address technical implementation questions",
            "Assign next batch of evidence tasks (8-10 items)",
            "Troubleshoot any blockers or vendor issues"
        ],
        automatedPrep: "System tracks submission status and flags overdue items for discussion"
    },
    {
        week: "Week 7-10",
        focus: "Implementation Sprint 2",
        agenda: [
            "Progress review: 70%+ of controls should be complete",
            "Focus on remaining high-priority gaps",
            "Begin POA&M refinement for remaining items",
            "Prepare for final evidence organization phase"
        ],
        automatedPrep: "AI calculates completion percentage and identifies remaining critical path items"
    },
    {
        week: "Week 11-12",
        focus: "Package Assembly & Handoff",
        agenda: [
            "Final evidence review and organization",
            "C3PAO selection guidance and preparation",
            "Management briefing and sign-off process",
            "Transition to independent maintenance"
        ],
        automatedPrep: "System generates final compliance report and readiness assessment"
    }
];

export default function ClientLifecycleInfrastructure() {
    const [selectedTab, setSelectedTab] = useState("automation");

    return (
        <div className="space-y-8">
            <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center"
            >
                <h1 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-3">
                    Scaling Weekly Client Check-ins: From 5 to 50+ Clients
                </h1>
                <p className="text-lg lg:text-xl text-gray-600 max-w-4xl mx-auto">
                    Our systematic approach to automating and streamlining the weekly coaching process while maintaining personalized, expert guidance.
                </p>
            </motion.div>

            <Alert className="bg-blue-50 border-blue-200">
                <Bot className="h-4 w-4 text-blue-600" />
                <AlertTitle className="text-blue-800">The Scaling Challenge</AlertTitle>
                <AlertDescription className="text-blue-700">
                    Weekly 1-hour coaching calls are our core differentiator, but manually managing 50+ client calls means 50+ hours per week just on calls. This system maintains quality while reducing manual overhead by 60-70%.
                </AlertDescription>
            </Alert>

            <Tabs value={selectedTab} onValueChange={setSelectedTab} className="w-full">
                <TabsList className="grid w-full grid-cols-4">
                    <TabsTrigger value="automation">Automation Workflow</TabsTrigger>
                    <TabsTrigger value="templates">Call Templates</TabsTrigger>
                    <TabsTrigger value="scaling">Scaling Metrics</TabsTrigger>
                    <TabsTrigger value="implementation">Implementation</TabsTrigger>
                </TabsList>

                <TabsContent value="automation" className="space-y-6">
                    <div className="grid gap-6">
                        {automationWorkflow.map((phase, index) => (
                            <motion.div
                                key={index}
                                initial={{ opacity: 0, x: -20 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ delay: index * 0.1 }}
                            >
                                <Card>
                                    <CardHeader>
                                        <CardTitle className="flex items-center gap-3">
                                            <phase.icon className="w-6 h-6 text-blue-600" />
                                            {phase.phase}
                                            <Badge className="ml-auto">Saves {phase.timesSaved}</Badge>
                                        </CardTitle>
                                    </CardHeader>
                                    <CardContent>
                                        <div className="grid md:grid-cols-2 gap-6">
                                            <div>
                                                <h4 className="font-semibold mb-3 text-green-800">Automated Processes:</h4>
                                                <ul className="space-y-2">
                                                    {phase.automations.map((automation, i) => (
                                                        <li key={i} className="flex items-start gap-2 text-sm">
                                                            <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                                                            <span>{automation}</span>
                                                        </li>
                                                    ))}
                                                </ul>
                                            </div>
                                            <div>
                                                <h4 className="font-semibold mb-3 text-blue-800">Required Tools:</h4>
                                                <div className="flex flex-wrap gap-2">
                                                    {phase.tools.map((tool, i) => (
                                                        <Badge key={i} variant="outline" className="text-xs">
                                                            {tool}
                                                        </Badge>
                                                    ))}
                                                </div>
                                            </div>
                                        </div>
                                    </CardContent>
                                </Card>
                            </motion.div>
                        ))}
                    </div>
                </TabsContent>

                <TabsContent value="templates" className="space-y-6">
                    <div className="grid gap-6">
                        {weeklyCallTemplates.map((template, index) => (
                            <Card key={index}>
                                <CardHeader>
                                    <div className="flex justify-between items-start">
                                        <div>
                                            <CardTitle>{template.week}</CardTitle>
                                            <CardDescription>{template.focus}</CardDescription>
                                        </div>
                                        <Badge variant="outline">{template.week.split(' ')[1]}</Badge>
                                    </div>
                                </CardHeader>
                                <CardContent>
                                    <div className="grid md:grid-cols-2 gap-6">
                                        <div>
                                            <h4 className="font-semibold mb-3">Standard Agenda:</h4>
                                            <ul className="space-y-2 text-sm">
                                                {template.agenda.map((item, i) => (
                                                    <li key={i} className="flex items-start gap-2">
                                                        <Target className="w-4 h-4 text-blue-500 mt-0.5 flex-shrink-0" />
                                                        <span>{item}</span>
                                                    </li>
                                                ))}
                                            </ul>
                                        </div>
                                        <div>
                                            <h4 className="font-semibold mb-3">Automated Preparation:</h4>
                                            <p className="text-sm text-gray-600 bg-gray-50 p-3 rounded-md">
                                                {template.automatedPrep}
                                            </p>
                                        </div>
                                    </div>
                                </CardContent>
                            </Card>
                        ))}
                    </div>
                </TabsContent>

                <TabsContent value="scaling" className="space-y-6">
                    <Card>
                        <CardHeader>
                            <CardTitle>Time Savings at Scale</CardTitle>
                            <CardDescription>How automation reduces manual overhead as client base grows</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-4">
                                {scalingMetrics.map((metric, index) => (
                                    <div key={index} className="grid grid-cols-4 gap-4 p-4 bg-gray-50 rounded-md">
                                        <div>
                                            <div className="font-semibold text-gray-800">{metric.clients}</div>
                                        </div>
                                        <div>
                                            <div className="text-sm text-red-600">Manual: {metric.manualTime}</div>
                                        </div>
                                        <div>
                                            <div className="text-sm text-green-600">Automated: {metric.automatedTime}</div>
                                        </div>
                                        <div>
                                            <Badge className="bg-green-100 text-green-800">{metric.savings} saved</Badge>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-green-50 border-green-200">
                        <CardHeader>
                            <CardTitle className="text-green-800">The Business Impact</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="grid md:grid-cols-3 gap-4 text-sm">
                                <div>
                                    <h4 className="font-semibold text-green-800 mb-2">Revenue Capacity</h4>
                                    <p className="text-green-700">At 50 clients: $375,000 annual revenue with only 75 hours/week instead of 250</p>
                                </div>
                                <div>
                                    <h4 className="font-semibold text-green-800 mb-2">Quality Maintenance</h4>
                                    <p className="text-green-700">Standardized templates ensure consistent delivery across all clients</p>
                                </div>
                                <div>
                                    <h4 className="font-semibold text-green-800 mb-2">Team Growth</h4>
                                    <p className="text-green-700">Automated processes enable hiring additional consultants without quality loss</p>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="implementation" className="space-y-6">
                    <Card>
                        <CardHeader>
                            <CardTitle>Implementation Roadmap</CardTitle>
                            <CardDescription>Step-by-step plan to build the automated client management system</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-6">
                                <div className="grid md:grid-cols-2 gap-6">
                                    <Card className="border-blue-200 bg-blue-50/50">
                                        <CardHeader>
                                            <CardTitle className="text-blue-800">Phase 1: Foundation (Weeks 1-2)</CardTitle>
                                        </CardHeader>
                                        <CardContent className="space-y-2 text-sm">
                                            <div className="flex items-center gap-2">
                                                <CheckCircle className="w-4 h-4 text-green-500" />
                                                <span>Set up Calendly Business with custom scheduling rules</span>
                                            </div>
                                            <div className="flex items-center gap-2">
                                                <CheckCircle className="w-4 h-4 text-green-500" />
                                                <span>Configure SendGrid email automation sequences</span>
                                            </div>
                                            <div className="flex items-center gap-2">
                                                <CheckCircle className="w-4 h-4 text-green-500" />
                                                <span>Create standardized call agenda templates</span>
                                            </div>
                                            <div className="flex items-center gap-2">
                                                <CheckCircle className="w-4 h-4 text-green-500" />
                                                <span>Set up call recording and transcription</span>
                                            </div>
                                        </CardContent>
                                    </Card>

                                    <Card className="border-green-200 bg-green-50/50">
                                        <CardHeader>
                                            <CardTitle className="text-green-800">Phase 2: Integration (Weeks 3-4)</CardTitle>
                                        </CardHeader>
                                        <CardContent className="space-y-2 text-sm">
                                            <div className="flex items-center gap-2">
                                                <Clock className="w-4 h-4 text-amber-500" />
                                                <span>Build AWS Lambda functions for AI agenda generation</span>
                                            </div>
                                            <div className="flex items-center gap-2">
                                                <Clock className="w-4 h-4 text-amber-500" />
                                                <span>Integrate with existing PartnershipCommunication CRM</span>
                                            </div>
                                            <div className="flex items-center gap-2">
                                                <Clock className="w-4 h-4 text-amber-500" />
                                                <span>Create client progress tracking dashboard</span>
                                            </div>
                                            <div className="flex items-center gap-2">
                                                <Clock className="w-4 h-4 text-amber-500" />
                                                <span>Test automation with first 3-5 clients</span>
                                            </div>
                                        </CardContent>
                                    </Card>
                                </div>

                                <Alert className="bg-amber-50 border-amber-200">
                                    <Target className="h-4 w-4 text-amber-600" />
                                    <AlertTitle className="text-amber-800">Immediate Action Item</AlertTitle>
                                    <AlertDescription className="text-amber-700">
                                        Start with Phase 1 tools immediately. Even basic automation will save 15+ hours per week at just 10 clients.
                                        <div className="mt-2">
                                            <Button size="sm" className="bg-amber-600 hover:bg-amber-700 text-white">
                                                Begin Implementation Plan <ArrowRight className="w-4 h-4 ml-1" />
                                            </Button>
                                        </div>
                                    </AlertDescription>
                                </Alert>
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>
            </Tabs>
        </div>
    );
}
