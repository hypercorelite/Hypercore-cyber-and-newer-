import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Bot, Database, Zap, Shield, TrendingUp, CheckCircle, RefreshCw, Upload } from 'lucide-react';
import { motion } from "framer-motion";

import { AITrainingSession } from "@/api/entities";
import { DataProcessingAgreement } from "@/api/entities";

export default function AITrainingPipeline() {
    const [trainingSessions, setTrainingSessions] = useState([]);
    const [dataAgreements, setDataAgreements] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        loadData();
    }, []);

    const loadData = async () => {
        try {
            const [sessions, agreements] = await Promise.all([
                AITrainingSession.list('-created_date', 10),
                DataProcessingAgreement.filter({ ai_training_consent: true })
            ]);
            setTrainingSessions(sessions);
            setDataAgreements(agreements);
        } catch (error) {
            console.error('Failed to load AI training data:', error);
        } finally {
            setLoading(false);
        }
    };

    const trainingMetrics = {
        totalDataPoints: trainingSessions.reduce((sum, session) => sum + (session.data_points_collected || 0), 0),
        averageAccuracy: trainingSessions.length > 0 
            ? trainingSessions.reduce((sum, session) => sum + (session.model_accuracy_after || 0), 0) / trainingSessions.length 
            : 0,
        activeModels: ["hypercore/cmmc-assessor-v2", "hypercore/policy-generator-v1", "hypercore/gap-analyzer-v1"],
        contributingClients: dataAgreements.length
    };

    if (loading) {
        return <div className="flex items-center justify-center p-8"><RefreshCw className="w-6 h-6 animate-spin" /></div>;
    }

    return (
        <div className="space-y-8">
            <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center"
            >
                <Badge className="mb-4 bg-purple-100 text-purple-800">AI TRAINING INFRASTRUCTURE</Badge>
                <h1 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-3">
                    Continuous AI Model Training Pipeline
                </h1>
                <p className="text-lg lg:text-xl text-gray-600">
                    How we use anonymized client data to continuously improve our CMMC AI models, creating a sustainable competitive moat.
                </p>
            </motion.div>

            <Alert className="bg-blue-50 border-blue-200">
                <Bot className="h-4 w-4 text-blue-600" />
                <AlertTitle className="text-blue-800">Our AI Competitive Advantage</AlertTitle>
                <AlertDescription className="text-blue-700">
                    Every client engagement makes our AI smarter. As we help more contractors achieve CMMC compliance, our models learn from real-world implementation challenges, creating increasingly accurate gap analysis and documentation generation.
                </AlertDescription>
            </Alert>

            {/* Metrics Dashboard */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <Card className="bg-green-50 border-green-200">
                    <CardContent className="p-4">
                        <div className="flex items-center gap-3">
                            <Database className="w-8 h-8 text-green-600" />
                            <div>
                                <h3 className="font-bold text-2xl text-green-800">{trainingMetrics.totalDataPoints.toLocaleString()}</h3>
                                <p className="text-sm text-green-600">Training Data Points</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>
                
                <Card className="bg-blue-50 border-blue-200">
                    <CardContent className="p-4">
                        <div className="flex items-center gap-3">
                            <TrendingUp className="w-8 h-8 text-blue-600" />
                            <div>
                                <h3 className="font-bold text-2xl text-blue-800">{trainingMetrics.averageAccuracy.toFixed(1)}%</h3>
                                <p className="text-sm text-blue-600">Average Model Accuracy</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>
                
                <Card className="bg-purple-50 border-purple-200">
                    <CardContent className="p-4">
                        <div className="flex items-center gap-3">
                            <Bot className="w-8 h-8 text-purple-600" />
                            <div>
                                <h3 className="font-bold text-2xl text-purple-800">{trainingMetrics.activeModels.length}</h3>
                                <p className="text-sm text-purple-600">Active AI Models</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>
                
                <Card className="bg-orange-50 border-orange-200">
                    <CardContent className="p-4">
                        <div className="flex items-center gap-3">
                            <Shield className="w-8 h-8 text-orange-600" />
                            <div>
                                <h3 className="font-bold text-2xl text-orange-800">{trainingMetrics.contributingClients}</h3>
                                <p className="text-sm text-orange-600">Contributing Clients</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </div>

            {/* Training Sessions */}
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                        <Zap className="w-6 h-6" />
                        Recent Training Sessions
                    </CardTitle>
                    <CardDescription>Our AI models are continuously learning from real CMMC implementation data.</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="space-y-4">
                        {trainingSessions.slice(0, 5).map((session) => (
                            <div key={session.id} className="border rounded-lg p-4">
                                <div className="flex justify-between items-start mb-2">
                                    <h4 className="font-semibold">{session.session_name}</h4>
                                    <Badge className={session.status === 'complete' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}>
                                        {session.status}
                                    </Badge>
                                </div>
                                <p className="text-sm text-gray-600 mb-3">Model: {session.model_name}</p>
                                
                                {session.model_accuracy_before && session.model_accuracy_after && (
                                    <div className="space-y-2">
                                        <div className="flex justify-between text-sm">
                                            <span>Accuracy Improvement</span>
                                            <span className="font-medium text-green-600">
                                                {session.model_accuracy_before}% → {session.model_accuracy_after}%
                                            </span>
                                        </div>
                                        <Progress value={session.model_accuracy_after} className="h-2" />
                                    </div>
                                )}
                                
                                <div className="mt-3 text-xs text-gray-500">
                                    Data Points: {session.data_points_collected?.toLocaleString() || 'N/A'} | 
                                    Anonymization: {session.anonymization_method || 'differential_privacy'}
                                </div>
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>

            {/* Data Processing Agreements */}
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                        <Shield className="w-6 h-6" />
                        Ethical AI Training: Client Data Contributions
                    </CardTitle>
                    <CardDescription>Clients who consent to anonymized data sharing help improve our AI for the entire Defense Industrial Base.</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="grid md:grid-cols-2 gap-4">
                        {dataAgreements.slice(0, 6).map((agreement) => (
                            <div key={agreement.id} className="border rounded-lg p-3">
                                <div className="flex justify-between items-center">
                                    <h4 className="font-medium">{agreement.contractor_name}</h4>
                                    <Badge variant="outline">{agreement.data_classification}</Badge>
                                </div>
                                <p className="text-sm text-gray-600 mt-1">
                                    Encryption: {agreement.encryption_level} | 
                                    Retention: {agreement.data_retention_days} days
                                </p>
                                <div className="mt-2 text-xs text-green-600 flex items-center gap-1">
                                    <CheckCircle className="w-3 h-3" />
                                    Consented to AI training contribution
                                </div>
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>

            <Alert className="bg-yellow-50 border-yellow-200">
                <Upload className="h-4 w-4 text-yellow-700" />
                <AlertTitle className="text-yellow-800">Hugging Face Model Repository</AlertTitle>
                <AlertDescription className="text-yellow-700">
                    All trained models are hosted on Hugging Face Hub under the "hypercore" organization. This open approach ensures transparency while maintaining our competitive advantage through continuous data collection and model improvement.
                    <div className="mt-2 space-y-1 text-sm">
                        {trainingMetrics.activeModels.map((model, index) => (
                            <div key={index} className="font-mono text-xs">🤗 {model}</div>
                        ))}
                    </div>
                </AlertDescription>
            </Alert>
        </div>
    );
}