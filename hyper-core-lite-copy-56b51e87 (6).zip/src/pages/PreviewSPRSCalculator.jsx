
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Shield, Eye, UserPlus, ArrowRight, Calculator, CheckCircle, X } from 'lucide-react';
import { Checkbox } from "@/components/ui/checkbox";

// Sample SPRS controls for preview
const sampleControls = [
    {
        id: '3.1.1',
        description: 'Limit system access to authorized users',
        points: 5,
        implemented: true,
        alternativeMeasures: false
    },
    {
        id: '3.3.1', 
        description: 'Create and retain system audit logs',
        points: 3,
        implemented: false,
        alternativeMeasures: true
    },
    {
        id: '3.5.1',
        description: 'Identify system users and processes',
        points: 1,
        implemented: true,
        alternativeMeasures: false
    },
    {
        id: '3.13.11',
        description: 'Employ FIPS-validated cryptography',
        points: 5,
        implemented: false,
        alternativeMeasures: false
    }
];

export default function PreviewSPRSCalculator() {
    const [controls, setControls] = useState(sampleControls);

    useEffect(() => {
        document.title = "Preview CMMC SPRS Score Calculator | DoD Compliance | HyperCore";
        const metaDesc = document.querySelector('meta[name="description"]');
        if (metaDesc) {
            metaDesc.setAttribute('content', 'Instantly preview our SPRS Score Calculator for NIST 800-171. See how the tool works with sample data—no registration required. Perfect for government evaluation.');
        }
    }, []);
    
    const calculateScore = () => {
        let currentScore = 0;
        const totalPossible = controls.reduce((sum, control) => sum + control.points, 0);
        
        controls.forEach(control => {
            if (control.implemented || control.alternativeMeasures) {
                currentScore += control.points;
            }
        });

        return {
            current: currentScore,
            total: totalPossible,
            percentage: Math.round((currentScore / totalPossible) * 100)
        };
    };

    const score = calculateScore();

    const updateControl = (controlId, field, value) => {
        setControls(prev => prev.map(control => 
            control.id === controlId 
                ? { ...control, [field]: value }
                : control
        ));
    };

    return (
        <div className="min-h-screen bg-gray-50 py-8">
            <div className="container mx-auto px-4 max-w-6xl">
                {/* Preview Banner */}
                <Alert className="mb-6 bg-blue-50 border-blue-200">
                    <Eye className="h-4 w-4 text-blue-600" />
                    <AlertTitle className="text-blue-800">Preview Mode - Government Evaluation</AlertTitle>
                    <AlertDescription className="text-blue-700">
                        This is a preview of the SPRS Calculator with sample controls. 
                        <Link to={createPageUrl('Register')} className="font-semibold underline ml-1 hover:text-blue-600">
                            Sign up for free access
                        </Link> to calculate your actual SPRS score.
                    </AlertDescription>
                </Alert>

                <div className="flex justify-between items-center mb-6">
                    <div>
                        <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
                            <Calculator className="w-8 h-8 text-blue-600" />
                            SPRS Score Calculator
                        </h1>
                        <p className="text-gray-600">Calculate your NIST 800-171 assessment score for DoD contracts</p>
                    </div>
                    <Button asChild size="lg" className="bg-blue-600 hover:bg-blue-700">
                        <Link to={createPageUrl('Register')}>
                            <UserPlus className="w-4 h-4 mr-2" />
                            Get Full Access
                        </Link>
                    </Button>
                </div>

                <div className="grid lg:grid-cols-3 gap-6">
                    {/* Score Summary */}
                    <div>
                        <Card className="sticky top-6">
                            <CardHeader>
                                <CardTitle>Current SPRS Score</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                <div className="text-center">
                                    <div className="text-4xl font-bold text-blue-600">{score.current}</div>
                                    <div className="text-gray-500">out of {score.total} points</div>
                                    <div className="text-2xl font-semibold text-gray-700">{score.percentage}%</div>
                                </div>
                                
                                <Progress value={score.percentage} className="w-full" />
                                
                                <div className="space-y-2 text-sm">
                                    <div className="flex justify-between">
                                        <span>Implemented:</span>
                                        <span className="font-medium">
                                            {controls.filter(c => c.implemented).length}
                                        </span>
                                    </div>
                                    <div className="flex justify-between">
                                        <span>Alternative Measures:</span>
                                        <span className="font-medium">
                                            {controls.filter(c => c.alternativeMeasures && !c.implemented).length}
                                        </span>
                                    </div>
                                    <div className="flex justify-between">
                                        <span>Not Implemented:</span>
                                        <span className="font-medium">
                                            {controls.filter(c => !c.implemented && !c.alternativeMeasures).length}
                                        </span>
                                    </div>
                                </div>

                                <Alert className="bg-yellow-50 border-yellow-200">
                                    <Shield className="h-4 w-4 text-yellow-600" />
                                    <AlertDescription className="text-yellow-700 text-sm">
                                        The full version includes all 110 NIST controls and generates official SPRS documentation.
                                    </AlertDescription>
                                </Alert>
                            </CardContent>
                        </Card>
                    </div>

                    {/* Controls Assessment */}
                    <div className="lg:col-span-2">
                        <Card>
                            <CardHeader>
                                <CardTitle>NIST 800-171 Controls Assessment (Sample)</CardTitle>
                                <CardDescription>Mark controls as implemented or having alternative measures</CardDescription>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-4">
                                    {controls.map((control) => (
                                        <div key={control.id} className="border rounded-lg p-4 space-y-3">
                                            <div className="flex justify-between items-start">
                                                <div className="flex-1">
                                                    <h3 className="font-medium">NIST 800-171 {control.id}</h3>
                                                    <p className="text-gray-600 text-sm">{control.description}</p>
                                                </div>
                                                <Badge variant="outline" className="ml-4">
                                                    {control.points} {control.points === 1 ? 'point' : 'points'}
                                                </Badge>
                                            </div>
                                            
                                            <div className="flex items-center gap-6">
                                                <div className="flex items-center space-x-2">
                                                    <Checkbox 
                                                        id={`implemented-${control.id}`}
                                                        checked={control.implemented}
                                                        onCheckedChange={(checked) => updateControl(control.id, 'implemented', checked)}
                                                    />
                                                    <label htmlFor={`implemented-${control.id}`} className="text-sm">
                                                        Implemented
                                                    </label>
                                                </div>
                                                
                                                <div className="flex items-center space-x-2">
                                                    <Checkbox 
                                                        id={`alternative-${control.id}`}
                                                        checked={control.alternativeMeasures}
                                                        onCheckedChange={(checked) => updateControl(control.id, 'alternativeMeasures', checked)}
                                                        disabled={control.implemented}
                                                    />
                                                    <label htmlFor={`alternative-${control.id}`} className="text-sm">
                                                        Alternative Implementation
                                                    </label>
                                                </div>

                                                <div className="ml-auto">
                                                    {control.implemented ? (
                                                        <CheckCircle className="w-5 h-5 text-green-500" />
                                                    ) : control.alternativeMeasures ? (
                                                        <Shield className="w-5 h-5 text-yellow-500" />
                                                    ) : (
                                                        <X className="w-5 h-5 text-red-500" />
                                                    )}
                                                </div>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>
                    </div>
                </div>

                {/* CTA Section */}
                <Card className="mt-8 bg-gradient-to-r from-green-600 to-teal-700 text-white">
                    <CardContent className="text-center py-8">
                        <h2 className="text-2xl font-bold mb-4">Ready to Calculate Your Real SPRS Score?</h2>
                        <p className="text-green-100 mb-6">
                            Assess all 110 NIST controls, generate official documentation, and prepare for DoD assessments.
                        </p>
                        <Button asChild size="lg" variant="secondary">
                            <Link to={createPageUrl('Register')}>
                                Start Free Assessment <ArrowRight className="w-4 h-4 ml-2" />
                            </Link>
                        </Button>
                    </CardContent>
                </Card>

                <div className="text-center mt-8">
                    <Card className="bg-green-50 border-green-200">
                        <CardContent className="p-6">
                            <h3 className="text-xl font-semibold text-green-900 mb-2">Calculate Your Real SPRS Score</h3>
                            <p className="text-green-700 mb-4">Use the full calculator with your actual compliance status</p>
                            <Button asChild className="bg-green-600 hover:bg-green-700">
                                <Link to={createPageUrl('SPRSScoreCalculator')}>
                                    Go to Full SPRS Calculator
                                </Link>
                            </Button>
                        </CardContent>
                    </Card>
                </div>
            </div>
        </div>
    );
}
