import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { ComplianceFramework } from "@/api/entities";
import { ComplianceTask } from "@/api/entities";
import { 
    Shield, 
    CheckCircle, 
    AlertTriangle, 
    Clock,
    FileText,
    Users,
    Settings,
    Database,
    Lock,
    Eye,
    Zap
} from "lucide-react";
import { motion } from "framer-motion";

const CMMC_DOMAINS = [
    { name: "Access Control", icon: Lock, color: "text-blue-600" },
    { name: "Asset Management", icon: Database, color: "text-green-600" },
    { name: "Awareness and Training", icon: Users, color: "text-purple-600" },
    { name: "Audit and Accountability", icon: Eye, color: "text-orange-600" },
    { name: "Configuration Management", icon: Settings, color: "text-gray-600" },
    { name: "Identification and Authentication", icon: Shield, color: "text-red-600" },
    { name: "Incident Response", icon: Zap, color: "text-yellow-600" },
    { name: "Maintenance", icon: Settings, color: "text-indigo-600" },
    { name: "Media Protection", icon: Shield, color: "text-pink-600" },
    { name: "Personnel Security", icon: Users, color: "text-teal-600" },
    { name: "Physical Protection", icon: Lock, color: "text-amber-600" },
    { name: "Risk Management", icon: AlertTriangle, color: "text-red-500" },
    { name: "Security Assessment", icon: CheckCircle, color: "text-green-500" },
    { name: "Situational Awareness", icon: Eye, color: "text-blue-500" },
    { name: "System and Communications Protection", icon: Shield, color: "text-purple-500" },
    { name: "System and Information Integrity", icon: CheckCircle, color: "text-emerald-600" },
    { name: "Cybersecurity Governance", icon: FileText, color: "text-slate-600" }
];

export default function CMMCReadiness() {
    const [cmmcTasks, setCmmcTasks] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        loadCMMCTasks();
    }, []);

    const loadCMMCTasks = async () => {
        try {
            const frameworks = await ComplianceFramework.filter({ framework_name: "CMMC" });
            if (frameworks.length > 0) {
                const tasks = await ComplianceTask.filter({ framework_id: frameworks[0].id });
                setCmmcTasks(tasks);
            }
        } catch (error) {
            console.error('Failed to load CMMC tasks:', error);
        } finally {
            setLoading(false);
        }
    };

    const getDomainStats = (domainName) => {
        const domainTasks = cmmcTasks.filter(task => task.cmmc_domain === domainName);
        const completed = domainTasks.filter(task => task.status === 'completed').length;
        const inProgress = domainTasks.filter(task => task.status === 'in_progress' || task.status === 'human_review_required').length;
        const pending = domainTasks.filter(task => task.status === 'pending').length;
        const total = domainTasks.length;
        const progress = total > 0 ? (completed / total) * 100 : 0;
        
        return { completed, inProgress, pending, total, progress };
    };

    const overallStats = {
        completed: cmmcTasks.filter(t => t.status === 'completed').length,
        inProgress: cmmcTasks.filter(t => ['in_progress', 'human_review_required', 'ai_completed'].includes(t.status)).length,
        pending: cmmcTasks.filter(t => t.status === 'pending').length,
        total: cmmcTasks.length
    };

    const overallProgress = overallStats.total > 0 ? (overallStats.completed / overallStats.total) * 100 : 0;

    return (
        <div className="min-h-screen bg-gradient-to-br from-gray-50 to-indigo-50 p-6">
            <div className="max-w-7xl mx-auto">
                <motion.div
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="mb-8"
                >
                    <h1 className="text-4xl font-bold text-gray-900 mb-2 flex items-center gap-3">
                        <Shield className="w-10 h-10 text-indigo-600" />
                        CMMC Readiness Assessment
                    </h1>
                    <p className="text-lg text-gray-600">
                        Track progress across all 17 CMMC domains for Level 2 certification
                    </p>
                </motion.div>

                {/* Overall Progress */}
                <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.2 }}
                    className="mb-8"
                >
                    <Card className="bg-gradient-to-r from-indigo-500 to-purple-600 text-white">
                        <CardContent className="p-8">
                            <div className="flex items-center justify-between mb-4">
                                <h2 className="text-2xl font-bold">CMMC Level 2 Readiness</h2>
                                <Badge className="bg-white text-indigo-600 text-lg px-4 py-2">
                                    {Math.round(overallProgress)}% Complete
                                </Badge>
                            </div>
                            <Progress value={overallProgress} className="h-4 mb-4 bg-white/20" />
                            <div className="grid grid-cols-4 gap-4 text-center">
                                <div>
                                    <div className="text-3xl font-bold">{overallStats.completed}</div>
                                    <div className="text-indigo-100">Completed</div>
                                </div>
                                <div>
                                    <div className="text-3xl font-bold">{overallStats.inProgress}</div>
                                    <div className="text-indigo-100">In Progress</div>
                                </div>
                                <div>
                                    <div className="text-3xl font-bold">{overallStats.pending}</div>
                                    <div className="text-indigo-100">Pending</div>
                                </div>
                                <div>
                                    <div className="text-3xl font-bold">{overallStats.total}</div>
                                    <div className="text-indigo-100">Total Controls</div>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </motion.div>

                {/* Domain Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {CMMC_DOMAINS.map((domain, index) => {
                        const stats = getDomainStats(domain.name);
                        const IconComponent = domain.icon;
                        
                        return (
                            <motion.div
                                key={domain.name}
                                initial={{ opacity: 0, y: 20 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: index * 0.05 }}
                            >
                                <Card className="hover:shadow-lg transition-shadow">
                                    <CardHeader className="pb-3">
                                        <div className="flex items-center justify-between">
                                            <div className="flex items-center gap-2">
                                                <IconComponent className={`w-5 h-5 ${domain.color}`} />
                                                <CardTitle className="text-sm">{domain.name}</CardTitle>
                                            </div>
                                            <Badge variant={stats.progress === 100 ? "default" : stats.progress > 0 ? "secondary" : "outline"}>
                                                {Math.round(stats.progress)}%
                                            </Badge>
                                        </div>
                                    </CardHeader>
                                    <CardContent>
                                        <Progress value={stats.progress} className="mb-3" />
                                        <div className="grid grid-cols-3 gap-2 text-xs text-center">
                                            <div>
                                                <div className="font-semibold text-green-600">{stats.completed}</div>
                                                <div className="text-gray-500">Done</div>
                                            </div>
                                            <div>
                                                <div className="font-semibold text-yellow-600">{stats.inProgress}</div>
                                                <div className="text-gray-500">Active</div>
                                            </div>
                                            <div>
                                                <div className="font-semibold text-gray-600">{stats.pending}</div>
                                                <div className="text-gray-500">Todo</div>
                                            </div>
                                        </div>
                                    </CardContent>
                                </Card>
                            </motion.div>
                        );
                    })}
                </div>

                {/* Readiness Assessment */}
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.8 }}
                    className="mt-8"
                >
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <CheckCircle className="w-5 h-5 text-green-600" />
                                3PAO Assessment Readiness
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                                <div className="text-center">
                                    <div className={`text-4xl font-bold ${overallProgress >= 80 ? 'text-green-600' : overallProgress >= 50 ? 'text-yellow-600' : 'text-red-600'}`}>
                                        {overallProgress >= 80 ? 'READY' : overallProgress >= 50 ? 'PARTIAL' : 'NOT READY'}
                                    </div>
                                    <div className="text-sm text-gray-600">Assessment Readiness</div>
                                </div>
                                <div className="text-center">
                                    <div className="text-2xl font-bold text-blue-600">
                                        {Math.max(0, Math.round((90 - (overallProgress * 0.9)) * 30))} days
                                    </div>
                                    <div className="text-sm text-gray-600">Estimated Time to Ready</div>
                                </div>
                                <div className="text-center">
                                    <div className="text-2xl font-bold text-purple-600">
                                        ${Math.round(50000 + (overallProgress * 1000))}
                                    </div>
                                    <div className="text-sm text-gray-600">Est. Contract Value Unlocked</div>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </motion.div>
            </div>
        </div>
    );
}