import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { CheckCircle, Shield, Zap, DollarSign, Target, FileText, Clock, Users, BookOpen } from 'lucide-react';
import { motion } from "framer-motion";

const marketingPillars = [
    {
        title: "Dual-Platform Narrative",
        icon: Shield,
        points: [
            "Market as the solution to multi-cloud complexity, not a single-cloud tool.",
            "Messaging: 'Your CMMC compliance, no matter your cloud.'",
            "Showcase a 'single pane of glass' for unified compliance across AWS and Microsoft.",
            "Address the real-world subcontractor journey: a mix of M365 and AWS."
        ]
    },
    {
        title: "Educational Leadership",
        icon: BookOpen,
        points: [
            "Position HyperCore as an educational partner for subcontractors who lack deep CMMC expertise.",
            "Content: Webinars & whitepapers explaining how to orchestrate controls across clouds.",
            "Success Stories: Publish case studies of subcontractors passing audits with our platform.",
            "List on AWS Marketplace, highlighting the dual-cloud capability."
        ]
    },
    {
        title: "AI-Powered Efficiency",
        icon: Zap,
        points: [
            "Focus on how AI reduces cost and complexity for resource-strapped subcontractors.",
            "Automated Evidence Collection: Eliminate manual work by pulling data from both Microsoft and AWS services.",
            "Automated Document Generation: Simplify SSP and POA&M creation.",
            "Real-Time Readiness: Provide a continuous view of compliance posture."
        ]
    }
];

const pricingTiers = [
    {
        level: "Level 1: FCI Foundational",
        price: "$299/mo",
        target: "Subcontractors handling only Federal Contract Information (FCI)",
        features: [
            "Automated evidence collection for basic cyber hygiene",
            "SSP & POA&M document templates",
            "Real-time compliance dashboard",
            "Covers up to 15 controls"
        ]
    },
    {
        level: "Level 2: CUI Advanced",
        price: "$799/mo+",
        target: "Subcontractors handling Controlled Unclassified Information (CUI)",
        features: [
            "All Level 1 features",
            "Full evidence collection for all 110 CMMC controls",
            "Integrations with AWS Config & Microsoft Purview",
            "Advanced reporting for auditors"
        ]
    },
    {
        level: "Add-On: Professional Services",
        price: "Custom Quote",
        target: "Clients needing hands-on support",
        features: [
            "Readiness assessments and gap analysis",
            "Technical remediation support",
            "C3PAO audit preparation",
            "Billed hourly or as a project package"
        ]
    }
];

const monetizationStrategy = {
    title: "Monetize the Supply Chain: The Prime Contractor Upsell",
    description: "Prime contractors are a powerful sales channel. They are motivated to ensure their supply chain is compliant.",
    offerings: [
        {
            name: "Managed Subcontractor Compliance Portal",
            details: "A premium service for Primes to monitor their subcontractors' CMMC status through a single dashboard."
        },
        {
            name: "Subcontractor Referral Bundle",
            details: "Offer discounted packages to subcontractors referred by an existing Prime partner, creating a powerful incentive."
        }
    ]
};

export default function ComplianceMarketStrategy() {
    return (
        <div className="min-h-screen bg-gray-50 p-6">
            <div className="max-w-7xl mx-auto">
                <motion.div
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="text-center mb-8"
                >
                    <h1 className="text-4xl font-bold text-gray-900 mb-3">
                        Go-to-Market Strategy: CMMC for the Multi-Cloud Subcontractor
                    </h1>
                    <p className="text-xl text-gray-600">
                        A unified plan for marketing, pricing, and service delivery.
                    </p>
                </motion.div>

                <Alert className="mb-8 bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
                    <Target className="h-4 w-4 text-blue-600" />
                    <AlertTitle className="text-blue-800">The Winning Formula</AlertTitle>
                    <AlertDescription className="text-blue-700">
                        Combine a **platform-agnostic message** with a **value-based pricing model** to capture the underserved defense subcontractor market. We solve their real-world, multi-cloud problem at a price they can afford.
                    </AlertDescription>
                </Alert>

                <Tabs defaultValue="marketing" className="w-full">
                    <TabsList className="grid w-full grid-cols-3">
                        <TabsTrigger value="marketing">Marketing Strategy</TabsTrigger>
                        <TabsTrigger value="pricing">Pricing & Monetization</TabsTrigger>
                        <TabsTrigger value="delivery">Deliverables & Timelines</TabsTrigger>
                    </TabsList>
                    
                    <TabsContent value="marketing" className="pt-6">
                        <div className="grid md:grid-cols-3 gap-6">
                            {marketingPillars.map((pillar, index) => {
                                const Icon = pillar.icon;
                                return (
                                <motion.div key={pillar.title} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.1 }}>
                                    <Card className="h-full">
                                        <CardHeader>
                                            <CardTitle className="flex items-center gap-2"><Icon className="w-6 h-6" /> {pillar.title}</CardTitle>
                                        </CardHeader>
                                        <CardContent>
                                            <ul className="space-y-3">
                                                {pillar.points.map((point, pIndex) => (
                                                    <li key={pIndex} className="flex items-start gap-2 text-sm">
                                                        <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                                                        <span>{point}</span>
                                                    </li>
                                                ))}
                                            </ul>
                                        </CardContent>
                                    </Card>
                                </motion.div>
                                );
                            })}
                        </div>
                    </TabsContent>

                    <TabsContent value="pricing" className="pt-6">
                        <div className="space-y-6">
                            <Card>
                                <CardHeader>
                                    <CardTitle>Tiered, Value-Based Pricing</CardTitle>
                                    <CardDescription>Match the pricing to the subcontractor's specific compliance need (FCI vs. CUI).</CardDescription>
                                </CardHeader>
                                <CardContent className="grid md:grid-cols-3 gap-6">
                                    {pricingTiers.map(tier => (
                                        <Card key={tier.level} className={tier.level.includes('CUI') ? 'border-blue-400' : ''}>
                                            <CardHeader>
                                                <CardTitle>{tier.level}</CardTitle>
                                                <CardDescription>{tier.target}</CardDescription>
                                            </CardHeader>
                                            <CardContent>
                                                <p className="text-3xl font-bold mb-4">{tier.price}</p>
                                                <ul className="space-y-2 text-sm">
                                                    {tier.features.map((feature, fIndex) => (
                                                         <li key={fIndex} className="flex items-start gap-2">
                                                            <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                                                            <span>{feature}</span>
                                                        </li>
                                                    ))}
                                                </ul>
                                            </CardContent>
                                        </Card>
                                    ))}
                                </CardContent>
                            </Card>

                            <Card className="bg-purple-50 border-purple-200">
                                <CardHeader>
                                    <CardTitle className="text-purple-800">{monetizationStrategy.title}</CardTitle>
                                    <CardDescription>{monetizationStrategy.description}</CardDescription>
                                </CardHeader>
                                <CardContent className="grid md:grid-cols-2 gap-4">
                                    {monetizationStrategy.offerings.map(offering => (
                                        <div key={offering.name} className="p-4 bg-white rounded-lg border">
                                            <h4 className="font-semibold text-purple-700">{offering.name}</h4>
                                            <p className="text-sm text-gray-600">{offering.details}</p>
                                        </div>
                                    ))}
                                </CardContent>
                            </Card>
                        </div>
                    </TabsContent>

                    <TabsContent value="delivery" className="pt-6">
                         <div className="grid md:grid-cols-2 gap-6">
                            <Card>
                                <CardHeader>
                                    <CardTitle>Standard Deliverables</CardTitle>
                                    <CardDescription>The core automated outputs of the platform.</CardDescription>
                                </CardHeader>
                                <CardContent className="space-y-2">
                                    <div className="flex items-center gap-2"><FileText className="w-4 h-4 text-blue-500"/>Automated SSP & POA&M Reports</div>
                                    <div className="flex items-center gap-2"><Shield className="w-4 h-4 text-blue-500"/>Audit-Ready Evidence Library</div>
                                    <div className="flex items-center gap-2"><Zap className="w-4 h-4 text-blue-500"/>Real-Time Compliance Dashboard</div>
                                </CardContent>
                            </Card>
                             <Card>
                                <CardHeader>
                                    <CardTitle>Realistic Timelines</CardTitle>
                                    <CardDescription>Setting clear expectations with clients.</CardDescription>
                                </CardHeader>
                                <CardContent className="space-y-2">
                                    <div className="flex items-center gap-2"><Clock className="w-4 h-4 text-blue-500"/>**3-6 Months:** Readiness Phase (accelerated by AI)</div>
                                    <div className="flex items-center gap-2"><Clock className="w-4 h-4 text-blue-500"/>**9-15 Months:** Full Cycle including C3PAO wait times</div>
                                    <div className="flex items-center gap-2"><Clock className="w-4 h-4 text-blue-500"/>**3 Years:** Simplified recertification with continuous monitoring</div>
                                </CardContent>
                            </Card>
                             <div className="md:col-span-2">
                                <Alert variant="destructive">
                                    <Shield className="h-4 w-4" />
                                    <AlertTitle>Guarantees & Remediation Policy</AlertTitle>
                                    <AlertDescription>
                                        <ul className="list-disc pl-5 mt-2">
                                            <li>**No Guarantee of Certification:** We explicitly state that our platform prepares clients for an audit but cannot guarantee certification, which is determined by the C3PAO.</li>
                                            <li>**Automated Remediation Tracking:** The platform provides a clear, auditable trail of all remediation efforts against POA&M items.</li>
                                            <li>**Transparent Remediation Pricing:** All hands-on remediation support is billed separately as a professional service, preventing sticker shock and setting clear expectations.</li>
                                        </ul>
                                    </AlertDescription>
                                </Alert>
                            </div>
                        </div>
                    </TabsContent>
                </Tabs>
            </div>
        </div>
    );
}