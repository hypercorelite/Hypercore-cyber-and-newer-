import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { CheckCircle, Clock, DollarSign, Gift, ArrowRight } from 'lucide-react';
import DisclaimerBanner from '../components/legal/DisclaimerBanner';

export default function BetaExpiration() {
    return (
        <div className="bg-gray-50 py-12 md:py-20">
            <div className="container mx-auto px-4 max-w-4xl">
                <div className="text-center mb-12">
                    <h1 className="text-4xl md:text-5xl font-extrabold text-gray-900 mb-4">
                        What Happens After December 5th, 2025?
                    </h1>
                    <p className="text-xl text-gray-600">
                        Our commitment to transparency and value continues. Here’s what to expect when the free beta period ends.
                    </p>
                </div>

                <Card className="mb-8 shadow-lg">
                    <CardHeader>
                        <CardTitle className="text-2xl">Your Documents are Yours to Keep, Forever.</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="flex items-start gap-4">
                            <Gift className="w-10 h-10 text-green-600 flex-shrink-0 mt-1" />
                            <div>
                                <p className="text-lg text-gray-700">
                                    Any and all documents you generate during the free beta period—including your System Security Plan (SSP), policies, and readiness reports—are yours to download and keep, at no charge, regardless of whether you choose to subscribe.
                                </p>
                            </div>
                        </div>
                    </CardContent>
                </Card>

                <Card className="mb-8 shadow-lg">
                    <CardHeader>
                        <CardTitle className="text-2xl">Transition to a Low-Cost Subscription</CardTitle>
                        <CardDescription>For continued access to the platform for updates and new features.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                        <div className="flex items-start gap-4">
                            <DollarSign className="w-10 h-10 text-blue-600 flex-shrink-0 mt-1" />
                            <div>
                                <h4 className="font-semibold text-lg">Affordable Monthly Subscription</h4>
                                <p className="text-gray-700">
                                    To continue using the HyperCore AI platform for ongoing compliance monitoring, document updates, and new feature releases after December 5th, we will offer a low-cost monthly subscription.
                                </p>
                            </div>
                        </div>
                         <div className="flex items-start gap-4">
                            <Clock className="w-10 h-10 text-purple-600 flex-shrink-0 mt-1" />
                            <div>
                                <h4 className="font-semibold text-lg">Why a Subscription?</h4>
                                <p className="text-gray-700">
                                    CMMC compliance is not a one-time event. It requires continuous monitoring and regular updates. A subscription ensures your documentation stays current with evolving threats and regulatory changes, and gives you access to our ever-improving AI tools.
                                </p>
                            </div>
                        </div>
                        <Alert className="bg-green-50 border-green-200">
                            <AlertTitle className="text-green-800 font-bold">Preferential Pricing for Beta Users</AlertTitle>
                            <AlertDescription className="text-green-700">
                                As a thank you for your contribution to our platform's development, all free beta users will receive a significant discount on our standard subscription rates. We will announce pricing well in advance of the December 5th transition.
                            </AlertDescription>
                        </Alert>
                    </CardContent>
                </Card>

                <div className="text-center mt-12">
                    <p className="text-lg text-gray-700 mb-6">Ready to get your compliance documents for free now?</p>
                    <Button asChild size="lg" className="bg-blue-600 hover:bg-blue-700">
                        <Link to={createPageUrl('PartnershipTrial')}>
                            Start Your Free Trial <ArrowRight className="w-4 h-4 ml-2" />
                        </Link>
                    </Button>
                </div>
                 <div className="mt-12">
                    <DisclaimerBanner />
                </div>
            </div>
        </div>
    );
}