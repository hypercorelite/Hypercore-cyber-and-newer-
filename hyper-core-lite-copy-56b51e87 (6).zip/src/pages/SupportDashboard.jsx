import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { SupportTicket } from "@/api/entities";
import { KnowledgeBaseArticle } from "@/api/entities";
import { Bot, MessageSquare, Users, Clock, AlertCircle, Star } from "lucide-react";
import { motion } from "framer-motion";
import { toast } from "sonner";
import { agentSDK } from "@/agents";

export default function SupportDashboard() {
    const [tickets, setTickets] = useState([]);
    const [knowledgeBase, setKnowledgeBase] = useState([]);
    const [selectedTicket, setSelectedTicket] = useState(null);
    const [newResponse, setNewResponse] = useState('');
    const [loading, setLoading] = useState(true);
    const [agentConversations, setAgentConversations] = useState([]);

    useEffect(() => {
        loadData();
    }, []);

    const loadData = async () => {
        setLoading(true);
        try {
            const [ticketData, kbData] = await Promise.all([
                SupportTicket.list('-created_date'),
                KnowledgeBaseArticle.list()
            ]);
            setTickets(ticketData);
            setKnowledgeBase(kbData);
            
            try {
                const conversations = await agentSDK.listConversations({ agent_name: "support_agent" });
                setAgentConversations(conversations);
            } catch (error) {
                console.log("AI agent conversations not available yet");
            }
        } catch (error) {
            console.error("Failed to load support data:", error);
            toast.error("Failed to load support dashboard");
        } finally {
            setLoading(false);
        }
    };

    const handleTicketResponse = async () => {
        if (!selectedTicket || !newResponse.trim()) {
            toast.error("Please enter a response message");
            return;
        }

        try {
            const updatedConversation = [
                ...(selectedTicket.conversation || []),
                { sender: "support", message: newResponse, timestamp: new Date().toISOString() }
            ];

            await SupportTicket.update(selectedTicket.id, {
                conversation: updatedConversation,
                status: "awaiting_reply"
            });

            toast.success("Response sent to client");
            setNewResponse('');
            setSelectedTicket(null);
            loadData();
        } catch (error) {
            console.error("Failed to send response:", error);
            toast.error("Failed to send response");
        }
    };
    
    const getStatusColor = (status) => ({
        'new': 'bg-red-100 text-red-800', 'in_progress': 'bg-yellow-100 text-yellow-800',
        'awaiting_reply': 'bg-blue-100 text-blue-800', 'resolved': 'bg-green-100 text-green-800',
        'closed': 'bg-gray-100 text-gray-800'
    }[status] || 'bg-gray-100 text-gray-800');

    const getPriorityColor = (priority) => ({
        'low': 'bg-gray-100 text-gray-800', 'medium': 'bg-yellow-100 text-yellow-800',
        'high': 'bg-orange-100 text-orange-800', 'urgent': 'bg-red-100 text-red-800'
    }[priority] || 'bg-gray-100 text-gray-800');
    
    const sortedTickets = [...tickets].sort((a, b) => {
        if (a.source === 'expert_request' && b.source !== 'expert_request') return -1;
        if (b.source === 'expert_request' && a.source !== 'expert_request') return 1;
        if (a.priority === 'urgent' && b.priority !== 'urgent') return -1;
        if (b.priority === 'urgent' && a.priority !== 'urgent') return 1;
        return new Date(b.created_date) - new Date(a.created_date);
    });

    if (loading) {
        return <div className="flex justify-center items-center h-64">Loading support dashboard...</div>;
    }

    return (
        <div className="space-y-6">
            <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="flex justify-between items-center">
                <div>
                    <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
                        <Users className="w-8 h-8 text-blue-600" /> Customer Support Dashboard
                    </h1>
                    <p className="text-gray-600 mt-2">Manage support tickets and AI agent interactions</p>
                </div>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                {/* Stat Cards */}
                <Card><CardContent className="p-4"><div className="flex items-center gap-3"><AlertCircle className="w-6 h-6 text-red-500" /><div><p className="text-2xl font-bold">{tickets.filter(t => t.status === 'new').length}</p><p className="text-sm text-gray-600">New Tickets</p></div></div></CardContent></Card>
                <Card><CardContent className="p-4"><div className="flex items-center gap-3"><Clock className="w-6 h-6 text-yellow-500" /><div><p className="text-2xl font-bold">{tickets.filter(t => t.status === 'in_progress').length}</p><p className="text-sm text-gray-600">In Progress</p></div></div></CardContent></Card>
                <Card><CardContent className="p-4"><div className="flex items-center gap-3"><Bot className="w-6 h-6 text-purple-500" /><div><p className="text-2xl font-bold">{agentConversations.length}</p><p className="text-sm text-gray-600">AI Conversations</p></div></div></CardContent></Card>
                <Card><CardContent className="p-4"><div className="flex items-center gap-3"><MessageSquare className="w-6 h-6 text-green-500" /><div><p className="text-2xl font-bold">{knowledgeBase.length}</p><p className="text-sm text-gray-600">KB Articles</p></div></div></CardContent></Card>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2">
                    <Card>
                        <CardHeader><CardTitle>Support Tickets</CardTitle><CardDescription>Manage customer support requests. Expert requests are highlighted and prioritized.</CardDescription></CardHeader>
                        <CardContent>
                            <div className="space-y-3 max-h-[60vh] overflow-y-auto pr-2">
                                {sortedTickets.length === 0 ? <p className="text-center text-gray-500 py-8">No support tickets yet</p> : sortedTickets.map((ticket) => (
                                    <div key={ticket.id} className={`p-4 border rounded-lg cursor-pointer transition-all ${selectedTicket?.id === ticket.id ? 'bg-blue-50 border-blue-300 shadow-md' : 'hover:bg-gray-50'} ${ticket.source === 'expert_request' ? 'border-yellow-400 border-2 bg-yellow-50' : ''}`} onClick={() => setSelectedTicket(ticket)}>
                                        <div className="flex justify-between items-start"><div className="flex-grow"><h4 className="font-semibold flex items-center gap-2">{ticket.source === 'expert_request' && <Star className="w-4 h-4 text-yellow-500 fill-current" />}{ticket.subject}</h4><p className="text-sm text-gray-600">{ticket.client_email}</p><p className="text-xs text-gray-500 mt-1">{new Date(ticket.created_date).toLocaleDateString()}</p></div><div className="flex gap-2 flex-col items-end"><Badge className={getStatusColor(ticket.status)}>{ticket.status.replace('_', ' ')}</Badge><Badge className={getPriorityColor(ticket.priority)}>{ticket.priority}</Badge></div></div>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>
                </div>
                <div>
                    <Card>
                        <CardHeader><CardTitle>{selectedTicket ? 'Ticket Response' : 'Select a Ticket'}</CardTitle></CardHeader>
                        <CardContent>
                            {selectedTicket ? (<div className="space-y-4"><h4 className="font-semibold">{selectedTicket.subject}</h4><p className="text-sm text-gray-600">{selectedTicket.description}</p>{selectedTicket.conversation?.length > 0 && (<div className="space-y-2"><h5 className="font-medium">Conversation:</h5>{selectedTicket.conversation.map((msg, index) => (<div key={index} className={`p-2 rounded text-sm ${msg.sender === 'client' ? 'bg-gray-100' : 'bg-blue-100'}`}><strong>{msg.sender}:</strong> {msg.message}</div>))}</div>)}<Textarea placeholder="Type your response..." value={newResponse} onChange={(e) => setNewResponse(e.target.value)} rows={4} /><Button onClick={handleTicketResponse} className="w-full">Send Response</Button></div>) : (<p className="text-center text-gray-500 py-8">Select a ticket to view details and respond</p>)}
                        </CardContent>
                    </Card>
                </div>
            </div>
        </div>
    );
}