import React, { useEffect } from 'react';
import ROICalculator from '../components/calculator/ROICalculator';

export default function ROICalculatorPage() {
    useEffect(() => {
        document.title = "CMMC ROI Calculator - HyperCore vs Consultants Savings | HyperCore";
        document.querySelector('meta[name="description"]')?.setAttribute('content', 
            'Calculate your CMMC compliance savings with HyperCore vs traditional consultants. Save $58K+ and 9 months. Interactive ROI calculator for defense contractors.');
    }, []);

    return <ROICalculator />;
}