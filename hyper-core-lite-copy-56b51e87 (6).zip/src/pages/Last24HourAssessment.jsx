import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { CheckCircle, AlertTriangle, TrendingUp, Clock, Users, Activity, Shield, Mail, Bot, Database, FileText, BarChart, FileCode, Target, ArrowRight } from 'lucide-react';
import { AuditLog } from "@/api/entities";
import { TestingLog } from "@/api/entities";
import { SupportTicket } from "@/api/entities";
import { ClientOnboarding } from "@/api/entities";
import { ClientEngagement } from "@/api/entities";
import { PartnershipCommunication } from "@/api/entities";
import { LetterOfIntent } from "@/api/entities";
import { UsageMetric } from "@/api/entities";
import { AIMetric } from "@/api/entities";
import { motion } from "framer-motion";
import { LoadingSpinner } from '../components/ui/LoadingSpinner';
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

// --- DEFINITIVE DATA VALIDATION HELPERS ---
const isRealUser = (email) => email && !email.includes('sample') && !email.includes('demo') && !email.includes('test@');

const KNOWN_SAMPLE_COMPANIES = [
    "aerodefense solutions",
    "maritime tech inc.",
    "cybernetics corp.",
    "defense logistics llc",
    "secure comms ltd.",
    "sample company",
    "test inc",
    "democorp"
];

const isRealRecord = (item) => {
    if (!item) return false;
    // Check for dummy creation dates often used in sample data
    if (item.created_date && (new Date(item.created_date).getFullYear() < 2020 || item.created_date.includes('1969'))) return false;
    
    // Check for sample user emails
    if (item.user_email && !isRealUser(item.user_email)) return false;
    if (item.client_email && !isRealUser(item.client_email)) return false;
    
    // Check for common sample data identifiers in string fields
    const lowerCompanyName = item.companyName?.toLowerCase() || item.company_name?.toLowerCase();
    if (lowerCompanyName && (KNOWN_SAMPLE_COMPANIES.includes(lowerCompanyName) || lowerCompanyName.includes('sample') || lowerCompanyName.includes('test'))) return false;
    
    if (item.event_name?.toLowerCase().includes('sample') || item.event_name?.toLowerCase().includes('test')) return false;
    if (item.description?.toLowerCase().includes('sample') || item.description?.toLowerCase().includes('test')) return false;
    if (item.ticket_title?.toLowerCase().includes('sample') || item.ticket_title?.toLowerCase().includes('test')) return false;
    if (item.test_name?.toLowerCase().includes('sample') || item.test_name?.toLowerCase().includes('test')) return false;

    return true;
};

export default function Last24HourAssessment() {
    const [data, setData] = useState(null);
    const [loading, setLoading] = useState(true);
    const [criticalEvents, setCriticalEvents] = useState([]);

    useEffect(() => {
        loadLast24Hours();
    }, []);

    const loadLast24Hours = async () => {
        setLoading(true);
        try {
            // Get current time and 24 hours ago
            const now = new Date();
            const twentyFourHoursAgo = new Date(now.getTime() - (24 * 60 * 60 * 1000));

            // Load all relevant data with higher limits to account for filtering out sample data
            const [auditLogs, testingLogs, supportTickets, clientOnboarding, lois, usageMetrics, aiMetrics] = await Promise.all([
                AuditLog.list('-created_date', 500),
                TestingLog.list('-created_date', 100),
                SupportTicket.list('-created_date', 100),
                ClientOnboarding.list('-created_date', 100),
                LetterOfIntent.list('-created_date', 100),
                UsageMetric.list('-created_date', 500),
                AIMetric.list('-created_date', 500)
            ]);

            // --- STRICT FILTERING FOR REAL DATA ---
            const realAuditLogs = auditLogs.filter(isRealRecord);
            const realTestingLogs = testingLogs.filter(isRealRecord);
            const realSupportTickets = supportTickets.filter(isRealRecord);
            const realClientOnboarding = clientOnboarding.filter(isRealRecord);
            const realLOIs = lois.filter(isRealRecord);
            const realUsageMetrics = usageMetrics.filter(isRealRecord);
            const realAIMetrics = aiMetrics.filter(isRealRecord);

            // Filter for last 24 hours
            const filterLast24Hours = (items) => items.filter(item =>
                new Date(item.created_date) >= twentyFourHoursAgo
            );

            const last24HourAuditLogs = filterLast24Hours(realAuditLogs);
            const last24HourTestingLogs = filterLast24Hours(realTestingLogs);
            const last24HourSupportTickets = filterLast24Hours(realSupportTickets);
            const last24HourClientOnboarding = filterLast24Hours(realClientOnboarding);
            const last24HourLOIs = filterLast24Hours(realLOIs);
            const last24HourUsageMetrics = filterLast24Hours(realUsageMetrics);
            const last24HourAIMetrics = filterLast24Hours(realAIMetrics);

            // --- Calculate Metrics FROM REAL DATA ONLY ---

            // General Metrics
            const totalEvents = last24HourAuditLogs.length;
            const successfulEvents = last24HourAuditLogs.filter(log => log.status === 'SUCCESS').length;
            const failedEvents = last24HourAuditLogs.filter(log => log.status === 'FAILURE').length;
            const newClients = last24HourClientOnboarding.length;
            const newSupportTickets = last24HourSupportTickets.length;

            // Migration Progress Metrics
            const migrationTests = last24HourTestingLogs.filter(log =>
                log.test_name && (log.test_name.includes('Migration') || log.test_name.includes('AWS') || log.test_name.includes('Export'))
            );
            const migrationTestsRun = migrationTests.length;
            const migrationSuccessRate = migrationTestsRun > 0 ? (migrationTests.filter(t => t.status === 'SUCCESS').length / migrationTestsRun) * 100 : 100;
            const recentMigrationEvents = last24HourAuditLogs.filter(log =>
                log.event_name && (log.event_name.includes('MIGRATION') || log.event_name.includes('EXPORT') || log.event_name.includes('AWS'))
            ).slice(0, 5);

            // SBIR Proposal Progress Metrics
            const newLOIs = last24HourLOIs.length;
            const avgResponseTime = last24HourUsageMetrics.length > 0 ? Math.round(last24HourUsageMetrics.reduce((sum, m) => sum + m.response_time_ms, 0) / last24HourUsageMetrics.length) : 0;
            const aiAccuracy = last24HourAIMetrics.length > 0 ? (last24HourAIMetrics.reduce((sum, m) => sum + m.accuracy_score, 0) / last24HourAIMetrics.length * 100).toFixed(1) : 0;

            // Identify critical events
            const critical = [];
            if (failedEvents > 0) critical.push({ type: 'error', message: `High failure rate: ${failedEvents} failed events` });
            if (newSupportTickets > 0) critical.push({ type: 'warning', message: `Spike in support tickets: ${newSupportTickets} new tickets` });
            if (migrationTestsRun > 0 && migrationSuccessRate < 100) critical.push({ type: 'warning', message: `Migration test success rate is low: ${migrationSuccessRate.toFixed(0)}%` });
            
            setCriticalEvents(critical);

            setData({
                totalEvents,
                successRate: totalEvents > 0 ? ((successfulEvents / totalEvents) * 100).toFixed(1) : 100,
                newClients,
                newSupportTickets,
                migrationTestsRun,
                migrationSuccessRate,
                newLOIs,
                sbirAnalytics: { avgResponseTime, aiAccuracy },
                recentMigrationEvents,
                recentLOIs: last24HourLOIs.slice(0, 5),
                last24HourAuditLogs: last24HourAuditLogs.slice(0, 10),
            });

        } catch (error) {
            console.error("Failed to load 24-hour assessment:", error);
            setData(null); 
        } finally {
            setLoading(false);
        }
    };

    if (loading) {
        return <LoadingSpinner text="Analyzing last 24 hours of system activity..." />;
    }

    if (!data) {
        return (
            <div className="text-center p-8">
                <AlertTriangle className="w-12 h-12 text-yellow-500 mx-auto mb-4" />
                <p>Failed to load 24-hour assessment data. Please try again later.</p>
                <Button onClick={loadLast24Hours} className="mt-4">Retry</Button>
            </div>
        );
    }

    return (
        <div className="space-y-6">
            <BreadcrumbNav currentPageName="Last24HourAssessment" />

            <div className="flex justify-between items-center">
                <div>
                    <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
                        <Clock className="w-8 h-8 text-blue-600" />
                        Last 24 Hour System Assessment
                    </h1>
                    <p className="text-gray-600 mt-2">Comprehensive analysis of system activity, user engagement, and performance</p>
                </div>
                <Button onClick={loadLast24Hours} variant="outline">
                    <Activity className="w-4 h-4 mr-2" />
                    Refresh Data
                </Button>
            </div>

            {/* Critical Alerts */}
            {criticalEvents.length > 0 && (
                <motion.div
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                >
                    <Card className="border-orange-200 bg-orange-50">
                        <CardHeader>
                            <CardTitle className="text-orange-800">Critical Events & Alerts</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-2">
                                {criticalEvents.map((event, index) => (
                                    <Alert key={index} className={`${
                                        event.type === 'error' ? 'bg-red-50 border-red-200' :
                                        event.type === 'warning' ? 'bg-yellow-50 border-yellow-200' :
                                        'bg-blue-50 border-blue-200'
                                    }`}>
                                        <AlertTriangle className="h-4 w-4" />
                                        <AlertDescription>{event.message}</AlertDescription>
                                    </Alert>
                                ))}
                            </div>
                        </CardContent>
                    </Card>
                </motion.div>
            )}

            {/* Key Metrics */}
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                <Card>
                    <CardContent className="p-4">
                        <div className="flex items-center gap-3">
                            <Activity className="w-6 h-6 text-blue-500" />
                            <div>
                                <p className="text-2xl font-bold">{data.totalEvents}</p>
                                <p className="text-sm text-gray-600">Total Events</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>

                <Card>
                    <CardContent className="p-4">
                        <div className="flex items-center gap-3">
                            <CheckCircle className="w-6 h-6 text-green-500" />
                            <div>
                                <p className="text-2xl font-bold">{data.successRate}%</p>
                                <p className="text-sm text-gray-600">Success Rate</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>

                <Card>
                    <CardContent className="p-4">
                        <div className="flex items-center gap-3">
                            <Users className="w-6 h-6 text-purple-500" />
                            <div>
                                <p className="text-2xl font-bold">{data.newClients}</p>
                                <p className="text-sm text-gray-600">New Clients</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>

                <Card>
                    <CardContent className="p-4">
                        <div className="flex items-center gap-3">
                            <Target className="w-6 h-6 text-green-500" />
                            <div>
                                <p className="text-2xl font-bold">{data.newLOIs}</p>
                                <p className="text-sm text-gray-600">New LOIs Signed</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>

                <Card>
                    <CardContent className="p-4">
                        <div className="flex items-center gap-3">
                            <FileCode className="w-6 h-6 text-orange-500" />
                            <div>
                                <p className="text-2xl font-bold">{data.migrationTestsRun}</p>
                                <p className="text-sm text-gray-600">Migration Tests</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>

                <Card>
                    <CardContent className="p-4">
                        <div className="flex items-center gap-3">
                            <Mail className="w-6 h-6 text-yellow-500" />
                            <div>
                                <p className="text-2xl font-bold">{data.newSupportTickets}</p>
                                <p className="text-sm text-gray-600">New Tickets</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </div>

            {/* Detailed Breakdown */}
            <div className="grid md:grid-cols-2 gap-6">
                {/* Migration Progress */}
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2"><FileCode className="w-5 h-5 text-orange-600" />Migration Progress (24h)</CardTitle>
                        <CardDescription>Status of the Base44 to AWS migration effort</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="grid grid-cols-2 gap-4 mb-4">
                            <div className="text-center p-3 bg-gray-50 rounded-lg">
                                <p className="text-2xl font-bold">{data.migrationTestsRun}</p>
                                <p className="text-sm text-gray-600">Tests Executed</p>
                            </div>
                            <div className="text-center p-3 bg-gray-50 rounded-lg">
                                <p className="text-2xl font-bold text-green-600">{data.migrationSuccessRate.toFixed(0)}%</p>
                                <p className="text-sm text-gray-600">Success Rate</p>
                            </div>
                        </div>
                         <h4 className="font-medium mb-2">Recent Migration Events:</h4>
                        <div className="space-y-2">
                           {data.recentMigrationEvents.length > 0 ? data.recentMigrationEvents.map((log) => (
                                <div key={log.id} className="text-sm p-2 bg-orange-50 rounded flex justify-between items-center">
                                    <span>{log.event_name}</span>
                                    <Badge variant="outline" className={log.status === 'SUCCESS' ? 'text-green-700 border-green-200' : 'text-red-700 border-red-200'}>{log.status}</Badge>
                                </div>
                            )) : <p className="text-center text-gray-500 py-3">No migration events logged.</p>}
                        </div>
                        <Button asChild variant="outline" className="w-full mt-4">
                            <Link to={createPageUrl('AWSMigrationExecutionPlan')}>View Full Migration Plan <ArrowRight className="w-4 h-4 ml-2" /></Link>
                        </Button>
                    </CardContent>
                </Card>

                {/* SBIR Proposal Progress */}
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2"><Target className="w-5 h-5 text-green-600" />SBIR Proposal Evidence (24h)</CardTitle>
                        <CardDescription>New data and metrics strengthening the grant proposal</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="grid grid-cols-3 gap-4 mb-4">
                             <div className="text-center p-3 bg-gray-50 rounded-lg">
                                <p className="text-2xl font-bold">{data.newLOIs}</p>
                                <p className="text-sm text-gray-600">New LOIs</p>
                            </div>
                            <div className="text-center p-3 bg-gray-50 rounded-lg">
                                <p className="text-2xl font-bold text-blue-600">{data.sbirAnalytics.aiAccuracy}%</p>
                                <p className="text-sm text-gray-600">AI Accuracy</p>
                            </div>
                            <div className="text-center p-3 bg-gray-50 rounded-lg">
                                <p className="text-2xl font-bold text-purple-600">{data.sbirAnalytics.avgResponseTime}ms</p>
                                <p className="text-sm text-gray-600">API Speed</p>
                            </div>
                        </div>
                        <h4 className="font-medium mb-2">Recently Signed Letters of Intent:</h4>
                        <div className="space-y-2">
                           {data.recentLOIs.length > 0 ? data.recentLOIs.map((loi) => (
                                <div key={loi.id} className="text-sm p-2 bg-green-50 rounded">
                                    <strong>{loi.companyName}</strong> committed as a {loi.commitmentLevel}.
                                </div>
                            )) : <p className="text-center text-gray-500 py-3">No new LOIs to report.</p>}
                        </div>
                        <Button asChild variant="outline" className="w-full mt-4">
                            <Link to={createPageUrl('RevisedSBIRStrategy')}>View SBIR Submission Plan <ArrowRight className="w-4 h-4 ml-2" /></Link>
                        </Button>
                    </CardContent>
                </Card>
            </div>

            {/* General System Events */}
            <Card>
                <CardHeader>
                    <CardTitle>System Events (Last 10)</CardTitle>
                    <CardDescription>Most recent general system activity</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="space-y-3">
                        {data.last24HourAuditLogs.map((log) => (
                            <div key={log.id} className="flex justify-between items-center p-3 bg-gray-50 rounded-md">
                                <div>
                                    <p className="font-semibold text-sm">{log.event_name}</p>
                                    <p className="text-xs text-gray-600">{log.user_email}</p>
                                </div>
                                <Badge className={
                                    log.status === 'SUCCESS' ? 'bg-green-100 text-green-800' :
                                    log.status === 'FAILURE' ? 'bg-red-100 text-red-800' :
                                    'bg-yellow-100 text-yellow-800'
                                }>
                                    {log.status}
                                </Badge>
                            </div>
                        ))}
                        {data.last24HourAuditLogs.length === 0 && (
                            <p className="text-center text-gray-500 py-4">No system events in the last 24 hours</p>
                        )}
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}