import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowRight, Shield, Zap, Target, Clock, DollarSign, Server, Database, Lock, Eye, AlertTriangle, CheckCircle, TrendingUp, Building } from 'lucide-react';

export default function DefenseSubcontractorStrategy() {
    
    const marketIntelligence = {
        industryFailureRates: {
            firstPassRate: "Most contractors find 'some level of non-compliance'",
            remediationCycle: "Multiple iterations are the norm, not the exception",
            waitTimes: "Months of waiting for C3PAO re-assessment due to high demand",
            hiddenCosts: "Tens to hundreds of thousands in unforeseen remediation"
        },
        competitorApproach: {
            consultingCosts: "$50,000 - $200,000+ for manual preparation",
            c3paoFees: "$40,000 - $80,000 per assessment attempt",
            timeline: "6-18+ months preparation phase",
            totalInvestment: "$150,000 - $400,000+ including remediation cycles"
        },
        hypercoreAdvantage: {
            cost: "$25,000 total investment",
            timeline: "90 days to C3PAO-ready",
            legacyIntegration: "Automated assessment and migration of existing systems",
            successRate: "Engineered for first-pass success, rapid remediation if needed"
        }
    };

    const insiderSecrets = [
        {
            secret: "Most contractors spend more on remediation than the initial assessment",
            reality: "The $40k-$80k C3PAO fee is just the entry cost. The real expense comes from the 'tens to hundreds of thousands' in remediation work most contractors face.",
            hypercoreAdvantage: "Our AI pre-identifies gaps before the C3PAO arrives, dramatically reducing surprise findings."
        },
        {
            secret: "Legacy system integration is the #1 compliance killer",
            reality: "Most contractors fail because they can't properly document and secure their existing infrastructure. Manual gap analysis misses critical vulnerabilities.",
            hypercoreAdvantage: "Automated legacy system assessment and compliance roadmapping. We don't just find problems; we engineer solutions."
        },
        {
            secret: "C3PAO scheduling is becoming a critical bottleneck",
            reality: "High demand means contractors needing re-assessment wait months for scheduling. Every month of delay costs potential contract opportunities.",
            hypercoreAdvantage: "Get it right the first time. Our platform reduces the probability of needing multiple assessment cycles."
        },
        {
            secret: "AWS inheritance can eliminate 60-70% of compliance work",
            reality: "Most contractors don't realize that AWS GovCloud automatically satisfies most Physical & Environmental Protection controls, saving $50,000+ in infrastructure costs.",
            hypercoreAdvantage: "We map AWS inherited controls and focus your resources on what actually needs implementation."
        }
    ];

    const competitiveIntelligence = {
        whatCompetitorsDo: [
            "Hire expensive consultants for manual gap analysis ($50k-$200k)",
            "Spend 6-18 months in preparation phase",
            "Discover compliance gaps during the actual C3PAO audit",
            "Enter costly remediation cycles with uncertain timelines",
            "Wait months for re-assessment scheduling"
        ],
        whatHyperCoreDoes: [
            "AI-powered automated assessment of entire infrastructure ($25k total)",
            "90-day engineered preparation with legacy system integration",
            "Identify and remediate gaps before C3PAO arrives",
            "Provide audit-ready documentation and evidence packages",
            "Continuous monitoring prevents compliance drift"
        ]
    };

    return (
        <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-blue-900 text-white p-6">
            <div className="max-w-7xl mx-auto">
                <header className="text-center mb-12">
                    <Badge className="bg-red-600 text-white mb-4 text-sm font-bold">CLASSIFIED: DEFENSE CONTRACTOR INTELLIGENCE</Badge>
                    <h1 className="text-5xl font-extrabold mb-4 bg-gradient-to-r from-blue-400 to-emerald-400 bg-clip-text text-transparent">
                        The Defense Contractor's CMMC Cheat Sheet
                    </h1>
                    <p className="text-xl text-gray-300 max-w-3xl mx-auto">
                        The insider intelligence your competitors don't have. Real-world data on C3PAO pass rates, costs, and the systematic approach that changes everything.
                    </p>
                </header>

                <Alert className="mb-12 bg-gradient-to-r from-red-900 to-orange-900 border-red-500">
                    <AlertTriangle className="h-5 w-5 text-red-400" />
                    <AlertTitle className="text-red-200 font-bold text-lg">MARKET INTELLIGENCE: The Remediation Trap</AlertTitle>
                    <AlertDescription className="text-red-100">
                        <div className="grid md:grid-cols-2 gap-4 mt-4">
                            <div>
                                <h4 className="font-semibold text-red-200">What the Industry Won't Tell You:</h4>
                                <ul className="text-sm mt-2 space-y-1">
                                    <li>• {marketIntelligence.industryFailureRates.firstPassRate}</li>
                                    <li>• {marketIntelligence.industryFailureRates.remediationCycle}</li>
                                    <li>• {marketIntelligence.industryFailureRates.waitTimes}</li>
                                    <li>• {marketIntelligence.industryFailureRates.hiddenCosts}</li>
                                </ul>
                            </div>
                            <div>
                                <h4 className="font-semibold text-red-200">Your Competitors' True Costs:</h4>
                                <ul className="text-sm mt-2 space-y-1">
                                    <li>• Preparation: {marketIntelligence.competitorApproach.consultingCosts}</li>
                                    <li>• C3PAO Assessment: {marketIntelligence.competitorApproach.c3paoFees}</li>
                                    <li>• Timeline: {marketIntelligence.competitorApproach.timeline}</li>
                                    <li>• <strong>Total Investment: {marketIntelligence.competitorApproach.totalInvestment}</strong></li>
                                </ul>
                            </div>
                        </div>
                    </AlertDescription>
                </Alert>

                <Tabs defaultValue="insider-secrets" className="space-y-8">
                    <TabsList className="grid w-full grid-cols-4 bg-gray-800 border border-gray-600">
                        <TabsTrigger value="insider-secrets" className="data-[state=active]:bg-blue-600">Insider Secrets</TabsTrigger>
                        <TabsTrigger value="competitive-intel" className="data-[state=active]:bg-blue-600">Competitive Intel</TabsTrigger>
                        <TabsTrigger value="legacy-integration" className="data-[state=active]:bg-blue-600">Legacy Systems</TabsTrigger>
                        <TabsTrigger value="hypercore-advantage" className="data-[state=active]:bg-blue-600">HyperCore Advantage</TabsTrigger>
                    </TabsList>

                    <TabsContent value="insider-secrets">
                        <div className="space-y-6">
                            <h2 className="text-3xl font-bold text-center mb-8 text-blue-400">Industry Secrets Your Competitors Don't Know</h2>
                            
                            {insiderSecrets.map((item, index) => (
                                <Card key={index} className="bg-gray-800 border-gray-600">
                                    <CardHeader>
                                        <CardTitle className="text-yellow-400 flex items-center gap-2">
                                            <Lock className="w-5 h-5" />
                                            Secret #{index + 1}: {item.secret}
                                        </CardTitle>
                                    </CardHeader>
                                    <CardContent className="space-y-4">
                                        <div className="bg-red-900/30 p-4 rounded border border-red-500/50">
                                            <h4 className="font-semibold text-red-300 mb-2">The Harsh Reality:</h4>
                                            <p className="text-red-100 text-sm">{item.reality}</p>
                                        </div>
                                        <div className="bg-green-900/30 p-4 rounded border border-green-500/50">
                                            <h4 className="font-semibold text-green-300 mb-2">Your HyperCore Advantage:</h4>
                                            <p className="text-green-100 text-sm">{item.hypercoreAdvantage}</p>
                                        </div>
                                    </CardContent>
                                </Card>
                            ))}
                        </div>
                    </TabsContent>

                    <TabsContent value="competitive-intel">
                        <div className="grid lg:grid-cols-2 gap-8">
                            <Card className="bg-red-900/20 border-red-500">
                                <CardHeader>
                                    <CardTitle className="text-red-400 flex items-center gap-2">
                                        <AlertTriangle className="w-5 h-5" />
                                        What Your Competitors Are Doing (The Hard Way)
                                    </CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <ul className="space-y-3">
                                        {competitiveIntelligence.whatCompetitorsDo.map((item, index) => (
                                            <li key={index} className="flex items-start gap-3 text-red-100">
                                                <div className="w-2 h-2 bg-red-500 rounded-full mt-2 flex-shrink-0"></div>
                                                <span className="text-sm">{item}</span>
                                            </li>
                                        ))}
                                    </ul>
                                    <div className="mt-6 p-4 bg-red-800/30 rounded">
                                        <div className="text-2xl font-bold text-red-300">$150K - $400K+</div>
                                        <div className="text-red-400 text-sm">Total cost including remediation cycles</div>
                                        <div className="text-red-400 text-sm">12-24+ months timeline</div>
                                    </div>
                                </CardContent>
                            </Card>

                            <Card className="bg-green-900/20 border-green-500">
                                <CardHeader>
                                    <CardTitle className="text-green-400 flex items-center gap-2">
                                        <Shield className="w-5 h-5" />
                                        What HyperCore Does (Your Secret Weapon)
                                    </CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <ul className="space-y-3">
                                        {competitiveIntelligence.whatHyperCoreDoes.map((item, index) => (
                                            <li key={index} className="flex items-start gap-3 text-green-100">
                                                <CheckCircle className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                                                <span className="text-sm">{item}</span>
                                            </li>
                                        ))}
                                    </ul>
                                    <div className="mt-6 p-4 bg-green-800/30 rounded">
                                        <div className="text-2xl font-bold text-green-300">$25K Total</div>
                                        <div className="text-green-400 text-sm">Fixed cost, no remediation surprises</div>
                                        <div className="text-green-400 text-sm">90 days to C3PAO-ready</div>
                                    </div>
                                </CardContent>
                            </Card>
                        </div>
                    </TabsContent>

                    <TabsContent value="legacy-integration">
                        <Card className="bg-gray-800 border-gray-600">
                            <CardHeader>
                                <CardTitle className="text-blue-400 flex items-center gap-2">
                                    <Database className="w-5 h-5" />
                                    Legacy System Integration: The Make-or-Break Factor
                                </CardTitle>
                                <CardDescription className="text-gray-300">
                                    Why 90% of CMMC failures stem from legacy infrastructure gaps, and how HyperCore solves it.
                                </CardDescription>
                            </CardHeader>
                            <CardContent className="space-y-6">
                                <Alert className="bg-yellow-900/30 border-yellow-500">
                                    <Server className="h-4 w-4 text-yellow-400" />
                                    <AlertTitle className="text-yellow-300">The Legacy System Problem</AlertTitle>
                                    <AlertDescription className="text-yellow-100">
                                        Most defense contractors have mission-critical systems that are 5-15+ years old. These systems were never designed for CMMC compliance, creating massive blind spots in security posture assessment.
                                    </AlertDescription>
                                </Alert>

                                <div className="grid md:grid-cols-2 gap-6">
                                    <div className="bg-red-900/20 p-4 rounded border border-red-500/50">
                                        <h4 className="font-semibold text-red-300 mb-3">Traditional Approach Failures:</h4>
                                        <ul className="space-y-2 text-sm text-red-100">
                                            <li>• Manual documentation of legacy systems</li>
                                            <li>• Incomplete visibility into data flows</li>
                                            <li>• Missed interdependencies and vulnerabilities</li>
                                            <li>• Expensive "rip and replace" recommendations</li>
                                            <li>• Months of system archeology and guesswork</li>
                                        </ul>
                                    </div>
                                    
                                    <div className="bg-green-900/20 p-4 rounded border border-green-500/50">
                                        <h4 className="font-semibold text-green-300 mb-3">HyperCore's AI-Powered Solution:</h4>
                                        <ul className="space-y-2 text-sm text-green-100">
                                            <li>• Automated discovery and mapping of all systems</li>
                                            <li>• AI-driven data flow analysis and classification</li>
                                            <li>• Comprehensive vulnerability assessment</li>
                                            <li>• Cost-effective compliance integration strategies</li>
                                            <li>• Complete documentation package for C3PAO</li>
                                        </ul>
                                    </div>
                                </div>

                                <div className="bg-blue-900/30 p-6 rounded border border-blue-500/50">
                                    <h4 className="font-semibold text-blue-300 mb-4 text-center">AWS Migration Strategy: The Ultimate Compliance Accelerator</h4>
                                    <div className="grid md:grid-cols-3 gap-4 text-center">
                                        <div>
                                            <div className="text-2xl font-bold text-blue-400">60-70%</div>
                                            <div className="text-blue-300 text-sm">Controls Inherited from AWS</div>
                                        </div>
                                        <div>
                                            <div className="text-2xl font-bold text-blue-400">$50K+</div>
                                            <div className="text-blue-300 text-sm">Infrastructure Costs Eliminated</div>
                                        </div>
                                        <div>
                                            <div className="text-2xl font-bold text-blue-400">6+ Months</div>
                                            <div className="text-blue-300 text-sm">Timeline Reduction</div>
                                        </div>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    </TabsContent>

                    <TabsContent value="hypercore-advantage">
                        <div className="space-y-8">
                            <Card className="bg-gradient-to-r from-blue-900 to-purple-900 border-blue-500">
                                <CardHeader className="text-center">
                                    <CardTitle className="text-3xl text-blue-300 mb-4">Your Unfair Advantage: The HyperCore Difference</CardTitle>
                                    <CardDescription className="text-blue-100 text-lg">
                                        While your competitors struggle with traditional approaches, you deploy a systematic, AI-powered advantage that changes the entire game.
                                    </CardDescription>
                                </CardHeader>
                                <CardContent className="space-y-8">
                                    
                                    <div className="grid md:grid-cols-4 gap-6 text-center">
                                        <div className="bg-white/10 p-4 rounded">
                                            <DollarSign className="w-8 h-8 mx-auto text-green-400 mb-2" />
                                            <div className="text-2xl font-bold text-green-300">$25K</div>
                                            <div className="text-green-100 text-sm">Total Investment</div>
                                            <div className="text-xs text-gray-400 mt-1">vs $150K-$400K traditional</div>
                                        </div>
                                        <div className="bg-white/10 p-4 rounded">
                                            <Clock className="w-8 h-8 mx-auto text-blue-400 mb-2" />
                                            <div className="text-2xl font-bold text-blue-300">90 Days</div>
                                            <div className="text-blue-100 text-sm">To C3PAO Ready</div>
                                            <div className="text-xs text-gray-400 mt-1">vs 6-18+ months traditional</div>
                                        </div>
                                        <div className="bg-white/10 p-4 rounded">
                                            <Target className="w-8 h-8 mx-auto text-purple-400 mb-2" />
                                            <div className="text-2xl font-bold text-purple-300">First-Pass</div>
                                            <div className="text-purple-100 text-sm">Engineered Success</div>
                                            <div className="text-xs text-gray-400 mt-1">vs remediation cycles</div>
                                        </div>
                                        <div className="bg-white/10 p-4 rounded">
                                            <Database className="w-8 h-8 mx-auto text-yellow-400 mb-2" />
                                            <div className="text-2xl font-bold text-yellow-300">Legacy</div>
                                            <div className="text-yellow-100 text-sm">System Integration</div>
                                            <div className="text-xs text-gray-400 mt-1">vs manual assessment</div>
                                        </div>
                                    </div>

                                    <Alert className="bg-gradient-to-r from-green-900 to-emerald-900 border-green-500">
                                        <CheckCircle className="h-5 w-5 text-green-400" />
                                        <AlertTitle className="text-green-300 font-bold">Strategic Advantage Summary</AlertTitle>
                                        <AlertDescription className="text-green-100">
                                            <div className="mt-4 grid md:grid-cols-2 gap-4">
                                                <div>
                                                    <h4 className="font-semibold mb-2">Immediate Benefits:</h4>
                                                    <ul className="text-sm space-y-1">
                                                        <li>• 85% cost reduction vs traditional approaches</li>
                                                        <li>• 75% timeline acceleration</li>
                                                        <li>• Comprehensive legacy system integration</li>
                                                        <li>• AI-powered gap identification and remediation</li>
                                                    </ul>
                                                </div>
                                                <div>
                                                    <h4 className="font-semibold mb-2">Long-term Competitive Edge:</h4>
                                                    <ul className="text-sm space-y-1">
                                                        <li>• Continuous compliance monitoring</li>
                                                        <li>• Rapid response to changing requirements</li>
                                                        <li>• Audit-ready documentation at all times</li>
                                                        <li>• Scalable compliance for growth</li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </AlertDescription>
                                    </Alert>
                                </CardContent>
                            </Card>

                            <Card className="bg-gray-900 border-gray-600 text-center">
                                <CardHeader>
                                    <CardTitle className="text-3xl text-white">Ready to Deploy Your Secret Weapon?</CardTitle>
                                </CardHeader>
                                <CardContent className="space-y-6">
                                    <p className="text-gray-300 text-lg max-w-2xl mx-auto">
                                        While your competitors burn through hundreds of thousands in remediation cycles, you can achieve CMMC compliance in 90 days for a fraction of the cost. This isn't just efficiency—it's competitive advantage.
                                    </p>
                                    <div className="flex flex-col sm:flex-row gap-4 justify-center">
                                        <Button size="lg" className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-semibold px-8 py-3">
                                            <Shield className="w-5 h-5 mr-2" />
                                            Schedule Strategic Assessment
                                        </Button>
                                        <Button size="lg" variant="outline" className="border-gray-400 text-gray-300 hover:bg-gray-800 px-8 py-3">
                                            <TrendingUp className="w-5 h-5 mr-2" />
                                            View Technical Architecture
                                        </Button>
                                    </div>
                                    <p className="text-xs text-gray-500 max-w-lg mx-auto">
                                        Join the defense contractors who have already discovered this advantage. Limited availability for new strategic partnerships.
                                    </p>
                                </CardContent>
                            </Card>
                        </div>
                    </TabsContent>
                </Tabs>
            </div>
        </div>
    );
}