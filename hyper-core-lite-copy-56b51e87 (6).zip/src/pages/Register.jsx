import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { User } from "@/api/entities";
import { toast } from "sonner";
import { Shield, UserPlus, Building } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function Register() {
    const [formData, setFormData] = useState({
        email: '',
        password: '',
        confirmPassword: '',
        full_name: '',
        organization_name: '',
        industry: 'defense_contractor',
        size: '',
        location: '',
        cmmc_level: 'Level 2'
    });
    const [loading, setLoading] = useState(false);

    const handleSubmit = async (e) => {
        e.preventDefault();
        
        if (formData.password !== formData.confirmPassword) {
            toast.error("Passwords don't match");
            return;
        }

        if (formData.password.length < 8) {
            toast.error("Password must be at least 8 characters");
            return;
        }

        setLoading(true);
        try {
            await User.create({
                email: formData.email,
                full_name: formData.full_name,
                organization_name: formData.organization_name,
                industry: formData.industry,
                size: parseInt(formData.size),
                location: formData.location,
                cmmc_level: formData.cmmc_level,
                partnership_role: 'prospect', // Default role for all new registrations
                sector_role: 'defense_contractor',
                portal_access_level: 'public'
            });

            toast.success("Registration successful! You can now access the free trial tools.");
            // Redirect to dashboard
            window.location.href = createPageUrl('Dashboard');
            
        } catch (error) {
            console.error("Registration failed:", error);
            toast.error("Registration failed. Please try again.");
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="min-h-screen bg-gradient-to-b from-gray-50 to-blue-50 py-12">
            <div className="container mx-auto px-4 max-w-2xl">
                <Card className="shadow-xl">
                    <CardHeader className="text-center">
                        <div className="mx-auto w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                            <UserPlus className="w-6 h-6 text-blue-600" />
                        </div>
                        <CardTitle className="text-2xl font-bold">Register for Free CMMC Trial</CardTitle>
                        <CardDescription>
                            Join 31,500+ defense contractors preparing for CMMC compliance. Free until December 5th, 2025.
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                        <form onSubmit={handleSubmit} className="space-y-4">
                            <div className="grid md:grid-cols-2 gap-4">
                                <Input
                                    type="email"
                                    placeholder="Email Address"
                                    value={formData.email}
                                    onChange={(e) => setFormData({...formData, email: e.target.value})}
                                    required
                                />
                                <Input
                                    placeholder="Full Name"
                                    value={formData.full_name}
                                    onChange={(e) => setFormData({...formData, full_name: e.target.value})}
                                    required
                                />
                            </div>

                            <div className="grid md:grid-cols-2 gap-4">
                                <Input
                                    type="password"
                                    placeholder="Password (min 8 characters)"
                                    value={formData.password}
                                    onChange={(e) => setFormData({...formData, password: e.target.value})}
                                    required
                                />
                                <Input
                                    type="password"
                                    placeholder="Confirm Password"
                                    value={formData.confirmPassword}
                                    onChange={(e) => setFormData({...formData, confirmPassword: e.target.value})}
                                    required
                                />
                            </div>

                            <Input
                                placeholder="Organization/Company Name"
                                value={formData.organization_name}
                                onChange={(e) => setFormData({...formData, organization_name: e.target.value})}
                                required
                            />

                            <div className="grid md:grid-cols-3 gap-4">
                                <Select value={formData.industry} onValueChange={(value) => setFormData({...formData, industry: value})}>
                                    <SelectTrigger>
                                        <SelectValue placeholder="Industry" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="defense_contractor">Defense Contractor</SelectItem>
                                        <SelectItem value="aerospace">Aerospace</SelectItem>
                                        <SelectItem value="manufacturing">Manufacturing</SelectItem>
                                        <SelectItem value="technology">Technology</SelectItem>
                                        <SelectItem value="other">Other</SelectItem>
                                    </SelectContent>
                                </Select>

                                <Input
                                    type="number"
                                    placeholder="Employee Count"
                                    value={formData.size}
                                    onChange={(e) => setFormData({...formData, size: e.target.value})}
                                    required
                                />

                                <Input
                                    placeholder="Location (City, State)"
                                    value={formData.location}
                                    onChange={(e) => setFormData({...formData, location: e.target.value})}
                                    required
                                />
                            </div>

                            <Select value={formData.cmmc_level} onValueChange={(value) => setFormData({...formData, cmmc_level: value})}>
                                <SelectTrigger>
                                    <SelectValue placeholder="Target CMMC Level" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="Level 1">CMMC Level 1</SelectItem>
                                    <SelectItem value="Level 2">CMMC Level 2</SelectItem>
                                    <SelectItem value="Level 3">CMMC Level 3</SelectItem>
                                </SelectContent>
                            </Select>

                            <Alert>
                                <Shield className="h-4 w-4" />
                                <AlertDescription>
                                    By registering, you agree to our terms of service and privacy policy. 
                                    Your data is used solely for CMMC compliance assistance and will not be shared with third parties.
                                </AlertDescription>
                            </Alert>

                            <Button type="submit" className="w-full" disabled={loading}>
                                {loading ? "Creating Account..." : "Register for Free Trial"}
                            </Button>
                        </form>

                        <div className="text-center mt-6">
                            <p className="text-sm text-gray-600">
                                Already have an account? <Link to={createPageUrl('Login')} className="text-blue-600 hover:underline">Sign In</Link>
                            </p>
                        </div>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}