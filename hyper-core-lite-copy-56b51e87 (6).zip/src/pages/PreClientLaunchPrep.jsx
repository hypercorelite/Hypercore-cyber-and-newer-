import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Tabs, TabsList, TabsContent, TabsTrigger } from "@/components/ui/tabs";
import { CheckCircle, GitBranch, Cloud, Shield, Code, Terminal, Copy, ExternalLink, Rocket, Target, DollarSign, Scale, ArrowRight } from 'lucide-react';
import { toast } from "sonner";

const CodeBlock = ({ content, title }) => {
    const handleCopy = () => {
        navigator.clipboard.writeText(content);
        toast.success(`${title} copied to clipboard!`);
    };

    return (
        <div className="relative">
            <Button
                size="icon"
                variant="ghost"
                className="absolute top-2 right-2 h-7 w-7"
                onClick={handleCopy}
            >
                <Copy className="h-4 w-4" />
            </Button>
            <pre className="bg-gray-900 text-white p-4 rounded-md font-mono text-xs max-h-[400px] overflow-y-auto">
                <code>{content}</code>
            </pre>
        </div>
    );
};

export default function PreClientLaunchPrep() {

    const serverSetupCommands = `# SSH into your EC2 instance first: ssh -i your-key.pem ubuntu@your-ec2-ip

# Update all packages
sudo apt update && sudo apt upgrade -y

# Install Nginx web server
sudo apt install -y nginx

# Install Node.js (v18.x is recommended)
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs

# Install a process manager to keep the app running
sudo npm install -g pm2

# Install Certbot for free SSL certificates
sudo apt install -y certbot python3-certbot-nginx`;

    const deploymentScript = `#!/bin/bash
set -e

# --- Configuration ---
REMOTE_USER="ubuntu"
REMOTE_HOST="YOUR_EC2_IP_ADDRESS" # <-- IMPORTANT: Change this
KEY_FILE="~/.ssh/your-key.pem" # <-- IMPORTANT: Change this
DEPLOY_DIR="/var/www/hypercore"

echo "--- Building the application ---"
npm run build

echo "--- Creating deployment package ---"
tar -czf deployment.tar.gz build

echo "--- Uploading to EC2 instance ---"
scp -i \${KEY_FILE} deployment.tar.gz \${REMOTE_USER}@\${REMOTE_HOST}:~/

echo "--- Deploying on EC2 ---"
ssh -i \${KEY_FILE} \${REMOTE_USER}@\${REMOTE_HOST} << 'EOF'
    set -e
    
    # Create directory if it doesn't exist
    sudo mkdir -p /var/www/hypercore
    
    # Move new build into place
    sudo mv ~/deployment.tar.gz /var/www/hypercore/
    cd /var/www/hypercore
    
    # Unpack the new version
    sudo tar -xzf deployment.tar.gz
    sudo rm deployment.tar.gz
    
    # Serve with Nginx (config assumed to be in place)
    # Ensure Nginx is pointing its root to /var/www/hypercore/build
    sudo systemctl restart nginx
    
    echo "✅ EC2 deployment successful!"
EOF

echo "🎉 Full deployment complete!"`;
    
    return (
        <div className="space-y-8">
            <div className="text-center">
                <h1 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-3">
                    Pre-Client Launch & Operations Playbook
                </h1>
                <p className="text-lg lg:text-xl text-gray-600">
                    Your final consolidated guide to transition from development to live, client-ready operations.
                </p>
            </div>
            
            <Alert className="bg-blue-50 border-blue-200">
                <Rocket className="h-4 w-4 text-blue-600" />
                <AlertTitle className="text-blue-800">Final Overview</AlertTitle>
                <AlertDescription className="text-blue-700">
                    You have a complete, professional-grade platform. The focus now shifts from *building* to *operating* and *selling*. This playbook contains your strategy and technical steps to launch.
                </AlertDescription>
            </Alert>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Left Column: Strategy */}
                <div className="space-y-8">
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2"><Target /> Strategic Stance for Market Entry</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="mb-4">Your core advantage is offering a **Service, Not Just Software**. This is your winning bet.</p>
                            <ul className="space-y-2 text-sm">
                                <li className="flex items-start gap-2"><CheckCircle className="w-4 h-4 mt-0.5 text-green-500 flex-shrink-0" /><span>Target overwhelmed small businesses who need a finished result, not another tool.</span></li>
                                <li className="flex items-start gap-2"><CheckCircle className="w-4 h-4 mt-0.5 text-green-500 flex-shrink-0" /><span>Deliver a fixed-price **CMMC readiness outcome**, using your AI platform as an internal efficiency engine.</span></li>
                                <li className="flex items-start gap-2"><CheckCircle className="w-4 h-4 mt-0.5 text-green-500 flex-shrink-0" /><span>Your primary sales tool is the <Link to={createPageUrl('DeploymentActionPlan')} className="font-semibold text-blue-600 underline">Deployment Action Plan</Link>.</span></li>
                            </ul>
                        </CardContent>
                    </Card>

                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2"><DollarSign /> Minimalist Cost Structure</CardTitle>
                        </CardHeader>
                        <CardContent>
                           <p className="mb-4">Your infrastructure is designed for extreme capital efficiency. The business is self-funding after the first client.</p>
                            <ul className="space-y-2 text-sm">
                                <li><strong>One-Time Setup:</strong> ~$15 (Domain Registration)</li>
                                <li><strong>Monthly (Pre-Client):</strong> ~$5-10 (AWS Route 53, Email, minimal EC2 usage within Free Tier)</li>
                                <li><strong>Monthly (Post-Client):</strong> ~$25-50 (Covered by revenue)</li>
                            </ul>
                             <Button asChild variant="link" className="p-0 h-auto mt-2">
                                <Link to={createPageUrl('MarketEntryCost')}>View Detailed Cost Breakdown <ArrowRight className="w-4 h-4 ml-1"/></Link>
                            </Button>
                        </CardContent>
                    </Card>

                     <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2"><Scale /> Legal & Compliance Framework</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="mb-4">Your legal posture is **Preparation, Not Certification**. All client-facing materials must reflect this.</p>
                             <ul className="space-y-2 text-sm">
                                <li className="flex items-start gap-2"><CheckCircle className="w-4 h-4 mt-0.5 text-green-500 flex-shrink-0" /><span>Website disclaimers are ready.</span></li>
                                <li className="flex items-start gap-2"><CheckCircle className="w-4 h-4 mt-0.5 text-green-500 flex-shrink-0" /><span>Master Service Agreement templates are prepared.</span></li>
                                <li className="flex items-start gap-2"><CheckCircle className="w-4 h-4 mt-0.5 text-green-500 flex-shrink-0" /><span>Invoice terms are defined.</span></li>
                            </ul>
                            <Alert variant="destructive" className="mt-4">
                                <AlertTitle>Action Required</AlertTitle>
                                <AlertDescription>You must have these documents reviewed by qualified legal counsel before engaging clients.</AlertDescription>
                            </Alert>
                             <Button asChild variant="link" className="p-0 h-auto mt-2">
                                <Link to={createPageUrl('ProfessionalTransformation')}>Review Legal Templates <ArrowRight className="w-4 h-4 ml-1"/></Link>
                            </Button>
                        </CardContent>
                    </Card>
                </div>

                {/* Right Column: Technical Steps */}
                <Card className="lg:col-span-1">
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2"><Rocket/> Execution Plan: Migration & Launch</CardTitle>
                        <CardDescription>Your technical next steps to migrate from Base44 to your self-hosted AWS environment.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <Tabs defaultValue="step1">
                            <TabsList className="grid w-full grid-cols-3">
                                <TabsTrigger value="step1">1. Local Setup</TabsTrigger>
                                <TabsTrigger value="step2">2. Server Config</TabsTrigger>
                                <TabsTrigger value="step3">3. Deployment</TabsTrigger>
                            </TabsList>
                            <TabsContent value="step1" className="p-4 border rounded-b-md">
                                <h3 className="font-semibold text-lg mb-2">Step 1: GitHub & VS Code Setup</h3>
                                <p className="text-sm text-gray-600 mb-4">Create a local version of your application to manage with standard developer tools.</p>
                                <ol className="list-decimal pl-5 space-y-2 text-sm">
                                    <li>Download your entire application code from the Base44 platform.</li>
                                    <li>Open the project folder in Visual Studio Code.</li>
                                    <li>Initialize a Git repository: `git init`</li>
                                    <li>Create a new repository on GitHub.com.</li>
                                    <li>Link your local folder to GitHub: `git remote add origin [YOUR_GITHUB_REPO_URL]`</li>
                                    <li>Make your first commit and push: `git add .`, `git commit -m "Initial commit"`, `git push -u origin main`</li>
                                </ol>
                            </TabsContent>
                            <TabsContent value="step2" className="p-4 border rounded-b-md">
                                <h3 className="font-semibold text-lg mb-2">Step 2: Configure EC2 Server</h3>
                                <p className="text-sm text-gray-600 mb-4">Prepare your AWS EC2 instance to host a professional web application.</p>
                                <CodeBlock content={serverSetupCommands} title="Server Setup Commands" />
                                <Alert className="mt-2">
                                    <AlertDescription>After running these, follow the <Link to={createPageUrl('AWSImplementationGuide')} className="font-semibold text-blue-600 underline">full guide</Link> to configure Nginx and SSL.</AlertDescription>
                                </Alert>
                            </TabsContent>
                            <TabsContent value="step3" className="p-4 border rounded-b-md">
                                <h3 className="font-semibold text-lg mb-2">Step 3: Deploy Your Application</h3>
                                <p className="text-sm text-gray-600 mb-4">Use a script to automate building your application and moving it to your live server.</p>
                                <CodeBlock content={deploymentScript} title="deploy.sh" />
                                 <Alert className="mt-2">
                                    <AlertTitle>How to Use</AlertTitle>
                                    <AlertDescription>Save this script as `deploy.sh` in your project's root folder. Make it executable (`chmod +x deploy.sh`) and run it (`./deploy.sh`) to deploy changes.</AlertDescription>
                                </Alert>
                            </TabsContent>
                        </Tabs>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}