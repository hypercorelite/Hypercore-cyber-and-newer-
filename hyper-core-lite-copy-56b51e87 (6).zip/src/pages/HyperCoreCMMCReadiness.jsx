
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { CheckCircle, ArrowRight, Shield, FileText, DollarSign, CalendarDays, Layers, Bot, Gavel, UserCheck } from 'lucide-react';
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import DisclaimerBanner from '../components/legal/DisclaimerBanner';

const serviceDeliverables = [
    { 
        category: 'Core Documentation & Planning (AI-Generated Drafts)',
        items: [
            { name: 'System Security Plan (SSP) Template', role: 'A comprehensive, AI-generated starting point for your SSP, requiring your team\'s review and finalization.' },
            { name: '18 Core CMMC Policy Templates', role: 'A full suite of required policy documents, ready for your team to adapt and adopt.' },
            { name: 'Plan of Action & Milestones (POA&M) Draft', role: 'An initial, AI-identified roadmap for addressing compliance gaps, to be managed by your team.' },
        ]
    },
    {
        category: 'Evidence & Implementation Guidance',
        items: [
            { name: 'Evidence Collection Guidance Package', role: 'Organized checklists and templates to guide your team in collecting evidence for each CMMC control.' },
            { name: 'Implementation Guide', role: 'Step-by-step documentation explaining what was implemented and how to maintain it.' },
            { name: 'AI-Powered Support', role: 'Instant answers from our AI assistant and email escalation to human experts for complex questions.' }
        ]
    }
];

const timelinePhases = [
    {
        phase: "Phase 1: Foundation & Quick Wins (Days 1-30)",
        description: "We execute the service agreement and you remit the initial 50% deposit. We then deliver your complete AI-generated policy documentation suite (14 policies), initial SSP, and a full gap analysis."
    },
    {
        phase: "Phase 2: Guided Evidence Collection (Days 31-75)",
        description: "Through weekly coaching sessions, we guide your team in collecting the specific evidence required to prove each CMMC control is met, continuously refining your SSP and POA&M."
    },
    {
        phase: "Phase 3: Final Package Delivery & Handoff (Days 76-90)",
        description: "We help you assemble your final, C3PAO-formatted evidence package. Upon delivery and your approval, the final 50% payment is due."
    }
];

export default function HyperCoreCMMCReadiness() {
    return (
        <div className="min-h-screen bg-white p-4 lg:p-8">
            <div className="max-w-6xl mx-auto">
                <motion.div
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="text-center mb-12"
                >
                    <Badge className="mb-4 bg-blue-100 text-blue-800" variant="outline">The HyperCore Program</Badge>
                    <h1 className="text-4xl lg:text-5xl font-extrabold text-gray-900 mb-4 tracking-tight">
                        90-Day CMMC Audit Preparedness Program
                    </h1>
                    <p className="text-lg lg:text-xl text-gray-600 max-w-4xl mx-auto">
                        Our expert-guided tutoring model provides everything your team needs to prepare for a CMMC Level 2 assessment.
                    </p>
                </motion.div>

                <div className="mb-12">
                  <DisclaimerBanner />
                </div>

                <Card className="mb-12 bg-gradient-to-r from-blue-600 to-indigo-700 text-white">
                    <CardHeader>
                        <CardTitle className="text-center text-3xl font-bold">$12,500 Fixed-Fee</CardTitle>
                        <CardDescription className="text-center text-lg text-blue-200">Expert-guided preparation program. One price for complete audit readiness.</CardDescription>
                    </CardHeader>
                    <CardContent className="text-center">
                        <p className="text-blue-100 mb-4">Also available: $5,000 AI Documentation Kickstarter for experienced teams.</p>
                        <Button asChild size="lg" className="bg-white text-indigo-700 hover:bg-gray-100">
                            <Link to={createPageUrl('ProgramDetails')}>
                                View All Program Options <ArrowRight className="w-4 h-4 ml-2" />
                            </Link>
                        </Button>
                    </CardContent>
                </Card>

                <Alert className="bg-blue-50 border-blue-200 mb-12">
                    <Bot className="h-4 w-4 text-blue-600" />
                    <AlertTitle className="text-blue-800">Our Role: Your AI-Powered Compliance Partner</AlertTitle>
                    <AlertDescription className="text-blue-700">
                        We provide the AI tools, templates, and expert guidance. Your team provides the specifics about your environment. Together, we prepare your organization for a successful C3PAO assessment. This entire process is free to try until December 5th, 2025.
                    </AlertDescription>
                </Alert>
                
                <div className="mb-12">
                     <h2 className="text-3xl font-bold text-center mb-8 text-gray-800">What You Get: A Breakdown of Deliverables</h2>
                     <div className="space-y-8">
                        {serviceDeliverables.map((category, index) => (
                            <motion.div 
                                key={index}
                                initial={{ opacity: 0, y: 20 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: index * 0.1 }}
                            >
                                <Card>
                                    <CardHeader>
                                        <CardTitle>{category.category}</CardTitle>
                                    </CardHeader>
                                    <CardContent>
                                        <ul className="space-y-4">
                                            {category.items.map((item, i) => (
                                                <li key={i} className="flex items-start gap-3">
                                                    <UserCheck className="w-5 h-5 text-green-600 mt-1 flex-shrink-0" />
                                                    <div>
                                                        <h4 className="font-semibold">{item.name}</h4>
                                                        <p className="text-sm text-gray-600">{item.role}</p>
                                                    </div>
                                                </li>
                                            ))}
                                        </ul>
                                    </CardContent>
                                    </Card>
                            </motion.div>
                        ))}
                    </div>
                </div>

                <Alert className="bg-yellow-50 border-yellow-300 mb-12">
                    <DollarSign className="h-4 w-4 text-yellow-700" />
                    <AlertTitle className="font-semibold text-yellow-800">Our Conditional 90-Day Guarantee</AlertTitle>
                    <AlertDescription className="text-yellow-700">
                        Our money-back satisfaction guarantee is conditional on your team's active participation and completion of 80% of the Success Plan milestones. We guarantee our expert guidance, not a specific audit outcome.
                        <Link to={createPageUrl('Legal')} className="font-semibold underline hover:text-yellow-800 ml-2">
                            Read the full MSA clause here.
                        </Link>
                    </AlertDescription>
                </Alert>

                <Card className="mb-12">
                    <CardHeader>
                        <CardTitle>Structured 90-Day Timeline & Payment Schedule</CardTitle>
                        <CardDescription>Our process is designed for clarity, momentum, and accountability.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                        {timelinePhases.map((phase, index) => (
                            <div key={index} className="flex items-start gap-4">
                                <div className="flex-shrink-0 w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center font-bold text-gray-700">{index + 1}</div>
                                <div>
                                    <h4 className="font-semibold">{phase.phase}</h4>
                                    <p className="text-sm text-gray-600">{phase.description}</p>
                                </div>
                            </div>
                        ))}
                         <Alert className="bg-green-50 border-green-200">
                            <DollarSign className="h-4 w-4 text-green-700" />
                            <AlertTitle className="font-semibold">Professional Payment Terms</AlertTitle>
                            <AlertDescription className="text-green-700">
                                We operate on a 50% upfront, 50% upon-completion model via secure wire transfer with Net-30 terms, reflecting standard, professional B2B engagement practices. ($6,250 upfront, $6,250 on completion for the full program)
                            </AlertDescription>
                        </Alert>
                    </CardContent>
                </Card>

                <Card className="mb-12 bg-blue-50 border-blue-200">
                    <CardHeader>
                        <CardTitle className="text-blue-800">Your Role: 75 Minutes, Not 8 Weeks</CardTitle>
                        <CardDescription className="text-blue-700">The 8-week timeline is our processing time. Your total active time commitment is minimal.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div className="flex items-start gap-3">
                            <CheckCircle className="w-5 h-5 text-blue-600 mt-1 flex-shrink-0" />
                            <div>
                                <h4 className="font-semibold">30 Minutes (Week 1): One-Time Document Upload</h4>
                                <p className="text-sm text-blue-700">Upload your current policies, network diagrams, and system documentation. The AI handles the rest.</p>
                            </div>
                        </div>
                        <div className="flex items-start gap-3">
                            <CheckCircle className="w-5 h-5 text-blue-600 mt-1 flex-shrink-0" />
                            <div>
                                <h4 className="font-semibold">30 Minutes (Week 2): Review AI-Generated Content</h4>
                                <p className="text-sm text-blue-700">Review and approve the AI-generated policies and System Security Plan draft. Simple yes/no decisions.</p>
                            </div>
                        </div>
                         <div className="flex items-start gap-3">
                            <CheckCircle className="w-5 h-5 text-blue-600 mt-1 flex-shrink-0" />
                            <div>
                                <h4 className="font-semibold">15 Minutes (Week 8): Download Final Package</h4>
                                <p className="text-sm text-blue-700">Receive your complete, audit-ready documentation package. No ongoing maintenance required from you.</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>

                <Alert variant="destructive" className="mb-12 p-6">
                    <Gavel className="h-5 w-5" />
                    <AlertTitle className="font-bold text-xl">Critical Service Expectation</AlertTitle>
                    <AlertDescription className="text-base mt-2">
                        HyperCore AI provides **CMMC preparation training and guidance services only.** We are not a C3PAO and do not conduct official assessments or grant certifications. Final compliance determination is made solely by an independent C3PAO. 
                        <Link to={createPageUrl('Legal')} className="font-semibold underline hover:text-red-700 ml-2">
                            Read our full legal responsibilities here.
                        </Link>
                    </AlertDescription>
                </Alert>

                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                >
                    <Card className="text-center bg-gray-900 text-white">
                        <CardContent className="p-8 lg:p-10">
                            <h3 className="text-2xl font-bold mb-4">Secure Your Place in the Defense Supply Chain</h3>
                            <p className="text-gray-300 mb-6 max-w-2xl mx-auto">
                                The CMMC mandate is an immediate business reality. Let's start your 90-day guided journey to compliance today.
                            </p>
                            <div className="flex flex-col sm:flex-row gap-4 justify-center">
                                <Button asChild size="lg" className="bg-white text-gray-900 hover:bg-gray-200">
                                    <Link to={createPageUrl('PartnershipInquiry')}>
                                        Request Engagement Agreement <ArrowRight className="w-4 h-4 ml-2" />
                                    </Link>
                                </Button>
                                <Button asChild size="lg" variant="outline" className="border-gray-500 text-white hover:bg-gray-800">
                                     <Link to={createPageUrl('PartnershipTrial')}>
                                        Take the Free Assessment First
                                    </Link>
                                </Button>
                            </div>
                            
                            <div className="mt-6 pt-6 border-t border-gray-700">
                                <p className="text-sm text-gray-400 mb-3">Want to see the detailed week-by-week breakdown?</p>
                                <Button asChild variant="link" className="text-gray-300 hover:text-white">
                                    <Link to={createPageUrl('NinetyDayDeliveryReality')}>
                                        View Realistic 90-Day Timeline <ArrowRight className="w-4 h-4 ml-1" />
                                    </Link>
                                </Button>
                            </div>
                        </CardContent>
                    </Card>
                </motion.div>

                <Alert className="bg-gray-100 border-gray-200 mt-12">
                    <Layers className="h-4 w-4 text-gray-700" />
                    <AlertTitle className="font-semibold text-gray-800">Expanding Your Compliance Horizon?</AlertTitle>
                    <AlertDescription className="text-gray-600 mt-2">
                        Our platform's architecture is built on the NIST framework, making it easily adaptable to other standards like SOC 2 and ISO 27001. Secure your DoD contracts today, and let's discuss your broader compliance needs tomorrow.
                        <Link to={createPageUrl('ComplianceSolutions')} className="text-blue-600 font-semibold hover:underline flex items-center gap-1 mt-2">
                            Learn About Other Frameworks We Support <ArrowRight className="w-4 h-4" />
                        </Link>
                    </AlertDescription>
                </Alert>

            </div>
        </div>
    );
}
