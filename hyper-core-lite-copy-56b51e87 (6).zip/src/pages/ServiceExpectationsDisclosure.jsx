import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { FileText, UserPlus, Link as LinkIcon, Loader2, Copy } from 'lucide-react';
import { ComplianceFramework } from '@/api/entities';
import { ComplianceTask } from '@/api/entities';
import { toast } from "sonner";
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";

// CMMC Controls data directly in component instead of importing
const cmmcControls = [
    {
        id: "3.1.1",
        title: "Limit system access to authorized users",
        description: "The organization limits system access to authorized users, processes acting on behalf of authorized users, or devices (including other systems) and to the types of transactions and functions that authorized users are permitted to exercise.",
        priority: "high"
    },
    {
        id: "3.1.2", 
        title: "Limit system access to transaction types",
        description: "The organization limits system access to the types of transactions and functions that authorized users are permitted to exercise.",
        priority: "medium"
    },
    {
        id: "3.3.1",
        title: "Create and retain audit logs",
        description: "The organization creates, protects, and retains system audit records to the extent needed to enable the monitoring, analysis, investigation, and reporting of unlawful, unauthorized, or inappropriate system activity.",
        priority: "high"
    },
    {
        id: "3.4.1",
        title: "Establish configuration baselines",
        description: "The organization establishes and maintains baseline configurations and inventories of information systems (including hardware, software, firmware, and documentation) as components of those systems.",
        priority: "medium"
    },
    {
        id: "3.5.1",
        title: "Identify system users and processes",
        description: "The organization identifies information system users, processes acting on behalf of users, or devices.",
        priority: "high"
    }
    // Add more controls as needed - this is a sample set
];

export default function ServiceExpectationsDisclosure() {
    const [organizationName, setOrganizationName] = useState('');
    const [generating, setGenerating] = useState(false);
    const [generatedUrl, setGeneratedUrl] = useState('');

    const handleCreateProject = async () => {
        if (!organizationName) {
            toast.error("Organization Name is required.");
            return;
        }

        setGenerating(true);
        setGeneratedUrl('');

        try {
            // Step 1: Create the Compliance Framework for the client
            const framework = await ComplianceFramework.create({
                framework_name: "CMMC",
                organization_name: organizationName,
                compliance_status: "in_progress",
                ai_agent_assigned: "cmmc_assessment_agent"
            });

            // Step 2: Create all CMMC tasks linked to this framework
            const tasksToCreate = cmmcControls.map(control => ({
                framework_id: framework.id,
                task_title: control.title,
                requirement_section: control.id,
                task_description: control.description,
                task_type: "technical_implementation",
                priority: control.priority,
                status: "pending_ai_analysis"
            }));

            await ComplianceTask.bulkCreate(tasksToCreate);

            // Step 3: Generate the unique portal URL
            const portalUrl = createPageUrl(`CMMCReadinessAssessment?frameworkId=${framework.id}`);
            setGeneratedUrl(window.location.origin + portalUrl);
            
            toast.success("Client project created successfully!");

        } catch (error) {
            console.error("Failed to create client project:", error);
            toast.error("Failed to create project. See console for details.");
        } finally {
            setGenerating(false);
        }
    };
    
    const copyToClipboard = () => {
        navigator.clipboard.writeText(generatedUrl);
        toast.success("URL Copied to clipboard!");
    };

    return (
        <div className="max-w-4xl mx-auto p-4 sm:p-6 lg:p-8">
            <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                className="mb-8"
            >
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-3 text-2xl">
                            <UserPlus className="w-6 h-6 text-blue-600" />
                            Onboard New CMMC Client
                        </CardTitle>
                        <CardDescription>
                            Create a new compliance project and generate a secure, unique portal link for your client.
                        </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                        <div className="space-y-2">
                            <label htmlFor="orgName" className="font-medium">Client Organization Name</label>
                            <Input
                                id="orgName"
                                placeholder="e.g., ACME Defense Corp"
                                value={organizationName}
                                onChange={(e) => setOrganizationName(e.target.value)}
                            />
                        </div>
                        <Button onClick={handleCreateProject} disabled={generating || !organizationName}>
                            {generating ? (
                                <>
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                    Generating Project...
                                </>
                            ) : (
                               "Create Client Project & Generate Link"
                            )}
                        </Button>

                        {generatedUrl && (
                            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
                                <Alert>
                                    <LinkIcon className="h-4 w-4" />
                                    <AlertTitle>Client Portal Link Generated!</AlertTitle>
                                    <AlertDescription className="break-all mt-2">
                                        <p className="mb-4">Send this unique and secure link to your client to access their CMMC readiness portal.</p>
                                        <div className="flex items-center gap-2 p-2 bg-gray-100 rounded-md">
                                            <Input readOnly value={generatedUrl} className="bg-white"/>
                                            <Button size="icon" variant="ghost" onClick={copyToClipboard}>
                                                <Copy className="w-4 h-4" />
                                            </Button>
                                        </div>
                                    </AlertDescription>
                                </Alert>
                            </motion.div>
                        )}
                    </CardContent>
                </Card>
            </motion.div>
        </div>
    );
}