
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { CheckCircle, Server, Shield, Zap, DollarSign, ArrowRight, Target, Building, Clock, Link as LinkIcon, Code } from 'lucide-react';

export default function AWSCMMCInheritance() {
    
    const marketReality = {
        traditionalPath: {
            preparation: "6-18+ months",
            consultingCosts: "$50,000 - $200,000+",
            assessmentFee: "$40,000 - $80,000",
            remediationCosts: "Tens to hundreds of thousands",
            totalCost: "$150,000 - $400,000+",
            passRate: "Most find some level of non-compliance",
            timeline: "12-24+ months including remediation cycles"
        },
        hypercoreAdvantage: {
            awsInheritance: "60-70% of controls inherited immediately",
            preparation: "2-3 months",
            totalCost: "$25,000",
            successRate: "Dramatically improved readiness",
            timeline: "90 days to C3PAO-ready"
        }
    };

    const awsInheritedControls = {
        physicalEnvironmental: {
            domain: "PE - Physical & Environmental Protection",
            totalControls: 20,
            inheritedControls: 19,
            inheritancePercentage: 95,
            awsCapabilities: [
                "24/7 physical security with guards and biometric access",
                "Redundant power, cooling, and fire suppression",
                "Geographic redundancy across Availability Zones",
                "Secure disposal of physical media",
                "Environmental monitoring and alerting",
                "Access logging and video surveillance"
            ],
            businessImpact: "Eliminates $50,000+ in physical security infrastructure costs"
        },
        maintenance: {
            domain: "MA - Maintenance",
            totalControls: 6,
            inheritedControls: 6,
            inheritancePercentage: 100,
            awsCapabilities: [
                "AWS manages all underlying infrastructure maintenance",
                "Automated patch management via Systems Manager",
                "Maintenance windows handled by AWS",
                "No physical access required by customers",
                "All maintenance activities logged via CloudTrail"
            ],
            businessImpact: "Eliminates dedicated maintenance staff requirements"
        },
        systemCommunications: {
            domain: "SC - System & Communications Protection",
            totalControls: 28,
            inheritedControls: 20,
            inheritancePercentage: 71,
            awsCapabilities: [
                "VPC provides network segmentation",
                "Security Groups for granular traffic control",
                "AWS Shield for DDoS protection",
                "KMS for encryption key management",
                "TLS 1.3 encryption in transit",
                "CloudFront for secure content delivery"
            ],
            businessImpact: "Eliminates $30,000+ network security appliance costs"
        },
        systemIntegrity: {
            domain: "SI - System & Information Integrity",
            totalControls: 16,
            inheritedControls: 12,
            inheritancePercentage: 75,
            awsCapabilities: [
                "AWS Inspector for vulnerability scanning",
                "GuardDuty for threat detection",
                "CloudWatch for system monitoring",
                "AWS Config for configuration monitoring",
                "Trusted Advisor for security recommendations"
            ],
            businessImpact: "Replaces $20,000+ annual security monitoring tools"
        }
    };

    const technicalIntegration = {
        azurePolicy: {
            title: "Azure Policy Integration",
            goal: "Enforcing CMMC controls for encryption (SC.L2-3.13.16)",
            description: "CMMC requires organizations to 'protect the confidentiality of CUI at rest.' Our platform leverages Azure Policy to enforce this at scale.",
            howItWorks: [
                {
                    step: "1. Define Policy",
                    detail: "We use Azure Policy to create a policy requiring all VMs and storage accounts in the CUI environment to have encryption enabled, leveraging built-in NIST SP 800-171 policies that map to CMMC."
                },
                {
                    step: "2. Continuous Monitoring",
                    detail: "Our dashboard integrates with Azure Policy to continuously monitor compliance, showing exactly which resources are compliant and which are not in real-time."
                },
                {
                    step: "3. Automated Remediation",
                    detail: "If a new storage account is created without encryption, an automated workflow is triggered to either flag it for review or automatically encrypt the resource, logging the action as evidence."
                },
                {
                    step: "4. Audit-Ready Reporting",
                    detail: "We aggregate compliance data into reports, providing a verifiable log of continuous adherence to encryption controls for auditors."
                }
            ],
            codeSnippet: `
// Azure Policy Definition (JSON)
{
  "if": {
    "allOf": [
      {
        "field": "type",
        "equals": "Microsoft.Storage/storageAccounts"
      },
      {
        "field": "Microsoft.Storage/storageAccounts/supportsHttpsTrafficOnly",
        "equals": "false"
      }
    ]
  },
  "then": {
    "effect": "audit"
  }
}`
        },
        awsConfig: {
            title: "AWS Config Integration",
            goal: "Monitoring configuration changes for CMMC (CM.L2-3.4.2)",
            description: "CMMC requires organizations to 'enforce and review configurations.' AWS Config is a key tool for inventorying and evaluating resource configurations.",
            howItWorks: [
                {
                    step: "1. Continuous Recording",
                    detail: "Our platform integrates with AWS Config to continuously monitor all resources in your CUI enclave (e.g., AWS GovCloud), automatically recording every configuration change."
                },
                {
                    step: "2. Rule Evaluation",
                    detail: "We leverage AWS Config Rules to check for compliance. For example, a rule ensures no S3 bucket storing CUI is ever made public."
                },
                {
                    step: "3. AI-Powered Alerting",
                    detail: "If a misconfiguration occurs, AWS Config notifies our platform. Our AI analyzes the alert and provides insights on its impact to your overall CMMC posture."
                },
                {
                    step: "4. Auditor Evidence",
                    detail: "We centralize all AWS Config data, including configuration history, providing auditors with a verifiable log of all changes and monitoring activities."
                }
            ],
            codeSnippet: `
# AWS Config Rule (YAML snippet)
Resources:
  S3BucketPublicReadProhibited:
    Type: "AWS::Config::ConfigRule"
    Properties:
      ConfigRuleName: "s3-bucket-public-read-prohibited"
      Description: "Checks that S3 buckets do not allow public read access."
      Source:
        Owner: "AWS"
        SourceIdentifier: "S3_BUCKET_PUBLIC_READ_PROHIBITED"`
        }
    };

    return (
        <div className="min-h-screen bg-gray-50 p-6">
            <div className="max-w-7xl mx-auto">
                <header className="text-center mb-12">
                    <h1 className="text-4xl font-bold text-gray-900 mb-3 flex items-center justify-center gap-3">
                        <Server className="w-10 h-10 text-blue-600" />
                        The AWS CMMC Compliance Accelerator
                    </h1>
                    <p className="text-xl text-gray-600">
                        How HyperCore and AWS eliminate up to 70% of your CMMC compliance burden before you even start.
                    </p>
                </header>

                <Tabs defaultValue="overview" className="space-y-6">
                    <TabsList className="grid w-full grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
                        <TabsTrigger value="overview">Market Reality Check</TabsTrigger>
                        <TabsTrigger value="inheritance">AWS Inheritance Advantage</TabsTrigger>
                        <TabsTrigger value="integration">Technical Integration Deep-Dive</TabsTrigger>
                    </TabsList>
                    
                    <TabsContent value="overview">
                        <Card className="bg-red-50 border-red-200">
                            <CardHeader>
                                <CardTitle className="text-red-800">The Problem: The Traditional CMMC Path is Broken</CardTitle>
                                <CardDescription>Most contractors fail their first audit, leading to costly remediation cycles.</CardDescription>
                            </CardHeader>
                            <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div>
                                    <h4 className="font-semibold text-gray-700 mb-2">Traditional Path (High Risk)</h4>
                                    <ul className="space-y-1 text-sm">
                                        <li className="flex items-center gap-2"><Clock className="w-4 h-4 text-red-500" /> <span>{marketReality.traditionalPath.timeline}</span></li>
                                        <li className="flex items-center gap-2"><DollarSign className="w-4 h-4 text-red-500" /> <span>{marketReality.traditionalPath.totalCost}</span></li>
                                        <li className="flex items-center gap-2"><Target className="w-4 h-4 text-red-500" /> <span>{marketReality.traditionalPath.passRate}</span></li>
                                    </ul>
                                </div>
                                <div>
                                    <h4 className="font-semibold text-green-700 mb-2">HyperCore on AWS (Strategic Advantage)</h4>
                                    <ul className="space-y-1 text-sm">
                                        <li className="flex items-center gap-2"><Clock className="w-4 h-4 text-green-500" /> <span>{marketReality.hypercoreAdvantage.timeline}</span></li>
                                        <li className="flex items-center gap-2"><DollarSign className="w-4 h-4 text-green-500" /> <span>{marketReality.hypercoreAdvantage.totalCost}</span></li>
                                        <li className="flex items-center gap-2"><Shield className="w-4 h-4 text-green-500" /> <span>{marketReality.hypercoreAdvantage.awsInheritance}</span></li>
                                    </ul>
                                </div>
                            </CardContent>
                        </Card>
                    </TabsContent>

                    <TabsContent value="inheritance">
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                            {Object.values(awsInheritedControls).map((control, index) => (
                                <Card key={index} className="flex flex-col">
                                    <CardHeader>
                                        <CardTitle>{control.domain}</CardTitle>
                                        <div className="flex items-center justify-between">
                                            <Badge className="bg-blue-100 text-blue-800">{control.inheritedControls} / {control.totalControls} Controls Inherited</Badge>
                                            <div className="text-right">
                                                <div className="text-2xl font-bold text-blue-600">{control.inheritancePercentage}%</div>
                                                <div className="text-xs text-gray-500">Inheritance</div>
                                            </div>
                                        </div>
                                        <Progress value={control.inheritancePercentage} className="mt-2" />
                                    </CardHeader>
                                    <CardContent className="flex-grow">
                                        <h4 className="font-semibold mb-2 text-sm">Key AWS Capabilities:</h4>
                                        <ul className="space-y-1 text-xs list-disc list-inside">
                                            {control.awsCapabilities.slice(0, 4).map((cap, i) => <li key={i}>{cap}</li>)}
                                        </ul>
                                    </CardContent>
                                    <div className="p-4 bg-gray-100 mt-auto">
                                        <p className="text-xs font-semibold text-green-700">{control.businessImpact}</p>
                                    </div>
                                </Card>
                            ))}
                        </div>
                    </TabsContent>

                    <TabsContent value="integration">
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                            {/* AWS Config Integration */}
                            <Card className="border-orange-300">
                                <CardHeader>
                                    <div className="flex items-center gap-2">
                                        <img src="https://a0.awsstatic.com/libra-css/images/logos/aws_logo_smile_1200x630.png" alt="AWS Logo" className="w-10 h-auto" />
                                        <CardTitle className="text-xl">AWS Config Integration</CardTitle>
                                    </div>
                                    <CardDescription>{technicalIntegration.awsConfig.goal}</CardDescription>
                                </CardHeader>
                                <CardContent>
                                    <p className="text-sm mb-4">{technicalIntegration.awsConfig.description}</p>
                                    <div className="space-y-3">
                                        {technicalIntegration.awsConfig.howItWorks.map((item, index) => (
                                            <div key={index} className="flex items-start gap-3">
                                                <CheckCircle className="w-5 h-5 text-green-500 mt-1 flex-shrink-0" />
                                                <div>
                                                    <h4 className="font-semibold text-sm">{item.step}</h4>
                                                    <p className="text-xs text-gray-600">{item.detail}</p>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                    <Card className="bg-slate-900 text-white font-mono mt-4">
                                        <CardHeader className="pb-2">
                                            <CardTitle className="text-sm text-slate-300 flex items-center gap-2"><Code className="w-4 h-4"/>Example Config Rule</CardTitle>
                                        </CardHeader>
                                        <CardContent className="p-3 pt-0"><pre className="overflow-x-auto text-xs"><code>{technicalIntegration.awsConfig.codeSnippet}</code></pre></CardContent>
                                    </Card>
                                </CardContent>
                            </Card>
                            
                            {/* Azure Policy Integration */}
                            <Card className="border-blue-300">
                                <CardHeader>
                                    <div className="flex items-center gap-2">
                                        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/a/a8/Microsoft_Azure_Logo.svg/1200px-Microsoft_Azure_Logo.svg.png" alt="Azure Logo" className="w-10 h-auto" />
                                        <CardTitle className="text-xl">Azure Policy Integration</CardTitle>
                                    </div>
                                    <CardDescription>{technicalIntegration.azurePolicy.goal}</CardDescription>
                                </CardHeader>
                                <CardContent>
                                    <p className="text-sm mb-4">{technicalIntegration.azurePolicy.description}</p>
                                    <div className="space-y-3">
                                        {technicalIntegration.azurePolicy.howItWorks.map((item, index) => (
                                            <div key={index} className="flex items-start gap-3">
                                                <CheckCircle className="w-5 h-5 text-green-500 mt-1 flex-shrink-0" />
                                                <div>
                                                    <h4 className="font-semibold text-sm">{item.step}</h4>
                                                    <p className="text-xs text-gray-600">{item.detail}</p>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                    <Card className="bg-slate-900 text-white font-mono mt-4">
                                         <CardHeader className="pb-2">
                                            <CardTitle className="text-sm text-slate-300 flex items-center gap-2"><Code className="w-4 h-4"/>Example Policy Definition</CardTitle>
                                        </CardHeader>
                                        <CardContent className="p-3 pt-0"><pre className="overflow-x-auto text-xs"><code>{technicalIntegration.azurePolicy.codeSnippet}</code></pre></CardContent>
                                    </Card>
                                </CardContent>
                            </Card>
                        </div>
                        <Alert className="mt-8 bg-blue-50 border-blue-200">
                            <Zap className="h-4 w-4 text-blue-600" />
                            <AlertTitle className="text-blue-800">Key Benefit: Auditability & Automation</AlertTitle>
                            <AlertDescription className="text-blue-700">
                                These integrations provide automated, well-documented evidence for CMMC assessors, streamlining the audit process and increasing the likelihood of a successful assessment. They enable continuous, near-real-time monitoring at a scale that is unfeasible with manual processes.
                            </AlertDescription>
                        </Alert>
                    </TabsContent>
                </Tabs>

                <div className="mt-12 text-center">
                    <h3 className="text-2xl font-bold text-gray-900">Ready to leverage the cloud for CMMC success?</h3>
                    <p className="text-gray-600 mt-2">See how our platform can accelerate your journey to compliance.</p>
                    <Button size="lg" className="mt-6 bg-blue-600 hover:bg-blue-700">
                        Schedule a Technical Demo <ArrowRight className="w-5 h-5 ml-2" />
                    </Button>
                </div>
            </div>
        </div>
    );
}
