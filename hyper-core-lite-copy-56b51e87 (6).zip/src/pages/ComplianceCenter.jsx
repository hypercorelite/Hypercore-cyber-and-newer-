
import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { ComplianceFramework } from "@/api/entities";
import { ComplianceTask } from "@/api/entities";
import { AIComplianceAgent } from "@/api/entities";
import {
    Shield,
    Bot,
    CheckCircle,
    AlertTriangle,
    Clock,
    Users,
    FileText,
    TrendingUp,
    Zap
} from "lucide-react";
import { motion } from "framer-motion";
import SampleDataLoader from "../components/compliance/SampleDataLoader";

export default function ComplianceCenter() {
    const [frameworks, setFrameworks] = useState([]);
    const [tasks, setTasks] = useState([]);
    const [agents, setAgents] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        loadData();
    }, []);

    const loadData = async () => {
        try {
            const [frameworkData, taskData, agentData] = await Promise.all([
                ComplianceFramework.list('-updated_date', 10),
                ComplianceTask.list('-created_date', 20),
                AIComplianceAgent.list('-last_training_date', 5)
            ]);

            setFrameworks(frameworkData);
            setTasks(taskData);
            setAgents(agentData);
        } catch (error) {
            console.error('Failed to load compliance data:', error);
        } finally {
            setLoading(false);
        }
    };

    const getStatusColor = (status) => {
        const colors = {
            not_started: "bg-gray-100 text-gray-800",
            in_progress: "bg-blue-100 text-blue-800",
            review_required: "bg-yellow-100 text-yellow-800",
            compliant: "bg-green-100 text-green-800",
            non_compliant: "bg-red-100 text-red-800"
        };
        return colors[status] || "bg-gray-100 text-gray-800";
    };

    const getRiskColor = (risk) => {
        const colors = {
            low: "text-green-600",
            medium: "text-yellow-600",
            high: "text-orange-600",
            critical: "text-red-600"
        };
        return colors[risk] || "text-gray-600";
    };

    const pendingApprovals = tasks.filter(task => task.status === 'human_review_required').length;
    const aiCompletedTasks = tasks.filter(task => task.status === 'ai_completed').length;
    const totalTasks = tasks.length;
    const overallProgress = totalTasks > 0 ? Math.round((tasks.filter(t => t.status === 'completed').length / totalTasks) * 100) : 0;

    return (
        <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50 p-6">
            <div className="max-w-7xl mx-auto">
                <motion.div
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="mb-8"
                >
                    <h1 className="text-4xl font-bold text-gray-900 mb-2 flex items-center gap-3">
                        <Shield className="w-10 h-10 text-blue-600" />
                        Compliance Command Center
                    </h1>
                    <p className="text-lg text-gray-600">
                        AI-Powered HIPAA, FERPA & CMMC Compliance Automation
                    </p>
                </motion.div>

                {/* Sample Data Loader - Show only if no data */}
                {frameworks.length === 0 && tasks.length === 0 && agents.length === 0 && !loading && (
                    <div className="mb-8">
                        <SampleDataLoader />
                    </div>
                )}

                {/* Key Metrics */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                    <motion.div
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: 0.1 }}
                    >
                        <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
                            <CardContent className="p-6 text-center">
                                <TrendingUp className="w-12 h-12 text-blue-600 mx-auto mb-4" />
                                <div className="text-3xl font-bold text-blue-600">{overallProgress}%</div>
                                <div className="text-blue-700 font-semibold">Overall Progress</div>
                            </CardContent>
                        </Card>
                    </motion.div>

                    <motion.div
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: 0.2 }}
                    >
                        <Card className="bg-gradient-to-br from-yellow-50 to-yellow-100 border-yellow-200">
                            <CardContent className="p-6 text-center">
                                <Clock className="w-12 h-12 text-yellow-600 mx-auto mb-4" />
                                <div className="text-3xl font-bold text-yellow-600">{pendingApprovals}</div>
                                <div className="text-yellow-700 font-semibold">Pending Reviews</div>
                            </CardContent>
                        </Card>
                    </motion.div>

                    <motion.div
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: 0.3 }}
                    >
                        <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
                            <CardContent className="p-6 text-center">
                                <Bot className="w-12 h-12 text-green-600 mx-auto mb-4" />
                                <div className="text-3xl font-bold text-green-600">{aiCompletedTasks}</div>
                                <div className="text-green-700 font-semibold">AI Completed</div>
                            </CardContent>
                        </Card>
                    </motion.div>

                    <motion.div
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: 0.4 }}
                    >
                        <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
                            <CardContent className="p-6 text-center">
                                <Users className="w-12 h-12 text-purple-600 mx-auto mb-4" />
                                <div className="text-3xl font-bold text-purple-600">{agents.length}</div>
                                <div className="text-purple-700 font-semibold">Active AI Agents</div>
                            </CardContent>
                        </Card>
                    </motion.div>
                </div>

                {/* Compliance Frameworks */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
                    <motion.div
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.5 }}
                    >
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2">
                                    <Shield className="w-5 h-5 text-blue-600" />
                                    Active Compliance Frameworks
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-4">
                                    {frameworks.map((framework, index) => (
                                        <motion.div
                                            key={framework.id}
                                            initial={{ opacity: 0, y: 10 }}
                                            animate={{ opacity: 1, y: 0 }}
                                            transition={{ delay: index * 0.1 }}
                                            className="border rounded-lg p-4 hover:shadow-md transition-shadow"
                                        >
                                            <div className="flex justify-between items-start mb-2">
                                                <div>
                                                    <h3 className="font-semibold text-lg">
                                                        {framework.framework_name} - {framework.organization_name}
                                                    </h3>
                                                    <div className="flex items-center gap-2 mt-1">
                                                        <Badge className={getStatusColor(framework.compliance_status)}>
                                                            {framework.compliance_status.replace('_', ' ')}
                                                        </Badge>
                                                        <span className={`text-sm font-medium ${getRiskColor(framework.risk_level)}`}>
                                                            {framework.risk_level} risk
                                                        </span>
                                                    </div>
                                                </div>
                                                <div className="text-right">
                                                    <div className="text-2xl font-bold text-blue-600">
                                                        {framework.completion_percentage}%
                                                    </div>
                                                </div>
                                            </div>
                                            <Progress value={framework.completion_percentage} className="mb-3" />
                                            <div className="flex items-center justify-between text-sm text-gray-600">
                                                <div className="flex items-center gap-1">
                                                    <Bot className="w-4 h-4" />
                                                    {framework.ai_agent_assigned || 'No agent assigned'}
                                                </div>
                                                <div>
                                                    Target: {framework.target_completion_date ?
                                                        new Date(framework.target_completion_date).toLocaleDateString() :
                                                        'Not set'
                                                    }
                                                </div>
                                            </div>
                                        </motion.div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>
                    </motion.div>

                    {/* AI Agents Performance */}
                    <motion.div
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.6 }}
                    >
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2">
                                    <Bot className="w-5 h-5 text-green-600" />
                                    AI Compliance Specialists
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-4">
                                    {agents.map((agent, index) => (
                                        <motion.div
                                            key={agent.id}
                                            initial={{ opacity: 0, y: 10 }}
                                            animate={{ opacity: 1, y: 0 }}
                                            transition={{ delay: index * 0.1 }}
                                            className="border rounded-lg p-4 bg-gradient-to-r from-green-50 to-blue-50"
                                        >
                                            <div className="flex justify-between items-start mb-2">
                                                <div>
                                                    <h3 className="font-semibold">
                                                        {agent.agent_name}
                                                    </h3>
                                                    <div className="text-sm text-gray-600">
                                                        {agent.specialization.replace('_', ' ')}
                                                    </div>
                                                </div>
                                                <Badge className={agent.status === 'active' ?
                                                    'bg-green-100 text-green-800' :
                                                    'bg-gray-100 text-gray-800'
                                                }>
                                                    {agent.status}
                                                </Badge>
                                            </div>
                                            <div className="grid grid-cols-2 gap-4 text-sm">
                                                <div>
                                                    <span className="text-gray-600">Tasks Completed:</span>
                                                    <div className="font-semibold">{agent.tasks_completed}</div>
                                                </div>
                                                <div>
                                                    <span className="text-gray-600">Accuracy:</span>
                                                    <div className="font-semibold text-green-600">
                                                        {agent.accuracy_rate}%
                                                    </div>
                                                </div>
                                            </div>
                                        </motion.div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>
                    </motion.div>
                </div>

                {/* Human Review Queue */}
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.7 }}
                >
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <AlertTriangle className="w-5 h-5 text-yellow-600" />
                                Human Review Required ({pendingApprovals} items)
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-3">
                                {tasks.filter(task => task.status === 'human_review_required').slice(0, 5).map((task, index) => (
                                    <motion.div
                                        key={task.id}
                                        initial={{ opacity: 0, x: -10 }}
                                        animate={{ opacity: 1, x: 0 }}
                                        transition={{ delay: index * 0.1 }}
                                        className="border rounded-lg p-4 bg-yellow-50 hover:shadow-md transition-shadow"
                                    >
                                        <div className="flex justify-between items-start">
                                            <div>
                                                <h4 className="font-semibold">{task.task_title}</h4>
                                                <p className="text-sm text-gray-600 mt-1">
                                                    {task.requirement_section} • {task.task_type.replace('_', ' ')}
                                                </p>
                                                <div className="text-sm text-gray-700 mt-2">
                                                    <strong>AI Suggestion:</strong> {task.ai_agent_suggestions}
                                                </div>
                                            </div>
                                            <div className="flex gap-2">
                                                <Button size="sm" className="bg-green-600 hover:bg-green-700">
                                                    <CheckCircle className="w-4 h-4 mr-1" />
                                                    Approve
                                                </Button>
                                                <Button size="sm" variant="outline">
                                                    Review
                                                </Button>
                                            </div>
                                        </div>
                                    </motion.div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>
                </motion.div>
            </div>
        </div>
    );
}
