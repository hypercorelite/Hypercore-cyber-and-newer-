
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ArrowRight, Bot, Zap, DollarSign, Target, User, Shield, CheckCircle, X } from 'lucide-react';
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";

const mvpFeatures = {
    core: [
        "AI Gap Analysis Engine (Core)",
        "AI-Generated SSP Draft",
        "AI-Generated POA&M Draft",
        "5 Core AI-Generated Policies",
        "Simple Evidence Upload (No UI)",
        "PDF Report Export"
    ],
    deferred: [
        "Interactive Dashboard UI",
        "Real-time Progress Tracking",
        "Advanced User Management",
        "Full 14-Policy Suite Automation",
        "Automated Evidence Mapping"
    ]
};

const budget = {
    sweatEquity: "4 weeks @ 40 hrs/wk = 160 hrs",
    techCosts: [
        { item: "AWS Services (Lambda, S3)", cost: "~$50" },
        { item: "OpenAI API Calls", cost: "~$100" },
        { item: "Database (DynamoDB)", cost: "~$25" }
    ],
    totalCash: "~$175",
    totalValue: "$20,175 (160hrs @ $125/hr + cash)"
};

const pricingTiers = [
    { title: "Free Assessment", price: "$0", features: ["One-time AI Gap Analysis Report"], bestFor: "Lead generation & demonstrating value" },
    { title: "Pro (Self-Service)", price: "$250/mo", features: ["Full AI Toolkit Access", "Unlimited SSP/Policy Generation", "AI Support Agent"], bestFor: "Core recurring revenue" },
    { title: "Enterprise (Guided)", price: "$12,500", features: ["Pro Plan+", "Human Expert Onboarding", "Dedicated Escalation Channel"], bestFor: "Large clients requiring white-glove service" }
];

const valuePropositionComparison = [
    {
        category: "Traditional Consulting (Pivot Point, KLC, Kieri)",
        price: "$15,000 - $50,000+",
        timeline: "3-18 Months",
        model: "Manual, human-led. Limited by consultant availability."
    },
    {
        category: "GRC Software",
        price: "$24,000 - $120,000 / year",
        timeline: "6-12+ Months (DIY)",
        model: "Complex software, requires in-house expertise to operate."
    },
    {
        category: "HyperCore AI (Our Model)",
        price: "$250/mo (Pro) or $12,500 (Enterprise)",
        timeline: "90 Days (AI-Accelerated)",
        model: "AI-first platform with human-in-the-loop expert guidance. Infinitely scalable."
    }
];

export default function StreamlinedActionPlan() {
    return (
        <div className="space-y-8">
            <BreadcrumbNav currentPageName="StreamlinedActionPlan" />

            <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="text-center">
                <Badge className="mb-4 bg-purple-100 text-purple-800">INTERNAL STRATEGY</Badge>
                <h1 className="text-4xl font-bold text-gray-900 mb-4">The Hyperspeed Action Plan</h1>
                <p className="text-xl text-gray-600 max-w-4xl mx-auto">
                    The AI-First Blueprint: From a 4-Week MVP to SBIR Funding and Market Dominance.
                </p>
            </motion.div>

            <Alert className="bg-gradient-to-r from-blue-500 to-purple-600 text-white border-0 shadow-lg">
                <Bot className="h-5 w-5 text-white" />
                <AlertTitle className="text-2xl font-bold">The Strategic Shift: From Service to Product</AlertTitle>
                <AlertDescription className="text-lg mt-2">
                    We are no longer building a tool to make a consultant more efficient. We are building an AI that <strong className="font-bold">IS</strong> the consultant. Every decision must serve scalability and eliminate human bottlenecks.
                </AlertDescription>
            </Alert>

            {/* ADD TIMELINE COMPARISON AT THE TOP */}
            <Card className="bg-gradient-to-r from-yellow-50 to-orange-50 border-2 border-orange-300">
                <CardHeader>
                    <CardTitle className="text-center text-2xl">⚡ Timeline Compression Analysis</CardTitle>
                    <CardDescription className="text-center text-lg">From 16-week learning path to 4-week AI-powered sprint</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="overflow-x-auto">
                        <table className="w-full">
                            <thead>
                                <tr className="border-b">
                                    <th className="text-left p-3">Metric</th>
                                    <th className="text-left p-3 text-gray-600">Old Plan (16-Week Learning)</th>
                                    <th className="text-left p-3 text-blue-600">New Plan (4-Week Sprint)</th>
                                    <th className="text-left p-3">Impact</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr className="border-b">
                                    <td className="p-3 font-medium">Total Timeline</td>
                                    <td className="p-3 text-gray-600">16 weeks (112 days)</td>
                                    <td className="p-3 text-blue-600 font-bold">4 weeks (28 days)</td>
                                    <td className="p-3 text-green-600">75% reduction</td>
                                </tr>
                                <tr className="border-b">
                                    <td className="p-3 font-medium">Total Hours</td>
                                    <td className="p-3 text-gray-600">400+ hours</td>
                                    <td className="p-3 text-blue-600 font-bold">160 hours</td>
                                    <td className="p-3 text-green-600">60% reduction</td>
                                </tr>
                                <tr className="border-b">
                                    <td className="p-3 font-medium">Cash Investment</td>
                                    <td className="p-3 text-gray-600">$780</td>
                                    <td className="p-3 text-blue-600 font-bold">$175</td>
                                    <td className="p-3 text-green-600">78% reduction</td>
                                </tr>
                                <tr className="border-b">
                                    <td className="p-3 font-medium">MVP Completion</td>
                                    <td className="p-3 text-gray-600">January 2025</td>
                                    <td className="p-3 text-blue-600 font-bold">October 2025</td>
                                    <td className="p-3 text-green-600">3 months earlier</td>
                                </tr>
                                <tr className="border-b">
                                    <td className="p-3 font-medium">SBIR Deadline</td>
                                    <td className="p-3 text-red-600">MISSED (Dec 3)</td>
                                    <td className="p-3 text-green-600 font-bold">MET (Dec 3)</td>
                                    <td className="p-3 text-green-600">Critical</td>
                                </tr>
                                <tr className="border-b">
                                    <td className="p-3 font-medium">Market Timing</td>
                                    <td className="p-3 text-red-600">Post-DFARS enforcement</td>
                                    <td className="p-3 text-green-600 font-bold">Pre-DFARS enforcement</td>
                                    <td className="p-3 text-green-600">First-mover advantage</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </CardContent>
            </Card>

            <div className="grid md:grid-cols-2 gap-8">
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2"><Zap className="text-yellow-500"/>The 4-Week AI-First MVP</CardTitle>
                        <CardDescription>Focus exclusively on the core AI processing loop. No UI frills.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <h4 className="font-semibold mb-2 text-green-700">IN SCOPE (Core Features):</h4>
                        <ul className="list-disc list-inside space-y-1 text-sm mb-4">
                            {mvpFeatures.core.map(f => <li key={f}>{f}</li>)}
                        </ul>
                        <h4 className="font-semibold mb-2 text-red-700">OUT OF SCOPE (Deferred Post-MVP):</h4>
                        <ul className="list-disc list-inside space-y-1 text-sm text-gray-500">
                            {mvpFeatures.deferred.map(f => <li key={f}>{f}</li>)}
                        </ul>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2"><DollarSign className="text-green-600"/>Streamlined Budget & Timeline</CardTitle>
                        <CardDescription>Capital-efficient 4-week sprint to SBIR submission.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div>
                            <h4 className="font-semibold">Timeline: 4 Weeks Total</h4>
                            <ol className="text-sm space-y-1 mt-1 list-decimal list-inside">
                                <li><strong>Week 1:</strong> AI Core & Backend Setup</li>
                                <li><strong>Week 2:</strong> Minimalist Frontend & API Integration</li>
                                <li><strong>Week 3:</strong> Write SBIR Proposal (Leveraging MVP)</li>
                                <li><strong>Week 4:</strong> Polish & Submit Grant</li>
                            </ol>
                        </div>
                        <div>
                            <h4 className="font-semibold">Budget</h4>
                             <p className="text-sm"><strong>Founder Investment:</strong> {budget.sweatEquity}</p>
                            <p className="text-sm"><strong>Total Cash Required: <span className="font-bold text-green-700">{budget.totalCash}</span></strong></p>
                            <p className="text-xs text-gray-500">Demonstrates extreme capital efficiency for SBIR reviewers.</p>
                        </div>
                    </CardContent>
                </Card>
            </div>

            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2"><Target className="text-green-500"/>Value Proposition vs. Market</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="space-y-4">
                        {valuePropositionComparison.map(tier => (
                            <div key={tier.category} className={`p-3 rounded-lg ${tier.category.includes('HyperCore') ? 'bg-green-100 border border-green-300' : 'bg-gray-100'}`}>
                                <h4 className={`font-bold ${tier.category.includes('HyperCore') ? 'text-green-800' : 'text-gray-800'}`}>{tier.category}</h4>
                                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-sm mt-1">
                                    <div><strong>Price:</strong> {tier.price}</div>
                                    <div><strong>Timeline:</strong> {tier.timeline}</div>
                                    <div className="sm:col-span-1"><strong>Model:</strong> {tier.model}</div>
                                </div>
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2"><Target className="text-blue-600"/>New Value Proposition & Pricing</CardTitle>
                    <CardDescription>Product-led growth model designed for rapid adoption and scale.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    <div className="grid md:grid-cols-3 gap-4">
                        {pricingTiers.map(tier => (
                            <div key={tier.title} className="p-4 border rounded-lg text-center">
                                <h4 className="font-bold">{tier.title}</h4>
                                <p className="text-2xl font-bold my-2">{tier.price}</p>
                                <p className="text-xs text-gray-600">{tier.bestFor}</p>
                            </div>
                        ))}
                    </div>
                     <Alert>
                        <AlertTitle>The Right Model for Scale</AlertTitle>
                        <AlertDescription>The free assessment drives top-of-funnel growth, the monthly subscription creates a scalable revenue engine, and the enterprise package captures high-value clients without disrupting the core product focus.</AlertDescription>
                    </Alert>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2"><User className="text-purple-600"/>The "Me, Myself, and AI" Impact</CardTitle>
                    <CardDescription>Your role shifts from consultant to system operator.</CardDescription>
                </CardHeader>
                <CardContent className="grid md:grid-cols-2 gap-6">
                    <div className="p-4 bg-red-50 text-red-800 rounded-lg border border-red-200">
                        <h4 className="font-semibold flex items-center gap-2"><X/> NO LONGER:</h4>
                        <ul className="text-sm list-disc list-inside mt-2">
                           <li>Doing client discovery calls</li>
                           <li>Manually reviewing evidence</li>
                           <li>Writing documentation for clients</li>
                           <li>Being the product</li>
                        </ul>
                    </div>
                    <div className="p-4 bg-green-50 text-green-800 rounded-lg border border-green-200">
                        <h4 className="font-semibold flex items-center gap-2"><CheckCircle/> YOUR NEW ROLE:</h4>
                         <ul className="text-sm list-disc list-inside mt-2">
                           <li>Improving the AI prompts</li>
                           <li>Analyzing product usage data</li>
                           <li>Handling L3 human escalations</li>
                           <li>Building the machine</li>
                        </ul>
                    </div>
                </CardContent>
            </Card>

             <Card className="bg-gray-900 text-white">
                <CardHeader>
                    <CardTitle className="text-2xl">The Path Forward: MVP → Grant → Scale</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="flex items-center gap-4">
                        <div className="bg-blue-500 text-white rounded-full w-8 h-8 flex items-center justify-center font-bold flex-shrink-0">1</div>
                        <p><strong>Build AI-First MVP (4 Weeks):</strong> Execute the hyper-efficient sprint defined above.</p>
                    </div>
                    <div className="flex items-center gap-4">
                        <div className="bg-green-500 text-white rounded-full w-8 h-8 flex items-center justify-center font-bold flex-shrink-0">2</div>
                        <p><strong>Secure SBIR Funding:</strong> Use the MVP as a powerful demo of technical feasibility and market understanding to win the grant.</p>
                    </div>
                    <div className="flex items-center gap-4">
                        <div className="bg-purple-500 text-white rounded-full w-8 h-8 flex items-center justify-center font-bold flex-shrink-0">3</div>
                        <p><strong>Commercial Launch & Scale:</strong> Use grant funds to build the full UI, launch the subscription model, and capture the market.</p>
                    </div>
                </CardContent>
            </Card>

        </div>
    );
}
