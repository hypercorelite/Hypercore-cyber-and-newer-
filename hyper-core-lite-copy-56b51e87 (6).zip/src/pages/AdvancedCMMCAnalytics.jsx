import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { BarChart, CheckCircle, Zap, Shield, Target, TrendingUp, DollarSign, ExternalLink } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import BreadcrumbNav from '../components/navigation/BreadcrumbNav';

const toolComparison = [
    { name: "Risk Cognizance GRC", analytics: "AI-powered predictive risk forecasting, automated evidence collection, real-time SPRS scoring.", levels: "1-3", pricing: "$7K-20K/year", strength: "Centralized dashboards for flow-downs; 65% audit time reduction." },
    { name: "TrustCloud", analytics: "ML trend analysis, compliance scoring with confidence intervals, predictive threat intelligence.", levels: "1-2", pricing: "$5K-15K/year", strength: "Proactive gap alerts; 40% faster readiness for CUI handlers." },
    { name: "Drata", analytics: "Automated control mapping, risk heatmaps, anomaly detection via NLP on logs.", levels: "1-3", pricing: "$10K-25K/year", strength: "Strong evidence organization for C3PAO audits." },
    { name: "Vanta", analytics: "Continuous monitoring dashboards, predictive compliance failure modeling, vendor risk analytics.", levels: "1-2", pricing: "$15K-30K/year", strength: "Excellent policy automation for MSPs and tech firms." },
    { name: "HyperCore Cyber", analytics: "Advanced predictive modeling (3-6 month gap forecasts), real-time drift analytics, DFARS clause extraction via NLP.", levels: "1-3", pricing: "$2K-5K/year", strength: "Tailored for NoVA's 31,500 SMBs; 70% flow-down error reduction; local AI deployment." }
];

export default function AdvancedCMMCAnalytics() {
    return (
        <div className="space-y-8 p-4 md:p-6 lg:p-8">
            <BreadcrumbNav currentPageName="Advanced CMMC Analytics" />

            <header className="text-center space-y-4">
                <Badge variant="outline" className="text-blue-600 border-blue-600">AI-Powered Compliance</Badge>
                <h1 className="text-4xl font-bold tracking-tight text-gray-900 sm:text-5xl">
                    Advanced CMMC Analytics: Your Edge in 2025
                </h1>
                <p className="max-w-3xl mx-auto text-lg text-gray-600">
                    Leverage AI and predictive modeling to streamline CMMC 2.0 compliance, automate evidence collection, and mitigate False Claims Act risks for your DoD contracts.
                </p>
            </header>

            <Alert className="bg-blue-50 border-blue-200">
                <BarChart className="h-5 w-5 text-blue-700" />
                <AlertTitle className="font-bold text-blue-800">The 2025 Compliance Shift</AlertTitle>
                <AlertDescription className="text-blue-700">
                    With the CMMC Final Rule now effective, 75% of DIB contractors overestimate their readiness. Advanced analytics are no longer optional—they are essential for survival and growth.
                </AlertDescription>
            </Alert>

            <section id="what-is-analytics">
                <Card>
                    <CardHeader>
                        <CardTitle>What Are Advanced CMMC Analytics?</CardTitle>
                        <CardDescription>Moving beyond checklists to predictive, real-time compliance insights.</CardDescription>
                    </CardHeader>
                    <CardContent className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                        <div className="p-4 bg-gray-50 rounded-lg">
                            <Zap className="w-6 h-6 text-blue-600 mb-2"/>
                            <h3 className="font-semibold">Predictive Risk Modeling</h3>
                            <p className="text-sm text-gray-600">Forecast compliance gaps 3-6 months in advance using machine learning on historical SPRS data.</p>
                        </div>
                        <div className="p-4 bg-gray-50 rounded-lg">
                            <CheckCircle className="w-6 h-6 text-green-600 mb-2"/>
                            <h3 className="font-semibold">Automated Gap Analysis</h3>
                            <p className="text-sm text-gray-600">Scan against all 110 NIST SP 800-171 controls with 95% accuracy, generating POA&Ms in minutes.</p>
                        </div>
                        <div className="p-4 bg-gray-50 rounded-lg">
                            <Target className="w-6 h-6 text-red-600 mb-2"/>
                            <h3 className="font-semibold">Continuous Monitoring</h3>
                            <p className="text-sm text-gray-600">Utilize real-time dashboards for drift detection, integrated with your SIEM/EDR for instant threat response.</p>
                        </div>
                        <div className="p-4 bg-gray-50 rounded-lg">
                            <TrendingUp className="w-6 h-6 text-purple-600 mb-2"/>
                            <h3 className="font-semibold">Supply Chain Visibility</h3>
                            <p className="text-sm text-gray-600">Leverage flow-down analytics to verify subcontractor compliance, reducing errors by over 70%.</p>
                        </div>
                    </CardContent>
                </Card>
            </section>
            
            <section id="tool-comparison">
                <Card>
                    <CardHeader>
                        <CardTitle>2025 Market Landscape: Top Analytics Tools</CardTitle>
                        <CardDescription>A comparison of leading solutions and their core strengths for the DIB.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="overflow-x-auto">
                            <Table>
                                <TableHeader>
                                    <TableRow>
                                        <TableHead>Tool</TableHead>
                                        <TableHead>Core Analytics Features</TableHead>
                                        <TableHead>Pricing (Est. 2025)</TableHead>
                                        <TableHead>Key Strength for NoVA DIB</TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {toolComparison.map((tool) => (
                                        <TableRow key={tool.name} className={tool.name === 'HyperCore Cyber' ? 'bg-green-50' : ''}>
                                            <TableCell className="font-bold">{tool.name}</TableCell>
                                            <TableCell>{tool.analytics}</TableCell>
                                            <TableCell>{tool.pricing}</TableCell>
                                            <TableCell>{tool.strength}</TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </div>
                    </CardContent>
                </Card>
            </section>

            <section id="hypercore-edge">
                <Card className="bg-gradient-to-r from-blue-900 to-gray-800 text-white">
                    <CardHeader>
                        <CardTitle className="flex items-center gap-3"><Shield className="text-green-400"/>The HyperCore Advantage</CardTitle>
                        <CardDescription className="text-blue-200">Why our AI-first, DIB-focused platform delivers unmatched value.</CardDescription>
                    </CardHeader>
                    <CardContent className="grid md:grid-cols-3 gap-6">
                        <div className="space-y-2">
                            <h3 className="font-semibold text-green-300">Predictive Modeling Superiority</h3>
                            <p className="text-sm text-blue-100">Our 3-6 month gap forecasting provides a 25% accuracy gain over Vanta’s basic scoring, enabling true proactive compliance.</p>
                        </div>
                        <div className="space-y-2">
                            <h3 className="font-semibold text-green-300">DFARS & Flow-Down Specialization</h3>
                            <p className="text-sm text-blue-100">Proprietary NLP for DFARS clause extraction reduces subcontractor verification errors by 70%, a critical gap Drata misses.</p>
                        </div>
                        <div className="space-y-2">
                            <h3 className="font-semibold text-green-300">Cost Disruption & Actionability</h3>
                            <p className="text-sm text-blue-100">At $2K-5K/year (50% below market average), we provide not just data but actionable, auto-generated POA&Ms.</p>
                        </div>
                    </CardContent>
                </Card>
            </section>

            <section id="pricing-roi">
                 <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2"><DollarSign className="w-5 h-5 text-green-600"/>Pricing, ROI, and FCA Risk Mitigation</CardTitle>
                    </CardHeader>
                    <CardContent className="grid md:grid-cols-2 gap-8">
                        <div>
                            <h3 className="font-semibold mb-2">Market Pricing vs. HyperCore</h3>
                            <p className="text-sm text-gray-600 mb-4">SMB tiers typically start at $99/month, while enterprise solutions cost $5K-30K annually. High-priced consulting can reach $75K per project.</p>
                            <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                                <p className="font-bold text-green-800">HyperCore's pricing of $2K-5K/year undercuts the market by 50-80%, delivering an ROI of 65% faster audit readiness and saving clients an average of $15K on Level 2 prep.</p>
                            </div>
                        </div>
                        <div>
                            <h3 className="font-semibold mb-2">False Claims Act (FCA) Mitigation</h3>
                            <p className="text-sm text-gray-600 mb-4">Manual compliance processes miss real-time configuration drifts and flow-down errors, exposing contractors to $1M+ fines. AI-driven analytics create an auditable, continuous record of compliance.</p>
                            <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                                <p className="font-bold text-red-800">Our analytics reduce FCA risk by 40% by automating control validation and creating an immutable evidence trail, protecting you from misrepresentation penalties.</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </section>

            <div className="text-center py-8">
                <h2 className="text-3xl font-bold mb-4">Ready to Gain Your Competitive Edge?</h2>
                <p className="text-lg text-gray-600 mb-8">Stop guessing and start predicting. See how HyperCore's advanced analytics can transform your CMMC strategy.</p>
                <div className="flex justify-center gap-4">
                    <Button asChild size="lg">
                        <Link to={createPageUrl('PartnershipTrial')}>
                            Start Free Trial <ExternalLink className="w-4 h-4 ml-2" />
                        </Link>
                    </Button>
                    <Button asChild variant="outline" size="lg">
                         <Link to={createPageUrl('ContactUs')}>
                            Request a Custom Demo
                        </Link>
                    </Button>
                </div>
            </div>
        </div>
    );
}