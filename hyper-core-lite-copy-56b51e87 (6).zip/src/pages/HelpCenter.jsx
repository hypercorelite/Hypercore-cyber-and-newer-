import React, { useState, useEffect } from 'react';
import { KnowledgeBaseArticle } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Search, LifeBuoy, Bot, Mail, MessageSquare } from "lucide-react";
import { toast } from "sonner";
import { LoadingSpinner } from '../components/ui/LoadingSpinner';

const PageLoadingSpinner = ({ text }) => (
    <div className="flex flex-col items-center justify-center min-h-[calc(100vh-200px)]">
        <LoadingSpinner />
        <p className="mt-4 text-lg text-gray-600">{text}</p>
    </div>
);

export default function HelpCenter() {
    const [articles, setArticles] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchArticles = async () => {
            try {
                const fetchedArticles = await KnowledgeBaseArticle.list();
                setArticles(fetchedArticles);
            } catch (error) {
                console.error("Failed to load help articles:", error);
                toast.error("Failed to load help articles.");
            } finally {
                setLoading(false);
            }
        };
        fetchArticles();
    }, []);

    const filteredArticles = articles.filter(article =>
        !article.title.toLowerCase().includes("contacting support") &&
        (article.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        article.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
        article.category.toLowerCase().includes(searchTerm.toLowerCase()))
    );
    
    if (loading) {
        return <PageLoadingSpinner text="Loading Help Center..."/>;
    }

    return (
        <div className="bg-white py-12 md:py-20">
            <div className="container mx-auto px-4 max-w-5xl">
                <div className="text-center mb-12">
                    <LifeBuoy className="mx-auto h-12 w-12 text-blue-600 mb-4" />
                    <h1 className="text-4xl md:text-5xl font-extrabold text-gray-900 mb-4">
                        Help Center
                    </h1>
                    <p className="text-xl text-gray-600">
                        Find answers to common questions about your account, billing, and our services.
                    </p>
                </div>
                
                <Card className="mb-12 bg-blue-50 border-blue-200">
                    <CardHeader>
                        <CardTitle className="flex items-center gap-3 text-blue-800">
                           <Bot className="w-6 h-6" /> Contacting Support
                        </CardTitle>
                        <CardDescription>We use an AI-first model to provide fast, scalable support.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                         <div className="flex items-start gap-3">
                            <Bot className="w-5 h-5 text-blue-600 mt-0.5" />
                            <div>
                                <strong>1. AI Instant Support (24/7):</strong> Use our AI assistant in your portal for immediate answers.
                            </div>
                        </div>
                        <div className="flex items-start gap-3">
                            <MessageSquare className="w-5 h-5 text-green-600 mt-0.5" />
                            <div>
                                <strong>2. Support Ticket:</strong> For complex issues, the AI will create a ticket for our expert team.
                            </div>
                        </div>
                        <div className="flex items-start gap-3">
                            <Mail className="w-5 h-5 text-purple-600 mt-0.5" />
                            <div>
                                <strong>3. Direct Email:</strong> For urgent matters, email us at <strong>support@hypercorecyber.com</strong>.
                            </div>
                        </div>
                         <p className="text-xs text-gray-600 pt-2 border-t"><strong>No phone support is provided.</strong> This allows us to keep costs low and provide efficient, documented support.</p>
                    </CardContent>
                </Card>

                <div className="relative mb-8">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <Input
                        type="text"
                        placeholder="Search help articles (e.g., 'invoice', 'password')..."
                        className="pl-10 text-lg py-6"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                    />
                </div>

                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {filteredArticles.length > 0 ? (
                        filteredArticles.map(article => (
                            <Card key={article.id} className="hover:shadow-lg transition-shadow">
                                <CardHeader>
                                    <CardTitle>{article.title}</CardTitle>
                                    <CardDescription>{article.category}</CardDescription>
                                </CardHeader>
                                <CardContent>
                                    <p className="text-sm text-gray-600 line-clamp-3">
                                        {article.content.substring(0, 150)}...
                                    </p>
                                </CardContent>
                            </Card>
                        ))
                    ) : (
                        <p className="text-center text-gray-500 md:col-span-3">No articles found matching your search.</p>
                    )}
                </div>
            </div>
        </div>
    );
}