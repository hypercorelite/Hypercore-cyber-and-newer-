import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, AlertTriangle, Loader2, Mail, FileDown, MessageSquare, BarChart, Users, TestTube } from 'lucide-react';
import { toast } from "sonner";
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";

// Entity imports
import { ClientOnboarding } from "@/api/entities";
import { ClientEngagement } from "@/api/entities";
import { ClientFeedback } from "@/api/entities";
import { SupportTicket } from "@/api/entities";

// Function imports
import { generateTrialReport } from "@/api/functions";
import { sendEmail } from "@/api/functions";
import { exportSBIRClientData } from "@/api/functions";
import { testEmailSystem } from "@/api/functions";
import { testCMMCReportPipeline } from "@/api/functions";

export default function ClientPipelineTests() {
    const [testResults, setTestResults] = useState({});
    const [loading, setLoading] = useState({});
    const [testClient, setTestClient] = useState({
        email: 'sbir.test.client@example.com',
        name: 'SBIR Test Client',
        company: 'Test Defense Innovations',
        size: '51-200',
        industry: 'defense_contractor',
        cmmc_status: 'planning',
        referral: 'SBIR.gov'
    });

    const runTest = async (testName, testFunction) => {
        setLoading(prev => ({ ...prev, [testName]: true }));
        try {
            const result = await testFunction();
            setTestResults(prev => ({ ...prev, [testName]: { success: true, ...result } }));
            toast.success(`✅ ${testName} test passed!`);
        } catch (error) {
            setTestResults(prev => ({ ...prev, [testName]: { success: false, message: error.message } }));
            toast.error(`❌ ${testName} test failed.`);
        } finally {
            setLoading(prev => ({ ...prev, [testName]: false }));
        }
    };
    
    // Test 1: Full Client Onboarding Flow
    const testOnboardingFlow = async () => {
        const clientRecord = await ClientOnboarding.create({
            client_email: testClient.email,
            client_name: testClient.name,
            company_name: testClient.company,
            onboarding_stage: 'email_captured',
            sbir_case_study_consent: true,
        });

        await sendEmail({
            to: testClient.email,
            subject: "Welcome to HyperCore Free Beta (Test)",
            html: `<h2>Welcome, ${testClient.name}!</h2><p>This is a test email to verify the onboarding system.</p>`
        });

        await ClientOnboarding.update(clientRecord.id, { onboarding_stage: 'profile_completed' });

        return { message: 'Client onboarded and welcome email sent.', details: { recordId: clientRecord.id, stage: 'profile_completed' }};
    };

    // Test 2: Assessment & Report Generation
    const testAssessmentFlow = async () => {
        const { data: report } = await generateTrialReport({
            organizationName: testClient.company,
            answers: { accessControl: 'yes', incidentResponse: 'no' },
            userEmail: testClient.email,
        });

        await ClientEngagement.create({
            client_email: testClient.email,
            engagement_type: 'assessment_completed',
            assessment_score: report.score,
            pdf_report_generated: true,
        });
        
        return { message: `Assessment completed with score ${report.score}. Engagement logged.`, details: report };
    };

    // Test 3: Support Ticket Creation
    const testSupportTicketFlow = async () => {
        const ticket = await SupportTicket.create({
            client_email: testClient.email,
            client_name: testClient.name,
            subject: "Test: Escalation Support Ticket",
            description: "This is an automated test of the support ticket system.",
            priority: "medium",
            source: "portal_form"
        });
        
        await sendEmail({
             to: 'admin@hypercore.com', // Your admin email
             subject: `[Support Test] New Ticket from ${testClient.company}`,
             html: `<h2>New Support Ticket (Test)</h2><p><b>Client:</b> ${testClient.name}</p><p><b>Subject:</b> ${ticket.subject}</p><p>${ticket.description}</p>`
        });

        return { message: 'Support ticket created and admin notified.', details: { ticketId: ticket.id } };
    };

    // Test 4: SBIR Data Export
    const testSBIRDataExport = async () => {
         const { data } = await exportSBIRClientData({});
         if (!data || data.length === 0) throw new Error("Export returned no data.");
         return { message: `Successfully exported ${data.length} records for SBIR proposal.`, details: data };
    };
    
    // Test 5: Email System Health Check
    const testEmailInfra = async () => {
         const { data } = await testEmailSystem({ testRecipient: testClient.email });
         return { message: data.message, details: data.details };
    };

    // Test 6: CMMC PDF Report Pipeline
    const testReportPipeline = async () => {
         const { data } = await testCMMCReportPipeline({ testRecipient: testClient.email });
         return { message: data.message, details: data.details };
    };

    const TestCard = ({ title, description, testName, testFunction }) => (
        <Card>
            <CardHeader>
                <CardTitle>{title}</CardTitle>
                <CardDescription>{description}</CardDescription>
            </CardHeader>
            <CardContent>
                <Button onClick={() => runTest(testName, testFunction)} disabled={loading[testName]}>
                    {loading[testName] ? <Loader2 className="w-4 h-4 mr-2 animate-spin"/> : <TestTube className="w-4 h-4 mr-2" />}
                    Run Test
                </Button>
                {testResults[testName] && (
                    <Alert className={`mt-4 ${testResults[testName].success ? 'bg-green-50 border-green-200 text-green-800' : 'bg-red-50 border-red-200 text-red-800'}`}>
                        {testResults[testName].success ? <CheckCircle className="h-4 w-4" /> : <AlertTriangle className="h-4 w-4" />}
                        <AlertTitle>{testResults[testName].success ? 'Test Passed' : 'Test Failed'}</AlertTitle>
                        <AlertDescription className="text-xs break-words">
                            {testResults[testName].message}
                        </AlertDescription>
                    </Alert>
                )}
            </CardContent>
        </Card>
    );

    return (
        <div className="space-y-8">
            <BreadcrumbNav currentPageName="ClientPipelineTests" />
            
            <CardHeader className="px-0">
                <CardTitle className="text-3xl font-bold flex items-center gap-3">
                    <Users className="w-8 h-8 text-blue-600" />
                    Client Pipeline & SBIR Data Testing
                </CardTitle>
                <CardDescription>
                    End-to-end tests for the complete client lifecycle and SBIR data collection systems.
                </CardDescription>
            </CardHeader>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                 <TestCard 
                    title="1. Client Onboarding & Welcome Email"
                    description="Simulates a new client signing up and receiving their welcome email."
                    testName="Onboarding"
                    testFunction={testOnboardingFlow}
                 />
                 <TestCard 
                    title="2. Assessment & Report Generation"
                    description="Runs the AI assessment, generates a report, and logs the engagement."
                    testName="Assessment"
                    testFunction={testAssessmentFlow}
                 />
                 <TestCard 
                    title="3. Support Ticket Escalation"
                    description="Creates a support ticket from the client and sends an alert to the admin."
                    testName="Support Ticket"
                    testFunction={testSupportTicketFlow}
                 />
                 <TestCard 
                    title="4. SBIR Data Export"
                    description="Exports anonymized client data into a CSV format for SBIR proposals."
                    testName="SBIR Data Export"
                    testFunction={testSBIRDataExport}
                 />
                 <TestCard 
                    title="5. Email System Health Check"
                    description="Verifies the SendGrid integration is configured and can send emails."
                    testName="Email System"
                    testFunction={testEmailInfra}
                 />
                 <TestCard 
                    title="6. PDF Report Pipeline"
                    description="Tests the full pipeline for generating and emailing a CMMC report."
                    testName="PDF Report"
                    testFunction={testReportPipeline}
                 />
            </div>
        </div>
    );
}