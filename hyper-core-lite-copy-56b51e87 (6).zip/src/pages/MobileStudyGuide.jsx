import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Book, Youtube, Lightbulb, Mic, Shield, DollarSign, Target, Code } from 'lucide-react';
import { motion } from "framer-motion";
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";

const studyTopics = [
    {
        category: "AI-Assisted Development",
        icon: Code,
        color: "text-purple-600",
        description: "Master the tools that will write 80% of your code. Focus on effective prompting, not just theory.",
        resources: [
            { title: "GitHub Copilot Pro Best Practices", type: "YouTube", action: "Watch", link: "https://www.youtube.com/results?search_query=github+copilot+pro+tips" },
            { title: "Cursor IDE Crash Course", type: "YouTube", action: "Watch", link: "https://www.youtube.com/results?search_query=cursor+ide+tutorial" },
            { title: "Prompt Engineering for Code Gen", type: "Reading", action: "Read", link: "https://www.promptingguide.ai/applications/code_generation" }
        ]
    },
    {
        category: "Serverless & AWS Basics",
        icon: Book,
        color: "text-orange-500",
        description: "Understand the 'what' and 'why' of the core AWS services for the MVP: Lambda, S3, and API Gateway.",
        resources: [
            { title: "Serverless on AWS in 10 Minutes", type: "YouTube", action: "Watch", link: "https://www.youtube.com/watch?v=rL41s9n-p-I" },
            { title: "Official AWS Podcast", type: "Podcast", action: "Listen", link: "https://aws.amazon.com/podcasts/aws-podcast/" }
        ]
    },
    {
        category: "CMMC Structure",
        icon: Shield,
        color: "text-blue-600",
        description: "Understand the *structure* of CMMC for data modeling, not deep implementation details which the AI will handle.",
        resources: [
            { title: "NIST 800-171 Control Families", type: "Web", action: "Browse", link: "https://csrc.nist.gov/projects/cprt/catalog#/cprt/framework/version/SP_800-171_rev-2/home" },
            { title: "CMMC Level 2 Assessment Guide", type: "Reading", action: "Skim", link: "https://dodcio.defense.gov/CMMC/Documentation/" }
        ]
    },
    {
        category: "SBIR Strategy",
        icon: DollarSign,
        color: "text-green-600",
        description: "Use this time for market research to strengthen the SBIR Phase I proposal's commercialization plan.",
        resources: [
            { title: "DoD SBIR Topics Portal", type: "Web", action: "Browse", link: "https://www.dodsbirsttr.mil/submissions/login" },
            { title: "Writing a Winning SBIR Abstract", type: "Podcast", action: "Listen", link: "https://www.google.com/search?q=sbir+proposal+podcast" }
        ]
    }
];

export default function MobileStudyGuide() {
    return (
        <div className="space-y-8">
            <BreadcrumbNav currentPageName="MobileStudyGuide" />
            <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center"
            >
                <Badge className="mb-4 bg-gray-100 text-gray-800">PRE-SPRINT PREP</Badge>
                <h1 className="text-4xl font-bold text-gray-900 mb-4">
                    Mobile Study Guide: AI-First Edition
                </h1>
                <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                    A curated list of resources to front-load the theory for our AI-powered 8-week sprint.
                </p>
            </motion.div>
            
            <Alert className="bg-green-50 border-green-200">
                <Target className="h-4 w-4 text-green-600" />
                <AlertTitle className="text-green-800">Strategic Goal: Master the Tools, Not the Manual</AlertTitle>
                <AlertDescription className="text-green-700">
                    Use this time to become an expert at directing AI. When your desktop is ready, you'll be prepared to manage the AI workforce, not become the manual labor.
                </AlertDescription>
            </Alert>

            <div className="grid md:grid-cols-2 gap-6">
                {studyTopics.map((topic) => (
                    <Card key={topic.category}>
                        <CardHeader>
                            <CardTitle className={`flex items-center gap-3 ${topic.color}`}>
                                <topic.icon className="w-6 h-6" />
                                {topic.category}
                            </CardTitle>
                            <CardDescription>{topic.description}</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <ul className="space-y-3">
                                {topic.resources.map((res) => (
                                    <li key={res.title}>
                                        <a href={res.link} target="_blank" rel="noopener noreferrer" className="block p-3 bg-gray-50 hover:bg-gray-100 rounded-md transition-colors">
                                            <div className="flex items-center justify-between">
                                                <div>
                                                    <div className="flex items-center gap-2">
                                                        {res.type === "YouTube" && <Youtube className="w-4 h-4 text-red-600" />}
                                                        {res.type === "Podcast" && <Mic className="w-4 h-4 text-purple-600" />}
                                                        {res.type === "Reading" && <Book className="w-4 h-4 text-blue-600" />}
                                                        {res.type === "Web" && <Lightbulb className="w-4 h-4 text-yellow-600" />}
                                                        <span className="font-semibold text-gray-800">{res.title}</span>
                                                    </div>
                                                </div>
                                                <Badge variant="outline">{res.action} <ArrowRight className="w-3 h-3 ml-1"/></Badge>
                                            </div>
                                        </a>
                                    </li>
                                ))}
                            </ul>
                        </CardContent>
                    </Card>
                ))}
            </div>
        </div>
    );
}