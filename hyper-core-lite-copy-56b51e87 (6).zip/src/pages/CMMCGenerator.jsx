import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { User } from '@/api/entities';
import CMMCGenerator from '../components/cmmc/CMMCGenerator';
import BreadcrumbNav from '../components/navigation/BreadcrumbNav';
import { Shield, Zap, CheckCircle } from 'lucide-react';

export default function CMMCGeneratorPage() {
    const [user, setUser] = useState(null);
    const [clientDetails, setClientDetails] = useState(null);

    useEffect(() => {
        const fetchUser = async () => {
            try {
                const currentUser = await User.me();
                setUser(currentUser);
                
                // Set default client details for testing
                const defaultDetails = {
                    company_name: currentUser.organization_name || 'Elite Defense Systems',
                    industry: 'Defense Contracting',
                    size: '101-250',
                    location: 'Northern Virginia',
                    cmmc_level: 'Level 2',
                    dataTypes: 'CUI',
                    userCount: '201-500',
                    systemName: 'Integrated Defense Network',
                    systemDescription: 'Mission-critical network supporting defense contract operations, managing CUI data flows, and ensuring secure communications with DoD partners.',
                    systemType: 'hybrid'
                };
                setClientDetails(defaultDetails);
            } catch (error) {
                console.error('Failed to fetch user:', error);
            }
        };
        fetchUser();
    }, []);

    return (
        <div className="space-y-6">
            <BreadcrumbNav currentPageName="CMMCGenerator" />
            
            <div className="text-center">
                <Badge className="mb-4 bg-blue-100 text-blue-800">AI-POWERED TESTING</Badge>
                <h1 className="text-4xl font-bold text-gray-900 mb-4">CMMC Document Generator</h1>
                <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                    Test the comprehensive AI-powered PDF generation system for CMMC Level 2 compliance documents.
                </p>
            </div>

            <Alert className="bg-green-50 border-green-200">
                <CheckCircle className="h-4 w-4 text-green-600" />
                <AlertDescription className="text-green-800">
                    <strong>Live Production Test:</strong> This generator creates actual, comprehensive CMMC documents using advanced AI prompts. 
                    Documents include detailed SSP sections, complete policy texts, and implementation guidance.
                </AlertDescription>
            </Alert>

            <div className="grid lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2">
                    <CMMCGenerator clientDetails={clientDetails} />
                </div>
                
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <Zap className="w-5 h-5 text-yellow-500" />
                            AI Features
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div className="p-3 bg-blue-50 rounded-lg">
                            <h4 className="font-semibold text-blue-800">Document Analysis</h4>
                            <p className="text-sm text-blue-600">Upload policies/diagrams for AI gap analysis</p>
                        </div>
                        <div className="p-3 bg-green-50 rounded-lg">
                            <h4 className="font-semibold text-green-800">SSP Generation</h4>
                            <p className="text-sm text-green-600">Complete NIST-compliant System Security Plans</p>
                        </div>
                        <div className="p-3 bg-purple-50 rounded-lg">
                            <h4 className="font-semibold text-purple-800">Policy Creation</h4>
                            <p className="text-sm text-purple-600">14 comprehensive CMMC policy documents</p>
                        </div>
                        <div className="p-3 bg-orange-50 rounded-lg">
                            <h4 className="font-semibold text-orange-800">Controls Mapping</h4>
                            <p className="text-sm text-orange-600">All 110 NIST 800-171 controls with implementation</p>
                        </div>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}