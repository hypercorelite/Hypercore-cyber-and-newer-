import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Bot, Shield, Clock, ArrowRight, Zap, FileText, CheckCircle, UserCheck } from 'lucide-react';
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import DisclaimerBanner from '../components/legal/DisclaimerBanner';

const processBreakdown = [
    {
        icon: FileText,
        title: "Client Upload & Review (75 Mins Total)",
        description: "Your total active time commitment over the entire process.",
        details: [
            "30 mins: Initial document upload via secure portal.",
            "30 mins: Review and approve AI-generated drafts.",
            "15 mins: Download final, audit-ready package."
        ]
    },
    {
        icon: Bot,
        title: "AI Processing & Generation (Weeks 1-7)",
        description: "Our AI engine performs the heavy lifting in the background.",
        details: [
            "Analyzes uploaded documents for compliance gaps.",
            "Generates 3-5 core policies and SSP framework.",
            "Assembles evidence templates and checklists.",
            "Continuously refines your compliance package."
        ]
    },
    {
        icon: UserCheck,
        title: "Human-in-the-Loop Review (Throughout)",
        description: "Our experts ensure quality and accuracy where it counts.",
        details: [
            "Validates AI-generated content for context.",
            "Answers escalated email support questions.",
            "Performs final quality assurance on the package.",
            "Ensures the output is C3PAO-ready."
        ]
    }
];

export default function OurTutoringModel() {
    return (
        <div className="min-h-screen bg-white">
            <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center py-16 px-4 bg-gray-50"
            >
                <Badge className="mb-4 bg-blue-100 text-blue-800" variant="outline">THE HYPERCORE MODEL</Badge>
                <h1 className="text-4xl lg:text-5xl font-extrabold text-gray-900 mb-4 tracking-tight">
                    Our AI-First Compliance Service
                </h1>
                <p className="text-lg lg:text-xl text-gray-600 max-w-4xl mx-auto">
                    We replaced high-effort consulting and DIY software with a scalable AI service that delivers a finished product.
                </p>
            </motion.div>

            <div className="max-w-7xl mx-auto p-4 lg:p-8 space-y-16">

                <Alert className="bg-green-50 border-green-200">
                    <Zap className="h-4 w-4 text-green-600" />
                    <AlertTitle className="text-green-800">The 8-Week Process vs. Your 75-Minute Effort</AlertTitle>
                    <AlertDescription className="text-green-700">
                        Clients don't spend 8 weeks working; they engage for just 75 minutes. The 8-week timeline is for our backend AI processing and human-in-the-loop quality assurance to deliver a complete, audit-ready package.
                    </AlertDescription>
                </Alert>

                <div className="grid md:grid-cols-3 gap-8">
                    {processBreakdown.map((section, index) => (
                        <motion.div 
                            key={index}
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: index * 0.2 }}
                        >
                            <Card className="h-full border-gray-200 hover:shadow-lg transition-shadow">
                                <CardHeader className="text-center">
                                    <section.icon className="w-12 h-12 mx-auto mb-4 text-blue-600" />
                                    <CardTitle className="text-xl">{section.title}</CardTitle>
                                    <CardDescription>{section.description}</CardDescription>
                                </CardHeader>
                                <CardContent>
                                    <ul className="space-y-2">
                                        {section.details.map((detail, detailIndex) => (
                                            <li key={detailIndex} className="flex items-start gap-2 text-sm">
                                                <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                                                <span>{detail}</span>
                                            </li>
                                        ))}
                                    </ul>
                                </CardContent>
                            </Card>
                        </motion.div>
                    ))}
                </div>

                <DisclaimerBanner />

                <Card className="text-center bg-gray-900 text-white">
                    <CardContent className="p-8 lg:p-10">
                        <h3 className="text-2xl font-bold mb-4">Ready for Effortless Compliance?</h3>
                        <p className="text-gray-300 mb-6 max-w-2xl mx-auto">
                           Experience the new category of compliance service. Get audit-ready in 8 weeks with only 75 minutes of your time.
                        </p>
                        <div className="flex flex-col sm:flex-row gap-4 justify-center">
                            <Button asChild size="lg" className="bg-blue-600 hover:bg-blue-700">
                                <Link to={createPageUrl('ProgramDetails')}>
                                    View MVP Program Options <ArrowRight className="w-4 h-4 ml-2" />
                                </Link>
                            </Button>
                            <Button asChild size="lg" variant="outline" className="border-gray-500 text-white hover:bg-gray-800">
                                <Link to={createPageUrl('CompetitiveComparison')}>
                                    Compare vs. Other Models
                                </Link>
                            </Button>
                        </div>
                    </CardContent>
                </Card>

            </div>
        </div>
    );
}