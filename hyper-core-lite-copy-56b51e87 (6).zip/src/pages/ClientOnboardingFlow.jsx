import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { CheckCircle, ArrowRight, Mail, FileDown, MessageSquare } from 'lucide-react';
import { toast } from "sonner";
import { User } from "@/api/entities";
import { ClientOnboarding } from "@/api/entities";
import { generateTrialReport } from "@/api/functions";
import { sendEmail } from "@/api/functions";

export default function ClientOnboardingFlow() {
    const [currentStep, setCurrentStep] = useState(1);
    const [formData, setFormData] = useState({
        client_email: '',
        client_name: '',
        company_name: '',
        company_size: '',
        industry_sector: '',
        current_cmmc_status: '',
        referral_source: '',
        phone: '',
        sbir_case_study_consent: false
    });
    const [loading, setLoading] = useState(false);
    const [reportGenerated, setReportGenerated] = useState(false);
    const [reportData, setReportData] = useState(null);

    const handleInputChange = (field, value) => {
        setFormData(prev => ({ ...prev, [field]: value }));
    };

    const handleStepComplete = async (step) => {
        setLoading(true);
        try {
            if (step === 1) {
                // Email capture step
                await ClientOnboarding.create({
                    ...formData,
                    onboarding_stage: 'email_captured'
                });
                
                // Send welcome email
                await sendEmail({
                    to: formData.client_email,
                    subject: "Welcome to HyperCore Free Beta - Next Steps",
                    html: `
                        <h2>Welcome ${formData.client_name}!</h2>
                        <p>Thanks for joining our free beta program. Let's get you CMMC-ready by November 10th.</p>
                        <p><strong>Next Step:</strong> Complete your profile to get personalized AI analysis.</p>
                        <p>Questions? Just reply to this email - our team responds within 24 hours.</p>
                    `
                });
                
                toast.success("Welcome email sent! Check your inbox.");
                setCurrentStep(2);
                
            } else if (step === 2) {
                // Profile completion
                await ClientOnboarding.update(formData.client_email, {
                    ...formData,
                    onboarding_stage: 'profile_completed'
                });
                setCurrentStep(3);
                
            } else if (step === 3) {
                // Generate assessment report
                const { data: results } = await generateTrialReport({
                    organizationName: formData.company_name,
                    answers: {}, // This would come from assessment form
                    userEmail: formData.client_email,
                });
                
                setReportData(results);
                setReportGenerated(true);
                
                // Update onboarding status
                await ClientOnboarding.update(formData.client_email, {
                    onboarding_stage: 'report_generated'
                });
                
                // Send report via email
                await sendEmail({
                    to: formData.client_email,
                    subject: "Your CMMC Readiness Report is Ready",
                    html: `
                        <h2>Your CMMC Readiness Analysis</h2>
                        <p>Hi ${formData.client_name},</p>
                        <p>Your AI-powered CMMC readiness analysis is complete! Here's what we found:</p>
                        <ul>
                            <li><strong>Compliance Score:</strong> ${results.score}%</li>
                            <li><strong>Priority Actions:</strong> ${results.gaps.length} items need attention</li>
                            <li><strong>Strengths:</strong> ${results.strengths.length} areas already compliant</li>
                        </ul>
                        <p><strong>Next Steps:</strong></p>
                        <ol>
                            <li>Download your detailed PDF report from your dashboard</li>
                            <li>Review the implementation checklist</li>
                            <li>Schedule a free consultation if needed</li>
                        </ol>
                        <p>Remember: This free beta access continues through December 5, 2025.</p>
                    `
                });
                
                toast.success("Report generated and emailed to you!");
            }
        } catch (error) {
            toast.error("Something went wrong. Please try again.");
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    if (reportGenerated) {
        return (
            <div className="max-w-4xl mx-auto p-6 space-y-6">
                <Card className="bg-green-50 border-green-200">
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <CheckCircle className="w-6 h-6 text-green-600" />
                            Welcome to HyperCore Beta, {formData.client_name}!
                        </CardTitle>
                        <CardDescription>Your CMMC readiness report has been generated and emailed to you.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div className="grid md:grid-cols-3 gap-4">
                            <Button className="flex items-center gap-2">
                                <FileDown className="w-4 h-4" />
                                Download PDF Report
                            </Button>
                            <Button variant="outline" className="flex items-center gap-2">
                                <Mail className="w-4 h-4" />
                                Email Support
                            </Button>
                            <Button variant="outline" className="flex items-center gap-2">
                                <MessageSquare className="w-4 h-4" />
                                Provide Feedback
                            </Button>
                        </div>
                    </CardContent>
                </Card>
            </div>
        );
    }

    return (
        <div className="max-w-2xl mx-auto p-6">
            <div className="text-center mb-8">
                <h1 className="text-3xl font-bold">Get Started with Your Free Beta</h1>
                <p className="text-gray-600 mt-2">Step {currentStep} of 3</p>
            </div>

            {currentStep === 1 && (
                <Card>
                    <CardHeader>
                        <CardTitle>Let's Get You Started</CardTitle>
                        <CardDescription>First, we need your contact information.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <Input
                            placeholder="Your Email Address"
                            type="email"
                            value={formData.client_email}
                            onChange={(e) => handleInputChange('client_email', e.target.value)}
                        />
                        <Input
                            placeholder="Your Full Name"
                            value={formData.client_name}
                            onChange={(e) => handleInputChange('client_name', e.target.value)}
                        />
                        <Input
                            placeholder="Company Name"
                            value={formData.company_name}
                            onChange={(e) => handleInputChange('company_name', e.target.value)}
                        />
                        <Button 
                            onClick={() => handleStepComplete(1)}
                            disabled={!formData.client_email || !formData.client_name || !formData.company_name || loading}
                            className="w-full"
                        >
                            Continue <ArrowRight className="w-4 h-4 ml-2" />
                        </Button>
                    </CardContent>
                </Card>
            )}

            {currentStep === 2 && (
                <Card>
                    <CardHeader>
                        <CardTitle>Tell Us About Your Organization</CardTitle>
                        <CardDescription>This helps us provide personalized recommendations.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <Select onValueChange={(value) => handleInputChange('company_size', value)}>
                            <SelectTrigger>
                                <SelectValue placeholder="Company Size" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="1-10">1-10 employees</SelectItem>
                                <SelectItem value="11-50">11-50 employees</SelectItem>
                                <SelectItem value="51-200">51-200 employees</SelectItem>
                                <SelectItem value="201-1000">201-1000 employees</SelectItem>
                                <SelectItem value="1000+">1000+ employees</SelectItem>
                            </SelectContent>
                        </Select>

                        <Select onValueChange={(value) => handleInputChange('industry_sector', value)}>
                            <SelectTrigger>
                                <SelectValue placeholder="Industry Sector" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="defense_contractor">Defense Contractor</SelectItem>
                                <SelectItem value="subcontractor">Defense Subcontractor</SelectItem>
                                <SelectItem value="aerospace">Aerospace</SelectItem>
                                <SelectItem value="manufacturing">Manufacturing</SelectItem>
                                <SelectItem value="healthcare">Healthcare</SelectItem>
                                <SelectItem value="finance">Finance</SelectItem>
                                <SelectItem value="other">Other</SelectItem>
                            </SelectContent>
                        </Select>

                        <Select onValueChange={(value) => handleInputChange('current_cmmc_status', value)}>
                            <SelectTrigger>
                                <SelectValue placeholder="Current CMMC Status" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="not_started">Haven't started CMMC preparation</SelectItem>
                                <SelectItem value="planning">Planning phase</SelectItem>
                                <SelectItem value="implementing">Currently implementing</SelectItem>
                                <SelectItem value="ready_for_audit">Ready for assessment</SelectItem>
                                <SelectItem value="certified">Already certified</SelectItem>
                            </SelectContent>
                        </Select>

                        <Input
                            placeholder="How did you find us? (Optional)"
                            value={formData.referral_source}
                            onChange={(e) => handleInputChange('referral_source', e.target.value)}
                        />

                        <div className="flex items-center space-x-2">
                            <Checkbox
                                checked={formData.sbir_case_study_consent}
                                onCheckedChange={(checked) => handleInputChange('sbir_case_study_consent', checked)}
                            />
                            <label className="text-sm text-gray-600">
                                I consent to HyperCore using anonymized data from my assessment for SBIR grant research and case studies (helps us secure funding to keep the platform free longer)
                            </label>
                        </div>

                        <Button 
                            onClick={() => handleStepComplete(2)}
                            disabled={!formData.company_size || !formData.industry_sector || loading}
                            className="w-full"
                        >
                            Complete Profile <ArrowRight className="w-4 h-4 ml-2" />
                        </Button>
                    </CardContent>
                </Card>
            )}

            {currentStep === 3 && (
                <Card>
                    <CardHeader>
                        <CardTitle>Generate Your CMMC Readiness Report</CardTitle>
                        <CardDescription>Our AI will analyze your organization's compliance posture.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <Alert className="mb-4">
                            <AlertDescription>
                                This demo version provides a sample analysis. Upload real documents for a more accurate assessment.
                            </AlertDescription>
                        </Alert>
                        <Button 
                            onClick={() => handleStepComplete(3)}
                            disabled={loading}
                            className="w-full"
                        >
                            {loading ? "Generating Report..." : "Generate My Report"}
                        </Button>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}