import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, Menu, ArrowRight, Zap, Target, Users, DollarSign, CheckCircle, X, Star, Phone, Mail, MessageCircle, Bot } from 'lucide-react';
import { motion } from "framer-motion";

// Navigation Improvements
const navigationImprovements = [
    {
        improvement: "Global Search Bar",
        implementation: "Add search to header with keyboard shortcut (Ctrl+K)",
        impact: "60% faster page access",
        code: `// Add to layout header
<div className="relative">
    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
    <Input
        placeholder="Search pages, data, contacts... (Ctrl+K)"
        className="pl-10 pr-4 py-2 w-64"
        onFocus={() => setShowSearchModal(true)}
    />
</div>`
    },
    {
        improvement: "Breadcrumb Navigation",
        implementation: "Show current location path for deep navigation",
        impact: "Reduces confusion by 40%",
        code: `// Add breadcrumbs component
<nav className="flex items-center space-x-2 text-sm text-gray-500 mb-4">
    <Link to="/dashboard">Dashboard</Link>
    <ArrowRight className="w-3 h-3" />
    <Link to="/partnerships">Partnerships</Link>
    <ArrowRight className="w-3 h-3" />
    <span className="text-gray-900">Contact Details</span>
</nav>`
    },
    {
        improvement: "Quick Actions Sidebar",
        implementation: "Floating action menu for common tasks",
        impact: "50% reduction in clicks for routine tasks",
        code: `// Floating quick actions
<div className="fixed right-6 bottom-6 z-50">
    <Button className="rounded-full w-14 h-14 shadow-lg">
        <Plus className="w-6 h-6" />
    </Button>
    {showQuickActions && (
        <div className="absolute bottom-16 right-0 space-y-2">
            <QuickActionButton icon={Users} label="New Contact" />
            <QuickActionButton icon={Mail} label="Send Email" />
            <QuickActionButton icon={Phone} label="Log Call" />
        </div>
    )}
</div>`
    },
    {
        improvement: "Smart Menu Categories",
        implementation: "Group related functions with visual indicators",
        impact: "Easier mental model for navigation",
        code: `// Enhanced navigation structure
const menuSections = [
    {
        title: "Client Management",
        icon: Users,
        items: ["Partnership Hub", "Email Campaigns", "Support Dashboard"]
    },
    {
        title: "Business Operations", 
        icon: Target,
        items: ["Analytics", "Financial Reports", "System Status"]
    },
    {
        title: "Platform Tools",
        icon: Zap,
        items: ["CMMC Assessment", "Document Generator", "Compliance Center"]
    }
];`
    }
];

// Competitive Analysis Data
const competitorComparison = [
    {
        category: "Service Model",
        hypercore: "Expert-guided 90-day program",
        competitor1: "Self-service platform subscription",
        competitor2: "Hourly consulting rates",
        competitor3: "Managed service contracts",
        advantage: "Fixed timeline with guaranteed deliverables"
    },
    {
        category: "Pricing Structure",
        hypercore: "$7,500 fixed fee (split 50/50)",
        competitor1: "$2,000-5,000/month ongoing",
        competitor2: "$300-500/hour (200-500 hours)",
        competitor3: "$50,000-200,000/year",
        advantage: "Predictable, one-time cost"
    },
    {
        category: "Timeline to Readiness",
        hypercore: "90 days guaranteed",
        competitor1: "12-18 months (self-paced)",
        competitor2: "6-24 months (depends on availability)",
        competitor3: "3-6 months (plus ongoing management)",
        advantage: "Fastest path to assessment readiness"
    },
    {
        category: "Client Effort Required",
        hypercore: "2-4 hours/week guided tasks",
        competitor1: "20+ hours/week learning platform",
        competitor2: "10-15 hours/week managing consultants",
        competitor3: "5-10 hours/week coordination calls",
        advantage: "Minimal time investment required"
    },
    {
        category: "Deliverables",
        hypercore: "Complete evidence package + training",
        competitor1: "Platform access + templates",
        competitor2: "Custom documentation + advice",
        competitor3: "Managed infrastructure + ongoing support",
        advantage: "Comprehensive, ready-to-submit package"
    },
    {
        category: "Success Guarantee",
        hypercore: "Structured methodology with expert review",
        competitor1: "No guarantees (self-service)",
        competitor2: "Limited to hours contracted",
        competitor3: "SLA-based but expensive to maintain",
        advantage: "Expert validation at every step"
    }
];

const pricingTiers = [
    {
        name: "CMMC Readiness Program",
        price: "$7,500",
        duration: "One-time, 90-day program",
        target: "Defense contractors preparing for first assessment",
        features: [
            "Complete AI-generated policy suite (14 documents)",
            "Weekly expert guidance and review sessions",
            "Custom System Security Plan (SSP) development",
            "Audit-ready evidence package organization",
            "Direct expert coaching on AWS CMMC architecture",
            "Gap analysis and prioritized remediation plan"
        ],
        comparison: "vs. $60,000-150,000 typical consulting costs",
        cta: "Start Your 90-Day Program"
    },
    {
        name: "Enterprise Partnership",
        price: "Custom Pricing", 
        duration: "Ongoing partnership",
        target: "Large organizations with multiple assessments",
        features: [
            "Everything in CMMC Readiness Program",
            "Multiple facility/division assessments",
            "Ongoing compliance monitoring",
            "C3PAO assessment coordination",
            "Staff training and certification programs",
            "Custom integration with existing tools"
        ],
        comparison: "vs. $200,000+ managed service contracts",
        cta: "Schedule Enterprise Consultation"
    }
];

// Customer Service Improvements
const customerServiceEnhancements = [
    {
        feature: "AI-Powered Chat Assistant",
        description: "24/7 instant answers to common questions",
        implementation: "Integrate with existing support agent",
        benefits: ["Immediate response to prospects", "Reduces support ticket volume by 70%", "Captures leads even outside business hours"],
        priority: "HIGH"
    },
    {
        feature: "Smart Knowledge Base",
        description: "Self-service help center with search",
        implementation: "Expand current KB with better organization",
        benefits: ["Faster customer self-service", "Reduces repetitive support questions", "Improves client satisfaction scores"],
        priority: "HIGH"
    },
    {
        feature: "Proactive Support Alerts", 
        description: "Monitor client progress and offer help before they ask",
        implementation: "Automated triggers based on platform usage",
        benefits: ["Prevents client confusion and delays", "Increases program completion rates", "Demonstrates proactive service"],
        priority: "MEDIUM"
    },
    {
        feature: "Video Call Integration",
        description: "One-click video calls for complex issues",
        implementation: "Calendly + Zoom integration in support tickets",
        benefits: ["Faster resolution of complex issues", "More personal service experience", "Better client relationship building"],
        priority: "MEDIUM"
    }
];

export default function NavigationOptimization() {
    const [activeTab, setActiveTab] = useState("navigation");

    return (
        <div className="space-y-8">
            <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center"
            >
                <h1 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-3">
                    Platform Optimization Strategy
                </h1>
                <p className="text-lg lg:text-xl text-gray-600">
                    Navigation improvements, competitive positioning, and customer service enhancements
                </p>
            </motion.div>

            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="navigation">🧭 Navigation</TabsTrigger>
                    <TabsTrigger value="competitive">⚖️ Competitive Edge</TabsTrigger>
                    <TabsTrigger value="service">🎧 Customer Service</TabsTrigger>
                </TabsList>

                <TabsContent value="navigation" className="space-y-6">
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <Menu className="w-5 h-5" />
                                Navigation & UX Improvements
                            </CardTitle>
                            <CardDescription>
                                Make your platform more intuitive and efficient for both prospects and admin users
                            </CardDescription>
                        </CardHeader>
                    </Card>

                    <div className="grid gap-6">
                        {navigationImprovements.map((item, index) => (
                            <Card key={index}>
                                <CardHeader>
                                    <div className="flex justify-between items-start">
                                        <div>
                                            <CardTitle>{item.improvement}</CardTitle>
                                            <CardDescription>{item.implementation}</CardDescription>
                                        </div>
                                        <Badge className="bg-green-100 text-green-800">
                                            {item.impact}
                                        </Badge>
                                    </div>
                                </CardHeader>
                                <CardContent>
                                    <pre className="bg-gray-900 text-white p-4 rounded-md text-xs overflow-x-auto">
                                        <code>{item.code}</code>
                                    </pre>
                                </CardContent>
                            </Card>
                        ))}
                    </div>

                    <Alert className="bg-blue-50 border-blue-200">
                        <Target className="h-4 w-4 text-blue-600" />
                        <AlertTitle className="text-blue-800">Implementation Priority</AlertTitle>
                        <AlertDescription className="text-blue-700">
                            Start with Global Search Bar and Breadcrumbs (2-3 hours total). These provide the biggest impact 
                            for navigation clarity and user efficiency.
                        </AlertDescription>
                    </Alert>
                </TabsContent>

                <TabsContent value="competitive" className="space-y-6">
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <Star className="w-5 h-5" />
                                Competitive Positioning Strategy
                            </CardTitle>
                            <CardDescription>
                                Clear value proposition differentiation from existing CMMC providers
                            </CardDescription>
                        </CardHeader>
                    </Card>

                    {/* Competitive Comparison Table */}
                    <Card>
                        <CardHeader>
                            <CardTitle>Market Position Analysis</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="overflow-x-auto">
                                <table className="w-full text-sm">
                                    <thead>
                                        <tr className="border-b">
                                            <th className="text-left p-3 font-semibold">Aspect</th>
                                            <th className="text-left p-3 font-semibold bg-green-50">HyperCore AI</th>
                                            <th className="text-left p-3 font-semibold">GRC Platforms</th>
                                            <th className="text-left p-3 font-semibold">Consulting Firms</th>
                                            <th className="text-left p-3 font-semibold">Managed Services</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {competitorComparison.map((row, index) => (
                                            <tr key={index} className="border-b hover:bg-gray-50">
                                                <td className="p-3 font-medium">{row.category}</td>
                                                <td className="p-3 bg-green-50 font-semibold text-green-800">{row.hypercore}</td>
                                                <td className="p-3 text-gray-600">{row.competitor1}</td>
                                                <td className="p-3 text-gray-600">{row.competitor2}</td>
                                                <td className="p-3 text-gray-600">{row.competitor3}</td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        </CardContent>
                    </Card>

                    {/* Pricing Strategy */}
                    <div className="grid md:grid-cols-2 gap-6">
                        {pricingTiers.map((tier, index) => (
                            <Card key={index} className={index === 0 ? "border-2 border-blue-500" : ""}>
                                <CardHeader>
                                    <div className="flex justify-between items-start">
                                        <div>
                                            <CardTitle>{tier.name}</CardTitle>
                                            <CardDescription>{tier.target}</CardDescription>
                                        </div>
                                        {index === 0 && <Badge>Most Popular</Badge>}
                                    </div>
                                    <div className="text-2xl font-bold text-green-600">
                                        {tier.price}
                                        <span className="text-sm text-gray-500 ml-2">{tier.duration}</span>
                                    </div>
                                    <div className="text-sm text-blue-600 font-medium">{tier.comparison}</div>
                                </CardHeader>
                                <CardContent>
                                    <ul className="space-y-2 mb-6">
                                        {tier.features.map((feature, i) => (
                                            <li key={i} className="flex items-start gap-2">
                                                <CheckCircle className="w-4 h-4 text-green-500 mt-1 flex-shrink-0" />
                                                <span className="text-sm">{feature}</span>
                                            </li>
                                        ))}
                                    </ul>
                                    <Button className="w-full">
                                        {tier.cta}
                                    </Button>
                                </CardContent>
                            </Card>
                        ))}
                    </div>

                    <Alert className="bg-yellow-50 border-yellow-200">
                        <DollarSign className="h-4 w-4 text-yellow-600" />
                        <AlertTitle className="text-yellow-800">Value Messaging Focus</AlertTitle>
                        <AlertDescription className="text-yellow-700">
                            Emphasize <strong>"Expert Tutoring vs. Self-Study"</strong> - position as the difference between 
                            struggling alone with complex software vs. having a CMMC expert guide you to success.
                        </AlertDescription>
                    </Alert>
                </TabsContent>

                <TabsContent value="service" className="space-y-6">
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <MessageCircle className="w-5 h-5" />
                                Streamlined Customer Service Strategy
                            </CardTitle>
                            <CardDescription>
                                Reduce support burden while improving client satisfaction and success rates
                            </CardDescription>
                        </CardHeader>
                    </Card>

                    <div className="grid gap-6">
                        {customerServiceEnhancements.map((enhancement, index) => (
                            <Card key={index} className={enhancement.priority === 'HIGH' ? 'border-l-4 border-l-red-500' : 'border-l-4 border-l-blue-500'}>
                                <CardHeader>
                                    <div className="flex justify-between items-start">
                                        <div>
                                            <CardTitle className="flex items-center gap-2">
                                                {index === 0 && <Bot className="w-5 h-5" />}
                                                {index === 1 && <Search className="w-5 h-5" />}
                                                {index === 2 && <Zap className="w-5 h-5" />}
                                                {index === 3 && <Phone className="w-5 h-5" />}
                                                {enhancement.feature}
                                            </CardTitle>
                                            <CardDescription>{enhancement.description}</CardDescription>
                                        </div>
                                        <Badge variant={enhancement.priority === 'HIGH' ? 'destructive' : 'secondary'}>
                                            {enhancement.priority}
                                        </Badge>
                                    </div>
                                </CardHeader>
                                <CardContent>
                                    <div className="space-y-4">
                                        <div>
                                            <h4 className="font-semibold mb-2">Implementation:</h4>
                                            <p className="text-sm text-gray-600">{enhancement.implementation}</p>
                                        </div>
                                        <div>
                                            <h4 className="font-semibold mb-2">Benefits:</h4>
                                            <ul className="space-y-1">
                                                {enhancement.benefits.map((benefit, i) => (
                                                    <li key={i} className="flex items-center gap-2 text-sm">
                                                        <CheckCircle className="w-4 h-4 text-green-500" />
                                                        {benefit}
                                                    </li>
                                                ))}
                                            </ul>
                                        </div>
                                    </div>
                                </CardContent>
                            </Card>
                        ))}
                    </div>

                    <div className="grid md:grid-cols-2 gap-6">
                        <Card>
                            <CardHeader>
                                <CardTitle>Self-Service Success Rate</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-4">
                                    <div className="flex justify-between items-center">
                                        <span>Current</span>
                                        <span className="font-bold">30%</span>
                                    </div>
                                    <div className="flex justify-between items-center">
                                        <span>With AI Chat + Better KB</span>
                                        <span className="font-bold text-green-600">85%</span>
                                    </div>
                                    <div className="text-sm text-gray-600">
                                        This means 55% fewer support tickets requiring human intervention
                                    </div>
                                </div>
                            </CardContent>
                        </Card>

                        <Card>
                            <CardHeader>
                                <CardTitle>Implementation Timeline</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-2 text-sm">
                                    <div className="flex justify-between">
                                        <span>Week 1: AI Chat Integration</span>
                                        <Badge variant="outline">4 hours</Badge>
                                    </div>
                                    <div className="flex justify-between">
                                        <span>Week 2: Knowledge Base Expansion</span>
                                        <Badge variant="outline">6 hours</Badge>
                                    </div>
                                    <div className="flex justify-between">
                                        <span>Week 3: Proactive Alerts</span>
                                        <Badge variant="outline">8 hours</Badge>
                                    </div>
                                    <div className="flex justify-between">
                                        <span>Week 4: Video Integration</span>
                                        <Badge variant="outline">4 hours</Badge>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    </div>

                    <Alert className="bg-green-50 border-green-200">
                        <Users className="h-4 w-4 text-green-600" />
                        <AlertTitle className="text-green-800">Customer Success Impact</AlertTitle>
                        <AlertDescription className="text-green-700">
                            These improvements will increase your program completion rate from ~70% to ~90%, 
                            directly impacting client success and your reputation in the defense contractor community.
                        </AlertDescription>
                    </Alert>
                </TabsContent>
            </Tabs>
        </div>
    );
}