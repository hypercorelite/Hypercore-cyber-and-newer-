import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { motion } from "framer-motion";
import { 
    Shield, 
    CheckCircle, 
    AlertTriangle, 
    Target, 
    FileText,
    Zap,
    Users,
    Database,
    Lock,
    Eye,
    Settings,
    Building,
    TrendingUp,
    DollarSign,
    Brain,
    Server,
    Info // New icon
} from 'lucide-react';
import AIAssessmentControl from '../components/compliance/AIAssessmentControl';

// Updated with AWS hosting reality
const HYPERCORE_ASSESSMENT = {
    company_profile: {
        name: "HyperCore AI, LLC",
        assessment_date: "September 2025",
        target_level: "CMMC Level 2 on AWS GovCloud",
        assessor: "HyperCore Platform (Self-Assessment)",
        business_model: "AI-Powered CMMC Compliance & Risk Management Platform"
    },
    overall_score: 88, // Score increased due to AWS
    defense_contractor_readiness: {
        timeline_to_compliant: "90 Days", // Accelerated timeline
        estimated_cost_traditional: "$150,000",
        estimated_cost_hypercore: "$25,000", // Adjusted to a realistic service fee
        cost_savings: "$125,000",
        partnership_value: "Access to $50M+ in DoD contracts"
    },
    domains: [
        {
            id: "AC",
            name: "Access Control",
            description: "Limit system access to authorized users and processes",
            score: 90,
            status: "excellent",
            controls_total: 22,
            controls_met: 19,
            strengths: [
                "Multi-factor authentication implemented on all systems",
                "Role-based access control via Base44 platform",
                "Automated user provisioning/deprovisioning",
                "Regular access reviews conducted"
            ],
            gaps: [
                "Need formal access control policy documentation",
                "Privileged access management could be enhanced",
                "Remote access monitoring needs improvement"
            ],
            next_steps: [
                "Document formal AC policies (2 weeks)",
                "Implement PAM solution (4 weeks)", 
                "Deploy advanced session monitoring (3 weeks)"
            ]
        },
        {
            id: "AT",
            name: "Awareness and Training",
            description: "Ensure personnel are trained in cybersecurity",
            score: 70, // Slightly improved
            status: "adequate",
            controls_total: 5,
            controls_met: 3,
            strengths: [
                "Security awareness integrated into onboarding",
                "Regular security updates shared with team",
                "Phishing simulation testing in place"
            ],
            gaps: [
                "No formal security training curriculum",
                "Limited role-based security training",
                "Training effectiveness not measured"
            ],
            next_steps: [
                "Develop formal training program (3 weeks)",
                "Implement training tracking system (2 weeks)",
                "Create role-specific training modules (4 weeks)"
            ]
        },
        {
            id: "AU", 
            name: "Audit and Accountability",
            description: "Create and maintain audit logs and accountability measures",
            score: 95, // Improved with CloudTrail
            status: "excellent",
            controls_total: 12,
            controls_met: 11,
            strengths: [
                "Comprehensive audit logging via AWS CloudTrail and AuditLog entity",
                "Real-time security event monitoring", 
                "Automated log analysis and alerting",
                "Audit trail integrity protection",
                "Regular audit log reviews"
            ],
            gaps: [
                "Long-term audit log retention strategy needed"
            ],
            next_steps: [
                "Implement 7-year audit retention policy (1 week)"
            ]
        },
        {
            id: "CM",
            name: "Configuration Management", 
            description: "Maintain secure system configurations",
            score: 85, // Improved with AWS Config
            status: "strong",
            strengths: [
                "Infrastructure as Code via AWS CloudFormation",
                "Version control for all code and configs",
                "Automated deployment pipelines",
                "Security baselines defined"
            ],
            gaps: [
                "Change management process needs formal documentation",
            ],
            next_steps: [
                "Formalize change management process using AWS best practices (1 week)",
                "Deploy configuration monitoring tools (3 weeks)",
                "Implement automated compliance checking (4 weeks)"
            ]
        },
        {
            id: "IA",
            name: "Identification and Authentication",
            description: "Identify and authenticate users and processes",
            score: 92, // Improved with AWS IAM
            status: "excellent", 
            controls_total: 12,
            controls_met: 11,
            strengths: [
                "AWS IAM enforces strong authentication",
                "Multi-factor authentication mandatory",
                "Strong password policies enforced",
                "Service account management implemented",
                "Identity federation with Google workspace",
                "Session management controls active"
            ],
            gaps: [],
            next_steps: ["Continue regular access reviews."]
        },
        {
            id: "IR",
            name: "Incident Response",
            description: "Establish incident response capabilities",
            score: 75,
            status: "adequate",
            controls_total: 8,
            controls_met: 6,
            strengths: [
                "Incident response procedures documented",
                "24/7 monitoring and alerting via platform",
                "Automated threat response capabilities",
                "Security incident tracking system"
            ],
            gaps: [
                "Limited incident response team training", 
                "No formal incident communication plan",
                "Recovery procedures need enhancement"
            ],
            next_steps: [
                "Conduct IR tabletop exercises (2 weeks)",
                "Develop communication templates (1 week)",
                "Test and refine recovery procedures (3 weeks)"
            ]
        },
        {
            id: "MA",
            name: "Maintenance",
            description: "Perform system maintenance securely",
            score: 95, // Significantly improved with AWS
            status: "excellent",
            controls_total: 6,
            controls_met: 6,
            strengths: [
                "AWS manages all underlying infrastructure maintenance",
                "Automated patch management via AWS Systems Manager",
                "Maintenance windows properly scheduled",
                "Remote maintenance tools secured",
                "Maintenance activities logged via CloudTrail",
                "No physical access required by HyperCore personnel"
            ],
            gaps: [],
            next_steps: [
                "Document patch management policy for application layer (1 week)"
            ],
            strategic_note: "Over 90% of Maintenance controls are inherited from AWS."
        },
        {
            id: "MP",
            name: "Media Protection",
            description: "Protect media containing sensitive information",
            score: 85, // Improved with AWS
            status: "strong",
            controls_total: 8,
            controls_met: 5,
            strengths: [
                "Data encryption at rest (AWS KMS) and in transit (TLS 1.3)",
                "AWS handles secure disposal of physical media",
                "Access controls on storage media"
            ],
            gaps: [
                "Formal media sanitization procedures for digital assets needed"
            ],
            next_steps: [
                "Develop digital media sanitization policy (1 week)",
                "Implement portable media controls (3 weeks)",
                "Establish secure transportation procedures (1 week)"
            ]
        },
        {
            id: "PE",
            name: "Physical and Environmental Protection",
            description: "Protect physical facilities and equipment",
            score: 98, // Massively improved with AWS
            status: "excellent",
            controls_total: 20,
            controls_met: 19,
            strengths: [
                "All production infrastructure hosted in AWS GovCloud regions",
                "AWS provides enterprise-grade physical security (24/7 guards, biometrics)",
                "Redundant power, cooling, and fire suppression managed by AWS",
                "Geographic redundancy across AWS Availability Zones"
            ],
            gaps: [
                "Need policy for securing corporate office (non-production)"
            ],
            next_steps: [
                "Document physical security policy for corporate office (1 week)"
            ],
            strategic_note: "Nearly all PE controls are fully inherited from AWS, a massive compliance accelerator."
        },
        {
            id: "PS",
            name: "Personnel Security",
            description: "Ensure trustworthiness of personnel",
            score: 80,
            status: "strong",
            controls_total: 8,
            controls_met: 7,
            strengths: [
                "Background checks for all personnel",
                "Security clearances for applicable positions",
                "Personnel security policies established",
                "Termination procedures implemented"
            ],
            gaps: [
                "Ongoing personnel security reviews need formalization"
            ],
            next_steps: [
                "Implement periodic security review process (2 weeks)"
            ]
        },
        {
            id: "RA",
            name: "Risk Assessment", 
            description: "Assess and manage organizational risk",
            score: 92,
            status: "excellent",
            controls_total: 7,
            controls_met: 7,
            strengths: [
                "Comprehensive risk assessment methodology",
                "AI-powered threat intelligence integration",
                "Regular vulnerability assessments",
                "Risk register maintained and updated",
                "Automated risk scoring capabilities",
                "Supply chain risk assessments"
            ],
            gaps: [],
            next_steps: [
                "Continue regular risk assessment cycles"
            ],
            competitive_advantage: "AI-driven risk assessment is a core platform capability"
        },
        {
            id: "SA",
            name: "System and Services Acquisition",
            description: "Acquire systems and services securely",
            score: 75,
            status: "adequate", 
            controls_total: 22,
            controls_met: 15,
            strengths: [
                "Security requirements in procurement processes",
                "Vendor security assessments conducted",
                "Supply chain risk management",
                "Secure development lifecycle practices"
            ],
            gaps: [
                "Some acquisition security controls need formalization",
                "Third-party assessment procedures could be enhanced",
                "Software composition analysis needs improvement"
            ],
            next_steps: [
                "Formalize acquisition security procedures (3 weeks)",
                "Enhance vendor assessment program (4 weeks)",
                "Implement software composition analysis (2 weeks)"
            ]
        },
        {
            id: "SC",
            name: "System and Communications Protection",
            description: "Protect system and communication boundaries",
            score: 90, // Improved with VPC, Security Groups
            status: "excellent",
            controls_total: 28,
            controls_met: 24,
            strengths: [
                "AWS VPC provides strong network segmentation",
                "AWS Security Groups and NACLs for fine-grained traffic control",
                "End-to-end encryption implemented",
                "Network segmentation and monitoring",
                "Secure communications protocols",
                "Application-level security controls",
                "API security implemented"
            ],
            gaps: [
                "Denial of service protections need configuration review"
            ],
            next_steps: [
                "Review and optimize AWS Shield Advanced configuration (1 week)",
                "Enhance network boundary controls (3 weeks)",
                "Upgrade communications encryption (1 week)"
            ]
        },
        {
            id: "SI",
            name: "System and Information Integrity",
            description: "Identify and correct system flaws",
            score: 90, // Improved with AWS Inspector
            status: "excellent",
            controls_total: 16,
            controls_met: 14,
            strengths: [
                "Automated vulnerability scanning with AWS Inspector",
                "Real-time system monitoring",
                "Malware protection deployed",
                "Security alerting and response",
                "Information system monitoring"
            ],
            gaps: [],
            next_steps: ["Continue regular vulnerability scan reviews."]
        }
    ]
};

// Defense contractor specific strategic implications
const DEFENSE_CONTRACTOR_IMPLICATIONS = {
    immediate_opportunities: {
        prime_contractors_available: [
            "Lockheed Martin", "Raytheon", "Boeing", "General Dynamics", "Northrop Grumman"
        ],
        contract_value_threshold: "New contracts starting late 2025",
        time_to_market: "The CMMC rollout is active. Non-compliant subs will be ineligible for new contracts starting imminently.",
        competitive_advantage: "First-mover advantage for compliant subcontractors to lock in prime relationships."
    },
    cost_breakdown: {
        traditional_path: {
            consultant_fees: "$50,000",
            implementation_costs: "$75,000", 
            audit_preparation: "$15,000",
            assessment_fees: "$10,000",
            total: "$150,000"
        },
        hypercore_path: {
            partnership_services_trade: "$0",
            infrastructure_upgrades: "$5,000",
            assessment_preparation: "$2,000",
            audit_fees: "$1,000",
            total: "$8,000"
        }
    },
    revenue_impact: {
        accessible_contract_value: "$2.5M - $50M annually",
        time_to_first_contract: "6-9 months post-compliance",
        roi_timeline: "First contract pays for entire compliance investment"
    }
};

export default function HyperCoreCMMCAssessment() {
    const [selectedDomain, setSelectedDomain] = useState(null);
    const [activeTab, setActiveTab] = useState('overview');

    const getStatusColor = (status) => {
        const colors = {
            excellent: "bg-green-100 text-green-800 border-green-200",
            strong: "bg-blue-100 text-blue-800 border-blue-200", 
            adequate: "bg-yellow-100 text-yellow-800 border-yellow-200",
            needs_improvement: "bg-orange-100 text-orange-800 border-orange-200",
            major_gaps: "bg-red-100 text-red-800 border-red-200"
        };
        return colors[status] || "bg-gray-100 text-gray-800 border-gray-200";
    };

    const getStatusIcon = (status) => {
        if (status === 'excellent' || status === 'strong') return <CheckCircle className="w-4 h-4 text-green-600" />;
        if (status === 'adequate') return <Target className="w-4 h-4 text-yellow-600" />;
        return <AlertTriangle className="w-4 h-4 text-red-600" />;
    };

    // Dummy function for navigation, replace with actual router logic in a real app
    const createPageUrl = (pageName) => {
        if (pageName === 'PartnershipInquiry') return '/partnership-inquiry';
        if (pageName === 'PartnershipPitch') return '/pitch-deck';
        return '#'; 
    };

    return (
        <div className="min-h-screen bg-gray-50 p-6">
            <div className="max-w-7xl mx-auto">
                <motion.div
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="text-center mb-8"
                >
                    <h1 className="text-4xl font-bold text-gray-900 mb-3 flex items-center justify-center gap-3">
                        <Shield className="w-10 h-10 text-blue-600" />
                        CMMC Level 2 Readiness for 2026 Mandate
                    </h1>
                    <p className="text-xl text-gray-600">
                        Achieve DoD Contract Readiness Before the Deadlines. Your Competitors Are Not Ready.
                    </p>
                </motion.div>

                <Alert className="mb-8 bg-yellow-50 border-yellow-200">
                    <Info className="h-4 w-4 text-yellow-700" />
                    <AlertTitle className="text-yellow-800">Demonstration Disclaimer</AlertTitle>
                    <AlertDescription className="text-yellow-700">
                        This is a sample CMMC Readiness Report. The data presented is based on pre-loaded, sample evidence and does not reflect a live scan of any organization's systems. The purpose is to demonstrate the output and analytical capabilities of our platform.
                    </AlertDescription>
                </Alert>
                
                <Alert className="mb-8 bg-blue-50 border-blue-200">
                    <Server className="h-4 w-4 text-blue-600" />
                    <AlertTitle className="text-blue-800">Now on AWS: The Compliance Accelerator</AlertTitle>
                    <AlertDescription className="text-blue-700">
                        HyperCore AI is now built on Amazon Web Services. We inherit a significant portion of CMMC's stringent physical and environmental controls directly from AWS, dramatically reducing your compliance burden and timeline. You're not just buying a service; you're leveraging a secure, pre-vetted infrastructure.
                    </AlertDescription>
                </Alert>

                <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
                    <TabsList className="grid w-full grid-cols-5">
                        <TabsTrigger value="overview">Readiness Overview</TabsTrigger>
                        <TabsTrigger value="domains">Technical Analysis</TabsTrigger>
                        <TabsTrigger value="ai_assessment">
                            <Brain className="w-4 h-4 mr-2" />
                            AI Assessment Demo
                        </TabsTrigger>
                        <TabsTrigger value="contractor_value">Defense Contractor ROI</TabsTrigger>
                        <TabsTrigger value="partnership">Get CMMC Ready</TabsTrigger>
                    </TabsList>

                    <TabsContent value="overview">
                        <div className="space-y-6">
                            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                                <Card className="bg-blue-50 border-blue-200">
                                    <CardHeader className="pb-3">
                                        <CardTitle className="text-lg text-blue-800">Current Readiness</CardTitle>
                                    </CardHeader>
                                    <CardContent>
                                        <div className="text-3xl font-bold text-blue-600 mb-2">{HYPERCORE_ASSESSMENT.overall_score}%</div>
                                        <div className="text-sm text-blue-700">CMMC Level 2 on AWS</div>
                                        <Progress value={HYPERCORE_ASSESSMENT.overall_score} className="mt-2" />
                                    </CardContent>
                                </Card>

                                <Card className="bg-green-50 border-green-200">
                                    <CardHeader className="pb-3">
                                        <CardTitle className="text-lg text-green-800">Cost Savings</CardTitle>
                                    </CardHeader>
                                    <CardContent>
                                        <div className="text-3xl font-bold text-green-600 mb-2">${parseInt(HYPERCORE_ASSESSMENT.defense_contractor_readiness.cost_savings.replace('$', '').replace(',', '')).toLocaleString()}</div>
                                        <div className="text-sm text-green-700">vs Traditional Path</div>
                                        <div className="text-xs text-gray-600 mt-1">${parseInt(HYPERCORE_ASSESSMENT.defense_contractor_readiness.estimated_cost_hypercore.replace('$', '').replace(',', '')).toLocaleString()} total vs ${parseInt(HYPERCORE_ASSESSMENT.defense_contractor_readiness.estimated_cost_traditional.replace('$', '').replace(',', '')).toLocaleString()} typical</div>
                                    </CardContent>
                                </Card>

                                <Card className="bg-purple-50 border-purple-200">
                                    <CardHeader className="pb-3">
                                        <CardTitle className="text-lg text-purple-800">Time to Compliant</CardTitle>
                                    </CardHeader>
                                    <CardContent>
                                        <div className="text-3xl font-bold text-purple-600 mb-2">{HYPERCORE_ASSESSMENT.defense_contractor_readiness.timeline_to_compliant}</div>
                                        <div className="text-sm text-purple-700">Fixed Timeline</div>
                                        <div className="text-xs text-gray-600 mt-1">vs 12-18 months traditional</div>
                                    </CardContent>
                                </Card>

                                <Card className="bg-yellow-50 border-yellow-200">
                                    <CardHeader className="pb-3">
                                        <CardTitle className="text-lg text-yellow-800">Contract Access</CardTitle>
                                    </CardHeader>
                                    <CardContent>
                                        <div className="text-3xl font-bold text-yellow-600 mb-2">{DEFENSE_CONTRACTOR_IMPLICATIONS.revenue_impact.accessible_contract_value.split('-')[1].trim().replace(' annually', '')}</div>
                                        <div className="text-sm text-yellow-700">Annual DoD Contract Access</div>
                                        <div className="text-xs text-gray-600 mt-1">Unlock subcontract opportunities</div>
                                    </CardContent>
                                </Card>
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                                {HYPERCORE_ASSESSMENT.domains.map((domain) => (
                                    <Card key={domain.id} className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => setSelectedDomain(domain)}>
                                        <CardHeader className="pb-3">
                                            <div className="flex justify-between items-start">
                                                <div>
                                                    <CardTitle className="text-lg">{domain.id} - {domain.name}</CardTitle>
                                                    <div className="text-sm text-gray-600 mt-1">
                                                        {domain.controls_met}/{domain.controls_total} controls met
                                                    </div>
                                                </div>
                                                {getStatusIcon(domain.status)}
                                            </div>
                                        </CardHeader>
                                        <CardContent>
                                            <div className="space-y-3">
                                                <div className="flex justify-between items-center">
                                                    <span className="text-2xl font-bold text-gray-900">{domain.score}%</span>
                                                    <Badge className={getStatusColor(domain.status)}>
                                                        {domain.status.replace('_', ' ')}
                                                    </Badge>
                                                </div>
                                                <Progress value={domain.score} />
                                                <p className="text-xs text-gray-600">{domain.description}</p>
                                            </div>
                                        </CardContent>
                                    </Card>
                                ))}
                            </div>
                        </div>
                    </TabsContent>

                    <TabsContent value="domains">
                        <div className="space-y-6">
                            {selectedDomain ? (
                                <motion.div
                                    initial={{ opacity: 0, y: 20 }}
                                    animate={{ opacity: 1, y: 0 }}
                                >
                                    <Card>
                                        <CardHeader>
                                            <div className="flex justify-between items-start">
                                                <div>
                                                    <CardTitle className="text-2xl">{selectedDomain.id} - {selectedDomain.name}</CardTitle>
                                                    <CardDescription>{selectedDomain.description}</CardDescription>
                                                </div>
                                                <Button variant="outline" onClick={() => setSelectedDomain(null)}>
                                                    Back to All Domains
                                                </Button>
                                            </div>
                                        </CardHeader>
                                        <CardContent>
                                            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                                                <div>
                                                    <h4 className="font-semibold text-green-700 mb-3 flex items-center gap-2">
                                                        <CheckCircle className="w-4 h-4" />
                                                        Strengths
                                                    </h4>
                                                    <ul className="space-y-2">
                                                        {selectedDomain.strengths.map((strength, index) => (
                                                            <li key={index} className="text-sm text-green-700 flex items-start gap-2">
                                                                <div className="w-2 h-2 bg-green-500 rounded-full mt-1.5 flex-shrink-0"></div>
                                                                {strength}
                                                            </li>
                                                        ))}
                                                    </ul>
                                                </div>
                                                
                                                <div>
                                                    <h4 className="font-semibold text-red-700 mb-3 flex items-center gap-2">
                                                        <AlertTriangle className="w-4 h-4" />
                                                        Gaps to Address
                                                    </h4>
                                                    <ul className="space-y-2">
                                                        {selectedDomain.gaps.map((gap, index) => (
                                                            <li key={index} className="text-sm text-red-700 flex items-start gap-2">
                                                                <div className="w-2 h-2 bg-red-500 rounded-full mt-1.5 flex-shrink-0"></div>
                                                                {gap}
                                                            </li>
                                                        ))}
                                                    </ul>
                                                </div>

                                                <div>
                                                    <h4 className="font-semibold text-blue-700 mb-3 flex items-center gap-2">
                                                        <Target className="w-4 h-4" />
                                                        Next Steps
                                                    </h4>
                                                    <ul className="space-y-2">
                                                        {selectedDomain.next_steps.map((step, index) => (
                                                            <li key={index} className="text-sm text-blue-700 flex items-start gap-2">
                                                                <div className="w-2 h-2 bg-blue-500 rounded-full mt-1.5 flex-shrink-0"></div>
                                                                {step}
                                                            </li>
                                                        ))}
                                                    </ul>
                                                </div>
                                            </div>

                                            {selectedDomain.competitive_advantage && (
                                                <Alert className="mt-6 bg-green-50 border-green-200">
                                                    <Zap className="h-4 w-4 text-green-600" />
                                                    <AlertTitle className="text-green-800">Competitive Advantage</AlertTitle>
                                                    <AlertDescription className="text-green-700">
                                                        {selectedDomain.competitive_advantage}
                                                    </AlertDescription>
                                                </Alert>
                                            )}

                                            {selectedDomain.strategic_note && (
                                                <Alert className="mt-6 bg-blue-50 border-blue-200">
                                                    <Building className="h-4 w-4 text-blue-600" />
                                                    <AlertTitle className="text-blue-800">Strategic Note</AlertTitle>
                                                    <AlertDescription className="text-blue-700">
                                                        {selectedDomain.strategic_note}
                                                    </AlertDescription>
                                                </Alert>
                                            )}
                                        </CardContent>
                                    </Card>
                                </motion.div>
                            ) : (
                                <Card>
                                    <CardHeader>
                                        <CardTitle>Select a Domain for Detailed Analysis</CardTitle>
                                        <CardDescription>Click on any domain above to see detailed findings, gaps, and remediation steps.</CardDescription>
                                    </CardHeader>
                                </Card>
                            )}
                        </div>
                    </TabsContent>

                    <TabsContent value="ai_assessment">
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2">
                                    <Brain className="w-5 h-5 text-purple-600" />
                                    AI-Powered Compliance Workflow
                                </CardTitle>
                                <CardDescription>
                                    Simulate a real C3PAO workflow. Select a control, upload evidence, and let our AI agent determine compliance.
                                </CardDescription>
                            </CardHeader>
                            <CardContent>
                                <AIAssessmentControl />
                            </CardContent>
                        </Card>
                    </TabsContent>

                    <TabsContent value="contractor_value">
                        <div className="space-y-6">
                            <Card>
                                <CardHeader>
                                    <CardTitle className="flex items-center gap-2">
                                        <TrendingUp className="w-5 h-5 text-green-600" />
                                        Defense Contractor Business Case
                                    </CardTitle>
                                    <CardDescription>
                                        Why proactive CMMC Level 2 compliance is your single greatest competitive advantage.
                                    </CardDescription>
                                </CardHeader>
                                <CardContent>
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                                        <div>
                                            <h4 className="font-semibold mb-4 text-red-700">The Problem: The Compliance Window is Closing</h4>
                                            <ul className="space-y-2 text-sm text-gray-700">
                                                <li className="flex items-start gap-2">
                                                    <AlertTriangle className="w-4 h-4 text-red-500 mt-0.5 flex-shrink-0" />
                                                    <strong>Late 2025:</strong> CMMC requirements begin appearing in new DoD contracts.
                                                </li>
                                                <li className="flex items-start gap-2">
                                                    <AlertTriangle className="w-4 h-4 text-red-500 mt-0.5 flex-shrink-0" />
                                                    <strong>Oct 31, 2026:</strong> Compliance is mandatory for ALL new DoD contracts.
                                                </li>
                                                <li className="flex items-start gap-2">
                                                    <AlertTriangle className="w-4 h-4 text-red-500 mt-0.5 flex-shrink-0" />
                                                    <strong>Widespread Unpreparedness:</strong> Reports show a significant number of defense contractors will not be ready in time.
                                                </li>
                                                <li className="flex items-start gap-2">
                                                    <AlertTriangle className="w-4 h-4 text-red-500 mt-0.5 flex-shrink-0" />
                                                    <strong>Locked Out:</strong> Unprepared contractors will be ineligible to bid, creating a massive opportunity for you.
                                                </li>
                                            </ul>
                                        </div>
                                        <div>
                                            <h4 className="font-semibold mb-4 text-green-700">The HyperCore Solution</h4>
                                            <ul className="space-y-2 text-sm text-gray-700">
                                                <li className="flex items-start gap-2">
                                                    <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                                                    <strong>{HYPERCORE_ASSESSMENT.defense_contractor_readiness.estimated_cost_hypercore} Total Cost:</strong> 95% savings vs traditional compliance approach
                                                </li>
                                                <li className="flex items-start gap-2">
                                                    <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                                                    <strong>{HYPERCORE_ASSESSMENT.defense_contractor_readiness.timeline_to_compliant} Timeline:</strong> Get compliant before the competition
                                                </li>
                                                <li className="flex items-start gap-2">
                                                    <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                                                    <strong>Partnership Model:</strong> Trade services instead of cash for platform access
                                                </li>
                                                <li className="flex items-start gap-2">
                                                    <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                                                    <strong>Ongoing Support:</strong> Continuous compliance monitoring and updates
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </CardContent>
                            </Card>

                            <Card>
                                <CardHeader>
                                    <CardTitle className="flex items-center gap-2">
                                        <DollarSign className="w-5 h-5 text-green-600" />
                                        ROI Analysis: Traditional vs HyperCore Path
                                    </CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                        <Card className="bg-red-50 border-red-200">
                                            <CardHeader>
                                                <CardTitle className="text-red-800">Traditional CMMC Path</CardTitle>
                                            </CardHeader>
                                            <CardContent className="space-y-2 text-sm">
                                                <div className="flex justify-between">
                                                    <span>CMMC Consultant:</span>
                                                    <span className="font-semibold">{DEFENSE_CONTRACTOR_IMPLICATIONS.cost_breakdown.traditional_path.consultant_fees}</span>
                                                </div>
                                                <div className="flex justify-between">
                                                    <span>Infrastructure Upgrades:</span>
                                                    <span className="font-semibold">{DEFENSE_CONTRACTOR_IMPLICATIONS.cost_breakdown.traditional_path.implementation_costs}</span>
                                                </div>
                                                <div className="flex justify-between">
                                                    <span>Audit Preparation:</span>
                                                    <span className="font-semibold">{DEFENSE_CONTRACTOR_IMPLICATIONS.cost_breakdown.traditional_path.audit_preparation}</span>
                                                </div>
                                                <div className="flex justify-between">
                                                    <span>Assessment Fees:</span>
                                                    <span className="font-semibold">{DEFENSE_CONTRACTOR_IMPLICATIONS.cost_breakdown.traditional_path.assessment_fees}</span>
                                                </div>
                                                <hr className="my-2" />
                                                <div className="flex justify-between font-bold text-lg text-red-700">
                                                    <span>Total:</span>
                                                    <span>{DEFENSE_CONTRACTOR_IMPLICATIONS.cost_breakdown.traditional_path.total}</span>
                                                </div>
                                                <div className="text-xs text-gray-600">Timeline: 12-18 months</div>
                                            </CardContent>
                                        </Card>

                                        <Card className="bg-green-50 border-green-200">
                                            <CardHeader>
                                                <CardTitle className="text-green-800">HyperCore Partnership Path</CardTitle>
                                            </CardHeader>
                                            <CardContent className="space-y-2 text-sm">
                                                <div className="flex justify-between">
                                                    <span>Platform Access (Trade):</span>
                                                    <span className="font-semibold text-green-600">{DEFENSE_CONTRACTOR_IMPLICATIONS.cost_breakdown.hypercore_path.partnership_services_trade}</span>
                                                </div>
                                                <div className="flex justify-between">
                                                    <span>Infrastructure Upgrades:</span>
                                                    <span className="font-semibold">{DEFENSE_CONTRACTOR_IMPLICATIONS.cost_breakdown.hypercore_path.infrastructure_upgrades}</span>
                                                </div>
                                                <div className="flex justify-between">
                                                    <span>Assessment Prep:</span>
                                                    <span className="font-semibold">{DEFENSE_CONTRACTOR_IMPLICATIONS.cost_breakdown.hypercore_path.assessment_preparation}</span>
                                                </div>
                                                <div className="flex justify-between">
                                                    <span>Audit Fees:</span>
                                                    <span className="font-semibold">{DEFENSE_CONTRACTOR_IMPLICATIONS.cost_breakdown.hypercore_path.audit_fees}</span>
                                                </div>
                                                <hr className="my-2" />
                                                <div className="flex justify-between font-bold text-lg text-green-700">
                                                    <span>Total:</span>
                                                    <span>{DEFENSE_CONTRACTOR_IMPLICATIONS.cost_breakdown.hypercore_path.total}</span>
                                                </div>
                                                <div className="text-xs text-gray-600">Timeline: {HYPERCORE_ASSESSMENT.defense_contractor_readiness.timeline_to_compliant}</div>
                                                <div className="mt-4 p-2 bg-green-100 rounded text-center">
                                                    <div className="font-bold text-green-800">Save {HYPERCORE_ASSESSMENT.defense_contractor_readiness.cost_savings}</div>
                                                    <div className="text-xs text-green-700">95% cost reduction</div>
                                                </div>
                                            </CardContent>
                                        </Card>
                                    </div>
                                </CardContent>
                            </Card>
                        </div>
                    </TabsContent>

                    <TabsContent value="partnership">
                        <div className="space-y-6">
                            <Card className="bg-gradient-to-r from-blue-50 to-green-50 border-blue-200">
                                <CardHeader className="text-center">
                                    <CardTitle className="text-2xl text-gray-900">Ready to Get CMMC Level 2 Compliant?</CardTitle>
                                    <CardDescription className="text-lg">
                                        You're {HYPERCORE_ASSESSMENT.overall_score}% ready today. We can get you to 100% in {HYPERCORE_ASSESSMENT.defense_contractor_readiness.timeline_to_compliant} for under ${parseInt(HYPERCORE_ASSESSMENT.defense_contractor_readiness.estimated_cost_hypercore.replace('$', '').replace(',', '')).toLocaleString()}.
                                    </CardDescription>
                                </CardHeader>
                                <CardContent className="text-center space-y-6">
                                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                        <div className="text-center">
                                            <div className="text-3xl font-bold text-blue-600">Step 1</div>
                                            <div className="font-semibold">Partnership Discussion</div>
                                            <div className="text-sm text-gray-600">30-minute call to understand your needs</div>
                                        </div>
                                        <div className="text-center">
                                            <div className="text-3xl font-bold text-blue-600">Step 2</div>
                                            <div className="font-semibold">Value Exchange Agreement</div>
                                            <div className="text-sm text-gray-600">Trade services for platform access</div>
                                        </div>
                                        <div className="text-center">
                                            <div className="text-3xl font-bold text-blue-600">Step 3</div>
                                            <div className="font-semibold">CMMC Compliance</div>
                                            <div className="text-sm text-gray-600">{HYPERCORE_ASSESSMENT.defense_contractor_readiness.timeline_to_compliant} to full certification</div>
                                        </div>
                                    </div>
                                    
                                    <div className="flex flex-col md:flex-row gap-4 justify-center">
                                        <Button asChild size="lg" className="bg-blue-600 hover:bg-blue-700">
                                            <a href={createPageUrl('PartnershipInquiry')}>
                                                <Shield className="w-5 h-5 mr-2" />
                                                Start CMMC Partnership
                                            </a>
                                        </Button>
                                        <Button asChild size="lg" variant="outline">
                                            <a href={createPageUrl('PartnershipPitch')}>
                                                <FileText className="w-5 h-5 mr-2" />
                                                View Full Pitch Deck
                                            </a>
                                        </Button>
                                    </div>
                                </CardContent>
                            </Card>

                            <Alert className="bg-yellow-50 border-yellow-200">
                                <Target className="h-4 w-4 text-yellow-600" />
                                <AlertTitle className="text-yellow-800">Critical Market Reality</AlertTitle>
                                <AlertDescription className="text-yellow-700">
                                    <strong>The CMMC rollout has begun.</strong> Contractors who are not compliant WILL be excluded from new bids starting in late 2025. This platform offers the fastest path to securing your future revenue.
                                </AlertDescription>
                            </Alert>
                        </div>
                    </TabsContent>
                </Tabs>
            </div>
        </div>
    );
}