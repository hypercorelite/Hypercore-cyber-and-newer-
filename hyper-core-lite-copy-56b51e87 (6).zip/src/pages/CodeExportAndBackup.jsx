import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Copy, Download, Github, Terminal, UploadCloud, Shield } from 'lucide-react';
import BreadcrumbNav from '../components/navigation/BreadcrumbNav';
import { toast } from "sonner";

const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    toast.success("Command copied to clipboard!");
};

const steps = [
    {
        title: "Export Your App's Code from Base44",
        icon: Download,
        description: "In the Base44 platform dashboard (not this app), navigate to your app's settings. Find and click the 'Export App' button. This will download a .ZIP file containing your entire application's source code.",
        details: "This ZIP file includes your React frontend pages and components, your backend function code, and your entity (database) schemas."
    },
    {
        title: "Create a Private GitHub Repository",
        icon: Github,
        description: "Go to GitHub.com and create a new, private repository. Name it something like 'hypercore-cmmc-ai-source'. This is where your code will live securely.",
        details: "A private repository ensures only you can see or access your application's proprietary code."
    },
    {
        title: "Unzip and Prepare the Code",
        icon: Terminal,
        description: "On your local computer, unzip the downloaded file. Open a terminal or command prompt and navigate into the unzipped folder using the 'cd' command.",
        command: "cd path/to/your-unzipped-app-folder"
    },
    {
        title: "Connect and Push to GitHub",
        icon: UploadCloud,
        description: "Run the following git commands in your terminal one by one. This will initialize a local repository, connect it to your remote GitHub repo, and upload all the code.",
        commands: [
            { cmd: "git init -b main", desc: "Initializes a new Git repository." },
            { cmd: "git remote add origin YOUR_GITHUB_REPO_URL.git", desc: "Connects your local folder to GitHub. (Copy the URL from your GitHub page)." },
            { cmd: "git add .", desc: "Stages all your files for the first commit." },
            { cmd: 'git commit -m "Initial commit from Base44 export"', desc: "Saves your files in Git history." },
            { cmd: "git push -u origin main", desc: "Uploads your code to GitHub." },
        ]
    }
];

export default function CodeExportAndBackup() {
    return (
        <div className="space-y-6">
            <BreadcrumbNav currentPageName="Code Export & Backup" />
            <div className="text-center">
                <h1 className="text-3xl font-bold">Code Export & GitHub Backup Guide</h1>
                <p className="text-lg text-gray-600 mt-2">Your step-by-step guide to taking full ownership of your application's source code.</p>
            </div>

            <Alert className="bg-blue-50 border-blue-200">
                <Shield className="h-4 w-4" />
                <AlertTitle className="font-bold text-blue-800">The Strategic Goal: Code Ownership</AlertTitle>
                <AlertDescription className="text-blue-700">
                    The purpose of this process is to give you a complete, independent copy of your application's code. This is the first step towards migrating to a platform like AWS GovCloud and achieving ultimate security and control.
                </AlertDescription>
            </Alert>

            <div className="space-y-4">
                {steps.map((step, index) => (
                    <Card key={index}>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-3">
                                <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center">
                                    <step.icon className="w-5 h-5 text-gray-600" />
                                </div>
                                <span>{step.title}</span>
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="mb-4">{step.description}</p>
                            {step.details && <p className="text-sm text-gray-500 bg-gray-50 p-3 rounded-md mb-4">{step.details}</p>}
                            
                            {step.command && (
                                <div className="relative bg-gray-800 text-white p-3 rounded-md font-mono text-sm">
                                    <code>{step.command}</code>
                                    <Button size="icon" variant="ghost" className="absolute top-1/2 right-2 -translate-y-1/2 h-8 w-8" onClick={() => copyToClipboard(step.command)}>
                                        <Copy className="h-4 w-4" />
                                    </Button>
                                </div>
                            )}

                            {step.commands && (
                                <div className="space-y-2">
                                    {step.commands.map((c, i) => (
                                        <div key={i} className="space-y-1">
                                            <p className="text-xs font-semibold text-gray-600">{c.desc}</p>
                                            <div className="relative bg-gray-800 text-white p-3 rounded-md font-mono text-sm">
                                                <code>{c.cmd}</code>
                                                <Button size="icon" variant="ghost" className="absolute top-1/2 right-2 -translate-y-1/2 h-8 w-8" onClick={() => copyToClipboard(c.cmd)}>
                                                    <Copy className="h-4 w-4" />
                                                </Button>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            )}
                        </CardContent>
                    </Card>
                ))}
            </div>

            <Alert>
                <AlertTitle className="font-bold">Process Complete</AlertTitle>
                <AlertDescription>
                    Once you have completed these steps, your application's full source code will be securely backed up in your private GitHub repository, ready for future development or migration.
                </AlertDescription>
            </Alert>
        </div>
    );
}