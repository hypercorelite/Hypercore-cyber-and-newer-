
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Copy, Download, Github, Terminal, UploadCloud, Shield, Server, Zap } from 'lucide-react';
import BreadcrumbNav from '../components/navigation/BreadcrumbNav';
import { toast } from "sonner";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    toast.success("Command copied to clipboard!");
};

// Moved priorityColors outside to be accessible by both StepCard and CodeExportAndMigration component
const priorityColors = {
    CRITICAL: "bg-red-100 text-red-800 border-red-200",
    RECOMMENDED: "bg-blue-100 text-blue-800 border-blue-200"
};

const migrationSteps = [
    {
        title: "Export Your App from Base44",
        icon: Download,
        priority: "CRITICAL",
        description: "Get a complete copy of your application code and data schemas",
        details: "In the Base44 platform dashboard (not this app), navigate to your app's settings and click 'Export App'. Download the ZIP file containing all your code.",
        timeEstimate: "5 minutes"
    },
    {
        title: "Connect to Your AWS Staging Server", 
        icon: Server,
        priority: "CRITICAL",
        description: "Access your newly created EC2 instance to prepare it for deployment",
        details: "Use the SSH command from AWS Console to connect to your server",
        command: "ssh -i \"hypercore-staging-key.pem\" ec2-user@18.117.115.4",
        timeEstimate: "5 minutes"
    },
    {
        title: "Deploy App to Staging Server",
        icon: UploadCloud,
        priority: "CRITICAL", 
        description: "Set up your exported application on the EC2 instance",
        details: "Upload the ZIP file to your server and configure it to run",
        commands: [
            { cmd: "sudo yum update -y", desc: "Update the server packages" },
            { cmd: "sudo yum install -y nodejs npm unzip", desc: "Install Node.js and utilities" },
            { cmd: "scp -i hypercore-staging-key.pem app-export.zip ec2-user@18.117.115.4:~/", desc: "Upload your app files" },
            { cmd: "unzip app-export.zip && cd app-export/", desc: "Extract and enter the app directory" },
            { cmd: "npm install && npm start", desc: "Install dependencies and start the app" }
        ],
        timeEstimate: "30-45 minutes"
    },
    {
        title: "Install AWS MGN Agent",
        icon: Zap,
        priority: "CRITICAL",
        description: "Install the Migration Service agent to begin server replication.",
        details: "The MGN agent will continuously replicate your server to create the production copy. To get your keys for the command below, follow our secure setup guide.",
        commands: [
            { cmd: "wget https://aws-application-migration-service-us-east-1.s3.us-east-1.amazonaws.com/latest/linux/aws-replication-installer-init.py", desc: "Download MGN installer" },
            { cmd: "sudo python3 aws-replication-installer-init.py --region us-east-1 --aws-access-key-id YOUR_KEY --aws-secret-access-key YOUR_SECRET", desc: "Install and configure MGN agent" }
        ],
        timeEstimate: "15-20 minutes"
    }
];

const optionalSteps = [
    {
        title: "Create GitHub Backup (Optional)",
        icon: Github,
        priority: "RECOMMENDED",
        description: "Create a private repository for code ownership and version control",
        details: "While not required for migration, this gives you complete code ownership",
        commands: [
            { cmd: "git init -b main", desc: "Initialize Git repository" },
            { cmd: "git remote add origin YOUR_GITHUB_REPO_URL.git", desc: "Connect to GitHub repository" },
            { cmd: "git add . && git commit -m \"Initial commit from Base44 export\"", desc: "Commit your code" },
            { cmd: "git push -u origin main", desc: "Upload to GitHub" }
        ],
        timeEstimate: "15 minutes"
    }
];

const StepCard = ({ step, isOptional = false }) => {
    return (
        <Card className={`${isOptional ? 'border-dashed' : 'border-solid'} mb-4`}>
            <CardHeader>
                <CardTitle className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center">
                        <step.icon className="w-5 h-5 text-gray-600" />
                    </div>
                    <span>{step.title}</span>
                    <Badge className={priorityColors[step.priority]}>
                        {step.priority}
                    </Badge>
                    <span className="text-sm text-gray-500 ml-auto">{step.timeEstimate}</span>
                </CardTitle>
            </CardHeader>
            <CardContent>
                <p className="mb-4 text-gray-700">{step.description}</p>
                {step.details && (
                    <p className="text-sm text-gray-600 bg-gray-50 p-3 rounded-md mb-4">{step.details}</p>
                )}
                
                {step.command && (
                    <div className="relative bg-gray-800 text-white p-3 rounded-md font-mono text-sm mb-4">
                        <code>{step.command}</code>
                        <Button 
                            size="icon" 
                            variant="ghost" 
                            className="absolute top-1/2 right-2 -translate-y-1/2 h-8 w-8 text-gray-400 hover:bg-gray-700 hover:text-white" 
                            onClick={() => copyToClipboard(step.command)}
                        >
                            <Copy className="h-4 w-4" />
                        </Button>
                    </div>
                )}

                {step.commands && (
                    <div className="space-y-3">
                        {step.commands.map((c, i) => (
                            <div key={i} className="space-y-2">
                                <p className="text-xs font-semibold text-gray-600">{c.desc}</p>
                                <div className="relative bg-gray-800 text-white p-3 rounded-md font-mono text-sm">
                                    <code>{c.cmd}</code>
                                    <Button 
                                        size="icon" 
                                        variant="ghost" 
                                        className="absolute top-1/2 right-2 -translate-y-1/2 h-8 w-8 text-gray-400 hover:bg-gray-700 hover:text-white" 
                                        onClick={() => copyToClipboard(c.cmd)}
                                    >
                                        <Copy className="h-4 w-4" />
                                    </Button>
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </CardContent>
        </Card>
    );
};

export default function CodeExportAndMigration() {
    return (
        <div className="space-y-6">
            <BreadcrumbNav currentPageName="Code Export & Migration Guide" />
            
            <div className="text-center">
                <h1 className="text-3xl font-bold text-gray-900">Week 3: Base44 Export → AWS Migration</h1>
                <p className="text-lg text-gray-600 mt-2">Your step-by-step guide to migrating from Base44 to AWS infrastructure</p>
            </div>

            <Alert className="bg-blue-50 border-blue-200">
                <Shield className="h-4 w-4" />
                <AlertTitle className="font-bold text-blue-800">Migration Strategy: Server Replication</AlertTitle>
                <AlertDescription className="text-blue-700">
                    We'll export your app, deploy it on your staging EC2 server, then use AWS MGN to create a production-ready copy. 
                    This approach is reliable, auditable, and gives you complete infrastructure control.
                </AlertDescription>
            </Alert>

            <Card className="border-green-200 bg-green-50">
                <CardHeader>
                    <CardTitle className="text-green-800">🎯 Your Migration Target</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="grid md:grid-cols-2 gap-4">
                        <div>
                            <h4 className="font-semibold text-green-700 mb-2">Staging Server (Current)</h4>
                            <p className="text-sm text-green-600">
                                <strong>Instance:</strong> i-064da99d018c7c309<br/>
                                <strong>Public IP:</strong> 18.117.115.4<br/>
                                <strong>Status:</strong> ✅ Ready and Running
                            </p>
                        </div>
                        <div>
                            <h4 className="font-semibold text-green-700 mb-2">Production Server (Target)</h4>
                            <p className="text-sm text-green-600">
                                Will be created automatically by AWS MGN<br/>
                                Identical configuration, optimized for production<br/>
                                <strong>Timeline:</strong> Week 4-5 of sprint plan
                            </p>
                        </div>
                    </div>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle className="text-2xl font-bold text-gray-900">Critical Migration Steps</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    {migrationSteps.map((step, index) => (
                        <Card key={index} className="border-l-4 border-blue-500">
                            <CardHeader>
                                <CardTitle className="flex items-center gap-3">
                                    <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center">
                                        <step.icon className="w-5 h-5 text-gray-600" />
                                    </div>
                                    <span>{step.title}</span>
                                    <Badge className={priorityColors[step.priority]}>
                                        {step.priority}
                                    </Badge>
                                    <span className="text-sm text-gray-500 ml-auto">{step.timeEstimate}</span>
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <p className="mb-4 text-gray-700">{step.description}</p>
                                {step.details && (
                                    <p className="text-sm text-gray-600 bg-gray-50 p-3 rounded-md mb-4">{step.details}</p>
                                )}
                                
                                {step.title === "Install AWS MGN Agent" && (
                                    <Alert className="mb-4">
                                        <AlertTitle>Need your AWS keys?</AlertTitle>
                                        <AlertDescription>
                                            <Button asChild variant="link" className="p-0 h-auto">
                                                <Link to={createPageUrl('MGNAgentSetupGuide')}>
                                                    Follow this guide to create secure credentials.
                                                </Link>
                                            </Button>
                                        </AlertDescription>
                                    </Alert>
                                )}

                                {step.command && (
                                    <div className="relative bg-gray-800 text-white p-3 rounded-md font-mono text-sm mb-4">
                                        <code>{step.command}</code>
                                        <Button 
                                            size="icon" 
                                            variant="ghost" 
                                            className="absolute top-1/2 right-2 -translate-y-1/2 h-8 w-8 text-gray-400 hover:bg-gray-700 hover:text-white" 
                                            onClick={() => copyToClipboard(step.command)}
                                        >
                                            <Copy className="h-4 w-4" />
                                        </Button>
                                    </div>
                                )}

                                {step.commands && (
                                    <div className="space-y-3">
                                        {step.commands.map((c, i) => (
                                            <div key={i} className="space-y-2">
                                                <p className="text-xs font-semibold text-gray-600">{c.desc}</p>
                                                <div className="relative bg-gray-800 text-white p-3 rounded-md font-mono text-sm">
                                                    <code>{c.cmd}</code>
                                                    <Button 
                                                        size="icon" 
                                                        variant="ghost" 
                                                        className="absolute top-1/2 right-2 -translate-y-1/2 h-8 w-8 text-gray-400 hover:bg-gray-700 hover:text-white" 
                                                        onClick={() => copyToClipboard(c.cmd)}
                                                    >
                                                        <Copy className="h-4 w-4" />
                                                    </Button>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                )}
                            </CardContent>
                        </Card>
                    ))}
                </CardContent>
            </Card>

            <div>
                <h2 className="text-2xl font-bold text-gray-700 mb-4">Optional: Code Ownership Steps</h2>
                <p className="text-gray-600 mb-4">These steps aren't required for migration but give you complete code ownership:</p>
                {optionalSteps.map((step, index) => (
                    <StepCard key={index} step={step} isOptional={true} />
                ))}
            </div>

            <Alert className="bg-yellow-50 border-yellow-300">
                <AlertTitle className="font-bold text-yellow-800">Timeline Expectations</AlertTitle>
                <AlertDescription className="text-yellow-700 mt-2">
                    <div className="grid md:grid-cols-2 gap-4">
                        <div>
                            <h4 className="font-semibold">This Week (Week 3):</h4>
                            <ul className="text-sm list-disc list-inside space-y-1">
                                <li>Export and deploy to staging server</li>
                                <li>Install MGN agent and begin replication</li>
                                <li>Total time: 3-4 hours</li>
                            </ul>
                        </div>
                        <div>
                            <h4 className="font-semibold">Next Week (Week 4):</h4>
                            <ul className="text-sm list-disc list-inside space-y-1">
                                <li>Test the migrated production server</li>
                                <li>Validate all functionality works</li>
                                <li>Prepare for DNS cutover</li>
                            </ul>
                        </div>
                    </div>
                </AlertDescription>
            </Alert>
        </div>
    );
}
