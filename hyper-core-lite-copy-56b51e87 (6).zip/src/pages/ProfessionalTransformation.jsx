
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CheckCircle, Shield, FileText, Briefcase, Gavel, DollarSign, ArrowRight, Building, Users } from 'lucide-react';
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

const llcDetails = {
    entityName: "HyperCore Lite Cybersecurity Ecosystem LLC",
    entityId: "11897536",
    entityType: "Limited Liability Company",
    stateOfFormation: "Virginia",
    status: "Active",
    formationDate: "09/04/2025",
    registeredAgent: "Christine Boes",
    principalOffice: "11410 Bacon Race Rd, Woodbridge, VA, 22192, USA"
};

const einDetails = {
    ein: "39-4162842",
    legalName: "HYPERCORE LITE CYBERSECURITY ECOSYSTEM LLC",
    organizationType: "Single Member Limited Liability Company (LLC)",
    principalActivity: "Cyber Security and AI Model Training",
    assignmentDate: "September 2025",
    responsibleParty: "Christine Boes"
};

const policyDetails = {
    insurer: "Hiscox",
    policyType: "Technology E&O & Cyber Liability",
    policyPeriod: "09/11/2025 - 09/11/2026",
    generalLiability: "$500,000",
    professionalLiability: "$250,000",
    cyberLiability: "$250,000",
    documentationContact: "Christine@dannyboes.com",
    annualPremium: "$516.00"
};

const transformationSteps = [
    { text: "LLC Formation Completed", icon: Gavel, status: 'completed' },
    { text: "Federal EIN Assignment", icon: FileText, status: 'completed' },
    { text: "Business Insurance Secured", icon: Shield, status: 'completed' },
    { text: "Banking & Payment Systems Live", icon: DollarSign, status: 'completed' },
    { text: "Master Service Agreement Drafted", icon: Briefcase, status: 'active' },
    { text: "First Client Onboarded", icon: Users, status: 'pending' }
];

export default function ProfessionalTransformation() {
    const statusStyles = {
        completed: {
            bg: "bg-green-50 border-green-200",
            icon: CheckCircle,
            iconColor: "text-green-600",
            textColor: "text-gray-500 line-through",
            badge: null
        },
        active: {
            bg: "bg-blue-50 border-blue-200",
            iconColor: "text-blue-600",
            textColor: "text-blue-800",
            badge: <Badge className="ml-auto bg-blue-600">Current Focus</Badge>
        },
        pending: {
            bg: "bg-gray-50",
            iconColor: "text-gray-400",
            textColor: "text-gray-600",
            badge: null
        }
    };

    return (
        <div className="space-y-8 p-4 sm:p-6 lg:p-8">
            <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center"
            >
                <Badge className="mb-4 bg-green-100 text-green-800">MILESTONE ACHIEVED</Badge>
                <h1 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-3">
                    Professional Transformation & Market Readiness
                </h1>
                <p className="text-lg lg:text-xl text-gray-600 max-w-3xl mx-auto">
                    From a bootstrapped concept to a legally protected, insurable, and credible professional service ready for the defense industrial base.
                </p>
            </motion.div>

            <div className="max-w-4xl mx-auto">
                <Card className="overflow-hidden">
                    <CardHeader className="bg-gray-50 border-b">
                        <CardTitle className="flex items-center gap-3 text-xl">
                            <Building className="w-6 h-6 text-indigo-600" />
                            Legal Entity Status
                        </CardTitle>
                        <CardDescription>
                            Official registration details from the Virginia State Corporation Commission.
                        </CardDescription>
                    </CardHeader>
                    <CardContent className="p-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-4 text-sm">
                            <div><strong>Entity Name:</strong> {llcDetails.entityName}</div>
                            <div><strong>Entity ID:</strong> {llcDetails.entityId}</div>
                            <div><strong>Entity Type:</strong> {llcDetails.entityType}</div>
                            <div><strong>State of Formation:</strong> {llcDetails.stateOfFormation}</div>
                            <div><strong>Formation Date:</strong> {llcDetails.formationDate}</div>
                            <div><strong>Status:</strong> <Badge className="bg-green-100 text-green-800">{llcDetails.status}</Badge></div>
                            <div><strong>Registered Agent:</strong> {llcDetails.registeredAgent}</div>
                            <div className="md:col-span-2"><strong>Principal Office:</strong> {llcDetails.principalOffice}</div>
                        </div>
                    </CardContent>
                </Card>

                <Card className="overflow-hidden mt-8">
                    <CardHeader className="bg-gray-50 border-b">
                        <CardTitle className="flex items-center gap-3 text-xl">
                            <FileText className="w-6 h-6 text-green-600" />
                            Federal Tax Identification (EIN)
                        </CardTitle>
                        <CardDescription>
                            Official IRS assignment enabling business banking, tax filing, and federal recognition.
                        </CardDescription>
                    </CardHeader>
                    <CardContent className="p-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-4 text-sm">
                            <div><strong>EIN:</strong> <Badge className="font-mono bg-green-100 text-green-800">{einDetails.ein}</Badge></div>
                            <div><strong>Assignment Date:</strong> {einDetails.assignmentDate}</div>
                            <div><strong>Organization Type:</strong> {einDetails.organizationType}</div>
                            <div><strong>Principal Activity:</strong> {einDetails.principalActivity}</div>
                            <div><strong>Responsible Party:</strong> {einDetails.responsibleParty}</div>
                            <div><strong>Legal Name:</strong> {einDetails.legalName}</div>
                        </div>
                        <div className="mt-4 pt-4 border-t">
                            <h4 className="font-semibold mb-2 text-green-800">Immediate Business Capabilities Unlocked:</h4>
                            <ul className="space-y-1 list-disc list-inside text-sm">
                                <li><span className="font-bold text-green-700">Open business bank accounts (Completed with United Bank)</span></li>
                                <li>Apply for business licenses and permits</li>
                                <li>File business tax returns</li>
                                <li><span className="font-bold text-green-700">Enter into contracts as a legitimate business entity (Ready for Net-30 Wire Transfer)</span></li>
                                <li>Apply for business credit and financing</li>
                            </ul>
                        </div>
                    </CardContent>
                </Card>

                <Card className="overflow-hidden mt-8">
                    <CardHeader className="bg-gray-50 border-b">
                        <CardTitle className="flex items-center gap-3 text-xl">
                            <Shield className="w-6 h-6 text-blue-600" />
                            Active Business Insurance Policy
                        </CardTitle>
                        <CardDescription>
                            This policy provides critical Errors & Omissions (E&O) and Cyber Liability coverage, enabling confident market entry.
                        </CardDescription>
                    </CardHeader>
                    <CardContent className="p-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-4 text-sm">
                            <div><strong>Insurer:</strong> <Badge variant="outline">{policyDetails.insurer}</Badge></div>
                            <div><strong>Policy Type:</strong> {policyDetails.policyType}</div>
                            <div><strong>Policy Period:</strong> {policyDetails.policyPeriod}</div>
                            <div><strong>Annual Premium:</strong> ${policyDetails.annualPremium}</div>
                            <div className="md:col-span-2"><strong>Documentation Contact:</strong> <a href={`mailto:${policyDetails.documentationContact}`} className="text-blue-600 hover:underline">{policyDetails.documentationContact}</a></div>
                            <div className="md:col-span-2 pt-4 mt-4 border-t">
                                <h4 className="font-semibold mb-2">Coverage Limits:</h4>
                                <ul className="space-y-1 list-disc list-inside">
                                    <li><strong>Professional Liability (E&O):</strong> ${policyDetails.professionalLiability} per claim</li>
                                    <li><strong>General Aggregate Liability:</strong> ${policyDetails.generalLiability}</li>
                                    <li><strong>Cyber Liability:</strong> ${policyDetails.cyberLiability} per claim</li>
                                </ul>
                            </div>
                        </div>
                    </CardContent>
                </Card>

                <Alert className="mt-8 bg-green-50 border-green-200">
                    <CheckCircle className="h-4 w-4 text-green-700" />
                    <AlertTitle className="text-green-800 font-bold">Market Impact</AlertTitle>
                    <AlertDescription className="text-green-700">
                        With insurance in place, you are no longer just a consultant; you are a professional services firm. This unlocks the ability to sign MSAs with larger contractors and demonstrates a commitment to risk management that clients expect.
                    </AlertDescription>
                </Alert>

                <Card className="mt-8">
                    <CardHeader>
                        <CardTitle>Bootstrapper's Roadmap to a Prime Contractor</CardTitle>
                        <CardDescription>Tracking our progress from formation to market leadership.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-4">
                            {transformationSteps.map((step, index) => {
                                const style = statusStyles[step.status];
                                const StepIcon = step.status === 'completed' ? style.icon : step.icon;
                                return (
                                    <div key={index} className={`flex items-center p-3 rounded-md ${style.bg}`}>
                                        <StepIcon className={`w-5 h-5 mr-3 ${style.iconColor}`} />
                                        <span className={`font-medium ${style.textColor}`}>{step.text}</span>
                                        {style.badge}
                                    </div>
                                );
                            })}
                        </div>
                    </CardContent>
                </Card>

                <div className="mt-8 text-center">
                     <Button asChild>
                        <Link to={createPageUrl('LegalStrategy')}>
                            Review Our Legal & Risk Framework <ArrowRight className="w-4 h-4 ml-2" />
                        </Link>
                    </Button>
                </div>
            </div>
        </div>
    );
}
