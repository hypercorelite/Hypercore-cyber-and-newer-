import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { TrendingUp, Target, Search, Users, FileText, BarChart, Zap, Globe } from 'lucide-react';
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";

const primaryKeywords = [
    { keyword: "CMMC Level 2 assessment", volume: "1,200/month", difficulty: "Medium", intent: "High Commercial" },
    { keyword: "NIST 800-171 automation", volume: "800/month", difficulty: "Low", intent: "High Commercial" },
    { keyword: "DoD contractor compliance", volume: "2,100/month", difficulty: "High", intent: "Medium Commercial" },
    { keyword: "automated CMMC assessment", volume: "450/month", difficulty: "Low", intent: "Very High Commercial" },
    { keyword: "CMMC gap analysis tool", volume: "320/month", difficulty: "Low", intent: "Very High Commercial" },
    { keyword: "SPRS score automation", volume: "180/month", difficulty: "Very Low", intent: "Very High Commercial" }
];

const contentStrategy = [
    {
        title: "CMMC Implementation Guides",
        description: "Step-by-step guides for each NIST 800-171 control",
        keywords: "CMMC implementation, NIST 800-171 controls, DoD compliance guide",
        contentType: "Educational Long-form",
        frequency: "2 per week",
        businessValue: "Builds trust and demonstrates expertise"
    },
    {
        title: "Cost Comparison Calculators",
        description: "Interactive tools showing cost savings vs consultants/GRC tools",
        keywords: "CMMC consultant cost, GRC tool comparison, compliance cost calculator",
        contentType: "Interactive Tools",
        frequency: "1 per month",
        businessValue: "Captures leads actively comparing solutions"
    },
    {
        title: "CMMC News and Updates",
        description: "Commentary on new CMMC regulations and DoD announcements",
        keywords: "CMMC 2.0 updates, DoD cybersecurity news, CMMC regulation changes",
        contentType: "News Analysis",
        frequency: "Weekly",
        businessValue: "Positions as thought leader and industry expert"
    }
];

const technicalSEO = [
    {
        area: "Page Speed Optimization",
        current: "Good (85/100)",
        target: "Excellent (95+/100)",
        impact: "Higher rankings, better user experience",
        actions: ["Optimize images", "Minimize JavaScript", "Enable caching"]
    },
    {
        area: "Mobile Responsiveness",
        current: "Good",
        target: "Perfect",
        impact: "Mobile-first indexing advantage",
        actions: ["Test all forms on mobile", "Optimize touch targets", "Improve mobile navigation"]
    },
    {
        area: "Schema Markup",
        current: "Basic",
        target: "Comprehensive",
        impact: "Rich snippets, better SERP visibility",
        actions: ["Add Organization schema", "Implement FAQ schema", "Add Service schema"]
    }
];

const competitorAnalysis = [
    {
        competitor: "Traditional CMMC Consultants",
        strength: "Established relationships, proven track record",
        weakness: "Expensive, slow, not scalable",
        seoOpportunity: "Target 'automated CMMC' and 'DIY CMMC' keywords they ignore"
    },
    {
        competitor: "GRC Software (Archer, ServiceNow)",
        strength: "Enterprise features, compliance frameworks",
        weakness: "Complex, expensive, requires experts to operate",
        seoOpportunity: "Target 'simple CMMC tool' and 'CMMC for small contractors' keywords"
    },
    {
        competitor: "CMMC Training Companies",
        strength: "Educational content, industry connections",
        weakness: "Don't provide actual implementation tools",
        seoOpportunity: "Target 'CMMC implementation tool' and 'automated CMMC compliance' keywords"
    }
];

export default function SEOOptimizationStrategy() {
    return (
        <div className="space-y-8 p-4 md:p-6">
            <BreadcrumbNav currentPageName="SEOOptimizationStrategy" />
            
            <div className="text-center">
                <Badge className="mb-4 text-lg bg-green-100 text-green-800">SEO STRATEGY</Badge>
                <h1 className="text-3xl font-bold text-gray-900 mb-4">
                    SEO & Market Penetration Strategy for DoD Contractors
                </h1>
                <p className="text-lg text-gray-600 max-w-4xl mx-auto">
                    Data-driven approach to capture DoD contractors actively searching for CMMC compliance solutions
                </p>
            </div>

            <Alert className="bg-blue-50 border-blue-200">
                <Globe className="h-4 w-4 text-blue-700" />
                <AlertTitle className="font-bold text-blue-800">SEO Opportunity Assessment</AlertTitle>
                <AlertDescription className="text-blue-700">
                    High-value, low-competition keywords in the CMMC space represent a significant opportunity. Most competitors focus on generic "cybersecurity" terms instead of specific DoD contractor pain points.
                </AlertDescription>
            </Alert>

            <Tabs defaultValue="keywords" className="w-full">
                <TabsList className="grid w-full grid-cols-4">
                    <TabsTrigger value="keywords">Target Keywords</TabsTrigger>
                    <TabsTrigger value="content">Content Strategy</TabsTrigger>
                    <TabsTrigger value="technical">Technical SEO</TabsTrigger>
                    <TabsTrigger value="competitors">Competitor Analysis</TabsTrigger>
                </TabsList>

                <TabsContent value="keywords">
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <Search className="text-blue-600" />
                                High-Value Keyword Targets
                            </CardTitle>
                            <CardDescription>Keywords with high commercial intent and achievable rankings</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <div className="overflow-x-auto">
                                <table className="w-full text-sm">
                                    <thead>
                                        <tr className="border-b">
                                            <th className="text-left p-2">Keyword</th>
                                            <th className="text-left p-2">Monthly Volume</th>
                                            <th className="text-left p-2">Difficulty</th>
                                            <th className="text-left p-2">Commercial Intent</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {primaryKeywords.map((kw, index) => (
                                            <tr key={index} className="border-b hover:bg-gray-50">
                                                <td className="p-2 font-medium">{kw.keyword}</td>
                                                <td className="p-2">{kw.volume}</td>
                                                <td className="p-2">
                                                    <Badge variant={kw.difficulty === 'Low' || kw.difficulty === 'Very Low' ? 'default' : 'secondary'}>
                                                        {kw.difficulty}
                                                    </Badge>
                                                </td>
                                                <td className="p-2">
                                                    <Badge variant={kw.intent.includes('Very High') ? 'default' : 'secondary'}>
                                                        {kw.intent}
                                                    </Badge>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="content">
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <FileText className="text-green-600" />
                                Content Marketing Strategy
                            </CardTitle>
                            <CardDescription>Educational content that builds trust and captures leads</CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-6">
                            {contentStrategy.map((strategy, index) => (
                                <div key={index} className="p-4 bg-gray-50 rounded-lg">
                                    <h3 className="font-semibold text-gray-800 mb-2">{strategy.title}</h3>
                                    <p className="text-sm text-gray-600 mb-3">{strategy.description}</p>
                                    <div className="grid md:grid-cols-2 gap-4 text-xs">
                                        <div>
                                            <p><strong>Target Keywords:</strong> {strategy.keywords}</p>
                                            <p><strong>Content Type:</strong> {strategy.contentType}</p>
                                        </div>
                                        <div>
                                            <p><strong>Publishing Frequency:</strong> {strategy.frequency}</p>
                                            <p><strong>Business Value:</strong> {strategy.businessValue}</p>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="technical">
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <Zap className="text-orange-600" />
                                Technical SEO Optimization
                            </CardTitle>
                            <CardDescription>Foundation improvements for better search visibility</CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-6">
                            {technicalSEO.map((item, index) => (
                                <div key={index} className="p-4 border rounded-lg">
                                    <div className="flex justify-between items-start mb-3">
                                        <h3 className="font-semibold text-gray-800">{item.area}</h3>
                                        <div className="text-sm">
                                            <span className="text-gray-500">Current: </span>
                                            <span className="font-medium">{item.current}</span>
                                            <span className="text-gray-500"> → Target: </span>
                                            <span className="font-medium text-green-600">{item.target}</span>
                                        </div>
                                    </div>
                                    <p className="text-sm text-gray-600 mb-3">{item.impact}</p>
                                    <div>
                                        <p className="text-sm font-medium text-gray-700 mb-1">Action Items:</p>
                                        <ul className="text-xs space-y-1">
                                            {item.actions.map((action, i) => (
                                                <li key={i} className="flex items-center gap-2">
                                                    <div className="w-1.5 h-1.5 bg-blue-500 rounded-full"></div>
                                                    {action}
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                                </div>
                            ))}
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="competitors">
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <Target className="text-purple-600" />
                                Competitive SEO Landscape
                            </CardTitle>
                            <CardDescription>How to outrank established players in CMMC space</CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-6">
                            {competitorAnalysis.map((comp, index) => (
                                <div key={index} className="p-4 bg-gray-50 rounded-lg">
                                    <h3 className="font-semibold text-gray-800 mb-3">{comp.competitor}</h3>
                                    <div className="grid md:grid-cols-2 gap-4 text-sm">
                                        <div>
                                            <p className="text-green-700"><strong>Their Strength:</strong> {comp.strength}</p>
                                            <p className="text-red-700 mt-2"><strong>Their Weakness:</strong> {comp.weakness}</p>
                                        </div>
                                        <div>
                                            <p className="text-blue-700"><strong>Your SEO Opportunity:</strong></p>
                                            <p className="text-blue-600 text-sm mt-1">{comp.seoOpportunity}</p>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </CardContent>
                    </Card>
                </TabsContent>
            </Tabs>

            <Alert className="bg-green-50 border-green-200">
                <TrendingUp className="h-4 w-4 text-green-700" />
                <AlertTitle className="font-bold text-green-800">90-Day SEO Action Plan</AlertTitle>
                <AlertDescription className="text-green-700">
                    <strong>Week 1-2:</strong> Technical SEO fixes, schema markup<br/>
                    <strong>Week 3-8:</strong> Publish 12 educational CMMC articles targeting primary keywords<br/>
                    <strong>Week 9-12:</strong> Build backlinks through guest posting and industry partnerships<br/>
                    <strong>Expected Result:</strong> 300% increase in organic traffic, top 3 rankings for "automated CMMC assessment"
                </AlertDescription>
            </Alert>
        </div>
    );
}