
import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { generatePdf } from "@/api/functions/generatePdf";
import { LetterOfIntent } from "@/api/entities";
import { toast } from "sonner";
import { FileSignature, Loader2 } from "lucide-react";
import { submitLOI } from "@/api/functions"; // Import the new function

// The form structure you designed, now used to dynamically build the page.
const formDefinition = {
  "formMetadata": {
    "title": "HyperCore Cyber CMMC Compliance Platform Letter of Intent",
    "version": "1.0.0",
    "date": "2025-09-17",
    "description": "Engagement form for SMB DoD contractors to commit to HyperCore Cyber's AI platform and provide feedback for SBIR Phase I data synthesis.",
    "compliance": "CMMC Level 2, NIST SP 800-171, DFARS 252.204-7021"
  },
  "formFields": [
    {
      "id": "companyInfo",
      "section": "Contractor Information",
      "fields": [
        { "label": "Company Name", "type": "text", "name": "companyName", "required": true, "placeholder": "Enter your company name (e.g., ABC Defense Tech, Inc.)" },
        { "label": "CAGE Code", "type": "text", "name": "cageCode", "required": true, "placeholder": "Enter CAGE Code (e.g., 1ABC2)" },
        { "label": "UEI", "type": "text", "name": "uei", "required": true, "placeholder": "Enter UEI (e.g., X123Y456Z789)" },
        { "label": "DoD Contract Number(s)", "type": "text", "name": "contractNumbers", "required": false, "placeholder": "List relevant DoD contract numbers" }
      ]
    },
    {
      "id": "representativeInfo",
      "section": "Responsible Representative",
      "fields": [
        { "label": "Full Name", "type": "text", "name": "repName", "required": true, "placeholder": "Enter full name (e.g., John Doe)" },
        { "label": "Title", "type": "text", "name": "repTitle", "required": true, "placeholder": "Enter title (e.g., Compliance Officer)" },
        { "label": "Email", "type": "email", "name": "repEmail", "required": true, "placeholder": "Enter email (e.g., john.doe@company.com)" }
      ]
    },
    {
      "id": "commitment",
      "section": "Letter of Intent",
      "fields": [
        {
          "label": "Commitment to Use HyperCore Platform",
          "type": "dropdown",
          "name": "commitmentLevel",
          "required": true,
          "options": [
            "Pilot Participant (Phase I Beta, Free)",
            "Early Adopter (Post-Phase I, Freemium)",
            "Paid Subscriber ($99/month Post-Phase II)"
          ],
          "default": "Pilot Participant (Phase I Beta, Free)"
        },
        {
          "label": "Intent Statement",
          "type": "textarea",
          "name": "intentStatement",
          "required": true,
          "default": "As a DoD contractor, we intend to use HyperCore Cyber’s AI platform to prepare for CMMC Level 2 compliance, including SSP generation, policy development, and 3PAO audit readiness, to meet DFARS 252.204-7021 requirements."
        }
      ]
    },
    {
      "id": "feedback",
      "section": "Platform Feedback",
      "fields": [
        { "label": "What You Like", "type": "textarea", "name": "likeFeedback", "required": true, "placeholder": "Describe features you like (e.g., AI SSP automation, user-friendly interface)" },
        { "label": "What You Love", "type": "textarea", "name": "loveFeedback", "required": true, "placeholder": "Highlight standout features (e.g., cost savings, Base64 PDF export)" },
        { "label": "What to Improve", "type": "textarea", "name": "improveFeedback", "required": true, "placeholder": "Suggest enhancements (e.g., integrate with SharePoint, add mobile support)" },
        { "label": "Top Priority Feature", "type": "dropdown", "name": "priorityFeatures", "required": true, "options": ["Automated SSP Generation", "Policy and Procedure Templates", "110-Control Mapping and Scoring", "POA&M and SPRS Reporting", "Implementation Guidance", "Mock 3PAO Audit Simulator"], "default": "Automated SSP Generation" }
      ]
    },
    {
      "id": "signature",
      "section": "Digital Signature",
      "fields": [
        { "label": "Signature Name", "type": "text", "name": "signatureName", "required": true, "placeholder": "Type your full name to sign" },
        { "label": "Date", "type": "date", "name": "signatureDate", "required": true },
        { "label": "I agree to the terms and consent to this digital signature.", "type": "checkbox", "name": "digitalSignatureConsent", "required": true }
      ]
    }
  ]
};

const initialState = {
    companyName: '', cageCode: '', uei: '', contractNumbers: '',
    repName: '', repTitle: '', repEmail: '',
    commitmentLevel: 'Pilot Participant (Phase I Beta, Free)',
    intentStatement: "As a DoD contractor, we intend to use HyperCore Cyber’s AI platform to prepare for CMMC Level 2 compliance, including SSP generation, policy development, and 3PAO audit readiness, to meet DFARS 252.204-7021 requirements.",
    likeFeedback: '', loveFeedback: '', improveFeedback: '',
    priorityFeatures: 'Automated SSP Generation',
    signatureName: '', signatureDate: new Date().toISOString().split('T')[0], digitalSignatureConsent: false,
};

export default function GenerateLOI() {
    const [formData, setFormData] = useState<LetterOfIntent>(initialState);
    const [isLoading, setIsLoading] = useState(false);

    const handleChange = (name: string, value: string | boolean) => {
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const validateForm = () => {
        let isValid = true;
        const requiredFields = formDefinition.formFields.flatMap(section =>
            section.fields.filter(field => field.required).map(field => field.name)
        );

        for (const fieldName of requiredFields) {
            const value = formData[fieldName as keyof LetterOfIntent];
            if (typeof value === 'string' && !value.trim()) {
                toast.error(`Please fill in the "${fieldName}" field.`);
                isValid = false;
            } else if (typeof value === 'boolean' && !value) {
                toast.error(`Please agree to the terms for digital signature.`);
                isValid = false;
            }
        }
        return isValid;
    };

    const handleGenerateAndSign = async () => {
        if (!validateForm()) return;
        setIsLoading(true);

        const pdfDoc = generatePdf(formData);
        pdfDoc.save(`${formData.companyName.replace(/\s+/g, '_')}_LOI.pdf`);
        
        toast.success("LOI PDF generated and downloaded!");

        try {
            // New: Submit data to backend for analytics
            const { data, error } = await submitLOI(formData);
            if (error || !data.success) {
                throw new Error(error?.message || "Failed to log submission.");
            }
            toast.info("Your feedback has been securely logged for our SBIR program. Thank you!");
            
            // Optionally clear form or redirect
            // setFormData({ ...initialState });

        } catch (err) {
            console.error("Submission logging failed:", err);
            toast.error("Could not log your submission for analytics.", {
                description: "The PDF was generated, but we failed to record the submission."
            });
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="min-h-screen bg-gray-100 dark:bg-gray-900 text-gray-900 dark:text-gray-100 p-8 flex justify-center">
            <div className="w-full max-w-4xl bg-white dark:bg-gray-800 shadow-lg rounded-lg p-8">
                <h1 className="text-4xl font-bold text-center mb-6 text-gray-800 dark:text-gray-200">
                    {formDefinition.formMetadata.title}
                </h1>
                <p className="text-center text-gray-600 dark:text-gray-400 mb-8">
                    {formDefinition.formMetadata.description}
                </p>

                {formDefinition.formFields.map(section => (
                    <div key={section.id} className="mb-8 p-6 border border-gray-200 dark:border-gray-700 rounded-lg shadow-sm">
                        <h2 className="text-2xl font-semibold mb-6 pb-2 border-b border-gray-300 dark:border-gray-600">
                            {section.section}
                        </h2>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            {section.fields.map(field => (
                                <div key={field.name} className={`${field.type === 'textarea' || (section.id === 'commitment' && field.name === 'intentStatement') ? 'md:col-span-2' : ''}`}>
                                    <Label htmlFor={field.name} className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                        {field.label} {field.required && <span className="text-red-500">*</span>}
                                    </Label>
                                    {field.type === 'text' || field.type === 'email' || field.type === 'date' ? (
                                        <Input
                                            type={field.type}
                                            id={field.name}
                                            name={field.name}
                                            value={String(formData[field.name as keyof LetterOfIntent])}
                                            onChange={(e) => handleChange(field.name, e.target.value)}
                                            placeholder={field.placeholder}
                                            required={field.required}
                                            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-gray-200"
                                        />
                                    ) : field.type === 'textarea' ? (
                                        <Textarea
                                            id={field.name}
                                            name={field.name}
                                            value={String(formData[field.name as keyof LetterOfIntent])}
                                            onChange={(e) => handleChange(field.name, e.target.value)}
                                            placeholder={field.placeholder}
                                            required={field.required}
                                            rows={field.name === 'intentStatement' ? 5 : 3}
                                            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-gray-200"
                                        />
                                    ) : field.type === 'dropdown' ? (
                                        <Select
                                            name={field.name}
                                            value={String(formData[field.name as keyof LetterOfIntent])}
                                            onValueChange={(value) => handleChange(field.name, value)}
                                            required={field.required}
                                        >
                                            <SelectTrigger className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-gray-200">
                                                <SelectValue placeholder={field.label} />
                                            </SelectTrigger>
                                            <SelectContent className="dark:bg-gray-700 dark:text-gray-200">
                                                {field.options?.map(option => (
                                                    <SelectItem key={option} value={option}>{option}</SelectItem>
                                                ))}
                                            </SelectContent>
                                        </Select>
                                    ) : field.type === 'checkbox' ? (
                                        <div className="flex items-center space-x-2 mt-3">
                                            <Checkbox
                                                id={field.name}
                                                checked={Boolean(formData[field.name as keyof LetterOfIntent])}
                                                onCheckedChange={(checked) => handleChange(field.name, checked as boolean)}
                                                required={field.required}
                                                className="dark:border-gray-400 dark:checked:bg-blue-600"
                                            />
                                            <Label htmlFor={field.name} className="text-sm text-gray-700 dark:text-gray-300">
                                                {field.label}
                                            </Label>
                                        </div>
                                    ) : null}
                                </div>
                            ))}
                        </div>
                    </div>
                ))}

                <div className="flex justify-center mt-10">
                    <Button
                        onClick={handleGenerateAndSign}
                        className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-lg shadow-md transition duration-300 ease-in-out flex items-center justify-center"
                        disabled={isLoading}
                    >
                        {isLoading ? (
                            <>
                                <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                                Processing...
                            </>
                        ) : (
                            <>
                                <FileSignature className="mr-2 h-5 w-5" />
                                Generate & Sign LOI
                            </>
                        )}
                    </Button>
                </div>
            </div>
        </div>
    );
}
