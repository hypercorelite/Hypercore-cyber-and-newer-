import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend } from "recharts";
import { Zap, Server, Cpu, MemoryStick, Timer, CheckCircle, AlertTriangle, Gauge } from "lucide-react";
import { motion } from "framer-motion";
import { runLoadTestSimulation } from "@/api/functions";
import { toast } from "sonner";

export default function LoadTesting() {
    const [testConfig, setTestConfig] = useState({
        concurrentUsers: 50,
        durationSeconds: 30,
        testTarget: "AI_Analysis_Pipeline"
    });
    const [isRunning, setIsRunning] = useState(false);
    const [results, setResults] = useState(null);

    const handleRunSimulation = async () => {
        setIsRunning(true);
        setResults(null);
        toast.info(`Starting load test simulation for ${testConfig.concurrentUsers} users...`);

        try {
            const response = await runLoadTestSimulation(testConfig);
            if (response.status === 200) {
                setResults(response.data);
                toast.success("Simulation complete! Results are available.");
            } else {
                toast.error("Simulation failed. Please check backend logs.");
            }
        } catch (error) {
            console.error("Load test error:", error);
            toast.error("An error occurred during the simulation.");
        } finally {
            setIsRunning(false);
        }
    };

    return (
        <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50 p-6">
            <div className="max-w-7xl mx-auto">
                <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
                    <h1 className="text-4xl font-bold text-gray-900 mb-2 flex items-center gap-3">
                        <Gauge className="w-10 h-10 text-blue-600" />
                        System Load Testing Dashboard
                    </h1>
                    <p className="text-lg text-gray-600">
                        Simulate heavy user traffic to demonstrate platform stability and performance to partners.
                    </p>
                </motion.div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    <Card className="lg:col-span-1">
                        <CardHeader>
                            <CardTitle>Configure Simulation</CardTitle>
                            <CardDescription>Set the parameters for your load test.</CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div>
                                <label className="text-sm font-medium">Concurrent Users</label>
                                <Input 
                                    type="number" 
                                    value={testConfig.concurrentUsers}
                                    onChange={(e) => setTestConfig({...testConfig, concurrentUsers: parseInt(e.target.value)})}
                                />
                            </div>
                            <div>
                                <label className="text-sm font-medium">Test Duration (seconds)</label>
                                <Input 
                                    type="number"
                                    value={testConfig.durationSeconds}
                                    onChange={(e) => setTestConfig({...testConfig, durationSeconds: parseInt(e.target.value)})}
                                />
                            </div>
                            <div>
                                <label className="text-sm font-medium">Target System</label>
                                <Select value={testConfig.testTarget} onValueChange={(v) => setTestConfig({...testConfig, testTarget: v})}>
                                    <SelectTrigger>
                                        <SelectValue placeholder="Select a system to test" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="AI_Analysis_Pipeline">AI Analysis Pipeline</SelectItem>
                                        <SelectItem value="CMMC_Assessment_Engine">CMMC Assessment Engine</SelectItem>
                                        <SelectItem value="Legal_Document_Generation">Legal Document Generation</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                            <Button onClick={handleRunSimulation} disabled={isRunning} className="w-full">
                                {isRunning ? (
                                    <><Zap className="w-4 h-4 mr-2 animate-spin" />Running Simulation...</>
                                ) : (
                                    <><Zap className="w-4 h-4 mr-2" />Run Simulation</>
                                )}
                            </Button>
                        </CardContent>
                    </Card>

                    <Card className="lg:col-span-2">
                        <CardHeader>
                            <CardTitle>Performance Results</CardTitle>
                            <CardDescription>Real-time metrics from the simulation.</CardDescription>
                        </CardHeader>
                        <CardContent>
                            {isRunning && (
                                <div className="text-center py-20">
                                    <Zap className="w-12 h-12 mx-auto text-blue-500 animate-ping" />
                                    <p className="mt-4 font-semibold text-blue-600">Simulation in progress...</p>
                                </div>
                            )}
                            {results ? (
                                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
                                    <div className="h-64 mb-6">
                                        <ResponsiveContainer width="100%" height="100%">
                                            <LineChart data={results.metrics}>
                                                <XAxis dataKey="time" unit="s" />
                                                <YAxis yAxisId="left" stroke="#8884d8" />
                                                <YAxis yAxisId="right" orientation="right" stroke="#82ca9d" />
                                                <Tooltip />
                                                <Legend />
                                                <Line yAxisId="left" type="monotone" dataKey="apiResponseTime" name="Response Time (ms)" stroke="#8884d8" />
                                                <Line yAxisId="right" type="monotone" dataKey="cpuUsage" name="CPU (%)" stroke="#82ca9d" />
                                            </LineChart>
                                        </ResponsiveContainer>
                                    </div>
                                    <Card className="bg-gray-50">
                                        <CardHeader>
                                            <CardTitle>Simulation Summary</CardTitle>
                                        </CardHeader>
                                        <CardContent>
                                            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                                                <div className={`p-3 rounded-lg ${results.summary.performance_grade === 'Excellent' ? 'bg-green-100' : 'bg-red-100'}`}>
                                                    <div className="text-lg font-bold">{results.summary.performance_grade}</div>
                                                    <div className="text-sm text-gray-600">Performance</div>
                                                </div>
                                                <div className="p-3 bg-blue-50 rounded-lg">
                                                    <div className="text-lg font-bold">{results.summary.averageResponseTime}ms</div>
                                                    <div className="text-sm text-gray-600">Avg. Response Time</div>
                                                </div>
                                                <div className="p-3 bg-purple-50 rounded-lg">
                                                    <div className="text-lg font-bold">{results.summary.averageCpuUsage}%</div>
                                                    <div className="text-sm text-gray-600">Avg. CPU Load</div>
                                                </div>
                                                <div className="p-3 bg-red-50 rounded-lg">
                                                    <div className="text-lg font-bold">{results.summary.totalFailedRequests}</div>
                                                    <div className="text-sm text-gray-600">Failed Requests</div>
                                                </div>
                                            </div>
                                            <div className="mt-4 bg-white p-3 rounded-lg border">
                                                <h4 className="font-semibold text-sm">AI Recommendation:</h4>
                                                <p className="text-sm text-gray-700">{results.summary.ai_recommendation}</p>
                                            </div>
                                        </CardContent>
                                    </Card>
                                </motion.div>
                            ) : (
                                !isRunning && <div className="text-center text-gray-500 py-20">Configure and run a simulation to see results.</div>
                            )}
                        </CardContent>
                    </Card>
                </div>
            </div>
        </div>
    );
}