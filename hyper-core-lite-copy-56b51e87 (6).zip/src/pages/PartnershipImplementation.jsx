import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { 
    Target, 
    Users, 
    Calendar, 
    DollarSign, 
    CheckCircle, 
    Clock, 
    Phone,
    Mail,
    FileText,
    Handshake,
    TrendingUp
} from 'lucide-react';

const IMPLEMENTATION_ROADMAP = {
    week1: {
        title: "Week 1: Foundation & Target List",
        budget: "$0-200",
        hours_required: "15-20 hours",
        tasks: [
            {
                task: "Create Partner Target Database",
                description: "Research and identify 25-30 potential partners across legal, insurance, and C3PAO categories",
                tools_needed: ["LinkedIn Sales Navigator (free trial)", "Google Sheets", "State bar association directories"],
                deliverable: "Spreadsheet with contact info, firm size, specializations, partnership fit score",
                time_estimate: "6-8 hours"
            },
            {
                task: "Develop Partnership Pitch Materials",
                description: "Create a 10-slide deck and 2-page executive summary showcasing platform value",
                tools_needed: ["Canva or PowerPoint", "Platform screenshots", "Mock case studies"],
                deliverable: "Professional pitch deck + executive summary PDF",
                time_estimate: "4-6 hours"
            },
            {
                task: "Set Up Outreach Systems",
                description: "Create email templates, tracking systems, and follow-up workflows",
                tools_needed: ["Gmail", "Google Calendar", "Simple CRM (HubSpot free)"],
                deliverable: "Outreach system ready for scalable partner contact",
                time_estimate: "3-4 hours"
            },
            {
                task: "Legal Foundation Check",
                description: "Ensure you can legally offer services and enter partnerships",
                tools_needed: ["Business registration verification", "Basic liability research"],
                deliverable: "Clear understanding of legal requirements and limitations",
                time_estimate: "2-3 hours"
            }
        ]
    },
    week2_3: {
        title: "Weeks 2-3: Initial Outreach & Discovery",
        budget: "$100-300",
        hours_required: "20-25 hours",
        tasks: [
            {
                task: "Execute Partner Outreach Campaign",
                description: "Contact 20-25 target partners with personalized outreach messages",
                approach: "LinkedIn messages + follow-up emails. 5 contacts per day, personalized for each firm",
                tools_needed: ["LinkedIn Premium ($60/month)", "Email tracking tools", "Calendar scheduling"],
                deliverable: "10-12 partnership discovery calls scheduled",
                time_estimate: "12-15 hours"
            },
            {
                task: "Conduct Discovery Calls",
                description: "Run 30-45 minute discovery calls to understand partner needs and pain points",
                call_structure: ["5 min: Intro & platform overview", "15 min: Partner pain point discovery", "15 min: Platform demo", "10 min: Next steps discussion"],
                deliverable: "Detailed notes on partner needs, 3-5 qualified partnership opportunities",
                time_estimate: "8-10 hours"
            }
        ]
    },
    week4_6: {
        title: "Weeks 4-6: Pilot Program Launch",
        budget: "$200-500", 
        hours_required: "25-30 hours",
        tasks: [
            {
                task: "Negotiate Pilot Agreements",
                description: "Structure 2-3 pilot partnerships with clear value exchange terms",
                framework: "2-month pilot: Free platform access in exchange for feedback, testimonials, and specific services",
                deliverable: "2-3 signed pilot partnership agreements",
                time_estimate: "8-10 hours"
            },
            {
                task: "Customize Platform for Pilot Partners",
                description: "Minor customizations to make platform more relevant for each partner",
                customizations: ["Partner-specific branding elements", "Custom report templates", "Partner-relevant data examples"],
                deliverable: "Partner-ready platform instances",
                time_estimate: "10-12 hours"
            },
            {
                task: "Launch Client Demonstrations",
                description: "Help pilot partners demonstrate platform value to their clients",
                support: "Join partner-client meetings, provide technical support, gather client feedback",
                deliverable: "5-8 successful client demonstrations with measurable value",
                time_estimate: "8-12 hours"
            }
        ]
    },
    week7_12: {
        title: "Weeks 7-12: Validation & Scale Preparation",
        budget: "$300-800",
        hours_required: "30-40 hours",
        tasks: [
            {
                task: "Document Partnership Success",
                description: "Create case studies, collect testimonials, quantify partner ROI",
                documentation: ["Time savings for partners", "Client value delivered", "New business generated", "Cost reductions achieved"],
                deliverable: "Professional case studies and partnership success metrics",
                time_estimate: "8-10 hours"
            },
            {
                task: "Expand Pilot Program",
                description: "Add 2-3 additional partners based on lessons learned from initial pilots",
                approach: "Use success stories from pilot partners to attract additional partnerships",
                deliverable: "5-6 total active partnerships",
                time_estimate: "12-15 hours"
            },
            {
                task: "Prepare AWS Migration Plan",
                description: "Based on partnership success, create detailed AWS migration and scaling plan",
                components: ["AWS architecture design", "Migration timeline", "Budget requirements", "Partnership scaling strategy"],
                deliverable: "AWS migration roadmap and funding justification",
                time_estimate: "6-8 hours"
            },
            {
                task: "Negotiate Long-Term Agreements",
                description: "Convert successful pilots into formal, long-term partnership agreements",
                goal: "$50K+ in committed annual traded services",
                deliverable: "Formal partnership contracts with committed service values",
                time_estimate: "8-12 hours"
            }
        ]
    }
};

const PARTNER_OUTREACH_TEMPLATES = {
    initial_linkedin: {
        subject: "AI-Powered Client Assessment Tool for [FIRM NAME]",
        template: `Hi [FIRST NAME],

I've been following [FIRM NAME]'s work in [PRACTICE AREA] and I'm impressed by your focus on [SPECIFIC DETAIL FROM RESEARCH].

I've developed an AI platform that helps law firms like yours provide immediate, valuable cybersecurity assessments to clients - turning what used to be a referral to outside consultants into a high-value service you can offer directly.

The platform generates professional CMMC compliance reports and threat intelligence analysis that many of our partner firms are using to:
• Identify new billable opportunities with existing clients
• Demonstrate technical expertise in cybersecurity law
• Provide immediate value in client consultations

Would you be interested in a brief 15-minute demo to see how this might fit your practice? I'm happy to show you exactly how other firms are using it.

Best,
[YOUR NAME]
HyperCore AI Platform`
    },
    insurance_broker: {
        subject: "Pre-Underwriting Risk Assessment for Cyber Liability",
        template: `Hi [FIRST NAME],

I noticed [BROKERAGE NAME] specializes in cyber liability coverage - an increasingly challenging market for accurate risk assessment.

I've built an AI-powered risk assessment platform that several insurance brokers are now using to:
• Pre-qualify cyber liability applicants before carrier submission
• Provide data-driven risk scores to support pricing negotiations
• Identify specific security improvements that could lower premiums

The platform uses CMMC compliance as a proxy for overall cyber maturity and cross-references against live threat intelligence.

Would you be interested in a quick demo of how this could improve your underwriting accuracy and win rates?

Best regards,
[YOUR NAME]
HyperCore Risk Assessment Platform`
    }
};

const SUCCESS_METRICS = {
    week4_targets: {
        partnerships: "2-3 pilot partnerships signed",
        calls: "10+ discovery calls completed", 
        qualified_leads: "5+ qualified partnership opportunities",
        budget_spent: "Under $500"
    },
    week8_targets: {
        partnerships: "3-5 active partnerships",
        client_demos: "8+ client demonstrations",
        value_generated: "Measurable ROI for partners",
        testimonials: "2+ partner testimonials"
    },
    week12_targets: {
        partnerships: "5-6 active partnerships",
        committed_services: "$25K+ in committed traded services",
        case_studies: "3+ professional case studies",
        aws_readiness: "Clear AWS migration justification"
    }
};

export default function PartnershipImplementation() {
    const [activeWeek, setActiveWeek] = useState('week1');
    const [checkedTasks, setCheckedTasks] = useState({});

    const handleTaskCheck = (weekKey, taskIndex) => {
        const key = `${weekKey}-${taskIndex}`;
        setCheckedTasks(prev => ({
            ...prev,
            [key]: !prev[key]
        }));
    };

    return (
        <div className="min-h-screen bg-gray-50 p-6">
            <div className="max-w-7xl mx-auto">
                <div className="text-center mb-8">
                    <h1 className="text-4xl font-bold text-gray-900 mb-3">
                        Partnership Implementation Roadmap
                    </h1>
                    <p className="text-xl text-gray-600">
                        Your step-by-step guide to validating partnerships on Base44 over the next 12 weeks
                    </p>
                </div>

                <Alert className="mb-8 bg-blue-50 border-blue-200">
                    <Target className="h-4 w-4 text-blue-600" />
                    <AlertTitle className="text-blue-800">Implementation Goal</AlertTitle>
                    <AlertDescription className="text-blue-700">
                        By Week 12: <strong>5-6 active partnerships</strong> generating <strong>$50K+ in committed traded services</strong> annually, with clear justification for AWS migration investment.
                    </AlertDescription>
                </Alert>

                <Tabs value={activeWeek} onValueChange={setActiveWeek} className="space-y-6">
                    <TabsList className="grid w-full grid-cols-4">
                        <TabsTrigger value="week1">Week 1</TabsTrigger>
                        <TabsTrigger value="week2_3">Weeks 2-3</TabsTrigger>
                        <TabsTrigger value="week4_6">Weeks 4-6</TabsTrigger>
                        <TabsTrigger value="week7_12">Weeks 7-12</TabsTrigger>
                    </TabsList>

                    {Object.entries(IMPLEMENTATION_ROADMAP).map(([key, phase]) => (
                        <TabsContent key={key} value={key}>
                            <Card>
                                <CardHeader>
                                    <div className="flex justify-between items-start">
                                        <div>
                                            <CardTitle className="text-xl">{phase.title}</CardTitle>
                                            <CardDescription className="text-base">
                                                Budget: {phase.budget} | Time: {phase.hours_required}
                                            </CardDescription>
                                        </div>
                                        <div className="text-right">
                                            <div className="text-sm text-gray-500">Progress</div>
                                            <div className="text-2xl font-bold text-blue-600">
                                                {Math.round((Object.keys(checkedTasks).filter(k => 
                                                    k.startsWith(key) && checkedTasks[k]
                                                ).length / phase.tasks.length) * 100) || 0}%
                                            </div>
                                        </div>
                                    </div>
                                </CardHeader>
                                <CardContent>
                                    <div className="space-y-6">
                                        {phase.tasks.map((task, index) => (
                                            <div key={index} className="border rounded-lg p-4 bg-white">
                                                <div className="flex items-start gap-3">
                                                    <Checkbox 
                                                        checked={checkedTasks[`${key}-${index}`] || false}
                                                        onCheckedChange={() => handleTaskCheck(key, index)}
                                                        className="mt-1"
                                                    />
                                                    <div className="flex-1">
                                                        <div className="flex justify-between items-start mb-2">
                                                            <h4 className="font-semibold text-gray-900">{task.task}</h4>
                                                            <Badge variant="outline">{task.time_estimate}</Badge>
                                                        </div>
                                                        <p className="text-sm text-gray-600 mb-3">{task.description}</p>
                                                        
                                                        {task.tools_needed && (
                                                            <div className="mb-3">
                                                                <div className="text-xs font-semibold text-gray-500 mb-1">TOOLS NEEDED:</div>
                                                                <div className="text-xs text-gray-600">{task.tools_needed.join(", ")}</div>
                                                            </div>
                                                        )}
                                                        
                                                        {task.approach && (
                                                            <div className="mb-3">
                                                                <div className="text-xs font-semibold text-gray-500 mb-1">APPROACH:</div>
                                                                <div className="text-xs text-gray-600">{task.approach}</div>
                                                            </div>
                                                        )}

                                                        {task.call_structure && (
                                                            <div className="mb-3">
                                                                <div className="text-xs font-semibold text-gray-500 mb-1">CALL STRUCTURE:</div>
                                                                <ul className="text-xs text-gray-600 space-y-1">
                                                                    {task.call_structure.map((item, i) => (
                                                                        <li key={i}>• {item}</li>
                                                                    ))}
                                                                </ul>
                                                            </div>
                                                        )}

                                                        {task.framework && (
                                                            <div className="mb-3">
                                                                <div className="text-xs font-semibold text-gray-500 mb-1">FRAMEWORK:</div>
                                                                <div className="text-xs text-gray-600">{task.framework}</div>
                                                            </div>
                                                        )}

                                                        <div className="bg-green-50 border border-green-200 rounded p-2">
                                                            <div className="text-xs font-semibold text-green-800 mb-1">DELIVERABLE:</div>
                                                            <div className="text-xs text-green-700">{task.deliverable}</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </CardContent>
                            </Card>
                        </TabsContent>
                    ))}
                </Tabs>

                <div className="mt-8 grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <Mail className="w-5 h-5" />
                                Outreach Templates
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-4">
                                <div>
                                    <h4 className="font-semibold text-sm mb-2">Legal Firms - LinkedIn Message</h4>
                                    <div className="text-xs bg-gray-50 p-3 rounded border">
                                        <div className="font-semibold mb-1">Subject: {PARTNER_OUTREACH_TEMPLATES.initial_linkedin.subject}</div>
                                        <div className="whitespace-pre-line">{PARTNER_OUTREACH_TEMPLATES.initial_linkedin.template}</div>
                                    </div>
                                </div>
                                <div>
                                    <h4 className="font-semibold text-sm mb-2">Insurance Brokers - Email</h4>
                                    <div className="text-xs bg-gray-50 p-3 rounded border">
                                        <div className="font-semibold mb-1">Subject: {PARTNER_OUTREACH_TEMPLATES.insurance_broker.subject}</div>
                                        <div className="whitespace-pre-line">{PARTNER_OUTREACH_TEMPLATES.insurance_broker.template}</div>
                                    </div>
                                </div>
                            </div>
                        </CardContent>
                    </Card>

                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <TrendingUp className="w-5 h-5" />
                                Success Metrics Timeline
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-4">
                                {Object.entries(SUCCESS_METRICS).map(([key, metrics]) => (
                                    <div key={key}>
                                        <h4 className="font-semibold text-sm mb-2 capitalize">{key.replace('_', ' ')}</h4>
                                        <div className="bg-blue-50 p-3 rounded border space-y-1">
                                            {Object.entries(metrics).map(([metric, target]) => (
                                                <div key={metric} className="flex justify-between text-xs">
                                                    <span className="capitalize">{metric.replace('_', ' ')}:</span>
                                                    <span className="font-semibold">{target}</span>
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>
                </div>

                <Card className="mt-8 bg-gradient-to-r from-green-50 to-blue-50">
                    <CardHeader>
                        <CardTitle>🎯 Week 1 Priority Actions (Start Today)</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="grid md:grid-cols-3 gap-6">
                            <div className="space-y-2">
                                <h4 className="font-semibold text-green-800">Day 1-2: Research</h4>
                                <ul className="text-sm space-y-1">
                                    <li>• Sign up for LinkedIn Sales Navigator free trial</li>
                                    <li>• Create Google Sheet for partner tracking</li>
                                    <li>• Research 10 local law firms (5-25 attorneys)</li>
                                    <li>• Research 5 independent insurance brokers</li>
                                </ul>
                            </div>
                            <div className="space-y-2">
                                <h4 className="font-semibold text-blue-800">Day 3-5: Content Creation</h4>
                                <ul className="text-sm space-y-1">
                                    <li>• Create 10-slide partnership pitch deck</li>
                                    <li>• Write 2-page executive summary</li>
                                    <li>• Take platform screenshots for demos</li>
                                    <li>• Customize outreach templates</li>
                                </ul>
                            </div>
                            <div className="space-y-2">
                                <h4 className="font-semibold text-purple-800">Day 6-7: Setup</h4>
                                <ul className="text-sm space-y-1">
                                    <li>• Set up HubSpot free CRM</li>
                                    <li>• Create email tracking system</li>
                                    <li>• Schedule outreach time blocks</li>
                                    <li>• Prepare demo environment</li>
                                </ul>
                            </div>
                        </div>
                        
                        <Alert className="mt-6 bg-yellow-50 border-yellow-200">
                            <Clock className="h-4 w-4 text-yellow-600" />
                            <AlertDescription className="text-yellow-800">
                                <strong>Time Commitment:</strong> This roadmap requires 15-20 hours per week for the first month, then 10-15 hours per week. Block specific times for partnership development or it won't happen.
                            </AlertDescription>
                        </Alert>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}