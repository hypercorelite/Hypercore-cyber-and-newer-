
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Check, ShieldCheck, Server, Key, Eye, FileText, ArrowRight, Layers, CheckCircle } from 'lucide-react';
import { motion } from "framer-motion";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const foundationalPillars = [
    { name: 'AWS GovCloud (US)', description: 'Utilizing this isolated region designed for sensitive data simplifies compliance from day one.' },
    { name: 'Secure Enclave Architecture', description: 'Isolating all CUI data and processing into a dedicated, strictly controlled VPC.' },
    { name: 'VPC Segmentation', description: 'Using private subnets and network ACLs to create a defense-in-depth network architecture.' },
    { name: 'Shared Responsibility', description: 'Leveraging AWS security OF the cloud, while we guide you in securing everything IN the cloud.' },
];

const securityServicesConfig = [
    { 
        category: 'Access Control', 
        icon: Key,
        details: [
            'Enforce MFA for all users via IAM Identity Center.',
            'Apply the principle of least privilege using granular IAM policies.',
            'Use Service Control Policies (SCPs) to prevent insecure actions at the account level.'
        ] 
    },
    { 
        category: 'Data Protection', 
        icon: ShieldCheck,
        details: [
            'Mandate encryption at rest for S3, EBS, and RDS using AWS KMS with customer-managed keys.',
            'Enforce encryption in transit using strict S3 bucket policies that require HTTPS.',
            'Deploy Amazon Macie to automatically discover and classify CUI stored in S3.'
        ] 
    },
    { 
        category: 'Logging & Monitoring', 
        icon: Eye,
        details: [
            'Enable a multi-region CloudTrail with log file integrity validation for a tamper-proof audit trail.',
            'Deploy GuardDuty for intelligent threat detection across your AWS accounts.',
            'Use AWS Config rules to continuously assess resource configurations against CMMC requirements.'
        ] 
    },
    { 
        category: 'Incident Response', 
        icon: FileText,
        details: [
            'Centralize all findings in AWS Security Hub for a single pane of glass view of your security posture.',
            'Automate remediation for common findings using EventBridge and Lambda functions.',
            'Implement a robust data backup and recovery strategy with AWS Backup.'
        ] 
    }
];

export default function AWSCMMCIntegration() {
    return (
        <div className="bg-gray-50/50">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
                <motion.div
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="text-center mb-12"
                >
                    <h1 className="text-4xl lg:text-5xl font-extrabold text-gray-900 mb-4 tracking-tight">
                        Our AWS Security Strategy for CMMC
                    </h1>
                    <p className="text-lg lg:text-xl text-gray-600 max-w-4xl mx-auto">
                        Achieving CMMC compliance in AWS is more than enabling services—it's about expert architectural design and granular configuration. Here's how we guide you to a defensible and audit-ready environment.
                    </p>
                </motion.div>

                <Card className="mb-12">
                    <CardHeader>
                        <CardTitle className="flex items-center gap-3"><Server className="w-6 h-6 text-blue-600" /> Foundational Architecture</CardTitle>
                        <CardDescription>We start with a secure foundation, architecting your AWS environment to meet the stringent requirements for handling CUI.</CardDescription>
                    </CardHeader>
                    <CardContent className="grid md:grid-cols-2 gap-6">
                        {foundationalPillars.map(pillar => (
                            <div key={pillar.name} className="flex items-start gap-3">
                                <CheckCircle className="w-5 h-5 text-green-600 mt-1 flex-shrink-0" />
                                <div>
                                    <h4 className="font-semibold">{pillar.name}</h4>
                                    <p className="text-sm text-gray-600">{pillar.description}</p>
                                </div>
                            </div>
                        ))}
                    </CardContent>
                </Card>

                <Card className="mb-12">
                    <CardHeader>
                        <CardTitle className="flex items-center gap-3"><Layers className="w-6 h-6 text-blue-600" /> Strategic Service Configuration</CardTitle>
                        <CardDescription>We provide expert guidance on configuring core AWS security services to create overlapping layers of protection around your CUI data.</CardDescription>
                    </CardHeader>
                    <CardContent className="grid md:grid-cols-2 gap-8">
                        {securityServicesConfig.map(service => {
                            const Icon = service.icon;
                            return (
                                <div key={service.category}>
                                    <h3 className="text-lg font-semibold flex items-center gap-2 mb-3"><Icon className="w-5 h-5 text-gray-700" /> {service.category}</h3>
                                    <ul className="space-y-2">
                                        {service.details.map((detail, i) => (
                                            <li key={i} className="flex items-start gap-2 text-sm text-gray-700">
                                                <Check className="w-4 h-4 text-green-500 mt-1 flex-shrink-0" />
                                                <span>{detail}</span>
                                            </li>
                                        ))}
                                    </ul>
                                </div>
                            );
                        })}
                    </CardContent>
                </Card>

                <Alert className="mb-12 bg-blue-50 border-blue-200">
                    <ShieldCheck className="h-4 w-4 text-blue-600" />
                    <AlertTitle className="text-blue-800">The Power of Integration</AlertTitle>
                    <AlertDescription className="text-blue-700">
                        Our methodology ensures these services work in concert. For example, <strong>AWS Config</strong> detects a non-compliant S3 bucket, which creates a high-priority finding in <strong>Security Hub</strong>, which in turn triggers an automated <strong>EventBridge</strong> rule to immediately remediate the issue. This is the level of automation and security required for CMMC.
                    </AlertDescription>
                </Alert>

                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                >
                    <Card className="text-center bg-gray-900 text-white">
                        <CardContent className="p-8 lg:p-10">
                            <h3 className="text-2xl font-bold mb-4">Ready for an Expert-Guided Implementation?</h3>
                            <p className="text-gray-300 mb-6 max-w-2xl mx-auto">
                                Don't risk misconfigurations. Our $7,500 fixed-fee engagement provides the expert roadmap to build your secure AWS environment correctly, the first time.
                            </p>
                            <Button asChild size="lg" className="bg-white text-gray-900 hover:bg-gray-200">
                                <Link to={createPageUrl('HyperCoreCMMCReadiness')}>
                                    View Our 90-Day Program <ArrowRight className="w-4 h-4 ml-2" />
                                </Link>
                            </Button>
                        </CardContent>
                    </Card>
                </motion.div>

            </div>
        </div>
    );
}
