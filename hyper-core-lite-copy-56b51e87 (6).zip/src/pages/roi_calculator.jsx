
import React, { useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { ArrowRight, Phone, Calendar } from 'lucide-react';
import ROICalculator from '../components/calculator/ROICalculator';

export default function ROICalculatorPage() {
    useEffect(() => {
        document.title = "CMMC ROI Calculator - Save $58K vs Consultants | HyperCore";
        document.querySelector('meta[name="description"]')?.setAttribute('content', 
            'Calculate your CMMC compliance savings with HyperCore vs traditional consultants. Save $58K+ and 9 months. Interactive ROI calculator for defense contractors.');
    }, []);

    return (
        <div className="bg-gray-50 py-12">
            <div className="max-w-6xl mx-auto px-4">
                <div className="text-center mb-8">
                    <h1 className="text-4xl font-bold text-gray-900 mb-4">
                        CMMC ROI Calculator
                    </h1>
                    <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                        See exactly how much you'll save with HyperCore's AI-powered CMMC compliance vs traditional consultants and GRC platforms
                    </p>
                </div>

                <ROICalculator />

                {/* CTA Section */}
                <div className="mt-16">
                    <Card className="bg-gradient-to-r from-blue-600 to-indigo-700 text-white text-center">
                        <CardContent className="p-12">
                            <h2 className="text-3xl font-bold mb-4">Calculate Your Savings: Contact us for a 48-hour demo</h2>
                            <p className="text-xl text-blue-100 mb-8 max-w-3xl mx-auto">
                                See your actual CMMC gaps and savings potential with a personalized 48-hour assessment. 
                                No cost, no obligation - just real results for your organization.
                            </p>
                            <div className="flex flex-col sm:flex-row gap-4 justify-center">
                                <Button asChild size="lg" className="bg-white text-blue-700 hover:bg-gray-100 text-lg px-8 py-4">
                                    <Link to={createPageUrl('PartnershipTrial')}>
                                        <Calendar className="w-5 h-5 mr-2" />
                                        Start 48-Hour Demo
                                    </Link>
                                </Button>
                                <Button asChild size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-blue-700 text-lg px-8 py-4">
                                    <Link to={createPageUrl('PartnershipInquiry')}>
                                        <Phone className="w-5 h-5 mr-2" />
                                        Schedule Engagement Call
                                    </Link>
                                </Button>
                            </div>
                            <p className="text-sm text-blue-200 mt-6">
                                90-day money-back guarantee • Complete CMMC Level 2 package • Built for SMBs
                            </p>
                        </CardContent>
                    </Card>
                </div>

                {/* SMB Value Prop */}
                <div className="mt-12">
                    <Card className="bg-green-50 border-green-200">
                        <CardContent className="p-8">
                            <h3 className="text-2xl font-bold text-green-800 mb-4 text-center">
                                Built for Small Defense Contractors (68% of DIB)
                            </h3>
                            <div className="grid md:grid-cols-2 gap-6">
                                <div>
                                    <h4 className="font-semibold text-green-700 mb-2">Affordable Pricing</h4>
                                    <ul className="text-green-700 space-y-1">
                                        <li>• $5K/48-hour gap assessment</li>
                                        <li>• $12K/90-day compliance package</li>
                                        <li>• Save 70-94% vs. competitors</li>
                                        <li>• 90-day money-back guarantee</li>
                                    </ul>
                                </div>
                                <div>
                                    <h4 className="font-semibold text-green-700 mb-2">Proven Results</h4>
                                    <ul className="text-green-700 space-y-1">
                                        <li>• 85-95% NIST 800-171 accuracy</li>
                                        <li>• All 130 controls automated</li>
                                        <li>• AI + human coaching model</li>
                                        <li>• CMMC-ready in 90 days</li>
                                    </ul>
                                </div>
                            </div>
                            <div className="text-center mt-6">
                                <p className="text-sm text-green-600">
                                    <strong>vs. Vanta ($24K), Drata ($36K), consultants ($50K-$200K)</strong>
                                </p>
                            </div>
                        </CardContent>
                    </Card>
                </div>
            </div>
        </div>
    );
}
