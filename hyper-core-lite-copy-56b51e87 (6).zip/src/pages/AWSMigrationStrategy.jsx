import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { DollarSign, Cloud, CheckCircle, AlertTriangle, ArrowRight, BookOpen, Server } from 'lucide-react';
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const migrationCosts = {
    oneTime: {
        title: "One-Time Migration Cost (90-Day Free Period)",
        cost: "$0",
        note: "AWS Application Migration Service (MGN) is free for 90 days per server.",
        items: [
            { name: "MGN Replication Server License", cost: "$0", details: "Covered by the 90-day free tier." },
            { name: "Staging EC2 Instance (existing)", cost: "$0", details: "Using the instance you already have." },
            { name: "Test Instance Launches", cost: "~$5-10", details: "Minimal charges for testing, likely covered by credits." },
        ]
    },
    ongoing: {
        title: "Ongoing Monthly Cost (Post-Migration)",
        cost: "$15-50",
        note: "For a production-ready EC2 instance.",
        items: [
            { name: "Production EC2 Instance", cost: "$10-40", details: "t3.micro or t3.small instance for production." },
            { name: "EBS Storage (SSD)", cost: "$3-8", details: "For the server's operating system and application files." },
            { name: "Data Transfer & Snapshots", cost: "$2-5", details: "Standard operational costs for data and backups." },
        ]
    }
};

const migrationRealities = [
    { task: "Export & Set Up App on Staging EC2", effort: "6-8 hours", reality: "Deploy the exported Base44 code onto your existing EC2 instance." },
    { task: "Install MGN Agent & Replicate", effort: "2-4 hours", reality: "Install the agent and let MGN automatically replicate the server." },
    { task: "Non-Disruptive Testing in AWS", effort: "4-6 hours", reality: "Launch test clones of the migrated server to validate functionality." },
    { task: "Execute Final Cutover", effort: "1-2 hours", reality: "Point your domain's DNS to the new production EC2 instance." }
];


export default function AWSMigrationStrategy() {
    return (
        <div className="space-y-8">
            <BreadcrumbNav currentPageName="AWSMigrationStrategy" />

            <div className="text-center">
                <Badge className="mb-4 bg-blue-100 text-blue-800">LIFT & SHIFT ROADMAP</Badge>
                <h1 className="text-4xl font-bold text-gray-900 mb-4">AWS Migration: The "Lift & Shift" Plan</h1>
                <p className="text-xl text-gray-600 max-w-4xl mx-auto">
                    Using AWS Application Migration Service (MGN) to create a direct, auditable, and federally-compliant copy of your application on standard AWS infrastructure.
                </p>
            </div>

            <Alert className="bg-green-50 border-green-200">
                <CheckCircle className="h-5 w-5 text-green-600" />
                <AlertTitle className="text-green-800 font-bold">The Bottom Line: A Free Migration Path</AlertTitle>
                <AlertDescription className="text-green-700 mt-2">
                    The migration itself is **free** for 90 days using AWS MGN. Your only costs are minimal charges for test servers and the final production EC2 instance post-migration. This is the most capital-efficient path to a production-ready system.
                </AlertDescription>
            </Alert>

            <div className="grid md:grid-cols-2 gap-8">
                {/* ONE-TIME COSTS */}
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <DollarSign className="w-6 h-6 text-orange-600" />
                            {migrationCosts.oneTime.title}
                        </CardTitle>
                        <CardDescription>{migrationCosts.oneTime.note}</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div className="text-4xl font-bold text-orange-600 mb-4">{migrationCosts.oneTime.cost}</div>
                        {migrationCosts.oneTime.items.map(item => (
                            <div key={item.name} className="flex justify-between items-start text-sm">
                                <div>
                                    <p className="font-semibold text-gray-800">{item.name}</p>
                                    <p className="text-xs text-gray-500">{item.details}</p>
                                </div>
                                <Badge variant="outline">{item.cost}</Badge>
                            </div>
                        ))}
                    </CardContent>
                </Card>

                {/* ONGOING COSTS */}
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <Server className="w-6 h-6 text-blue-600" />
                            {migrationCosts.ongoing.title}
                        </CardTitle>
                        <CardDescription>{migrationCosts.ongoing.note}</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div className="text-4xl font-bold text-blue-600 mb-4">{migrationCosts.ongoing.cost} / mo</div>
                        {migrationCosts.ongoing.items.map(item => (
                            <div key={item.name} className="flex justify-between items-start text-sm">
                                <div>
                                    <p className="font-semibold text-gray-800">{item.name}</p>
                                    <p className="text-xs text-gray-500">{item.details}</p>
                                </div>
                                <Badge variant="outline">{item.cost}</Badge>
                            </div>
                        ))}
                    </CardContent>
                </Card>
            </div>

            <Card>
                <CardHeader>
                    <CardTitle>Migration Task Reality Check</CardTitle>
                    <CardDescription>What each migration step actually involves in terms of development effort.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    {migrationRealities.map((task, index) => (
                        <div key={index} className="p-4 bg-gray-50 rounded-lg flex justify-between items-center">
                            <div>
                                <h4 className="font-semibold">{task.task}</h4>
                                <p className="text-sm text-gray-600">{task.reality}</p>
                            </div>
                            <Badge className="bg-blue-100 text-blue-800 text-base">{task.effort}</Badge>
                        </div>
                    ))}
                    <Alert className="mt-6">
                        <BookOpen className="h-4 w-4" />
                        <AlertTitle>Detailed Implementation Guide</AlertTitle>
                        <AlertDescription>
                            The full step-by-step technical guide for this "Lift & Shift" approach is available.
                            <Button asChild variant="link" className="p-0 h-auto ml-1 font-bold">
                                <Link to={createPageUrl('AWSMigrationExecutionPlan')}>
                                    View the MGN Execution Plan <ArrowRight className="w-4 h-4 ml-1" />
                                </Link>
                            </Button>
                        </AlertDescription>
                    </Alert>
                </CardContent>
            </Card>
        </div>
    );
}