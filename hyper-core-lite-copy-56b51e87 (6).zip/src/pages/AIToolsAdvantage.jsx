import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Bot, Video, FileText, CheckSquare, Zap, Loader2 } from 'lucide-react';
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";
import { toast } from "sonner";

const aiPoweredPhases = [
    {
        phase: "Phase 1: Foundation & Discovery (Weeks 1-2)",
        manualDescription: "Requires 4-6 hours of kickoff calls, manual gap analysis, and spreadsheet-based project planning.",
        aiAdvantage: "AI completes this in minutes. Automated gap analysis, instant project plan generation, and video tutorials replace kickoff calls.",
        tools: [
            { name: "Generate Kickoff Video Script", icon: Video, description: "Create a 5-min tutorial script explaining the gap analysis process." },
            { name: "Generate Prioritized Checklist", icon: CheckSquare, description: "Instantly create a personalized task list from the AI gap analysis." },
            { name: "Generate SSP & POA&M Drafts", icon: FileText, description: "Produce initial drafts of the System Security Plan and Plan of Action & Milestones." },
        ]
    },
    {
        phase: "Phase 2: Guided Implementation (Weeks 3-10)",
        manualDescription: "Requires weekly 1-hour coaching calls, manual evidence review, and ad-hoc technical guidance.",
        aiAdvantage: "AI provides 24/7 guidance. Self-service video modules replace calls, and the AI agent provides real-time feedback on evidence.",
        tools: [
            { name: "Generate Implementation Video Scripts", icon: Video, description: "Create scripts for tutorials on Access Control, Incident Response, etc." },
            { name: "Generate Technical Checklists", icon: CheckSquare, description: "Produce step-by-step checklists for AWS security configuration and control implementation." },
            { name: "Generate All 14 Policy Documents", icon: FileText, description: "Draft the complete suite of 14 CMMC-required policy documents." },
        ]
    },
    {
        phase: "Phase 3: Package Assembly & Handoff (Weeks 11-12)",
        manualDescription: "Requires hours of manually organizing evidence, finalizing documents, and conducting audit prep briefings.",
        aiAdvantage: "AI automates the entire evidence package. It organizes files, finalizes documents, and generates a pre-audit report in one click.",
        tools: [
            { name: "Generate Audit Prep Video Script", icon: Video, description: "Create a script for a final video explaining how to work with a C3PAO assessor." },
            { name: "Generate Final Evidence Checklist", icon: CheckSquare, description: "Produce a final verification checklist to ensure all evidence is present and correct." },
            { name: "Assemble C3PAO-Ready Evidence Package", icon: FileText, description: "Compile all evidence, policies, and plans into a single, organized package for the auditor." },
        ]
    }
];

export default function AIToolsAdvantage() {
    const [loadingStates, setLoadingStates] = useState({});

    const handleGenerate = (phaseIndex, toolIndex) => {
        const key = `${phaseIndex}-${toolIndex}`;
        setLoadingStates(prev => ({ ...prev, [key]: true }));
        toast.info("AI is generating content...", {
            description: "This is a demonstration of the AI's capability. In the live product, this would generate a real document.",
        });

        setTimeout(() => {
            setLoadingStates(prev => ({ ...prev, [key]: false }));
            toast.success("Content generated successfully!");
        }, 1500);
    };

    return (
        <div className="space-y-8">
            <BreadcrumbNav currentPageName="AIToolsAdvantage" />

            <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="text-center">
                <Badge className="mb-4 bg-purple-100 text-purple-800">SCALABLE PRODUCT</Badge>
                <h1 className="text-4xl font-bold text-gray-900 mb-4">The AI Advantage: Automating the 90-Day Plan</h1>
                <p className="text-xl text-gray-600 max-w-4xl mx-auto">
                    How AI transforms a high-touch consulting service into a scalable, self-service software product.
                </p>
            </motion.div>

            <Alert className="bg-green-50 border-green-200">
                <Zap className="h-4 w-4 text-green-700" />
                <AlertTitle className="font-semibold text-green-800">The Core Strategy: Product, Not People</AlertTitle>
                <AlertDescription className="text-green-700">
                    Instead of selling your time, you sell access to an AI that does the work 24/7. This is the foundation for scaling to thousands of clients without hiring a massive consulting team.
                </AlertDescription>
            </Alert>

            <div className="space-y-12">
                {aiPoweredPhases.map((phase, phaseIndex) => (
                    <motion.div
                        key={phase.phase}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: phaseIndex * 0.2 }}
                    >
                        <Card className="overflow-hidden">
                            <CardHeader className="bg-gray-50">
                                <CardTitle className="text-2xl">{phase.phase}</CardTitle>
                            </CardHeader>
                            <CardContent className="p-6">
                                <div className="grid md:grid-cols-2 gap-6 mb-6">
                                    <div className="p-4 bg-red-50 rounded-lg border border-red-200">
                                        <h4 className="font-semibold text-red-800 mb-2">The Old Way (Manual Consulting)</h4>
                                        <p className="text-sm text-red-700">{phase.manualDescription}</p>
                                    </div>
                                    <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                                        <h4 className="font-semibold text-green-800 mb-2">The AI Advantage (Scalable Product)</h4>
                                        <p className="text-sm text-green-700">{phase.aiAdvantage}</p>
                                    </div>
                                </div>

                                <h3 className="font-semibold mb-4 flex items-center gap-2"><Bot className="w-5 h-5 text-blue-600" /> AI Generation Tools for this Phase:</h3>
                                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                                    {phase.tools.map((tool, toolIndex) => {
                                        const key = `${phaseIndex}-${toolIndex}`;
                                        const isLoading = loadingStates[key];
                                        return (
                                            <div key={tool.name} className="flex flex-col p-4 bg-blue-50 rounded-lg border border-blue-200 h-full">
                                                <div className="flex-grow">
                                                    <div className="flex items-center gap-3 mb-2">
                                                        <tool.icon className="w-6 h-6 text-blue-700" />
                                                        <h4 className="font-semibold text-blue-800">{tool.name}</h4>
                                                    </div>
                                                    <p className="text-xs text-blue-600 mb-4">{tool.description}</p>
                                                </div>
                                                <Button onClick={() => handleGenerate(phaseIndex, toolIndex)} disabled={isLoading} className="w-full mt-auto">
                                                    {isLoading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Zap className="w-4 h-4 mr-2" />}
                                                    {isLoading ? "Generating..." : "Generate Now"}
                                                </Button>
                                            </div>
                                        );
                                    })}
                                </div>
                            </CardContent>
                        </Card>
                    </motion.div>
                ))}
            </div>
        </div>
    );
}