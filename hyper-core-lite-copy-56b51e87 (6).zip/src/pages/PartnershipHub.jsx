
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { PartnershipCommunication } from "@/api/entities";
import { Plus, Filter, Users, DollarSign, TrendingUp, Mail, Eye } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from "@/components/ui/dialog";
import { LoadingSpinner } from '../components/ui/LoadingSpinner';
import { toast } from "sonner";
import ReactMarkdown from 'react-markdown';
import AddLeadForm from '../components/partnership/AddLeadForm';

export default function PartnershipHub() {
    const [communications, setCommunications] = useState([]);
    const [filteredComms, setFilteredComms] = useState([]);
    const [loading, setLoading] = useState(true);
    const [filters, setFilters] = useState({ status: 'all', type: 'all' });
    const [isAddLeadOpen, setIsAddLeadOpen] = useState(false);
    const [isSubmitting, setIsSubmitting] = useState(false);

    useEffect(() => {
        loadCommunications();
    }, []);

    useEffect(() => {
        let filtered = communications;
        if (filters.status !== 'all') {
            filtered = filtered.filter(c => c.status === filters.status);
        }
        if (filters.type !== 'all') {
            filtered = filtered.filter(c => c.partnership_type === filters.type);
        }
        setFilteredComms(filtered);
    }, [filters, communications]);

    const loadCommunications = async () => {
        setLoading(true);
        try {
            const comms = await PartnershipCommunication.list('-created_date', 100);
            setCommunications(comms);
            setFilteredComms(comms);
        } catch (error) {
            toast.error("Failed to load communications.");
            console.error(error);
        } finally {
            setLoading(false);
        }
    };
    
    const handleAddLeadSubmit = async (newLeadData) => {
        setIsSubmitting(true);
        try {
            await PartnershipCommunication.create(newLeadData);
            toast.success(`Lead for "${newLeadData.organization}" added successfully!`);
            setIsAddLeadOpen(false);
            loadCommunications();
        } catch (error) {
            toast.error("Failed to add lead.");
            console.error("Add lead error:", error);
        } finally {
            setIsSubmitting(false);
        }
    };

    const statusConfig = {
        target: 'bg-gray-200 text-gray-800',
        contacted: 'bg-blue-100 text-blue-800',
        replied: 'bg-green-200 text-green-900 font-semibold',
        demo_scheduled: 'bg-yellow-100 text-yellow-800',
        negotiating: 'bg-orange-100 text-orange-800',
        active_partner: 'bg-green-100 text-green-800',
        on_hold: 'bg-purple-100 text-purple-800',
        closed_lost: 'bg-red-100 text-red-800'
    };

    const stats = {
        total: communications.length,
        active: communications.filter(c => c.status === 'active_partner').length,
        pipelineValue: communications.reduce((acc, curr) => acc + (curr.estimated_value || 0), 0)
    };

    return (
        <div className="space-y-6">
            <CardHeader className="px-0">
                <CardTitle className="flex items-center gap-3 text-3xl font-bold">
                    <Users className="w-8 h-8 text-blue-600" />
                    Client Acquisition Hub
                </CardTitle>
                <CardDescription>A centralized CRM to manage leads, track your sales pipeline, and grow your partnerships.</CardDescription>
            </CardHeader>

            <div className="grid md:grid-cols-3 gap-6">
                <Card>
                    <CardHeader><CardTitle className="text-sm flex items-center gap-2"><Users /> Total Leads</CardTitle></CardHeader>
                    <CardContent><p className="text-3xl font-bold">{stats.total}</p></CardContent>
                </Card>
                <Card>
                     <CardHeader><CardTitle className="text-sm flex items-center gap-2"><DollarSign /> Pipeline Value</CardTitle></CardHeader>
                    <CardContent><p className="text-3xl font-bold">${stats.pipelineValue.toLocaleString()}</p></CardContent>
                </Card>
                <Card>
                    <CardHeader><CardTitle className="text-sm flex items-center gap-2"><TrendingUp /> Active Partners</CardTitle></CardHeader>
                    <CardContent><p className="text-3xl font-bold">{stats.active}</p></CardContent>
                </Card>
            </div>
            
            <Card>
                <CardHeader>
                    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                        <CardTitle>Sales Pipeline</CardTitle>
                        <div className="flex gap-2 w-full sm:w-auto">
                            <Select value={filters.status} onValueChange={(v) => setFilters(f => ({ ...f, status: v }))}>
                                <SelectTrigger><Filter className="w-4 h-4 mr-2" /><SelectValue placeholder="Filter by Status" /></SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="all">All Statuses</SelectItem>
                                    {Object.keys(statusConfig).map(s => <SelectItem key={s} value={s}>{s.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}</SelectItem>)}
                                </SelectContent>
                            </Select>
                            <Dialog open={isAddLeadOpen} onOpenChange={setIsAddLeadOpen}>
                                <DialogTrigger asChild>
                                    <Button><Plus className="w-4 h-4 mr-2"/>Add Lead</Button>
                                </DialogTrigger>
                                <DialogContent>
                                    <DialogHeader>
                                        <DialogTitle>Add New Lead</DialogTitle>
                                        <DialogDescription>
                                            Enter the details of the new lead to add them to your sales pipeline.
                                        </DialogDescription>
                                    </DialogHeader>
                                    <AddLeadForm 
                                        onSubmit={handleAddLeadSubmit}
                                        onCancel={() => setIsAddLeadOpen(false)}
                                        isSubmitting={isSubmitting}
                                    />
                                </DialogContent>
                            </Dialog>
                        </div>
                    </div>
                </CardHeader>
                <CardContent>
                    {loading ? <LoadingSpinner /> : (
                        <div className="space-y-4">
                            {filteredComms.length > 0 ? filteredComms.map(comm => (
                                <Card key={comm.id} className="p-4 hover:shadow-md transition-shadow">
                                    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
                                        <div className="flex-grow">
                                            <p className="font-bold text-lg">{comm.organization}</p>
                                            <p className="text-sm text-gray-600">{comm.contact_person} ({comm.email})</p>
                                        </div>
                                        <div className="flex items-center gap-4">
                                            <Badge variant="outline">{comm.partnership_type.replace(/_/g, ' ')}</Badge>
                                            <Badge className={statusConfig[comm.status]}>{comm.status.replace(/_/g, ' ')}</Badge>
                                            <p className="text-sm font-semibold">${(comm.estimated_value || 0).toLocaleString()}</p>
                                            <Dialog>
                                                <DialogTrigger asChild>
                                                    <Button variant="ghost" size="icon" disabled={!comm.notes}>
                                                        <Eye className="w-4 h-4" />
                                                    </Button>
                                                </DialogTrigger>
                                                <DialogContent className="max-w-2xl">
                                                    <DialogHeader>
                                                        <DialogTitle>Communication Log: {comm.organization}</DialogTitle>
                                                        <DialogDescription>
                                                            Full history including automated outreach and client replies.
                                                         </DialogDescription>
                                                    </DialogHeader>
                                                    <div className="prose prose-sm max-w-none max-h-[60vh] overflow-y-auto rounded-md border p-4">
                                                        <ReactMarkdown>{comm.notes?.replace(/---/g, '\n---\n')}</ReactMarkdown>
                                                    </div>
                                                </DialogContent>
                                            </Dialog>
                                        </div>
                                    </div>
                                </Card>
                            )) : <p className="text-center text-gray-500 py-6">No matching leads found.</p>}
                        </div>
                    )}
                </CardContent>
            </Card>
        </div>
    );
}
