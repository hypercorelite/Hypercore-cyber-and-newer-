import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { CheckCircle, AlertTriangle, Loader2, Mail, TestTube, Send, Rocket } from 'lucide-react';
import { toast } from "sonner";
import { sendTargetedPrimeEmail } from "@/api/functions";
import { motion } from "framer-motion";
import { User } from '@/api/entities';

export default function EmailSystemTest() {
    const [testResult, setTestResult] = useState(null);
    const [loading, setLoading] = useState(false);
    const [userEmail, setUserEmail] = useState('');

    useState(() => {
        User.me().then(u => setUserEmail(u.email));
    }, []);

    const runFinalTest = async () => {
        setLoading(true);
        setTestResult(null);
        toast.info(`🚀 Sending test campaign email to ${userEmail}...`);
        try {
            const { data } = await sendTargetedPrimeEmail({ testMode: true });
            if (data.success) {
                setTestResult({ success: true, message: data.message });
                toast.success("✅ Test email dispatched! Please check your inbox (and spam folder).");
            } else {
                throw new Error(data.error || 'The test function reported a failure.');
            }
        } catch (error) {
            const errorMessage = error.response?.data?.error || error.message;
            setTestResult({ success: false, message: errorMessage });
            toast.error(`❌ Test failed: ${errorMessage}`);
        } finally {
            setLoading(false);
        }
    };

    const launchCampaign = async () => {
        // This is a placeholder for the actual launch logic.
        // For now, it links to the outreach page.
        window.location.href = '/ConciergePrimeOutreach';
    };

    return (
        <div className="space-y-6 max-w-3xl mx-auto p-4 md:p-6">
            <div className="text-center">
                <h1 className="text-3xl font-bold text-gray-900 flex items-center justify-center gap-3">
                    <Mail className="w-8 h-8 text-blue-600" />
                    Final Launch Verification
                </h1>
                <p className="text-lg text-gray-600 mt-2">One final, foolproof test before market launch.</p>
            </div>
            
            <Alert>
                <TestTube className="h-4 w-4" />
                <AlertTitle>The Definitive Test</AlertTitle>
                <AlertDescription>
                    This button sends the **exact** prime contractor outreach email to your logged-in email address ({userEmail}). 
                    Verify its arrival in your inbox (or spam) to confirm 100% deliverability. 
                    This is the final go/no-go check.
                </AlertDescription>
            </Alert>
            
            <Card>
                <CardHeader>
                    <CardTitle>Prime Campaign Delivery Test</CardTitle>
                    <CardDescription>Sends a real campaign email to your account.</CardDescription>
                </CardHeader>
                <CardContent className="text-center">
                    <Button size="lg" onClick={runFinalTest} disabled={loading}>
                        {loading ? (
                            <><Loader2 className="w-5 h-5 mr-2 animate-spin" /> Sending Test...</>
                        ) : (
                            <><Send className="w-5 h-5 mr-2" /> Send Test Campaign Email</>
                        )}
                    </Button>

                    {testResult && (
                        <div className={`mt-6 p-4 rounded-lg text-left ${testResult.success ? 'bg-green-50' : 'bg-red-50'}`}>
                            <h4 className="font-semibold flex items-center gap-2">
                                {testResult.success ? <CheckCircle className="w-5 h-5 text-green-600" /> : <AlertTriangle className="w-5 h-5 text-red-600" />}
                                Test Result
                            </h4>
                            <p className="text-sm text-gray-700 mt-1">{testResult.message}</p>
                        </div>
                    )}
                </CardContent>
            </Card>

            {testResult?.success && (
                <motion.div
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="mt-8 flex flex-col items-center gap-4"
                >
                    <Alert className="max-w-xl bg-green-50 border-green-200 text-green-800">
                        <CheckCircle className="h-4 w-4" />
                        <AlertTitle>Test Dispatched! Ready to Launch?</AlertTitle>
                        <AlertDescription>
                            Once you confirm the test email has arrived in your inbox, you are cleared to proceed to the outreach center and launch the full campaign.
                        </AlertDescription>
                    </Alert>
                    <Button size="lg" className="bg-gradient-to-r from-red-600 to-orange-500 text-white shadow-lg hover:shadow-xl" onClick={launchCampaign}>
                         <Rocket className="w-5 h-5 mr-2" /> GO TO LAUNCH CENTER
                    </Button>
                </motion.div>
            )}
        </div>
    );
}