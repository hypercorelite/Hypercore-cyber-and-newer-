import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Copy } from 'lucide-react';
import { toast } from "sonner";
import BreadcrumbNav from "@/components/navigation/BreadcrumbNav";

export default function LinkedInGroupPosts() {
    const copyToClipboard = (text, title) => {
        navigator.clipboard.writeText(text);
        toast.success(`${title} copied to clipboard!`);
    };

    const posts = [
        {
            title: "🔥 GROUP LAUNCH POST (Post at 7:00 PM EDT)",
            content: `**Welcome to the NoVA DIB CMMC Innovators Group!**

This is a no-BS forum for Northern Virginia's defense contractors to solve the CMMC 2.0 challenge before the November 10, 2025 deadline.

**The Problem:** 70% of subcontractors are misinterpreting DFARS flow-down requirements, putting prime contractors at risk of $4.6M+ in False Claims Act penalties. Traditional consultants are quoting $50K and 12-month timelines—a death sentence for SMBs.

**Our Mission:** To share real, actionable strategies for using AI and automation to get CMMC Level 2 compliant in 90 days for 70% less cost.

We'll be sharing:
- Real-time data from prime contractor supply chain audits
- Walkthroughs of AI-driven gap analysis
- Strategies for generating an audit-ready SSP in under 48 hours

Let's start with a hard question: **What is the single biggest CMMC compliance bottleneck you're facing right now?** Cost? Time? Lack of expertise?

#CMMC #DoD #NoVA #GovCon #Cybersecurity #NIST #DFARS`
        },
        {
            title: "DAY 2 FOLLOW-UP: The $50K Question",
            content: `Yesterday we kicked off the group by highlighting the $4.6M FCA risk primes are facing. Today, let's talk about the subcontractor's perspective.

**The $50,000 Question:** Why does achieving CMMC Level 2 compliance cost the average SMB over $50,000 with a traditional consultant?

It's not the technology. It's the billable hours for manual work:
- 100+ hours for manual evidence collection
- 80+ hours to write 18 policies from scratch
- 60+ hours for manual gap analysis against 110 NIST controls

Our AI platform automates 90% of this manual labor. We're seeing 70-80% cost reductions in our current pilots.

Is your company still relying on manual assessments? How much time have you wasted on paperwork this month?

#CMMCCompliance #Automation #AI #CostSavings #GovCon`
        },
        {
            title: "DAY 3 ENGAGEMENT: Real-Time Poll",
            content: `Quick poll for the group:

**What's your company's BIGGEST fear regarding the November 10, 2025 CMMC deadline?**

A) Losing our existing DoD contracts
B) The massive cost of the C3PAO audit
C) The sheer amount of paperwork and documentation
D) We have no idea where to even start

Vote with a comment below. Let's see where the community stands.

#CMMCReady #DoDContracts #Compliance #CybersecurityAudit`
        },
        {
            title: "WEEK 2: AI vs. Traditional Consultants",
            content: `**Week 2 Deep Dive: Why AI Beats Traditional CMMC Consultants**

Had 3 calls this week with NoVA contractors comparing our AI platform to traditional consultants. Here's what we found:

**Traditional Consultant Path:**
- $35K-75K upfront cost
- 6-12 month timeline
- 40+ billable hours just for gap analysis
- Manual evidence collection (error-prone)
- Static documentation that goes stale

**AI-First Approach:**
- $2,997/month with Net-30 payment terms
- 90-day timeline to full compliance
- Automated gap analysis in 48 hours
- Continuous monitoring and drift detection
- Real-time compliance scoring

**The Reality Check:** Most consultants are using the same NIST 800-171 checklist you can download for free. You're paying $50K for someone to fill out a spreadsheet.

Our AI does the heavy lifting. You focus on implementation.

Anyone else tired of paying consultant rates for checkbox exercises?

#CMMC #AI #DefenseContractors #ComplianceAutomation`
        },
        {
            title: "WEEK 3: C3PAO Audit Horror Stories",
            content: `**Week 3 Reality Check: C3PAO Audit Failures We're Seeing**

Anonymous poll results from our group (43 responses):
- 67% failed their first C3PAO audit attempt
- Average remediation time: 4-6 months
- Most common failure: Evidence documentation gaps

**Top 3 Audit Failures:**
1. **Access Control (AC):** Can't prove who accessed what, when
2. **Incident Response (IR):** No documented incident handling procedures  
3. **System Monitoring (SI):** No continuous monitoring evidence

**The Pattern:** Companies think they're compliant, but auditors want PROOF, not promises.

Our AI platform addresses this by:
✓ Auto-generating evidence packages
✓ Continuous compliance monitoring
✓ Audit-ready documentation templates
✓ Real-time gap alerts

**Question for the group:** What surprised you most about your C3PAO experience? Let's learn from each other's mistakes.

#C3PAO #CMMCAudit #ComplianceEvidence #AuditPrep`
        }
    ];

    return (
        <div className="space-y-6">
            <BreadcrumbNav currentPageName="LinkedIn Group Posts" />
            
            <div className="text-center">
                <h1 className="text-3xl font-bold text-gray-900 mb-4">
                    📱 NoVA DIB CMMC Innovators - Ready-to-Post Content
                </h1>
                <p className="text-lg text-gray-600">
                    Copy, paste, and post these to build engagement and drive leads
                </p>
            </div>

            <div className="space-y-6">
                {posts.map((post, index) => (
                    <Card key={index} className="border-2 border-blue-200">
                        <CardHeader className="bg-blue-50">
                            <CardTitle className="text-xl text-blue-800">{post.title}</CardTitle>
                        </CardHeader>
                        <CardContent className="pt-6">
                            <div className="bg-white p-4 rounded-md border whitespace-pre-wrap text-sm mb-4">
                                {post.content}
                            </div>
                            <Button 
                                onClick={() => copyToClipboard(post.content, post.title)}
                                className="w-full bg-blue-600 hover:bg-blue-700"
                            >
                                <Copy className="h-4 w-4 mr-2" /> 
                                Copy Post to Clipboard
                            </Button>
                        </CardContent>
                    </Card>
                ))}
            </div>
        </div>
    );
}