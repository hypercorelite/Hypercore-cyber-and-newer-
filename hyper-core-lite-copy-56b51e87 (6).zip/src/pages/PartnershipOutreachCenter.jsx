import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Handshake, Mail, FileText, Target, Clock } from 'lucide-react';
import PreVeilOutreachTemplate from '../components/partnership/PreVeilOutreachTemplate';
import PartnershipMOUTemplate from '../components/partnership/PartnershipMOUTemplate';

export default function PartnershipOutreachCenter() {
    const priorityTargets = [
        {
            name: "PreVeil",
            type: "Tool Provider", 
            timeline: "Week 1-2",
            potential: "20-30% conversion",
            action: "Email + API demo"
        },
        {
            name: "Core-CSI", 
            type: "Consultant",
            timeline: "Week 1-2", 
            potential: "$10K-20K per client",
            action: "AFCEA networking"
        },
        {
            name: "TrustCloud",
            type: "GRC Platform",
            timeline: "Week 3-4",
            potential: "100+ referrals", 
            action: "LinkedIn outreach"
        }
    ];

    return (
        <div className="space-y-8">
            <div className="text-center">
                <h1 className="text-3xl font-bold mb-4 flex items-center justify-center gap-3">
                    <Handshake className="w-8 h-8 text-blue-600" />
                    Partnership Outreach Command Center
                </h1>
                <p className="text-lg text-gray-600 max-w-4xl mx-auto">
                    Execute your NoVA DIB penetration strategy with ready-to-use email templates, MOUs, and partnership frameworks.
                </p>
            </div>

            {/* Priority Targets Overview */}
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Target className="w-5 h-5" />
                        Q4 2025 Priority Targets
                    </CardTitle>
                    <CardDescription>
                        High-value partnerships targeting NoVA's DIB subcontractor ecosystem
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="grid md:grid-cols-3 gap-4">
                        {priorityTargets.map((target, index) => (
                            <div key={index} className="p-4 border rounded-lg">
                                <div className="flex justify-between items-start mb-2">
                                    <h3 className="font-semibold">{target.name}</h3>
                                    <Badge variant="outline">{target.type}</Badge>
                                </div>
                                <div className="space-y-1 text-sm text-gray-600">
                                    <div className="flex items-center gap-1">
                                        <Clock className="w-3 h-3" />
                                        {target.timeline}
                                    </div>
                                    <div>Potential: {target.potential}</div>
                                    <div>Action: {target.action}</div>
                                </div>
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>

            {/* Email Templates */}
            <PreVeilOutreachTemplate />

            {/* MOU Template */}
            <PartnershipMOUTemplate />
            
            {/* Additional Outreach Tools */}
            <div className="grid md:grid-cols-2 gap-6">
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <Mail className="w-5 h-5 text-green-600" />
                            Core-CSI Pitch Framework
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-2 text-sm">
                            <p><strong>Hook:</strong> "Enhance your EA services with AI-driven CMMC drift detection"</p>
                            <p><strong>Value Prop:</strong> "White-label our gap scans for 20% revenue share"</p>
                            <p><strong>Proof:</strong> "Free POC for your Quantico clients"</p>
                            <p><strong>Next Step:</strong> "2-week pilot starting immediately"</p>
                        </div>
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <FileText className="w-5 h-5 text-purple-600" />
                            TrustCloud API Integration Pitch
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-2 text-sm">
                            <p><strong>Hook:</strong> "Combine our platforms for unbeatable CMMC automation"</p>
                            <p><strong>Value Prop:</strong> "AI Duo for 3PAO prep in Loudoun data hubs"</p>
                            <p><strong>Proof:</strong> "Joint demo at Carahsoft events"</p>
                            <p><strong>Next Step:</strong> "API integration by Nov 2025"</p>
                        </div>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}