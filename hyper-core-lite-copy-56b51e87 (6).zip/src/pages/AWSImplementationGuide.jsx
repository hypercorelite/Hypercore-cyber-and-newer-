
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, DollarSign, Cloud, Server, Github, Terminal, GitBranch, ArrowRight, Laptop, Info } from 'lucide-react';
import { motion } from "framer-motion";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const awsServices = [
    { name: "Lambda", purpose: "Runs your backend code (more cost-effective than EC2).", cost: "$0 (1M free requests/month)" },
    { name: "RDS (PostgreSQL)", purpose: "Your main database for storing all app data.", cost: "$0 (Free for 12 months, then ~$15/month)" },
    { name: "S3", purpose: "Stores files and hosts the static parts of your website.", cost: "$0 (5GB free)" },
    { name: "CloudFront", purpose: "Makes your website load fast globally (CDN).", cost: "~$1-2/month depending on traffic" },
    { name: "Route 53", purpose: "Your DNS for hypercorecyber.com.", cost: "$0.50/month (existing)" },
    { name: "SES", purpose: "Sends transactional emails for your platform.", cost: "$0 (62k free emails/month)" },
];

const thirdPartyServices = [
    { name: "GitHub", purpose: "Stores your code and runs the automated deployment pipeline.", cost: "$0 (Free for private repos & actions)" },
    { name: "SendGrid", purpose: "Handles your marketing & outreach email campaigns.", cost: "$0+ (existing)" },
    { name: "CallRail", purpose: "Professional phone/callback system.", cost: "$89/month" },
    { name: "Calendly", purpose: "Automates meeting and demo scheduling.", cost: "$16/month (Pro)" },
    { name: "Zapier", purpose: "Connects services (e.g., CallRail to your CRM).", cost: "$20/month" },
];

const deploymentTimeline = [
    { 
        week: "Week 1: Infrastructure Deployment", 
        tasks: [
            "Confirm hypercorecyber.com is managed via AWS Route 53.",
            "Using AWS CLI, create your S3 bucket for static assets.",
            "Deploy your free-tier RDS PostgreSQL database instance.",
            "Create your initial Lambda function placeholder in AWS.",
            "Install all necessary software on your desktop (see 'Your Desktop Setup' tab)."
        ],
        focus: "Core AWS Services Live"
    },
    { 
        week: "Week 2: CI/CD & Code Migration", 
        tasks: [
            "Copy the workflow code from the 'GitHub Actions' tab into your GitHub repository.",
            "Add your AWS credentials as secrets in your GitHub repository settings.",
            "Push your application code to the `main` branch.",
            "Verify that the GitHub Action runs successfully and deploys the code to Lambda and S3.",
            "Test all application functionality on hypercorecyber.com."
        ],
        focus: "Automated Deployment Pipeline Active"
    },
    { 
        week: "Week 3: Third-Party Integrations", 
        tasks: [
            "Set up CallRail, Calendly, and Zapier accounts.",
            "Integrate CallRail phone numbers and Calendly scheduling into the live website.",
            "Configure Zapier to automatically add new leads into the Partnership Hub.",
            "Set up automated outreach sequences in SendGrid."
        ],
        focus: "Full Business Automation Achieved"
    }
];

const desktopSetup = [
    { name: "Git", purpose: "Version control system to track code changes." },
    { name: "Node.js", purpose: "JavaScript runtime to test parts of your app locally." },
    { name: "AWS CLI", purpose: "Command Line Interface to interact with your AWS account.", installation: "Install from the official AWS website." },
    { name: "A Code Editor", purpose: "VS Code is highly recommended (free).", installation: "Download from the official VS Code website." }
];

const CodeBlock = ({ content }) => {
    return (
        <pre className="bg-gray-800 text-white p-4 rounded-md text-xs overflow-x-auto">
            <code>{content}</code>
        </pre>
    );
};


export default function AWSImplementationGuide() {
    return (
        <div className="space-y-8 relative">
            <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center"
            >
                <h1 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-3">
                    Streamlined AWS & GitHub Deployment Guide
                </h1>
                <p className="text-lg lg:text-xl text-gray-600">
                    Your copy-paste guide for migrating to a professional, cost-effective AWS infrastructure.
                </p>
            </motion.div>

            <Alert className="bg-blue-50 border-blue-200 relative z-10">
                <Cloud className="h-4 w-4 text-blue-600" />
                <AlertTitle className="text-blue-800">Deployment Strategy: Serverless First</AlertTitle>
                <AlertDescription className="text-blue-700">
                    This guide uses <strong>AWS Lambda</strong> instead of a 24/7 running EC2 instance. This serverless approach is dramatically cheaper for your use case (pennies per month vs. ~$20+/month for an EC2 instance) and scales automatically without any management.
                </AlertDescription>
            </Alert>
            
            <Tabs defaultValue="costs" className="w-full relative z-10">
                <TabsList className="grid w-full grid-cols-5 mb-6 bg-white border shadow-sm">
                    <TabsTrigger value="costs" className="data-[state=active]:bg-blue-50">Cost Breakdown</TabsTrigger>
                    <TabsTrigger value="timeline" className="data-[state=active]:bg-blue-50">Deployment Timeline</TabsTrigger>
                    <TabsTrigger value="desktop" className="data-[state=active]:bg-blue-50">Your Desktop Setup</TabsTrigger>
                    <TabsTrigger value="github_actions" className="data-[state=active]:bg-blue-50">GitHub Actions</TabsTrigger>
                    <TabsTrigger value="workflow" className="data-[state=active]:bg-blue-50">Daily Workflow</TabsTrigger>
                </TabsList>
                
                <TabsContent value="costs" className="mt-6 relative">
                    <Card className="relative z-10">
                        <CardHeader>
                            <CardTitle>Monthly Cost & Platform Breakdown</CardTitle>
                            <CardDescription>What you pay for and where it runs, reflecting your existing assets.</CardDescription>
                        </CardHeader>
                        <CardContent className="grid md:grid-cols-2 gap-8">
                            <div>
                                <h3 className="font-semibold text-lg mb-3 flex items-center gap-2"><Cloud className="w-5 h-5 text-blue-600"/>Core AWS Infrastructure</h3>
                                <div className="space-y-2">
                                    {awsServices.map(s => (
                                        <div key={s.name} className="flex justify-between items-center text-sm p-2 bg-gray-50 rounded-md">
                                            <span className="font-medium">{s.name}: <span className="text-gray-600 font-normal">{s.purpose}</span></span>
                                            <Badge variant="secondary">{s.cost}</Badge>
                                        </div>
                                    ))}
                                    <div className="flex justify-between items-center text-sm p-2 bg-blue-50 rounded-md border border-blue-200">
                                        <span className="font-bold text-blue-800">AWS Sub-Total:</span>
                                        <Badge className="bg-blue-100 text-blue-800">~$5 / month</Badge>
                                    </div>
                                </div>
                            </div>
                            <div>
                                <h3 className="font-semibold text-lg mb-3 flex items-center gap-2"><Server className="w-5 h-5 text-gray-700"/>Third-Party Services</h3>
                                <div className="space-y-2">
                                    {thirdPartyServices.map(s => (
                                        <div key={s.name} className="flex justify-between items-center text-sm p-2 bg-gray-50 rounded-md">
                                            <span className="font-medium">{s.name}: <span className="text-gray-600 font-normal">{s.purpose}</span></span>
                                            <Badge variant="outline">{s.cost}</Badge>
                                        </div>
                                    ))}
                                    <div className="flex justify-between items-center text-sm p-2 bg-gray-100 rounded-md border">
                                        <span className="font-bold">Third-Party Sub-Total:</span>
                                        <Badge>$125 / month</Badge>
                                    </div>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>
                
                <TabsContent value="timeline" className="mt-6 relative">
                    <Card className="relative z-10">
                        <CardHeader>
                            <CardTitle>Real-World Deployment Timeline</CardTitle>
                            <CardDescription>A 3-week plan to go from your current setup to a fully automated AWS platform.</CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            {deploymentTimeline.map(item => (
                                <div key={item.week} className="border-l-4 border-blue-500 pl-4">
                                    <h4 className="font-semibold text-lg">{item.week} <Badge variant="secondary">{item.focus}</Badge></h4>
                                    <ul className="mt-2 space-y-1 list-disc list-inside text-sm text-gray-700">
                                        {item.tasks.map((task, i) => <li key={i}>{task}</li>)}
                                    </ul>
                                </div>
                            ))}
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="desktop" className="mt-6 relative">
                     <Card className="relative z-10">
                        <CardHeader>
                            <CardTitle>Your Desktop Environment Setup</CardTitle>
                            <CardDescription>What you need to install on your computer to deploy and manage the application.</CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-4">
                             <div>
                                <h3 className="font-semibold mb-2">Required Software</h3>
                                <div className="grid md:grid-cols-2 gap-4">
                                    {desktopSetup.map(tool => (
                                        <div key={tool.name} className="p-3 bg-gray-50 rounded-md">
                                            <p className="font-medium">{tool.name}</p>
                                            <p className="text-sm text-gray-600">{tool.purpose}</p>
                                        </div>
                                    ))}
                                </div>
                            </div>
                            <div>
                                <h3 className="font-semibold mb-2">Environment Variables File (`.env`)</h3>
                                <p className="text-sm text-gray-600 mb-2">Create this file in your project's root folder. This file is ignored by Git and will never be public.</p>
                                <CodeBlock content={
`# AWS Credentials (from your AWS IAM user)
AWS_ACCESS_KEY_ID=YOUR_AWS_ACCESS_KEY
AWS_SECRET_ACCESS_KEY=YOUR_AWS_SECRET_KEY
AWS_REGION=us-east-1

# Your Domain
DOMAIN_NAME=hypercorecyber.com

# SendGrid Credentials
SENDGRID_API_KEY=YOUR_SENDGRID_API_KEY
SENDGRID_VERIFIED_SENDER=your-verified@email.com

# Other service keys
CALLRAIL_API_KEY=YOUR_CALLRAIL_KEY
ZAPIER_WEBHOOK_URL=YOUR_ZAPIER_URL
`
                                }/>
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>

                 <TabsContent value="github_actions" className="mt-6 relative">
                    <Card className="relative z-10">
                        <CardHeader>
                            <CardTitle>Copy-Paste GitHub Actions Workflow</CardTitle>
                            <CardDescription>Create a file at `.github/workflows/deploy.yml` in your project and paste this code. This automates your entire deployment.</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <Alert className="mb-4">
                                <Info className="h-4 w-4" />
                                <AlertTitle>Prerequisite</AlertTitle>
                                <AlertDescription>You must first add your `AWS_ACCESS_KEY_ID` and `AWS_SECRET_ACCESS_KEY` as secrets in your GitHub repository settings under "Secrets and variables" &gt; "Actions".</AlertDescription>
                            </Alert>
                             <CodeBlock content={
`name: Deploy to AWS

on:
  push:
    branches: [ main ] # Trigger deployment on every push to the main branch

jobs:
  deploy:
    runs-on: ubuntu-latest
    
    steps:
    - name: Checkout Repository
      uses: actions/checkout@v3
    
    - name: Configure AWS credentials
      uses: aws-actions/configure-aws-credentials@v2
      with:
        aws-access-key-id: \${{ secrets.AWS_ACCESS_KEY_ID }}
        aws-secret-access-key: \${{ secrets.AWS_SECRET_ACCESS_KEY }}
        aws-region: us-east-1

    - name: Setup Node.js
      uses: actions/setup-node@v3
      with:
        node-version: '18'
        cache: 'npm'

    - name: Install Dependencies
      run: npm ci

    - name: Build Application
      run: npm run build # This should build your static files into a 'build' or 'dist' directory

    - name: Prepare Backend for Lambda
      run: |
        # Add commands here to prepare your backend code if necessary
        # e.g., copying node_modules, creating a zip file
        zip -r backend.zip . -x "build/*" ".git/*" ".github/*" "node_modules/aws-sdk/*"
        
    - name: Deploy to Lambda
      run: |
        aws lambda update-function-code \\
          --function-name YourLambdaFunctionName \\ # IMPORTANT: Replace with your Lambda function name
          --zip-file fileb://backend.zip

    - name: Deploy to S3
      run: |
        aws s3 sync ./build s3://your-s3-bucket-name --delete # IMPORTANT: Replace with your S3 bucket name
`
                            }/>
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="workflow" className="mt-6 relative">
                    <Card className="relative z-10">
                        <CardHeader>
                            <CardTitle>Your Day-to-Day Deployment Workflow</CardTitle>
                            <CardDescription>This is the simple, repeatable process for pushing updates from your computer to the live website.</CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-4 text-center">
                            <div className="flex flex-col md:flex-row items-center justify-center gap-4 text-sm">
                                <div className="p-4 rounded-lg bg-gray-100 flex flex-col items-center gap-2">
                                    <Laptop className="w-8 h-8 text-blue-600"/>
                                    <h4 className="font-semibold">1. Code Locally</h4>
                                    <p className="text-xs text-gray-600">Make changes to the app on your computer.</p>
                                </div>
                                <ArrowRight className="w-6 h-6 text-gray-400 hidden md:block" />
                                <div className="p-4 rounded-lg bg-gray-100 flex flex-col items-center gap-2">
                                    <Terminal className="w-8 h-8 text-gray-700"/>
                                    <h4 className="font-semibold">2. Commit Changes</h4>
                                    <code className="text-xs bg-gray-200 p-1 rounded">git commit -m "feat: new feature"</code>
                                </div>
                                 <ArrowRight className="w-6 h-6 text-gray-400 hidden md:block" />
                                <div className="p-4 rounded-lg bg-gray-100 flex flex-col items-center gap-2">
                                    <GitBranch className="w-8 h-8 text-orange-600"/>
                                    <h4 className="font-semibold">3. Push to GitHub</h4>
                                    <code className="text-xs bg-gray-200 p-1 rounded">git push origin main</code>
                                </div>
                                 <ArrowRight className="w-6 h-6 text-gray-400 hidden md:block" />
                                <div className="p-4 rounded-lg bg-green-50 border border-green-200 flex flex-col items-center gap-2">
                                    <Github className="w-8 h-8 text-green-700"/>
                                    <h4 className="font-semibold text-green-800">4. Automation Takes Over</h4>
                                    <p className="text-xs text-green-700">GitHub Actions automatically builds and deploys your changes to AWS.</p>
                                </div>
                            </div>
                            <Alert>
                                <CheckCircle className="h-4 h-4" />
                                <AlertTitle>That's It!</AlertTitle>
                                <AlertDescription>
                                    Your only job is to write code and push it. The entire deployment process is handled for you automatically.
                                </AlertDescription>
                            </Alert>
                        </CardContent>
                    </Card>
                </TabsContent>
            </Tabs>
        </div>
    );
}
