
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, CheckCircle, Download, Cloud, Rocket, Clock } from 'lucide-react';
import { motion } from 'framer-motion';
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";

const CodeBlock = ({ content }) => {
    return (
        <pre className="bg-gray-800 text-white p-3 rounded-md font-mono text-sm overflow-x-auto">
            <code>{content}</code>
        </pre>
    );
};

export default function JMeterLoadTestingGuide() {
    return (
        <div className="space-y-8">
            <BreadcrumbNav currentPageName="JMeterLoadTestingGuide" />
            <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="text-center">
                <Badge className="mb-4 bg-green-100 text-green-800">REAL PERFORMANCE TESTING</Badge>
                <h1 className="text-4xl font-bold text-gray-900 mb-4 flex items-center justify-center gap-3">
                    <Rocket className="w-8 h-8 text-green-600" />
                    Load Testing Guide: JMeter & CloudWatch
                </h1>
                <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                    A step-by-step guide to stress-test your live APIs and prove enterprise-grade scalability and uptime to prime contractors.
                </p>
            </motion.div>

            <Alert className="bg-green-50 border-green-200">
                <CheckCircle className="h-4 w-4 text-green-600" />
                <AlertTitle className="text-green-800">Your Goal: A Bulletproof Performance Report</AlertTitle>
                <AlertDescription className="text-green-700">
                    The objective is to produce screenshots and data proving your platform handles **1,000+ concurrent users** with an average response time **under 200ms** and maintains **≥99% uptime**. This is the evidence that beats competitors like Vanta.
                </AlertDescription>
            </Alert>

            <div className="space-y-6">
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-3">
                            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center font-bold text-gray-700">1</div>
                            Download & Install Apache JMeter
                        </CardTitle>
                        <CardDescription>Get the industry-standard, free load testing tool. (Estimated time: 10 minutes)</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <p className="mb-2">JMeter is a free, open-source Java application designed to load test functional behavior and measure performance.</p>
                        <p className="mb-4">**Requirement:** You must have Java 8 or higher installed on your machine.</p>
                        <a href="https://jmeter.apache.org/download_jmeter.cgi" target="_blank" rel="noopener noreferrer" className="text-blue-600 font-semibold hover:underline flex items-center">
                            Download Apache JMeter Official Release <ArrowRight className="w-4 h-4 ml-1" />
                        </a>
                        <p className="text-sm text-gray-500 mt-2">Download the "Binaries" zip file (e.g., `apache-jmeter-5.x.x.zip`) and unzip it to a directory on your computer. To run JMeter, navigate to the `bin` folder and run `jmeter.bat` (for Windows) or `jmeter.sh` (for macOS/Linux).</p>
                    </CardContent>
                </Card>

                <Card className="border-blue-200">
                    <CardHeader>
                        <CardTitle className="flex items-center gap-3 text-blue-800">
                            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center font-bold">2</div>
                            Configure JMeter Load Test Plan
                        </CardTitle>
                         <CardDescription>Create a test plan to simulate 1,000 users hitting your live API endpoints. (Estimated time: 20 minutes)</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <p>Follow these steps inside the JMeter GUI:</p>
                        <ol className="list-decimal list-inside space-y-3">
                            <li>**Create a Thread Group:** Right-click on "Test Plan" &gt; Add &gt; Threads (Users) &gt; Thread Group.
                                <ul className="list-disc list-inside ml-6 mt-2 bg-gray-50 p-2 rounded">
                                    <li>**Number of Threads (users):** `1000`</li>
                                    <li>**Ramp-up period (in seconds):` `10` (This simulates 100 users per second)</li>
                                    <li>**Loop Count:** `10` (Each user will send 10 requests)</li>
                                </ul>
                            </li>
                            <li>**Add HTTP Request Sampler:** Right-click on your Thread Group &gt; Add &gt; Sampler &gt; HTTP Request.
                                <ul className="list-disc list-inside ml-6 mt-2 bg-gray-50 p-2 rounded">
                                    <li>**Protocol [http]:** `https`</li>
                                    <li>**Server Name or IP:** `api.hypercorecyber.com`</li>
                                    <li>**Path:** `/v1/analyzer` (You will create a second sampler for `/v1/drift`)</li>
                                    <li>Add a parameter: `control` = `AC-2`</li>
                                </ul>
                            </li>
                            <li>**Add Listeners:** Right-click on Thread Group &gt; Add &gt; Listener &gt; View Results Tree &amp; Summary Report. These will show you the results of the test.</li>
                        </ol>
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-3">
                            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center font-bold text-gray-700">3</div>
                            Run Test & Verify Uptime in CloudWatch
                        </CardTitle>
                        <CardDescription>Execute the test and then validate uptime and error rates in your AWS console. (Estimated time: 30 minutes)</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                       <p>First, click the green "Start" button in JMeter to run the load test. Watch the Summary Report for real-time metrics.</p>
                       <p>After the test, log into your **AWS Console**:</p>
                        <ol className="list-decimal list-inside space-y-2">
                            <li>Navigate to **CloudWatch &gt; Metrics &gt; All metrics**.</li>
                            <li>Select **Lambda &gt; By Function Name**.</li>
                            <li>Find your API functions (e.g., `hypercore-api-analyzer`, `hypercore-api-drift`).</li>
                            <li>Select the **Invocations**, **Errors**, and **Duration** metrics.</li>
                            <li>Change the time period to the last hour and the statistic to "Average" for duration and "Sum" for errors/invocations.</li>
                        </ol>
                        <Alert>
                            <Cloud className="h-4 w-4" />
                            <AlertTitle>What to Document</AlertTitle>
                            <AlertDescription>
                                Take a screenshot of the JMeter Summary Report showing the average response time. Then, take a screenshot of your CloudWatch metrics graph showing high invocations with a near-zero error rate. These two images are your proof of performance and reliability.
                            </AlertDescription>
                        </Alert>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}
