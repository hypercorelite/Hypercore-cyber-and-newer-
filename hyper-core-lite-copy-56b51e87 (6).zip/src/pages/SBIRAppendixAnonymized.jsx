import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { CheckCircle, TrendingUp, DollarSign, Clock, FileText, Shield, Users, Award, Zap, ArrowRight, AlertCircle } from 'lucide-react';
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const platformCapabilities = [
    {
        capability: "Complete CMMC Level 2 Automation",
        description: "Platform generates all required documentation (SSP, policies, procedures) in under 2 hours versus 6+ months manual process",
        impact: "Enables SMBs to meet DoD deadlines that would otherwise be impossible"
    },
    {
        capability: "AI-Powered Gap Analysis", 
        description: "Automated assessment of all 110 NIST SP 800-171 controls with specific implementation guidance",
        impact: "Eliminates need for $50K+ consultant fees for compliance assessment"
    },
    {
        capability: "Supply Chain Compliance Dashboard",
        description: "Real-time visibility into subcontractor compliance status for Prime contractors",
        impact: "Reduces contract risk and accelerates subcontractor onboarding"
    }
];

const dibImplications = [
    {
        title: "Democratized Market Entry",
        description: "By removing cost and time barriers, innovative SMBs can compete for DoD contracts based on capability rather than compliance budget. This expands the DIB talent pool and increases competition.",
        icon: Users
    },
    {
        title: "Supply Chain Resilience", 
        description: "Prime contractors can onboard and verify more diverse subcontractors quickly, creating a more robust and competitive supply chain ecosystem.",
        icon: Shield
    },
    {
        title: "Accelerated Compliance Cycles",
        description: "What previously took 12-18 months can now be accomplished in 90 days, enabling faster project delivery and reduced DoD procurement timelines.",
        icon: Zap
    }
];

export default function SBIRAppendixAnonymized() {
    return (
        <div className="space-y-8 p-4 md:p-6">
            <BreadcrumbNav currentPageName="SBIRAppendixAnonymized" />
            
            <div className="text-center">
                <Badge className="mb-4 text-lg">SBIR APPENDIX E: Market Impact Potential</Badge>
                <h1 className="text-3xl font-bold text-gray-900 mb-4">
                    Platform Readiness for Defense Industrial Base Transformation
                </h1>
                <p className="text-lg text-gray-600 max-w-4xl mx-auto">
                    How our fully operational AI-first compliance platform is positioned to strengthen the DIB by enabling SMB market participation.
                </p>
            </div>

            <Alert className="bg-blue-50 border-blue-200">
                <AlertCircle className="h-4 w-4 text-blue-700" />
                <AlertTitle className="font-bold text-blue-800">Current Status: Platform Ready, Seeking Real-World Validation</AlertTitle>
                <AlertDescription className="text-blue-700">
                    Our platform is fully developed and operational, capable of serving the entire 31,500+ SMB contractor market. We are now actively recruiting real DoD contractors for our free trial program to gather authentic usage data and testimonials.
                </AlertDescription>
            </Alert>
            
            <Card>
                <CardHeader>
                    <CardTitle>Platform Capabilities & Market Impact Potential</CardTitle>
                    <CardDescription>How our technology addresses critical DIB challenges</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    {platformCapabilities.map((capability, index) => (
                        <div key={index} className="p-4 border rounded-lg shadow-sm">
                            <h3 className="font-bold text-lg text-gray-800">{capability.capability}</h3>
                            <p className="text-sm mt-2 mb-3">{capability.description}</p>
                            <p className="text-sm text-green-700 font-medium bg-green-50 p-2 rounded">
                                <strong>Projected Impact:</strong> {capability.impact}
                            </p>
                        </div>
                    ))}
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>Strategic Implications for Defense Industrial Base</CardTitle>
                    <CardDescription>How AI-first compliance can transform the DIB ecosystem</CardDescription>
                </CardHeader>
                <CardContent className="grid md:grid-cols-3 gap-6">
                    {dibImplications.map((item, index) => {
                        const Icon = item.icon;
                        return (
                            <div key={index} className="p-4 bg-gray-50 rounded-lg">
                                <Icon className="w-8 h-8 text-blue-600 mb-3" />
                                <h3 className="font-semibold text-lg mb-2">{item.title}</h3>
                                <p className="text-sm text-gray-700">{item.description}</p>
                            </div>
                        );
                    })}
                </CardContent>
            </Card>

            <Card className="bg-green-50 border-green-200">
                <CardHeader>
                    <CardTitle className="text-green-800">Ready for Real-World Deployment</CardTitle>
                    <CardDescription className="text-green-700">
                        Platform is operational and ready to begin serving actual DoD contractors
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <p className="text-green-800 mb-4">
                        Our AI-first CMMC compliance platform has been fully developed and tested. All technical capabilities are operational and ready to serve real DoD contractors. We are now actively seeking authentic users to validate our market impact through our free trial program.
                    </p>
                    <Button asChild className="bg-green-700 hover:bg-green-800 text-white">
                        <Link to={createPageUrl('PartnershipTrial')}>
                            Join Our Validation Program <ArrowRight className="w-4 h-4 ml-2" />
                        </Link>
                    </Button>
                </CardContent>
            </Card>

        </div>
    );
}