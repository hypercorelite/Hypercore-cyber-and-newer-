import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { TrendingUp, Target, Search, Users, Link as LinkIcon, Globe, ExternalLink } from 'lucide-react';
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";
import { Button } from '@/components/ui/button';

const impressionsData = [
  { name: 'Week 1', organic: 120, direct: 30, referral: 10 },
  { name: 'Week 2', organic: 350, direct: 45, referral: 80 },
  { name: 'Week 3', organic: 680, direct: 60, referral: 150 },
  { name: 'Week 4', organic: 950, direct: 70, referral: 210 },
];

const keywordData = [
    { keyword: "CMMC for SMBs", rank: 8, change: "+3", volume: 1200 },
    { keyword: "AI CMMC compliance", rank: 12, change: "+5", volume: 800 },
    { keyword: "DFARS automation tool", rank: 15, change: "+8", volume: 450 },
    { keyword: "NIST 800-171 gap analysis", rank: 22, change: "+10", volume: 320 },
];

const topReferringDomains = [
    { domain: "reddit.com", backlinks: 3, traffic: 125 },
    { domain: "linkedin.com", backlinks: 5, traffic: 98 },
    { domain: "defensenews.com", backlinks: 1, traffic: 45 },
    { domain: "ndia.org/forums", backlinks: 2, traffic: 32 },
];

export default function SEOMetricsDashboard() {
    return (
        <div className="space-y-6">
            <BreadcrumbNav currentPageName="SEOMetricsDashboard" />

            <div className="text-center">
                <h1 className="text-3xl font-bold tracking-tight text-gray-900">Live SEO & Analytics Dashboard</h1>
                <p className="text-lg text-gray-600">Monitoring organic growth and content performance in real-time.</p>
            </div>

            <Alert className="bg-yellow-50 border-yellow-300">
                <Globe className="h-4 w-4 text-yellow-700" />
                <AlertTitle className="font-bold text-yellow-800">Live Data Simulation</AlertTitle>
                <AlertDescription className="text-yellow-700">
                    This dashboard simulates live data from Google Search Console & GA4 to track the effectiveness of your SEO strategy.
                </AlertDescription>
            </Alert>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <Card>
                    <CardHeader><CardTitle>Total Impressions</CardTitle></CardHeader>
                    <CardContent>
                        <p className="text-4xl font-bold">1,825</p>
                        <p className="text-sm text-green-600 flex items-center"><TrendingUp className="w-4 h-4 mr-1"/> +312% this month</p>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader><CardTitle>Organic Clicks</CardTitle></CardHeader>
                    <CardContent>
                        <p className="text-4xl font-bold">146</p>
                        <p className="text-sm text-green-600 flex items-center"><TrendingUp className="w-4 h-4 mr-1"/> +450% this month</p>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader><CardTitle>Avg. CTR</CardTitle></CardHeader>
                    <CardContent>
                        <p className="text-4xl font-bold">8.0%</p>
                        <p className="text-sm text-gray-500">Industry avg: 2.5%</p>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader><CardTitle>Conversions</CardTitle></CardHeader>
                    <CardContent>
                        <p className="text-4xl font-bold">7</p>
                        <p className="text-sm text-gray-500">From organic traffic</p>
                    </CardContent>
                </Card>
            </div>
            
            <Card>
                <CardHeader>
                    <CardTitle>Impression Growth by Source (Last 4 Weeks)</CardTitle>
                </CardHeader>
                <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                        <LineChart data={impressionsData}>
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="name" />
                            <YAxis />
                            <Tooltip />
                            <Legend />
                            <Line type="monotone" dataKey="organic" stroke="#10b981" name="Organic (Google)" strokeWidth={2} />
                            <Line type="monotone" dataKey="referral" stroke="#8b5cf6" name="Referral (Forums/Links)" strokeWidth={2} />
                            <Line type="monotone" dataKey="direct" stroke="#3b82f6" name="Direct" strokeWidth={2} />
                        </LineChart>
                    </ResponsiveContainer>
                </CardContent>
            </Card>

            <div className="grid md:grid-cols-2 gap-6">
                <Card>
                    <CardHeader>
                        <CardTitle>Keyword Rankings (Top 4)</CardTitle>
                    </CardHeader>
                    <CardContent>
                         <div className="space-y-2">
                            {keywordData.map(kw => (
                                <div key={kw.keyword} className="flex justify-between items-center p-2 bg-gray-50 rounded-md">
                                    <span className="font-medium text-sm">{kw.keyword}</span>
                                    <div className="flex items-center gap-3 text-sm">
                                        <Badge variant="secondary">Rank: {kw.rank}</Badge>
                                        <span className="text-green-600 font-bold">{kw.change}</span>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader>
                        <CardTitle>Top Referring Domains</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-2">
                            {topReferringDomains.map(ref => (
                                <div key={ref.domain} className="flex justify-between items-center p-2 bg-gray-50 rounded-md">
                                    <a href={`https://${ref.domain}`} target="_blank" rel="noopener noreferrer" className="font-medium text-sm text-blue-600 hover:underline flex items-center gap-1">
                                        {ref.domain} <ExternalLink className="w-3 h-3" />
                                    </a>
                                    <div className="flex items-center gap-3 text-sm">
                                        <Badge variant="outline">Traffic: {ref.traffic}</Badge>
                                        <Badge variant="secondary">Links: {ref.backlinks}</Badge>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}