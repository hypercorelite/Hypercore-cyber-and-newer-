
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Shield, Eye, UserPlus, ArrowRight } from 'lucide-react';

// Sample data for preview
const sampleControls = [
    {
        id: 'AC.L2-3.1.1',
        description: 'Limit system access to authorized users',
        policy: 'Access Control Policy',
        evidence: 'User access logs, account reviews',
        status: 'Implemented',
        lastReview: '2024-11-15'
    },
    {
        id: 'AU.L2-3.3.1', 
        description: 'Create and retain system audit logs',
        policy: 'Audit and Accountability Policy',
        evidence: 'SIEM configuration, log retention policy',
        status: 'In Progress',
        lastReview: '2024-11-10'
    },
    {
        id: 'IA.L2-3.5.1',
        description: 'Identify system users and processes',
        policy: 'Identification and Authentication Policy',
        evidence: 'Identity management system documentation',
        status: 'Not Started',
        lastReview: null
    }
];

export default function PreviewTraceabilityMatrix() {
    const [selectedControl, setSelectedControl] = useState(null);

    useEffect(() => {
        document.title = "Preview CMMC Traceability Matrix Tool | HyperCore";
        const metaDesc = document.querySelector('meta[name="description"]');
        if (metaDesc) {
            metaDesc.setAttribute('content', 'Evaluate our CMMC Level 2 Traceability Matrix tool without signing up. Ideal for government professionals and DoD contractors performing initial technology assessments.');
        }
    }, []);

    const getStatusColor = (status) => {
        switch (status) {
            case 'Implemented': return 'bg-green-100 text-green-800';
            case 'In Progress': return 'bg-yellow-100 text-yellow-800';
            case 'Not Started': return 'bg-red-100 text-red-800';
            default: return 'bg-gray-100 text-gray-800';
        }
    };

    return (
        <div className="min-h-screen bg-gray-50 py-8">
            <div className="container mx-auto px-4 max-w-7xl">
                {/* Preview Banner */}
                <Alert className="mb-6 bg-blue-50 border-blue-200">
                    <Eye className="h-4 w-4 text-blue-600" />
                    <AlertTitle className="text-blue-800">Preview Mode - Government Evaluation</AlertTitle>
                    <AlertDescription className="text-blue-700">
                        This is a preview of the Traceability Matrix tool with sample data. 
                        <Link to={createPageUrl('Register')} className="font-semibold underline ml-1 hover:text-blue-600">
                            Sign up for free access
                        </Link> to use with your actual data.
                    </AlertDescription>
                </Alert>

                <div className="flex justify-between items-center mb-6">
                    <div>
                        <h1 className="text-3xl font-bold text-gray-900">CMMC Traceability Matrix</h1>
                        <p className="text-gray-600">Map NIST controls to policies, evidence, and implementation status</p>
                    </div>
                    <Button asChild size="lg" className="bg-blue-600 hover:bg-blue-700">
                        <Link to={createPageUrl('Register')}>
                            <UserPlus className="w-4 h-4 mr-2" />
                            Get Full Access
                        </Link>
                    </Button>
                </div>

                <div className="grid lg:grid-cols-3 gap-6">
                    {/* Controls List */}
                    <div className="lg:col-span-2">
                        <Card>
                            <CardHeader>
                                <CardTitle>NIST 800-171 Controls (Sample)</CardTitle>
                                <CardDescription>Click a control to view details</CardDescription>
                            </CardHeader>
                            <CardContent>
                                <Table>
                                    <TableHeader>
                                        <TableRow>
                                            <TableHead>Control ID</TableHead>
                                            <TableHead>Description</TableHead>
                                            <TableHead>Status</TableHead>
                                            <TableHead>Last Review</TableHead>
                                        </TableRow>
                                    </TableHeader>
                                    <TableBody>
                                        {sampleControls.map((control) => (
                                            <TableRow 
                                                key={control.id}
                                                className="cursor-pointer hover:bg-gray-50"
                                                onClick={() => setSelectedControl(control)}
                                            >
                                                <TableCell className="font-medium">{control.id}</TableCell>
                                                <TableCell className="max-w-md truncate">{control.description}</TableCell>
                                                <TableCell>
                                                    <Badge className={getStatusColor(control.status)}>
                                                        {control.status}
                                                    </Badge>
                                                </TableCell>
                                                <TableCell>{control.lastReview || 'Not reviewed'}</TableCell>
                                            </TableRow>
                                        ))}
                                    </TableBody>
                                </Table>
                            </CardContent>
                        </Card>
                    </div>

                    {/* Control Details */}
                    <div>
                        <Card>
                            <CardHeader>
                                <CardTitle>Control Details</CardTitle>
                            </CardHeader>
                            <CardContent>
                                {selectedControl ? (
                                    <div className="space-y-4">
                                        <div>
                                            <h3 className="font-semibold text-lg">{selectedControl.id}</h3>
                                            <p className="text-gray-600">{selectedControl.description}</p>
                                        </div>
                                        <div>
                                            <h4 className="font-medium">Related Policy:</h4>
                                            <p className="text-sm text-gray-600">{selectedControl.policy}</p>
                                        </div>
                                        <div>
                                            <h4 className="font-medium">Evidence:</h4>
                                            <p className="text-sm text-gray-600">{selectedControl.evidence}</p>
                                        </div>
                                        <div>
                                            <h4 className="font-medium">Status:</h4>
                                            <Badge className={getStatusColor(selectedControl.status)}>
                                                {selectedControl.status}
                                            </Badge>
                                        </div>
                                        <Alert className="bg-yellow-50 border-yellow-200">
                                            <Shield className="h-4 w-4 text-yellow-600" />
                                            <AlertDescription className="text-yellow-700">
                                                In the full version, you can edit status, upload evidence files, and track implementation progress.
                                            </AlertDescription>
                                        </Alert>
                                    </div>
                                ) : (
                                    <p className="text-gray-500">Select a control from the list to view details</p>
                                )}
                            </CardContent>
                        </Card>
                    </div>
                </div>

                {/* CTA Section */}
                <Card className="mt-8 bg-gradient-to-r from-blue-600 to-indigo-700 text-white">
                    <CardContent className="text-center py-8">
                        <h2 className="text-2xl font-bold mb-4">Ready to Use This With Your Data?</h2>
                        <p className="text-blue-100 mb-6">
                            Import your actual controls, map to your policies, and track real implementation status.
                        </p>
                        <Button asChild size="lg" variant="secondary">
                            <Link to={createPageUrl('Register')}>
                                Start Free Trial <ArrowRight className="w-4 h-4 ml-2" />
                            </Link>
                        </Button>
                    </CardContent>
                </Card>

                <div className="text-center mt-8">
                    <Card className="bg-blue-50 border-blue-200">
                        <CardContent className="p-6">
                            <h3 className="text-xl font-semibold text-blue-900 mb-2">Ready to Use the Full Tool?</h3>
                            <p className="text-blue-700 mb-4">Access the complete traceability matrix with your compliance data</p>
                            <Button asChild className="bg-blue-600 hover:bg-blue-700">
                                <Link to={createPageUrl('TraceabilityMatrix')}>
                                    Go to Full Traceability Matrix Tool
                                </Link>
                            </Button>
                        </CardContent>
                    </Card>
                </div>
            </div>
        </div>
    );
}
