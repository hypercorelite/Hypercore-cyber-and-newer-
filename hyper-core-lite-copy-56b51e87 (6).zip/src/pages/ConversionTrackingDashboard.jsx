import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ClientOnboarding } from "@/api/entities";
import { ClientEngagement } from "@/api/entities";
import { ClientFeedback } from "@/api/entities";
import { PartnershipCommunication } from "@/api/entities";
import { TrendingUp, Users, DollarSign, Clock, AlertTriangle, CheckCircle, Mail } from 'lucide-react';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, PieChart, Pie, Cell } from 'recharts';
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert";

export default function ConversionTrackingDashboard() {
    const [conversionData, setConversionData] = useState({
        totalTrialUsers: 0,
        convertedUsers: 0,
        conversionRate: 0,
        averageTimeToConvert: 0,
        dropoffStages: [],
        revenueFromConversions: 0,
        followupNeeded: []
    });
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        loadConversionData();
    }, []);

    const loadConversionData = async () => {
        try {
            // Get all trial users
            const trialUsers = await ClientOnboarding.list();
            const engagements = await ClientEngagement.list();
            const partnerships = await PartnershipCommunication.filter({ partnership_type: 'client' });
            
            // Calculate conversion metrics
            const totalTrials = trialUsers.length;
            const converted = partnerships.filter(p => p.status === 'active_partner').length;
            const conversionRate = totalTrials > 0 ? ((converted / totalTrials) * 100).toFixed(1) : 0;

            // Identify users needing follow-up (completed assessment but no recent engagement)
            const followupNeeded = trialUsers.filter(user => {
                const hasRecentEngagement = engagements.some(eng => 
                    eng.client_email === user.client_email && 
                    new Date(eng.created_date) > new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
                );
                return user.onboarding_stage === 'assessment_started' && !hasRecentEngagement;
            });

            // Calculate estimated revenue (assuming $297/month per conversion)
            const estimatedRevenue = converted * 297;

            // Drop-off analysis
            const stages = {
                'email_captured': trialUsers.filter(u => u.onboarding_stage === 'email_captured').length,
                'profile_completed': trialUsers.filter(u => u.onboarding_stage === 'profile_completed').length,
                'assessment_started': trialUsers.filter(u => u.onboarding_stage === 'assessment_started').length,
                'report_generated': trialUsers.filter(u => u.onboarding_stage === 'report_generated').length,
                'conversion_interested': trialUsers.filter(u => u.onboarding_stage === 'conversion_interested').length,
            };

            setConversionData({
                totalTrialUsers: totalTrials,
                convertedUsers: converted,
                conversionRate: parseFloat(conversionRate),
                followupNeeded: followupNeeded,
                revenueFromConversions: estimatedRevenue,
                dropoffStages: Object.entries(stages).map(([stage, count]) => ({
                    stage: stage.replace('_', ' ').toUpperCase(),
                    count,
                    percentage: totalTrials > 0 ? ((count / totalTrials) * 100).toFixed(1) : 0
                }))
            });

        } catch (error) {
            console.error('Failed to load conversion data:', error);
        } finally {
            setLoading(false);
        }
    };

    const sendFollowupEmail = async (user) => {
        // This would trigger your follow-up email system
        alert(`Follow-up email would be sent to ${user.client_email}`);
    };

    if (loading) {
        return <div className="p-8 text-center">Loading conversion data...</div>;
    }

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <div>
                    <h1 className="text-3xl font-bold">Conversion Tracking Dashboard</h1>
                    <p className="text-gray-600">Monitor trial-to-paid conversion metrics and identify optimization opportunities</p>
                </div>
                <Button onClick={loadConversionData} variant="outline">
                    Refresh Data
                </Button>
            </div>

            {/* Key Metrics */}
            <div className="grid md:grid-cols-4 gap-6">
                <Card>
                    <CardHeader className="pb-2">
                        <CardTitle className="text-sm flex items-center gap-2">
                            <Users className="w-4 h-4" />
                            Total Trial Users
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-3xl font-bold">{conversionData.totalTrialUsers}</p>
                        <p className="text-sm text-gray-600">All time</p>
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader className="pb-2">
                        <CardTitle className="text-sm flex items-center gap-2">
                            <CheckCircle className="w-4 h-4 text-green-600" />
                            Converted to Paid
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-3xl font-bold text-green-600">{conversionData.convertedUsers}</p>
                        <p className="text-sm text-gray-600">Active partnerships</p>
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader className="pb-2">
                        <CardTitle className="text-sm flex items-center gap-2">
                            <TrendingUp className="w-4 h-4" />
                            Conversion Rate
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-3xl font-bold">{conversionData.conversionRate}%</p>
                        <Badge variant={conversionData.conversionRate > 10 ? "default" : "destructive"}>
                            {conversionData.conversionRate > 10 ? "Strong" : "Needs Improvement"}
                        </Badge>
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader className="pb-2">
                        <CardTitle className="text-sm flex items-center gap-2">
                            <DollarSign className="w-4 h-4" />
                            Est. Monthly Revenue
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-3xl font-bold">${conversionData.revenueFromConversions.toLocaleString()}</p>
                        <p className="text-sm text-gray-600">From conversions</p>
                    </CardContent>
                </Card>
            </div>

            {/* Funnel Drop-off Analysis */}
            <Card>
                <CardHeader>
                    <CardTitle>Conversion Funnel Analysis</CardTitle>
                    <CardDescription>Identify where users are dropping off in your trial flow</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="space-y-4">
                        {conversionData.dropoffStages.map((stage, index) => (
                            <div key={index} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                                <span className="font-medium">{stage.stage}</span>
                                <div className="flex items-center gap-3">
                                    <span className="text-2xl font-bold">{stage.count}</span>
                                    <Badge variant="outline">{stage.percentage}%</Badge>
                                </div>
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>

            {/* Follow-up Needed */}
            {conversionData.followupNeeded.length > 0 && (
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <AlertTriangle className="w-5 h-5 text-orange-600" />
                            Users Needing Follow-up
                        </CardTitle>
                        <CardDescription>
                            Trial users who completed assessment but haven't engaged recently
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-3">
                            {conversionData.followupNeeded.slice(0, 10).map((user, index) => (
                                <div key={index} className="flex justify-between items-center p-3 border rounded-lg">
                                    <div>
                                        <p className="font-medium">{user.client_name}</p>
                                        <p className="text-sm text-gray-600">{user.client_email}</p>
                                        <p className="text-sm text-gray-600">{user.company_name}</p>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        <Badge variant="outline">{user.onboarding_stage}</Badge>
                                        <Button 
                                            size="sm" 
                                            onClick={() => sendFollowupEmail(user)}
                                            className="flex items-center gap-1"
                                        >
                                            <Mail className="w-3 h-3" />
                                            Follow Up
                                        </Button>
                                    </div>
                                </div>
                            ))}
                        </div>
                        {conversionData.followupNeeded.length > 10 && (
                            <p className="text-sm text-gray-600 mt-3">
                                And {conversionData.followupNeeded.length - 10} more users needing follow-up...
                            </p>
                        )}
                    </CardContent>
                </Card>
            )}

            {/* Conversion Optimization Recommendations */}
            <Alert>
                <TrendingUp className="h-4 w-4" />
                <AlertTitle>Optimization Recommendations</AlertTitle>
                <AlertDescription>
                    <ul className="list-disc list-inside space-y-1 mt-2">
                        <li>Your conversion rate is {conversionData.conversionRate}%. Industry average is 10-15%.</li>
                        <li>{conversionData.followupNeeded.length} users need immediate follow-up emails.</li>
                        <li>Consider A/B testing different trial flows to improve drop-off rates.</li>
                        <li>Focus on the assessment-to-report stage where most users seem to drop off.</li>
                    </ul>
                </AlertDescription>
            </Alert>
        </div>
    );
}