import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, XCircle, Loader2, PlayCircle } from 'lucide-react';
import { toast } from "sonner";

const tests = [
    { id: 'ssp_gen', name: 'AI SSP Generation', description: 'Tests if the AI can generate a complete SSP from mock data.' },
    { id: 'poam_gen', name: 'AI POA&M Generation', description: 'Tests creation of POA&M for non-compliant controls.' },
    { id: 'sprs_calc', name: 'SPRS Score Calculation', description: 'Verifies the accuracy of the SPRS scoring logic.' },
    { id: 'evidence_link', name: 'Evidence Linking', description: 'Ensures evidence can be correctly linked to controls in the matrix.' },
    { id: 'drift_alert', name: 'Drift Detection Alert', description: 'Simulates a configuration change and verifies alert generation.' },
    { id: 'contract_scan', name: 'DFARS Contract Scan', description: 'Tests the Smart Contract Analyzer for DFARS 7012 clause.' }
];

export default function SystemTests() {
    const [testResults, setTestResults] = useState({});
    const [runningTests, setRunningTests] = useState({});

    const runTest = (testId) => {
        setRunningTests(prev => ({ ...prev, [testId]: true }));
        toast.info(`Running test: ${tests.find(t => t.id === testId)?.name}`);
        
        // Simulate an async test
        setTimeout(() => {
            const success = Math.random() > 0.15; // 85% success rate
            setTestResults(prev => ({ ...prev, [testId]: success ? 'Passed' : 'Failed' }));
            setRunningTests(prev => ({ ...prev, [testId]: false }));
            toast[success ? 'success' : 'error'](`Test ${success ? 'passed' : 'failed'}: ${tests.find(t => t.id === testId)?.name}`);
        }, 1500 + Math.random() * 1000);
    };

    return (
        <div className="space-y-6">
            <div className="text-center">
                <h1 className="text-3xl font-bold">DFARS Assessment Suite - System Tests</h1>
                <p className="text-lg text-gray-600">Verify the functionality of all new AI-powered DFARS compliance tools.</p>
            </div>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {tests.map(test => (
                    <Card key={test.id}>
                        <CardHeader>
                            <CardTitle>{test.name}</CardTitle>
                            <CardDescription>{test.description}</CardDescription>
                        </CardHeader>
                        <CardContent className="flex flex-col items-center justify-center space-y-4">
                            {testResults[test.id] && (
                                <Badge variant={testResults[test.id] === 'Passed' ? 'default' : 'destructive'} className="text-lg px-4 py-2">
                                    {testResults[test.id] === 'Passed' ? 
                                        <CheckCircle className="w-5 h-5 mr-2"/> : 
                                        <XCircle className="w-5 h-5 mr-2"/>
                                    }
                                    {testResults[test.id]}
                                </Badge>
                            )}
                            <Button onClick={() => runTest(test.id)} disabled={runningTests[test.id]}>
                                {runningTests[test.id] ? 
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : 
                                    <PlayCircle className="w-4 h-4 mr-2" />
                                }
                                Run Test
                            </Button>
                        </CardContent>
                    </Card>
                ))}
            </div>
        </div>
    );
}