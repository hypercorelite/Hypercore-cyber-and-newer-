import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { FileText, Upload, Brain, CheckCircle, AlertTriangle } from 'lucide-react';
import { motion } from "framer-motion";

export default function SmartContractAnalyzer() {
    const [analysisResult, setAnalysisResult] = useState({
        contractType: "DoD Subcontract",
        cmmcLevel: "Level 2",
        flowDownClauses: [
            {
                clause: "DFARS 252.204-7012",
                title: "Safeguarding Covered Defense Information",
                requirement: "Implement NIST SP 800-171 controls",
                compliance: "Required",
                deadline: "Contract Performance Period"
            },
            {
                clause: "DFARS 252.204-7021", 
                title: "Cybersecurity Maturity Model Certification",
                requirement: "Achieve CMMC Level 2 certification",
                compliance: "Required",
                deadline: "October 1, 2025"
            },
            {
                clause: "FAR 52.204-21",
                title: "Basic Safeguarding of Covered Contractor Information Systems",
                requirement: "Apply basic security controls",
                compliance: "Superseded by DFARS 7012",
                deadline: "N/A"
            }
        ],
        riskAssessment: {
            overallRisk: "Medium",
            keyRisks: [
                "Tight CMMC certification timeline",
                "CUI handling requirements unclear",
                "Subcontractor flow-down obligations"
            ]
        },
        aiRecommendations: [
            "Begin CMMC Level 2 preparation immediately",
            "Implement NIST SP 800-171 controls within 90 days",
            "Establish CUI identification and handling procedures",
            "Create subcontractor cybersecurity flow-down requirements"
        ]
    });

    return (
        <div className="space-y-8">
            <div className="text-center">
                <h1 className="text-3xl font-bold text-gray-900 mb-4 flex items-center justify-center gap-3">
                    <FileText className="w-8 h-8 text-blue-600" />
                    Smart Contract Flow-Down Analyzer
                </h1>
                <p className="text-lg text-gray-600 max-w-4xl mx-auto">
                    AI-powered analysis of DoD contract clauses to identify exact CMMC requirements and deadlines.
                </p>
            </div>

            <Card>
                <CardHeader>
                    <CardTitle>Upload Contract for AI Analysis</CardTitle>
                    <CardDescription>Our AI will identify all cybersecurity flow-down requirements and CMMC obligations</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                        <Upload className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                        <p className="text-lg font-medium text-gray-700 mb-2">Drop your contract here</p>
                        <p className="text-sm text-gray-500 mb-4">Supports PDF, Word, and text files</p>
                        <Button>
                            <Upload className="w-4 h-4 mr-2" />
                            Choose File
                        </Button>
                    </div>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Brain className="w-5 h-5 text-purple-600" />
                        AI Analysis Results
                    </CardTitle>
                    <CardDescription>Intelligent extraction of cybersecurity requirements from contract language</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-4">
                        <div>
                            <p className="font-semibold">Contract Type:</p>
                            <Badge className="bg-blue-100 text-blue-800">{analysisResult.contractType}</Badge>
                        </div>
                        <div>
                            <p className="font-semibold">Required CMMC Level:</p>
                            <Badge className="bg-green-100 text-green-800">{analysisResult.cmmcLevel}</Badge>
                        </div>
                    </div>

                    <div>
                        <h3 className="font-semibold text-lg mb-4">Identified Flow-Down Clauses</h3>
                        <div className="space-y-4">
                            {analysisResult.flowDownClauses.map((clause, index) => (
                                <motion.div
                                    key={index}
                                    initial={{ opacity: 0, x: -20 }}
                                    animate={{ opacity: 1, x: 0 }}
                                    transition={{ delay: index * 0.1 }}
                                    className="p-4 border rounded-lg"
                                >
                                    <div className="flex justify-between items-start mb-2">
                                        <div>
                                            <h4 className="font-semibold">{clause.clause}</h4>
                                            <p className="text-sm text-gray-600">{clause.title}</p>
                                        </div>
                                        <Badge 
                                            className={clause.compliance === 'Required' ? 
                                                'bg-red-100 text-red-800' : 
                                                'bg-gray-100 text-gray-800'
                                            }
                                        >
                                            {clause.compliance}
                                        </Badge>
                                    </div>
                                    <p className="text-sm mb-2"><strong>Requirement:</strong> {clause.requirement}</p>
                                    <p className="text-sm"><strong>Deadline:</strong> {clause.deadline}</p>
                                </motion.div>
                            ))}
                        </div>
                    </div>

                    <Alert className="bg-yellow-50 border-yellow-200">
                        <AlertTriangle className="h-4 w-4 text-yellow-600" />
                        <AlertTitle className="text-yellow-800">Risk Assessment: {analysisResult.riskAssessment.overallRisk}</AlertTitle>
                        <AlertDescription className="text-yellow-700">
                            <ul className="list-disc list-inside mt-2">
                                {analysisResult.riskAssessment.keyRisks.map((risk, index) => (
                                    <li key={index}>{risk}</li>
                                ))}
                            </ul>
                        </AlertDescription>
                    </Alert>

                    <div>
                        <h3 className="font-semibold text-lg mb-4 flex items-center gap-2">
                            <CheckCircle className="w-5 h-5 text-green-600" />
                            AI Recommendations
                        </h3>
                        <div className="space-y-2">
                            {analysisResult.aiRecommendations.map((recommendation, index) => (
                                <div key={index} className="flex items-start gap-3 p-3 bg-green-50 rounded">
                                    <CheckCircle className="w-5 h-5 text-green-600 mt-0.5 flex-shrink-0" />
                                    <p className="text-sm">{recommendation}</p>
                                </div>
                            ))}
                        </div>
                    </div>
                </CardContent>
            </Card>

            <Alert className="bg-blue-50 border-blue-200">
                <Brain className="h-4 w-4 text-blue-600" />
                <AlertTitle className="text-blue-800 font-bold">Why Contract Analysis Matters</AlertTitle>
                <AlertDescription className="text-blue-700">
                    Most contractors misunderstand their exact CMMC obligations, leading to over-compliance (wasted money) or under-compliance (contract loss). 
                    Our AI reads the fine print so you know exactly what's required, when it's due, and what it means for your business.
                </AlertDescription>
            </Alert>
        </div>
    );
}