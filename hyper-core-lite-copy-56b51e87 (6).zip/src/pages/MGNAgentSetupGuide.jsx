
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Copy, Terminal, ShieldCheck, HardDrive } from 'lucide-react';
import BreadcrumbNav from '../components/navigation/BreadcrumbNav';
import { toast } from "sonner";

const copyToClipboard = (text, message) => {
    navigator.clipboard.writeText(text);
    toast.success(message);
};

const steps = [
    {
        title: "Connect to Your EC2 Instance",
        icon: Terminal,
        description: "Use SSH to log into the EC2 instance that you have prepared as your source server. All the following commands must be run on that server.",
        details: "Example: `ssh -i 'your-key.pem' ubuntu@your-ec2-ip-address`"
    },
    {
        title: "Install/Update AWS CLI",
        icon: HardDrive,
        description: "Ensure the AWS Command Line Interface is installed and up-to-date. This tool allows your server to communicate with AWS services.",
        commands: [
            { cmd: "sudo apt update && sudo apt upgrade -y", desc: "Update your server's package list." },
            { cmd: "sudo apt install -y python3-pip unzip", desc: "Install Python's package manager and unzip." },
            { cmd: "pip3 install awscli --upgrade --user", desc: "Install or upgrade the AWS CLI." }
        ]
    },
    {
        title: "Configure AWS Credentials",
        icon: ShieldCheck,
        description: "Configure the AWS CLI with the Access Key and Secret Key you just created. This authorizes the server to install the MGN agent.",
        command: "aws configure",
        configSteps: [
            "Run the command `aws configure`.",
            "Paste your **Access Key ID** when prompted.",
            "Paste your **Secret Access Key** when prompted.",
            "For **Default region name**, type: `us-east-1` and press Enter.",
            "For **Default output format**, type: `json` and press Enter."
        ]
    },
    {
        title: "Download and Run the MGN Installer",
        icon: Terminal,
        description: "Download the AWS Application Migration Service agent installer and run it with sudo privileges. This script will install the agent and register your server with MGN.",
        commands: [
            { 
                cmd: "wget -O ./aws-application-migration-service-agent-installer-latest.py https://aws-application-migration-service-us-east-1.s3.us-east-1.amazonaws.com/latest/linux/aws-application-migration-service-agent-installer-latest.py", 
                desc: "Download the MGN agent installer script." 
            },
            { 
                cmd: "sudo python3 aws-application-migration-service-agent-installer-latest.py --region us-east-1", 
                desc: "Run the installer. It will use the credentials you configured in the previous step." 
            }
        ]
    }
];

const CommandBlock = ({ command }) => (
    <div className="space-y-1">
        <p className="text-xs font-semibold text-gray-600">{command.desc}</p>
        <div className="relative bg-gray-800 text-white p-3 pr-12 rounded-md font-mono text-sm">
            <code>{command.cmd}</code>
            <Button size="icon" variant="ghost" className="absolute top-1/2 right-2 -translate-y-1/2 h-8 w-8" onClick={() => copyToClipboard(command.cmd, "Command copied!")}>
                <Copy className="h-4 w-4" />
            </Button>
        </div>
    </div>
);


export default function MGNAgentSetupGuide() {
    return (
        <div className="space-y-6">
            <BreadcrumbNav currentPageName="MGNAgentSetupGuide" />
            <div className="text-center">
                <h1 className="text-3xl font-bold">MGN Agent Installation Guide</h1>
                <p className="text-lg text-gray-600 mt-2">The final step: Installing the AWS migration agent on your source server.</p>
            </div>

            <Alert className="bg-green-50 border-green-200">
                <ShieldCheck className="h-4 w-4" />
                <AlertTitle className="font-bold text-green-800">Process Complete</AlertTitle>
                <AlertDescription className="text-green-700">
                    Once these steps are complete, your EC2 instance will appear in the AWS MGN Console as a 'Source Server' and begin replicating. This is the final step for Week 3 of the sprint plan.
                </AlertDescription>
            </Alert>

            <div className="space-y-4">
                {steps.map((step, index) => (
                    <Card key={index}>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-3">
                                <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center">
                                    <step.icon className="w-5 h-5 text-gray-600" />
                                </div>
                                <span>{step.title}</span>
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="mb-4">{step.description}</p>
                            {step.details && <p className="text-sm text-gray-500 bg-gray-50 p-3 rounded-md mb-4">{step.details}</p>}
                            
                            {step.command && (
                                <div className="relative bg-gray-800 text-white p-3 pr-12 rounded-md font-mono text-sm mb-4">
                                    <code>{step.command}</code>
                                    <Button size="icon" variant="ghost" className="absolute top-1/2 right-2 -translate-y-1/2 h-8 w-8" onClick={() => copyToClipboard(step.command, "Command copied!")}>
                                        <Copy className="h-4 w-4" />
                                    </Button>
                                </div>
                            )}

                            {step.configSteps && (
                                <ul className="list-decimal list-inside space-y-2 text-sm text-gray-700 bg-blue-50 p-4 rounded-md mb-4">
                                    {step.configSteps.map((c, i) => <li key={i}>{c}</li>)}
                                </ul>
                            )}

                            {step.commands && (
                                <div className="space-y-3">
                                    {step.commands.map((c, i) => (
                                        <CommandBlock key={i} command={c} />
                                    ))}
                                </div>
                            )}
                        </CardContent>
                    </Card>
                ))}
            </div>
        </div>
    );
}
