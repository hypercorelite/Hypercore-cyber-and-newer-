
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CheckCircle, XCircle, Shield, ArrowRight, Scale, DollarSign, BookOpen, Users, ClipboardCheck, Gavel, TrendingUp, AlertTriangle, Building, User, ScrollText, Calendar } from 'lucide-react';
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

const requirements = [
    { title: "Register with The Cyber AB", description: "Create an account and apply on the official CMMC Accreditation Body (The Cyber AB) Marketplace.", icon: ClipboardCheck },
    { title: "Pay Annual Fee", description: "An annual fee is required to maintain RPO status. This is currently around $5,000.", icon: DollarSign },
    { title: "Pass Organizational Background Check", description: "The organization must undergo and pass a background check conducted by The Cyber AB's partner.", icon: Shield },
    { title: "Employ at least one Registered Practitioner (RP)", description: "Your staff must include at least one trained and certified RP. Each RP requires separate training and fees.", icon: Users },
    { title: "Sign RPO Agreement & Code of Conduct", description: "You must agree to the legal terms and ethical obligations set forth by The Cyber AB.", icon: Gavel }
];

const prosAndCons = {
    pros: [
        { title: "Official Credibility", description: "Your organization is listed on The Cyber AB Marketplace, providing a powerful stamp of approval.", icon: CheckCircle },
        { title: "Direct Marketing Channel", description: "Companies seeking CMMC help use the Marketplace to find verified providers.", icon: CheckCircle },
        { title: "Access to Official Resources", description: "Gain access to RPO-specific materials, updates, and communications from The Cyber AB.", icon: CheckCircle },
        { title: "Clearer Market Positioning", description: "Moves from an 'independent tutor' to an 'official consultant', which may be easier for DIB clients to understand.", icon: CheckCircle }
    ],
    cons: [
        { title: "Shift in Marketing Message", description: "The 'unbiased, conflict-free tutor' angle is weakened. You become an official consultant, a different value proposition.", icon: XCircle },
        { title: "Annual & Per-Person Costs", description: "Incurs annual RPO fees plus training, exam, and application fees for each Registered Practitioner (RP) on staff.", icon: XCircle },
        { title: "Administrative Overhead", description: "Requires ongoing effort to maintain compliance with The Cyber AB's requirements and renew status.", icon: XCircle },
        { title: "Direct Competition", description: "You will be listed alongside all other RPOs, moving from a niche 'tutoring' market to a more crowded 'consulting' market.", icon: XCircle }
    ]
};

export default function RPOEvaluationStrategy() {
    return (
        <div className="min-h-screen bg-gray-50 p-4 sm:p-6 lg:p-8">
            <div className="max-w-6xl mx-auto">
                <motion.div
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="text-center mb-12"
                >
                    <Badge className="mb-4 bg-red-100 text-red-800">🔒 ADMIN ONLY - STRATEGIC PIVOT</Badge>
                    <h1 className="text-4xl lg:text-5xl font-extrabold text-gray-900 mb-4 tracking-tight">
                        RPO Status Evaluation & Strategy
                    </h1>
                    <p className="text-lg lg:text-xl text-gray-600 max-w-4xl mx-auto">
                        A comprehensive guide to the requirements, costs, and strategic implications of becoming a CMMC Registered Provider Organization (RPO).
                    </p>
                </motion.div>

                <Alert className="mb-12 bg-blue-50 border-blue-200">
                    <Shield className="h-4 w-4 text-blue-700" />
                    <AlertTitle className="font-semibold text-blue-800">What is an RPO?</AlertTitle>
                    <AlertDescription className="text-blue-700 mt-2">
                        An RPO is an organization authorized by the CMMC Cyber AB to provide CMMC consulting services to companies in the Defense Industrial Base. RPOs are trained and vetted, but they **cannot** conduct official audits. This maintains a separation between consulting and auditing. Your role would be to prepare clients *for* their audit with a C3PAO.
                    </AlertDescription>
                </Alert>

                <Card className="mb-12">
                    <CardHeader>
                        <CardTitle className="text-2xl">The Path to Becoming an RPO</CardTitle>
                        <CardDescription>These are the official steps and requirements mandated by The Cyber AB.</CardDescription>
                    </CardHeader>
                    <CardContent className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {requirements.map((req, index) => (
                            <div key={index} className="p-4 border rounded-lg bg-white flex items-start gap-4">
                                <req.icon className="w-8 h-8 text-blue-600 mt-1 flex-shrink-0" />
                                <div>
                                    <h3 className="font-semibold">{req.title}</h3>
                                    <p className="text-sm text-gray-600">{req.description}</p>
                                </div>
                            </div>
                        ))}
                    </CardContent>
                </Card>

                <Card className="mb-12">
                    <CardHeader>
                        <CardTitle className="text-2xl">Estimated Cost Breakdown</CardTitle>
                        <CardDescription>Costs are based on current Cyber AB fee structures and market rates for training. These are estimates for the first year.</CardDescription>
                    </CardHeader>
                    <CardContent className="grid md:grid-cols-2 gap-x-8 gap-y-6">
                        <div className="space-y-4">
                            <h3 className="font-semibold text-lg flex items-center gap-2"><Building className="w-5 h-5 text-gray-600"/>Organizational Costs (RPO)</h3>
                            <ul className="space-y-3 text-sm">
                                <li className="flex justify-between items-center">
                                    <span><Shield className="w-4 h-4 inline mr-2 text-gray-500" />RPO Application & Background Check:</span>
                                    <span className="font-bold text-gray-800">$1,000 - $2,000</span>
                                </li>
                                <li className="flex justify-between items-center">
                                    <span><Calendar className="w-4 h-4 inline mr-2 text-gray-500" />RPO Annual Marketplace Fee:</span>
                                    <span className="font-bold text-gray-800">$5,000</span>
                                </li>
                            </ul>
                        </div>
                        <div className="space-y-4">
                            <h3 className="font-semibold text-lg flex items-center gap-2"><User className="w-5 h-5 text-gray-600"/>Individual Costs (per Registered Practitioner)</h3>
                            <ul className="space-y-3 text-sm">
                                <li className="flex justify-between items-center">
                                    <span><BookOpen className="w-4 h-4 inline mr-2 text-gray-500" />Approved RP Training Course:</span>
                                    <span className="font-bold text-gray-800">$1,500 - $2,500</span>
                                </li>
                                <li className="flex justify-between items-center">
                                    <span><ScrollText className="w-4 h-4 inline mr-2 text-gray-500" />RP Exam & Application Fee:</span>
                                    <span className="font-bold text-gray-800">$550</span>
                                </li>
                                <li className="flex justify-between items-center">
                                    <span><Calendar className="w-4 h-4 inline mr-2 text-gray-500" />RP Annual Maintenance Fee:</span>
                                    <span className="font-bold text-gray-800">$250</span>
                                </li>
                            </ul>
                        </div>
                    </CardContent>
                    <div className="p-4 border-t">
                        <Alert>
                            <DollarSign className="h-4 w-4" />
                            <AlertTitle className="font-bold">Total Estimated First-Year Cost</AlertTitle>
                            <AlertDescription>
                                Approximately <strong>$8,300 - $10,300</strong> for the organization and one Registered Practitioner. Each additional RP would add ~$2,300.
                            </AlertDescription>
                        </Alert>
                    </div>
                </Card>
                
                <Card className="mb-12">
                    <CardHeader>
                        <CardTitle className="text-2xl">Assessment: Importance to Our Tutoring Model</CardTitle>
                        <CardDescription>Evaluating if RPO status helps or hinders our unique "expert tutor" value proposition.</CardDescription>
                    </CardHeader>
                    <CardContent className="grid md:grid-cols-2 gap-8">
                        <div className="space-y-4">
                            <h3 className="text-xl font-semibold text-center text-green-700 flex items-center justify-center gap-2"><TrendingUp /> How RPO Status ENHANCES the Model</h3>
                            <div className="p-4 bg-green-50 rounded-lg">
                                <h4 className="font-semibold text-green-800">Adds Official Validation</h4>
                                <p className="text-sm text-green-700">It provides third-party validation from The Cyber AB, transforming our "expert tutor" claim into an "accredited expert tutor" fact. This builds immediate trust.</p>
                            </div>
                            <div className="p-4 bg-green-50 rounded-lg">
                                <h4 className="font-semibold text-green-800">Unlocks a Primary Lead Channel</h4>
                                <p className="text-sm text-green-700">The Cyber AB Marketplace is the #1 place companies look for help. Being listed finds the "students" for our tutoring model automatically.</p>
                            </div>
                             <div className="p-4 bg-green-50 rounded-lg">
                                <h4 className="font-semibold text-green-800">Lowers the Barrier to Trust</h4>
                                <p className="text-sm text-green-700">For risk-averse DIB clients, official status removes the initial skepticism of working with a novel, independent provider. It answers "Why should I trust you?".</p>
                            </div>
                        </div>

                        <div className="space-y-4">
                             <h3 className="text-xl font-semibold text-center text-red-700 flex items-center justify-center gap-2"><AlertTriangle /> How RPO Status CHALLENGES the Model</h3>
                             <div className="p-4 bg-red-50 rounded-lg">
                                <h4 className="font-semibold text-red-800">Weakens "Conflict-Free" Messaging</h4>
                                <p className="text-sm text-red-700">Our strongest message is being an unbiased outsider. Becoming an RPO puts us inside the official ecosystem, making us "another consultant" and harder to differentiate.</p>
                            </div>
                            <div className="p-4 bg-red-50 rounded-lg">
                                <h4 className="font-semibold text-red-800">Increases Direct Competition</h4>
                                <p className="text-sm text-red-700">As a "tutor," we have a unique category. As an RPO, we are listed alongside hundreds of other RPOs, forcing us to compete directly on their terms.</p>
                            </div>
                            <div className="p-4 bg-red-50 rounded-lg">
                                <h4 className="font-semibold text-red-800">Blurs Value Proposition</h4>
                                <p className="text-sm text-red-700">The "tutor" model implies a lean, affordable service. The "consultant" (RPO) label can be associated with the high costs we are trying to disrupt.</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>

                <Card className="mb-12">
                    <CardHeader>
                        <CardTitle className="text-2xl">Strategic Analysis: Pros vs. Cons</CardTitle>
                        <CardDescription>A balanced look at how pursuing RPO status would impact our business model.</CardDescription>
                    </CardHeader>
                    <CardContent className="grid md:grid-cols-2 gap-8">
                        {/* Pros */}
                        <div className="space-y-4">
                            <h3 className="text-xl font-semibold text-center text-green-700">Advantages of RPO Status</h3>
                            {prosAndCons.pros.map((pro, index) => (
                                <div key={index} className="flex items-start gap-3">
                                    <pro.icon className="w-5 h-5 text-green-500 mt-1 flex-shrink-0" />
                                    <div>
                                        <h4 className="font-medium">{pro.title}</h4>
                                        <p className="text-sm text-gray-600">{pro.description}</p>
                                    </div>
                                </div>
                            ))}
                        </div>

                        {/* Cons */}
                        <div className="space-y-4">
                            <h3 className="text-xl font-semibold text-center text-red-700">Disadvantages & Strategic Shifts</h3>
                            {prosAndCons.cons.map((con, index) => (
                                <div key={index} className="flex items-start gap-3">
                                    <con.icon className="w-5 h-5 text-red-500 mt-1 flex-shrink-0" />
                                    <div>
                                        <h4 className="font-medium">{con.title}</h4>
                                        <p className="text-sm text-gray-600">{con.description}</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </CardContent>
                </Card>

                <Alert className="mb-12">
                    <Scale className="h-4 w-4" />
                    <AlertTitle className="font-bold text-xl">Verdict & Strategic Recommendation</AlertTitle>
                    <AlertDescription className="mt-2 text-base space-y-2">
                        <p><strong>Verdict:</strong> RPO status is **not essential, but it is a powerful accelerator.** It provides credibility that would otherwise take years to build. The benefits of validation and lead generation outweigh the messaging challenges, provided we manage the narrative carefully.</p>
                        <p><strong>Recommendation:</strong> Pursue RPO status, but frame it as a credential that **validates our superior model**, not a label that defines us. Our marketing message should pivot to: <br/><em>"The best of both worlds: The official credibility of a CMMC Registered Provider Organization with the efficiency and fixed-fee certainty of our AI-powered tutoring model. We are the accredited experts who don't act like traditional consultants."</em></p>
                    </AlertDescription>
                </Alert>

                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                >
                    <Card className="text-center bg-gray-900 text-white">
                        <CardContent className="p-8">
                            <h3 className="text-2xl font-bold mb-4">Next Steps</h3>
                            <p className="text-gray-300 mb-6 max-w-2xl mx-auto">
                                If we proceed, the first step is to designate a team member to become a Registered Practitioner (RP) and begin the RPO application process on The Cyber AB website.
                            </p>
                            <a href="https://cyberab.org/Marketplace" target="_blank" rel="noopener noreferrer">
                                <Button size="lg" variant="secondary">
                                    Visit The Cyber AB Marketplace <ArrowRight className="w-4 h-4 ml-2" />
                                </Button>
                            </a>
                        </CardContent>
                    </Card>
                </motion.div>
            </div>
        </div>
    );
}
