import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Calendar, AlertTriangle, CheckCircle, RefreshCw, Users, HardDrive, FileText, Shield } from 'lucide-react';
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function ContinuousComplianceWorkflow() {
    const [currentMonth] = useState(new Date().getMonth() + 1);
    const [complianceScore, setComplianceScore] = useState(85);
    
    const monthlyTasks = [
        {
            month: 1, title: "Annual SSP Review & Update", 
            description: "Review and update your System Security Plan to reflect any changes in architecture, personnel, or processes from the previous year.",
            priority: "Critical", tools: ["SSP Generator", "Policy Updates"]
        },
        {
            month: 2, title: "Personnel Access Review", 
            description: "Review all user access permissions and update role-based access controls. Document any new hires or departures.",
            priority: "High", tools: ["Access Control Matrix", "Personnel Tracking"]
        },
        {
            month: 3, title: "Incident Response Testing", 
            description: "Conduct tabletop exercises and update incident response procedures based on lessons learned.",
            priority: "High", tools: ["IR Procedures", "Test Documentation"]
        },
        {
            month: 4, title: "Vulnerability Assessment Update", 
            description: "Update vulnerability management processes and document remediation of any identified weaknesses.",
            priority: "High", tools: ["POA&M Generator", "Risk Assessment"]
        },
        {
            month: 5, title: "Training & Awareness Update", 
            description: "Update security awareness training materials and document completion of annual training requirements.",
            priority: "Medium", tools: ["Training Documentation", "Compliance Tracking"]
        },
        {
            month: 6, title: "Mid-Year Compliance Audit", 
            description: "Conduct internal compliance assessment and update evidence packages for all 110 controls.",
            priority: "Critical", tools: ["Evidence Tracker", "SPRS Calculator", "Compliance Report"]
        },
        {
            month: 7, title: "Configuration Management Review", 
            description: "Review and update baseline configurations, change management procedures, and system documentation.",
            priority: "High", tools: ["Configuration Baselines", "Change Documentation"]
        },
        {
            month: 8, title: "Business Continuity Planning", 
            description: "Update backup procedures, disaster recovery plans, and test continuity capabilities.",
            priority: "Medium", tools: ["Continuity Plans", "Recovery Procedures"]
        },
        {
            month: 9, title: "Third-Party Risk Assessment", 
            description: "Review all vendor relationships and update supply chain risk management documentation.",
            priority: "High", tools: ["Vendor Assessment", "Risk Register"]
        },
        {
            month: 10, title: "Physical Security Review", 
            description: "Update physical and environmental protection controls and access control systems.",
            priority: "Medium", tools: ["Physical Security Assessment", "Access Logs"]
        },
        {
            month: 11, title: "Pre-Audit Preparation", 
            description: "Prepare for potential C3PAO assessments and ensure all evidence is current and accessible.",
            priority: "Critical", tools: ["Evidence Package", "Audit Checklist", "Traceability Matrix"]
        },
        {
            month: 12, title: "Annual Compliance Certification", 
            description: "Generate annual compliance report and prepare for next year's compliance planning cycle.",
            priority: "Critical", tools: ["Annual Report", "SPRS Submission", "Planning Documents"]
        }
    ];

    const currentTasks = monthlyTasks.filter(task => task.month === currentMonth);
    const upcomingTasks = monthlyTasks.filter(task => task.month === currentMonth + 1);

    return (
        <div className="max-w-6xl mx-auto p-6 space-y-8">
            <motion.div 
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center"
            >
                <h1 className="text-4xl font-bold text-gray-900 mb-4">Continuous CMMC Compliance Workflow</h1>
                <p className="text-xl text-gray-600 max-w-4xl mx-auto">
                    CMMC compliance is NOT a one-time document package. It's an ongoing accountability stream that must be maintained throughout your entire DoD contract lifecycle.
                </p>
            </motion.div>

            <Alert className="bg-red-50 border-red-200">
                <AlertTriangle className="h-4 w-4 text-red-600" />
                <AlertTitle className="text-red-800 font-bold">Critical Understanding: Ongoing Responsibility</AlertTitle>
                <AlertDescription className="text-red-700 space-y-2">
                    <p><strong>Whether you are a prime contractor or subcontractor, you are continually responsible for:</strong></p>
                    <ul className="list-disc list-inside space-y-1 mt-2">
                        <li>Updating your SSP and policies as systems change</li>
                        <li>Maintaining evidence for all 110 controls throughout contract performance</li>
                        <li>Onboarding new staff with proper CMMC awareness and access controls</li>
                        <li>Updating documentation when deploying new system architecture</li>
                        <li>Monitoring compliance as you deploy and update software</li>
                        <li>Maintaining audit readiness at all times during active DoD contracts</li>
                    </ul>
                </AlertDescription>
            </Alert>

            <div className="grid lg:grid-cols-3 gap-6">
                <Card className="lg:col-span-2">
                    <CardHeader>
                        <CardTitle className="flex items-center gap-3">
                            <Calendar className="w-6 h-6 text-blue-600" />
                            This Month's Compliance Tasks ({new Date().toLocaleString('default', { month: 'long' })})
                        </CardTitle>
                        <CardDescription>
                            Your ongoing CMMC compliance responsibilities for {new Date().getFullYear()}
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                        {currentTasks.map((task, index) => (
                            <motion.div 
                                key={index}
                                initial={{ opacity: 0, x: -20 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ delay: index * 0.1 }}
                                className="border rounded-lg p-4 mb-4"
                            >
                                <div className="flex justify-between items-start mb-2">
                                    <h3 className="font-semibold text-lg">{task.title}</h3>
                                    <Badge className={
                                        task.priority === 'Critical' ? 'bg-red-100 text-red-800' :
                                        task.priority === 'High' ? 'bg-orange-100 text-orange-800' :
                                        'bg-yellow-100 text-yellow-800'
                                    }>
                                        {task.priority}
                                    </Badge>
                                </div>
                                <p className="text-gray-600 mb-3">{task.description}</p>
                                <div className="flex flex-wrap gap-2 mb-3">
                                    {task.tools.map((tool, i) => (
                                        <Badge key={i} variant="outline">{tool}</Badge>
                                    ))}
                                </div>
                                <div className="flex gap-2">
                                    <Button size="sm" asChild>
                                        <Link to={createPageUrl('TraceabilityMatrix')}>Update Documentation</Link>
                                    </Button>
                                    <Button size="sm" variant="outline" asChild>
                                        <Link to={createPageUrl('EvidenceCollectionTracker')}>Collect Evidence</Link>
                                    </Button>
                                </div>
                            </motion.div>
                        ))}
                    </CardContent>
                </Card>

                <div className="space-y-6">
                    <Card>
                        <CardHeader>
                            <CardTitle className="text-center">Compliance Health</CardTitle>
                        </CardHeader>
                        <CardContent className="text-center">
                            <div className="text-4xl font-bold text-green-600 mb-2">{complianceScore}%</div>
                            <Progress value={complianceScore} className="mb-4" />
                            <p className="text-sm text-gray-600">Current compliance posture based on continuous monitoring</p>
                        </CardContent>
                    </Card>

                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <RefreshCw className="w-5 h-5" />
                                Next Month
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            {upcomingTasks.map((task, index) => (
                                <div key={index} className="border-l-2 border-blue-200 pl-4 mb-4">
                                    <h4 className="font-medium">{task.title}</h4>
                                    <p className="text-sm text-gray-600">{task.description}</p>
                                </div>
                            ))}
                        </CardContent>
                    </Card>

                    <Card className="bg-blue-50 border-blue-200">
                        <CardHeader>
                            <CardTitle className="text-blue-800">Why Continuous Compliance?</CardTitle>
                        </CardHeader>
                        <CardContent className="text-blue-700 text-sm space-y-2">
                            <p><strong>False Claims Act Protection:</strong> Static documentation can lead to compliance gaps and potential legal liability.</p>
                            <p><strong>Contract Performance:</strong> Your CMMC obligations continue throughout the entire contract lifecycle.</p>
                            <p><strong>Audit Readiness:</strong> C3PAOs can assess you at any time during contract performance.</p>
                        </CardContent>
                    </Card>
                </div>
            </div>

            <Alert className="bg-green-50 border-green-200">
                <CheckCircle className="h-4 w-4 text-green-600" />
                <AlertTitle className="text-green-800 font-bold">AI-First Continuous Compliance Advantage</AlertTitle>
                <AlertDescription className="text-green-700">
                    Unlike expensive consultants who deliver static documents or GRC software that requires expert management, 
                    our AI-first platform enables you to continuously update your SSP, policies, and compliance documentation 
                    as your business evolves. This ongoing capability keeps you audit-ready at all times while building 
                    internal compliance expertise.
                </AlertDescription>
            </Alert>

            <div className="text-center">
                <Button size="lg" asChild className="mr-4">
                    <Link to={createPageUrl('PartnershipTrial')}>Start Your Continuous Compliance Journey</Link>
                </Button>
                <Button size="lg" variant="outline" asChild>
                    <Link to={createPageUrl('BlogPost')}>Read: Why Static Consulting Fails</Link>
                </Button>
            </div>
        </div>
    );
}