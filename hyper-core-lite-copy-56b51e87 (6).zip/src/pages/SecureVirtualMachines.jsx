
import React, { useState, useEffect } from "react";
import { VMInstance } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Shield, Search, Server } from "lucide-react";
import { motion } from "framer-motion";

import VMControlPanel from "../components/vm/VMControlPanel";
import CreateVMDialog from "../components/vm/CreateVMDialog";

export default function SecureVirtualMachines() {
    const [vms, setVms] = useState([]);
    const [loading, setLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState("");

    useEffect(() => {
        loadVMs();
        
        // Poll for VM status updates every 30 seconds
        const interval = setInterval(loadVMs, 30000);
        return () => clearInterval(interval);
    }, []);

    const loadVMs = async () => {
        try {
            const fetchedVMs = await VMInstance.list('-created_date', 50);
            setVms(fetchedVMs);
        } catch (error) {
            console.error('Failed to load VMs:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleVMCreated = async (vmData) => {
        await VMInstance.create(vmData);
        loadVMs();
    };

    const handleVMUpdate = async (vmId, updates) => {
        await VMInstance.update(vmId, updates);
        loadVMs();
    };

    const filteredVMs = vms.filter(vm =>
        vm.name.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50 p-6">
            <div className="max-w-7xl mx-auto">
                <motion.div
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="flex justify-between items-center mb-8"
                >
                    <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
                        <Server className="w-8 h-8 text-blue-600" />
                        Virtual Machine Manager
                    </h1>
                    <div className="flex gap-3">
                        <CreateVMDialog onVMCreated={handleVMCreated} />
                    </div>
                </motion.div>

                <div className="bg-blue-100 border-l-4 border-blue-500 text-blue-800 p-4 mb-6 rounded-r-lg">
                    <h4 className="font-bold">Strategic Pivot to AWS</h4>
                    <p className="text-sm">This page now serves as a conceptual manager for virtual machines. Our primary strategy is to deploy and manage production VMs using **Amazon EC2** via the AWS Free Tier. The controls below simulate the actions that would be performed via the AWS API.</p>
                </div>

                <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.2 }}
                    className="mb-6"
                >
                    <div className="relative">
                        <Search className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                        <Input
                            placeholder="Search virtual machines..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="pl-10"
                        />
                    </div>
                </motion.div>

                <div className="grid gap-6">
                    {filteredVMs.map((vm, index) => (
                        <motion.div
                            key={vm.id}
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: index * 0.1 }}
                        >
                            <VMControlPanel 
                                vm={vm} 
                                onVMUpdate={handleVMUpdate}
                            />
                        </motion.div>
                    ))}
                </div>

                {filteredVMs.length === 0 && !loading && (
                    <div className="text-center py-12">
                        <Shield className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                        <h3 className="text-lg font-semibold text-gray-600 mb-2">
                            No Virtual Machines Found
                        </h3>
                        <p className="text-gray-500 mb-4">
                            Create your first conceptual VM to model an AWS EC2 instance.
                        </p>
                        <CreateVMDialog onVMCreated={handleVMCreated} />
                    </div>
                )}
            </div>
        </div>
    );
}
