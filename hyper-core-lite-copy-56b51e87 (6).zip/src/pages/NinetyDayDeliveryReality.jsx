
import React, { useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { ArrowRight, Zap, Clock, Shield } from 'lucide-react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const oldPlan = {
    name: "Original 90-Day Plan",
    timeline: "12 Weeks",
    focus: "Comprehensive, manual guidance",
    risk: "Too slow for Nov 10 DFARS deadline"
};

const newPlan = {
    name: "New AI-First Free Beta",
    timeline: "Instant Value",
    focus: "AI-driven analysis & automated documentation",
    advantage: "Meets Nov 10 deadline, zero cost"
};

export default function NinetyDayDeliveryReality() {
    useEffect(() => {
        // SEO Optimization
        document.title = "AI-Accelerated CMMC Certification in 90 Days | HyperCore Cyber";
        document.querySelector('meta[name="description"]')?.setAttribute('content',
            'Discover how our AI-powered platform helps DoD contractors accelerate CMMC certification. Achieve readiness in 90 days with our structured, automated approach.');
    }, []);

    // timelinePhases array was not present in the original code, but if it were, it would be here.
    // For now, it's not needed based on the provided current file code.

    return (
        <div className="bg-gray-50 py-12 md:py-20">
            <div className="container mx-auto px-4">
                <motion.div
                    className="text-center mb-12"
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                >
                    <h1 className="text-4xl md:text-5xl font-extrabold text-gray-900 mb-4">
                        AI-Accelerated CMMC Certification in 90 Days
                    </h1>
                    <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                        Our structured program leverages AI to streamline documentation and implementation, making 90-day CMMC readiness a reality for motivated DoD contractors.
                    </p>
                </motion.div>

                <Alert className="max-w-4xl mx-auto mb-12 bg-blue-50 border-blue-200">
                    <Zap className="h-5 w-5 text-blue-600" />
                    <AlertTitle className="text-blue-800 font-bold">The Market Shifted, So We Did Too.</AlertTitle>
                    <AlertDescription className="text-blue-700">
                        When the DFARS final rule confirmed the November 10, 2025 enforcement date, a 90-day plan was no longer good enough. Our contractors needed a solution that worked <span className="font-bold">now</span>. Our AI breakthrough allowed us to deliver exactly that.
                    </AlertDescription>
                </Alert>

                <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
                    <Card className="opacity-60 bg-gray-100">
                        <CardHeader>
                            <div className="flex items-center gap-3">
                                <Clock className="w-6 h-6 text-gray-500" />
                                <CardTitle className="text-gray-600">The Old Way: 90-Day Plan</CardTitle>
                            </div>
                            <CardDescription>A solid, but ultimately too slow, approach.</CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-3">
                            <p><strong>Timeline:</strong> {oldPlan.timeline}</p>
                            <p><strong>Focus:</strong> {oldPlan.focus}</p>
                            <p className="font-semibold text-red-600"><strong>Critical Flaw:</strong> {oldPlan.risk}</p>
                        </CardContent>
                    </Card>

                    <Card className="ring-2 ring-blue-500 shadow-xl">
                        <CardHeader>
                            <div className="flex items-center gap-3">
                                <Shield className="w-6 h-6 text-blue-600" />
                                <CardTitle>The New Way: AI-First Free Beta</CardTitle>
                            </div>
                            <CardDescription>Delivering compliance readiness, instantly and for free.</CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-3">
                            <p><strong>Timeline:</strong> <span className="font-bold text-green-600">{newPlan.timeline}</span></p>
                            <p><strong>Focus:</strong> {newPlan.focus}</p>
                            <p className="font-semibold text-green-600"><strong>Key Advantage:</strong> {newPlan.advantage}</p>
                        </CardContent>
                    </Card>
                </div>

                <div className="text-center mt-12">
                     <p className="text-lg text-gray-700 mb-6">The AI-First approach isn't just faster—it's smarter. It respects your time and delivers what you need, when you need it.</p>
                     <Button asChild size="lg" className="bg-blue-600 hover:bg-blue-700">
                        <Link to={createPageUrl('ProgramDetails')}>
                            Learn About the Free Beta <ArrowRight className="w-4 h-4 ml-2" />
                        </Link>
                    </Button>
                </div>
            </div>
        </div>
    );
}
