import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, Circle, FileText, Bot, Shield, Users } from 'lucide-react';
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import FeedbackWidget from '../components/support/FeedbackWidget';

const eightWeekPlan = [
    // Week 1: Foundation & Assessment
    {
        title: 'Week 1: Foundation & Assessment',
        tasks: [
            { id: '1-1', title: 'Run Initial AI Gap Analysis', description: 'Upload your existing security documents to establish a compliance baseline.', domain: ['Assessment'], icon: Bot },
            { id: '1-2', title: 'Define System Boundaries', description: 'Clearly define the scope of the system that handles CUI/FCI.', domain: ['Scope'], icon: Shield },
            { id: '1-3', title: 'Identify Key Stakeholders', description: 'List all personnel with compliance responsibilities.', domain: ['Personnel'], icon: Users },
        ],
    },
    // Week 2: Access Control
    {
        title: 'Week 2: Access Control',
        tasks: [
            { id: '2-1', title: 'Generate Access Control Policy', description: 'Use the AI Policy Generator for your AC policy.', domain: ['AC'], icon: FileText },
            { id: '2-2', title: 'Implement Least Privilege', description: 'Review user accounts and ensure access is limited to job function.', domain: ['AC'], icon: Users },
            { id: '2-3', title: 'Enforce Password Complexity', description: 'Configure systems to require strong passwords as per NIST guidelines.', domain: ['AC', 'IA'], icon: Shield },
        ],
    },
    // Week 3: Incident Response
    {
        title: 'Week 3: Incident Response',
        tasks: [
            { id: '3-1', title: 'Generate Incident Response Policy', description: 'Use the AI Policy Generator for your IR policy.', domain: ['IR'], icon: FileText },
            { id: '3-2', title: 'Establish Incident Reporting Channel', description: 'Create a clear process for employees to report suspected incidents.', domain: ['IR'], icon: Users },
            { id: '3-3', title: 'Run a Tabletop IR Drill', description: 'Simulate a security incident to test your response plan.', domain: ['IR'], icon: Bot },
        ],
    },
    // Week 4: System Security & SSP
    {
        title: 'Week 4: System Security & SSP',
        tasks: [
            { id: '4-1', title: 'Generate System Security Plan (SSP)', description: 'Use the SSP Builder to create the initial draft of your SSP.', domain: ['System'], icon: FileText },
            { id: '4-2', title: 'Review System Hardening', description: 'Ensure servers and workstations follow security configuration best practices.', domain: ['CM'], icon: Shield },
            { id: '4-3', title: 'Implement Malware Protection', description: 'Verify that antivirus/antimalware is installed and updated on all systems.', domain: ['SI'], icon: Shield },
        ],
    },
    // Week 5-7: Implement & Document
    {
        title: 'Week 5-7: Implement Remaining Controls',
        tasks: [
            { id: '5-1', title: 'Address Physical Security', description: 'Review and document controls for facility access.', domain: ['PE'], icon: Shield },
            { id: '5-2', title: 'Conduct Security Awareness Training', description: 'Train all employees on their security responsibilities.', domain: ['AT'], icon: Users },
            { id: '5-3', title: 'Implement Media Protection', description: 'Establish procedures for handling and destroying CUI on removable media.', domain: ['MP'], icon: Shield },
            { id: '5-4', title: 'Perform Vulnerability Scans', description: 'Run scans on your network to identify and remediate vulnerabilities.', domain: ['RA'], icon: Bot },
        ],
    },
    // Week 8: Final Review & Reporting
    {
        title: 'Week 8: Final Review & Reporting',
        tasks: [
            { id: '8-1', title: 'Finalize SSP and Policies', description: 'Review and approve all generated and created documentation.', domain: ['Documentation'], icon: FileText },
            { id: '8-2', title: 'Generate Final PDF Report', description: 'Use the Report Generator to create your C3PAO-ready evidence package.', domain: ['Reporting'], icon: FileText },
            { id: '8-3', title: 'Create Plan of Action & Milestones (POA&M)', description: 'Document any remaining gaps and your plan to address them.', domain: ['Assessment'], icon: FileText },
        ],
    },
];

export default function ImplementationPlan() {
    const [planState, setPlanState] = useState(() => {
        try {
            const savedState = localStorage.getItem('cmmcImplementationPlan');
            return savedState ? JSON.parse(savedState) : eightWeekPlan.map(week => ({
                ...week,
                tasks: week.tasks.map(task => ({ ...task, completed: false }))
            }));
        } catch (error) {
            return eightWeekPlan.map(week => ({
                ...week,
                tasks: week.tasks.map(task => ({ ...task, completed: false }))
            }));
        }
    });

    const [progress, setProgress] = useState(0);

    useEffect(() => {
        const totalTasks = planState.reduce((acc, week) => acc + week.tasks.length, 0);
        const completedTasks = planState.reduce((acc, week) => acc + week.tasks.filter(t => t.completed).length, 0);
        setProgress(totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0);
        
        localStorage.setItem('cmmcImplementationPlan', JSON.stringify(planState));
    }, [planState]);

    const handleToggleComplete = (weekIndex, taskIndex) => {
        const newPlanState = [...planState];
        const task = newPlanState[weekIndex].tasks[taskIndex];
        task.completed = !task.completed;
        setPlanState(newPlanState);
        toast.success(task.completed ? "Task marked as complete!" : "Task marked as incomplete.");
    };

    return (
        <div className="min-h-screen bg-gray-50 p-6">
            <div className="max-w-5xl mx-auto">
                <CardHeader className="px-0 text-center mb-6">
                    <CardTitle className="text-3xl font-bold">Your 8-Week CMMC Implementation Plan</CardTitle>
                    <CardDescription className="text-lg">Follow this structured plan to get audit-ready by the deadline.</CardDescription>
                </CardHeader>

                <Card className="mb-8">
                    <CardContent className="pt-6">
                        <div className="flex items-center gap-4">
                            <span className="font-bold text-lg">{Math.round(progress)}% Complete</span>
                            <Progress value={progress} className="flex-1" />
                        </div>
                    </CardContent>
                </Card>

                <Tabs defaultValue="week-0" className="w-full">
                    <TabsList className="grid w-full grid-cols-3 md:grid-cols-6">
                        {planState.map((week, index) => (
                            <TabsTrigger key={index} value={`week-${index}`}>Week {index + (index < 4 ? 1 : `${index+1}-${index+3}`.includes('7')? '5-7': index+1)}</TabsTrigger>
                        ))}
                    </TabsList>

                    {planState.map((week, weekIndex) => (
                        <TabsContent key={weekIndex} value={`week-${weekIndex}`}>
                            <Card>
                                <CardHeader>
                                    <CardTitle>{week.title}</CardTitle>
                                </CardHeader>
                                <CardContent className="space-y-4">
                                    {week.tasks.map((task, taskIndex) => (
                                        <div
                                            key={task.id}
                                            className={cn(
                                                "flex items-center justify-between p-4 rounded-lg border transition-all",
                                                task.completed ? "bg-green-50 border-green-200" : "bg-white"
                                            )}
                                        >
                                            <div className="flex items-start gap-4">
                                                <task.icon className={cn("w-6 h-6 mt-1 flex-shrink-0", task.completed ? "text-green-600" : "text-gray-500")} />
                                                <div>
                                                    <h4 className={cn("font-semibold", task.completed && "line-through text-gray-500")}>{task.title}</h4>
                                                    <p className="text-sm text-gray-600">{task.description}</p>
                                                    <div className="mt-2">
                                                        <Badge variant="outline">{task.domain.join(', ')}</Badge>
                                                    </div>
                                                </div>
                                            </div>
                                            <Button
                                                variant={task.completed ? "outline" : "secondary"}
                                                size="sm"
                                                onClick={() => handleToggleComplete(weekIndex, taskIndex)}
                                                className="ml-4 flex-shrink-0"
                                            >
                                                {task.completed ? <CheckCircle className="w-4 h-4 mr-2" /> : <Circle className="w-4 h-4 mr-2" />}
                                                {task.completed ? "Completed" : "Mark Complete"}
                                            </Button>
                                        </div>
                                    ))}
                                </CardContent>
                            </Card>
                        </TabsContent>
                    ))}
                </Tabs>
            </div>
            <FeedbackWidget />
        </div>
    );
}