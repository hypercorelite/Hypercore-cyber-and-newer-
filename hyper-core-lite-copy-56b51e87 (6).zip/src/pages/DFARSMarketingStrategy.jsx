import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CheckCircle, Target, TrendingUp, DollarSign, Users, Calendar, Rocket, Zap } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";

const marketingTactics = [
    {
        id: 1,
        title: "AI-Accelerated DFARS Lifeline ABM Campaigns",
        description: "Personalized outreach to NoVA primes using predictive DFARS gap modeling",
        budget: "$5,000/month",
        timeline: "Q4 2025 - Ongoing",
        expectedImpact: "25% lead uplift, 40% higher MQL-to-SQL conversion",
        priority: "High",
        status: "Ready to Launch",
        channels: ["LinkedIn Sales Navigator", "ZoomInfo", "Personalized demos"],
        kpis: ["MQL conversion rate", "Demo booking rate", "Pipeline velocity"]
    },
    {
        id: 2, 
        title: "Free DFARS Risk Calculator Lead Magnets",
        description: "Interactive calculators scoring DFARS readiness with personalized recommendations",
        budget: "$2,000 setup + $1,000/month promotion",
        timeline: "October 2025",
        expectedImpact: "15-20% visitor-to-trial conversion",
        priority: "High",
        status: "Development Required",
        channels: ["Website integration", "LinkedIn ads", "Email nurturing"],
        kpis: ["Calculator completions", "Email captures", "Trial conversions"]
    },
    {
        id: 3,
        title: "DFARS vs. CMMC Content Cluster SEO",
        description: "Pillar content strategy targeting long-tail DFARS compliance searches",
        budget: "$3,000/month (content + promotion)",
        timeline: "November 2025 - Q1 2026", 
        expectedImpact: "Top-3 SERP rankings, 20% organic traffic boost",
        priority: "Medium",
        status: "Content Planning",
        channels: ["Knowledge Hub", "Guest posts", "Schema markup"],
        kpis: ["SERP rankings", "Organic traffic", "Backlink acquisition"]
    },
    {
        id: 4,
        title: "NoVA DFARS Survival Webinar Series",
        description: "Quarterly webinars with local RPO partners showcasing AI tools",
        budget: "$2,500/event (4x/year)",
        timeline: "Q4 2025 - 2026",
        expectedImpact: "50-100 attendees/event, 30% demo booking rate",
        priority: "High",
        status: "Partner Outreach",
        channels: ["Zoom webinars", "LinkedIn promotion", "Partner networks"],
        kpis: ["Attendance rate", "Demo bookings", "Partner engagement"]
    },
    {
        id: 5,
        title: "DFARS Penalty Avoidance PPC + Competitor Conquesting",
        description: "Strategic Google Ads targeting competitor keywords and compliance pain points",
        budget: "$3,000/month",
        timeline: "October 2025 - Ongoing",
        expectedImpact: "15% CTR, 10-15% conversion to trials",
        priority: "Medium", 
        status: "Campaign Setup",
        channels: ["Google Ads", "Landing page optimization", "Competitor analysis"],
        kpis: ["CTR", "Cost per lead", "Trial conversion rate"]
    },
    {
        id: 6,
        title: "LinkedIn DFARS FCA Case Study Thought Leadership",
        description: "Weekly LinkedIn content using real FCA cases to showcase AI prevention",
        budget: "$500/month boosting + content creation",
        timeline: "Ongoing",
        expectedImpact: "5K+ impressions/post, 20% engagement rate",
        priority: "Medium",
        status: "Content Calendar Ready",
        channels: ["LinkedIn organic + paid", "Infographics", "Video content"],
        kpis: ["Engagement rate", "Connection requests", "Brand mentions"]
    },
    {
        id: 7,
        title: "AI-DFARS Innovation Press Release Campaign",
        description: "Strategic PR highlighting DFARS compliance achievements and innovations",
        budget: "$1,000/release (4x/year)",
        timeline: "Q4 2025 - 2026",
        expectedImpact: "10+ backlinks per release, 15% traffic spike",
        priority: "Low",
        status: "PR Calendar Planning",
        channels: ["PR Newswire", "CyberNewsWire", "Federal Register feeds"],
        kpis: ["Media pickup", "Backlink acquisition", "Website traffic"]
    },
    {
        id: 8,
        title: "Interactive DFARS Gap Analyzer Demo",
        description: "Live demo tool allowing contract upload for instant AI analysis",
        budget: "$5,000 development + $1,000/month promotion",
        timeline: "November 2025",
        expectedImpact: "25% visitor-to-lead conversion, viral sharing potential",
        priority: "High",
        status: "Technical Specification",
        channels: ["Website integration", "Reddit promotion", "Stack Overflow"],
        kpis: ["Demo completions", "Lead generation", "Social shares"]
    }
];

const competitorComparison = [
    {
        aspect: "Differentiation",
        hypercore: "AI predictive modeling for DFARS gaps",
        competitors: "Generic templates/encryption focus (PreVeil/Exostar)",
        edge: "50% cost savings + proactive alerts"
    },
    {
        aspect: "Channel Focus", 
        hypercore: "ABM + NoVA webinars",
        competitors: "Broad emails/DIB ads",
        edge: "40% higher personalization ROI"
    },
    {
        aspect: "Content Type",
        hypercore: "Interactive calculators/case studies", 
        competitors: "Static guides",
        edge: "30% better engagement"
    },
    {
        aspect: "Budget Efficiency",
        hypercore: "$5-10K/month (PPC/ABM)",
        competitors: "$15K+ on broad awareness",
        edge: "SMB-affordable scaling"
    }
];

const rolloutPlan = [
    {
        phase: "Q4 2025 - Foundation",
        weeks: "Weeks 1-4",
        tactics: ["Launch ABM campaigns", "Deploy risk calculator", "Begin webinar planning"],
        budget: "$15,000",
        expectedResults: ["100+ qualified leads", "20% demo booking rate", "Partner agreements"]
    },
    {
        phase: "Q1 2026 - Scale",
        weeks: "Weeks 5-16", 
        tactics: ["Content cluster launch", "PPC campaign optimization", "First webinar execution"],
        budget: "$35,000",
        expectedResults: ["Top-3 SERP rankings", "200+ trial sign-ups", "50+ webinar attendees"]
    },
    {
        phase: "Q2 2026 - Optimize",
        weeks: "Weeks 17-28",
        tactics: ["PR campaign launch", "Interactive demo deployment", "LinkedIn amplification"],
        budget: "$25,000",
        expectedResults: ["National media coverage", "500+ demo interactions", "Industry recognition"]
    }
];

export default function DFARSMarketingStrategy() {
    const [selectedTab, setSelectedTab] = useState("tactics");

    const totalBudget = marketingTactics.reduce((sum, tactic) => {
        const monthlyBudget = parseInt(tactic.budget.replace(/[^0-9]/g, ''));
        return sum + monthlyBudget;
    }, 0);

    return (
        <div className="space-y-8">
            <BreadcrumbNav currentPageName="DFARS Marketing Strategy" />
            
            <div className="text-center">
                <h1 className="text-4xl font-bold text-gray-900">🚀 DFARS Marketing Strategy 2025</h1>
                <p className="text-xl text-gray-600 max-w-4xl mx-auto mt-4">
                    Comprehensive marketing plan to outpace competitors and dominate the NoVA DFARS compliance market
                </p>
            </div>

            <Alert className="bg-blue-50 border-blue-200">
                <Rocket className="h-4 w-4 text-blue-600" />
                <AlertTitle className="text-blue-800">Strategic Advantage</AlertTitle>
                <AlertDescription className="text-blue-700">
                    While competitors like PreVeil and Exostar focus on generic templates, <strong>your AI-first DFARS suite</strong> offers predictive gap modeling and contract intelligence—positioning you as the innovation leader in the $1.2B DIB compliance market.
                </AlertDescription>
            </Alert>

            <Tabs defaultValue="tactics" className="w-full">
                <TabsList className="grid w-full grid-cols-4">
                    <TabsTrigger value="tactics">Marketing Tactics</TabsTrigger>
                    <TabsTrigger value="comparison">Competitive Edge</TabsTrigger>
                    <TabsTrigger value="rollout">Rollout Plan</TabsTrigger>
                    <TabsTrigger value="budget">Budget & ROI</TabsTrigger>
                </TabsList>

                <TabsContent value="tactics" className="space-y-6">
                    <div className="grid gap-6">
                        {marketingTactics.map((tactic) => (
                            <Card key={tactic.id} className="border-l-4 border-l-blue-500">
                                <CardHeader>
                                    <div className="flex justify-between items-start">
                                        <div>
                                            <CardTitle className="flex items-center gap-3">
                                                <Target className="w-5 h-5 text-blue-600" />
                                                {tactic.title}
                                            </CardTitle>
                                            <CardDescription className="mt-2">{tactic.description}</CardDescription>
                                        </div>
                                        <div className="text-right space-y-2">
                                            <Badge className={`${tactic.priority === 'High' ? 'bg-red-100 text-red-800' : 
                                                tactic.priority === 'Medium' ? 'bg-yellow-100 text-yellow-800' : 
                                                'bg-green-100 text-green-800'}`}>
                                                {tactic.priority} Priority
                                            </Badge>
                                            <Badge variant="outline">{tactic.status}</Badge>
                                        </div>
                                    </div>
                                </CardHeader>
                                <CardContent>
                                    <div className="grid md:grid-cols-3 gap-4 mb-4">
                                        <div>
                                            <span className="font-semibold text-sm">Budget:</span>
                                            <p className="text-green-600 font-bold">{tactic.budget}</p>
                                        </div>
                                        <div>
                                            <span className="font-semibold text-sm">Timeline:</span>
                                            <p className="text-blue-600">{tactic.timeline}</p>
                                        </div>
                                        <div>
                                            <span className="font-semibold text-sm">Expected Impact:</span>
                                            <p className="text-purple-600">{tactic.expectedImpact}</p>
                                        </div>
                                    </div>
                                    <div className="grid md:grid-cols-2 gap-4">
                                        <div>
                                            <span className="font-semibold text-sm">Channels:</span>
                                            <div className="flex flex-wrap gap-1 mt-1">
                                                {tactic.channels.map((channel, index) => (
                                                    <Badge key={index} variant="secondary" className="text-xs">
                                                        {channel}
                                                    </Badge>
                                                ))}
                                            </div>
                                        </div>
                                        <div>
                                            <span className="font-semibold text-sm">Key KPIs:</span>
                                            <div className="flex flex-wrap gap-1 mt-1">
                                                {tactic.kpis.map((kpi, index) => (
                                                    <Badge key={index} variant="outline" className="text-xs">
                                                        {kpi}
                                                    </Badge>
                                                ))}
                                            </div>
                                        </div>
                                    </div>
                                </CardContent>
                            </Card>
                        ))}
                    </div>
                </TabsContent>

                <TabsContent value="comparison" className="space-y-6">
                    <Card>
                        <CardHeader>
                            <CardTitle>HyperCore vs. Competitors Marketing Comparison</CardTitle>
                            <CardDescription>How your marketing strategy outpaces PreVeil, Exostar, and other DFARS tools</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <Table>
                                <TableHeader>
                                    <TableRow>
                                        <TableHead>Aspect</TableHead>
                                        <TableHead>HyperCore Strategy</TableHead>
                                        <TableHead>Competitor Approach</TableHead>
                                        <TableHead>Your Advantage</TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {competitorComparison.map((comp, index) => (
                                        <TableRow key={index}>
                                            <TableCell className="font-semibold">{comp.aspect}</TableCell>
                                            <TableCell className="text-blue-700">{comp.hypercore}</TableCell>
                                            <TableCell className="text-gray-600">{comp.competitors}</TableCell>
                                            <TableCell>
                                                <Badge className="bg-green-100 text-green-800">
                                                    {comp.edge}
                                                </Badge>
                                            </TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="rollout" className="space-y-6">
                    {rolloutPlan.map((phase, index) => (
                        <Card key={index}>
                            <CardHeader>
                                <CardTitle className="flex items-center gap-3">
                                    <Calendar className="w-5 h-5 text-purple-600" />
                                    {phase.phase}
                                </CardTitle>
                                <CardDescription>{phase.weeks}</CardDescription>
                            </CardHeader>
                            <CardContent>
                                <div className="grid md:grid-cols-3 gap-6">
                                    <div>
                                        <h4 className="font-semibold mb-2">Key Tactics</h4>
                                        <ul className="space-y-1">
                                            {phase.tactics.map((tactic, i) => (
                                                <li key={i} className="flex items-center gap-2 text-sm">
                                                    <CheckCircle className="w-3 h-3 text-green-600" />
                                                    {tactic}
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                                    <div>
                                        <h4 className="font-semibold mb-2">Budget</h4>
                                        <p className="text-2xl font-bold text-green-600">{phase.budget}</p>
                                    </div>
                                    <div>
                                        <h4 className="font-semibold mb-2">Expected Results</h4>
                                        <ul className="space-y-1">
                                            {phase.expectedResults.map((result, i) => (
                                                <li key={i} className="text-sm text-purple-600">• {result}</li>
                                            ))}
                                        </ul>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    ))}
                </TabsContent>

                <TabsContent value="budget" className="space-y-6">
                    <div className="grid md:grid-cols-3 gap-6 mb-8">
                        <Card className="text-center">
                            <CardHeader>
                                <CardTitle className="flex items-center justify-center gap-2">
                                    <DollarSign className="w-5 h-5 text-green-600" />
                                    Total Monthly Budget
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <p className="text-3xl font-bold text-green-600">${totalBudget.toLocaleString()}</p>
                                <p className="text-sm text-gray-600">50% below competitor spend</p>
                            </CardContent>
                        </Card>
                        
                        <Card className="text-center">
                            <CardHeader>
                                <CardTitle className="flex items-center justify-center gap-2">
                                    <TrendingUp className="w-5 h-5 text-blue-600" />
                                    Expected ROI
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <p className="text-3xl font-bold text-blue-600">300%</p>
                                <p className="text-sm text-gray-600">Within 6 months</p>
                            </CardContent>
                        </Card>

                        <Card className="text-center">
                            <CardHeader>
                                <CardTitle className="flex items-center justify-center gap-2">
                                    <Users className="w-5 h-5 text-purple-600" />
                                    Lead Growth Target
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <p className="text-3xl font-bold text-purple-600">25%</p>
                                <p className="text-sm text-gray-600">Month-over-month</p>
                            </CardContent>
                        </Card>
                    </div>

                    <Alert className="bg-green-50 border-green-200">
                        <CheckCircle className="h-4 w-4 text-green-600" />
                        <AlertTitle className="text-green-800">Budget Efficiency Strategy</AlertTitle>
                        <AlertDescription className="text-green-700">
                            Your $15K/month marketing budget delivers <strong>40% better ROI than competitors</strong> through AI-personalized targeting and NoVA market specialization, while competitors spend $25K+ on broad awareness campaigns.
                        </AlertDescription>
                    </Alert>

                    <Card>
                        <CardHeader>
                            <CardTitle>Next Steps: Implementation Priority</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div className="flex items-center gap-4 p-4 bg-red-50 rounded-lg border border-red-200">
                                <Badge className="bg-red-100 text-red-800">Week 1</Badge>
                                <div>
                                    <h4 className="font-semibold">Launch ABM Campaign & Risk Calculator</h4>
                                    <p className="text-sm text-gray-600">Immediate lead generation focus</p>
                                </div>
                                <Button asChild size="sm" className="ml-auto">
                                    <Link to={createPageUrl('PartnershipOutreachCenter')}>Start ABM Setup</Link>
                                </Button>
                            </div>
                            
                            <div className="flex items-center gap-4 p-4 bg-yellow-50 rounded-lg border border-yellow-200">
                                <Badge className="bg-yellow-100 text-yellow-800">Week 2</Badge>
                                <div>
                                    <h4 className="font-semibold">NoVA Partner Webinar Planning</h4>
                                    <p className="text-sm text-gray-600">Secure PreVeil/Core-CSI partnerships</p>
                                </div>
                                <Button asChild size="sm" variant="outline" className="ml-auto">
                                    <Link to={createPageUrl('StrategicPartnershipDashboard')}>View Partners</Link>
                                </Button>
                            </div>
                            
                            <div className="flex items-center gap-4 p-4 bg-blue-50 rounded-lg border border-blue-200">
                                <Badge className="bg-blue-100 text-blue-800">Week 3</Badge>
                                <div>
                                    <h4 className="font-semibold">Content Cluster & PPC Launch</h4>
                                    <p className="text-sm text-gray-600">SEO foundation and paid acquisition</p>
                                </div>
                                <Button asChild size="sm" variant="outline" className="ml-auto">
                                    <Link to={createPageUrl('SEOActionPlan')}>View SEO Plan</Link>
                                </Button>
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>
            </Tabs>
        </div>
    );
}