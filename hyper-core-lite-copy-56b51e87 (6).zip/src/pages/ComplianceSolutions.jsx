
import React, { useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { ShieldCheck, ArrowRight, DollarSign, Clock, UserCheck, Check, Target, Zap } from 'lucide-react';
import { motion } from 'framer-motion';
import DisclaimerBanner from '../components/legal/DisclaimerBanner';
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { CheckCircle } from 'lucide-react';

export default function ComplianceSolutions() {
    useEffect(() => {
        // SEO Optimization for Government & CMMC Compliance
        document.title = "Free AI CMMC Compliance Solutions for Government Contractors | HyperCore";
        document.querySelector('meta[name="description"]')?.setAttribute('content', 
            'Free to try until December 5th! Automate your CMMC Level 2 compliance with our AI-powered solutions. Gap analysis, SSP generation, and policy creation for DoD & government contractors.');
    }, []);

    const freeSolutions = [
        {
            icon: Target,
            title: "Free to Try: AI Gap Analysis",
            description: "Complete assessment against all 110 NIST 800-171 controls with detailed compliance scoring. Free to try until December 5th.",
            features: ["110 Control Assessment", "Compliance Gap Report", "Priority Risk Analysis", "Implementation Roadmap"]
        },
        {
            icon: ShieldCheck,
            title: "Free to Try: System Security Plan Generator",
            description: "AI-powered SSP creation tailored to your organization's specific systems and processes. Free to try until December 5th.",
            features: ["Custom SSP Generation", "NIST Compliance Mapping", "Evidence Templates", "C3PAO Ready Format"]
        },
        {
            icon: Check,
            title: "Free to Try: 14 Policy Documents",
            description: "Complete set of CMMC Level 2 required policies, customized for your organization. Free to try until December 5th.",
            features: ["Access Control Policy", "Incident Response Policy", "Risk Assessment Policy", "11 Additional Policies"]
        },
        {
            icon: Clock,
            title: "Free to Try: 90-Day Implementation Plan",
            description: "Structured timeline with tasks, milestones, and deliverables to achieve CMMC readiness. Free to try until December 5th.",
            features: ["Week-by-Week Tasks", "Resource Allocation", "Milestone Tracking", "Progress Monitoring"]
        },
        {
            icon: Zap,
            title: "Free to Try: Evidence Collection Templates",
            description: "Pre-built templates to gather and organize evidence for each CMMC control requirement. Free to try until December 5th.",
            features: ["Control Evidence Maps", "Documentation Templates", "Audit Trail Formats", "C3PAO Preparation"]
        },
        {
            icon: UserCheck,
            title: "Free to Try: AI-Powered Support",
            description: "Instant AI assistance for CMMC questions, plus email escalation for complex issues during your free trial period ending December 5th.",
            features: ["24/7 AI Chat Support", "CMMC Knowledge Base", "Email Escalation Available", "Implementation Q&A"]
        }
    ];

    return (
        <div className="bg-white">
            <div className="container mx-auto px-4 py-16">
                 <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-12">
                    <Badge className="mb-6 bg-green-100 text-green-800 px-6 py-3 text-xl font-bold">
                        FREE TO TRY UNTIL DECEMBER 5TH, 2025
                    </Badge>
                    <h1 className="text-4xl md:text-5xl font-extrabold text-gray-900 mb-4">
                        Free AI Tools for CMMC 2025 Readiness
                    </h1>
                    <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                        Leverage our CMMC automation software to simplify every step of your compliance journey. <strong>Free to try until December 5th, 2025.</strong>
                    </p>
                </motion.div>

                <Alert className="max-w-4xl mx-auto mb-12 bg-green-50 border-green-200">
                    <CheckCircle className="h-5 w-5 text-green-600" />
                    <AlertTitle className="text-green-800 font-bold">All Solutions Free to Try Until December 5th</AlertTitle>
                    <AlertDescription className="text-green-700">
                        Get full access to every tool listed below at no cost until December 5th, 2025. No credit card required, no hidden fees during the free trial period.
                    </AlertDescription>
                </Alert>

                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {freeSolutions.map((solution, index) => (
                        <motion.div
                            key={index}
                            initial={{ opacity: 0, y: 20 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                            transition={{ delay: index * 0.1 }}
                        >
                            <Card className="h-full hover:shadow-lg transition-shadow border-2 border-green-200 bg-green-50">
                                <CardHeader>
                                    <div className="bg-blue-100 text-blue-600 rounded-lg w-12 h-12 flex items-center justify-center mb-4">
                                        <solution.icon className="w-6 h-6" />
                                    </div>
                                    <CardTitle className="text-green-800">{solution.title}</CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <p className="text-gray-700 mb-4">{solution.description}</p>
                                    <ul className="space-y-2">
                                        {solution.features.map((feature, featureIndex) => (
                                            <li key={featureIndex} className="flex items-center text-sm text-gray-600">
                                                <CheckCircle className="w-4 h-4 text-green-600 mr-2" />
                                                {feature}
                                            </li>
                                        ))}
                                    </ul>
                                </CardContent>
                            </Card>
                        </motion.div>
                    ))}
                </div>

                 <motion.div 
                    className="mt-16"
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                >
                    <Card className="bg-blue-50 border-blue-200 max-w-4xl mx-auto">
                        <CardHeader>
                            <CardTitle className="text-2xl text-blue-800">Why an AI-First Approach Wins</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="text-blue-700 mb-6">
                                Each solution above is powered by our core AI engine to solve the biggest compliance challenges: high costs, long timelines, and lack of expertise. By automating the documentation and planning, we empower your team to focus on implementation, saving you an average of <strong>$50,000 - $200,000</strong> and <strong>9-12 months</strong> of work.
                            </p>
                            <div className="flex flex-col sm:flex-row gap-4 justify-center">
                                <Button asChild size="lg" className="bg-blue-600 hover:bg-blue-700">
                                    <Link to={createPageUrl('PartnershipTrial')}>
                                        Start Free Trial Now <ArrowRight className="w-4 h-4 ml-2" />
                                    </Link>
                                </Button>
                            </div>
                        </CardContent>
                    </Card>
                </motion.div>
            </div>
            
            <div className="py-12 bg-gray-50">
                <div className="container mx-auto px-4">
                    <DisclaimerBanner />
                </div>
            </div>
        </div>
    );
}
