import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { CheckCircle, FileText, Bot, PlayCircle, Loader2 } from 'lucide-react';
import { toast } from "sonner";
import BreadcrumbNav from '../components/navigation/BreadcrumbNav';

const mockAssessmentResult = {
    overallScore: 85,
    compliantControls: 93,
    nonCompliantControls: 17,
    criticalGaps: [
        "AC.L2-3.1.3: CUI is not consistently separated from non-CUI networks.",
        "IR.L2-3.6.1: Incident response plan is not regularly tested.",
        "RA.L2-3.11.2: Vulnerability scans are performed ad-hoc, not periodically.",
    ],
};

export default function MockCMMCAssessment() {
    const [subcontractorName, setSubcontractorName] = useState('Sample Defense Systems, Inc.');
    const [assessmentStatus, setAssessmentStatus] = useState('ready');
    const [results, setResults] = useState(null);

    const runAssessment = () => {
        if (!subcontractorName) {
            toast.error("Please enter a subcontractor name.");
            return;
        }
        setAssessmentStatus('running');
        toast.info(`Running mock CMMC assessment for ${subcontractorName}...`);
        setTimeout(() => {
            setResults(mockAssessmentResult);
            setAssessmentStatus('completed');
            toast.success("Mock assessment complete.");
        }, 3000);
    };

    return (
        <div className="space-y-6">
            <BreadcrumbNav currentPageName="MockCMMCAssessment" />
            <CardHeader className="px-0">
                <CardTitle className="text-3xl font-bold flex items-center gap-3">
                    <Bot className="w-8 h-8 text-blue-600" />
                    Live CMMC Assessment Demo
                </CardTitle>
                <CardDescription>
                    Demonstrate the core value of your AI by running a simulated CMMC Level 2 assessment on a mock subcontractor. This shows primes exactly what they get.
                </CardDescription>
            </CardHeader>

            <Card>
                <CardHeader>
                    <CardTitle>1. Define Target</CardTitle>
                    <CardDescription>Enter the name of the mock subcontractor to assess.</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="flex gap-4">
                        <Input 
                            value={subcontractorName}
                            onChange={(e) => setSubcontractorName(e.target.value)}
                            placeholder="e.g., Sample Defense Systems, Inc."
                        />
                        <Button onClick={runAssessment} disabled={assessmentStatus === 'running'}>
                             {assessmentStatus === 'running' ? (
                                <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Assessing...</>
                            ) : (
                                <><PlayCircle className="w-4 h-4 mr-2" /> Run Assessment</>
                            )}
                        </Button>
                    </div>
                </CardContent>
            </Card>

            {results && (
                <Card>
                    <CardHeader>
                        <CardTitle>2. View Results for "{subcontractorName}"</CardTitle>
                        <CardDescription>AI-generated compliance summary.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div className="grid md:grid-cols-3 gap-4 text-center">
                            <div className="p-4 bg-blue-50 rounded-lg">
                                <p className="text-4xl font-bold text-blue-700">{results.overallScore}/110</p>
                                <p className="text-sm font-medium text-blue-600">SPRS Score</p>
                            </div>
                            <div className="p-4 bg-green-50 rounded-lg">
                                <p className="text-4xl font-bold text-green-700">{results.compliantControls}</p>
                                <p className="text-sm font-medium text-green-600">Compliant Controls</p>
                            </div>
                            <div className="p-4 bg-red-50 rounded-lg">
                                <p className="text-4xl font-bold text-red-700">{results.nonCompliantControls}</p>
                                <p className="text-sm font-medium text-red-600">Non-Compliant Controls</p>
                            </div>
                        </div>
                        <Alert variant="destructive">
                            <AlertTitle className="font-bold">Critical Compliance Gaps Identified</AlertTitle>
                            <AlertDescription>
                                <ul className="list-disc pl-5 mt-2">
                                    {results.criticalGaps.map((gap, i) => <li key={i}>{gap}</li>)}
                                </ul>
                            </AlertDescription>
                        </Alert>
                         <Button size="lg" className="w-full">
                            <FileText className="w-5 h-5 mr-2" />
                            Download Full PDF Assessment Report (SSP & POA&M)
                        </Button>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}