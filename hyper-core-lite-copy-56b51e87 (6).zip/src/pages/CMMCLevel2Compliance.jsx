import React, { useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { ArrowRight, Check, Shield, FileText, Bot } from 'lucide-react';
import DisclaimerBanner from '../components/legal/DisclaimerBanner';

const complianceDomains = [
    { name: "Access Control (AC)", controls: 22 },
    { name: "Awareness & Training (AT)", controls: 3 },
    { name: "Audit & Accountability (AU)", controls: 9 },
    { name: "Configuration Management (CM)", controls: 9 },
    { name: "Identification & Authentication (IA)", controls: 11 },
    { name: "Incident Response (IR)", controls: 3 },
    { name: "Maintenance (MA)", controls: 6 },
    { name: "Media Protection (MP)", controls: 8 },
    { name: "Personnel Security (PS)", controls: 2 },
    { name: "Physical Protection (PE)", controls: 6 },
    { name: "Risk Assessment (RA)", controls: 3 },
    { name: "Security Assessment (CA)", controls: 3 },
    { name: "System & Communications Protection (SC)", controls: 16 },
    { name: "System & Information Integrity (SI)", controls: 9 },
];

export default function CMMCLevel2Compliance() {
    useEffect(() => {
        document.title = "CMMC Level 2 Compliance Checklist & Guide (2025) | HyperCore";
        document.querySelector('meta[name="description"]')?.setAttribute('content', 
            "Your complete guide to CMMC Level 2 compliance. Understand the 110 controls from NIST 800-171 and use our AI tools to generate your required documentation.");
    }, []);

    return (
        <div className="bg-white">
            <section className="py-20 bg-gray-50">
                <div className="container mx-auto px-4 text-center">
                    <Shield className="w-16 h-16 text-blue-600 mx-auto mb-6" />
                    <h1 className="text-4xl md:text-5xl font-extrabold text-gray-900 mb-4">CMMC 2.0 Level 2 Compliance Guide</h1>
                    <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                        Your definitive resource for understanding the 110 controls required for CMMC Level 2, aligned with NIST SP 800-171.
                    </p>
                </div>
            </section>

            <section className="py-20">
                <div className="container mx-auto px-4 max-w-5xl">
                    <Card className="mb-12 bg-blue-50 border-blue-200">
                        <CardHeader>
                            <CardTitle className="text-2xl text-blue-800">What is CMMC Level 2?</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="text-gray-700 space-y-4">
                                CMMC Level 2 (Advanced) is designed for companies that handle Controlled Unclassified Information (CUI). It requires compliance with the **110 security controls** outlined in NIST SP 800-171. Achieving Level 2 is mandatory for most DoD contractors who process, store, or transmit CUI. The DFARS final rule mandates compliance for relevant contracts starting November 10, 2025.
                            </p>
                        </CardContent>
                    </Card>

                    <div className="text-center mb-12">
                        <h2 className="text-3xl font-bold text-gray-900">The 14 Control Families of CMMC Level 2</h2>
                        <p className="text-lg text-gray-600 mt-2">These families encompass all 110 controls you need to implement.</p>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                        {complianceDomains.map(domain => (
                            <Card key={domain.name} className="hover:shadow-md transition-shadow">
                                <CardContent className="p-6">
                                    <h3 className="font-bold text-gray-800">{domain.name}</h3>
                                    <p className="text-sm text-gray-600">{domain.controls} Controls</p>
                                </CardContent>
                            </Card>
                        ))}
                    </div>

                    <div className="mt-20 text-center">
                        <Card className="bg-gradient-to-r from-blue-600 to-indigo-700 text-white p-8">
                            <Bot className="w-12 h-12 mx-auto mb-4" />
                            <h2 className="text-3xl font-bold mb-4">Ready to Automate Your Compliance?</h2>
                            <p className="text-blue-100 max-w-2xl mx-auto mb-6">
                                Stop struggling with spreadsheets. Our AI can generate your System Security Plan (SSP), all required policies, and a detailed gap analysis report against these 110 controls in minutes.
                            </p>
                            <Button asChild size="lg" variant="secondary" className="bg-white text-blue-700 hover:bg-gray-100">
                                <Link to={createPageUrl('PartnershipTrial')}>
                                    Generate Your Compliance PDFs Now <ArrowRight className="w-4 h-4 ml-2" />
                                </Link>
                            </Button>
                        </Card>
                    </div>
                </div>
            </section>
            
            <div className="py-12 bg-gray-50">
                <div className="container mx-auto px-4">
                    <DisclaimerBanner />
                </div>
            </div>
        </div>
    );
}