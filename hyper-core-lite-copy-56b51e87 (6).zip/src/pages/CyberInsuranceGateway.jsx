
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
    CheckCircle,
    ExternalLink,
    Shield,
    ScanSearch, // New import
    Award,        // New import
    FileText,     // New import
    Megaphone     // New import
} from 'lucide-react';
import { motion } from "framer-motion";

const MINIMUM_VIABLE_PACKAGE = [
    {
        name: "General Liability Insurance",
        coverage: "$1,000,000",
        purpose: "Protects against basic business risks like property damage or client injury. Required by most commercial leases and contracts.",
        cost: "~$40-80 / month",
        provider: {
            name: "The Hartford",
            link: "https://www.thehartford.com/business-insurance/general-liability"
        }
    },
    {
        name: "Professional Liability (E&O)",
        coverage: "$1,000,000",
        purpose: "CRITICAL. Covers you if your software or advice causes a client financial loss due to errors or failure to perform.",
        cost: "~$50-100 / month",
        provider: {
            name: "Hiscox",
            link: "https://www.hiscox.com/small-business-insurance/professional-liability-insurance"
        }
    },
    {
        name: "Cyber Liability Insurance (Basic)",
        coverage: "$250,000",
        purpose: "Essential for credibility. Covers data breach costs, legal fees, and recovery. Shows you practice what you preach.",
        cost: "~$100-200 / month",
        provider: {
            name: "Embroker",
            link: "https://www.embroker.com/solutions/cyber-insurance/"
        }
    }
];

const GROWTH_PATH_INSURANCE = [
    {
        name: "Increased Cyber Liability Limits",
        requirement: "Active DoD Contracts / Handling CUI",
        details: "Increase coverage to $2M - $5M to meet federal contract requirements.",
        trigger: "SBIR Phase II Award / First Prime Contract"
    },
    {
        name: "Directors & Officers (D&O)",
        requirement: "Seeking Venture Capital / Board of Directors",
        details: "Protects your personal assets from lawsuits against the company's management.",
        trigger: "After Seed Funding Round"
    },
    {
        name: "Technology Errors & Omissions",
        requirement: "Large-Scale SaaS Deployment",
        details: "Specialized E&O policy covering software performance, uptime, and data loss.",
        trigger: "Enterprise Client Onboarding"
    }
];

// New constant array
const VALUE_PROPOSITIONS = [
    {
        title: "Pre-Underwriting Risk Portal",
        icon: ScanSearch,
        description: "Give their underwriters a private portal to scan potential clients' IP addresses and domains *before* they write a policy. This directly reduces their loss ratio by weeding out high-risk applicants.",
        status: "Ready to Demo",
        component: "AIAnalysisCard on Dashboard"
    },
    {
        title: "'HyperCore Certified' Referral Program",
        icon: Award,
        description: "We bring them a pipeline of vetted, low-risk clients who are already using our platform. This lowers their customer acquisition cost and guarantees a better-than-average risk pool.",
        status: "Process Ready",
        component: "PartnershipHub tracking"
    },
    {
        title: "Data-Driven Underwriting Reports",
        icon: FileText,
        description: "Provide their team with our detailed Cyber Resilience Score & Financial Impact Reports. This gives them proprietary data to price risk more accurately than their competitors.",
        status: "Ready to Demo",
        component: "FinancialRiskIntelligence Page"
    },
    {
        title: "Joint Marketing & Case Studies",
        icon: Megaphone,
        description: "Offer to co-author a whitepaper: 'How HyperCore & [Insurer Name] Reduced DIB Claims by X%.' This provides them with powerful marketing material to attract more clients.",
        status: "Content Ready",
        component: "Generateable templates"
    }
];

export default function CyberInsuranceGateway() {
    return (
        <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50 p-6">
            <div className="max-w-7xl mx-auto">
                <motion.div
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="mb-8"
                >
                    <h1 className="text-4xl font-bold text-gray-900 mb-2 flex items-center gap-3">
                        <Shield className="w-10 h-10 text-blue-600" />
                        Cyber Insurance Gateway
                    </h1>
                    <p className="text-lg text-gray-600">
                        Secure the minimum viable insurance needed to operate and win contracts.
                    </p>
                </motion.div>

                {/* New Section: Value Proposition */}
                <Card className="mb-8 bg-gradient-to-r from-purple-50 to-indigo-50 border-purple-200">
                    <CardHeader>
                        <CardTitle className="text-2xl text-purple-800">The Value Proposition for a No-Cost Partnership</CardTitle>
                        <CardDescription className="text-purple-700">
                            Instead of asking for insurance, offer them these tangible assets. This changes the conversation from "Can you cover us?" to "How can we make money together?"
                        </CardDescription>
                    </CardHeader>
                    <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {VALUE_PROPOSITIONS.map((prop, index) => (
                            <motion.div
                                key={prop.title}
                                initial={{ opacity: 0, y: 20 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: index * 0.15 }}
                            >
                                <Card className="h-full bg-white/60 hover:shadow-lg transition-shadow">
                                    <CardHeader>
                                        <div className="flex items-center gap-3">
                                            {/* Render the icon component dynamically */}
                                            {prop.icon && <prop.icon className="w-8 h-8 text-purple-600" />}
                                            <CardTitle>{prop.title}</CardTitle>
                                        </div>
                                    </CardHeader>
                                    <CardContent>
                                        <p className="text-sm text-gray-700 mb-4">{prop.description}</p>
                                        <Badge className="bg-green-100 text-green-800">{prop.status}</Badge>
                                    </CardContent>
                                </Card>
                            </motion.div>
                        ))}
                    </CardContent>
                </Card>

                <Card className="mb-8 bg-yellow-50 border-yellow-200">
                    <CardHeader>
                        <CardTitle className="text-yellow-800">ACTION: Secure This Coverage Immediately</CardTitle>
                        <CardDescription className="text-yellow-700">
                            You must have this basic coverage in place **before** engaging any potential client, giving a demo, or signing a pilot agreement. This is a non-negotiable step to protect your new LLC and your personal assets.
                        </CardDescription>
                    </CardHeader>
                </Card>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
                    {MINIMUM_VIABLE_PACKAGE.map((policy, index) => (
                        <motion.div
                            key={policy.name}
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: index * 0.1 }}
                        >
                            <Card className="h-full flex flex-col">
                                <CardHeader>
                                    <div className="flex justify-between items-center">
                                        <CardTitle className="text-lg">{policy.name}</CardTitle>
                                        <Badge variant="secondary">{policy.cost}</Badge>
                                    </div>
                                    <CardDescription className="font-bold text-blue-600">{policy.coverage} Coverage</CardDescription>
                                </CardHeader>
                                <CardContent className="flex-grow">
                                    <p className="text-sm text-gray-600 mb-4">{policy.purpose}</p>
                                </CardContent>
                                <div className="p-6 pt-0">
                                    <Button asChild className="w-full">
                                        <a href={policy.provider.link} target="_blank" rel="noopener noreferrer">
                                            Get Instant Quote from {policy.provider.name}
                                            <ExternalLink className="w-4 h-4 ml-2" />
                                        </a>
                                    </Button>
                                </div>
                            </Card>
                        </motion.div>
                    ))}
                </div>

                <Card>
                    <CardHeader>
                        <CardTitle>Insurance Growth Path</CardTitle>
                        <CardDescription>
                            This is the insurance you'll need as you win larger contracts and secure funding. Plan for these expenses post-SBIR award.
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-4">
                            {GROWTH_PATH_INSURANCE.map((item, index) => (
                                <div key={index} className="flex flex-col md:flex-row items-start justify-between p-4 border rounded-lg">
                                    <div className="flex-1 mb-2 md:mb-0">
                                        <h4 className="font-semibold">{item.name}</h4>
                                        <p className="text-sm text-gray-600">{item.details}</p>
                                    </div>
                                    <div className="md:text-right">
                                        <Badge className="mb-2 bg-purple-100 text-purple-800">{item.trigger}</Badge>
                                        <p className="text-xs text-gray-500">Requirement: {item.requirement}</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </CardContent>
                </Card>

            </div>
        </div>
    );
}
