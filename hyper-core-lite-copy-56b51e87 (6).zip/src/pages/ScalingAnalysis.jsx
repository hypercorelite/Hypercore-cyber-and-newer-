import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { TrendingUp, DollarSign, Users, Zap, Target, BarChart, ArrowRight, Cloud, Shield } from 'lucide-react';
import { motion } from "framer-motion";
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";

const scalingPhases = [
    {
        year: "Year 1 (2026)",
        market_share: "10%",
        total_customers: "3,150",
        subscription_customers: "2,677 (85%)",
        enterprise_customers: "473 (15%)",
        subscription_revenue: "$9.5M",
        enterprise_revenue: "$5.9M",
        total_arr: "$15.4M",
        monthly_growth: "~262 new customers/month",
        notes: "Foundation year - prove product-market fit, establish market presence"
    },
    {
        year: "Year 2 (2027)", 
        market_share: "20%",
        total_customers: "6,300",
        subscription_customers: "5,355 (85%)",
        enterprise_customers: "945 (15%)",
        subscription_revenue: "$19.1M",
        enterprise_revenue: "$11.8M",
        total_arr: "$30.9M",
        monthly_growth: "~262 new customers/month",
        notes: "Scaling acceleration - word of mouth drives growth, competitive differentiation proven"
    },
    {
        year: "Year 3 (2028)",
        market_share: "35%",
        total_customers: "11,025",
        subscription_customers: "9,371 (85%)",
        enterprise_customers: "1,654 (15%)",
        subscription_revenue: "$33.4M",
        enterprise_revenue: "$20.7M", 
        total_arr: "$54.1M",
        monthly_growth: "~394 new customers/month",
        notes: "Market dominance phase - competitors forced to drop prices or exit"
    },
    {
        year: "Year 4 (2029)",
        market_share: "50%",
        total_customers: "15,750",
        subscription_customers: "13,387 (85%)",
        enterprise_customers: "2,363 (15%)",
        subscription_revenue: "$47.7M",
        enterprise_revenue: "$29.5M",
        total_arr: "$77.2M",
        monthly_growth: "~394 new customers/month",
        notes: "Market leadership - platform becomes essential infrastructure for DIB"
    },
    {
        year: "Year 5 (2030)",
        market_share: "65%",
        total_customers: "20,475",
        subscription_customers: "17,404 (85%)",
        enterprise_customers: "3,071 (15%)",
        subscription_revenue: "$62.0M",
        enterprise_revenue: "$38.4M",
        total_arr: "$100.4M",
        monthly_growth: "~394 new customers/month",
        notes: "Market saturation approaching - focus shifts to retention, expansion, adjacent markets"
    }
];

const revenueExpansionOpportunities = [
    {
        opportunity: "Price Optimization",
        year_1: "$297/month baseline",
        year_5: "$397/month (+33% over 5 years)",
        impact: "+$20.7M additional ARR by Year 5"
    },
    {
        opportunity: "Enterprise Premium Tiers", 
        year_1: "$12.5K one-time",
        year_5: "$15K one-time + $500/month ongoing",
        impact: "+$12.3M additional ARR from premium services"
    },
    {
        opportunity: "Adjacent Compliance Frameworks",
        year_1: "CMMC only",
        year_5: "HIPAA, SOX, FedRAMP modules",
        impact: "+$25M ARR from compliance expansion"
    },
    {
        opportunity: "International Expansion",
        year_1: "US DIB only",
        year_5: "NATO allies, defense partnerships",
        impact: "+$30M ARR from international markets"
    }
];

const marketDisruptionImpact = [
    {
        metric: "Consultant Market Displacement",
        traditional_size: "$500M annually (31.5K contractors × $15K avg)",
        hypercore_capture: "$100M ARR by Year 5 (20% market capture)",
        impact: "Forces 70% of independent consultants to partner or exit"
    },
    {
        metric: "GRC Software Revenue Impact", 
        traditional_size: "$300M annually in SMB segment",
        hypercore_impact: "Force 50-75% price reductions to compete",
        our_advantage: "Superior automation makes price competition irrelevant"
    },
    {
        metric: "New Market Creation",
        description: "AI-First Compliance as a Service category",
        market_size: "$150M new category by Year 5",
        our_position: "Category creator and dominant player"
    }
];

export default function ScalingAnalysis() {
    return (
        <div className="space-y-8 p-4 md:p-6">
            <BreadcrumbNav currentPageName="ScalingAnalysis" />
            
            <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center"
            >
                <Badge className="mb-4 bg-purple-100 text-purple-800">5-YEAR STRATEGIC PROJECTION</Badge>
                <h1 className="text-4xl font-bold text-gray-900 mb-4">
                    From 10% to 65% Market Dominance: The $100M ARR Path
                </h1>
                <p className="text-xl text-gray-600 max-w-4xl mx-auto">
                    Your roadmap to capturing two-thirds of the 31,500 SMB contractor market through strategic pricing, platform expansion, and market disruption.
                </p>
            </motion.div>

            <Alert className="bg-green-50 border-green-200">
                <Target className="h-4 w-4 text-green-600" />
                <AlertTitle className="text-green-800 font-bold">Executive Summary: $100M ARR by 2030</AlertTitle>
                <AlertDescription className="text-green-700">
                    Conservative projections show 65% market share (20,475 customers) generating <strong>$100.4M ARR</strong> by Year 5, with additional expansion opportunities worth $88M+ in adjacent markets and premium services.
                </AlertDescription>
            </Alert>

            {/* Year-by-Year Scaling Analysis */}
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                        <TrendingUp className="w-6 h-6" />
                        5-Year Market Penetration Strategy
                    </CardTitle>
                    <CardDescription>
                        Realistic progression from 10% to 65% market share with mixed pricing model
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="space-y-6">
                        {scalingPhases.map((phase, index) => (
                            <motion.div
                                key={phase.year}
                                initial={{ opacity: 0, x: -20 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ delay: index * 0.1 }}
                                className={`p-6 rounded-lg border-l-4 ${
                                    index === 0 ? 'border-blue-500 bg-blue-50' :
                                    index === 1 ? 'border-green-500 bg-green-50' :
                                    index === 2 ? 'border-purple-500 bg-purple-50' :
                                    index === 3 ? 'border-orange-500 bg-orange-50' :
                                    'border-red-500 bg-red-50'
                                }`}
                            >
                                <div className="flex justify-between items-start mb-4">
                                    <h3 className="text-xl font-bold text-gray-800">{phase.year}</h3>
                                    <Badge variant="outline" className="text-lg font-bold">
                                        {phase.total_arr} ARR
                                    </Badge>
                                </div>
                                
                                <div className="grid md:grid-cols-4 gap-4 mb-4">
                                    <div>
                                        <p className="text-sm text-gray-600">Market Share</p>
                                        <p className="font-bold text-lg">{phase.market_share}</p>
                                        <p className="text-xs text-gray-500">{phase.total_customers} total customers</p>
                                    </div>
                                    <div>
                                        <p className="text-sm text-gray-600">Subscription Revenue</p>
                                        <p className="font-bold text-green-600">{phase.subscription_revenue}</p>
                                        <p className="text-xs text-gray-500">{phase.subscription_customers}</p>
                                    </div>
                                    <div>
                                        <p className="text-sm text-gray-600">Enterprise Revenue</p>
                                        <p className="font-bold text-blue-600">{phase.enterprise_revenue}</p>
                                        <p className="text-xs text-gray-500">{phase.enterprise_customers}</p>
                                    </div>
                                    <div>
                                        <p className="text-sm text-gray-600">Growth Rate</p>
                                        <p className="font-bold">{phase.monthly_growth}</p>
                                        <p className="text-xs text-gray-500">new customers/month</p>
                                    </div>
                                </div>
                                
                                <p className="text-sm text-gray-600 italic">{phase.notes}</p>
                            </motion.div>
                        ))}
                    </div>
                </CardContent>
            </Card>

            {/* Revenue Expansion Analysis */}
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                        <DollarSign className="w-6 h-6 text-green-600" />
                        Revenue Expansion Opportunities: +$88M Potential
                    </CardTitle>
                    <CardDescription>
                        Additional revenue streams beyond core CMMC subscription model
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="grid md:grid-cols-2 gap-6">
                        {revenueExpansionOpportunities.map((opportunity, index) => (
                            <div key={index} className="p-4 bg-gray-50 rounded-lg">
                                <h4 className="font-semibold text-lg mb-3">{opportunity.opportunity}</h4>
                                <div className="space-y-2 text-sm">
                                    <div className="flex justify-between">
                                        <span className="text-gray-600">Year 1:</span>
                                        <span>{opportunity.year_1}</span>
                                    </div>
                                    <div className="flex justify-between">
                                        <span className="text-gray-600">Year 5:</span>
                                        <span className="font-semibold">{opportunity.year_5}</span>
                                    </div>
                                    <div className="pt-2 border-t">
                                        <span className="text-green-600 font-semibold">Impact: {opportunity.impact}</span>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                    
                    <div className="mt-6 p-4 bg-green-100 rounded-lg">
                        <h4 className="font-bold text-green-800 mb-2">Total Expansion Potential</h4>
                        <p className="text-green-700">
                            <strong>Core Platform by Year 5:</strong> $100.4M ARR<br/>
                            <strong>Expansion Opportunities:</strong> +$88M ARR potential<br/>
                            <strong>Total Addressable by 2030:</strong> $188M+ ARR
                        </p>
                    </div>
                </CardContent>
            </Card>

            {/* Market Disruption Impact */}
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                        <Zap className="w-6 h-6 text-purple-600" />
                        Market Disruption Impact Analysis
                    </CardTitle>
                    <CardDescription>
                        How your growth affects and reshapes the entire CMMC ecosystem
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="space-y-6">
                        {marketDisruptionImpact.map((impact, index) => (
                            <div key={index} className="p-6 bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg border border-purple-200">
                                <h4 className="text-lg font-semibold text-purple-900 mb-3">{impact.metric}</h4>
                                <div className="grid md:grid-cols-2 gap-4 text-sm">
                                    {impact.traditional_size && (
                                        <div>
                                            <p className="text-gray-600">Traditional Market Size:</p>
                                            <p className="font-semibold">{impact.traditional_size}</p>
                                        </div>
                                    )}
                                    {impact.hypercore_capture && (
                                        <div>
                                            <p className="text-gray-600">HyperCore Capture:</p>
                                            <p className="font-semibold text-green-600">{impact.hypercore_capture}</p>
                                        </div>
                                    )}
                                    {impact.hypercore_impact && (
                                        <div>
                                            <p className="text-gray-600">Market Impact:</p>
                                            <p className="font-semibold text-red-600">{impact.hypercore_impact}</p>
                                        </div>
                                    )}
                                    {impact.our_advantage && (
                                        <div>
                                            <p className="text-gray-600">Strategic Advantage:</p>
                                            <p className="font-semibold text-blue-600">{impact.our_advantage}</p>
                                        </div>
                                    )}
                                    {impact.description && (
                                        <div className="md:col-span-2">
                                            <p className="text-gray-600">Description:</p>
                                            <p className="font-semibold">{impact.description}</p>
                                        </div>
                                    )}
                                    {impact.market_size && (
                                        <div>
                                            <p className="text-gray-600">New Market Size:</p>
                                            <p className="font-semibold text-green-600">{impact.market_size}</p>
                                        </div>
                                    )}
                                    {impact.our_position && (
                                        <div>
                                            <p className="text-gray-600">Our Position:</p>
                                            <p className="font-semibold text-purple-600">{impact.our_position}</p>
                                        </div>
                                    )}
                                </div>
                                {impact.impact && (
                                    <div className="mt-3 pt-3 border-t border-purple-200">
                                        <p className="text-purple-700 font-medium">Market Impact: {impact.impact}</p>
                                    </div>
                                )}
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>

            {/* Key Success Metrics */}
            <Card className="bg-gradient-to-r from-green-500 to-blue-600 text-white">
                <CardHeader>
                    <CardTitle className="text-2xl">5-Year Success Metrics</CardTitle>
                    <CardDescription className="text-green-100">Key performance indicators for market dominance</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4 pt-4">
                    <div className="grid md:grid-cols-3 gap-6">
                        <div className="text-center">
                            <div className="text-3xl font-bold">65%</div>
                            <div className="text-sm opacity-90">Market Share Captured</div>
                            <div className="text-xs opacity-75">20,475 of 31,500 contractors</div>
                        </div>
                        <div className="text-center">
                            <div className="text-3xl font-bold">$100.4M</div>
                            <div className="text-sm opacity-90">Annual Recurring Revenue</div>
                            <div className="text-xs opacity-75">Core platform only</div>
                        </div>
                        <div className="text-center">
                            <div className="text-3xl font-bold">$188M+</div>
                            <div className="text-sm opacity-90">Total Opportunity</div>
                            <div className="text-xs opacity-75">With all expansion streams</div>
                        </div>
                    </div>
                    
                    <div className="pt-6 border-t border-white/20">
                        <h4 className="font-semibold mb-3">Strategic Milestones by 2030:</h4>
                        <ul className="text-sm space-y-1 opacity-90">
                            <li>• Dominant player in CMMC compliance automation</li>
                            <li>• Category creator for AI-First Compliance as a Service</li>
                            <li>• 70% of traditional consultants forced to partner or exit</li>
                            <li>• Platform becomes essential infrastructure for DIB</li>
                            <li>• International expansion establishes global presence</li>
                        </ul>
                    </div>
                </CardContent>
            </Card>

            <div className="text-center">
                <Button asChild size="lg" className="bg-purple-600 hover:bg-purple-700">
                    <a href="#" className="flex items-center gap-2">
                        Execute This 5-Year Strategy <TrendingUp className="w-4 h-4" />
                    </a>
                </Button>
            </div>
        </div>
    );
}