import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { User } from "@/api/entities";
import { Shield, FileCheck, Bot, Upload, Download, MessageSquare, CheckSquare, ArrowRight } from 'lucide-react';
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

export default function ClientServicePortal() {
    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        User.me().then(user => {
            setUser(user);
            setLoading(false);
        }).catch(() => setLoading(false));
    }, []);

    if (loading) {
        return <div className="p-8 text-center">Loading your portal...</div>;
    }

    const mvpTools = [
        {
            title: "AI Gap Analysis",
            description: "Upload your documents and get an instant CMMC readiness score",
            icon: Bot,
            href: createPageUrl('AIGapAnalysis'),
            status: "active",
            color: "bg-blue-50 border-blue-200"
        },
        {
            title: "AI Policy Generator",
            description: "Generate core policies (Access Control, IR, etc.) in minutes",
            icon: FileCheck,
            href: createPageUrl('PolicyGenerator'),
            status: "active", 
            color: "bg-green-50 border-green-200"
        },
        {
            title: "System Security Plan Builder",
            description: "Create your foundational SSP with AI assistance",
            icon: Shield,
            href: createPageUrl('SSPBuilder'),
            status: "active",
            color: "bg-purple-50 border-purple-200"
        },
        {
            title: "Implementation Checklist",
            description: "8-week structured plan to guide you to compliance",
            icon: CheckSquare,
            href: createPageUrl('ImplementationPlan'),
            status: "active",
            color: "bg-orange-50 border-orange-200"
        },
        {
            title: "Expert Support",
            description: "Get help from our compliance experts via email",
            icon: MessageSquare,
            href: createPageUrl('ExpertSupport'),
            status: "active",
            color: "bg-yellow-50 border-yellow-200"
        },
        {
            title: "PDF Report Generator",
            description: "Download professional reports for leadership and auditors",
            icon: Download,
            href: createPageUrl('ReportGenerator'),
            status: "active",
            color: "bg-indigo-50 border-indigo-200"
        }
    ];

    return (
        <div className="min-h-screen bg-gray-50 p-6">
            <div className="max-w-6xl mx-auto">
                {/* Welcome Section */}
                <div className="text-center mb-8">
                    <h1 className="text-4xl font-bold text-gray-900 mb-4">
                        Welcome to Your CMMC Readiness Portal
                    </h1>
                    <p className="text-xl text-gray-600 mb-6">
                        Complete AI-powered toolkit to get audit-ready by November 10th
                    </p>
                    
                    <Alert className="max-w-4xl mx-auto bg-green-50 border-green-200">
                        <CheckSquare className="h-4 w-4 text-green-600" />
                        <AlertTitle className="text-green-800">Free Beta Access Through Dec 5, 2025</AlertTitle>
                        <AlertDescription className="text-green-700">
                            You have full access to all MVP tools at no cost. Use them to meet the November 10th DFARS deadline.
                        </AlertDescription>
                    </Alert>
                </div>

                {/* Tools Grid */}
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {mvpTools.map((tool, index) => (
                        <Card key={index} className={`${tool.color} hover:shadow-lg transition-shadow h-full`}>
                            <CardHeader>
                                <div className="flex items-center justify-between">
                                    <tool.icon className="w-8 h-8 text-gray-700" />
                                    <Badge className="bg-green-100 text-green-800">FREE</Badge>
                                </div>
                                <CardTitle className="text-xl">{tool.title}</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <CardDescription className="text-gray-600 mb-4 text-base">
                                    {tool.description}
                                </CardDescription>
                                <Button asChild className="w-full">
                                    <Link to={tool.href}>
                                        Start Using Tool <ArrowRight className="w-4 h-4 ml-2" />
                                    </Link>
                                </Button>
                            </CardContent>
                        </Card>
                    ))}
                </div>

                {/* Quick Actions */}
                <Card className="mt-8 bg-white">
                    <CardHeader>
                        <CardTitle className="text-2xl">Quick Start Guide</CardTitle>
                        <CardDescription>Follow these steps to maximize your free beta access</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="grid md:grid-cols-2 gap-6">
                            <div className="space-y-4">
                                <h3 className="font-bold text-lg">Week 1-2: Assessment</h3>
                                <ol className="list-decimal list-inside space-y-2 text-gray-700">
                                    <li>Run AI Gap Analysis on your current documentation</li>
                                    <li>Generate your first 3-5 core policies</li>
                                    <li>Start building your System Security Plan</li>
                                </ol>
                            </div>
                            <div className="space-y-4">
                                <h3 className="font-bold text-lg">Week 3-8: Implementation</h3>
                                <ol className="list-decimal list-inside space-y-2 text-gray-700">
                                    <li>Follow your 8-week implementation checklist</li>
                                    <li>Use expert support for guidance</li>
                                    <li>Generate final reports for audit readiness</li>
                                </ol>
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}