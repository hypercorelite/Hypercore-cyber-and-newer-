import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Bot, Zap, Mail, FileText, Shield, Users, Target, ArrowRight, Clock, CheckCircle } from 'lucide-react';
import { motion } from "framer-motion";

const aiWorkflows = {
    leadGeneration: {
        title: "AI Lead Generation & Qualification Agent",
        agent: "lead_qualifier_agent",
        purpose: "Automatically identify, reach out to, and qualify defense subcontractors",
        workflow: [
            {
                step: 1,
                action: "Scrape DoD Contractor Database",
                ai_task: "Use web scraping to identify subcontractors from SAM.gov and DIBBS",
                automation: "Daily automated search for new contractor registrations",
                output: "List of potential leads with contact information"
            },
            {
                step: 2,
                action: "AI-Powered Lead Scoring",
                ai_task: "Analyze company size, contract history, and compliance requirements",
                automation: "Score leads 1-100 based on likelihood to need CMMC compliance",
                output: "Prioritized lead list with engagement recommendations"
            },
            {
                step: 3,
                action: "Automated Email Outreach",
                ai_task: "Generate personalized email sequences based on lead profile",
                automation: "Send 3-touch email sequence with 5-day intervals",
                output: "Tracked engagement metrics and response rates"
            },
            {
                step: 4,
                action: "Demo Scheduling",
                ai_task: "Handle inbound responses and schedule demo calls",
                automation: "Calendar integration with automatic booking confirmation",
                output: "Qualified demos on your calendar with pre-demo briefs"
            }
        ],
        metrics: "Target: 100 leads/week, 10% response rate, 3-5 demos/week"
    },
    complianceAssessment: {
        title: "AI CMMC Readiness Assessment Agent",
        agent: "cmmc_assessment_agent",
        purpose: "Conduct comprehensive compliance assessments with minimal human intervention",
        workflow: [
            {
                step: 1,
                action: "Client Data Ingestion",
                ai_task: "Parse uploaded SSPs, network diagrams, and policy documents",
                automation: "Automated document classification and data extraction",
                output: "Structured compliance data ready for analysis"
            },
            {
                step: 2,
                action: "Multi-Cloud Evidence Collection",
                ai_task: "Connect to AWS Config and Microsoft Purview APIs",
                automation: "Real-time evidence collection from both cloud platforms",
                output: "Comprehensive evidence library with compliance mappings"
            },
            {
                step: 3,
                action: "Gap Analysis Generation",
                ai_task: "Compare current state against all 110 CMMC Level 2 controls",
                automation: "Automated gap identification with risk scoring",
                output: "Detailed gap analysis with remediation priorities"
            },
            {
                step: 4,
                action: "POA&M Creation",
                ai_task: "Generate Plan of Action & Milestones for all identified gaps",
                automation: "Automated timelines and resource estimates",
                output: "Professional POA&M document ready for C3PAO review"
            }
        ],
        metrics: "Target: Complete assessment in 48-72 hours vs. 2-4 weeks manual"
    },
    documentGeneration: {
        title: "AI Document Generation & Compliance Reporting Agent",
        agent: "compliance_doc_generator_agent",
        purpose: "Generate audit-ready compliance documents automatically",
        workflow: [
            {
                step: 1,
                action: "SSP Template Customization",
                ai_task: "Generate client-specific System Security Plan",
                automation: "Auto-populate controls based on assessed environment",
                output: "Draft SSP document (80-120 pages) in DOD format"
            },
            {
                step: 2,
                action: "Policy Document Creation",
                ai_task: "Create all required cybersecurity policies",
                automation: "Generate 15-20 policies tailored to client environment",
                output: "Complete policy library with implementation guides"
            },
            {
                step: 3,
                action: "Evidence Package Assembly",
                ai_task: "Organize and format all collected evidence",
                automation: "Create audit trail with proper documentation",
                output: "C3PAO-ready evidence package with cross-references"
            },
            {
                step: 4,
                action: "Executive Reporting",
                ai_task: "Generate executive summary and roadmap",
                automation: "Create timeline and budget estimates for compliance",
                output: "Executive briefing deck for client leadership"
            }
        ],
        metrics: "Target: Generate 100+ pages of compliance documentation in 4-6 hours"
    }
};

const customerWorkflows = {
    onboarding: {
        title: "Automated Customer Onboarding",
        steps: [
            "AI agent sends welcome sequence and collects initial requirements",
            "Automated compliance questionnaire with smart follow-up questions", 
            "AI schedules kickoff call and prepares personalized agenda",
            "Automated project setup in compliance tracking system"
        ]
    },
    support: {
        title: "AI-Powered Customer Support",
        steps: [
            "AI chatbot handles 80% of common CMMC questions",
            "Automated ticket routing based on issue complexity",
            "AI generates initial response drafts for human review",
            "Escalation to human experts for complex technical issues"
        ]
    },
    reporting: {
        title: "Continuous Compliance Monitoring",
        steps: [
            "Daily automated scans of client cloud environments",
            "AI identifies new compliance gaps or configuration drift",
            "Automated monthly compliance reports sent to clients",
            "Proactive alerts for potential audit findings"
        ]
    }
};

export default function AutomatedCMMCWorkflow() {
    const [selectedWorkflow, setSelectedWorkflow] = useState('leadGeneration');

    return (
        <div className="min-h-screen bg-gray-50 p-6">
            <div className="max-w-7xl mx-auto">
                <motion.div
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="text-center mb-8"
                >
                    <h1 className="text-4xl font-bold text-gray-900 mb-3 flex items-center justify-center gap-3">
                        <Bot className="w-10 h-10 text-blue-600" />
                        AI-Powered CMMC Workflow Automation
                    </h1>
                    <p className="text-xl text-gray-600">
                        Scale your compliance business with intelligent agents that handle routine tasks.
                    </p>
                </motion.div>

                <Alert className="mb-8 bg-blue-50 border-blue-200">
                    <Zap className="h-4 w-4 text-blue-600" />
                    <AlertTitle className="text-blue-800">The AI Multiplier Effect</AlertTitle>
                    <AlertDescription className="text-blue-700">
                        These workflows enable a 1-person team to deliver the same output as a 10-person consulting firm. AI handles the repetitive work while you focus on client relationships and strategic decisions.
                    </AlertDescription>
                </Alert>

                <Tabs defaultValue="sales" className="w-full">
                    <TabsList className="grid w-full grid-cols-3">
                        <TabsTrigger value="sales">Sales & Lead Generation</TabsTrigger>
                        <TabsTrigger value="delivery">Service Delivery</TabsTrigger>
                        <TabsTrigger value="support">Customer Success</TabsTrigger>
                    </TabsList>
                    
                    <TabsContent value="sales" className="pt-6">
                        <div className="space-y-6">
                            <Card>
                                <CardHeader>
                                    <CardTitle className="flex items-center gap-2">
                                        <Target className="w-6 h-6 text-green-600" />
                                        {aiWorkflows.leadGeneration.title}
                                    </CardTitle>
                                    <CardDescription>{aiWorkflows.leadGeneration.purpose}</CardDescription>
                                </CardHeader>
                                <CardContent>
                                    <div className="grid gap-4">
                                        {aiWorkflows.leadGeneration.workflow.map((step, index) => (
                                            <motion.div 
                                                key={step.step}
                                                initial={{ opacity: 0, x: -20 }}
                                                animate={{ opacity: 1, x: 0 }}
                                                transition={{ delay: index * 0.1 }}
                                                className="flex items-start gap-4 p-4 bg-white rounded-lg border"
                                            >
                                                <Badge className="bg-green-100 text-green-800 min-w-fit">
                                                    Step {step.step}
                                                </Badge>
                                                <div className="flex-1">
                                                    <h4 className="font-semibold text-gray-900">{step.action}</h4>
                                                    <p className="text-sm text-blue-600 mb-1">{step.ai_task}</p>
                                                    <p className="text-sm text-gray-600 mb-1">{step.automation}</p>
                                                    <p className="text-xs font-medium text-green-700">Output: {step.output}</p>
                                                </div>
                                                <ArrowRight className="w-4 h-4 text-gray-400 mt-2" />
                                            </motion.div>
                                        ))}
                                    </div>
                                    <Alert className="mt-4 bg-green-50 border-green-200">
                                        <Target className="h-4 w-4 text-green-600" />
                                        <AlertDescription className="text-green-700 font-medium">
                                            {aiWorkflows.leadGeneration.metrics}
                                        </AlertDescription>
                                    </Alert>
                                </CardContent>
                            </Card>
                        </div>
                    </TabsContent>

                    <TabsContent value="delivery" className="pt-6">
                        <div className="space-y-6">
                            <div className="grid md:grid-cols-2 gap-6">
                                <Card>
                                    <CardHeader>
                                        <CardTitle className="flex items-center gap-2">
                                            <Shield className="w-6 h-6 text-blue-600" />
                                            Assessment Automation
                                        </CardTitle>
                                    </CardHeader>
                                    <CardContent>
                                        <div className="space-y-3">
                                            {aiWorkflows.complianceAssessment.workflow.map((step, index) => (
                                                <div key={step.step} className="flex items-start gap-3 p-3 bg-gray-50 rounded">
                                                    <Badge variant="outline" className="min-w-fit">{step.step}</Badge>
                                                    <div>
                                                        <h5 className="font-medium text-sm">{step.action}</h5>
                                                        <p className="text-xs text-gray-600">{step.ai_task}</p>
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                        <Badge className="mt-3 bg-blue-100 text-blue-800">
                                            {aiWorkflows.complianceAssessment.metrics}
                                        </Badge>
                                    </CardContent>
                                </Card>

                                <Card>
                                    <CardHeader>
                                        <CardTitle className="flex items-center gap-2">
                                            <FileText className="w-6 h-6 text-purple-600" />
                                            Document Generation
                                        </CardTitle>
                                    </CardHeader>
                                    <CardContent>
                                        <div className="space-y-3">
                                            {aiWorkflows.documentGeneration.workflow.map((step, index) => (
                                                <div key={step.step} className="flex items-start gap-3 p-3 bg-gray-50 rounded">
                                                    <Badge variant="outline" className="min-w-fit">{step.step}</Badge>
                                                    <div>
                                                        <h5 className="font-medium text-sm">{step.action}</h5>
                                                        <p className="text-xs text-gray-600">{step.ai_task}</p>
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                        <Badge className="mt-3 bg-purple-100 text-purple-800">
                                            {aiWorkflows.documentGeneration.metrics}
                                        </Badge>
                                    </CardContent>
                                </Card>
                            </div>
                        </div>
                    </TabsContent>

                    <TabsContent value="support" className="pt-6">
                        <div className="grid md:grid-cols-3 gap-6">
                            {Object.entries(customerWorkflows).map(([key, workflow]) => (
                                <Card key={key}>
                                    <CardHeader>
                                        <CardTitle className="text-lg">{workflow.title}</CardTitle>
                                    </CardHeader>
                                    <CardContent>
                                        <div className="space-y-2">
                                            {workflow.steps.map((step, index) => (
                                                <div key={index} className="flex items-start gap-2">
                                                    <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                                                    <span className="text-sm text-gray-700">{step}</span>
                                                </div>
                                            ))}
                                        </div>
                                    </CardContent>
                                </Card>
                            ))}
                        </div>
                    </TabsContent>
                </Tabs>

                <Card className="mt-8 bg-gradient-to-r from-green-50 to-blue-50 border-green-200">
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <Bot className="w-6 h-6 text-green-600" />
                            Implementation Roadmap: AI-First Approach
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="grid md:grid-cols-4 gap-4">
                            <div className="text-center">
                                <Badge className="bg-green-100 text-green-800 mb-2">Week 1-2</Badge>
                                <h4 className="font-semibold">Lead Generation Agent</h4>
                                <p className="text-sm text-gray-600">Deploy AI lead qualification and outreach automation</p>
                            </div>
                            <div className="text-center">
                                <Badge className="bg-blue-100 text-blue-800 mb-2">Week 3-4</Badge>
                                <h4 className="font-semibold">Assessment Agent</h4>
                                <p className="text-sm text-gray-600">Implement automated CMMC readiness assessment</p>
                            </div>
                            <div className="text-center">
                                <Badge className="bg-purple-100 text-purple-800 mb-2">Week 5-6</Badge>
                                <h4 className="font-semibold">Document Generator</h4>
                                <p className="text-sm text-gray-600">Deploy AI-powered compliance documentation</p>
                            </div>
                            <div className="text-center">
                                <Badge className="bg-orange-100 text-orange-800 mb-2">Week 7-8</Badge>
                                <h4 className="font-semibold">Support Agent</h4>
                                <p className="text-sm text-gray-600">Launch AI customer support and monitoring</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}