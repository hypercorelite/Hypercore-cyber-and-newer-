import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, CheckCircle, Download, Shield, Terminal, Zap, FileText } from 'lucide-react';
import { motion } from 'framer-motion';
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";

const CodeBlock = ({ content }) => {
    return (
        <pre className="bg-gray-800 text-white p-3 rounded-md font-mono text-sm overflow-x-auto">
            <code>{content}</code>
        </pre>
    );
};

export default function LiveSecurityScanGuide() {
    return (
        <div className="space-y-8">
            <BreadcrumbNav currentPageName="LiveSecurityScanGuide" />
            <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="text-center">
                <Badge className="mb-4 bg-blue-100 text-blue-800">REAL SECURITY TESTING</Badge>
                <h1 className="text-4xl font-bold text-gray-900 mb-4 flex items-center justify-center gap-3">
                    <Zap className="w-8 h-8 text-blue-600" />
                    Live Security Scan Guide: Using OWASP ZAP
                </h1>
                <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                    A step-by-step guide to run a real penetration test on your platform and generate a clean report for prime contractor demos.
                </p>
            </motion.div>

            <Alert className="bg-green-50 border-green-200">
                <Shield className="h-4 w-4 text-green-600" />
                <AlertTitle className="text-green-800">Your Goal: A "Zero Vulnerability" Report</AlertTitle>
                <AlertDescription className="text-green-700">
                    The objective is to produce a PDF report from ZAP showing **zero high or critical vulnerabilities**. This is the evidence you'll show to Leidos, Booz Allen, and SAIC to prove your platform is secure.
                </AlertDescription>
            </Alert>

            <div className="space-y-6">
                {/* Step 1: Installation */}
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-3">
                            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center font-bold text-gray-700">1</div>
                            Download & Install OWASP ZAP
                        </CardTitle>
                        <CardDescription>Get the industry-standard, free security scanning tool. (Estimated time: 10 minutes)</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <p className="mb-4">OWASP ZAP is a free, open-source web application security scanner. It's what security professionals use to find vulnerabilities.</p>
                        <a href="https://www.zaproxy.org/download/" target="_blank" rel="noopener noreferrer" className="text-blue-600 font-semibold hover:underline flex items-center">
                            Download OWASP ZAP Official Release <ArrowRight className="w-4 h-4 ml-1" />
                        </a>
                        <p className="text-sm text-gray-500 mt-2">Choose the installer for your operating system (Windows, macOS, or Linux) and follow the installation prompts.</p>
                    </CardContent>
                </Card>

                {/* Step 2: Website Scan */}
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-3">
                            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center font-bold text-gray-700">2</div>
                            Run Website Scan (hypercorecyber.com)
                        </CardTitle>
                         <CardDescription>Perform a quick, automated scan of your public-facing website. (Estimated time: 15 minutes)</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <ol className="list-decimal list-inside space-y-2 mb-4">
                            <li>Launch OWASP ZAP.</li>
                            <li>In the "Quick Start" tab, find the **Automated Scan** section.</li>
                            <li>In the "URL to attack" field, enter:</li>
                        </ol>
                        <CodeBlock content="https://hypercorecyber.com" />
                        <p className="mt-4">Click the **Attack** button. ZAP will now crawl your website and perform a baseline scan for common vulnerabilities.</p>
                    </CardContent>
                </Card>

                {/* Step 3: API Scan */}
                <Card className="border-blue-200">
                    <CardHeader>
                        <CardTitle className="flex items-center gap-3 text-blue-800">
                            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center font-bold">3</div>
                            Run API Scan (api.hypercorecyber.com)
                        </CardTitle>
                        <CardDescription>This is the most critical test. Scan your live API endpoints. (Estimated time: 30 minutes)</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <p className="mb-4">APIs are a primary target for attackers. This test will verify that your Lambda-hosted functions are secure.</p>
                        <ol className="list-decimal list-inside space-y-2 mb-4">
                            <li>Wait for the first scan to complete.</li>
                            <li>Go back to the **Quick Start > Automated Scan** section.</li>
                            <li>Enter your primary API gateway URL:</li>
                        </ol>
                        <CodeBlock content="https://api.hypercorecyber.com" />
                        <p className="mt-4">Click **Attack**. ZAP will attempt to find and test endpoints like `/v1/analyzer` and `/v1/drift`.</p>
                        <Alert className="mt-4">
                            <Terminal className="h-4 w-4" />
                            <AlertTitle>For Deeper Scans (Advanced)</AlertTitle>
                            <AlertDescription>
                                For a more thorough API scan, you can import your API definition (like an OpenAPI/Swagger file) into ZAP. This tells ZAP exactly which endpoints to test. This is not required for the initial report but is a best practice.
                            </AlertDescription>
                        </Alert>
                    </CardContent>
                </Card>

                {/* Step 4: Review and Export */}
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-3">
                            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center font-bold text-gray-700">4</div>
                            Review and Export the Report
                        </CardTitle>
                        <CardDescription>Generate the PDF evidence for your prime contractor demos. (Estimated time: 5 minutes)</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <p className="mb-4">Once the scans are complete, check the "Alerts" tab at the bottom of the ZAP window. You are looking for:</p>
                        <ul className="list-disc list-inside space-y-2 mb-4">
                            <li><span className="font-semibold text-red-600">0 High Risk Alerts</span> (Flags like SQL Injection, OS Command Injection)</li>
                            <li><span className="font-semibold text-orange-600">0 Medium Risk Alerts</span> (Flags like Cross-Site Scripting)</li>
                        </ul>
                        <p className="mb-4">To generate the report:</p>
                        <ol className="list-decimal list-inside space-y-2 mb-4">
                            <li>In the top menu, go to **Report > Generate Report...**</li>
                            <li>Choose a template (the "Traditional HTML Report" is a good start).</li>
                            <li>Save the report. You can then print this to PDF.</li>
                        </ol>
                        <p>This exported report is your proof of security.</p>
                    </CardContent>
                </Card>

                {/* Success Card */}
                <Card className="bg-green-50 border-green-200">
                    <CardHeader>
                        <CardTitle className="flex items-center gap-3 text-green-800"><CheckCircle /> Action Complete: You Have Real Security Evidence</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-green-700">You now have a tangible, third-party validated penetration test report. Add the key findings (e.g., a screenshot of the "0 High, 0 Medium" alerts) to your Canva presentation for prime contractors.</p>
                        <p className="text-green-700 mt-2">Your pitch is now: <strong className="italic">"We conduct weekly penetration tests using industry-standard tools like OWASP ZAP. Here is our latest report, showing zero critical vulnerabilities."</strong></p>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}