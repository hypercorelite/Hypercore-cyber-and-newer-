import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, AlertTriangle, Loader2, PlayCircle, Code, Mail, Shield } from 'lucide-react';
import { toast } from "sonner";
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";
import { testEmailSystem } from "@/api/functions";
import { sendEmail } from "@/api/functions";

export default function EmailInfrastructure() {
    const [testResults, setTestResults] = useState({});
    const [loading, setLoading] = useState({});

    const runTest = async (testName, testFunction, params = {}) => {
        setLoading(prev => ({ ...prev, [testName]: true }));
        try {
            const { data } = await testFunction(params);
            setTestResults(prev => ({ ...prev, [testName]: { success: true, message: data.message || JSON.stringify(data) } }));
            toast.success(`✅ ${testName} test passed!`);
        } catch (error) {
            const errorMessage = error.response?.data?.error || error.message;
            setTestResults(prev => ({ ...prev, [testName]: { success: false, message: errorMessage } }));
            toast.error(`❌ ${testName} test failed.`);
        } finally {
            setLoading(prev => ({ ...prev, [testName]: false }));
        }
    };

    const runAttachmentTest = () => {
        const fileContent = "This is a test file for attachment deliverability.";
        const base64Content = btoa(fileContent);
        const attachment = {
            content: base64Content,
            filename: "test-attachment.txt",
            type: "text/plain",
            disposition: "attachment"
        };
        runTest('Attachment Test', testEmailSystem, { 
            subject: "HyperCore Attachment Test", 
            html: "<p>This email contains a test attachment.</p>",
            attachments: [attachment] 
        });
    };

    const TestCard = ({ title, description, testName, onClick }) => (
        <Card>
            <CardHeader>
                <CardTitle className="flex items-center gap-2">
                    <PlayCircle className="w-5 h-5 text-blue-600" />
                    {title}
                </CardTitle>
                <CardDescription>{description}</CardDescription>
            </CardHeader>
            <CardContent>
                <Button onClick={onClick} disabled={loading[testName]}>
                    {loading[testName] ? <Loader2 className="w-4 h-4 mr-2 animate-spin"/> : <PlayCircle className="w-4 h-4 mr-2" />}
                    Run Test
                </Button>
                {testResults[testName] && (
                    <Alert className={`mt-4 ${testResults[testName].success ? 'bg-green-50 border-green-200 text-green-800' : 'bg-red-50 border-red-200 text-red-800'}`}>
                        {testResults[testName].success ? <CheckCircle className="h-4 w-4" /> : <AlertTriangle className="h-4 w-4" />}
                        <AlertTitle>{testResults[testName].success ? 'Test Passed' : 'Test Failed'}</AlertTitle>
                        <AlertDescription className="text-xs break-words">
                            {testResults[testName].message}
                        </AlertDescription>
                    </Alert>
                )}
            </CardContent>
        </Card>
    );

    const dnsRecords = [
        { type: 'TXT (SPF)', host: '@', value: 'v=spf1 include:sendgrid.net -all', status: 'Active' },
        { type: 'CNAME (DKIM)', host: 's1._domainkey', value: 's1._domainkey.u123.sendgrid.net', status: 'Active' },
        { type: 'CNAME (DKIM)', host: 's2._domainkey', value: 's2._domainkey.u123.sendgrid.net', status: 'Active' },
        { type: 'TXT (DMARC)', host: '_dmarc', value: 'v=DMARC1; p=quarantine; rua=mailto:dmarc@hypercorecyber.com', status: 'Active' },
    ];

    return (
        <div className="space-y-8">
            <BreadcrumbNav currentPageName="EmailInfrastructure" />
            
            <CardHeader className="px-0">
                <CardTitle className="text-3xl font-bold flex items-center gap-3">
                    <Mail className="w-8 h-8 text-blue-600" />
                    Email Infrastructure & Deliverability
                </CardTitle>
                <CardDescription>
                    Manage and verify your email sending infrastructure, including SendGrid integration, DNS records, and deliverability tests.
                </CardDescription>
            </CardHeader>

            <div className="grid md:grid-cols-3 gap-8">
                <TestCard 
                    title="SendGrid Configuration Check"
                    description="Verifies that SendGrid API keys and the verified sender email are correctly configured in your environment."
                    testName="SendGrid Config"
                    onClick={() => runTest('SendGrid Config', sendEmail, { diagnosticMode: true })}
                />
                <TestCard 
                    title="Live Deliverability Test"
                    description="Sends a standard test email to your logged-in user account to confirm end-to-end email delivery."
                    testName="Deliverability"
                    onClick={() => runTest('Deliverability', testEmailSystem)}
                />
                <TestCard 
                    title="Attachment Deliverability Test"
                    description="Sends a test email with a text file attachment to confirm that attachments are being delivered correctly."
                    testName="Attachment Test"
                    onClick={runAttachmentTest}
                />
            </div>

            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Shield className="w-5 h-5 text-green-600"/>
                        DNS Records for Email Authentication
                    </CardTitle>
                    <CardDescription>
                        These are the essential DNS records for ensuring high email deliverability. They should be configured in your domain's DNS provider (e.g., AWS Route 53).
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="overflow-x-auto">
                        <table className="w-full text-sm">
                            <thead>
                                <tr className="text-left border-b">
                                    <th className="p-2">Type</th>
                                    <th className="p-2">Host</th>
                                    <th className="p-2">Value</th>
                                    <th className="p-2">Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                {dnsRecords.map((record, index) => (
                                    <tr key={index} className="border-b">
                                        <td className="p-2 font-mono bg-gray-50">{record.type}</td>
                                        <td className="p-2 font-mono">{record.host}</td>
                                        <td className="p-2 font-mono break-all">{record.value}</td>
                                        <td className="p-2">
                                            <Badge className={record.status === 'Active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}>
                                                {record.status}
                                            </Badge>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </CardContent>
            </Card>

            <Alert>
                <Code className="h-4 w-4" />
                <AlertTitle>Developer Note</AlertTitle>
                <AlertDescription>
                    The `sendEmail` function has been enhanced to support attachments. You can now pass an `attachments` array in the payload, with each object containing base64 content, a filename, and a MIME type. This makes your native system even more powerful for sending reports and proposals.
                </AlertDescription>
            </Alert>
        </div>
    );
}