import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CheckCircle, AlertTriangle, ArrowRight, Phone, Mail, Github, Cloud, Bot, Users, FileText, Zap, Target, DollarSign } from 'lucide-react';
import { motion } from "framer-motion";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const gapsAndOpportunities = [
    {
        category: "Infrastructure Gaps",
        priority: "HIGH",
        items: [
            {
                issue: "No automated phone callback system",
                impact: "Missing 40%+ of leads who prefer phone contact",
                solution: "Implement CallRail + Calendly integration",
                cost: "$89/month",
                timeline: "1 week"
            },
            {
                issue: "Manual CRM data entry",
                impact: "Time-consuming lead management",
                solution: "Zapier automation between forms, CallRail, and CRM",
                cost: "$20/month",
                timeline: "2 days"
            },
            {
                issue: "No email sequences for nurturing",
                impact: "Prospects go cold after initial contact",
                solution: "Automated drip campaigns in existing SendGrid",
                cost: "$0 (existing)",
                timeline: "3 days"
            }
        ],
        color: "border-red-200 bg-red-50"
    },
    {
        category: "Customer Engagement Gaps",
        priority: "MEDIUM",
        items: [
            {
                issue: "Generic documentation templates",
                impact: "Competitors can copy your approach",
                solution: "AI-powered client-specific document generation",
                cost: "Development time",
                timeline: "1 week"
            },
            {
                issue: "No client progress tracking",
                impact: "Manual follow-ups, missed milestones",
                solution: "Automated milestone tracking with email alerts",
                cost: "$0 (existing platform)",
                timeline: "2 days"
            },
            {
                issue: "Limited client self-service",
                impact: "Higher support burden on you",
                solution: "Client portal with AI chat assistant",
                cost: "Development time",
                timeline: "1 week"
            }
        ],
        color: "border-yellow-200 bg-yellow-50"
    },
    {
        category: "Competitive Advantages",
        priority: "OPPORTUNITY",
        items: [
            {
                issue: "Static competitor templates",
                impact: "Your AI can create dynamic, client-specific docs",
                solution: "Emphasize custom AI documentation in marketing",
                cost: "$0",
                timeline: "Immediate"
            },
            {
                issue: "No competitor has integrated CRM + assessment + docs",
                impact: "You can offer seamless end-to-end experience",
                solution: "Market as 'All-in-One CMMC Preparation Platform'",
                cost: "$0",
                timeline: "Immediate"
            },
            {
                issue: "Competitors use hourly billing",
                impact: "Fixed-fee model is major differentiator",
                solution: "Lead with transparent pricing in all marketing",
                cost: "$0",
                timeline: "Immediate"
            }
        ],
        color: "border-green-200 bg-green-50"
    }
];

const infrastructureRecommendations = {
    phone: {
        recommended: "CallRail + Calendly",
        features: [
            "Local/toll-free numbers",
            "Call recording and transcription",
            "Automatic lead scoring",
            "Integration with your CRM",
            "Missed call text-back automation"
        ],
        cost: "$89/month",
        setup: "2 hours",
        roi: "30%+ increase in qualified leads"
    },
    email: {
        current: "SendGrid (keep)",
        enhancements: [
            "Add automated drip sequences",
            "Implement email scoring/tracking",
            "Set up behavioral triggers",
            "Add email templates for each client phase"
        ],
        cost: "$0 (existing plan sufficient)",
        setup: "1 day",
        roi: "25% improvement in client engagement"
    },
    aws_migration: {
        current_status: "Vercel → AWS migration needed",
        benefits: [
            "Enterprise credibility for defense contractors",
            "Inherited CMMC controls (major selling point)",
            "Lower long-term costs",
            "Better integration with AWS Config/Security Hub"
        ],
        timeline: "2 weeks",
        cost: "$50/month vs current $240/month",
        immediate_action: "Set up AWS Lambda + RDS free tier"
    }
};

const customerEngagementAutomation = [
    {
        trigger: "New inquiry submitted",
        actions: [
            "Send immediate confirmation with next steps",
            "Add to CRM with 'warm lead' tag",
            "Schedule 24-hour follow-up reminder",
            "Send educational email sequence (5 emails over 2 weeks)"
        ]
    },
    {
        trigger: "Client signs agreement",
        actions: [
            "Create project in CRM",
            "Send welcome package with Phase 1 deliverables",
            "Schedule kickoff call automatically",
            "Begin weekly check-in sequence"
        ]
    },
    {
        trigger: "Client misses milestone",
        actions: [
            "Send gentle reminder with specific next steps",
            "Flag for personal follow-up if 3 days overdue",
            "Offer additional support resources"
        ]
    }
];

export default function PlatformAssessment() {
    return (
        <div className="space-y-8">
            <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center"
            >
                <h1 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-3">
                    Platform Assessment & Strategic Recommendations
                </h1>
                <p className="text-lg lg:text-xl text-gray-600">
                    Complete analysis of gaps, opportunities, and infrastructure improvements for maximum automation and competitive advantage.
                </p>
            </motion.div>

            {/* Executive Summary */}
            <Alert className="bg-blue-50 border-blue-200">
                <Target className="h-4 w-4 text-blue-600" />
                <AlertTitle className="text-blue-800">Executive Summary</AlertTitle>
                <AlertDescription className="text-blue-700">
                    <strong>Platform is 80% ready for scale.</strong> Key gaps: phone system integration and automated nurturing sequences. 
                    Estimated 2 weeks to achieve 95% hands-off automation. ROI: 50%+ increase in qualified leads, 70% reduction in manual work.
                </AlertDescription>
            </Alert>

            {/* Gaps Analysis */}
            <div className="space-y-6">
                <h2 className="text-2xl font-bold text-gray-800">Gaps & Opportunities Analysis</h2>
                {gapsAndOpportunities.map((category, index) => (
                    <Card key={index} className={`${category.color} border-2`}>
                        <CardHeader>
                            <div className="flex justify-between items-center">
                                <CardTitle>{category.category}</CardTitle>
                                <Badge variant={category.priority === 'HIGH' ? 'destructive' : category.priority === 'MEDIUM' ? 'secondary' : 'default'}>
                                    {category.priority}
                                </Badge>
                            </div>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-4">
                                {category.items.map((item, i) => (
                                    <div key={i} className="border-l-4 border-gray-300 pl-4">
                                        <h4 className="font-semibold text-gray-800">{item.issue}</h4>
                                        <p className="text-sm text-gray-600 mb-2">{item.impact}</p>
                                        <div className="flex flex-wrap gap-2 text-xs">
                                            <Badge variant="outline">💡 {item.solution}</Badge>
                                            <Badge variant="outline">💰 {item.cost}</Badge>
                                            <Badge variant="outline">⏱️ {item.timeline}</Badge>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>
                ))}
            </div>

            {/* Infrastructure Recommendations */}
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                        <Cloud className="w-6 h-6" />
                        Infrastructure Upgrade Roadmap
                    </CardTitle>
                    <CardDescription>Specific recommendations for backend systems and automation</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    
                    {/* Phone System */}
                    <div className="border rounded-lg p-4">
                        <div className="flex items-center gap-3 mb-3">
                            <Phone className="w-5 h-5 text-blue-600" />
                            <h3 className="font-semibold">Phone & Callback System</h3>
                        </div>
                        <div className="grid md:grid-cols-2 gap-4">
                            <div>
                                <p className="font-medium text-sm mb-2">Recommended: {infrastructureRecommendations.phone.recommended}</p>
                                <ul className="text-sm space-y-1">
                                    {infrastructureRecommendations.phone.features.map((feature, i) => (
                                        <li key={i} className="flex items-center gap-2">
                                            <CheckCircle className="w-3 h-3 text-green-500" />
                                            {feature}
                                        </li>
                                    ))}
                                </ul>
                            </div>
                            <div className="space-y-2">
                                <Badge className="bg-green-100 text-green-800">Cost: {infrastructureRecommendations.phone.cost}</Badge>
                                <Badge className="bg-blue-100 text-blue-800">Setup: {infrastructureRecommendations.phone.setup}</Badge>
                                <Badge className="bg-purple-100 text-purple-800">ROI: {infrastructureRecommendations.phone.roi}</Badge>
                            </div>
                        </div>
                    </div>

                    {/* Email Enhancement */}
                    <div className="border rounded-lg p-4">
                        <div className="flex items-center gap-3 mb-3">
                            <Mail className="w-5 h-5 text-green-600" />
                            <h3 className="font-semibold">Email System Enhancement</h3>
                        </div>
                        <div className="grid md:grid-cols-2 gap-4">
                            <div>
                                <p className="font-medium text-sm mb-2">Current: {infrastructureRecommendations.email.current}</p>
                                <ul className="text-sm space-y-1">
                                    {infrastructureRecommendations.email.enhancements.map((enhancement, i) => (
                                        <li key={i} className="flex items-center gap-2">
                                            <ArrowRight className="w-3 h-3 text-blue-500" />
                                            {enhancement}
                                        </li>
                                    ))}
                                </ul>
                            </div>
                            <div className="space-y-2">
                                <Badge className="bg-green-100 text-green-800">Cost: {infrastructureRecommendations.email.cost}</Badge>
                                <Badge className="bg-blue-100 text-blue-800">Setup: {infrastructureRecommendations.email.setup}</Badge>
                                <Badge className="bg-purple-100 text-purple-800">ROI: {infrastructureRecommendations.email.roi}</Badge>
                            </div>
                        </div>
                    </div>

                    {/* AWS Migration */}
                    <div className="border rounded-lg p-4">
                        <div className="flex items-center gap-3 mb-3">
                            <Github className="w-5 h-5 text-orange-600" />
                            <h3 className="font-semibold">AWS Migration Strategy</h3>
                        </div>
                        <div className="grid md:grid-cols-2 gap-4">
                            <div>
                                <p className="font-medium text-sm mb-2">Status: {infrastructureRecommendations.aws_migration.current_status}</p>
                                <ul className="text-sm space-y-1">
                                    {infrastructureRecommendations.aws_migration.benefits.map((benefit, i) => (
                                        <li key={i} className="flex items-center gap-2">
                                            <CheckCircle className="w-3 h-3 text-green-500" />
                                            {benefit}
                                        </li>
                                    ))}
                                </ul>
                            </div>
                            <div className="space-y-2">
                                <Badge className="bg-green-100 text-green-800">Savings: {infrastructureRecommendations.aws_migration.cost}</Badge>
                                <Badge className="bg-blue-100 text-blue-800">Timeline: {infrastructureRecommendations.aws_migration.timeline}</Badge>
                                <p className="text-sm font-medium">Action: {infrastructureRecommendations.aws_migration.immediate_action}</p>
                            </div>
                        </div>
                    </div>
                </CardContent>
            </Card>

            {/* Customer Engagement Automation */}
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                        <Bot className="w-6 h-6" />
                        Hands-Off Customer Engagement Automation
                    </CardTitle>
                    <CardDescription>Automated workflows to minimize your manual intervention</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="space-y-4">
                        {customerEngagementAutomation.map((workflow, index) => (
                            <div key={index} className="border-l-4 border-blue-200 pl-4">
                                <h4 className="font-semibold text-gray-800 mb-2">{workflow.trigger}</h4>
                                <ul className="space-y-1">
                                    {workflow.actions.map((action, i) => (
                                        <li key={i} className="text-sm flex items-center gap-2">
                                            <Zap className="w-3 h-3 text-yellow-500" />
                                            {action}
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>

            {/* AI-Powered Custom Documentation */}
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                        <FileText className="w-6 h-6" />
                        AI-Powered Custom Documentation Strategy
                    </CardTitle>
                    <CardDescription>How to leverage AI to create client-specific documents that competitors can't replicate</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="grid md:grid-cols-2 gap-6">
                        <div>
                            <h4 className="font-semibold mb-3">Competitor Weakness</h4>
                            <ul className="space-y-2 text-sm">
                                <li className="flex items-center gap-2">
                                    <AlertTriangle className="w-4 h-4 text-red-500" />
                                    Static fill-in-the-blank templates
                                </li>
                                <li className="flex items-center gap-2">
                                    <AlertTriangle className="w-4 h-4 text-red-500" />
                                    Generic industry language
                                </li>
                                <li className="flex items-center gap-2">
                                    <AlertTriangle className="w-4 h-4 text-red-500" />
                                    No integration with client systems
                                </li>
                                <li className="flex items-center gap-2">
                                    <AlertTriangle className="w-4 h-4 text-red-500" />
                                    Manual document assembly
                                </li>
                            </ul>
                        </div>
                        <div>
                            <h4 className="font-semibold mb-3">Your AI Advantage</h4>
                            <ul className="space-y-2 text-sm">
                                <li className="flex items-center gap-2">
                                    <CheckCircle className="w-4 h-4 text-green-500" />
                                    Dynamic content based on client assessment
                                </li>
                                <li className="flex items-center gap-2">
                                    <CheckCircle className="w-4 h-4 text-green-500" />
                                    Industry-specific language and examples
                                </li>
                                <li className="flex items-center gap-2">
                                    <CheckCircle className="w-4 h-4 text-green-500" />
                                    Real-time system integration details
                                </li>
                                <li className="flex items-center gap-2">
                                    <CheckCircle className="w-4 h-4 text-green-500" />
                                    Instant document generation and updates
                                </li>
                            </ul>
                        </div>
                    </div>
                    <Alert className="mt-4">
                        <Bot className="h-4 w-4" />
                        <AlertTitle>Implementation Strategy</AlertTitle>
                        <AlertDescription>
                            Position your AI as creating "living documents" that adapt to each client's specific environment, 
                            versus competitors' static templates. This becomes a key sales differentiator and retention tool.
                        </AlertDescription>
                    </Alert>
                </CardContent>
            </Card>

            {/* Implementation Priority */}
            <Card className="bg-gray-900 text-white">
                <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                        <Target className="w-6 h-6" />
                        Implementation Priority & Timeline
                    </CardTitle>
                    <CardDescription className="text-gray-300">Recommended order of implementation for maximum impact</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="space-y-4">
                        <div className="flex items-center justify-between p-3 bg-gray-800 rounded">
                            <span><strong>Week 1:</strong> Set up CallRail phone system + Calendly integration</span>
                            <Badge className="bg-red-600">HIGH IMPACT</Badge>
                        </div>
                        <div className="flex items-center justify-between p-3 bg-gray-800 rounded">
                            <span><strong>Week 1:</strong> Create automated email nurturing sequences</span>
                            <Badge className="bg-red-600">HIGH IMPACT</Badge>
                        </div>
                        <div className="flex items-center justify-between p-3 bg-gray-800 rounded">
                            <span><strong>Week 2:</strong> Implement Zapier automation for CRM data flow</span>
                            <Badge className="bg-yellow-600">MEDIUM IMPACT</Badge>
                        </div>
                        <div className="flex items-center justify-between p-3 bg-gray-800 rounded">
                            <span><strong>Week 3-4:</strong> AWS migration and inherited controls marketing</span>
                            <Badge className="bg-green-600">STRATEGIC</Badge>
                        </div>
                        <div className="flex items-center justify-between p-3 bg-gray-800 rounded">
                            <span><strong>Ongoing:</strong> Enhance AI documentation with client-specific features</span>
                            <Badge className="bg-blue-600">COMPETITIVE ADVANTAGE</Badge>
                        </div>
                    </div>
                </CardContent>
            </Card>

            {/* Total Investment */}
            <Alert className="bg-green-50 border-green-200">
                <DollarSign className="h-4 w-4 text-green-600" />
                <AlertTitle className="text-green-800">Total Investment Required</AlertTitle>
                <AlertDescription className="text-green-700">
                    <strong>Monthly: $109</strong> (CallRail $89 + Zapier $20)<br/>
                    <strong>One-time setup: 2 weeks development time</strong><br/>
                    <strong>Expected ROI: 200%+ within 90 days through increased lead conversion and reduced manual work</strong>
                </AlertDescription>
            </Alert>
        </div>
    );
}