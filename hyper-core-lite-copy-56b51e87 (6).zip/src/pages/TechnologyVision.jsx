import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Shield, Users, Zap, CheckCircle, AlertTriangle, Network, Clock, DollarSign, Target, Flag } from 'lucide-react';
import { motion } from "framer-motion";
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";

const infrastructureFramework = [
    {
        pillar: "Mission Continuity Assurance",
        description: "Preventing supply chain disruption due to compliance failures",
        critical_functions: [
            "Instant compliance verification for contract awards",
            "Real-time monitoring prevents contract suspension",
            "Automated remediation reduces mission downtime to zero",
            "24/7 compliance status ensures uninterrupted operations"
        ],
        national_security_impact: "Eliminates compliance-related delays in critical defense programs",
        roi_for_dod: "Prevents $50M-$500M in program delays per incident"
    },
    {
        pillar: "SMB Ecosystem Stabilization", 
        description: "Keeping 31,500 small contractors viable and compliant",
        critical_functions: [
            "Reduces compliance costs by 90% → keeps SMBs profitable",
            "Eliminates 18-month certification delays → maintains cash flow",
            "Prevents False Claims Act violations → protects business survival",
            "Automated updates ensure continuous compliance → no surprise failures"
        ],
        national_security_impact: "Preserves innovation capacity of small defense contractors",
        roi_for_dod: "Maintains competitive pricing through healthy SMB competition"
    },
    {
        pillar: "Supply Chain Resilience",
        description: "Creating redundant, reliable contractor networks", 
        critical_functions: [
            "Rapid onboarding of new contractors in crisis situations",
            "Instant compliance scoring for supplier risk assessment",
            "Geographic distribution analysis prevents single points of failure",
            "Cross-contractor capability mapping for surge capacity"
        ],
        national_security_impact: "Enables rapid military mobilization through robust contractor base",
        roi_for_dod: "Reduces dependency on prime contractors, increases negotiation leverage"
    },
    {
        pillar: "Threat Intelligence Integration",
        description: "Converting compliance data into actionable security intelligence",
        critical_functions: [
            "Aggregated threat patterns across 20K+ contractor networks", 
            "Early warning system for supply chain vulnerabilities",
            "Anonymous intelligence sharing without compromising contractors",
            "Predictive modeling for emerging cyber threats"
        ],
        national_security_impact: "Creates unprecedented visibility into DIB cyber posture",
        roi_for_dod: "Prevents breaches through predictive intelligence vs. reactive response"
    }
];

const missionCriticalScenarios = [
    {
        scenario: "Rapid Military Mobilization",
        traditional_problem: "18-month compliance timeline blocks urgent contractor onboarding",
        hypercore_solution: "New contractors compliant and operational within 72 hours",
        strategic_value: "Maintains US rapid response capability in crisis situations"
    },
    {
        scenario: "Major Contractor Cyber Breach",
        traditional_problem: "Supply chain disruption while manual assessment of alternatives takes months",
        hypercore_solution: "Instant identification of compliant backup contractors with equivalent capabilities",
        strategic_value: "Prevents single points of failure from crippling defense programs"
    },
    {
        scenario: "Evolving Threat Landscape",
        traditional_problem: "Static policies can't adapt to new threats; manual updates take 6-18 months",
        hypercore_solution: "AI-driven policy updates push to entire contractor base within hours",
        strategic_value: "Maintains technological superiority through adaptive security posture"
    },
    {
        scenario: "Congressional/GAO Investigation",
        traditional_problem: "Scattered compliance data across contractors makes oversight impossible",
        hypercore_solution: "Instant, comprehensive DIB compliance reporting and audit trails",
        strategic_value: "Demonstrates DoD stewardship of taxpayer funds and national security"
    }
];

const infrastructureMetrics = [
    {
        metric: "Supply Chain Uptime",
        current_state: "85% (compliance failures cause 15% downtime)", 
        hypercore_state: "99.9% (automated prevention of compliance failures)",
        impact: "Prevents $2.3B annually in program delays"
    },
    {
        metric: "Contractor Onboarding Speed",
        current_state: "12-18 months average time to compliance",
        hypercore_state: "72 hours from start to operational compliance", 
        impact: "Enables rapid surge capacity for national emergencies"
    },
    {
        metric: "False Claims Act Risk",
        current_state: "High risk due to manual documentation errors",
        hypercore_state: "Near-zero risk through AI-verified accuracy",
        impact: "Saves DoD $100M+ annually in contractor legal costs"
    },
    {
        metric: "Threat Intelligence Velocity",
        current_state: "Months to identify and respond to new threats",
        hypercore_state: "Hours to analyze, adapt, and deploy countermeasures",
        impact: "Maintains technological edge through adaptive security"
    }
];

export default function TechnologyVision() {
    return (
        <div className="space-y-8 p-4 md:p-6">
            <BreadcrumbNav currentPageName="TechnologyVision" />
            
            <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center"
            >
                <Badge className="mb-4 bg-red-100 text-red-800">NATIONAL SECURITY INFRASTRUCTURE</Badge>
                <h1 className="text-4xl font-bold text-gray-900 mb-4 flex items-center justify-center gap-3">
                    <Shield className="w-10 h-10 text-blue-600" />
                    Essential DIB Infrastructure: HyperCore as Mission-Critical Platform
                </h1>
                <p className="text-xl text-gray-600 max-w-5xl mx-auto">
                    How HyperCore evolves from compliance tool to essential Defense Industrial Base infrastructure, ensuring mission continuity, supply chain resilience, and national security advantage.
                </p>
            </motion.div>

            <Alert className="bg-blue-50 border-blue-200">
                <Flag className="h-4 w-4 text-blue-600" />
                <AlertTitle className="text-blue-800 font-bold">Strategic Vision: The DIB's Operating System</AlertTitle>
                <AlertDescription className="text-blue-700">
                    By 2030, HyperCore becomes the invisible infrastructure that keeps America's defense industrial base secure, compliant, and mission-ready 24/7. Like electrical grids or internet backbone, it's only noticed when it's missing—and absolutely critical when it's needed.
                </AlertDescription>
            </Alert>

            {/* Four Pillars of Essential Infrastructure */}
            <div className="space-y-8">
                <h2 className="text-3xl font-bold text-center text-gray-900 mb-8">The Four Pillars of DIB Infrastructure</h2>
                {infrastructureFramework.map((pillar, index) => (
                    <motion.div
                        key={index}
                        initial={{ opacity: 0, x: index % 2 === 0 ? -20 : 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.15 }}
                    >
                        <Card className={`border-l-4 ${
                            index === 0 ? 'border-red-500 bg-red-50' :
                            index === 1 ? 'border-blue-500 bg-blue-50' :
                            index === 2 ? 'border-green-500 bg-green-50' :
                            'border-purple-500 bg-purple-50'
                        }`}>
                            <CardHeader>
                                <CardTitle className="text-2xl">{pillar.pillar}</CardTitle>
                                <CardDescription className="text-lg">{pillar.description}</CardDescription>
                            </CardHeader>
                            <CardContent className="space-y-6">
                                <div>
                                    <h4 className="font-semibold text-lg mb-3">Critical Functions:</h4>
                                    <ul className="space-y-2">
                                        {pillar.critical_functions.map((func, i) => (
                                            <li key={i} className="flex items-start gap-2">
                                                <CheckCircle className="w-5 h-5 text-green-600 mt-0.5 flex-shrink-0" />
                                                <span>{func}</span>
                                            </li>
                                        ))}
                                    </ul>
                                </div>
                                
                                <div className="grid md:grid-cols-2 gap-4 pt-4 border-t">
                                    <div>
                                        <h5 className="font-semibold text-blue-800 mb-2">National Security Impact:</h5>
                                        <p className="text-blue-700">{pillar.national_security_impact}</p>
                                    </div>
                                    <div>
                                        <h5 className="font-semibold text-green-800 mb-2">DoD ROI:</h5>
                                        <p className="text-green-700">{pillar.roi_for_dod}</p>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    </motion.div>
                ))}
            </div>

            {/* Mission-Critical Scenarios */}
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                        <Target className="w-6 h-6 text-red-600" />
                        Mission-Critical Scenarios: When DIB Infrastructure Matters Most
                    </CardTitle>
                    <CardDescription>
                        Real-world scenarios where HyperCore's infrastructure role becomes essential to national security
                    </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    {missionCriticalScenarios.map((scenario, index) => (
                        <div key={index} className="p-6 bg-gradient-to-r from-gray-50 to-gray-100 rounded-lg border">
                            <h4 className="text-xl font-bold text-red-800 mb-4">{scenario.scenario}</h4>
                            <div className="grid md:grid-cols-3 gap-4 text-sm">
                                <div className="p-3 bg-red-50 rounded border-l-4 border-red-500">
                                    <h5 className="font-semibold text-red-700 mb-2">Traditional Problem:</h5>
                                    <p className="text-red-600">{scenario.traditional_problem}</p>
                                </div>
                                <div className="p-3 bg-green-50 rounded border-l-4 border-green-500">
                                    <h5 className="font-semibold text-green-700 mb-2">HyperCore Solution:</h5>
                                    <p className="text-green-600">{scenario.hypercore_solution}</p>
                                </div>
                                <div className="p-3 bg-blue-50 rounded border-l-4 border-blue-500">
                                    <h5 className="font-semibold text-blue-700 mb-2">Strategic Value:</h5>
                                    <p className="text-blue-600">{scenario.strategic_value}</p>
                                </div>
                            </div>
                        </div>
                    ))}
                </CardContent>
            </Card>

            {/* Infrastructure Performance Metrics */}
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                        <Network className="w-6 h-6 text-purple-600" />
                        Infrastructure Performance Metrics: Measuring Mission Impact
                    </CardTitle>
                    <CardDescription>
                        Quantifiable improvements to DIB performance through HyperCore infrastructure
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="grid md:grid-cols-2 gap-6">
                        {infrastructureMetrics.map((metric, index) => (
                            <div key={index} className="p-6 bg-white border rounded-lg shadow-sm">
                                <h4 className="text-lg font-bold text-gray-800 mb-4">{metric.metric}</h4>
                                <div className="space-y-3">
                                    <div className="p-3 bg-red-50 rounded border border-red-200">
                                        <p className="text-sm text-red-700 font-medium">Current State:</p>
                                        <p className="text-red-800">{metric.current_state}</p>
                                    </div>
                                    <div className="p-3 bg-green-50 rounded border border-green-200">
                                        <p className="text-sm text-green-700 font-medium">With HyperCore:</p>
                                        <p className="text-green-800">{metric.hypercore_state}</p>
                                    </div>
                                    <div className="p-3 bg-blue-50 rounded border border-blue-200">
                                        <p className="text-sm text-blue-700 font-medium">National Impact:</p>
                                        <p className="text-blue-800 font-semibold">{metric.impact}</p>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>

            {/* The Flywheel Effect */}
            <Card className="bg-gradient-to-r from-purple-600 to-blue-700 text-white">
                <CardHeader>
                    <CardTitle className="text-2xl">The DIB Infrastructure Flywheel Effect</CardTitle>
                    <CardDescription className="text-purple-100">
                        How HyperCore creates compounding value for the entire defense ecosystem
                    </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6 pt-4">
                    <div className="text-center">
                        <div className="text-4xl font-bold mb-4">🔄 The Flywheel</div>
                        <p className="text-lg opacity-90 mb-6">Each additional contractor makes the entire system stronger and more valuable</p>
                    </div>
                    
                    <div className="grid md:grid-cols-2 gap-6">
                        <div className="p-4 bg-white/10 rounded-lg">
                            <h4 className="font-bold mb-2">Network Effects (Years 1-3)</h4>
                            <ul className="text-sm space-y-1 opacity-90">
                                <li>• More contractors = better threat intelligence</li>
                                <li>• Larger dataset = more accurate AI predictions</li>
                                <li>• Broader coverage = fewer supply chain gaps</li>
                                <li>• Higher volume = better DoD negotiation position</li>
                            </ul>
                        </div>
                        <div className="p-4 bg-white/10 rounded-lg">
                            <h4 className="font-bold mb-2">Platform Effects (Years 4-5)</h4>
                            <ul className="text-sm space-y-1 opacity-90">
                                <li>• DoD depends on platform for procurement decisions</li>
                                <li>• Contractors can't compete without platform access</li>
                                <li>• New regulations get pushed through platform</li>
                                <li>• Platform becomes de facto DIB operating system</li>
                            </ul>
                        </div>
                    </div>

                    <div className="pt-6 border-t border-white/20 text-center">
                        <p className="text-xl font-bold">
                            Result: HyperCore becomes as essential to the DIB as<br/>
                            GPS is to navigation or TCP/IP is to the internet.
                        </p>
                        <p className="text-sm opacity-75 mt-2">
                            Mission-critical, always-on, infrastructure that enables everything else to function.
                        </p>
                    </div>
                </CardContent>
            </Card>

            {/* Call to Action */}
            <Card className="text-center bg-gradient-to-br from-red-50 to-blue-50">
                <CardContent className="p-8">
                    <h3 className="text-2xl font-bold text-gray-900 mb-4">
                        From Compliance Tool to National Security Infrastructure
                    </h3>
                    <p className="text-lg text-gray-600 mb-6 max-w-3xl mx-auto">
                        This isn't just about building a successful company—it's about creating essential infrastructure that ensures America maintains its technological superiority and defense readiness in an increasingly complex threat landscape.
                    </p>
                    <Button size="lg" className="bg-red-600 hover:bg-red-700">
                        <Shield className="w-5 h-5 mr-2" />
                        Build Essential DIB Infrastructure
                    </Button>
                </CardContent>
            </Card>
        </div>
    );
}