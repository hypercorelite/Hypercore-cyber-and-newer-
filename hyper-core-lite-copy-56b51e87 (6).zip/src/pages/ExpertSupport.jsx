import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { MessageSquare, Mail, Loader2, CheckCircle } from 'lucide-react';
import { SupportTicket } from "@/api/entities";
import { sendEmail } from "@/api/functions";
import { toast } from "sonner";

export default function ExpertSupport() {
    const [ticket, setTicket] = useState({
        client_name: '',
        client_email: '',
        subject: '',
        description: '',
        priority: 'medium',
        source: 'portal_form'
    });
    const [loading, setLoading] = useState(false);
    const [submitted, setSubmitted] = useState(false);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);

        try {
            // Create support ticket
            const supportTicket = await SupportTicket.create({
                ...ticket,
                status: 'new',
                conversation: [{
                    sender: 'client',
                    message: ticket.description,
                    timestamp: new Date().toISOString()
                }]
            });

            // Send email to client (confirmation)
            await sendEmail({
                to: ticket.client_email,
                subject: `Support Ticket Created: ${ticket.subject}`,
                html: `
                    <h2>Support Ticket Confirmation</h2>
                    <p>Hi ${ticket.client_name},</p>
                    <p>We've received your support request and will respond within 24 hours.</p>
                    
                    <div style="background: #f5f5f5; padding: 15px; margin: 20px 0; border-radius: 5px;">
                        <strong>Ticket ID:</strong> ${supportTicket.id}<br/>
                        <strong>Subject:</strong> ${ticket.subject}<br/>
                        <strong>Priority:</strong> ${ticket.priority}
                    </div>
                    
                    <p>Your message:</p>
                    <div style="background: #f9f9f9; padding: 10px; border-left: 3px solid #007bff;">
                        ${ticket.description}
                    </div>
                    
                    <p>Best regards,<br/>HyperCore Support Team</p>
                `
            });

            // Send notification to admin
            await sendEmail({
                to: 'support@hypercorecmmc.com',
                subject: `New Support Ticket: ${ticket.subject}`,
                html: `
                    <h2>New Support Ticket</h2>
                    <p><strong>From:</strong> ${ticket.client_name} (${ticket.client_email})</p>
                    <p><strong>Priority:</strong> ${ticket.priority}</p>
                    <p><strong>Subject:</strong> ${ticket.subject}</p>
                    
                    <h3>Message:</h3>
                    <div style="background: #f9f9f9; padding: 15px; border: 1px solid #ddd;">
                        ${ticket.description}
                    </div>
                    
                    <p><a href="#">View in Admin Dashboard</a></p>
                `
            });

            setSubmitted(true);
            toast.success("Support ticket submitted successfully!");
        } catch (error) {
            console.error('Failed to submit support ticket:', error);
            toast.error("Failed to submit support ticket. Please try again.");
        } finally {
            setLoading(false);
        }
    };

    if (submitted) {
        return (
            <div className="min-h-screen bg-gray-50 p-6 flex items-center justify-center">
                <Card className="max-w-2xl w-full">
                    <CardContent className="text-center p-8">
                        <CheckCircle className="w-16 h-16 text-green-600 mx-auto mb-4" />
                        <h2 className="text-2xl font-bold text-gray-900 mb-4">Support Ticket Submitted!</h2>
                        <p className="text-gray-600 mb-6">
                            Thank you for contacting us. We've received your support request and will respond via email within 24 hours.
                        </p>
                        <Button onClick={() => {setSubmitted(false); setTicket({client_name: '', client_email: '', subject: '', description: '', priority: 'medium', source: 'portal_form'});}}>
                            Submit Another Request
                        </Button>
                    </CardContent>
                </Card>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gray-50 p-6">
            <div className="max-w-4xl mx-auto">
                <CardHeader className="px-0 text-center">
                    <CardTitle className="text-3xl font-bold flex items-center justify-center gap-3">
                        <MessageSquare className="w-8 h-8 text-purple-600" />
                        Expert CMMC Support
                    </CardTitle>
                    <CardDescription className="text-lg">
                        Get help from our compliance experts - we respond within 24 hours
                    </CardDescription>
                </CardHeader>

                <Alert className="mb-8 bg-blue-50 border-blue-200">
                    <Mail className="h-4 w-4 text-blue-600" />
                    <AlertDescription className="text-blue-700">
                        Our CMMC experts are here to help with implementation guidance, control interpretations, 
                        and compliance questions. All communication is via email for your records.
                    </AlertDescription>
                </Alert>

                <Card>
                    <CardHeader>
                        <CardTitle>Submit Support Request</CardTitle>
                        <CardDescription>Describe your CMMC question or issue</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <form onSubmit={handleSubmit} className="space-y-6">
                            <div className="grid md:grid-cols-2 gap-4">
                                <Input
                                    placeholder="Your Name"
                                    value={ticket.client_name}
                                    onChange={(e) => setTicket({...ticket, client_name: e.target.value})}
                                    required
                                />
                                <Input
                                    type="email"
                                    placeholder="Your Email"
                                    value={ticket.client_email}
                                    onChange={(e) => setTicket({...ticket, client_email: e.target.value})}
                                    required
                                />
                            </div>

                            <div className="grid md:grid-cols-2 gap-4">
                                <Input
                                    placeholder="Subject (e.g., 'Question about AC-2 Implementation')"
                                    value={ticket.subject}
                                    onChange={(e) => setTicket({...ticket, subject: e.target.value})}
                                    required
                                />
                                <Select value={ticket.priority} onValueChange={(value) => setTicket({...ticket, priority: value})}>
                                    <SelectTrigger>
                                        <SelectValue placeholder="Priority Level" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="low">Low - General Question</SelectItem>
                                        <SelectItem value="medium">Medium - Need Guidance</SelectItem>
                                        <SelectItem value="high">High - Urgent Issue</SelectItem>
                                        <SelectItem value="urgent">Urgent - Audit Deadline</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>

                            <Textarea
                                placeholder="Describe your question or issue in detail. Include relevant NIST control numbers if known."
                                value={ticket.description}
                                onChange={(e) => setTicket({...ticket, description: e.target.value})}
                                rows={6}
                                required
                            />

                            <Button 
                                type="submit" 
                                className="w-full" 
                                size="lg"
                                disabled={loading}
                            >
                                {loading ? (
                                    <>
                                        <Loader2 className="w-5 h-5 animate-spin mr-2" />
                                        Submitting...
                                    </>
                                ) : (
                                    <>
                                        <MessageSquare className="w-5 h-5 mr-2" />
                                        Submit Support Request
                                    </>
                                )}
                            </Button>
                        </form>
                    </CardContent>
                </Card>

                <Card className="mt-8">
                    <CardHeader>
                        <CardTitle>Common Questions</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-4">
                            <div>
                                <h4 className="font-semibold">Implementation Questions</h4>
                                <p className="text-sm text-gray-600">How to implement specific NIST 800-171 controls, evidence collection, policy creation</p>
                            </div>
                            <div>
                                <h4 className="font-semibold">Technical Guidance</h4>
                                <p className="text-sm text-gray-600">Network security configurations, access controls, audit logging setup</p>
                            </div>
                            <div>
                                <h4 className="font-semibold">Assessment Preparation</h4>
                                <p className="text-sm text-gray-600">C3PAO readiness, evidence packages, documentation requirements</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}