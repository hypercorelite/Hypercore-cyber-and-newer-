import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, Mail, Target, Zap, ExternalLink, Calendar, DollarSign } from 'lucide-react';
import { toast } from "sonner";
import { sendPrimeDocumentationPackage } from "@/api/functions";

export default function PrimeOutreachExecution() {
    const [isExecuting, setIsExecuting] = useState(false);
    const [executionResults, setExecutionResults] = useState(null);

    const executeOutreach = async () => {
        setIsExecuting(true);
        toast.info("🚀 Executing enhanced prime contractor outreach campaign...");

        try {
            const { data } = await sendPrimeDocumentationPackage({});
            setExecutionResults(data);
            
            if (data.success) {
                toast.success(`✅ Campaign executed! ${data.emailsSent}/5 emails sent successfully`);
            } else {
                toast.error("Campaign execution encountered issues - check results below");
            }
        } catch (error) {
            toast.error(`Campaign failed: ${error.message}`);
        } finally {
            setIsExecuting(false);
        }
    };

    return (
        <div className="space-y-6">
            <div className="text-center">
                <h1 className="text-3xl font-bold text-gray-900 flex items-center justify-center gap-3">
                    <Target className="w-8 h-8 text-blue-600" />
                    Prime Contractor Outreach Execution
                </h1>
                <p className="text-lg text-gray-600 mt-2">
                    Deploy enhanced email campaign with NIST validation portal and professional documentation
                </p>
            </div>

            <Card className="bg-gradient-to-r from-blue-50 to-green-50 border-blue-200">
                <CardHeader>
                    <CardTitle className="flex items-center gap-3 text-blue-800">
                        <Zap className="w-6 h-6" />
                        Week 1 Strategic Execution (September 20-26, 2025)
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="grid md:grid-cols-3 gap-4 mb-6">
                        <div className="text-center p-4 bg-white rounded-lg">
                            <div className="text-2xl font-bold text-blue-700">100%</div>
                            <div className="text-sm text-blue-600">CMMC Level 3 Accuracy</div>
                        </div>
                        <div className="text-center p-4 bg-white rounded-lg">
                            <div className="text-2xl font-bold text-green-700">$33K</div>
                            <div className="text-sm text-green-600">Average Savings/Sub</div>
                        </div>
                        <div className="text-center p-4 bg-white rounded-lg">
                            <div className="text-2xl font-bold text-purple-700">87 Days</div>
                            <div className="text-sm text-purple-600">vs. 180-360 Industry</div>
                        </div>
                    </div>

                    <div className="space-y-4">
                        <div className="flex items-center gap-3">
                            <CheckCircle className="w-5 h-5 text-green-600" />
                            <span>Enhanced email template with executive FCA risk framing</span>
                        </div>
                        <div className="flex items-center gap-3">
                            <CheckCircle className="w-5 h-5 text-green-600" />
                            <span>NIST validation portal ready for live demonstrations</span>
                        </div>
                        <div className="flex items-center gap-3">
                            <CheckCircle className="w-5 h-5 text-green-600" />
                            <span>DFARS-compliant MSA/SOW documentation portal</span>
                        </div>
                        <div className="flex items-center gap-3">
                            <CheckCircle className="w-5 h-5 text-green-600" />
                            <span>Competitive positioning vs. Vanta (85%) and Drata (80%)</span>
                        </div>
                    </div>

                    <Button 
                        onClick={executeOutreach} 
                        disabled={isExecuting}
                        className="w-full mt-6 bg-blue-600 hover:bg-blue-700 text-white"
                        size="lg"
                    >
                        {isExecuting ? 
                            <>🚀 Executing Campaign...</> : 
                            <>Execute Prime Contractor Outreach Campaign</>
                        }
                    </Button>
                </CardContent>
            </Card>

            {executionResults && (
                <div className="space-y-4">
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-3">
                                <Mail className="w-6 h-6 text-green-600" />
                                Campaign Execution Results
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="grid md:grid-cols-2 gap-4 mb-6">
                                <div className="text-center p-4 bg-green-50 rounded-lg">
                                    <div className="text-2xl font-bold text-green-700">
                                        {executionResults.emailsSent || 0}/5
                                    </div>
                                    <div className="text-sm text-green-600">Emails Sent Successfully</div>
                                </div>
                                <div className="text-center p-4 bg-blue-50 rounded-lg">
                                    <div className="text-2xl font-bold text-blue-700">2-3</div>
                                    <div className="text-sm text-blue-600">Expected Demo Responses</div>
                                </div>
                            </div>

                            {executionResults.results && (
                                <div className="space-y-3">
                                    <h4 className="font-semibold">Prime Contractor Outreach Status:</h4>
                                    {executionResults.results.map((result, index) => (
                                        <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-md">
                                            <div>
                                                <div className="font-medium">{result.prime}</div>
                                                <div className="text-sm text-gray-600">{result.contact}</div>
                                                {result.fcaRisk && (
                                                    <div className="text-xs text-red-600 font-medium">
                                                        FCA Risk: {result.fcaRisk}
                                                    </div>
                                                )}
                                            </div>
                                            <Badge className={result.status === 'sent' ? 
                                                'bg-green-100 text-green-800' : 
                                                'bg-red-100 text-red-800'
                                            }>
                                                {result.status}
                                            </Badge>
                                        </div>
                                    ))}
                                </div>
                            )}

                            {executionResults.nextSteps && (
                                <div className="mt-6">
                                    <h4 className="font-semibold mb-3">Next Steps:</h4>
                                    <ul className="space-y-2">
                                        {executionResults.nextSteps.map((step, index) => (
                                            <li key={index} className="flex items-center gap-2">
                                                <CheckCircle className="w-4 h-4 text-blue-600" />
                                                <span className="text-sm">{step}</span>
                                            </li>
                                        ))}
                                    </ul>
                                </div>
                            )}

                            {executionResults.portalLinks && (
                                <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                                    <h4 className="font-semibold mb-3 text-blue-800">Demo Portal Links:</h4>
                                    <div className="space-y-2">
                                        <a 
                                            href={executionResults.portalLinks.nistValidation}
                                            target="_blank"
                                            rel="noopener noreferrer"
                                            className="flex items-center gap-2 text-blue-600 hover:underline"
                                        >
                                            <ExternalLink className="w-4 h-4" />
                                            NIST Validation Portal (for live demos)
                                        </a>
                                        <a 
                                            href={executionResults.portalLinks.professionalDocs}
                                            target="_blank"
                                            rel="noopener noreferrer"
                                            className="flex items-center gap-2 text-blue-600 hover:underline"
                                        >
                                            <ExternalLink className="w-4 h-4" />
                                            Professional Documentation Portal
                                        </a>
                                    </div>
                                </div>
                            )}
                        </CardContent>
                    </Card>
                </div>
            )}

            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                        <Calendar className="w-6 h-6 text-purple-600" />
                        Expected Timeline & Results
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="space-y-4">
                        <div className="flex items-center justify-between">
                            <span>Email responses expected</span>
                            <Badge>24-72 hours</Badge>
                        </div>
                        <div className="flex items-center justify-between">
                            <span>Demo bookings target</span>
                            <Badge>2-3 primes</Badge>
                        </div>
                        <div className="flex items-center justify-between">
                            <span>Pilot conversion target</span>
                            <Badge>10 SMB subs</Badge>
                        </div>
                        <div className="flex items-center justify-between">
                            <span>Q4 revenue target</span>
                            <Badge className="bg-green-100 text-green-800">$20K</Badge>
                        </div>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}