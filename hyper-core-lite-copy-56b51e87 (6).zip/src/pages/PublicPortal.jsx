import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { AlertTriangle, CheckCircle, ExternalLink, Bot } from 'lucide-react';

export default function TechnologyVision() {
    const [ipInput, setIpInput] = useState('');
    const [showResult, setShowResult] = useState(false);
    const [analyzing, setAnalyzing] = useState(false);

    const simulateAnalysis = () => {
        if (!ipInput.trim()) {
            alert('Please enter an IP address to analyze');
            return;
        }
        
        setAnalyzing(true);
        setShowResult(false);
        
        setTimeout(() => {
            setShowResult(true);
            setAnalyzing(false);
        }, 1500);
    };

    return (
        <div className="min-h-screen bg-gray-100 text-gray-900 p-6">
            <div className="max-w-5xl mx-auto">
                {/* Header */}
                <div className="text-center mb-12 pt-8">
                    <h1 className="text-4xl md:text-5xl font-bold mb-3 flex items-center justify-center gap-4">
                        <Bot className="w-10 h-10" />
                        Technology & Market Vision
                    </h1>
                    <p className="text-lg md:text-xl text-gray-600">
                        An internal demonstration of the AI-powered cybersecurity & compliance platform capabilities for strategic planning.
                    </p>
                </div>

                {/* CRITICAL DISCLAIMER */}
                <Card className="mb-8 bg-yellow-100 border-2 border-yellow-400">
                    <CardHeader className="flex flex-row items-start gap-4">
                        <AlertTriangle className="w-8 h-8 text-yellow-600" />
                        <div>
                            <CardTitle className="text-xl text-yellow-800">Internal Strategic Document</CardTitle>
                            <div className="text-yellow-700 mt-2">
                               This page contains simulated data and outlines the technology vision. It is for internal and strategic partnership evaluation only and should not be shared publicly.
                            </div>
                        </div>
                    </CardHeader>
                </Card>

                {/* Two Column Layout */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
                    {/* Interactive Demo Section */}
                    <Card className="bg-white border-gray-200">
                        <CardHeader>
                            <div className="flex items-center gap-2">
                                <span className="text-blue-600 text-xl">🤖</span>
                                <CardTitle>Interactive Capability Demo</CardTitle>
                            </div>
                            <p className="text-gray-600">
                                Test the core AI analysis engine. Enter a public IP address (e.g., 8.8.8.8) to see a simulated threat intelligence report.
                            </p>
                        </CardHeader>
                        <CardContent>
                            <div className="bg-blue-50/50 border border-blue-200 rounded-lg p-4">
                                <div className="flex gap-2 mb-4">
                                    <Input 
                                        placeholder="Enter IP address (e.g., 8.8.8.8)..."
                                        value={ipInput}
                                        onChange={(e) => setIpInput(e.target.value)}
                                        onKeyPress={(e) => e.key === 'Enter' && simulateAnalysis()}
                                        className="bg-white border-gray-300 text-gray-900 placeholder-gray-500"
                                    />
                                    <Button 
                                        onClick={simulateAnalysis}
                                        disabled={analyzing}
                                        className="bg-blue-600 hover:bg-blue-700"
                                    >
                                        {analyzing ? '🔄 Analyzing...' : '🧠 Analyze'}
                                    </Button>
                                </div>
                                
                                {showResult && (
                                    <div className="bg-white/10 rounded-lg p-4 border border-green-300 mt-4">
                                        <div className="text-green-700 font-semibold mb-2">✅ AI Analysis Complete</div>
                                        <div className="text-sm text-gray-700 space-y-1">
                                            <p><strong>Risk Score:</strong> <span className="text-green-600">15/100 (Low Risk)</span></p>
                                            <p><strong>Location:</strong> United States</p>
                                            <p><strong>ISP:</strong> Google LLC</p>
                                            <p><strong>Status:</strong> Clean - No abuse reports found</p>
                                            <p className="text-xs text-gray-500 mt-2">⚠️ This is simulated data for demonstration purposes</p>
                                        </div>
                                    </div>
                                )}
                            </div>
                        </CardContent>
                    </Card>

                    {/* Capabilities Roadmap */}
                    <Card className="bg-white border-gray-200">
                        <CardHeader>
                            <div className="flex items-center gap-2">
                                <span className="text-purple-600 text-xl">🛡️</span>
                                <CardTitle>Capabilities Roadmap</CardTitle>
                            </div>
                            <p className="text-gray-600">
                                Understanding what is demonstrable today vs. what we can build together.
                            </p>
                        </CardHeader>
                        <CardContent className="space-y-6">
                            {/* Demonstrable Today */}
                            <div>
                                <h4 className="font-semibold text-green-600 mb-3">✅ Demonstrable Today</h4>
                                <ul className="space-y-2 text-sm text-gray-700">
                                    <li className="flex items-start gap-2">
                                        <span className="text-green-500 mt-0.5">●</span>
                                        <span><strong>AI Threat Analysis:</strong> Analyze IP/domain reputation against threat intelligence.</span>
                                    </li>
                                    <li className="flex items-start gap-2">
                                        <span className="text-green-500 mt-0.5">●</span>
                                        <span><strong>Cyber Risk Scoring:</strong> Generate a quantifiable cyber risk score from data inputs.</span>
                                    </li>
                                    <li className="flex items-start gap-2">
                                        <span className="text-green-500 mt-0.5">●</span>
                                        <span><strong>Compliance Gap ID:</strong> Simulate an automated gap analysis for CMMC.</span>
                                    </li>
                                </ul>
                            </div>

                            {/* Partnership Required */}
                            <div>
                                <h4 className="font-semibold text-orange-600 mb-3">🤝 Partnership-Required for Real-World</h4>
                                <ul className="space-y-2 text-sm text-gray-700">
                                    <li className="flex items-start gap-2">
                                        <span className="text-orange-500 mt-0.5">●</span>
                                        <span><strong>FedRAMP / GovCloud:</strong> Requires partnership with AWS/Azure for secure government infrastructure.</span>
                                    </li>
                                    <li className="flex items-start gap-2">
                                        <span className="text-orange-500 mt-0.5">●</span>
                                        <span><strong>CMMC-AB RPO Status:</strong> Requires hiring certified assessors and CMMC-AB approval.</span>
                                    </li>
                                    <li className="flex items-start gap-2">
                                        <span className="text-orange-500 mt-0.5">●</span>
                                        <span><strong>E&O / Cyber Insurance:</strong> Requires underwriting partnership based on this platform's risk model.</span>
                                    </li>
                                </ul>
                            </div>
                        </CardContent>
                    </Card>
                </div>

                {/* Partnership Call to Action */}
                <Card className="bg-gradient-to-r from-blue-700 to-indigo-800 text-white">
                    <CardContent className="p-8 text-center">
                        <h2 className="text-2xl font-bold mb-3">Strategic Partnership Discussion</h2>
                        <p className="text-blue-200 mb-6 max-w-2xl mx-auto">
                           This platform demonstrates a powerful foundation. We are seeking strategic partners to provide infrastructure and expertise for full-scale deployment.
                        </p>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}