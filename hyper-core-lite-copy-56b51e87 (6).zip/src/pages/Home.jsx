
import React from 'react';
import { Button } from "@/components/ui/button";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckCircle, Shield, Zap, Award, Target, Rocket, Layers, BarChart, Clock, Calendar, Phone } from 'lucide-react';
import CompetitiveComparison from '../components/competitive/CompetitiveComparison';
import ROICalculator from '../components/calculator/ROICalculator';

// Triggering deployment in the new Hypercore-Cyber organization.
const features = [
    {
        icon: <Target className="w-8 h-8 text-white" />,
        title: '100% CMMC Level 3 Accuracy',
        description: 'Achieve perfect compliance with our AI engine, validated against all 130 NIST 800-171 controls.',
        badge: 'Industry First'
    },
    {
        icon: <Zap className="w-8 h-8 text-white" />,
        title: '87-Day Compliance Timeline',
        description: 'Go from assessment to C3PAO-ready in under three months, 50% faster than the industry average.',
    },
    {
        icon: <Shield className="w-8 h-8 text-white" />,
        title: '$4.6M FCA Risk Mitigation',
        description: 'Protect your prime contracts by eliminating the 70% error rate in subcontractor SPRS submissions.',
    },
    {
        icon: <Award className="w-8 h-8 text-white" />,
        title: '$33K Average Savings',
        description: 'Reduce compliance costs by up to 70% compared to traditional consultants and competing GRC platforms.',
    },
];

export default function Home() {
    return (
        <div className="bg-white text-gray-800">
            {/* Hero Section with DIB Market Messaging */}
            <section className="text-center py-20 px-4 bg-gray-50">
                <Badge variant="outline" className="mb-4 border-blue-300 text-blue-700 py-1 px-3 text-sm">
                    Built for the Entire DIB Supply Chain
                </Badge>
                <h1 className="text-4xl md:text-6xl font-extrabold text-gray-900 leading-tight">
                    Achieve CMMC Level 2 Compliance in 90 Days
                </h1>
                <p className="mt-4 text-lg md:text-xl text-gray-600 max-w-3xl mx-auto">
                    HyperCore is the first AI-powered platform validated at **100% accuracy** for all 130 NIST controls, protecting you from $4.6M FCA penalties and securing your place in the Defense Industrial Base.
                </p>
                
                {/* DIB Value Proposition */}
                <div className="mt-8 bg-green-50 border border-green-200 rounded-lg p-6 max-w-4xl mx-auto">
                    <h2 className="text-2xl font-bold text-green-800 mb-4">Complete DIB Solution: Primes & Subcontractors</h2>
                    <div className="grid md:grid-cols-2 gap-4 text-left">
                        <div>
                            <p className="text-green-700 font-semibold">$5K/48-hour gap assessment, $12K-$25K compliance</p>
                            <p className="text-green-700">85-95% NIST 800-171 accuracy (130/130 controls)</p>
                        </div>
                        <div>
                            <p className="text-green-700 font-semibold">AI + human coaching, 90-day guarantee</p>
                            <p className="text-green-700">Save 70-94% vs. Vanta ($24K), Drata ($36K), consultants ($50K-$200K)</p>
                        </div>
                    </div>
                    <div className="grid md:grid-cols-2 gap-4 text-left mt-4 pt-4 border-t border-green-200">
                        <div>
                            <p className="text-green-600 text-sm"><strong>For Prime Contractors:</strong> Derisk your entire supply chain with bulk assessments and centralized compliance management</p>
                        </div>
                        <div>
                            <p className="text-green-600 text-sm"><strong>For Subcontractors:</strong> Get audit-ready fast with affordable, AI-powered compliance that scales to your business</p>
                        </div>
                    </div>
                    <p className="text-center text-green-600 font-bold mt-4">*Complete CMMC solution for the entire Defense Industrial Base</p>
                </div>

                <div className="mt-8 flex justify-center gap-4">
                    <Button asChild size="lg" className="text-lg px-8 py-6">
                        <Link to={createPageUrl('PartnershipTrial')}>
                            <Calendar className="w-5 h-5 mr-2" />
                            Start 48-Hour Demo
                        </Link>
                    </Button>
                    <Button asChild size="lg" variant="outline" className="text-lg px-8 py-6">
                        <Link to={createPageUrl('PartnershipInquiry')}>
                            <Phone className="w-5 h-5 mr-2" />
                            Schedule Engagement
                        </Link>
                    </Button>
                </div>
                <p className="mt-4 text-sm text-gray-500">No credit card required. Get your initial gap analysis in minutes.</p>
            </section>

            {/* Features Section */}
            <section className="py-20 px-4 bg-blue-600 text-white">
                <div className="container mx-auto">
                    <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-10">
                        {features.map((feature, index) => (
                            <div key={index} className="text-center">
                                <div className="flex justify-center items-center h-16 w-16 rounded-full bg-blue-500 mx-auto mb-4">
                                    {feature.icon}
                                </div>
                                <h3 className="text-xl font-bold">{feature.title}</h3>
                                <p className="mt-2 text-blue-200">{feature.description}</p>
                                {feature.badge && <Badge className="mt-3 bg-white text-blue-600">{feature.badge}</Badge>}
                            </div>
                        ))}
                    </div>
                </div>
            </section>
            
            {/* Competitive Comparison Section */}
            <section className="py-20 px-4">
                <div className="container mx-auto text-center">
                    <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-900">The HyperCore Advantage</h2>
                    <p className="text-lg text-gray-600 max-w-2xl mx-auto mb-12">
                        Don't settle for "good enough." See how our live-validated accuracy provides certainty that competing GRC platforms can't match.
                    </p>
                    <CompetitiveComparison />
                </div>
            </section>

            {/* ROI Calculator Section */}
            <section className="py-20 px-4 bg-white">
                <div className="container mx-auto text-center">
                    <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-900">Calculate Your Savings</h2>
                    <p className="text-lg text-gray-600 max-w-2xl mx-auto mb-12">
                        See exactly how much you'll save vs traditional consultants and GRC platforms
                    </p>
                    <ROICalculator embedded={true} />
                </div>
            </section>

            {/* How It Works Section */}
            <section className="py-20 px-4 bg-gray-50">
                <div className="container mx-auto text-center">
                    <h2 className="text-3xl md:text-4xl font-bold mb-12 text-gray-900">Your 87-Day Path to CMMC Level 3</h2>
                    <div className="grid md:grid-cols-3 gap-8 text-left">
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center gap-3"><Rocket className="w-6 h-6 text-blue-600"/>Phase 1: AI-Powered Assessment (Days 1-30)</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <ul className="space-y-2 text-gray-600">
                                    <li className="flex items-start gap-2"><CheckCircle className="w-5 h-5 text-green-500 mt-1 shrink-0" /><span>Upload existing policies and procedures for instant analysis.</span></li>
                                    <li className="flex items-start gap-2"><CheckCircle className="w-5 h-5 text-green-500 mt-1 shrink-0" /><span>Our 155ms AI engine maps your posture against all 130 NIST controls.</span></li>
                                    <li className="flex items-start gap-2"><CheckCircle className="w-5 h-5 text-green-500 mt-1 shrink-0" /><span>Receive an automated SSP, POA&M, and prioritized remediation plan.</span></li>
                                </ul>
                            </CardContent>
                        </Card>
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center gap-3"><Layers className="w-6 h-6 text-blue-600"/>Phase 2: Guided Implementation (Days 31-60)</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <ul className="space-y-2 text-gray-600">
                                    <li className="flex items-start gap-2"><CheckCircle className="w-5 h-5 text-green-500 mt-1 shrink-0" /><span>Use AI-generated policy templates to fill documentation gaps.</span></li>
                                    <li className="flex items-start gap-2"><CheckCircle className="w-5 h-5 text-green-500 mt-1 shrink-0" /><span>Follow step-by-step guidance to implement technical controls.</span></li>
                                    <li className="flex items-start gap-2"><CheckCircle className="w-5 h-5 text-green-500 mt-1 shrink-0" /><span>Track progress in real-time on your compliance dashboard.</span></li>
                                </ul>
                            </CardContent>
                        </Card>
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center gap-3"><BarChart className="w-6 h-6 text-blue-600"/>Phase 3: Validation & Audit-Readiness (Days 61-87)</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <ul className="space-y-2 text-gray-600">
                                    <li className="flex items-start gap-2"><CheckCircle className="w-5 h-5 text-green-500 mt-1 shrink-0" /><span>Run final validation scans to confirm 100% compliance.</span></li>
                                    <li className="flex items-start gap-2"><CheckCircle className="w-5 h-5 text-green-500 mt-1 shrink-0" /><span>Generate your complete evidence package for C3PAO submission.</span></li>
                                    <li className="flex items-start gap-2"><CheckCircle className="w-5 h-5 text-green-500 mt-1 shrink-0" /><span>Enter your official audit with confidence, backed by verifiable data.</span></li>
                                </ul>
                            </CardContent>
                        </Card>
                    </div>
                </div>
            </section>
        </div>
    );
}
