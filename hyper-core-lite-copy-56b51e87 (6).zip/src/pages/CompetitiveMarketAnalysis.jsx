import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Target, Zap, CheckCircle, DollarSign, Clock, User } from 'lucide-react';
import BreadcrumbNav from '../components/navigation/BreadcrumbNav';

const grcSaaSData = [
    { platform: "Drata", features: "Pre-loaded CMMC requirements; automated control scoping/baselines; evidence mapping for 110 controls; POA&M automation; real-time monitoring; integrations with 300+ tools (e.g., M365, Azure); AI for gap analysis and audit prep.", pricing: "$5,000–$15,000/year (per organization, scaled by users/controls); starts at ~$79/user/month for SMBs; includes implementation support." },
    { platform: "Vanta", features: "Automated SSP/policy generation; continuous control monitoring for NIST 800-171; customizable templates for 14 domains; real-time dashboards for SPRS scoring; AI-driven evidence collection; 120+ integrations.", pricing: "$2,000–$10,000/year (subscription, per employee or framework); freemium for basic assessments; ~$10K average for Level 2 SMBs." },
    { platform: "Sprinto", features: "Workflow automation for risk assessments; policy management and audit reports; tracks regulatory changes (e.g., DFARS); centralized evidence for 3PAO; supports CMMC with NIST mapping.", pricing: "$1,500–$8,000/year (per user/module); SaaS model with monthly/annual billing; lower tiers (~$2/user/month) for startups." },
    { platform: "Secureframe", features: "Control orchestration for 110 practices; automated questionnaires and vendor risk; compliance dashboards; integrates with FedRAMP clouds; AI for remediation recommendations.", pricing: "$3,000–$12,000/year (per organization); ~$5K for SMBs with 50 users; add-ons for advanced reporting." },
    { platform: "AuditBoard", features: "Audit simplification for CMMC; collaborative risk management; intuitive interface for distributed teams; maps to NIST 800-171A objectives; evidence tracking.", pricing: "$4,000–$10,000/year (per module/user); focuses on mid-sized orgs; ~$6K for Level 2 prep." },
    { platform: "MetricStream", features: "Holistic GRC with cyber risk/IT modules; customizable for CMMC controls; third-party risk (TPRM) integration; AI for predictive analytics.", pricing: "$10,000+/year (enterprise-focused, per module); scalable for SMBs at ~$5K–$8K with basic plans." },
];

const consultantData = [
    { firm: "Paramify", services: "Gap assessment/roadmap; living SSP/POA&M; real-time SPRS scoring; used by many RPOs.", pricing: "$2,000 flat for initial gap assessment; $500–$2K/month for ongoing roadmap/support." },
    { firm: "Summit7", services: "Full documentation (SSP/policies); control implementation; mock audits; cloud config (Azure Gov).", pricing: "$10K–$30K project-based (gap + remediation); $1K–$3K/month retainer for SMBs." },
    { firm: "Kieri Solutions", services: "Joint surveillance/mock assessments; policy dev; enclave scoping for 110 controls.", pricing: "$32K–$120K full prep (simple cloud: $32K; complex: $120K); hourly $300+." },
    { firm: "A-LIGN (Prep Services)", services: "Gap analysis; remediation oversight; policy/procedure dev; training for interviews.", pricing: "$5K–$25K for assessment prep; $250–$400/hour; bundles with tools ~$10K total." },
    { firm: "Cherry Bekaert (RPO)", services: "Compliance gap assessments; SSP management; remediation planning; 6-month prep programs.", pricing: "$15K–$50K project (includes mocks); $2K–$5K/month for management." }
];

export default function CompetitiveMarketAnalysis() {
    return (
        <div className="space-y-8 p-6">
            <BreadcrumbNav currentPageName="CompetitiveMarketAnalysis" />
            <div className="text-center mb-8">
                <Badge className="mb-4 bg-purple-100 text-purple-800">COMPETITIVE LANDSCAPE</Badge>
                <h1 className="text-4xl font-bold text-gray-900 mb-4">
                    CMMC Compliance Market Analysis
                </h1>
                <p className="text-xl text-gray-600 max-w-4xl mx-auto">
                    Detailed breakdown of GRC SaaS platforms and non-3PAO consultant offerings for CMMC Level 2 preparation.
                </p>
            </div>

            <Alert className="bg-blue-50 border-blue-200">
                <Target className="h-4 w-4 text-blue-600" />
                <AlertTitle className="text-blue-800">Market Overview</AlertTitle>
                <AlertDescription className="text-blue-700">
                    The CMMC compliance market is split between scalable but generic GRC SaaS tools and expert but expensive consultants. Both leave a significant gap for a specialized, AI-first solution that combines affordability, expertise, and automation for the SMB market.
                </AlertDescription>
            </Alert>

            <Card>
                <CardHeader>
                    <CardTitle>GRC SaaS Platform Offerings</CardTitle>
                    <CardDescription>Automated tools that reduce manual effort but often require significant configuration and existing expertise.</CardDescription>
                </CardHeader>
                <CardContent>
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Platform</TableHead>
                                <TableHead>Key Features for CMMC Level 2</TableHead>
                                <TableHead>Pricing Structure (2025 Estimates)</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {grcSaaSData.map((platform, index) => (
                                <TableRow key={index}>
                                    <TableCell className="font-medium">{platform.platform}</TableCell>
                                    <TableCell>{platform.features}</TableCell>
                                    <TableCell>{platform.pricing}</TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>Non-3PAO Consultant Offerings</CardTitle>
                    <CardDescription>Expert-led services that provide hands-on guidance but at a high cost and with limited scalability.</CardDescription>
                </CardHeader>
                <CardContent>
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Consultant/Firm</TableHead>
                                <TableHead>Key Services for 3PAO Prep</TableHead>
                                <TableHead>Pricing Structure (2025 Estimates)</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {consultantData.map((consultant, index) => (
                                <TableRow key={index}>
                                    <TableCell className="font-medium">{consultant.firm}</TableCell>
                                    <TableCell>{consultant.services}</TableCell>
                                    <TableCell>{consultant.pricing}</TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-green-50 to-blue-50 border-2 border-green-300">
                <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                        <Zap className="w-6 h-6 text-green-600" />
                        HyperCore's Disruptive Advantage
                    </CardTitle>
                    <CardDescription>How our AI-first model creates a new category, outperforming both GRC SaaS and consultants.</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="grid md:grid-cols-3 gap-6">
                        <div className="p-4 bg-white rounded-lg border">
                            <h3 className="font-semibold text-lg mb-2 flex items-center gap-2"><DollarSign className="w-5 h-5 text-red-600"/>Cost Disruption</h3>
                            <p className="text-sm text-gray-700"><strong>Problem:</strong> GRC SaaS is $5K-$15K/year, Consultants are $10K-$50K.</p>
                            <p className="text-sm text-green-700 mt-2"><strong>HyperCore Solution:</strong> Freemium model with a $99/month subscription (~$5K total cost), enabled by a zero-capital AI stack. <strong>10-20x cheaper.</strong></p>
                        </div>
                        <div className="p-4 bg-white rounded-lg border">
                            <h3 className="font-semibold text-lg mb-2 flex items-center gap-2"><Clock className="w-5 h-5 text-red-600"/>Speed Disruption</h3>
                            <p className="text-sm text-gray-700"><strong>Problem:</strong> GRC SaaS takes 6-12 months, Consultants 6-12 months.</p>
                            <p className="text-sm text-green-700 mt-2"><strong>HyperCore Solution:</strong> 80-90% automation delivers 3-6 month compliance timelines. <strong>2-4x faster.</strong></p>
                        </div>
                        <div className="p-4 bg-white rounded-lg border">
                            <h3 className="font-semibold text-lg mb-2 flex items-center gap-2"><User className="w-5 h-5 text-red-600"/>Expertise Disruption</h3>
                            <p className="text-sm text-gray-700"><strong>Problem:</strong> GRC SaaS requires a trained admin. Consultants require only a coordinator but at high cost.</p>
                            <p className="text-sm text-green-700 mt-2"><strong>HyperCore Solution:</strong> AI handles complexity, making the platform usable by any non-technical SMB owner. <strong>90% expertise reduction.</strong></p>
                        </div>
                    </div>
                    <Alert className="mt-6 bg-white">
                        <CheckCircle className="h-4 w-4 text-green-600" />
                        <AlertTitle className="font-semibold">The Unbeatable Value Proposition</AlertTitle>
                        <AlertDescription>
                            HyperCore combines the automation of GRC SaaS with the guided expertise of a consultant, delivered at a price point neither can match. This isn't just a better option—it's a new category of compliance solution.
                        </AlertDescription>
                    </Alert>
                </CardContent>
            </Card>
        </div>
    );
}