import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { CheckCircle, Clock, Target, Zap, FileText, Users, BarChart, Lightbulb } from 'lucide-react';
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const currentStrengths = [
    {
        title: "Fully Operational AI Platform",
        description: "Complete NIST 800-171 automation with SSP generation, policy creation, and gap analysis - all working in production",
        evidence: "Live demo available, functional code base, automated document generation",
        sbirValue: "Proves technical feasibility and eliminates execution risk"
    },
    {
        title: "Identified Market Need",
        description: "SMB defense contractors face $50K+ compliance costs and 6-month timelines that exclude them from DoD contracts",
        evidence: "Market research, competitive analysis, cost comparisons documented",
        sbirValue: "Clear problem statement with quantified impact"
    },
    {
        title: "AI-First Innovation",
        description: "Novel approach replacing expensive human consultants with productized expertise",
        evidence: "Technical architecture, AI model integration, automation capabilities",
        sbirValue: "Demonstrates innovation beyond existing GRC tools and consultants"
    },
    {
        title: "Scalable Business Model",
        description: "Platform can serve unlimited contractors simultaneously vs. consultant bottlenecks",
        evidence: "Infrastructure design, cost modeling, pricing strategy",
        sbirValue: "Shows potential for broad DOD impact and commercial viability"
    }
];

const validationNeeds = [
    {
        title: "Real User Validation",
        description: "Need 10-15 authentic DoD contractors to test platform and provide feedback",
        timeline: "30-60 days",
        approach: "LinkedIn outreach, industry events, direct contractor engagement",
        success: "Collect LOIs, usage metrics, testimonials, and improvement feedback"
    },
    {
        title: "Performance Metrics",
        description: "Quantify time/cost savings vs. traditional methods with real data",
        timeline: "45-60 days",
        approach: "Track user sessions, document generation times, comparison studies",
        success: "Concrete ROI data: X hours saved, $Y cost reduction per contractor"
    },
    {
        title: "Technical Validation",
        description: "Demonstrate AI accuracy and compliance quality meets C3PAO standards",
        timeline: "30-45 days", 
        approach: "Expert reviews, compliance officer feedback, accuracy testing",
        success: "Independent validation of AI-generated compliance documentation"
    }
];

const proposalStrategy = {
    phase1: {
        title: "Phase I Strategy: Proof of Concept (Already 80% Complete)",
        ask: "$50,000 - $75,000",
        duration: "6 months",
        focus: "User validation and platform refinement",
        deliverables: [
            "User validation with 15+ real DoD contractors",
            "Quantified performance metrics vs. traditional methods",
            "Platform improvements based on user feedback",
            "Technical validation report from compliance experts",
            "Phase II preparation and scaling plan"
        ]
    },
    phase2: {
        title: "Phase II Strategy: Scale and DOD Integration", 
        ask: "$750,000 - $1,000,000",
        duration: "24 months",
        focus: "Enterprise deployment and DOD partnership",
        deliverables: [
            "Integration with DOD procurement systems",
            "Enterprise-grade security and compliance features",
            "Supply chain visibility tools for Prime contractors",
            "Training and support infrastructure",
            "Commercial deployment and revenue generation"
        ]
    }
};

export default function SBIRProposalStrategy() {
    return (
        <div className="space-y-8 p-4 md:p-6">
            <BreadcrumbNav currentPageName="SBIRProposalStrategy" />
            
            <div className="text-center">
                <Badge className="mb-4 text-lg bg-blue-100 text-blue-800">SBIR STRATEGY</Badge>
                <h1 className="text-3xl font-bold text-gray-900 mb-4">
                    SBIR Proposal Strategy: From Functional MVP to Government Contract
                </h1>
                <p className="text-lg text-gray-600 max-w-4xl mx-auto">
                    Strategic roadmap for leveraging your operational platform into successful Phase I and Phase II SBIR awards
                </p>
            </div>

            <Alert className="bg-green-50 border-green-200">
                <CheckCircle className="h-4 w-4 text-green-700" />
                <AlertTitle className="font-bold text-green-800">Current Position: Strong Foundation</AlertTitle>
                <AlertDescription className="text-green-700">
                    You have a significant advantage: a fully working product that solves a real DoD problem. Most SBIR applicants are still at the concept stage. Your challenge is validation, not development.
                </AlertDescription>
            </Alert>

            <div className="grid md:grid-cols-2 gap-8">
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <Zap className="text-blue-600" />
                            Current Strengths
                        </CardTitle>
                        <CardDescription>What you bring to the SBIR application today</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        {currentStrengths.map((strength, index) => (
                            <div key={index} className="p-3 bg-blue-50 rounded-lg">
                                <h4 className="font-semibold text-blue-800">{strength.title}</h4>
                                <p className="text-sm text-blue-700 mt-1">{strength.description}</p>
                                <p className="text-xs text-blue-600 mt-2 font-medium">SBIR Value: {strength.sbirValue}</p>
                            </div>
                        ))}
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <Target className="text-orange-600" />
                            Validation Needs
                        </CardTitle>
                        <CardDescription>What you need to strengthen your proposal</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        {validationNeeds.map((need, index) => (
                            <div key={index} className="p-3 bg-orange-50 rounded-lg">
                                <h4 className="font-semibold text-orange-800">{need.title}</h4>
                                <p className="text-sm text-orange-700 mt-1">{need.description}</p>
                                <p className="text-xs text-orange-600 mt-2">
                                    <strong>Timeline:</strong> {need.timeline} | <strong>Success:</strong> {need.success}
                                </p>
                            </div>
                        ))}
                    </CardContent>
                </Card>
            </div>

            <Card className="bg-gradient-to-r from-green-50 to-blue-50">
                <CardHeader>
                    <CardTitle className="text-2xl">SBIR Proposal Framework</CardTitle>
                    <CardDescription>Your competitive positioning for both Phase I and Phase II</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-6">
                        <div className="p-4 bg-white rounded-lg shadow-sm">
                            <h3 className="text-lg font-bold text-green-800 mb-3">{proposalStrategy.phase1.title}</h3>
                            <div className="space-y-2 text-sm">
                                <p><strong>Ask:</strong> {proposalStrategy.phase1.ask}</p>
                                <p><strong>Duration:</strong> {proposalStrategy.phase1.duration}</p>
                                <p><strong>Focus:</strong> {proposalStrategy.phase1.focus}</p>
                            </div>
                            <div className="mt-3">
                                <h4 className="font-semibold text-green-700 mb-2">Key Deliverables:</h4>
                                <ul className="text-xs space-y-1">
                                    {proposalStrategy.phase1.deliverables.map((item, i) => (
                                        <li key={i} className="flex items-start gap-2">
                                            <CheckCircle className="w-3 h-3 text-green-600 mt-0.5 flex-shrink-0" />
                                            {item}
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        </div>

                        <div className="p-4 bg-white rounded-lg shadow-sm">
                            <h3 className="text-lg font-bold text-blue-800 mb-3">{proposalStrategy.phase2.title}</h3>
                            <div className="space-y-2 text-sm">
                                <p><strong>Ask:</strong> {proposalStrategy.phase2.ask}</p>
                                <p><strong>Duration:</strong> {proposalStrategy.phase2.duration}</p>
                                <p><strong>Focus:</strong> {proposalStrategy.phase2.focus}</p>
                            </div>
                            <div className="mt-3">
                                <h4 className="font-semibold text-blue-700 mb-2">Key Deliverables:</h4>
                                <ul className="text-xs space-y-1">
                                    {proposalStrategy.phase2.deliverables.map((item, i) => (
                                        <li key={i} className="flex items-start gap-2">
                                            <CheckCircle className="w-3 h-3 text-blue-600 mt-0.5 flex-shrink-0" />
                                            {item}
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        </div>
                    </div>
                </CardContent>
            </Card>

            <Alert className="bg-yellow-50 border-yellow-200">
                <Lightbulb className="h-4 w-4 text-yellow-700" />
                <AlertTitle className="font-bold text-yellow-800">Strategic Recommendation</AlertTitle>
                <AlertDescription className="text-yellow-700">
                    <strong>Focus on Phase I first:</strong> Your technical platform is ready, but you need user validation data to make your proposal unbeatable. Spend the next 60 days getting 15+ real DoD contractors to use your platform and provide feedback. This will give you the evidence that 95% of SBIR applicants don't have.
                </AlertDescription>
            </Alert>

            <div className="flex gap-4 justify-center">
                <Button asChild size="lg" className="bg-blue-600 hover:bg-blue-700">
                    <Link to={createPageUrl('SEOOptimizationStrategy')}>
                        View SEO & Market Penetration Strategy
                    </Link>
                </Button>
                <Button asChild size="lg" variant="outline">
                    <Link to={createPageUrl('LinkedInCampaignStrategy')}>
                        Start LinkedIn Contractor Outreach
                    </Link>
                </Button>
            </div>
        </div>
    );
}