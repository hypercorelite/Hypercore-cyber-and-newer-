import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Mail, Send, Loader2, AlertTriangle, CheckCircle, Settings } from "lucide-react";
import { toast } from "sonner";
import { sendEmail } from "@/api/functions";

export default function EmailTester() {
    const [to, setTo] = useState('');
    const [subject, setSubject] = useState('HyperCore Email System Test');
    const [html, setHtml] = useState('<p>This is a test email from the HyperCore platform to confirm the email system is operational.</p>');
    const [diagnosticMode, setDiagnosticMode] = useState(false);
    const [loading, setLoading] = useState(false);
    const [result, setResult] = useState(null);

    const handleSendTest = async () => {
        if (!to) {
            toast.error("Please enter a recipient email address.");
            return;
        }

        setLoading(true);
        setResult(null);

        try {
            const response = await sendEmail({
                to,
                subject,
                html,
                diagnosticMode
            });
            
            if (response.status === 200) {
                setResult({ success: true, data: response.data });
                if (diagnosticMode) {
                    toast.success("Diagnostic check successful.");
                } else {
                    toast.success(`Test email successfully sent to ${to}`);
                }
            } else {
                const errorMessage = response.data?.error || "An unknown error occurred.";
                setResult({ success: false, error: errorMessage });
                toast.error(errorMessage);
            }
        } catch (error) {
            const errorMessage = error.response?.data?.error || error.message || "A network error occurred.";
            setResult({ success: false, error: errorMessage });
            toast.error(errorMessage);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="min-h-screen bg-gray-50 p-6">
            <div className="max-w-3xl mx-auto">
                <Card>
                    <CardHeader className="text-center">
                        <div className="mx-auto bg-blue-100 p-3 rounded-full w-fit mb-3">
                            <Mail className="w-8 h-8 text-blue-600" />
                        </div>
                        <CardTitle className="text-3xl font-bold">Email System Tester</CardTitle>
                        <CardDescription>
                            Verify your SendGrid integration and ensure emails are sent correctly from your professional domain.
                        </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                        <div className="space-y-2">
                            <Label htmlFor="to">Recipient Email *</Label>
                            <Input
                                id="to"
                                type="email"
                                placeholder="Enter your personal email to receive the test"
                                value={to}
                                onChange={(e) => setTo(e.target.value)}
                            />
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="subject">Subject</Label>
                            <Input
                                id="subject"
                                value={subject}
                                onChange={(e) => setSubject(e.target.value)}
                            />
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="html">Email Body (HTML)</Label>
                            <Textarea
                                id="html"
                                value={html}
                                onChange={(e) => setHtml(e.target.value)}
                                rows={5}
                            />
                        </div>
                        <div className="flex items-center space-x-2 bg-yellow-50 border border-yellow-200 p-3 rounded-lg">
                            <Checkbox id="diagnostic" checked={diagnosticMode} onCheckedChange={setDiagnosticMode} />
                            <Label htmlFor="diagnostic" className="font-medium text-yellow-800">
                                Run Diagnostic Check (doesn't send email)
                            </Label>
                        </div>
                        <Button onClick={handleSendTest} className="w-full" disabled={loading}>
                            {loading ? (
                                <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Please Wait</>
                            ) : (
                                <><Send className="w-4 h-4 mr-2" /> {diagnosticMode ? 'Run Diagnostic' : 'Send Test Email'}</>
                            )}
                        </Button>

                        {result && (
                            <Card className={result.success ? "bg-green-50 border-green-200" : "bg-red-50 border-red-200"}>
                                <CardHeader>
                                    <CardTitle className={`flex items-center gap-2 ${result.success ? 'text-green-800' : 'text-red-800'}`}>
                                        {result.success ? <CheckCircle className="w-5 h-5" /> : <AlertTriangle className="w-5 h-5" />}
                                        {diagnosticMode ? 'Diagnostic Result' : 'Send Result'}
                                    </CardTitle>
                                </CardHeader>
                                <CardContent>
                                    {result.success ? (
                                        <div className="space-y-2 text-sm text-green-700">
                                            <p><strong>Status:</strong> {result.data.status}</p>
                                            <p><strong>Message:</strong> {result.data.message}</p>
                                            {result.data.details && <p><strong>Details:</strong> {result.data.details}</p>}
                                        </div>
                                    ) : (
                                        <div className="space-y-2 text-sm text-red-700">
                                            <p><strong>Status:</strong> Error</p>
                                            <p><strong>Message:</strong> {result.error}</p>
                                        </div>
                                    )}
                                </CardContent>
                            </Card>
                        )}
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}