import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Check, ArrowRight, DollarSign, Users, Building, Star, TrendingUp, Shield } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import BreadcrumbNav from '../components/navigation/BreadcrumbNav';

const pricingTiers = [
    {
        name: "Basic",
        target: "Level 1/2 SMB Subs (68% of DIB)",
        price: "$12,000",
        period: "/year",
        icon: Building,
        description: "Achieve 100% validated Level 2 compliance in 87 days.",
        features: [
            "100% Validated Level 2 Accuracy",
            "CMMC Analyzer (110 Controls)",
            "Real-Time Drift Detection",
            "Automated SSP & POA&M Generation",
            "87-Day Implementation Guidance",
            "Email & AI Chatbot Support"
        ],
        cta: "Start Level 2 Compliance",
        ctaLink: "PartnershipTrial"
    },
    {
        name: "Pro", 
        target: "Level 2/3 SMBs & Small Primes",
        price: "$25,000",
        period: "/year",
        icon: Star,
        description: "The complete AI-driven platform for 100% validated Level 3 readiness.",
        hybridNote: "Hybrid model available: $15K upfront + $1K/month monitoring.",
        features: [
            "Everything in Basic, plus:",
            "100% Validated Level 3 Accuracy (130 Controls)",
            "Supply Chain Risk Analytics",
            "Automated ODP Testing & Evidence",
            "80% Flow-Down Error Reduction",
            "C3PAO Audit Preparation Package",
            "100% Money-Back C3PAO Guarantee"
        ],
        cta: "Achieve Level 3 Readiness",
        ctaLink: "PartnershipInquiry",
        highlight: "Most Popular"
    },
    {
        name: "Enterprise",
        target: "Prime Contractors & Large Orgs",
        price: "$100,000+",
        period: "/year",
        icon: Users,
        description: "A strategic partnership to de-risk your entire supply chain.",
        features: [
            "Everything in Pro, plus:",
            "Compliance Concierge Program",
            "FedRAMP & DFARS Integration",
            "Custom ODP & Policy Engine",
            "Dedicated Support & vCISO",
            "Volume-Based Subcontractor Pricing",
            "Full FCA Liability Reporting"
        ],
        cta: "Schedule Prime Consultation",
        ctaLink: "PartnershipInquiry",
        highlight: "Enterprise"
    }
];

export default function PricingStrategy() {
    return (
        <div className="space-y-8 p-4 md:p-6">
            <BreadcrumbNav currentPageName="PricingStrategy" />
            
            <div className="text-center">
                <h1 className="text-4xl font-bold text-gray-900">New Pricing & Packaging</h1>
                <p className="text-xl text-gray-600 max-w-4xl mx-auto mt-4">
                    Leveraging our 100% validated Level 3 accuracy to create a premium, market-dominant offering that remains accessible to SMBs.
                </p>
            </div>

            <Alert className="bg-blue-50 border-blue-200">
                <TrendingUp className="h-4 w-4 text-blue-700" />
                <AlertTitle className="font-bold text-blue-800">Strategic Shift: From Value to Dominance</AlertTitle>
                <AlertDescription className="text-blue-700">
                    We are no longer just a 'better value' than Vanta or Drata. We are the **only platform with validated 100% Level 3 accuracy**. 
                    This pricing reflects our unique capability to guarantee compliance outcomes.
                </AlertDescription>
            </Alert>

            <div className="grid lg:grid-cols-3 gap-8 items-start">
                {pricingTiers.map((tier, index) => (
                    <Card key={index} className={`flex flex-col relative ${
                        tier.highlight === 'Most Popular' ? 'ring-2 ring-blue-600 scale-105' : 
                        tier.highlight === 'Enterprise' ? '' : ''
                    }`}>
                        {tier.highlight && (
                            <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                                <span className={`px-3 py-1 text-xs font-bold rounded-full text-white ${
                                    tier.highlight === 'Most Popular' ? 'bg-blue-600' : 'bg-gray-700'
                                }`}>
                                    {tier.highlight}
                                </span>
                            </div>
                        )}
                        <CardHeader className="text-center">
                            <tier.icon className="w-10 h-10 text-blue-600 mx-auto mb-4" />
                            <CardTitle className="text-2xl">{tier.name}</CardTitle>
                            <CardDescription>{tier.target}</CardDescription>
                        </CardHeader>
                        <CardContent className="flex-grow">
                            <div className="text-center mb-6">
                                <span className="text-4xl font-bold">{tier.price}</span>
                                <span className="text-gray-600">{tier.period}</span>
                                {tier.hybridNote && <p className="text-xs text-blue-600 mt-1">{tier.hybridNote}</p>}
                            </div>
                            <ul className="space-y-3">
                                {tier.features.map((feature, i) => (
                                    <li key={i} className={`flex items-start gap-3 text-sm ${feature.includes("100% Money-Back") ? 'font-bold text-green-700' : ''}`}>
                                        {feature.includes("100% Money-Back") ? <Shield className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" /> : <Check className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />}
                                        <span>{feature}</span>
                                    </li>
                                ))}
                            </ul>
                        </CardContent>
                        <div className="p-6 pt-0">
                            <Button asChild className="w-full" size="lg" variant={tier.highlight === 'Most Popular' ? "default" : "outline"}>
                                {tier.ctaLink ? (
                                    <Link to={createPageUrl(tier.ctaLink)}>
                                        {tier.cta} <ArrowRight className="w-4 h-4 ml-2" />
                                    </Link>
                                ) : (
                                    <span>{tier.cta}</span>
                                )}
                            </Button>
                        </div>
                    </Card>
                ))}
            </div>

            <Card>
                <CardHeader>
                    <CardTitle>Post-Reassessment Rationale</CardTitle>
                </CardHeader>
                <CardContent className="grid md:grid-cols-3 gap-6 text-sm">
                    <div className="p-4 bg-gray-50 rounded-lg">
                        <h4 className="font-semibold text-lg mb-2">Hybrid Model Lock-In</h4>
                        <p className="text-gray-600">The Pro tier's hybrid model ($15K upfront + $1K/month) secures initial revenue for SSP generation while creating a recurring revenue stream for continuous monitoring. This increases LTV and builds a moat against one-time consultants.</p>
                    </div>
                    <div className="p-4 bg-gray-50 rounded-lg">
                        <h4 className="font-semibold text-lg mb-2">Accessible SMB Pricing</h4>
                        <p className="text-gray-600">The $12K/year Basic tier remains 50% cheaper than traditional consultants ($35K+), capturing the price-sensitive SMB market. Our 100% Level 2 accuracy justifies the premium over Drata's $10K entry point.</p>
                    </div>
                    <div className="p-4 bg-gray-50 rounded-lg">
                        <h4 className="font-semibold text-lg mb-2">The "Money-Back" Guarantee</h4>
                        <p className="text-gray-600">Offering a "100% refund if C3PAO fails" is a powerful risk-reversal tool. It leverages our validated accuracy to overcome DoD buyer skepticism, projected to boost conversions by 25%.</p>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}