import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { ArrowRight, DollarSign, Clock, Users, Zap, CheckCircle, AlertTriangle, Target, Shield } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const pricingTiers = [
    {
        name: "SBIR Partnership (Current)",
        price: "FREE",
        period: "Until Dec 5th, 2025",
        description: "Complete platform access for case study partners",
        deliverables: [
            "AI-powered gap analysis (110 NIST controls)",
            "Complete System Security Plan (SSP)",
            "All 14 CMMC Level 2 policy documents",
            "Automated 90-Day Success Plan",
            "AI assistant & Knowledge Hub access",
            "SPRS score calculation",
            "Evidence collection templates"
        ],
        timeline: "Instant generation, 90-day implementation guidance",
        value: "$150K+ in consultant equivalent value"
    },
    {
        name: "Pro Subscription (Post-Dec 5th)",
        price: "$297",
        period: "/month",
        description: "Ongoing compliance management & updates",
        deliverables: [
            "All SBIR Partnership features",
            "Continuous compliance monitoring",
            "Updated controls as regulations evolve",
            "Priority AI support",
            "Quarterly compliance health checks",
            "Integration with security tools",
            "Annual assessment prep"
        ],
        timeline: "Real-time updates, ongoing monitoring",
        value: "75-90% cost savings vs. alternatives"
    },
    {
        name: "Enterprise Guided",
        price: "$12,500",
        period: "one-time",
        description: "White-glove implementation support",
        deliverables: [
            "Everything in Pro Subscription",
            "Dedicated compliance specialist",
            "Weekly 1-on-1 coaching calls",
            "Custom policy development",
            "C3PAO readiness review",
            "Priority phone support",
            "Implementation project management"
        ],
        timeline: "90-day guided implementation",
        value: "80% less than traditional consulting"
    }
];

const competitorComparison = [
    {
        approach: "Traditional CMMC Consultants",
        cost: "$50K - $200K",
        timeline: "12-18 months",
        deliverables: "Manual documentation, static policies",
        problems: [
            "Hourly billing incentivizes slow work",
            "Human error risk in documentation",
            "Knowledge leaves with consultant",
            "Static deliverables become outdated",
            "No ongoing support included"
        ],
        success_rate: "60-70% (high failure rate)"
    },
    {
        approach: "GRC Software Platforms",
        cost: "$24K - $120K/year",
        timeline: "6-12 months to implement",
        deliverables: "Empty framework requiring expert input",
        problems: [
            "Requires dedicated expert hire",
            "Steep learning curve",
            "You still do all the work manually",
            "Complex spreadsheets disguised as software",
            "No actual compliance content included"
        ],
        success_rate: "40-50% (high abandonment rate)"
    },
    {
        approach: "HyperCore AI Automation",
        cost: "Free → $297/mo → $12.5K guided",
        timeline: "Hours to generate, 90 days to implement",
        deliverables: "Complete, audit-ready documentation + ongoing support",
        advantages: [
            "Instant document generation",
            "90% automation of compliance work",
            "Built-in expertise and guidance",
            "Living documents that stay current",
            "Continuous monitoring and updates"
        ],
        success_rate: "90%+ (AI-driven accuracy)"
    }
];

const marketDisruption = [
    {
        traditional_problem: "18-Month Manual Timeline",
        hypercore_solution: "Hours for Documentation, 90 Days Total",
        impact: "75% time reduction enables meeting DoD deadlines"
    },
    {
        traditional_problem: "$50K-$200K Consultant Fees",
        hypercore_solution: "Free → $297/month",
        impact: "90% cost reduction makes compliance accessible to SMBs"
    },
    {
        traditional_problem: "High Human Error Risk",
        hypercore_solution: "AI-Driven 90% Accuracy",
        impact: "Eliminates False Claims Act exposure from documentation errors"
    },
    {
        traditional_problem: "Expert Dependency Bottleneck",
        hypercore_solution: "Productized Expertise Available 24/7",
        impact: "Scales to serve 31,500 SMB contractors simultaneously"
    }
];

export default function StrategicValueProposition() {
    return (
        <div className="space-y-8 p-6">
            <div className="text-center mb-8">
                <Badge className="mb-4 bg-green-100 text-green-800">STRATEGIC ANALYSIS</Badge>
                <h1 className="text-4xl font-bold text-gray-900 mb-4">
                    HyperCore's Market Disruption Strategy
                </h1>
                <p className="text-xl text-gray-600 max-w-4xl mx-auto">
                    How we solve the CMMC speed, cost, and accuracy crisis through AI automation
                </p>
            </div>

            {/* Current Pricing & Deliverables */}
            <Card className="bg-gradient-to-r from-green-50 to-blue-50 border-2 border-green-300">
                <CardHeader>
                    <CardTitle className="text-2xl text-green-800">Our Three-Tier Value Model</CardTitle>
                    <CardDescription className="text-green-700">
                        Designed to capture the entire market: free validation, scalable subscriptions, premium services
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="grid lg:grid-cols-3 gap-6">
                        {pricingTiers.map((tier, index) => (
                            <Card key={index} className={`${index === 1 ? 'ring-2 ring-blue-500' : ''}`}>
                                <CardHeader>
                                    <CardTitle className="flex justify-between items-center">
                                        {tier.name}
                                        {index === 1 && <Badge className="bg-blue-100 text-blue-800">Most Popular</Badge>}
                                    </CardTitle>
                                    <div className="text-3xl font-bold">
                                        {tier.price}
                                        <span className="text-base text-gray-600">{tier.period}</span>
                                    </div>
                                    <CardDescription>{tier.description}</CardDescription>
                                </CardHeader>
                                <CardContent className="space-y-4">
                                    <div>
                                        <h4 className="font-semibold mb-2">What You Get:</h4>
                                        <ul className="space-y-1 text-sm">
                                            {tier.deliverables.map((item, i) => (
                                                <li key={i} className="flex items-start gap-2">
                                                    <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                                                    {item}
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                                    <div className="pt-2 border-t">
                                        <p className="text-sm"><strong>Timeline:</strong> {tier.timeline}</p>
                                        <p className="text-sm text-green-600"><strong>Value:</strong> {tier.value}</p>
                                    </div>
                                </CardContent>
                            </Card>
                        ))}
                    </div>
                </CardContent>
            </Card>

            {/* Market Disruption Analysis */}
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                        <Target className="w-6 h-6 text-purple-600" />
                        How We Disrupt the Traditional Market
                    </CardTitle>
                    <CardDescription>
                        Point-by-point comparison showing how AI automation solves fundamental industry problems
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="space-y-6">
                        {marketDisruption.map((disruption, index) => (
                            <div key={index} className="grid md:grid-cols-3 gap-4 p-4 bg-gray-50 rounded-lg">
                                <div>
                                    <h4 className="font-semibold text-red-700 mb-2">Traditional Problem</h4>
                                    <p className="text-sm">{disruption.traditional_problem}</p>
                                </div>
                                <div>
                                    <h4 className="font-semibold text-green-700 mb-2">HyperCore Solution</h4>
                                    <p className="text-sm">{disruption.hypercore_solution}</p>
                                </div>
                                <div>
                                    <h4 className="font-semibold text-blue-700 mb-2">Market Impact</h4>
                                    <p className="text-sm">{disruption.impact}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>

            {/* Competitive Comparison */}
            <Card>
                <CardHeader>
                    <CardTitle>Comprehensive Competitive Analysis</CardTitle>
                    <CardDescription>How we stack up against all existing approaches</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="space-y-8">
                        {competitorComparison.map((competitor, index) => (
                            <div key={index} className={`p-6 rounded-lg border-2 ${index === 2 ? 'border-green-300 bg-green-50' : 'border-gray-200'}`}>
                                <div className="grid md:grid-cols-4 gap-4 mb-4">
                                    <div>
                                        <h3 className="font-bold text-lg">{competitor.approach}</h3>
                                        {index === 2 && <Badge className="bg-green-100 text-green-800 mt-1">Our Approach</Badge>}
                                    </div>
                                    <div>
                                        <p className="text-sm text-gray-600">Cost</p>
                                        <p className="font-semibold">{competitor.cost}</p>
                                    </div>
                                    <div>
                                        <p className="text-sm text-gray-600">Timeline</p>
                                        <p className="font-semibold">{competitor.timeline}</p>
                                    </div>
                                    <div>
                                        <p className="text-sm text-gray-600">Success Rate</p>
                                        <p className="font-semibold">{competitor.success_rate || 'N/A'}</p>
                                    </div>
                                </div>
                                <div className="mb-4">
                                    <p className="text-sm text-gray-600 mb-1">What You Get:</p>
                                    <p className="text-sm">{competitor.deliverables}</p>
                                </div>
                                {competitor.problems && (
                                    <div>
                                        <p className="text-sm text-red-600 font-semibold mb-2">Key Problems:</p>
                                        <ul className="text-sm text-red-600 space-y-1">
                                            {competitor.problems.map((problem, i) => (
                                                <li key={i} className="flex items-start gap-2">
                                                    <AlertTriangle className="w-4 h-4 mt-0.5 flex-shrink-0" />
                                                    {problem}
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                                )}
                                {competitor.advantages && (
                                    <div>
                                        <p className="text-sm text-green-600 font-semibold mb-2">Key Advantages:</p>
                                        <ul className="text-sm text-green-600 space-y-1">
                                            {competitor.advantages.map((advantage, i) => (
                                                <li key={i} className="flex items-start gap-2">
                                                    <CheckCircle className="w-4 h-4 mt-0.5 flex-shrink-0" />
                                                    {advantage}
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                                )}
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>

            {/* SMB Readiness Assessment */}
            <Card className="bg-blue-50 border-blue-200">
                <CardHeader>
                    <CardTitle className="flex items-center gap-3 text-blue-800">
                        <Shield className="w-6 h-6" />
                        SMB DoD Contractor Readiness Assessment
                    </CardTitle>
                    <CardDescription className="text-blue-700">
                        How prepared we are to serve the 31,500 SMB contractors requiring CMMC Level 2
                    </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="grid md:grid-cols-2 gap-6">
                        <div>
                            <h4 className="font-semibold text-blue-800 mb-3">✅ What We Have Ready</h4>
                            <ul className="space-y-2 text-sm">
                                <li className="flex items-start gap-2">
                                    <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                                    Complete AI-powered gap analysis engine
                                </li>
                                <li className="flex items-start gap-2">
                                    <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                                    Automated SSP generation for any organization
                                </li>
                                <li className="flex items-start gap-2">
                                    <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                                    All 14 CMMC Level 2 policy templates
                                </li>
                                <li className="flex items-start gap-2">
                                    <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                                    SPRS score calculation and reporting
                                </li>
                                <li className="flex items-start gap-2">
                                    <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                                    90-Day implementation guidance system
                                </li>
                                <li className="flex items-start gap-2">
                                    <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                                    AI assistant trained on official DoD guidance
                                </li>
                            </ul>
                        </div>
                        <div>
                            <h4 className="font-semibold text-blue-800 mb-3">🚀 Scale & Market Fit</h4>
                            <div className="space-y-3 text-sm">
                                <div>
                                    <p className="font-medium">Target Market:</p>
                                    <p>31,500 SMB contractors requiring Level 2</p>
                                </div>
                                <div>
                                    <p className="font-medium">Current Capacity:</p>
                                    <p>Unlimited (cloud-based AI platform)</p>
                                </div>
                                <div>
                                    <p className="font-medium">Revenue Potential:</p>
                                    <p>$5M ARR serving just 10% of market</p>
                                </div>
                                <div>
                                    <p className="font-medium">Competitive Advantage:</p>
                                    <p>Only solution delivering instant, accurate results</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </CardContent>
            </Card>

            {/* Strategic Recommendations */}
            <Alert className="bg-green-50 border-green-200">
                <Zap className="h-4 w-4 text-green-600" />
                <AlertTitle className="text-green-800">Strategic Conclusion</AlertTitle>
                <AlertDescription className="text-green-700 space-y-2">
                    <p><strong>Market Position:</strong> We are uniquely positioned to disrupt a $1B+ annual market with a solution that is 90% faster, 75-90% cheaper, and significantly more accurate than existing alternatives.</p>
                    <p><strong>Immediate Opportunity:</strong> The November 10th CMMC deadline creates massive urgency. Traditional approaches cannot meet this timeline, giving us a first-mover advantage.</p>
                    <p><strong>Scaling Path:</strong> Our SBIR partnership strategy generates validation data while building market share. Post-Dec 5th pricing captures ongoing value while remaining dramatically more affordable than alternatives.</p>
                </AlertDescription>
            </Alert>

            <div className="text-center">
                <Button asChild size="lg" className="bg-blue-600 hover:bg-blue-700">
                    <Link to={createPageUrl('PartnershipTrial')}>
                        Experience Our Disruption Firsthand <ArrowRight className="w-4 h-4 ml-2" />
                    </Link>
                </Button>
            </div>
        </div>
    );
}