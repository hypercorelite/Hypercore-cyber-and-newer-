import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Shield, Bot, AlertTriangle, Users, CheckCircle, ArrowRight, BookOpen } from 'lucide-react';
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

const aiRisks = [
    {
        risk: "Poor Data Quality & 'Garbage In, Garbage Out'",
        description: "Competitor AI relies on perfect client data. SMBs often provide incomplete or inaccurate information, leading to flawed SSPs and failed audits.",
        mitigation: "Our 'human-in-the-loop' model uses AI for drafting but relies on expert human review to validate data quality and context, ensuring accuracy.",
        icon: AlertTriangle
    },
    {
        risk: "Lack of Explainability (The 'Black Box' Problem)",
        description: "Complex ML models can't explain their reasoning to a C3PAO auditor, creating significant audit risk.",
        mitigation: "Our AI acts as a 'tutor,' providing clear, NIST-traceable justifications for every recommendation, creating a transparent and defensible audit trail.",
        icon: BookOpen
    },
    {
        risk: "Adversarial AI Attacks & Data Poisoning",
        description: "Automated platforms are targets for attacks that could compromise the integrity of compliance documentation, exposing clients to False Claims Act liability.",
        mitigation: "By focusing on guidance rather than full automation, we reduce the attack surface. Final sign-off always rests with a human expert and the client.",
        icon: Shield
    },
    {
        risk: "Over-Reliance on Automation",
        description: "Competitors' end-to-end automation can miss nuanced, context-specific compliance requirements, leading to critical gaps.",
        mitigation: "Our model is 'AI-Assisted, Human-Led.' The AI handles 80% of the busy work, freeing up human experts to focus on the critical 20% that ensures true compliance.",
        icon: Users
    }
];

const competitorAI = [
    { name: "Risk Cognizance", approach: "ML for workflow automation, NLP for documentation.", weakness: "High risk from poor data quality, opaque AI logic." },
    { name: "Strike Graph", approach: "Generative AI for SSP/POA&M, ML for evidence validation.", weakness: "Vulnerable to 'black box' problem, potential for over-reliance on automation." },
    { name: "Hyperproof", approach: "AI for evidence collection and task automation.", weakness: "Less focused on guidance, assumes client has implementation expertise." },
];

export default function CMMCThreatDetectionCompliance() {
    return (
        <div className="space-y-8 p-4 sm:p-6 lg:p-8">
            <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center"
            >
                <Badge className="mb-4 bg-red-100 text-red-800">RISK & STRATEGY</Badge>
                <h1 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-3">
                    AI in CMMC: Turning Competitor Risks into Our Advantage
                </h1>
                <p className="text-lg lg:text-xl text-gray-600 max-w-4xl mx-auto">
                    An analysis of AI-related compliance risks and how our human-centric tutoring model mitigates them, creating a defensible market position.
                </p>
            </motion.div>

            <Alert className="bg-yellow-50 border-yellow-200">
                <Bot className="h-4 w-4 text-yellow-700" />
                <AlertTitle className="text-yellow-800 font-bold">Strategic Insight: Automation vs. Amplification</AlertTitle>
                <AlertDescription className="text-yellow-700">
                    Competitors use AI for **Automation**, which replaces human tasks but creates significant risks (black box logic, data quality issues). We use AI for **Amplification**, making human expertise more scalable, affordable, and accurate. This is our core competitive advantage.
                </AlertDescription>
            </Alert>

            <Card>
                <CardHeader>
                    <CardTitle>AI Risk Mitigation Strategy</CardTitle>
                    <CardDescription>How our AI-assisted tutoring model addresses the four critical drawbacks of AI in CMMC compliance.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    {aiRisks.map((item, index) => (
                        <motion.div
                            key={index}
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: index * 0.1 }}
                        >
                            <div className="flex items-start gap-4">
                                <item.icon className={`w-8 h-8 mt-1 flex-shrink-0 ${index % 2 === 0 ? 'text-red-500' : 'text-green-600'}`} />
                                <div>
                                    <h3 className="font-semibold text-red-700">Risk: {item.risk}</h3>
                                    <p className="text-sm text-gray-600 mb-2">{item.description}</p>
                                    <p className="text-sm font-medium text-green-700">
                                        <span className="font-bold">Our Mitigation:</span> {item.mitigation}
                                    </p>
                                </div>
                            </div>
                        </motion.div>
                    ))}
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>Competitor AI Landscape</CardTitle>
                    <CardDescription>A summary of competitor AI strategies and their inherent weaknesses.</CardDescription>
                </CardHeader>
                <CardContent>
                     <div className="overflow-x-auto">
                        <table className="w-full text-sm">
                            <thead className="bg-gray-50">
                                <tr>
                                    <th className="p-3 text-left font-semibold">Competitor</th>
                                    <th className="p-3 text-left font-semibold">AI Approach</th>
                                    <th className="p-3 text-left font-semibold text-red-600">Identified Weakness</th>
                                </tr>
                            </thead>
                            <tbody>
                                {competitorAI.map((item, index) => (
                                    <tr key={index} className="border-b">
                                        <td className="p-3 font-medium">{item.name}</td>
                                        <td className="p-3">{item.approach}</td>
                                        <td className="p-3 text-red-700 text-xs">{item.weakness}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </CardContent>
            </Card>

            <Alert className="bg-green-50 border-green-200">
                <CheckCircle className="h-4 w-4 text-green-600" />
                <AlertTitle className="text-green-800 font-bold">Your Unbeatable Position</AlertTitle>
                <AlertDescription className="text-green-700">
                    By acknowledging and designing for AI's limitations, your model builds trust and delivers superior accuracy. While competitors sell automation, you sell confidence—a far more valuable commodity in the high-stakes world of DoD compliance.
                </AlertDescription>
            </Alert>

            <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
            >
                <Card className="text-center bg-gray-800 text-white">
                    <CardContent className="p-8">
                        <h3 className="text-2xl font-bold mb-4">Translate Strategy into Action</h3>
                        <p className="text-gray-300 mb-6 max-w-2xl mx-auto">
                            This risk-aware strategy is a key component of our technical and business planning.
                        </p>
                        <Button asChild size="lg" variant="secondary" className="bg-white text-gray-900 hover:bg-gray-200">
                            <Link to={createPageUrl('SBIRTechnicalStrategy')}>
                                Review SBIR Proposal & Technical Plan <ArrowRight className="w-4 h-4 ml-2" />
                            </Link>
                        </Button>
                    </CardContent>
                </Card>
            </motion.div>
        </div>
    );
}