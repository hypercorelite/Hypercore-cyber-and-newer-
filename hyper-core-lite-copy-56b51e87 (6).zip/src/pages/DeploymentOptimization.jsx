
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Bot, Zap, UserCheck, Mail, GitBranch, ArrowRight, ShieldCheck } from 'lucide-react';
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

const optimizationAreas = [
    {
        area: "Client Onboarding Automation",
        icon: UserCheck,
        description: "Reduce the manual effort of setting up a new client from hours to seconds.",
        recommendations: [
            "Create a 'One-Click Onboarding' function that, upon signing a contract:",
            "1. Automatically creates the client's `ComplianceFramework` record.",
            "2. Instantly generates all 110 `ComplianceTask` records linked to that framework.",
            "3. Sends a templated welcome email via the `sendEmail` function with portal access details."
        ],
        impact: "Guarantees consistent setup, eliminates manual data entry errors, and allows you to start client work immediately."
    },
    {
        area: "AI-Powered Project Management",
        icon: Bot,
        description: "Evolve from reactive task management to proactive, AI-driven project oversight.",
        recommendations: [
            "Create a new `ProjectManagerAgent` scheduled to run daily.",
            "Task: 'Review all active ComplianceFrameworks. Identify any with tasks overdue by >7 days. For each, update their CRM status to 'needs_attention' and draft a polite follow-up email for the admin to review.'",
            "This agent needs `read` access to `ComplianceTask` and `update` access to `PartnershipCommunication`."
        ],
        impact: "Prevents client progress from stalling, provides early warnings on at-risk projects, and saves you hours of manual review each week."
    },
    {
        area: "Intelligent Chatbot & Authentication",
        icon: Zap,
        description: "Leverage user authentication to provide a personalized, interactive AI experience.",
        recommendations: [
            "**Public Site (Unauthenticated):** Deploy a simple chatbot on pages like 'Home' and 'PartnershipPitch'. This bot answers FAQs about pricing, services, and the 90-day timeline, acting as a 24/7 sales assistant.",
            "**Client Portal (Authenticated):** This is the key. When a client logs in, the chatbot knows their identity (`User.me()`).",
            "The bot can answer personalized questions like: 'What are my top 3 priorities this week?'",
            "Behind the scenes, an agent uses the user's ID to query their specific `ComplianceTask`s and provides a real, actionable answer.",
            "Give the agent `update` access to `ComplianceTask` so a client can say, 'Mark task AC.1.001 as ready for review.'"
        ],
        impact: "Transforms the client experience from a static portal to an interactive compliance partner, reducing support load and increasing engagement."
    },
    {
        area: "Streamlined Sales & CRM Automation",
        icon: Mail,
        description: "Connect your sales pipeline directly to your operational tools.",
        recommendations: [
            "Automate triggers based on status changes in the `PartnershipCommunication` entity.",
            "When status changes to 'demo_scheduled', automatically create a calendar invite and log the event.",
            "When status changes to 'active_partner', trigger the 'One-Click Onboarding' automation.",
            "This creates a seamless flow from initial contact to active, paying client with zero manual hand-off."
        ],
        impact: "Shortens the sales cycle, ensures no leads are dropped, and makes scaling your client base seamless."
    }
];

export default function DeploymentOptimization() {
    return (
        <div className="space-y-8 p-4 sm:p-6 lg:p-8">
            <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center"
            >
                <Zap className="w-12 h-12 mx-auto text-blue-600 mb-4" />
                <h1 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-3">
                    Automation & Optimization Roadmap
                </h1>
                <p className="text-lg lg:text-xl text-gray-600 max-w-3xl mx-auto">
                    Strategic recommendations to increase operational leverage, reduce manual effort, and build a truly scalable AI-powered service.
                </p>
            </motion.div>

            <Alert className="bg-blue-50 border-blue-200">
                <GitBranch className="h-4 w-4 text-blue-600" />
                <AlertTitle className="text-blue-800">From Manual Process to Automated System</AlertTitle>
                <AlertDescription className="text-blue-700">
                    The following steps outline how to evolve your business from a series of manual, expert-driven tasks into a cohesive, automated system that can scale from 5 to 50+ clients without a linear increase in effort.
                </AlertDescription>
            </Alert>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {optimizationAreas.map((area, index) => (
                    <motion.div
                        key={index}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.1 }}
                    >
                        <Card className="h-full flex flex-col">
                            <CardHeader>
                                <CardTitle className="flex items-center gap-3">
                                    <area.icon className="w-6 h-6 text-blue-600" />
                                    {area.area}
                                </CardTitle>
                                <CardDescription>{area.description}</CardDescription>
                            </CardHeader>
                            <CardContent className="flex-grow">
                                <h4 className="font-semibold mb-2 text-gray-800">Recommendations:</h4>
                                <ul className="space-y-3 text-sm text-gray-700">
                                    {area.recommendations.map((rec, i) => (
                                        <li key={i} className="flex items-start gap-2">
                                            <ArrowRight className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                                            <span>{rec}</span>
                                        </li>
                                    ))}
                                </ul>
                            </CardContent>
                            <div className="p-4 bg-gray-50 border-t">
                                <p className="text-sm font-semibold text-gray-800">Business Impact:</p>
                                <p className="text-sm text-gray-600">{area.impact}</p>
                            </div>
                        </Card>
                    </motion.div>
                ))}
            </div>

            <Alert>
                <ShieldCheck className="h-4 w-4" />
                <AlertTitle>Strategic Vision: The Self-Healing System</AlertTitle>
                <AlertDescription>
                    By implementing these automations, you create a system where the AI doesn't just perform tasks—it manages the workflow. It identifies problems (stalled clients), automates solutions (onboarding), and provides an interactive, intelligent experience (authenticated chatbot). This frees you to focus on high-value expert guidance, which is the core of your business and cannot be automated.
                    <div className="mt-4">
                        <Button asChild>
                            <Link to={createPageUrl('ClientLifecycleInfrastructure')}>
                                Review Client Management Workflow <ArrowRight className="w-4 h-4 ml-2" />
                            </Link>
                        </Button>
                    </div>
                </AlertDescription>
            </Alert>
        </div>
    );
}
