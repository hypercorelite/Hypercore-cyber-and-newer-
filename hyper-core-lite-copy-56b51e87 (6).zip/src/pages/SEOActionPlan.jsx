import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { ExternalLink, Check, Calendar, Target, TrendingUp, Link as LinkIcon, Edit } from 'lucide-react';
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";

const initialPlan = [
    { 
        week: 1, 
        theme: "Foundation & Content Launch",
        focus: ["Platform", "SEO", "Analytics"],
        tasks: [
            { id: 1, text: "Launch KnowledgeHub page with 3 SEO-optimized articles.", completed: false, category: "Platform" },
            { id: 2, text: "Post 3 Reddit threads (r/CMMC, 'AMA: AI Saves 50%')", completed: false, category: "Platform" },
            { id: 3, text: "Add JSON-LD schema to all articles and submit to GSC.", completed: false, category: "SEO" },
            { id: 4, text: "Install GA4 and configure 'article_view' & 'demo_signup' events.", completed: false, category: "Analytics" },
            { id: 5, text: "Create 5 UTM links for Reddit, LinkedIn, and forum tracking.", completed: false, category: "Analytics" },
        ]
    },
    { 
        week: 2, 
        theme: "Outreach & Backlink Building",
        focus: ["Platform", "SEO"],
        tasks: [
            { id: 6, text: "Pitch 'Defense One' op-ed with targeted, data-driven angle.", completed: false, category: "Platform" },
            { id: 7, text: "Post in 2 NDIA forum threads with valuable insights.", completed: false, category: "Platform" },
            { id: 8, text: "Submit KnowledgeHub to 2 free directories (e.g., DMOZ).", completed: false, category: "SEO" },
            { id: 9, text: "Comment on 3 relevant 'Defense News' articles with backlinks.", completed: false, category: "SEO" },
        ]
    },
    { 
        week: 3, 
        theme: "Engagement & Optimization",
        focus: ["Platform", "Analytics"],
        tasks: [
            { id: 10, text: "Pitch 'National Defense Magazine' with prestige angle.", completed: false, category: "Platform" },
            { id: 11, text: "Host live Q&A in 'NoVA DIB CMMC Innovators' LinkedIn group.", completed: false, category: "Platform" },
            { id: 12, text: "Analyze GA4 traffic sources and pivot strategy if forum CTR < 2%.", completed: false, category: "Analytics" },
            { id: 13, text: "Review LinkedIn engagement; A/B test post headlines.", completed: false, category: "Analytics" },
        ]
    },
    { 
        week: 4, 
        theme: "Scaling & Reporting",
        focus: ["SEO", "Analytics"],
        tasks: [
            { id: 14, text: "Check GSC for coverage errors and 404s; implement redirects.", completed: false, category: "SEO" },
            { id: 15, text: "Identify 3 new backlink opportunities from referring domains in GA4.", completed: false, category: "SEO" },
            { id: 16, text: "Compile 30-day report: GSC impressions, GA4 conversions, pilot leads.", completed: false, category: "Analytics" },
        ]
    }
];

export default function SEOActionPlan() {
    const [plan, setPlan] = useState(initialPlan);

    const toggleTask = (taskId) => {
        setPlan(plan.map(week => ({
            ...week,
            tasks: week.tasks.map(task => 
                task.id === taskId ? { ...task, completed: !task.completed } : task
            )
        })));
    };

    const completedTasks = plan.flatMap(w => w.tasks).filter(t => t.completed).length;
    const totalTasks = plan.flatMap(w => w.tasks).length;
    const progress = Math.round((completedTasks / totalTasks) * 100);

    return (
        <div className="space-y-6">
            <BreadcrumbNav currentPageName="SEO Action Plan" />
            
            <header className="text-center space-y-2">
                <h1 className="text-3xl font-bold tracking-tight text-gray-900">4-Week SEO & Content Execution Plan</h1>
                <p className="text-lg text-gray-600">Your interactive checklist for executing the no-cost optimization strategy.</p>
            </header>

            <Card>
                <CardHeader>
                    <CardTitle>Overall Progress</CardTitle>
                    <CardDescription>{completedTasks} of {totalTasks} tasks completed.</CardDescription>
                </CardHeader>
                <CardContent>
                    <Progress value={progress} className="w-full" />
                    <p className="text-center text-lg font-bold mt-2">{progress}% Complete</p>
                </CardContent>
            </Card>
            
            <div className="space-y-8">
                {plan.map(weekData => (
                    <Card key={weekData.week}>
                        <CardHeader>
                            <div className="flex justify-between items-center">
                                <CardTitle className="text-xl">Week {weekData.week}: {weekData.theme}</CardTitle>
                                <div className="flex gap-2">
                                    {weekData.focus.map(f => <Badge key={f} variant="secondary">{f}</Badge>)}
                                </div>
                            </div>
                        </CardHeader>
                        <CardContent className="space-y-3">
                            {weekData.tasks.map(task => (
                                <div 
                                    key={task.id} 
                                    className={`flex items-center gap-4 p-3 rounded-md transition-colors ${task.completed ? 'bg-green-50' : 'bg-gray-50'}`}
                                >
                                    <Checkbox
                                        id={`task-${task.id}`}
                                        checked={task.completed}
                                        onCheckedChange={() => toggleTask(task.id)}
                                        className="h-5 w-5"
                                    />
                                    <label 
                                        htmlFor={`task-${task.id}`}
                                        className={`flex-grow font-medium ${task.completed ? 'text-gray-500 line-through' : 'text-gray-800'}`}
                                    >
                                        {task.text}
                                    </label>
                                    <Badge variant="outline">{task.category}</Badge>
                                </div>
                            ))}
                        </CardContent>
                    </Card>
                ))}
            </div>

            <Card>
                <CardHeader>
                    <CardTitle>Expected Outcomes (by October 16, 2025)</CardTitle>
                </CardHeader>
                <CardContent className="grid md:grid-cols-3 gap-4 text-center">
                    <div className="p-4 bg-gray-50 rounded-lg">
                        <p className="text-2xl font-bold text-blue-700">15%</p>
                        <p className="text-sm text-gray-600">Impression Lift in GSC</p>
                    </div>
                    <div className="p-4 bg-gray-50 rounded-lg">
                        <p className="text-2xl font-bold text-green-700">2-5</p>
                        <p className="text-sm text-gray-600">Pilot Client Leads</p>
                    </div>
                    <div className="p-4 bg-gray-50 rounded-lg">
                        <p className="text-2xl font-bold text-purple-700">150+</p>
                        <p className="text-sm text-gray-600">LinkedIn Group Members</p>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}