import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Check, CheckCircle, FileText, Target, ArrowRight, Lightbulb } from 'lucide-react';
import { motion } from "framer-motion";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const checklistItems = [
    { 
        category: "Technical Volume (10 pages)",
        sprintOutput: "Weeks 1-5 of Daily Achievement Schedule",
        items: [
            { text: "Identification and Significance of the Problem", detail: "Clearly state the problem: SMBs cannot afford CMMC compliance. Source: Your GTM strategy & competitive analysis." },
            { text: "Phase I Technical Objectives", detail: "Feasibility of 'Me, Myself, and AI' model. Objective: Build an MVP that automates 10-20 CMMC controls via AI. Source: Sprint Weeks 3-5." },
            { text: "Phase I Work Plan", detail: "Your 8-week sprint plan is your work plan. Detail the tasks, duration, and milestones. Source: Daily Achievement Schedule." },
            { text: "Related Research", detail: "Cite research on AI in cybersecurity, LangChain, RAG, and existing GRC tools. Source: Mobile Study Guide research." },
            { text: "Key Personnel", detail: "Your resume, highlighting your deep domain expertise in this specific area." },
            { text: "Facilities and Equipment", detail: "Your desktop environment and AWS GovCloud architecture. Source: Sprint Weeks 1 & 3." }
        ]
    },
    { 
        category: "Commercialization Plan (5 pages)",
        sprintOutput: "Internal Business Strategy & Scaling Plan",
        items: [
            { text: "Value Proposition", detail: "Enterprise compliance results at an SMB price. 90% cheaper, 4x faster. Source: Competitive Comparison page." },
            { text: "Market Opportunity", detail: "31,500 underserved SMBs, $2.3B market gap due to CMMC enforcement. Source: Grant-Fueled Scaling Strategy." },
            { text: "Company/Team", detail: "Solo founder with deep expertise, using AI to scale. Lean, efficient, and fundable." },
            { text: "Product and/or Service", detail: "An AI-powered CMMC compliance platform. Detail the features built during your 8-week sprint." },
            { text: "Go-to-Market Strategy", detail: "Detail your phased approach to acquiring the first 100, then 1000 clients. Source: Internal Business Strategy." }
        ]
    },
    {
        category: "Cost Proposal",
        sprintOutput: "AWS Pricing Calculator & Sprint Plan",
        items: [
            { text: "Direct Labor", detail: "Your salary for the 6-12 month Phase I period (e.g., 1,040 hours @ $100/hr = $104,000)." },
            { text: "AWS GovCloud Costs", detail: "Estimate costs for a 12-month period based on scaling to 100 clients. Source: AWS Pricing Calculator." },
            { text: "Materials & Subscriptions", detail: "Costs for any software, API calls (OpenAI, etc.), and other direct costs." },
            { text: "Indirect Costs (F&A Rate)", detail: "Your federally negotiated Facilities & Administrative rate (if you have one) or a de minimis 10% rate on Modified Total Direct Costs (MTDC)." }
        ]
    }
];

export default function SBIRGrantRequirements() {
    return (
        <div className="space-y-8">
            <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center"
            >
                <Badge className="mb-4 bg-blue-100 text-blue-800">PROPOSAL CHECKLIST</Badge>
                <h1 className="text-4xl font-bold text-gray-900 mb-4">
                    SBIR Proposal Alignment
                </h1>
                <p className="text-xl text-gray-600 max-w-4xl mx-auto">
                    How your 56-day MVP sprint directly generates the content needed for the DoD SBIR 25.4 proposal due October 29, 2025.
                </p>
            </motion.div>

            <Alert className="bg-blue-50 border-blue-200">
                <Lightbulb className="h-4 w-4 text-blue-600" />
                <AlertTitle className="text-blue-800 font-bold">The Dual-Track Advantage</AlertTitle>
                <AlertDescription className="text-blue-700">
                    Don't think of this as "building then writing." You are building *in order to* write. Each technical milestone you complete is a paragraph in your proposal. Your sprint output IS your proposal's technical volume.
                </AlertDescription>
            </Alert>
            
            {checklistItems.map((section, index) => (
                <motion.div 
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.15 }}
                >
                    <Card className="border-l-4 border-blue-600">
                        <CardHeader>
                            <div className="flex justify-between items-start">
                                <div>
                                    <CardTitle className="text-2xl">{section.category}</CardTitle>
                                    <CardDescription>
                                        Sourced from: <strong>{section.sprintOutput}</strong>
                                    </CardDescription>
                                </div>
                                <FileText className="w-8 h-8 text-blue-400" />
                            </div>
                        </CardHeader>
                        <CardContent>
                            <ul className="space-y-4">
                                {section.items.map((item, i) => (
                                    <li key={i} className="flex items-start gap-3">
                                        <CheckCircle className="w-5 h-5 text-green-500 mt-1 flex-shrink-0" />
                                        <div>
                                            <h4 className="font-semibold">{item.text}</h4>
                                            <p className="text-sm text-gray-600">{item.detail}</p>
                                        </div>
                                    </li>
                                ))}
                            </ul>
                        </CardContent>
                    </Card>
                </motion.div>
            ))}
            
            <Card className="bg-gray-900 text-white">
                <CardHeader>
                    <CardTitle>Next Steps: From Plan to Submission</CardTitle>
                    <CardDescription className="text-gray-300">Your immediate actions to get started.</CardDescription>
                </CardHeader>
                <CardContent className="flex flex-col sm:flex-row gap-4">
                    <Button asChild size="lg" className="bg-red-600 hover:bg-red-700 flex-1">
                        <Link to={createPageUrl('SBIRFundingStrategy')}>
                            Review Target Topics & Deadlines <ArrowRight className="w-4 h-4 ml-2" />
                        </Link>
                    </Button>
                    <Button asChild size="lg" variant="secondary" className="flex-1">
                        <a href="https://www.dodsbirsttr.mil/" target="_blank" rel="noopener noreferrer">
                            Go to DoD SBIR Portal <ArrowRight className="w-4 h-4 ml-2" />
                        </a>
                    </Button>
                </CardContent>
            </Card>
        </div>
    );
}