
import React, { useState, useEffect, useCallback } from 'react';
import { useLocation } from 'react-router-dom';
import { ComplianceFramework } from '@/api/entities';
import { ComplianceTask } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { UploadFile } from "@/api/integrations";
import { generateCMMCReport } from "@/api/functions";
import { analyzeCMMCDocument } from "@/api/functions";
import { Loader2, ShieldCheck, FileUp, Download, MessageSquare, FileText, CheckCircle, AlertTriangle, Clock, Upload } from 'lucide-react';
import { toast } from "sonner";
import { motion } from "framer-motion";
import PolicyGenerator from '../components/assessment/PolicyGenerator';

const statusConfig = {
    pending_ai_analysis: { icon: Clock, color: "bg-gray-200 text-gray-800", text: "Pending" },
    ai_in_progress: { icon: Loader2, color: "bg-blue-100 text-blue-800", text: "AI Analyzing" },
    pending_human_review: { icon: AlertTriangle, color: "bg-yellow-100 text-yellow-800", text: "Review Required" },
    completed: { icon: CheckCircle, color: "bg-green-100 text-green-800", text: "Compliant" },
    rejected: { icon: AlertTriangle, color: "bg-red-100 text-red-800", text: "Needs Work" },
};

const complianceStatusColors = {
    'Compliant': 'bg-green-100 text-green-800',
    'Partially Compliant': 'bg-yellow-100 text-yellow-800', 
    'Non-compliant': 'bg-red-100 text-red-800',
    'Not Applicable': 'bg-gray-100 text-gray-800'
};

function DocumentUploadSection({ onAnalysisComplete }) {
    const [file, setFile] = useState(null);
    const [uploading, setUploading] = useState(false);
    const [uploadStatus, setUploadStatus] = useState('idle');

    const handleFileChange = (e) => {
        const selectedFile = e.target.files[0];
        if (selectedFile && ['application/pdf', 'text/plain'].includes(selectedFile.type)) {
            setFile(selectedFile);
            setUploadStatus('idle');
        } else {
            toast.error("Please upload a PDF or text file.");
        }
    };

    const handleUpload = async () => {
        if (!file) return;
        setUploading(true);
        setUploadStatus('uploading');

        try {
            toast.info("Uploading document...");
            const { file_url } = await UploadFile({ file });
            
            toast.success("Upload complete. Starting AI analysis...");
            const { data } = await analyzeCMMCDocument({ fileUrl: file_url });
            
            setUploadStatus('success');
            onAnalysisComplete(data);
            toast.success("CMMC Gap Analysis complete!");
        } catch (error) {
            console.error("Analysis failed:", error);
            setUploadStatus('error');
            toast.error("Analysis failed. Please try again.");
        } finally {
            setUploading(false);
        }
    };

    return (
        <Card>
            <CardHeader>
                <CardTitle className="flex items-center gap-2">
                    <FileUp className="w-5 h-5" />
                    Document Analysis
                </CardTitle>
                <CardDescription>Upload your policy document, network diagram, or current documentation for AI-powered gap analysis.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
                <Input 
                    type="file" 
                    accept=".pdf,.txt" 
                    onChange={handleFileChange}
                    disabled={uploading}
                />
                <Button 
                    onClick={handleUpload}
                    disabled={!file || uploading}
                    className="w-full"
                >
                    {uploading ? (
                        <span className="flex items-center">
                            <Loader2 className="animate-spin h-4 w-4 mr-2" />
                            Analyzing with AI...
                        </span>
                    ) : (
                        <span className="flex items-center">
                            <Upload className="h-4 w-4 mr-2" />
                            Analyze for CMMC Gaps
                        </span>
                    )}
                </Button>
                {uploadStatus === 'success' && (
                    <p className="text-green-600 flex items-center text-sm">
                        <CheckCircle className="h-4 w-4 mr-2" />
                        Analysis Complete - Results shown below
                    </p>
                )}
                {uploadStatus === 'error' && (
                    <p className="text-red-600 flex items-center text-sm">
                        <AlertTriangle className="h-4 w-4 mr-2" />
                        Analysis failed - Please try again
                    </p>
                )}
            </CardContent>
        </Card>
    );
}

function GapAnalysisResults({ analysisResult }) {
    if (!analysisResult) return null;

    return (
        <Card>
            <CardHeader>
                <CardTitle>AI Gap Analysis Results</CardTitle>
                <CardDescription>CMMC compliance gaps identified by AI, mapped to NIST 800-171 controls.</CardDescription>
            </CardHeader>
            <CardContent>
                <div className="space-y-4">
                    <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                        <h4 className="font-semibold text-blue-800 mb-2">Analysis Summary</h4>
                        <p className="text-blue-700 text-sm">{analysisResult.summary}</p>
                    </div>
                    
                    {analysisResult.gaps.length > 0 ? (
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Control</TableHead>
                                    <TableHead>Description</TableHead>
                                    <TableHead>Status</TableHead>
                                    <TableHead>Gap Description</TableHead>
                                    <TableHead>Recommendation</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {analysisResult.gaps.map((gap, index) => (
                                    <TableRow key={index}>
                                        <TableCell className="font-mono text-sm">{gap.control_id}</TableCell>
                                        <TableCell className="max-w-xs truncate">{gap.description}</TableCell>
                                        <TableCell>
                                            <Badge className={complianceStatusColors[gap.compliance_status] || complianceStatusColors['Not Applicable']}>
                                                {gap.compliance_status}
                                            </Badge>
                                        </TableCell>
                                        <TableCell className="max-w-sm">
                                            <p className="text-sm text-gray-600">{gap.gap_description}</p>
                                        </TableCell>
                                        <TableCell className="max-w-sm">
                                            <p className="text-sm text-green-700">{gap.recommendation}</p>
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    ) : (
                        <div className="text-center p-6 bg-green-50 rounded-lg">
                            <CheckCircle className="w-8 h-8 text-green-600 mx-auto mb-2" />
                            <p className="font-semibold text-green-800">No compliance gaps identified!</p>
                            <p className="text-sm text-green-600">The document appears to meet CMMC requirements based on AI analysis.</p>
                        </div>
                    )}
                </div>
            </CardContent>
        </Card>
    );
}

function TaskDetail({ task, onUpdate }) {
    const [comment, setComment] = useState("");
    const [file, setFile] = useState(null);
    const [uploading, setUploading] = useState(false);

    const handleFileChange = (e) => {
        setFile(e.target.files[0]);
    };

    const handleEvidenceSubmit = async () => {
        if (!file && !comment) {
            toast.error("Please provide evidence or a comment.");
            return;
        }
        setUploading(true);
        try {
            let fileUrl = task.evidence_files || "";
            if (file) {
                const uploadResult = await UploadFile({ file });
                fileUrl = uploadResult.file_url;
            }
            
            const newConversation = [
                ...(task.conversation || []),
                { sender: 'client', message: comment || 'File uploaded.', timestamp: new Date().toISOString() }
            ];

            await ComplianceTask.update(task.id, {
                evidence_files: fileUrl,
                status: 'pending_human_review',
                conversation: newConversation
            });
            
            onUpdate();
            setComment('');
            setFile(null);
            toast.success("Evidence submitted for expert review.");

        } catch (error) {
            console.error("Evidence submission failed:", error);
            toast.error("Failed to submit evidence.");
        } finally {
            setUploading(false);
        }
    };
    
    return (
        <Card className="col-span-2">
            <CardHeader>
                <CardTitle className="flex items-center gap-3">
                    <FileText className="w-5 h-5" /> 
                    {task.requirement_section}: {task.task_title}
                </CardTitle>
                <CardDescription>{task.task_description}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
                <div>
                    <h3 className="font-semibold mb-2">Conversation History</h3>
                    <div className="space-y-3 max-h-48 overflow-y-auto bg-gray-50 p-3 rounded-md">
                        {task.conversation?.length > 0 ? task.conversation.map((msg, index) => (
                            <div key={index} className={`text-sm ${msg.sender === 'client' ? 'text-right' : 'text-left'}`}>
                                <p className={`p-2 rounded-lg inline-block ${msg.sender === 'client' ? 'bg-blue-100' : 'bg-gray-200'}`}>{msg.message}</p>
                                <p className="text-xs text-gray-500 mt-1">{new Date(msg.timestamp).toLocaleString()}</p>
                            </div>
                        )) : <p className="text-sm text-gray-500 text-center">No comments yet.</p>}
                    </div>
                </div>

                <div className="space-y-4">
                    <h3 className="font-semibold">Submit Evidence & Comments</h3>
                    <Textarea 
                        placeholder="Add your notes or questions here..."
                        value={comment}
                        onChange={e => setComment(e.target.value)}
                    />
                    <div className="flex items-center gap-2">
                        <FileUp className="w-4 h-4 text-gray-500"/>
                        <Input type="file" onChange={handleFileChange} />
                    </div>
                    <Button onClick={handleEvidenceSubmit} disabled={uploading}>
                        {uploading ? <><Loader2 className="w-4 h-4 animate-spin mr-2"/>Submitting...</> : "Submit for Expert Review"}
                    </Button>
                </div>
            </CardContent>
        </Card>
    );
}

export default function CMMCReadinessAssessment() {
    const [framework, setFramework] = useState(null);
    const [tasks, setTasks] = useState([]);
    const [selectedTask, setSelectedTask] = useState(null);
    const [loading, setLoading] = useState(true);
    const [analysisResult, setAnalysisResult] = useState(null);
    const location = useLocation();

    const loadData = useCallback(async (frameworkId) => {
        setLoading(true);
        try {
            const fw = await ComplianceFramework.get(frameworkId);
            const taskList = await ComplianceTask.filter({ framework_id: frameworkId });
            setFramework(fw);
            const sortedTasks = taskList.sort((a, b) => a.requirement_section.localeCompare(b.requirement_section, undefined, { numeric: true }));
            setTasks(sortedTasks);
            setSelectedTask(currentSelected => {
                const isCurrentSelectedValid = sortedTasks.some(t => t.id === currentSelected?.id);
                return isCurrentSelectedValid ? currentSelected : (sortedTasks.length > 0 ? sortedTasks[0] : null);
            });
        } catch (error) {
            console.error("Failed to load compliance data:", error);
            toast.error("Could not load your assessment project.");
        } finally {
            setLoading(false);
        }
    }, []); 
    
    useEffect(() => {
        const params = new URLSearchParams(location.search);
        const frameworkId = params.get('frameworkId');
        if (frameworkId) {
            loadData(frameworkId);
        } else {
            setLoading(false);
        }
    }, [location.search, loadData]);

    const handleTaskSelect = (task) => {
        setSelectedTask(task);
    };

    const downloadReport = async () => {
        toast.info("Generating your C3PAO report package...");
        try {
            const { data } = await generateCMMCReport({ framework_id: framework.id });
            const byteCharacters = atob(data.fileContent);
            const byteNumbers = new Array(byteCharacters.length);
            for (let i = 0; i < byteCharacters.length; i++) {
                byteNumbers[i] = byteCharacters.charCodeAt(i);
            }
            const byteArray = new Uint8Array(byteNumbers);
            const blob = new Blob([byteArray], {type: 'application/pdf'});

            const link = document.createElement('a');
            link.href = window.URL.createObjectURL(blob);
            link.download = data.fileName;
            link.click();
            toast.success("Report downloaded successfully!");

        } catch (error) {
            console.error("Report generation failed:", error);
            toast.error("Failed to generate report.");
        }
    };

    if (loading) return (
        <div className="flex items-center justify-center h-screen">
            <Loader2 className="w-12 h-12 animate-spin text-blue-600"/>
            <span className="ml-3 text-lg">Loading your CMMC assessment...</span>
        </div>
    );
    
    if (!framework) return (
        <div className="text-center p-8">
            <AlertTriangle className="w-12 h-12 text-yellow-600 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Invalid Assessment Link</h3>
            <p className="text-gray-600">Please contact support for assistance accessing your CMMC assessment.</p>
        </div>
    );

    const completedTasks = tasks.filter(t => t.status === 'completed').length;
    const progress = Math.round((completedTasks / tasks.length) * 100);

    return (
        <div className="min-h-screen bg-gray-50 p-4 sm:p-6 lg:p-8">
            <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
                <Card className="border-blue-200 bg-gradient-to-r from-blue-50 to-indigo-50">
                    <CardHeader>
                        <div className="flex justify-between items-start">
                            <div>
                                <CardTitle className="text-2xl flex items-center gap-3 text-blue-900">
                                    <ShieldCheck className="w-8 h-8" />
                                    CMMC Readiness Portal for {framework.organization_name}
                                </CardTitle>
                                <CardDescription className="text-blue-700">Your AI-powered path to CMMC Level 2 compliance in 8 weeks.</CardDescription>
                            </div>
                            <Button onClick={downloadReport} className="bg-blue-600 hover:bg-blue-700">
                                <Download className="w-4 h-4 mr-2" /> Download C3PAO Package
                            </Button>
                        </div>
                    </CardHeader>
                    <CardContent>
                        <div className="flex items-center gap-4">
                            <span className="font-medium text-blue-900">{progress}% Complete</span>
                            <Progress value={progress} className="flex-1" />
                            <span className="text-sm text-blue-700">{completedTasks} of {tasks.length} controls compliant</span>
                        </div>
                    </CardContent>
                </Card>
            </motion.div>

            <div className="grid grid-cols-1 xl:grid-cols-4 gap-6 mb-8">
                <div className="xl:col-span-1">
                    <PolicyGenerator />
                </div>
                
                <div className="xl:col-span-3">
                    <DocumentUploadSection onAnalysisComplete={setAnalysisResult} />
                </div>
            </div>

            <GapAnalysisResults analysisResult={analysisResult} />

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-8">
                <Card className="lg:col-span-1">
                    <CardHeader>
                        <CardTitle>CMMC Control Tasks</CardTitle>
                        <CardDescription>Track your progress through all 110 NIST 800-171 controls</CardDescription>
                    </CardHeader>
                    <CardContent className="max-h-[60vh] overflow-y-auto pr-2">
                        <div className="space-y-2">
                            {tasks.map(task => {
                                const config = statusConfig[task.status] || statusConfig.pending_ai_analysis;
                                const Icon = config.icon;
                                return (
                                    <button
                                        key={task.id}
                                        onClick={() => handleTaskSelect(task)}
                                        className={`w-full text-left p-3 rounded-md border flex items-center justify-between transition-all ${selectedTask?.id === task.id ? 'bg-blue-50 border-blue-400' : 'bg-white hover:bg-gray-50'}`}
                                    >
                                        <div className="flex-grow">
                                            <p className="font-semibold text-sm">{task.requirement_section}</p>
                                            <p className="text-xs text-gray-600 truncate">{task.task_title}</p>
                                        </div>
                                        <Badge className={`ml-2 text-xs ${config.color}`}>
                                            <Icon className={`w-3 h-3 mr-1 ${config.text === 'AI Analyzing' ? 'animate-spin': ''}`}/> 
                                            {config.text}
                                        </Badge>
                                    </button>
                                )
                            })}
                        </div>
                    </CardContent>
                </Card>
                
                {selectedTask && <TaskDetail task={selectedTask} onUpdate={() => loadData(framework.id)} />}
            </div>
        </div>
    );
}
