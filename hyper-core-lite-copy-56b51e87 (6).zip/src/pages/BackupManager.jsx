
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { exportAppBackup } from "@/api/functions";
import { Download, Copy, CheckCircle, AlertTriangle, Github, Terminal, FileText } from 'lucide-react';
import { motion } from "framer-motion";
import { toast } from "sonner";

export default function BackupManager() {
    const [backupData, setBackupData] = useState(null);
    const [loading, setLoading] = useState(false);
    const [step, setStep] = useState(1);

    const generateBackup = async () => {
        setLoading(true);
        toast.info("Generating complete app backup...");
        
        try {
            const response = await exportAppBackup();
            if (response.status === 200) {
                setBackupData(response.data);
                setStep(2);
                toast.success("Backup package generated successfully!");
            } else {
                toast.error("Failed to generate backup");
            }
        } catch (error) {
            console.error('Backup error:', error);
            toast.error("Backup generation failed");
        } finally {
            setLoading(false);
        }
    };

    const copyToClipboard = (text) => {
        navigator.clipboard.writeText(text);
        toast.success("Copied to clipboard!");
    };

    // The downloadBackupScript function is removed as the commands will be shown directly.

    const downloadFileList = () => {
        if (!backupData) return;
        
        const fileList = Object.entries(backupData.export.fileInventory)
            .map(([category, files]) => {
                return `# ${category.toUpperCase()}\n${files.join('\n')}\n`;
            }).join('\n');
            
        const blob = new Blob([fileList], { type: 'text/plain' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'hypercore-file-list.txt';
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        a.remove();
        
        toast.success("File list downloaded!");
    };

    return (
        <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50 p-6">
            <div className="max-w-7xl mx-auto">
                <motion.div
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="mb-8"
                >
                    <h1 className="text-4xl font-bold text-gray-900 mb-2 flex items-center gap-3">
                        <Github className="w-10 h-10 text-gray-800" />
                        HyperCore Backup Manager
                    </h1>
                    <p className="text-lg text-gray-600">
                        Automated backup system for securing your intellectual property on GitHub
                    </p>
                </motion.div>

                {/* Step Indicator */}
                <div className="flex items-center justify-center mb-8">
                    <div className="flex items-center gap-4">
                        <div className={`flex items-center gap-2 ${step >= 1 ? 'text-blue-600' : 'text-gray-400'}`}>
                            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 1 ? 'bg-blue-600 text-white' : 'bg-gray-300'}`}>
                                1
                            </div>
                            <span>Generate</span>
                        </div>
                        <div className="w-12 h-1 bg-gray-300"></div>
                        <div className={`flex items-center gap-2 ${step >= 2 ? 'text-blue-600' : 'text-gray-400'}`}>
                            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 2 ? 'bg-blue-600 text-white' : 'bg-gray-300'}`}>
                                2
                            </div>
                            <span>Download</span>
                        </div>
                        <div className="w-12 h-1 bg-gray-300"></div>
                        <div className={`flex items-center gap-2 ${step >= 3 ? 'text-blue-600' : 'text-gray-400'}`}>
                            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 3 ? 'bg-blue-600 text-white' : 'bg-gray-300'}`}>
                                3
                            </div>
                            <span>Execute</span>
                        </div>
                    </div>
                </div>

                {/* Step 1: Generate Backup */}
                {step === 1 && (
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <FileText className="w-5 h-5 text-blue-600" />
                                Step 1: Generate Backup Package
                            </CardTitle>
                            <CardDescription>
                                Create a complete export of your HyperCore Lite application including all entities, pages, components, and functions.
                            </CardDescription>
                        </CardHeader>
                        <CardContent>
                            <Button 
                                onClick={generateBackup}
                                disabled={loading}
                                className="w-full bg-blue-600 hover:bg-blue-700"
                                size="lg"
                            >
                                {loading ? "Generating..." : "Generate Complete Backup"}
                            </Button>
                        </CardContent>
                    </Card>
                )}

                {/* Step 2: Download Resources */}
                {step >= 2 && backupData && (
                    <div className="space-y-6">
                        <Card className="border-green-200 bg-green-50">
                            <CardHeader>
                                <CardTitle className="text-green-800 flex items-center gap-2">
                                    <CheckCircle className="w-5 h-5" />
                                    Backup Generated Successfully!
                                </CardTitle>
                                <CardDescription className="text-green-700">
                                    Found {backupData.instructions.totalFiles} files ready for backup.
                                    Export generated by {backupData.export.metadata.exportedBy} on {new Date(backupData.export.metadata.exportDate).toLocaleString()}
                                </CardDescription>
                            </CardHeader>
                            <CardContent>
                                {/* Only the "Download File Checklist" button remains, as backup script commands are shown below */}
                                <div className="grid grid-cols-1 gap-4"> 
                                    <Button onClick={downloadFileList} variant="outline" className="flex items-center gap-2">
                                        <FileText className="w-4 h-4" />
                                        Download File Checklist
                                    </Button>
                                </div>
                            </CardContent>
                        </Card>

                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2">
                                    <Terminal className="w-5 h-5 text-gray-600" />
                                    Step 2: Execute Automated Setup
                                </CardTitle>
                                <CardDescription>
                                    Run these commands in your terminal to create the directory structure and prepare for file copying.
                                </CardDescription>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                <div>
                                    <h4 className="font-semibold mb-2">1. Make the script executable and run it:</h4>
                                    <div className="bg-black rounded-lg p-3 font-mono text-green-400 text-sm">
                                        <div>chmod +x ~/Downloads/hypercore-backup.sh</div>
                                        <div>~/Downloads/hypercore-backup.sh</div>
                                    </div>
                                    <Button 
                                        size="sm" 
                                        variant="outline" 
                                        className="mt-2"
                                        onClick={() => copyToClipboard("chmod +x ~/Downloads/hypercore-backup.sh\n~/Downloads/hypercore-backup.sh")}
                                    >
                                        <Copy className="w-3 h-3 mr-1" />
                                        Copy Commands
                                    </Button>
                                </div>

                                <div>
                                    <h4 className="font-semibold mb-2">2. Alternative: Manual directory creation:</h4>
                                    <Textarea
                                        value={backupData.backupScript}
                                        readOnly
                                        rows={8}
                                        className="font-mono text-xs bg-gray-50"
                                    />
                                    <Button 
                                        size="sm" 
                                        variant="outline" 
                                        className="mt-2"
                                        onClick={() => copyToClipboard(backupData.backupScript)}
                                    >
                                        <Copy className="w-3 h-3 mr-1" />
                                        Copy Entire Script
                                    </Button>
                                </div>
                            </CardContent>
                        </Card>

                        <Card className="border-yellow-200 bg-yellow-50">
                            <CardHeader>
                                <CardTitle className="text-yellow-800 flex items-center gap-2">
                                    <AlertTriangle className="w-5 h-5" />
                                    Step 3: Manual File Copy (Required)
                                </CardTitle>
                                <CardDescription className="text-yellow-700">
                                    Unfortunately, Base44 doesn't allow direct file system access, so you need to manually copy each file from the Base44 editor to your local directory.
                                </CardDescription>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-4">
                                    <div className="bg-white rounded-lg p-4 border">
                                        <h4 className="font-semibold mb-2">File Categories to Copy:</h4>
                                        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-sm">
                                            {Object.entries(backupData.export.fileInventory).map(([category, files]) => (
                                                <div key={category}>
                                                    <Badge className="mb-1">{category} ({files.length})</Badge>
                                                    <div className="text-xs text-gray-600">
                                                        {files.slice(0, 3).map(file => (
                                                            <div key={file}>{file}</div>
                                                        ))}
                                                        {files.length > 3 && <div>...and {files.length - 3} more</div>}
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                    
                                    <div>
                                        <h4 className="font-semibold mb-2">After copying all files, commit to GitHub:</h4>
                                        <div className="bg-black rounded-lg p-3 font-mono text-green-400 text-sm">
                                            {backupData.instructions.gitCommands.map((cmd, index) => (
                                                <div key={index}>{cmd}</div>
                                            ))}
                                        </div>
                                        <Button 
                                            size="sm" 
                                            variant="outline" 
                                            className="mt-2"
                                            onClick={() => copyToClipboard(backupData.instructions.gitCommands.join('\n'))}
                                        >
                                            <Copy className="w-3 h-3 mr-1" />
                                            Copy Git Commands
                                        </Button>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>

                        <Button 
                            onClick={() => setStep(3)}
                            className="w-full bg-green-600 hover:bg-green-700"
                        >
                            Mark as Complete
                        </Button>
                    </div>
                )}

                {/* Step 3: Completion */}
                {step >= 3 && (
                    <Card className="border-green-200 bg-green-50">
                        <CardHeader>
                            <CardTitle className="text-green-800 flex items-center gap-2">
                                <CheckCircle className="w-5 h-5" />
                                Backup Complete!
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="text-green-700 mb-4">
                                Your HyperCore Lite application is now safely backed up to GitHub. 
                                You can repeat this process anytime you make significant changes.
                            </p>
                            <Button 
                                onClick={() => {
                                    setStep(1);
                                    setBackupData(null);
                                }}
                                variant="outline"
                            >
                                Create Another Backup
                            </Button>
                        </CardContent>
                    </Card>
                )}
            </div>
        </div>
    );
}
