import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Zap, Target, BrainCircuit, CheckCircle, DollarSign, BarChart, Rocket } from 'lucide-react';
import BreadcrumbNav from '../components/navigation/BreadcrumbNav';

const hypercoreSuite = [
    {
        title: "Real-Time Drift Detection Dashboard",
        features: "Continuous monitoring of all 110 NIST 800-171 controls, instant alerts for configuration changes, privilege escalations, and system modifications.",
        edge: "Integrates with AWS GovCloud, reducing drift risks by 40%."
    },
    {
        title: "AI Risk Forecasting & Predictive Analytics",
        features: "ML trend analysis, predictive compliance failure modeling, and confidence-scored recommendations.",
        edge: "Uses closed LLMs trained on CMMC 2.0 data, boosting DIB-specific accuracy by 25%."
    },
    {
        title: "Smart Contract Flow-Down Analyzer",
        features: "NLP parsing of DoD contracts, automatic DFARS clause identification, deadline extraction, and risk assessment.",
        edge: "Cuts manual contract review time by 60% for multi-tier DIB supply chains."
    },
    {
        title: "90-Day AI Success Plan Generator",
        features: "Automated implementation roadmap, weekly task prioritization, and milestone tracking.",
        edge: "Generates SSPs/POA&Ms in JSON-LD for rapid SPRS submission, accelerating Phase 1 readiness."
    }
];

const competitors = [
    { name: "TrustCloud", pricing: "$5K-15K/year", weakness: "Focuses on scoring vs. actionable remediation; relies on periodic scans." },
    { name: "Concentric AI", pricing: "$10K-25K/year", weakness: "Finds problems but doesn't generate solutions; monitoring limited to data flows." },
    { name: "CMMC2.AI", pricing: "$99-499/month", weakness: "Guidance-only, not full automation; lacks native continuous monitoring." },
    { name: "StrikeGraph", pricing: "$4K-12K/year", weakness: "Static document generation vs. a living compliance system; monitoring is event-based." },
    { name: "Risk Cognizance GRC", pricing: "$7K-20K/year", weakness: "GRC-first, not AI-native; monitoring is a periodic hybrid." },
    { name: "Scytale", pricing: "$6K-18K/year", weakness: "Multi-framework focus dilutes CMMC specialization; can cause alert fatigue." },
    { name: "ComplAI", pricing: "$8K-22K/year", weakness: "Provides recommendations vs. actual deliverables; no built-in monitoring." },
    { name: "Rackspace-SMPL-C", pricing: "$79+/month", weakness: "Cloud-dependent (not platform-agnostic); monitoring is limited to the hosted enclave." },
];

const marketGaps = [
    { title: "Contract Intelligence", description: "No competitors match our NLP-driven DFARS clause extraction. This addresses a 40% error rate in subcontractor flow-downs." },
    { title: "True Continuous Lifecycle", description: "Our real-time drift detection surpasses the periodic scans used by most competitors like TrustCloud and Concentric AI." },
    { title: "Actionable Automation", description: "We generate SPRS-ready documents, outpacing tools like ComplAI that only provide recommendations." },
    { title: "Virginia Specialization", description: "Our NoVA-native focus provides tailored intelligence for the local DIB ecosystem, a niche national tools overlook." }
];

export default function MarketDisruptorAssessment() {
    return (
        <div className="space-y-8 p-4 md:p-6">
            <BreadcrumbNav currentPageName="MarketDisruptorAssessment" />
            <div className="text-center">
                <h1 className="text-3xl font-bold text-gray-900 mb-4 flex items-center justify-center gap-3">
                    <Zap className="w-8 h-8 text-red-500" />
                    AI-First CMMC Market Analysis (2025)
                </h1>
                <p className="text-lg text-gray-600 max-w-4xl mx-auto">
                    A complete analysis of the AI-native CMMC compliance market, positioning HyperCore to dominate the DIB subcontractor space.
                </p>
            </div>

            <Card className="bg-blue-50 border-blue-200">
                <CardHeader>
                    <CardTitle className="flex items-center gap-3"><Rocket className="w-6 h-6 text-blue-700"/>HyperCore's Unfair Advantage</CardTitle>
                    <CardDescription>Our AI-native suite is built for the complete compliance lifecycle, not just static assessments.</CardDescription>
                </CardHeader>
                <CardContent className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                    {hypercoreSuite.map((tool, index) => (
                        <div key={index} className="p-4 bg-white rounded-lg border">
                            <h3 className="font-semibold text-gray-800 mb-2">{tool.title}</h3>
                            <p className="text-sm text-gray-600 mb-3">{tool.features}</p>
                            <div className="text-xs text-blue-700 font-medium bg-blue-100 p-2 rounded">
                                <strong>2025 Edge:</strong> {tool.edge}
                            </div>
                        </div>
                    ))}
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>Competitor Landscape</CardTitle>
                    <CardDescription>Analysis of the 8 key AI-first tools in the 2025 DIB market.</CardDescription>
                </CardHeader>
                <CardContent>
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Tool</TableHead>
                                <TableHead>Est. Pricing (2025)</TableHead>
                                <TableHead>Primary Weakness</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {competitors.map((c, i) => (
                                <TableRow key={i}>
                                    <TableCell className="font-medium">{c.name}</TableCell>
                                    <TableCell>{c.pricing}</TableCell>
                                    <TableCell className="text-red-600">{c.weakness}</TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </CardContent>
            </Card>
            
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-3"><Target className="w-6 h-6 text-green-600"/>Market Gaps HyperCore Fills</CardTitle>
                </CardHeader>
                <CardContent className="grid md:grid-cols-2 gap-4">
                    {marketGaps.map((gap, i) => (
                         <div key={i} className="p-4 bg-green-50 border border-green-200 rounded-lg">
                            <h3 className="font-semibold text-green-800">{gap.title}</h3>
                            <p className="text-sm text-green-700">{gap.description}</p>
                        </div>
                    ))}
                </CardContent>
            </Card>

            <Alert className="bg-gray-900 text-white border-gray-700">
                <BrainCircuit className="h-5 w-5 text-blue-400" />
                <AlertTitle className="text-xl font-bold text-white">2025 Market Outlook & Recommendations</AlertTitle>
                <AlertDescription className="mt-4 space-y-3">
                    <p>The DIB compliance tool market is projected to hit **$2.5B**, with 70% of spend focused on Level 1 & 2 solutions for the 300K+ subcontractors. AI adoption is soaring by 45% due to the Q4 2025 Phase 1 rollout mandates.</p>
                    <div className="flex items-center gap-4 pt-2">
                        <DollarSign className="w-5 h-5 text-green-400"/>
                        <p><strong>Positioning:</strong> Target 25-30% of the NoVA SMB market through our affordability and lifecycle focus. Prioritize the PreVeil bundled solution for a 20% revenue share.</p>
                    </div>
                    <div className="flex items-center gap-4">
                         <BarChart className="w-5 h-5 text-yellow-400"/>
                         <p><strong>Risk Mitigation:</strong> Highlight our continuous monitoring as the antidote to False Claims Act penalties, a major pain point for primes.</p>
                    </div>
                </AlertDescription>
            </Alert>
        </div>
    );
}