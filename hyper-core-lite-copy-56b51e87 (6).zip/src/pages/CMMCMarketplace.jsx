import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Store, Clipboard, CheckSquare, FileText, ExternalLink } from "lucide-react";
import { motion } from "framer-motion";
import { toast } from "sonner";

const profileContent = {
    companyDescription: "We are a next-generation cybersecurity firm specializing in AI-powered compliance automation. Our flagship platform, HyperCore, accelerates CMMC and FedRAMP readiness by reducing audit preparation from months to weeks. We empower Defense Industrial Base contractors with continuous compliance, real-time risk assessment, and automated evidence collection, ensuring they meet DoD requirements efficiently and affordably.",
    servicesOffered: "• CMMC Level 1-3 Readiness Assessments\n• AI-Powered Gap Analysis & Remediation Planning\n• Automated Policy and Procedure Generation\n• Continuous Compliance Monitoring\n• Managed CMMC Compliance Service (RPO)\n• FedRAMP & NIST SP 800-171 Consulting",
};

const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    toast.success("Copied to clipboard!");
};

export default function CMMCMarketplace() {
    return (
        <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50 p-6">
            <div className="max-w-7xl mx-auto">
                <motion.div
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="mb-8"
                >
                    <h1 className="text-4xl font-bold text-gray-900 mb-2 flex items-center gap-3">
                        <Store className="w-10 h-10 text-blue-600" />
                        CMMC Provider Marketplace Onboarding
                    </h1>
                    <p className="text-lg text-gray-600">
                        Become an official CMMC Registered Provider Organization (RPO).
                    </p>
                </motion.div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.2 }}
                        className="space-y-6"
                    >
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2"><CheckSquare className="w-5 h-5 text-green-600" /> RPO Registration Checklist</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-4 text-gray-700">
                                <div className="flex items-start gap-3"><div className="font-bold text-green-600 mt-1">1.</div><div><span className="font-semibold">Register on The CyberAB Portal.</span> Create an account on the official CMMC Accreditation Body website to begin the process.</div></div>
                                <div className="flex items-start gap-3"><div className="font-bold text-green-600 mt-1">2.</div><div><span className="font-semibold">Complete RPO Application.</span> Fill out the organizational details and pay the annual registration fee.</div></div>
                                <div className="flex items-start gap-3"><div className="font-bold text-green-600 mt-1">3.</div><div><span className="font-semibold">Submit Your Company Profile.</span> Use the generator on the right to create your marketing materials for the official marketplace.</div></div>
                                <div className="flex items-start gap-3"><div className="font-bold text-green-600 mt-1">4.</div><div><span className="font-semibold">Pass Background Check.</span> Ensure all associated individuals pass the required organizational background screening.</div></div>
                                <a href="https://cyberab.org/CMMC-Ecosystem/Registered-Provider-Organizations-RPOs" target="_blank" rel="noopener noreferrer">
                                    <Button className="w-full mt-4">Go to CyberAB Portal <ExternalLink className="w-4 h-4 ml-2" /></Button>
                                </a>
                            </CardContent>
                        </Card>
                    </motion.div>

                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.4 }}
                    >
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2"><FileText className="w-5 h-5 text-purple-600" /> Marketplace Profile Generator</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                <div>
                                    <label className="text-sm font-semibold">Company Description</label>
                                    <Textarea value={profileContent.companyDescription} readOnly rows={5} className="mt-1 bg-gray-50" />
                                    <Button size="sm" variant="outline" className="mt-2" onClick={() => copyToClipboard(profileContent.companyDescription)}><Clipboard className="w-3 h-3 mr-2" />Copy</Button>
                                </div>
                                <div>
                                    <label className="text-sm font-semibold">Services Offered</label>
                                    <Textarea value={profileContent.servicesOffered} readOnly rows={6} className="mt-1 bg-gray-50" />
                                    <Button size="sm" variant="outline" className="mt-2" onClick={() => copyToClipboard(profileContent.servicesOffered)}><Clipboard className="w-3 h-3 mr-2" />Copy</Button>
                                </div>
                            </CardContent>
                        </Card>
                    </motion.div>
                </div>
            </div>
        </div>
    );
}