
import React from 'react';
import ReportGeneratorComponent from '../components/reporting/ReportGeneratorComponent';
import ChatbotAgentReportGenerator from '../components/reporting/ChatbotAgentReportGenerator';
import BreadcrumbNav from '../components/navigation/BreadcrumbNav';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { FileText, Bot } from 'lucide-react'; // Import Bot icon

export default function ReportGenerator() {
    return (
        <div className="space-y-6">
            <BreadcrumbNav currentPageName="ReportGenerator" />

            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                        <FileText className="w-6 h-6 text-blue-600" />
                        Client-Side CMMC Report Generator
                    </CardTitle>
                    <CardDescription>
                        This tool demonstrates client-side PDF generation from structured JSON data. Click the button to generate a sample CMMC compliance report directly in your browser.
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <ReportGeneratorComponent />
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                        <Bot className="w-6 h-6 text-purple-600" />
                        AI Chatbot Agent Strategy Report
                    </CardTitle>
                    <CardDescription>
                        This report outlines four key approaches (No-Code, Low-Code, Full-Stack, Local-Only) for developing custom AI chatbot CRM agents to support DFARS/CMMC compliance, highlighting HyperCore's advantages for each.
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <ChatbotAgentReportGenerator />
                </CardContent>
            </Card>
        </div>
    );
}
