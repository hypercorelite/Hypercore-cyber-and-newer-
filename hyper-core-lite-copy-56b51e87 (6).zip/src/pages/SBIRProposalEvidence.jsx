import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { LetterOfIntent } from "@/api/entities";
import { LoadingSpinner } from '../components/ui/LoadingSpinner';
import { toast } from "sonner";
import { Download, FileText, BarChart, ExternalLink, Award, Users } from 'lucide-react';
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function SBIRProposalEvidence() {
    const [lois, setLois] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchLOIs = async () => {
            try {
                // This will fetch REAL submissions. If none exist, it will be empty.
                const data = await LetterOfIntent.list('-created_date');
                setLois(data);
            } catch (error) {
                toast.error("Failed to load Letters of Intent.");
                console.error(error);
            } finally {
                setLoading(false);
            }
        };
        fetchLOIs();
    }, []);

    const downloadCSV = () => {
        if (lois.length === 0) {
            toast.warning("No Letters of Intent to export yet. Real data will appear here as partners submit authentic LOIs.");
            return;
        }

        const headers = [
            "Company Name", "CAGE Code", "UEI", "Representative Name", "Title", "Email",
            "Commitment Level", "Priority Feature", "Signature Date"
        ];
        
        const rows = lois.map(loi => [
            `"${loi.companyName || ''}"`,
            `"${loi.cageCode || ''}"`,
            `"${loi.uei || ''}"`,
            `"${loi.repName || ''}"`,
            `"${loi.repTitle || ''}"`,
            `"${loi.repEmail || ''}"`,
            `"${loi.commitmentLevel || ''}"`,
            `"${loi.priorityFeatures || ''}"`,
            `"${loi.signatureDate || ''}"`
        ].join(','));

        const csvContent = "data:text/csv;charset=utf-8," 
            + headers.join(',') + "\n" 
            + rows.join("\n");

        const encodedUri = encodeURI(csvContent);
        const link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", "SBIR_Appendix_Letters_of_Intent.csv");
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);

        toast.success("Successfully exported LOIs for SBIR Appendix.");
    };

    return (
        <div className="space-y-8 p-4 md:p-6">
            <BreadcrumbNav currentPageName="SBIRProposalEvidence" />
            <CardHeader className="px-0">
                <CardTitle className="flex items-center gap-3 text-3xl font-bold">
                    <Award className="w-8 h-8 text-blue-600" />
                    SBIR Proposal Evidence Collection Hub
                </CardTitle>
                <CardDescription>
                    Central dashboard for collecting authentic Letters of Intent from real DoD contractors using our platform.
                </CardDescription>
            </CardHeader>

            <Alert className="bg-blue-50 border-blue-200">
                <Users className="h-4 w-4 text-blue-700" />
                <AlertTitle className="font-bold text-blue-800">Status: Ready to Collect Real Evidence</AlertTitle>
                <AlertDescription className="text-blue-700">
                    Our platform is fully operational and ready to serve DoD contractors. This dashboard will populate with authentic Letters of Intent as real partners complete assessments and submit commitments through our <Link to={createPageUrl('LOIGenerator')} className="underline font-semibold">LOI Generator</Link>. Any previous sample data has been cleared.
                </AlertDescription>
            </Alert>

            <Card>
                <CardHeader>
                    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                        <div>
                            <CardTitle>Authentic Letters of Intent</CardTitle>
                            <CardDescription>
                                {lois.length} real submission{lois.length !== 1 && 's'} from actual DoD contractors. This will be your market validation evidence.
                            </CardDescription>
                        </div>
                        <Button onClick={downloadCSV} disabled={lois.length === 0}>
                            <Download className="w-4 h-4 mr-2" />
                            Export for SBIR Appendix (.csv)
                        </Button>
                    </div>
                </CardHeader>
                <CardContent>
                    {loading ? <LoadingSpinner /> : (
                        <div className="overflow-x-auto">
                            <Table>
                                <TableHeader>
                                    <TableRow>
                                        <TableHead>Company Name</TableHead>
                                        <TableHead>Representative</TableHead>
                                        <TableHead>Commitment Level</TableHead>
                                        <TableHead>Priority Feature</TableHead>
                                        <TableHead>Date Signed</TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {lois.length > 0 ? lois.map(loi => (
                                        <TableRow key={loi.id}>
                                            <TableCell className="font-medium">{loi.companyName}</TableCell>
                                            <TableCell>{loi.repName} ({loi.repTitle})</TableCell>
                                            <TableCell>
                                                <Badge variant="secondary">{loi.commitmentLevel}</Badge>
                                            </TableCell>
                                            <TableCell>{loi.priorityFeatures}</TableCell>
                                            <TableCell>
                                                {loi.signatureDate && loi.signatureDate !== '1969-12-31' ? 
                                                    new Date(loi.signatureDate).toLocaleDateString() : 
                                                    'Date not recorded properly'
                                                }
                                            </TableCell>
                                        </TableRow>
                                    )) : (
                                        <TableRow>
                                            <TableCell colSpan={5} className="text-center text-gray-500 py-8">
                                                No authentic Letters of Intent submitted yet. Platform is ready to collect real evidence from DoD contractors who use our tools.
                                            </TableCell>
                                        </TableRow>
                                    )}
                                </TableBody>
                            </Table>
                        </div>
                    )}
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>Next Steps: Gather Real Evidence</CardTitle>
                    <CardDescription>How to collect authentic testimonials and commitments for SBIR proposal</CardDescription>
                </CardHeader>
                <CardContent className="grid md:grid-cols-2 gap-4">
                    <Link to={createPageUrl('PartnershipTrial')} className="block p-4 border rounded-lg hover:bg-gray-50">
                        <h4 className="font-semibold flex items-center gap-2 text-blue-700"><Users className="w-5 h-5"/>Free Trial Program</h4>
                        <p className="text-sm text-gray-600">Direct potential partners to test our platform and provide real feedback.</p>
                    </Link>
                    <Link to={createPageUrl('AnalyticsDashboard')} className="block p-4 border rounded-lg hover:bg-gray-50">
                        <h4 className="font-semibold flex items-center gap-2 text-green-700"><BarChart className="w-5 h-5"/>Usage Analytics</h4>
                        <p className="text-sm text-gray-600">Track real user engagement and platform adoption metrics.</p>
                    </Link>
                </CardContent>
            </Card>
        </div>
    );
}