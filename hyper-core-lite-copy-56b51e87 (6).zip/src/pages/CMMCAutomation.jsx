import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { UploadFile } from "@/api/integrations";
import { analyzeCMMCDocument } from "@/api/functions";
import { Loader2, FileUp, Bot, Shield, FileText, CheckCircle, AlertTriangle } from 'lucide-react';
import { toast } from "sonner";
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";

const GapResult = ({ gap }) => {
    const statusConfig = {
        'Non-compliant': 'bg-red-100 text-red-800 border-red-200',
        'Partially Compliant': 'bg-yellow-100 text-yellow-800 border-yellow-200',
        'Compliant': 'bg-green-100 text-green-800 border-green-200',
        'Not Applicable': 'bg-gray-100 text-gray-800 border-gray-200',
    };
    return (
        <Card className="mb-4">
            <CardHeader className="pb-4">
                <div className="flex justify-between items-start">
                    <CardTitle className="text-lg flex items-center gap-2">
                        <FileText className="w-5 h-5 text-gray-600" />
                        {gap.control_id}: {gap.description}
                    </CardTitle>
                    <Badge className={statusConfig[gap.compliance_status] || statusConfig['Not Applicable']}>
                        {gap.compliance_status}
                    </Badge>
                </div>
            </CardHeader>
            <CardContent>
                <div className="grid md:grid-cols-2 gap-4 text-sm">
                    <div className="p-3 bg-gray-50 rounded-md">
                        <h4 className="font-semibold mb-1 text-gray-700">Gap Description</h4>
                        <p>{gap.gap_description}</p>
                    </div>
                    <div className="p-3 bg-green-50 rounded-md">
                        <h4 className="font-semibold mb-1 text-green-800">Recommendation</h4>
                        <p>{gap.recommendation}</p>
                    </div>
                </div>
            </CardContent>
        </Card>
    );
};

export default function CMMCAutomation() {
    const [file, setFile] = useState(null);
    const [isLoading, setIsLoading] = useState(false);
    const [analysisResult, setAnalysisResult] = useState(null);

    const handleFileChange = (e) => {
        setFile(e.target.files[0]);
    };

    const handleAnalyze = async () => {
        if (!file) {
            toast.error("Please select a file to analyze.");
            return;
        }
        setIsLoading(true);
        setAnalysisResult(null);
        toast.info("Uploading document...");

        try {
            const { file_url } = await UploadFile({ file });
            toast.success("Upload complete. Starting AI analysis...");
            
            const { data } = await analyzeCMMCDocument({ fileUrl: file_url });

            setAnalysisResult(data);
            toast.success("CMMC Gap Analysis complete!");
        } catch (error) {
            console.error("Analysis failed:", error);
            toast.error("An error occurred during analysis.", {
                description: error.response?.data?.details || error.message || "Please try again.",
            });
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="space-y-8">
            <BreadcrumbNav currentPageName="CMMCAutomation" />
            <CardHeader className="px-0">
                <CardTitle className="text-3xl font-bold flex items-center gap-3"><Bot className="w-8 h-8 text-blue-600" /> AI-Powered CMMC Gap Analysis</CardTitle>
                <CardDescription>Upload a policy document, SSP, or network diagram to instantly identify compliance gaps against NIST 800-171 controls.</CardDescription>
            </CardHeader>

            <Card>
                <CardHeader>
                    <CardTitle>1. Upload Your Document</CardTitle>
                    <CardDescription>PDF or TXT files are supported.</CardDescription>
                </CardHeader>
                <CardContent className="flex flex-col sm:flex-row gap-4 items-center">
                    <div className="flex-grow w-full">
                         <Input type="file" onChange={handleFileChange} accept=".pdf,.txt" className="w-full" />
                    </div>
                    <Button onClick={handleAnalyze} disabled={isLoading} className="w-full sm:w-auto">
                        {isLoading ? (
                            <><Loader2 className="w-4 h-4 animate-spin mr-2" />Analyzing...</>
                        ) : (
                            <><Shield className="w-4 h-4 mr-2" />Analyze for Gaps</>
                        )}
                    </Button>
                </CardContent>
            </Card>

            {isLoading && (
                <div className="text-center p-8">
                    <Loader2 className="w-12 h-12 animate-spin text-blue-600 mx-auto mb-4" />
                    <p className="text-lg font-semibold text-gray-800">Our AI is reading your document and identifying gaps...</p>
                    <p className="text-gray-600">This may take a minute or two depending on the document size.</p>
                </div>
            )}

            {analysisResult && (
                <Card>
                    <CardHeader>
                        <CardTitle>2. Analysis Results</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-6">
                        <Alert className="bg-blue-50 border-blue-200">
                             <CheckCircle className="h-4 w-4 text-blue-600" />
                            <AlertTitle className="text-blue-800">AI Summary</AlertTitle>
                            <AlertDescription className="text-blue-700">
                                {analysisResult.summary}
                            </AlertDescription>
                        </Alert>
                        <div>
                            {analysisResult.gaps.map((gap, index) => (
                                <GapResult key={index} gap={gap} />
                            ))}
                            {analysisResult.gaps.length === 0 && (
                                <div className="text-center p-6 bg-green-50 rounded-md">
                                    <CheckCircle className="w-8 h-8 text-green-600 mx-auto mb-2" />
                                    <p className="font-semibold text-green-800">No compliance gaps were identified in this document based on the analysis.</p>
                                </div>
                            )}
                        </div>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}