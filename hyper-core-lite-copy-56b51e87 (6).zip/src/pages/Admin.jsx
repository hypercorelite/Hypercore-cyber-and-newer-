
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Shield, ArrowRight, LogOut, Target, Users, CheckCircle, FileText } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { toast } from "sonner";
import { motion } from 'framer-motion';

export default function Admin() {
    const [adminKey, setAdminKey] = useState('');
    const [isAdmin, setIsAdmin] = useState(false);
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        // Check if already admin
        const adminStatus = localStorage.getItem('hypercore_admin_access');
        setIsAdmin(adminStatus === 'true');
    }, []);

    const handleLogin = () => {
        setLoading(true);
        
        if (adminKey === 'hypercore2025admin') {
            localStorage.setItem('hypercore_admin_access', 'true');
            setIsAdmin(true);
            toast.success("Admin access granted!");
        } else {
            toast.error("Invalid admin key");
        }
        
        setLoading(false);
    };

    const handleLogout = () => {
        localStorage.removeItem('hypercore_admin_access');
        setIsAdmin(false);
        setAdminKey('');
        toast.success("Logged out of admin mode");
    };

    const adminTools = [
        { name: "Dashboard", href: "Dashboard", desc: "Main operational dashboard", priority: "high", status: "operational" },
        { name: "Command Center", href: "AdminCommandCenter", desc: "Executive overview", priority: "high", status: "operational" },
        
        // --- CRITICAL ASSESSMENT TOOLS ---
        { name: "🔥 Real 48-Hour Assessment", href: "Real48HourAssessment", desc: "Honest assessment of progress + purge sample data", priority: "critical", status: "operational" },
        { name: "🧪 Complete System Test", href: "ComprehensiveSystemTest", desc: "Test all critical systems before campaign launch", priority: "critical", status: "operational" },
        { name: "🏢 Prime Contractor Inspection", href: "PrimeContractorInspection", desc: "Fortune 500 due diligence simulation with real testing", priority: "critical", status: "operational" },
        { name: "🎯 NIST Accuracy Validation", href: "NISTAccuracyValidation", desc: "Validate AI mapping accuracy against NIST 800-171 controls", priority: "critical", status: "operational" },
        
        // --- SBIR CRITICAL PATH (Updated for Real-World Accountability) ---
        { name: "🚀 SBIR Proposal Hub", href: "SBIRProposalStrategy", desc: "Hub for gathering the validation data for SBIR.", priority: "critical", status: "active" },
        { name: "📝 SBIR Implementation Appendix", href: "SBIRImplementationStrategy", desc: "Strategy for risk, scaling, and commercialization.", priority: "critical", status: "active" },
        { name: "💰 SBIR Cost Proposal", href: "SBIRCostProposal", desc: "Drafting the budget for the Phase I proposal.", priority: "critical", status: "active" },
        { name: "📊 SBIR Marketing Appendix", href: "SBIRMarketingAppendix", desc: "Collect and analyze real DoD contractor adoption data.", priority: "critical", status: "active" },
        { name: "📢 Customer Success Stories", href: "CustomerSuccessStories", desc: "Collect real-world case studies for marketing.", priority: "high", status: "active" },
        { name: "✍️ LOI Generator", href: "LOIGenerator", desc: "Collect Letters of Intent for market validation.", priority: "critical", status: "operational" },
        { name: "🚀 11-Week SBIR Plan", href: "RevisedSBIRStrategy", desc: "Detailed execution timeline for validation and submission.", priority: "critical", status: "in-progress" },
        
        // --- LinkedIn & Outreach ---
        { name: "📣 LinkedIn Campaign", href: "LinkedInCampaignStrategy", desc: "Publication and outreach playbook.", priority: "critical", status: "active" },
        { name: "📱 LinkedIn Posts Ready", href: "LinkedInGroupPosts", desc: "Ready-to-post content for your LinkedIn group.", priority: "critical", status: "active" },
        { name: "🤝 Prime Outreach", href: "PrimeContractorOutreach", desc: "Target prime contractors directly.", priority: "critical", status: "active" },

        // --- Core Operations ---
        { name: "Analytics Dashboard", href: "AnalyticsDashboard", desc: "Track real user engagement & SBIR metrics.", priority: "high", status: "active" },
        { name: "⏰ Last 24 Hours", href: "Last24HourAssessment", desc: "Real-time system health.", priority: "high", status: "operational" },
        { name: "Partnership Hub", href: "PartnershipHub", desc: "CRM and client pipeline.", priority: "high", status: "active" },
        { name: "Support Dashboard", href: "SupportDashboard", desc: "Customer support tickets.", priority: "medium", status: "operational" },
        { name: "User Management", href: "UserManagement", desc: "Manage users and roles.", priority: "medium", status: "operational" },

        // --- AI & Content Tools ---
        { name: "🔧 CMMC Generator", href: "CMMCGenerator", desc: "AI-powered CMMC tools.", priority: "critical", status: "operational" },
        { name: "📄 Report Generator", href: "ReportGenerator", desc: "Generate compliance reports.", priority: "high", status: "operational" },
        { name: "🧪 Tool Value Test", href: "ToolValueTest", desc: "Test AI content tailoring.", priority: "medium", status: "testing" },
        
        // --- Strategy & Backup ---
        { name: "💰 Pricing Strategy", href: "PricingStrategy", desc: "Review market pricing.", priority: "high", status: "operational" },
        { name: "📦 Code Export & Backup", href: "CodeExportAndBackup", desc: "Backup source to GitHub.", priority: "medium", status: "operational" },
        { name: "System Tests", href: "SystemTests", desc: "Verify all critical functions", priority: "high", status: "operational" },
    ];

    const getStatusColor = (status) => {
        const colors = {
            'operational': 'bg-green-100 text-green-800',
            'active': 'bg-blue-100 text-blue-800',
            'in-progress': 'bg-yellow-100 text-yellow-800',
            'testing': 'bg-orange-100 text-orange-800',
            'template': 'bg-gray-100 text-gray-800', // Changed from 'ready'
        };
        return colors[status] || 'bg-gray-100 text-gray-800';
    };

    const getPriorityColor = (priority) => {
        const colors = {
            'critical': 'border-l-4 border-red-500',
            'high': 'border-l-4 border-orange-400',
            'medium': 'border-l-4 border-blue-400'
        };
        return colors[priority] || '';
    };

    if (isAdmin) {
        return (
            <div className="min-h-screen bg-gray-50 p-6">
                <div className="max-w-7xl mx-auto">
                    {/* Enhanced Header with Progress Indicator */}
                    <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="flex justify-between items-center mb-8">
                        <div>
                            <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
                                <Shield className="w-8 h-8 text-green-600" />
                                Admin Portal
                            </h1>
                            <p className="text-gray-600 mt-2">Welcome to the HyperCore admin portal</p>
                            <div className="mt-3 flex items-center gap-4">
                                <div className="flex items-center gap-2">
                                    <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                                    <span className="text-sm text-gray-600">Critical SBIR Tools</span>
                                </div>
                                <div className="flex items-center gap-2">
                                    <div className="w-2 h-2 bg-orange-400 rounded-full"></div>
                                    <span className="text-sm text-gray-600">High Priority</span>
                                </div>
                                <div className="flex items-center gap-2">
                                    <div className="w-2 h-2 bg-blue-400 rounded-full"></div>
                                    <span className="text-sm text-gray-600">Medium Priority</span>
                                </div>
                            </div>
                        </div>
                        <div className="flex items-center gap-4">
                            <Link to={createPageUrl('Home')} className="text-blue-600 hover:text-blue-800">
                                🌐 View Client Site
                            </Link>
                            <Button variant="outline" onClick={handleLogout}>
                                <LogOut className="w-4 h-4 mr-2" />
                                Exit Admin
                            </Button>
                        </div>
                    </motion.div>

                    {/* SBIR Progress Alert - Updated to reflect 50% Technical Completion */}
                    <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
                        <div className="bg-gradient-to-r from-blue-600 to-green-500 rounded-lg p-6 text-white shadow-lg">
                            <div className="flex justify-between items-start">
                                <div>
                                    <h3 className="text-xl font-bold">SBIR Phase I Readiness</h3>
                                    <p className="text-blue-100">Overall progress towards a fully validated Phase I proposal.</p>
                                </div>
                                <div className="text-right">
                                    <p className="text-3xl font-bold">50%</p>
                                    <p className="text-blue-100">Complete</p>
                                </div>
                            </div>
                            <div className="mt-4">
                                <div className="w-full bg-black/20 rounded-full h-2.5">
                                    <div className="bg-white h-2.5 rounded-full" style={{ width: '50%' }}></div>
                                </div>
                                <div className="mt-3 grid grid-cols-2 gap-4 text-sm">
                                    <div>
                                        <p className="font-semibold text-white">✅ Stage 1: Technical Prototype</p>
                                        <p className="text-blue-200">100% Complete</p>
                                    </div>
                                    <div>
                                        <p className="font-semibold text-white">➡️ Stage 2: Market Validation</p>
                                        <p className="text-blue-200">0% Complete (Next Up)</p>
                                    </div>
                                </div>
                                <p className="text-right text-sm mt-2 text-white/80">Next Goal: Secure 15+ Real DoD Contractor LOIs</p>
                            </div>
                        </div>
                    </motion.div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {adminTools.map((tool) => (
                            <Link key={tool.name} to={createPageUrl(tool.href)}>
                                <Card className={`hover:shadow-lg transition-all cursor-pointer h-full ${getPriorityColor(tool.priority)}`}>
                                    <CardHeader>
                                        <div className="flex justify-between items-start">
                                            <CardTitle className="text-lg">{tool.name}</CardTitle>
                                            <Badge className={getStatusColor(tool.status)}>{tool.status}</Badge>
                                        </div>
                                        <CardDescription>{tool.desc}</CardDescription>
                                    </CardHeader>
                                    <CardContent>
                                        <Button variant="outline" className="w-full">
                                            Open <ArrowRight className="w-4 h-4 ml-2" />
                                        </Button>
                                    </CardContent>
                                </Card>
                            </Link>
                        ))}
                    </div>

                    {/* Quick Stats Footer - Updated for Accuracy */}
                    <div className="mt-8 grid grid-cols-2 md:grid-cols-4 gap-4">
                        <div className="bg-white p-4 rounded-lg shadow-sm text-center">
                            <p className="text-2xl font-bold text-green-600">{adminTools.length}</p>
                            <p className="text-sm text-gray-600">Admin Tools Active</p>
                        </div>
                        <div className="bg-white p-4 rounded-lg shadow-sm text-center">
                            <Target className="w-8 h-8 text-orange-500 mx-auto mb-2" />
                            <p className="text-lg font-bold text-orange-600">Validation Needed</p>
                            <p className="text-sm text-gray-600">SBIR Readiness</p>
                        </div>
                        <div className="bg-white p-4 rounded-lg shadow-sm text-center">
                            <p className="text-2xl font-bold text-purple-600">~$5M</p>
                            <p className="text-sm text-gray-600">TAM Projection</p>
                        </div>
                        <div className="bg-white p-4 rounded-lg shadow-sm text-center">
                            <p className="text-2xl font-bold text-orange-600">Q1 2025</p>
                            <p className="text-sm text-gray-600">Launch Target</p>
                        </div>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gray-100 flex items-center justify-center">
            <Card className="w-full max-w-md">
                <CardHeader className="text-center">
                    <Shield className="w-16 h-16 mx-auto text-red-500 mb-4" />
                    <CardTitle className="text-2xl">Admin Access</CardTitle>
                    <CardDescription>
                        Enter the admin key to access the admin portal
                    </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    <Input
                        type="password"
                        placeholder="Enter admin key..."
                        value={adminKey}
                        onChange={(e) => setAdminKey(e.target.value)}
                        onKeyPress={(e) => e.key === 'Enter' && handleLogin()}
                    />
                    <Button 
                        className="w-full bg-red-600 hover:bg-red-700" 
                        onClick={handleLogin}
                        disabled={loading || !adminKey}
                    >
                        {loading ? "Verifying..." : "Enter Admin Portal"}
                        <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                    
                    <div className="text-center text-xs text-gray-500 border-t pt-4">
                        <Link to={createPageUrl('Home')} className="text-blue-600 hover:text-blue-800">
                            ← Back to Public Site
                        </Link>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}
