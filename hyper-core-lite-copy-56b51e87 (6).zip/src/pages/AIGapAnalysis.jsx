import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Loader2, Upload, Bot, Shield, CheckCircle, AlertTriangle } from 'lucide-react';
import { UploadFile } from "@/api/integrations";
import { analyzeCMMCDocument } from "@/api/functions";
import { toast } from "sonner";
import ValuePropositionCard from '../components/competitive/ValuePropositionCard';

export default function AIGapAnalysis() {
    const [file, setFile] = useState(null);
    const [analysis, setAnalysis] = useState(null);
    const [loading, setLoading] = useState(false);

    const handleFileChange = (e) => {
        setFile(e.target.files[0]);
        setAnalysis(null);
    };

    const analyzeDocument = async () => {
        if (!file) {
            toast.error("Please select a file to analyze");
            return;
        }

        setLoading(true);
        try {
            toast.info("Uploading document...");
            const { file_url } = await UploadFile({ file });
            
            toast.info("AI is analyzing your document for CMMC gaps...");
            const { data } = await analyzeCMMCDocument({ fileUrl: file_url });
            
            setAnalysis(data);
            toast.success("Analysis complete!");
        } catch (error) {
            toast.error("Analysis failed. Please try again.");
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="min-h-screen bg-gray-50 p-6">
            <div className="max-w-4xl mx-auto space-y-8">
                <CardHeader className="px-0 text-center">
                    <CardTitle className="text-3xl font-bold flex items-center justify-center gap-3">
                        <Bot className="w-8 h-8 text-blue-600" />
                        AI-Powered CMMC Gap Analysis
                    </CardTitle>
                    <CardDescription className="text-lg">
                        Upload your policy document, network diagram, or current documentation to get an instant compliance gap analysis
                    </CardDescription>
                </CardHeader>

                <ValuePropositionCard 
                    toolName="AI Gap Analysis"
                    aiTime="5 Minutes"
                    aiCost={0}
                    saasTime="10-20 Hours"
                    saasCost={5000}
                    consultantTime="40+ Hours"
                    consultantCost={20000}
                    aiAdvantage="The AI doesn't just find keywords; it understands context and maps gaps directly to NIST controls, instantly prioritizing your workload."
                />

                <Card className="mb-8">
                    <CardHeader>
                        <CardTitle>Upload Your Document</CardTitle>
                        <CardDescription>Supported formats: PDF, TXT, DOCX</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <Input 
                            type="file" 
                            accept=".pdf,.txt,.docx" 
                            onChange={handleFileChange}
                            disabled={loading}
                        />
                        <Button 
                            onClick={analyzeDocument} 
                            disabled={!file || loading}
                            className="w-full"
                            size="lg"
                        >
                            {loading ? (
                                <>
                                    <Loader2 className="w-5 h-5 animate-spin mr-2" />
                                    Analyzing with AI...
                                </>
                            ) : (
                                <>
                                    <Shield className="w-5 h-5 mr-2" />
                                    Analyze for CMMC Gaps
                                </>
                            )}
                        </Button>
                    </CardContent>
                </Card>

                {analysis && (
                    <Card>
                        <CardHeader>
                            <CardTitle>AI Analysis Results</CardTitle>
                            <CardDescription>CMMC compliance gaps identified and mapped to NIST 800-171 controls</CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-6">
                            <Alert className="bg-blue-50 border-blue-200">
                                <Bot className="h-4 w-4 text-blue-600" />
                                <AlertTitle className="text-blue-800">AI Summary</AlertTitle>
                                <AlertDescription className="text-blue-700">
                                    {analysis.summary}
                                </AlertDescription>
                            </Alert>

                            <div className="space-y-4">
                                <h3 className="text-xl font-semibold">Identified Gaps</h3>
                                {analysis.gaps && analysis.gaps.length > 0 ? (
                                    analysis.gaps.map((gap, index) => (
                                        <Card key={index} className="border-l-4 border-l-red-400">
                                            <CardContent className="pt-4">
                                                <div className="flex justify-between items-start mb-2">
                                                    <h4 className="font-semibold flex items-center gap-2">
                                                        <AlertTriangle className="w-4 h-4 text-red-500" />
                                                        {gap.control_id}: {gap.description}
                                                    </h4>
                                                    <Badge className="bg-red-100 text-red-800">
                                                        {gap.compliance_status}
                                                    </Badge>
                                                </div>
                                                <p className="text-gray-600 mb-2">{gap.gap_description}</p>
                                                <p className="text-green-700 bg-green-50 p-2 rounded text-sm">
                                                    <strong>Recommendation:</strong> {gap.recommendation}
                                                </p>
                                            </CardContent>
                                        </Card>
                                    ))
                                ) : (
                                    <div className="text-center p-6 bg-green-50 rounded-lg">
                                        <CheckCircle className="w-8 h-8 text-green-600 mx-auto mb-2" />
                                        <p className="text-green-800 font-semibold">No critical gaps identified!</p>
                                        <p className="text-green-600">Your document appears to meet CMMC requirements.</p>
                                    </div>
                                )}
                            </div>
                        </CardContent>
                    </Card>
                )}
            </div>
        </div>
    );
}