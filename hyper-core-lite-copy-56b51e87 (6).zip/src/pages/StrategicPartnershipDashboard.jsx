import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Handshake, Zap, Target, Users, Bot } from 'lucide-react';
import { StrategicPartner } from "@/api/entities";
import { toast } from "sonner";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function StrategicPartnershipDashboard() {
    const [partners, setPartners] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        loadPartners();
    }, []);

    const loadPartners = async () => {
        setLoading(true);
        try {
            const partnerData = await StrategicPartner.list('-created_date');
            setPartners(partnerData);
        } catch (error) {
            toast.error("Failed to load strategic partners.");
        } finally {
            setLoading(false);
        }
    };
    
    const statusConfig = {
        'Identified': 'bg-gray-200 text-gray-800',
        'Outreach Sent': 'bg-blue-100 text-blue-800',
        'POC in Progress': 'bg-yellow-100 text-yellow-800',
        'Active Partner': 'bg-green-100 text-green-800',
        'Inactive': 'bg-red-100 text-red-800',
    };

    const activePartnersCount = partners.filter(p => p.status === 'Active Partner').length;

    return (
        <div className="space-y-8 p-4 md:p-6">
            <div className="text-center">
                <h1 className="text-3xl font-bold text-gray-900 mb-4 flex items-center justify-center gap-3">
                    <Handshake className="w-8 h-8 text-blue-600" />
                    Strategic DIB Partnership Dashboard
                </h1>
                <p className="text-lg text-gray-600 max-w-4xl mx-auto">
                    Manage and track high-value partnerships to penetrate the DIB subcontractor market, inspired by the Rackspace-SMPL-C model.
                </p>
            </div>

            <Alert className="bg-blue-50 border-blue-200">
                <Bot className="h-4 w-4 text-blue-700" />
                <AlertTitle className="font-bold text-blue-800">Your Go-to-Market Blueprint</AlertTitle>
                <AlertDescription className="text-blue-700">
                    This dashboard operationalizes your strategy: partner with established NoVA players (RPOs, Primes, Tool Providers) to bundle HyperCore's AI as the engine for their subcontractor compliance needs. Your goal is "Powered by HyperCore" recognition and scalable lead generation.
                </AlertDescription>
            </Alert>
            
            <Card>
                <CardHeader>
                    <CardTitle>Partnership Funnel Progress</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="flex items-center gap-4">
                        <span className="text-sm font-medium">Activation Progress:</span>
                        <Progress value={(activePartnersCount / partners.length) * 100} className="w-[60%]" />
                        <span className="text-sm font-bold">{activePartnersCount} of {partners.length} Partners Active</span>
                    </div>
                </CardContent>
            </Card>

            <div className="grid md:grid-cols-1 lg:grid-cols-3 gap-6">
                {loading ? <p>Loading partners...</p> : partners.map(partner => (
                    <Card key={partner.id} className="flex flex-col">
                        <CardHeader>
                            <div className="flex justify-between items-start">
                                <CardTitle>{partner.name}</CardTitle>
                                <Badge className={statusConfig[partner.status]}>{partner.status}</Badge>
                            </div>
                            <CardDescription>{partner.partnership_type}</CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-4 flex-grow">
                            <div>
                                <h4 className="font-semibold text-sm mb-1 flex items-center gap-2"><Users />DIB Reach</h4>
                                <p className="text-xs text-gray-600">{partner.reach_description}</p>
                            </div>
                            <div>
                                <h4 className="font-semibold text-sm mb-1 flex items-center gap-2"><Zap />Partnership Model</h4>
                                <p className="text-xs text-gray-600">{partner.partnership_model}</p>
                            </div>
                             <div>
                                <h4 className="font-semibold text-sm mb-1 flex items-center gap-2"><Target />Recognition Goal</h4>
                                <p className="text-xs text-gray-600">{partner.recognition_plan}</p>
                            </div>
                        </CardContent>
                        <div className="p-4 border-t">
                            <Button asChild variant="outline" className="w-full">
                                <Link to={createPageUrl(`PartnershipHub?partner_id=${partner.id}`)}>Manage Partnership & Leads</Link>
                            </Button>
                        </div>
                    </Card>
                ))}
            </div>
        </div>
    );
}