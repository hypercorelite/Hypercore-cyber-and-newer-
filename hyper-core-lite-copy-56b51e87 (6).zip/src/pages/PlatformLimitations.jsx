import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Shield, Server, Brain, Zap, AlertTriangle, GitBranch, ArrowRight } from 'lucide-react';
import { motion } from "framer-motion";

const challenges = {
    apiIntegration: {
        title: "API Integration & Data Normalization",
        icon: Server,
        points: [
            {
                challenge: "Disparate APIs",
                description: "AWS and Microsoft expose entirely different APIs for security and configuration data, requiring separate integration logic for each service.",
                approach: "Develop a modular 'Adaptor Architecture' where each service (e.g., AWS Config, Azure Policy) has its own dedicated data connector. This isolates complexity and makes adding new services easier."
            },
            {
                challenge: "Data Normalization",
                description: "Data from AWS (e.g., an IAM User) and Microsoft (e.g., an Entra ID User) have different formats and terminology but must map to the same CMMC control.",
                approach: "Create a 'Unified HyperCore Data Model'. All data from adaptors is transformed into this canonical format before being processed, ensuring consistent analysis."
            },
            {
                challenge: "Data Overload & Silos",
                description: "The sheer volume of logs and configuration items from two major clouds creates massive datasets that can be difficult to process in context.",
                approach: "Implement an asynchronous data processing pipeline with intelligent caching and event-driven architecture to handle high volume without losing performance."
            }
        ]
    },
    multiCloudSecurity: {
        title: "Multi-Cloud Security & Visibility",
        icon: Shield,
        points: [
            {
                challenge: "Fragmented Visibility",
                description: "Security teams struggle to get a consolidated view of risk when data is split between AWS and Azure consoles.",
                approach: "The core value of HyperCore: a 'single pane of glass' dashboard that visualizes a unified risk posture by mapping all normalized data to the CMMC framework."
            },
            {
                challenge: "Inconsistent Policies",
                description: "Implementing a consistent policy (e.g., encryption standards) is different in AWS versus Azure, complicating enforcement and auditing.",
                approach: "Develop an 'Abstracted Policy Engine' where users define the desired CMMC outcome, and HyperCore translates it into the specific AWS and Azure configurations required."
            },
            {
                challenge: "Expanded Attack Surface",
                description: "A multi-cloud environment doubles the number of potential entry points, APIs, and identity systems that need to be monitored.",
                approach: "Utilize 'Cross-Cloud Threat Correlation'. Our AI will be trained to identify attack patterns that span both clouds, such as compromised credentials being used in both Azure and AWS."
            }
        ]
    },
    aiAndAutomation: {
        title: "AI & Automation",
        icon: Brain,
        points: [
            {
                challenge: "Training AI on Multi-Platform Data",
                description: "AI models need to be trained on diverse, normalized data to understand the nuances of both AWS and Microsoft systems accurately.",
                approach: "A phased training approach. Start with domain-specific models (e.g., an 'Access Control Model') trained on the Unified HyperCore Data Model, not raw cloud data."
            },
            {
                challenge: "Automated Remediation Across Platforms",
                description: "Automating a fix is difficult when the target services have different APIs. A single remediation workflow must be able to target either cloud.",
                approach: "Implement 'Human-in-the-Loop Remediation'. Initially, the AI will generate the script or CLI command for a human to execute. Full automation will be a future, premium feature."
            },
            {
                challenge: "Preventing False Positives",
                description: "The complexity and data volume can lead to a high rate of false positive alerts, creating alert fatigue and distrust in the system.",
                approach: "Create a 'Feedback-Driven Learning Loop'. Allow users to mark alerts as false positives, which feeds back into the model to continuously improve its accuracy."
            }
        ]
    },
    scalability: {
        title: "Scalability & Performance",
        icon: Zap,
        points: [
            {
                challenge: "Managing Scale",
                description: "The platform must handle data from small subcontractors and large enterprises without performance degradation.",
                approach: "Build on a serverless architecture (e.g., AWS Lambda, App Runner) that scales automatically with demand, ensuring costs are tied directly to usage."
            },
            {
                challenge: "Handling API Rate Limits",
                description: "Continuous API calls to AWS and Microsoft will hit rate limits, potentially disabling monitoring.",
                approach: "Implement 'Intelligent API Throttling' and prioritized queuing. The system will manage API call frequency, backing off when limits are approached and prioritizing critical security checks."
            },
            {
                challenge: "Network Latency",
                description: "Transferring large volumes of log data between clouds can impact real-time monitoring capabilities.",
                approach: "Focus on edge processing and metadata. Instead of pulling all raw logs, the platform will rely on signals and alerts from services like GuardDuty and Microsoft Sentinel, only fetching deep logs on demand."
            }
        ]
    }
};

const roadmap = [
    { phase: "Phase 1: Unified Visibility (Q1)", goal: "Solve the visibility problem. Ingest and normalize data from both clouds to provide a single, comprehensive compliance dashboard.", key: "p1" },
    { phase: "Phase 2: Assisted Remediation (Q2)", goal: "Introduce Human-in-the-Loop remediation. The AI will generate scripts and step-by-step guides for users to fix identified gaps.", key: "p2" },
    { phase: "Phase 3: Autonomous Compliance (Q4)", goal: "Roll out fully automated remediation for a subset of controls as a premium, opt-in feature, building on the trust established in earlier phases.", key: "p3" },
];

export default function PlatformLimitations() {
    return (
        <div className="min-h-screen bg-gray-50 p-6">
            <div className="max-w-7xl mx-auto">
                <motion.div 
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="text-center mb-8"
                >
                    <h1 className="text-4xl font-bold text-gray-900 mb-3">
                        The Multi-Cloud CMMC Challenge
                    </h1>
                    <p className="text-xl text-gray-600">
                        An internal guide to the technical challenges we solve and how we communicate our strategic advantage.
                    </p>
                </motion.div>

                <Alert className="mb-8 bg-blue-50 border-blue-200">
                    <AlertTriangle className="h-4 w-4 text-blue-600" />
                    <AlertTitle className="text-blue-800">Our Strategic Position</AlertTitle>
                    <AlertDescription className="text-blue-700">
                        These challenges are not weaknesses; they are our moat. By acknowledging and systematically solving the hard problems of multi-cloud compliance, we differentiate ourselves from simplistic, single-platform tools and build a defensible, high-value product. Our marketing should reflect this engineering maturity.
                    </AlertDescription>
                </Alert>

                <Tabs defaultValue="apiIntegration" className="w-full">
                    <TabsList className="grid w-full grid-cols-2 lg:grid-cols-4">
                        {Object.entries(challenges).map(([key, value]) => {
                            const Icon = value.icon;
                            return (
                                <TabsTrigger key={key} value={key} className="flex items-center gap-2">
                                    <Icon className="w-4 h-4" />
                                    {value.title}
                                </TabsTrigger>
                            );
                        })}
                    </TabsList>

                    {Object.entries(challenges).map(([key, value]) => (
                        <TabsContent key={key} value={key} className="pt-6">
                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                                {value.points.map((item, index) => (
                                    <motion.div
                                        key={index}
                                        initial={{ opacity: 0, y: 20 }}
                                        animate={{ opacity: 1, y: 0 }}
                                        transition={{ delay: index * 0.1 }}
                                    >
                                        <Card className="h-full">
                                            <CardHeader>
                                                <CardTitle className="text-lg">{item.challenge}</CardTitle>
                                                <CardDescription>{item.description}</CardDescription>
                                            </CardHeader>
                                            <CardContent>
                                                <Badge>HyperCore Approach</Badge>
                                                <p className="mt-2 text-sm text-gray-700">{item.approach}</p>
                                            </CardContent>
                                        </Card>
                                    </motion.div>
                                ))}
                            </div>
                        </TabsContent>
                    ))}
                </Tabs>

                <Card className="mt-8">
                    <CardHeader>
                        <CardTitle>Phased Roadmap to Solving the Hard Problems</CardTitle>
                        <CardDescription>Our development is structured to deliver value at each stage while tackling complexity incrementally.</CardDescription>
                    </CardHeader>
                    <CardContent className="flex flex-col md:flex-row gap-4">
                        {roadmap.map((item, index) => (
                            <div key={item.key} className="flex items-center gap-4 flex-1">
                                <div className="text-lg font-bold text-blue-600">{`0${index + 1}`}</div>
                                <div>
                                    <h4 className="font-semibold">{item.phase}</h4>
                                    <p className="text-sm text-gray-600">{item.goal}</p>
                                </div>
                                {index < roadmap.length - 1 && <ArrowRight className="hidden md:block w-6 h-6 text-gray-300" />}
                            </div>
                        ))}
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}