import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { ArrowRight, Globe, Shield, UserCheck } from 'lucide-react';

export default function UserRolesAndViews() {
    return (
        <div className="p-4 md:p-8">
            <div className="text-center mb-12">
                <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-3">User Roles & Application Views</h1>
                <p className="text-lg text-gray-600 max-w-3xl mx-auto">
                    This page explains the different portals within the HyperCore application and defines the main "home" page for each user type.
                </p>
            </div>

            <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
                <Card className="flex flex-col">
                    <CardHeader>
                        <div className="flex items-center gap-4 mb-3">
                            <div className="bg-blue-100 p-3 rounded-full">
                                <Globe className="w-8 h-8 text-blue-600" />
                            </div>
                            <div>
                                <CardTitle className="text-2xl">Public Portal</CardTitle>
                                <CardDescription>For prospective clients and general visitors.</CardDescription>
                            </div>
                        </div>
                    </CardHeader>
                    <CardContent className="flex-grow space-y-4">
                        <div className="border-t pt-4">
                            <h4 className="font-semibold text-gray-800">Main Page (Homepage):</h4>
                            <p className="text-gray-600">The <span className="font-medium text-blue-700">Homepage</span> is the main entry point for all public traffic.</p>
                            <Button asChild variant="outline" size="sm" className="mt-2">
                                <Link to={createPageUrl('Home')} target="_blank">
                                    View Public Homepage <ArrowRight className="w-4 h-4 ml-2" />
                                </Link>
                            </Button>
                        </div>
                         <div className="border-t pt-4">
                            <h4 className="font-semibold text-gray-800">Key Characteristics:</h4>
                            <ul className="list-disc list-inside text-gray-600 space-y-1 mt-2">
                                <li>No login required.</li>
                                <li>Focuses on marketing, education, and lead capture.</li>
                                <li>Allows users to generate sample PDF documents for free.</li>
                                <li>Collects contact information for sales pipeline.</li>
                            </ul>
                        </div>
                    </CardContent>
                </Card>

                <Card className="flex flex-col border-purple-300 bg-purple-50">
                    <CardHeader>
                        <div className="flex items-center gap-4 mb-3">
                            <div className="bg-purple-100 p-3 rounded-full">
                                <Shield className="w-8 h-8 text-purple-600" />
                            </div>
                            <div>
                                <CardTitle className="text-2xl text-purple-900">Admin Portal</CardTitle>
                                <CardDescription className="text-purple-700">For internal business management and operations.</CardDescription>
                            </div>
                        </div>
                    </CardHeader>
                    <CardContent className="flex-grow space-y-4">
                       <div className="border-t border-purple-200 pt-4">
                            <h4 className="font-semibold text-purple-900">Main Page (Homepage):</h4>
                            <p className="text-purple-700">The <span className="font-medium text-purple-900">Admin Dashboard</span> is the main entry point for all authenticated administrators.</p>
                             <Button asChild variant="secondary" size="sm" className="mt-2 bg-purple-100 hover:bg-purple-200 text-purple-800">
                                <Link to={createPageUrl('Dashboard')}>
                                    Go to Admin Dashboard <ArrowRight className="w-4 h-4 ml-2" />
                                </Link>
                            </Button>
                        </div>

                         <div className="border-t border-purple-200 pt-4">
                            <h4 className="font-semibold text-purple-900">Key Characteristics:</h4>
                            <ul className="list-disc list-inside text-purple-700 space-y-1 mt-2">
                                <li>Requires Google authentication.</li>
                                <li>Provides access to CRM, system tests, and strategic documents.</li>
                                <li>Not visible to the public or clients.</li>
                                <li>Redirects automatically from public pages upon login.</li>
                            </ul>
                        </div>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}