import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { generateComplianceDocument } from "@/api/functions";
import { logAuditEvent } from "@/api/functions";
import { User } from "@/api/entities";
import { Loader2, CheckCircle, FileText, Download, Info, AlertTriangle, CheckSquare, Target, Shield } from 'lucide-react';
import { toast } from "sonner";
import ReactMarkdown from 'react-markdown';
import { motion } from "framer-motion";

const CMMC_DOCUMENTS = [
    { id: 'access_control_policy', name: 'Access Control Policy', domain: 'AC' },
    { id: 'awareness_training_plan', name: 'Awareness & Training Plan', domain: 'AT' },
    { id: 'audit_accountability_policy', name: 'Audit & Accountability Policy', domain: 'AU' },
    { id: 'configuration_management_plan', name: 'Configuration Management Plan', domain: 'CM' },
    { id: 'identification_authentication_procedures', name: 'Identification & Authentication Procedures', domain: 'IA' },
    { id: 'incident_response_plan', name: 'Incident Response Plan', domain: 'IR' },
    { id: 'system_maintenance_policy', name: 'System Maintenance Policy', domain: 'MA' },
    { id: 'media_protection_policy', name: 'Media Protection Policy', domain: 'MP' },
    { id: 'physical_environmental_protection_plan', name: 'Physical & Environmental Protection Plan', domain: 'PE' },
    { id: 'personnel_security_policy', name: 'Personnel Security Policy', domain: 'PS' },
    { id: 'risk_assessment_procedure', name: 'Risk Assessment Procedure', domain: 'RA' },
    { id: 'system_and_services_acquisition_policy', name: 'System & Services Acquisition Policy', domain: 'SA' },
    { id: 'system_and_communications_protection_policy', name: 'System & Communications Protection Policy', domain: 'SC' },
    { id: 'system_and_information_integrity_policy', name: 'System & Information Integrity Policy', domain: 'SI' },
];

const IMPLEMENTATION_CHECKLISTS = {
    'access_control_policy': [
        { task: "Conduct user access inventory", description: "List all current user accounts and their access levels", completed: false },
        { task: "Implement MFA for all users", description: "Deploy multi-factor authentication across all systems", completed: false },
        { task: "Establish quarterly access reviews", description: "Create process for regular access validation", completed: false },
        { task: "Configure session timeouts", description: "Set 15-minute idle timeout on all systems", completed: false },
        { task: "Document access control procedures", description: "Create formal written procedures for access management", completed: false },
        { task: "Train staff on access policies", description: "Educate all personnel on access control requirements", completed: false }
    ],
    'physical_environmental_protection_plan': [
        { task: "Install electronic access controls", description: "Deploy keycard or similar access control system", completed: false },
        { task: "Implement visitor management", description: "Create visitor registration and escort procedures", completed: false },
        { task: "Install security cameras", description: "Deploy surveillance at all entry/exit points", completed: false },
        { task: "Set up environmental monitoring", description: "Install temperature/humidity monitoring in server areas", completed: false },
        { task: "Test backup power systems", description: "Verify UPS and generator functionality", completed: false },
        { task: "Create facility security procedures", description: "Document all physical security measures", completed: false }
    ],
    'incident_response_plan': [
        { task: "Form incident response team", description: "Identify and train key personnel for incident response", completed: false },
        { task: "Set up monitoring tools", description: "Deploy SIEM or equivalent security monitoring", completed: false },
        { task: "Create contact lists", description: "Maintain current emergency contact information", completed: false },
        { task: "Conduct tabletop exercises", description: "Practice incident response scenarios quarterly", completed: false },
        { task: "Establish DoD reporting procedures", description: "Set up DIBNet portal access and reporting workflow", completed: false },
        { task: "Test backup and recovery", description: "Verify ability to restore systems from clean backups", completed: false }
    ]
    // Add more checklists for other documents as needed
};

const DocumentCard = ({ doc, onGenerate, onViewChecklist, loading, generatedDoc, showImplementation }) => {
    const status = generatedDoc?.status || 'missing';

    return (
        <Card className={`transition-all ${status === 'generated' ? 'bg-green-50 border-green-200' : 'bg-white'}`}>
            <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                    <FileText className="w-5 h-5 text-blue-600" />
                    {doc.name}
                </CardTitle>
                <CardDescription>CMMC Domain: {doc.domain}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-2">
                <Button onClick={() => onGenerate(doc.id, doc.name)} disabled={loading} className="w-full">
                    {loading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : 
                     status === 'generated' ? <><CheckCircle className="w-4 h-4 mr-2" />Regenerate Template</> : 'Generate Implementation Template'}
                </Button>
                {showImplementation && IMPLEMENTATION_CHECKLISTS[doc.id] && (
                    <Button variant="outline" onClick={() => onViewChecklist(doc.id, doc.name)} className="w-full">
                        <CheckSquare className="w-4 h-4 mr-2" />
                        View Implementation Checklist
                    </Button>
                )}
            </CardContent>
        </Card>
    );
};

const ImplementationChecklist = ({ docId, docName, checklist, onBack }) => {
    const [checklistState, setChecklistState] = useState(checklist || []);

    const toggleTask = (index) => {
        const updated = [...checklistState];
        updated[index].completed = !updated[index].completed;
        setChecklistState(updated);
    };

    const completedCount = checklistState.filter(task => task.completed).length;
    const progressPercent = (completedCount / checklistState.length) * 100;

    return (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <Card>
                <CardHeader>
                    <div className="flex justify-between items-start">
                        <div>
                            <CardTitle className="flex items-center gap-2">
                                <Target className="w-5 h-5 text-green-600" />
                                Implementation Checklist: {docName}
                            </CardTitle>
                            <CardDescription>
                                Complete these steps before generating your final audit document
                            </CardDescription>
                        </div>
                        <Button variant="outline" onClick={onBack}>Back to Templates</Button>
                    </div>
                </CardHeader>
                <CardContent>
                    <Alert className="mb-6 bg-blue-50 border-blue-200">
                        <Shield className="h-4 w-4 text-blue-600" />
                        <AlertTitle className="text-blue-800">Implementation First Approach</AlertTitle>
                        <AlertDescription className="text-blue-700">
                            <strong>Step 1:</strong> Use this checklist to actually implement the security controls.
                            <br />
                            <strong>Step 2:</strong> After implementation, create your final audit documentation based on what you've actually deployed.
                            <br />
                            <strong>Step 3:</strong> The implementation is what matters - documentation just proves you did it.
                        </AlertDescription>
                    </Alert>

                    <div className="mb-6">
                        <div className="flex justify-between items-center mb-2">
                            <span className="font-semibold">Progress: {completedCount}/{checklistState.length} tasks completed</span>
                            <span className="text-sm text-gray-600">{Math.round(progressPercent)}%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                            <div 
                                className="bg-green-600 h-2 rounded-full transition-all duration-300" 
                                style={{ width: `${progressPercent}%` }}
                            ></div>
                        </div>
                    </div>

                    <div className="space-y-4">
                        {checklistState.map((task, index) => (
                            <div key={index} className={`p-4 rounded-lg border ${task.completed ? 'bg-green-50 border-green-200' : 'bg-white border-gray-200'}`}>
                                <div className="flex items-start gap-3">
                                    <button 
                                        onClick={() => toggleTask(index)}
                                        className={`mt-1 w-5 h-5 rounded border-2 flex items-center justify-center ${
                                            task.completed ? 'bg-green-600 border-green-600' : 'border-gray-300 hover:border-green-400'
                                        }`}
                                    >
                                        {task.completed && <CheckSquare className="w-3 h-3 text-white" />}
                                    </button>
                                    <div className="flex-1">
                                        <h4 className={`font-semibold ${task.completed ? 'text-green-800 line-through' : 'text-gray-800'}`}>
                                            {task.task}
                                        </h4>
                                        <p className={`text-sm ${task.completed ? 'text-green-600' : 'text-gray-600'}`}>
                                            {task.description}
                                        </p>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>

                    {progressPercent === 100 && (
                        <Alert className="mt-6 bg-green-50 border-green-200">
                            <CheckCircle className="h-4 w-4 text-green-600" />
                            <AlertTitle className="text-green-800">Implementation Complete!</AlertTitle>
                            <AlertDescription className="text-green-700">
                                Excellent work! Now that you've implemented these controls, you can create your final audit documentation that accurately reflects your actual security posture.
                            </AlertDescription>
                        </Alert>
                    )}
                </CardContent>
            </Card>
        </motion.div>
    );
};

export default function ComplianceDocumentation() {
    const [companyName, setCompanyName] = useState('HyperCore AI, LLC');
    const [documents, setDocuments] = useState({});
    const [loading, setLoading] = useState({});
    const [activeDocument, setActiveDocument] = useState(null);
    const [activeChecklist, setActiveChecklist] = useState(null);
    const [currentUser, setCurrentUser] = useState(null);
    const [activeTab, setActiveTab] = useState('templates');

    useEffect(() => {
        const fetchUser = async () => {
            try {
                const user = await User.me();
                setCurrentUser(user);
            } catch (error) {
                console.error("Failed to fetch user. Audit logs will not be created.", error);
            }
        };
        fetchUser();
    }, []);

    const handleGenerateDocument = async (docId, docName) => {
        if (!companyName) {
            toast.error("Please provide an organization name before generating.");
            return;
        }
        setLoading(prevState => ({ ...prevState, [docId]: true }));

        try {
            const response = await generateComplianceDocument({
                documentType: docId,
                companyName: companyName
            });

            if (response.data && response.data.success && response.data.content) {
                const newDocState = { name: docName, content: response.data.content, status: 'generated' };
                setDocuments(prevState => ({ ...prevState, [docId]: newDocState }));
                setActiveDocument(newDocState);
                toast.success(`${docName} implementation template generated!`);

                if (currentUser) {
                    await logAuditEvent({
                        eventName: 'DOCUMENT_GENERATED',
                        userEmail: currentUser.email,
                        details: JSON.stringify({ documentName: docName, companyName: companyName, type: 'implementation_template' }),
                        status: 'SUCCESS'
                    });
                }
            } else {
                const errorMsg = response.data?.error || 'The backend function returned an error. Check the function logs.';
                throw new Error(errorMsg);
            }
        } catch (err) {
            const errorMessage = err.message || 'An unknown error occurred.';
            setActiveDocument({
                name: docName,
                content: `## Generation Failed\n\nAn error occurred while trying to generate the implementation template. This usually means the backend function has a problem.\n\n**Error Details:**\n\n\`\`\`\n${errorMessage}\n\`\`\``,
                status: 'error'
            });
            toast.error(`Failed to generate ${docName}: ${errorMessage}`);
            if (currentUser) {
                 await logAuditEvent({
                    eventName: 'DOCUMENT_GENERATION_FAILED',
                    userEmail: currentUser.email,
                    details: JSON.stringify({ documentName: docName, companyName: companyName, error: errorMessage }),
                    status: 'FAILURE'
                });
            }
        } finally {
            setLoading(prevState => ({ ...prevState, [docId]: false }));
        }
    };

    const handleViewChecklist = (docId, docName) => {
        setActiveChecklist({
            docId,
            docName,
            checklist: IMPLEMENTATION_CHECKLISTS[docId] || []
        });
        setActiveTab('checklist');
    };
    
    const downloadMarkdown = async () => {
        if (!activeDocument || !activeDocument.content || activeDocument.status === 'error') return;

        if (currentUser) {
            try {
                await logAuditEvent({
                    eventName: 'DOCUMENT_DOWNLOADED',
                    userEmail: currentUser.email,
                    details: JSON.stringify({ documentName: activeDocument.name, companyName: companyName, type: 'implementation_template' }),
                    status: 'SUCCESS'
                });
                toast.success("Download logged to audit trail.");
            } catch (auditError) {
                console.error("Failed to log download event:", auditError);
                toast.error("Could not log download to audit trail.");
            }
        }

        const blob = new Blob([activeDocument.content], { type: 'text/markdown;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `${activeDocument.name.replace(/ /g, '_')}_Implementation_Template.md`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
    };

    return (
        <div className="min-h-screen bg-gray-50 p-6">
            <div className="max-w-7xl mx-auto">
                <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
                    <h1 className="text-4xl font-bold text-gray-900 mb-3 flex items-center gap-3">
                        <Shield className="w-10 h-10 text-blue-600" />
                        CMMC Implementation Guide Center
                    </h1>
                    <p className="text-xl text-gray-600 mb-6">
                        Partnership Trial Recipients: Generate implementation templates and checklists to achieve real compliance.
                    </p>

                    <Alert className="mb-6 bg-yellow-50 border-yellow-200">
                        <AlertTriangle className="h-4 w-4 text-yellow-600" />
                        <AlertTitle className="text-yellow-800">Implementation First - Documentation Second</AlertTitle>
                        <AlertDescription className="text-yellow-700">
                            <strong>These are implementation guides, not final audit documents.</strong> The real value is in actually implementing the security controls described. Use these templates and checklists to build genuine compliance, then create your final audit documentation based on what you've actually deployed.
                        </AlertDescription>
                    </Alert>
                </motion.div>

                <Card className="mb-8">
                    <CardHeader className="text-center">
                        <CardTitle className="text-2xl font-bold">Organization Configuration</CardTitle>
                        <CardDescription>Enter your organization name to customize all templates and checklists.</CardDescription>
                    </CardHeader>
                    <CardContent className="max-w-xl mx-auto">
                        <div className="space-y-2">
                            <label htmlFor="companyName" className="font-medium">Organization Name</label>
                            <Input
                                id="companyName"
                                placeholder="Enter the organization name for customized templates"
                                value={companyName}
                                onChange={(e) => setCompanyName(e.target.value)}
                            />
                        </div>
                    </CardContent>
                </Card>

                <Tabs value={activeTab} onValueChange={setActiveTab}>
                    <TabsList className="grid w-full grid-cols-3">
                        <TabsTrigger value="templates">Implementation Templates</TabsTrigger>
                        <TabsTrigger value="checklist">
                            {activeChecklist ? `${activeChecklist.docName} Checklist` : 'Implementation Checklists'}
                        </TabsTrigger>
                        <TabsTrigger value="viewer">Template Viewer</TabsTrigger>
                    </TabsList>

                    <TabsContent value="templates" className="mt-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            {CMMC_DOCUMENTS.map(doc => (
                                <DocumentCard 
                                    key={doc.id}
                                    doc={doc}
                                    onGenerate={handleGenerateDocument}
                                    onViewChecklist={handleViewChecklist}
                                    loading={loading[doc.id]}
                                    generatedDoc={documents[doc.id]}
                                    showImplementation={true}
                                />
                            ))}
                        </div>
                    </TabsContent>

                    <TabsContent value="checklist" className="mt-6">
                        {activeChecklist ? (
                            <ImplementationChecklist
                                docId={activeChecklist.docId}
                                docName={activeChecklist.docName}
                                checklist={activeChecklist.checklist}
                                onBack={() => {
                                    setActiveChecklist(null);
                                    setActiveTab('templates');
                                }}
                            />
                        ) : (
                            <Card>
                                <CardHeader>
                                    <CardTitle>Select a Document for Implementation Checklist</CardTitle>
                                    <CardDescription>Click "View Implementation Checklist" on any document template to see the step-by-step implementation guide.</CardDescription>
                                </CardHeader>
                            </Card>
                        )}
                    </TabsContent>

                    <TabsContent value="viewer" className="mt-6">
                        <Card className="sticky top-20">
                            <CardHeader>
                                <div className="flex justify-between items-center">
                                    <CardTitle>
                                        {activeDocument?.status === 'error' && <AlertTriangle className="w-5 h-5 inline-block mr-2 text-red-500"/>}
                                        {activeDocument?.name || 'Implementation Template Viewer'}
                                    </CardTitle>
                                    {activeDocument && activeDocument.status === 'generated' && (
                                        <Button variant="outline" onClick={downloadMarkdown}>
                                            <Download className="w-4 h-4 mr-2" /> Download Implementation Template
                                        </Button>
                                    )}
                                </div>
                            </CardHeader>
                            <CardContent className="h-[75vh] overflow-y-auto border rounded-lg p-4 bg-white">
                                {activeDocument ? (
                                    <ReactMarkdown className="prose prose-sm max-w-none">
                                        {activeDocument.content}
                                    </ReactMarkdown>
                                ) : (
                                    <div className="text-center text-gray-500 flex flex-col items-center justify-center h-full">
                                        <Info className="w-12 h-12 mb-4" />
                                        <h3 className="text-lg font-semibold">Generate an implementation template to view it here.</h3>
                                        <p>Templates provide the strategic framework - your job is to implement the actual controls.</p>
                                    </div>
                                )}
                            </CardContent>
                        </Card>
                    </TabsContent>
                </Tabs>
            </div>
        </div>
    );
}