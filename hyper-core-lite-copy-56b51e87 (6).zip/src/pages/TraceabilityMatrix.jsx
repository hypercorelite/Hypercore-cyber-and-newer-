import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CheckCircle, XCircle, Clock, Link as LinkIcon, FileText } from 'lucide-react';
import { motion } from "framer-motion";
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";

const initialControls = [
    { id: 'AC.L2-3.1.1', domain: 'Access Control', description: 'Limit system access to authorized users.', status: 'Implemented', evidence: 'SSO Logs', policy: 'Access Control Policy v1.2' },
    { id: 'AC.L2-3.1.3', domain: 'Access Control', description: 'Control the flow of CUI.', status: 'Partially Implemented', evidence: 'Firewall Rules', policy: 'Access Control Policy v1.2' },
    { id: 'AU.L2-3.3.1', domain: 'Audit and Accountability', description: 'Create and retain system audit logs and records.', status: 'Not Implemented', evidence: 'None', policy: 'Audit Policy (Draft)' },
    { id: 'SC.L2-3.13.1', domain: 'System and Communications Protection', description: 'Monitor, control, and protect communications.', status: 'Implemented', evidence: 'IDS/IPS Alerts', policy: 'SC Policy v1.0' },
    { id: 'IR.L2-3.6.1', domain: 'Incident Response', description: 'Establish an operational incident-handling capability.', status: 'Partially Implemented', evidence: 'IR Plan v0.8', policy: 'IR Policy v1.0' },
];

const statusConfig = {
    'Implemented': { icon: CheckCircle, color: 'text-green-600', badge: 'bg-green-100 text-green-800' },
    'Partially Implemented': { icon: Clock, color: 'text-yellow-600', badge: 'bg-yellow-100 text-yellow-800' },
    'Not Implemented': { icon: XCircle, color: 'text-red-600', badge: 'bg-red-100 text-red-800' }
};

export default function TraceabilityMatrix() {
    const [controls] = useState(initialControls);

    return (
        <div className="space-y-6">
            <BreadcrumbNav currentPageName="TraceabilityMatrix" />
            <div className="text-center">
                <h1 className="text-3xl font-bold">CMMC Traceability Matrix</h1>
                <p className="text-lg text-gray-600">Map NIST SP 800-171 controls to policies and evidence for audit readiness.</p>
            </div>

            <Card>
                <CardHeader>
                    <CardTitle>DFARS Compliance Traceability</CardTitle>
                    <CardDescription>This matrix provides a clear line of sight from each CMMC/NIST control to its corresponding implementation evidence and governing policy.</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="overflow-x-auto">
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Control ID</TableHead>
                                    <TableHead>Description</TableHead>
                                    <TableHead>Status</TableHead>
                                    <TableHead>Policy</TableHead>
                                    <TableHead>Evidence</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {controls.map((control, index) => {
                                    const StatusIcon = statusConfig[control.status].icon;
                                    return (
                                        <motion.tr 
                                            key={control.id}
                                            initial={{ opacity: 0, y: -10 }}
                                            animate={{ opacity: 1, y: 0 }}
                                            transition={{ delay: index * 0.05 }}
                                            className="hover:bg-gray-50"
                                        >
                                            <TableCell className="font-mono text-xs font-semibold">{control.id}</TableCell>
                                            <TableCell className="text-sm max-w-xs">{control.description}</TableCell>
                                            <TableCell>
                                                <Badge className={`${statusConfig[control.status].badge} flex items-center gap-1.5`}>
                                                    <StatusIcon className={`w-3.5 h-3.5 ${statusConfig[control.status].color}`} />
                                                    {control.status}
                                                </Badge>
                                            </TableCell>
                                            <TableCell className="text-sm">
                                                <Button variant="link" className="p-0 h-auto text-blue-600">
                                                    <FileText className="w-3.5 h-3.5 mr-1" />
                                                    {control.policy}
                                                </Button>
                                            </TableCell>
                                            <TableCell>
                                                <Button variant="link" className="p-0 h-auto text-blue-600">
                                                    <LinkIcon className="w-3.5 h-3.5 mr-1" />
                                                    {control.evidence}
                                                </Button>
                                            </TableCell>
                                        </motion.tr>
                                    );
                                })}
                            </TableBody>
                        </Table>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}