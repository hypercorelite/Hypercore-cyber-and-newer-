import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, Target, Rocket, Calendar, DollarSign, Users, Shield, TrendingUp } from 'lucide-react';
import { motion } from "framer-motion";

const strategicPriorities = [
    {
        phase: "Immediate Actions (Next 30 Days)",
        icon: Rocket,
        color: "bg-red-50 border-red-200",
        items: [
            {
                action: "Legal Foundation Setup",
                priority: "CRITICAL",
                description: "Based on the regulatory analysis, ensure your MSA explicitly references 32 CFR Part 170 and DFARS clauses 252.204-7012, 252.204-7021.",
                timeline: "Week 1-2",
                cost: "$2,000-5,000"
            },
            {
                action: "Professional Liability Insurance",
                priority: "CRITICAL", 
                description: "The analysis confirms E&O insurance is non-negotiable. Get quotes specifically mentioning CMMC preparation services.",
                timeline: "Week 2-3",
                cost: "$1,500-4,000/year"
            },
            {
                action: "Market Positioning Refinement",
                priority: "HIGH",
                description: "Update all marketing to emphasize your 'TurboTax for CMMC' positioning and conflict-of-interest-free advantage.",
                timeline: "Week 3-4",
                cost: "Time investment"
            }
        ]
    },
    {
        phase: "Market Entry (Days 30-90)",
        icon: Target,
        color: "bg-blue-50 border-blue-200", 
        items: [
            {
                action: "SMB-Focused Lead Generation",
                priority: "HIGH",
                description: "Target the 73% SMB market segment. Create specific campaigns for manufacturers, IT services, and engineering firms.",
                timeline: "Month 2",
                cost: "$500-1,500/month"
            },
            {
                action: "Partnership Development",
                priority: "MEDIUM",
                description: "Partner with MSPs, cyber insurance brokers, and GRC SaaS providers who serve SMBs but lack CMMC expertise.",
                timeline: "Month 2-3",
                cost: "Time + revenue sharing"
            },
            {
                action: "Content Authority Building",
                priority: "HIGH", 
                description: "Create educational content about the Q3 2025 rollout timeline. Position as the SMB CMMC expert.",
                timeline: "Ongoing",
                cost: "Time investment"
            }
        ]
    },
    {
        phase: "Scale & Optimize (Days 90-180)",
        icon: TrendingUp,
        color: "bg-green-50 border-green-200",
        items: [
            {
                action: "AI Automation Enhancement",
                priority: "MEDIUM",
                description: "Based on client feedback, automate the most common SMB scenarios (basic manufacturing, simple IT services).",
                timeline: "Month 4-6",
                cost: "Development time"
            },
            {
                action: "Recurring Revenue Streams",
                priority: "HIGH",
                description: "Offer annual affirmation prep and triennial assessment prep as ongoing services.",
                timeline: "Month 4-5", 
                cost: "Minimal - service expansion"
            },
            {
                action: "Geographic Expansion",
                priority: "LOW",
                description: "Once proven locally, expand to other defense contractor hubs (Colorado Springs, Huntsville, etc.).",
                timeline: "Month 6+",
                cost: "Marketing investment"
            }
        ]
    }
];

const marketOpportunities = [
    {
        opportunity: "Early Mover Advantage",
        description: "Q3 2025 rollout means you have 6-12 months to establish market position before competitors flood in.",
        value: "$500K-2M potential revenue",
        timeframe: "Next 18 months"
    },
    {
        opportunity: "SMB Education Gap", 
        description: "SBA research shows most SMBs don't understand CMMC requirements. Massive education opportunity.",
        value: "Market leadership positioning",
        timeframe: "Ongoing"
    },
    {
        opportunity: "Insurance Partnership",
        description: "Cyber insurance premiums are rising. Partner with carriers to offer compliance prep + discounted premiums.",
        value: "Revenue sharing + client acquisition",
        timeframe: "Month 2-4"
    }
];

export default function StrategicPriorityRoadmap() {
    return (
        <div className="space-y-8 p-4 sm:p-6 lg:p-8">
            <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center"
            >
                <Badge className="mb-4 bg-green-100 text-green-800">VALIDATED MARKET OPPORTUNITY</Badge>
                <h1 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-3">
                    Strategic Priority Roadmap
                </h1>
                <p className="text-lg lg:text-xl text-gray-600 max-w-4xl mx-auto">
                    Based on comprehensive CMMC market analysis: 220,000 organizations need compliance, 73% are SMBs, and the phased rollout begins Q3 2025. Here's your execution plan.
                </p>
            </motion.div>

            <Alert className="bg-blue-50 border-blue-200">
                <Target className="h-4 w-4 text-blue-700" />
                <AlertTitle className="text-blue-800 font-bold">Market Timing is Critical</AlertTitle>
                <AlertDescription className="text-blue-700">
                    <div className="space-y-2 mt-2">
                        <p><strong>December 2024:</strong> CMMC Final Rule effective</p>
                        <p><strong>Q1 2025:</strong> C3PAO assessments now available</p>
                        <p><strong>Q3 2025:</strong> Phased rollout begins - this is your window</p>
                        <p><strong>December 2027:</strong> Full implementation required</p>
                    </div>
                </AlertDescription>
            </Alert>

            <div className="space-y-8">
                {strategicPriorities.map((phase, index) => (
                    <motion.div
                        key={index}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.2 }}
                    >
                        <Card className={phase.color}>
                            <CardHeader>
                                <CardTitle className="flex items-center gap-3">
                                    <phase.icon className="w-6 h-6" />
                                    {phase.phase}
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-4">
                                    {phase.items.map((item, i) => (
                                        <div key={i} className="border-l-4 border-l-gray-300 pl-4">
                                            <div className="flex justify-between items-start mb-2">
                                                <h4 className="font-semibold text-gray-900">{item.action}</h4>
                                                <Badge variant={item.priority === 'CRITICAL' ? 'destructive' : item.priority === 'HIGH' ? 'default' : 'secondary'}>
                                                    {item.priority}
                                                </Badge>
                                            </div>
                                            <p className="text-sm text-gray-600 mb-2">{item.description}</p>
                                            <div className="flex justify-between text-xs text-gray-500">
                                                <span><strong>Timeline:</strong> {item.timeline}</span>
                                                <span><strong>Investment:</strong> {item.cost}</span>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>
                    </motion.div>
                ))}
            </div>

            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                        <DollarSign className="w-6 h-6 text-green-600" />
                        High-Value Market Opportunities
                    </CardTitle>
                    <CardDescription>
                        Key opportunities validated by the market analysis
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {marketOpportunities.map((opp, index) => (
                            <div key={index} className="border border-gray-200 rounded-lg p-4">
                                <h4 className="font-semibold text-gray-900 mb-2">{opp.opportunity}</h4>
                                <p className="text-sm text-gray-600 mb-3">{opp.description}</p>
                                <div className="text-xs text-gray-500">
                                    <div className="mb-1"><strong>Value:</strong> {opp.value}</div>
                                    <div><strong>Timeframe:</strong> {opp.timeframe}</div>
                                </div>
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>

            <Alert className="bg-green-50 border-green-200">
                <CheckCircle className="h-4 w-4 text-green-700" />
                <AlertTitle className="text-green-800 font-bold">Strategic Validation Complete</AlertTitle>
                <AlertDescription className="text-green-700">
                    <div className="mt-2 space-y-1">
                        <p>✅ <strong>Market Need Confirmed:</strong> 220,000 orgs need CMMC, 73% are SMBs</p>
                        <p>✅ <strong>Competitive Positioning Validated:</strong> Clear gap between consulting and SaaS</p>
                        <p>✅ <strong>Regulatory Clarity:</strong> Your conflict-free model is explicitly advantageous</p>
                        <p>✅ <strong>Timing is Perfect:</strong> 6-12 months to establish before competitors</p>
                        <p>✅ <strong>Revenue Potential:</strong> $78+ billion in SMB DoD contracts available</p>
                    </div>
                </AlertDescription>
            </Alert>
        </div>
    );
}