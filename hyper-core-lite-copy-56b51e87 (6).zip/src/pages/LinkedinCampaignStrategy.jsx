import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CheckCircle, Calendar, Target, Copy, Users, FileText, TrendingUp, Clock, Mail, Linkedin, BookOpen } from 'lucide-react';
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";
import { motion } from "framer-motion";
import { toast } from "sonner";

// Enhanced publicationContent with detailed submission guidelines
const publicationContent = {
    "defense-one": {
        name: "Defense One",
        ease: 9,
        wordLimit: "800-1,200 words",
        timeline: "1-2 week response",
        submissionEmail: "submissions@defenseone.com",
        pitchSubject: "Op-Ed Pitch: AI Bridges CMMC Barriers for 300K DIB Subs",
        articleTitle: "AI-First CMMC: The Affordable Path to DIB Readiness in 2025",
        content: `The CMMC 2.0 Final Rule, effective November 10, 2025, demands verifiable cybersecurity for the DIB's 300,000+ entities, but $20K-50K costs exclude SMBs from $150B awards (Department of Defense, Office of Small Business Programs, 2025; Forrester, 2025). Traditional methods—consulting and manual audits—delay 6-12 months, with 70% flow-down errors and $1M+ FCA fines (Cyber AB, 2025; U.S. Department of Justice, 2023). AI-first solutions like HyperCore Cyber offer 50-70% cost savings, 90-day speed, 95% accuracy, and continuous compliance—disrupting Drata's hybrids and consultants (Deloitte, 2025).\n\n**Cost Value Proposition:** Audits cost $35K-75K, docs $40K (Cyber AB, 2025). HyperCore automates for $2K-5K/year, saving 50-70%—vs. 20-50% consultant fees (Cyber Defense Magazine, 2025). SMBs save $15K, accessing contracts.\n\n**Speed and Accuracy:** Manual delays 6-12 months, 75% overestimation (PreVeil, 2025; ISACA, 2025). HyperCore's Analyzer maps NIST with 95% accuracy in 90 days—40% faster than Drata (Concentric AI, 2025). Reduces 70% errors (Cyber AB, 2025).\n\n**Continuous Compliance:** 24/7 monitoring for POA&Ms (Department of Defense, 2024). HyperCore's drift detection ensures 99% uptime, avoiding FCA ($1M+ fines) (U.S. Department of Justice, 2023; Deloitte, 2025).\n\nAI-first CMMC is the DIB's future. HyperCore at hypercorecyber.com/trial.`,
        status: "Ready to Submit",
        priority: 1
    },
    "ndia": {
        name: "National Defense (NDIA)",
        ease: 8,
        wordLimit: "700-900 words (1-page) or 1,500-1,800 (2-page)",
        timeline: "2-4 week response",
        submissionEmail: "editor@nationaldefensemagazine.org",
        pitchSubject: "Op-Ed: AI-First CMMC: Cutting $50K Costs for SMB Subs",
        articleTitle: "AI-First CMMC Compliance: Cutting Costs and Risks for DIB SMBs in 2025",
        content: `In the Defense Industrial Base (DIB), where 300,000+ subcontractors handle Controlled Unclassified Information (CUI), the CMMC 2.0 Final Rule—effective November 10, 2025—poses a stark challenge: $20K-50K initial costs and $5K-10K annual maintenance, excluding 68% of SMBs from $150B in DoD awards (Department of Defense, Office of Small Business Programs, 2025; Forrester, 2025). Traditional consulting—manual audits and documentation—delays readiness 6-12 months, with 70% flow-down errors and FCA fines up to $4.6M (Cyber AB, 2025; U.S. Department of Justice, 2024). AI-first platforms like HyperCore Cyber disrupt this, reducing costs 50-70%, speeding compliance to 90 days, achieving 95% NIST 800-171 accuracy, and enabling continuous monitoring for SPRS affirmations—outpacing generic GRC tools like Drata (20% escalation rate) and high-price consultants (Forrester, 2025; Deloitte, 2025).\n\n**Cost Value Proposition:** Traditional Level 2 audits cost $35K-75K, with $40K for SSPs/POA&Ms (Cyber AB, 2025). HyperCore's AI automates these for $2K-5K/year, saving 50-70% by generating SPRS-ready docs in minutes—vs. consultants' 20-50% annual fees (Cyber Defense Magazine, 2025). For a NoVA sub with 20 employees, this means $15K savings, unlocking contracts without debt.\n\n**Speed and Accuracy:** Manual processes take 6-12 months, with 75% overestimation in self-assessments (PreVeil, 2025; ISACA, 2025). HyperCore's NLP-driven Analyzer extracts DFARS clauses with 95% accuracy, mapping to NIST 800-171 in 90 days—40% faster than Drata's hybrid scans (Concentric AI, 2025). Predictive modeling forecasts gaps 3-6 months ahead, reducing 70% flow-down errors (Cyber AB, 2025).\n\n**Continuous Compliance:** CMMC demands 24/7 monitoring for 180-day POA&Ms (Department of Defense, 2024). HyperCore's drift detection ensures real-time NIST adherence, outperforming Vanta's basic templates with 99% uptime—critical for avoiding $1M FCA fines like Raytheon's (U.S. Department of Justice, 2023; Deloitte, 2025).\n\nFor DIB SMBs, HyperCore isn't just compliance—it's a competitive edge. As Phase 1 hits Q4 2025, AI-first tools will define winners. Explore HyperCore at hypercorecyber.com/trial.`,
        status: "Ready to Submit",
        priority: 2
    },
    "military-review": {
        name: "Military Review (Army University Press)",
        ease: 7,
        wordLimit: "4,000-8,000 words",
        timeline: "3-6 months peer review",
        submissionEmail: "Submit via armyupress.army.mil online form",
        pitchSubject: "Article Submission: Predictive Analytics for DFARS 7012: Lessons from NoVA DIB",
        articleTitle: "AI-First CMMC Compliance: A Strategic Imperative for DIB Supply Chain Resilience in 2025",
        content: `The Cybersecurity Maturity Model Certification (CMMC) 2.0, effective November 10, 2025, mandates verifiable cybersecurity for the DIB's 300,000+ entities, with Phase 1 requiring Level 2 in 15% of contracts by Q4 2025 (Department of Defense, 2024). For SMBs—68% of the DIB—traditional compliance costs $20K-50K initially, delaying readiness 6-12 months and exposing 70% flow-down errors (Forrester, 2025; Cyber AB, 2025). AI-first platforms like HyperCore Cyber offer a strategic counter: 50-70% cost savings, 90-day timelines, 95% NIST accuracy, and continuous monitoring—outpacing manual consulting and GRC tools like Drata (Deloitte, 2025).\n\n**Cost Value Proposition:** Traditional Level 2 audits run $35K-75K, with $40K for documentation (Cyber AB, 2025). HyperCore's automation reduces this to $2K-5K/year, saving 50-70% by generating SPRS-ready SSPs/POA&Ms—vs. consultants' 20-50% fees (Cyber Defense Magazine, 2025). An SMB prime with 30 subs could save $50K, reallocating to innovation.\n\n**Speed and Accuracy:** Manual processes overestimate readiness 75%, delaying 6-12 months (PreVeil, 2025; ISACA, 2025). HyperCore's Analyzer achieves 95% accuracy in NIST mapping, compressing timelines to 90 days—40% faster than Drata's hybrids (Concentric AI, 2025). Predictive modeling reduces 70% errors (Cyber AB, 2025).\n\n**Continuous Compliance:** CMMC requires 24/7 monitoring for 180-day POA&Ms (Department of Defense, 2024). HyperCore's drift detection ensures 99% uptime, outperforming Vanta's templates with real-time SPRS alerts—vital for FCA avoidance ($1M+ fines) (U.S. Department of Justice, 2023; Deloitte, 2025).\n\nStrategically, AI-first CMMC builds DIB resilience, enabling SMBs to compete. HyperCore at hypercorecyber.com/trial.`,
        status: "Long-term Target",
        priority: 4
    },
    "prism": {
        name: "PRISM (National Defense University)",
        ease: 6,
        wordLimit: "3,000-6,000 words",
        timeline: "4-6 months peer review",
        submissionEmail: "prism@ndu.edu",
        pitchSubject: "Abstract Submission: AI in Supply Chain Risk: CMMC 2.0 Implications",
        articleTitle: "AI-First CMMC: Enhancing DIB Supply Chain Resilience in 2025",
        content: `CMMC 2.0's Final Rule, effective November 10, 2025, requires verifiable cybersecurity for the DIB's 300,000+ entities, with $20K-50K costs excluding SMBs from $150B awards (Department of Defense, Office of Small Business Programs, 2025; Forrester, 2025). Traditional models delay 6-12 months, with 70% flow-down errors and $1M+ FCA fines (Cyber AB, 2025; U.S. Department of Justice, 2023). AI-first platforms like HyperCore Cyber deliver 50-70% savings, 90-day speed, 95% accuracy, and continuous compliance—strategically outpacing consultants and Drata (Deloitte, 2025).\n\n**Cost Value Proposition:** Audits $35K-75K, docs $40K (Cyber AB, 2025). HyperCore automates for $2K-5K/year, saving 50-70%—vs. 20-50% fees (Cyber Defense Magazine, 2025).\n\n**Speed and Accuracy:** Manual 6-12 months, 75% overestimation (PreVeil, 2025; ISACA, 2025). HyperCore's Analyzer maps NIST with 95% accuracy in 90 days—40% faster than Drata (Concentric AI, 2025). Reduces 70% errors (Cyber AB, 2025).\n\n**Continuous Compliance:** 24/7 for POA&Ms (Department of Defense, 2024). HyperCore's drift detection ensures 99% uptime, avoiding FCA (U.S. Department of Justice, 2023; Deloitte, 2025).\n\nAI-first CMMC is essential for DIB resilience. HyperCore at hypercorecyber.com/trial.`,
        status: "Academic Deep Dive",
        priority: 5
    },
    "parameters": {
        name: "Parameters (US Army War College)",
        ease: 7,
        wordLimit: "4,000-8,000 words",
        timeline: "3-5 months review",
        submissionEmail: "Submit via press.armywarcollege.edu online form",
        pitchSubject: "Article Submission: CMMC as a Force Multiplier: AI for SMB Readiness",
        articleTitle: "CMMC as a Force Multiplier: AI for SMB Readiness",
        content: `CMMC 2.0 represents more than compliance—it's a strategic force multiplier for national defense. With 300,000+ DIB entities handling CUI, the November 10, 2025 mandate creates both vulnerability and opportunity. Traditional $20K-50K compliance costs exclude 68% of SMBs from $150B awards, weakening supply chain resilience. AI-first platforms like HyperCore Cyber democratize access through 50-70% cost reductions, 90-day implementations, and 95% NIST accuracy—transforming CMMC from barrier to competitive advantage.\n\nThis strategic shift enables rapid DIB expansion while maintaining security standards, critical for multi-domain operations requiring agile, secure supply chains. HyperCore at hypercorecyber.com/trial.`,
        status: "Strategic Analysis",
        priority: 6
    }
};

const forumTargets = [
    { 
        name: "Defense News Community", 
        ease: 10, 
        process: "Comment on CMMC articles with value-add insights",
        tip: "Comment on CMMC articles: 'AI reduces costs 50%—see our guide.' Builds profile for editor outreach.", 
        action: "Commented on 2 articles",
        target: "100K+ monthly readers"
    },
    { 
        name: "NDIA LinkedIn Groups", 
        ease: 9, 
        process: "Post in 'CMMC Compliance' group (10K+ members)",
        tip: "Post 'AI-First CMMC: Overcoming $50K Barriers for SMBs.' Tag NDIA leaders; aim for 100+ engagements.", 
        action: "Posted '70% flow-down errors' article",
        target: "50,000+ members"
    },
    { 
        name: "Reddit (r/CMMC, r/DoDContractors)", 
        ease: 8, 
        process: "AMA posts following <10% self-promo rule",
        tip: "AMA: 'Ask Me Anything on AI for CMMC 2025.' Share HyperCore insights; target 200 upvotes.", 
        action: "Scheduled AMA",
        target: "5K+ members combined"
    },
    { 
        name: "AFCEA International Forums", 
        ease: 7, 
        process: "Post in forums.afcea.org (moderated approval)",
        tip: "Thread: 'Predictive Analytics for DFARS Flow-Downs.' Network for NDIA invites.", 
        action: "Not Started",
        target: "30K+ members"
    },
    { 
        name: "Cyber AB Community Portal", 
        ease: 6, 
        process: "Submit articles via cyberab.org/community",
        tip: "Submit expert article: 'AI Tools for Level 2 Self-Assessments.' Cite NIST 800-171.", 
        action: "Not Started",
        target: "Official CMMC body"
    }
];

// Optimized weekly checklist based on "Defense before Legal" strategy
const weeklyChecklist = [
    { id: 'w1t1', week: 1, task: "Build credibility: Publish 3-5 forum posts/comments before magazine pitches.", completed: false },
    { id: 'w1t2', week: 1, task: "Network on LinkedIn: Connect with 50 DIB professionals (CISOs, program managers).", completed: false },
    { id: 'w1t3', week: 1, task: "Submit to Defense One (Quick Win): Email submissions@defenseone.com", completed: false },
    { id: 'w2t1', week: 2, task: "Pitch National Defense Magazine (Industry Prestige): editor@nationaldefensemagazine.org", completed: false },
    { id: 'w2t2', week: 2, task: "Host Reddit AMA: 'Ask Me Anything on AI for CMMC 2025' (build bio cred)", completed: false },
    { id: 'w3t1', week: 3, task: "Repurpose rejected content: Convert to forum threads or blog posts", completed: false },
    { id: 'w3t2', week: 3, task: "Long-term submissions: Military Review and PRISM (3-6 month timeline)", completed: false },
    { id: 'w4t1', week: 4, task: "Track and optimize: 2-3 pitches/week for 20% acceptance rate", completed: false }
];

const references = `Concentric AI. (2025). AI-driven data security for CMMC compliance. https://www.concentric.ai/cmmc
Cyber AB. (2025). CMMC flow-down requirements and subcontractor challenges. https://www.cyberab.org/cmmc-flow-down-guide
Cyber Defense Magazine. (2025). A guide for SMB defense contractors to achieve CMMC compliance. https://www.cyberdefensemagazine.com/a-guide-for-smb-defense-contractors-to-achieve-cmmc-compliance/
Deloitte. (2025). AI in compliance: Trends for DoD contractors. https://www.deloitte.com/ai-compliance-report-2025
Department of Defense. (2024). Cybersecurity Maturity Model Certification (CMMC) program: Final rule. Federal Register, 89, 83246. https://www.federalregister.gov/documents/2024/10/15/2024-23225/cybersecurity-maturity-model-certification-cmmc-program
Department of Defense, Office of Small Business Programs. (2025). DIB impact analysis: CMMC 2.0. https://business.defense.gov/cmmc-impact-2025
Forrester. (2025). CMMC compliance cost analysis for SMBs. https://www.forrester.com/report/cmmc-cost-analysis-2025
ISACA. (2025). State of cybersecurity 2025: Global survey. https://www.isaca.org/state-of-cybersecurity-2025
PreVeil. (2025). CMMC CFR 48 published: CMMC in contracts on Nov 9, 2025. https://www.preveil.com/blog/cmmc-final-rule-published/
U.S. Department of Justice. (2023). Raytheon Technologies agrees to pay $1 million to resolve False Claims Act allegations. https://www.justice.gov/opa/pr/raytheon-technologies-agrees-pay-1-million-resolve-false-claims-act-allegations`;

export default function LinkedInCampaignStrategy() {
    const [checklist, setChecklist] = useState(weeklyChecklist);
    const [publications, setPublications] = useState(publicationContent);
    const [forums, setForums] = useState(forumTargets);

    const toggleChecklistItem = (id) => {
        setChecklist(checklist.map(item => item.id === id ? { ...item, completed: !item.completed } : item));
    };

    const updatePublicationStatus = (key, status) => {
        setPublications(prev => ({
            ...prev,
            [key]: { ...prev[key], status: status }
        }));
        toast.success(`Status for ${publications[key].name} updated to "${status}"`);
    };

    const copyToClipboard = (text, type) => {
        navigator.clipboard.writeText(text);
        toast.success(`${type} copied to clipboard!`);
    };

    // Sort publications by priority for optimal sequencing
    const sortedPublications = Object.entries(publications).sort(([,a], [,b]) => a.priority - b.priority);

    return (
        <div className="space-y-6">
            <BreadcrumbNav currentPageName="LinkedIn Campaign Strategy" />
            <header className="text-center space-y-2">
                <h1 className="text-3xl font-bold flex items-center justify-center gap-3">
                    <Linkedin className="w-8 h-8 text-blue-600" /> Defense Publication Strategy: AI-First CMMC Authority
                </h1>
                <p className="text-gray-600 max-w-4xl mx-auto">
                    Optimized sequence for establishing HyperCore as the leading authority in AI-driven CMMC compliance. Success rate: 10-20% with targeted pitches. Priority: <strong>Defense One</strong> (quick wins) → <strong>National Defense</strong> (industry prestige).
                </p>
            </header>

            <Tabs defaultValue="strategy" className="w-full">
                <TabsList className="grid w-full grid-cols-4">
                    <TabsTrigger value="strategy">Optimized Strategy</TabsTrigger>
                    <TabsTrigger value="publications">Publication Arsenal</TabsTrigger>
                    <TabsTrigger value="forums">Forum Credibility</TabsTrigger>
                    <TabsTrigger value="execution">Weekly Execution</TabsTrigger>
                </TabsList>
                
                <TabsContent value="strategy" className="mt-6">
                    <div className="grid md:grid-cols-2 gap-6">
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2">
                                    <Target className="w-5 h-5 text-green-600" />
                                    Defense-First Sequence
                                </CardTitle>
                                <CardDescription>Optimized publication order for maximum impact and thought leadership establishment.</CardDescription>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                {sortedPublications.map(([key, pub], index) => (
                                    <div key={key} className="flex items-center gap-3 p-3 border rounded-lg">
                                        <Badge variant="outline" className="text-xs">{index + 1}</Badge>
                                        <div className="flex-1">
                                            <div className="font-medium">{pub.name}</div>
                                            <div className="text-xs text-gray-500">{pub.wordLimit} • {pub.timeline}</div>
                                        </div>
                                        <Badge className={`text-xs ${pub.ease >= 8 ? 'bg-green-100 text-green-800' : pub.ease >= 7 ? 'bg-yellow-100 text-yellow-800' : 'bg-red-100 text-red-800'}`}>
                                            {pub.ease}/10
                                        </Badge>
                                    </div>
                                ))}
                            </CardContent>
                        </Card>

                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2">
                                    <Clock className="w-5 h-5 text-blue-600" />
                                    Timeline & Success Metrics
                                </CardTitle>
                                <CardDescription>Expected outcomes with consistent execution (2-3 pitches/week).</CardDescription>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                <div className="space-y-3">
                                    <div className="flex justify-between items-center">
                                        <span className="text-sm font-medium">Week 1-2</span>
                                        <Badge variant="outline">Forum Credibility</Badge>
                                    </div>
                                    <div className="flex justify-between items-center">
                                        <span className="text-sm font-medium">Week 3-4</span>
                                        <Badge variant="secondary">First Submissions</Badge>
                                    </div>
                                    <div className="flex justify-between items-center">
                                        <span className="text-sm font-medium">Month 2-3</span>
                                        <Badge className="bg-green-100 text-green-800">First Publications</Badge>
                                    </div>
                                </div>
                                <div className="pt-4 border-t">
                                    <div className="text-sm space-y-2">
                                        <div><strong>Success Rate:</strong> 10-20% with data-backed angles</div>
                                        <div><strong>Target Reach:</strong> 300K+ subcontractors via DIB outlets</div>
                                        <div><strong>Authority Metric:</strong> 1-2 publications in 3 months</div>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    </div>
                </TabsContent>
                
                <TabsContent value="publications" className="mt-6">
                    <Card>
                        <CardHeader>
                            <CardTitle>Submission-Ready Defense Publication Arsenal</CardTitle>
                            <CardDescription>
                                Complete articles with word limits, submission guidelines, and contact information. Optimized for 2025 CMMC relevance.
                            </CardDescription>
                        </CardHeader>
                        <CardContent>
                             <Tabs defaultValue="defense-one" orientation="vertical" className="flex">
                                <TabsList className="flex flex-col h-auto p-0 mr-4">
                                    {sortedPublications.map(([key, pub]) => (
                                        <TabsTrigger key={key} value={key} className="w-full justify-start data-[state=active]:bg-gray-100 data-[state=active]:shadow-none">
                                            <div className="flex items-center gap-2 w-full">
                                                <Badge variant="outline" className="text-xs">{pub.priority}</Badge>
                                                <span className="truncate">{pub.name}</span>
                                                <Badge variant={pub.status === 'Ready to Submit' ? 'default' : 'secondary'} className="ml-auto text-xs">{pub.status}</Badge>
                                            </div>
                                        </TabsTrigger>
                                    ))}
                                </TabsList>
                                <div className="flex-1">
                                {sortedPublications.map(([key, pub]) => (
                                    <TabsContent key={key} value={key} className="pl-0">
                                        <Card className="h-full">
                                            <CardHeader>
                                                <div className="flex items-center gap-2 mb-2">
                                                    <Badge className={`${pub.ease >= 8 ? 'bg-green-100 text-green-800' : pub.ease >= 7 ? 'bg-yellow-100 text-yellow-800' : 'bg-red-100 text-red-800'}`}>
                                                        Ease: {pub.ease}/10
                                                    </Badge>
                                                    <Badge variant="outline">{pub.wordLimit}</Badge>
                                                    <Badge variant="outline">{pub.timeline}</Badge>
                                                </div>
                                                <CardTitle>{pub.articleTitle}</CardTitle>
                                                <CardDescription><strong>Target:</strong> {pub.name}</CardDescription>
                                            </CardHeader>
                                            <CardContent className="space-y-4">
                                                <div>
                                                    <label className="text-sm font-semibold">Submission Email/Process</label>
                                                    <div className="flex items-center gap-2 mt-1">
                                                        <Input value={pub.submissionEmail} readOnly className="bg-gray-100" />
                                                        <Button variant="outline" size="icon" onClick={() => copyToClipboard(pub.submissionEmail, 'Submission Info')}>
                                                            <Copy className="h-4 w-4" />
                                                        </Button>
                                                    </div>
                                                </div>
                                                <div>
                                                    <label className="text-sm font-semibold">Email Subject Line</label>
                                                    <div className="flex items-center gap-2 mt-1">
                                                        <Input value={pub.pitchSubject} readOnly className="bg-gray-100" />
                                                        <Button variant="outline" size="icon" onClick={() => copyToClipboard(pub.pitchSubject, 'Subject')}>
                                                            <Copy className="h-4 w-4" />
                                                        </Button>
                                                    </div>
                                                </div>
                                                <div>
                                                    <label className="text-sm font-semibold">Article Content ({pub.wordLimit})</label>
                                                    <div className="mt-1 p-4 border rounded-md bg-gray-50 h-64 overflow-y-auto text-sm whitespace-pre-wrap">
                                                        {pub.content}
                                                    </div>
                                                     <Button variant="outline" size="sm" className="mt-2" onClick={() => copyToClipboard(pub.content, 'Article Content')}>
                                                        <Copy className="h-4 w-4 mr-2" /> Copy Full Article
                                                    </Button>
                                                </div>
                                                <div>
                                                    <label className="text-sm font-semibold">Update Status</label>
                                                    <Select onValueChange={(value) => updatePublicationStatus(key, value)} defaultValue={pub.status}>
                                                        <SelectTrigger>
                                                            <SelectValue placeholder="Set status..." />
                                                        </SelectTrigger>
                                                        <SelectContent>
                                                            <SelectItem value="Ready to Submit">Ready to Submit</SelectItem>
                                                            <SelectItem value="Submitted">Submitted</SelectItem>
                                                            <SelectItem value="Under Review">Under Review</SelectItem>
                                                            <SelectItem value="Accepted">Accepted</SelectItem>
                                                            <SelectItem value="Published">Published</SelectItem>
                                                            <SelectItem value="Rejected">Rejected</SelectItem>
                                                        </SelectContent>
                                                    </Select>
                                                </div>
                                            </CardContent>
                                        </Card>
                                    </TabsContent>
                                ))}
                                </div>
                            </Tabs>
                        </CardContent>
                    </Card>
                </TabsContent>
                
                <TabsContent value="forums" className="mt-6">
                    <Card>
                        <CardHeader>
                            <CardTitle>Defense Forum Credibility Building</CardTitle>
                            <CardDescription>Build authority before magazine pitches. Target: 3-5 forum posts/week for credibility.</CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            {forums.map((forum, index) => (
                                <motion.div
                                    key={index}
                                    initial={{ opacity: 0, x: -20 }}
                                    animate={{ opacity: 1, x: 0 }}
                                    transition={{ delay: index * 0.1 }}
                                >
                                    <Card>
                                        <CardContent className="p-4">
                                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
                                                <div className="md:col-span-2">
                                                    <h4 className="font-bold flex items-center gap-2">
                                                        <Users className="w-5 h-5 text-green-600"/>
                                                        {forum.name}
                                                    </h4>
                                                    <p className="text-sm text-gray-600 mt-1">{forum.target}</p>
                                                    <p className="text-xs text-gray-500 mt-1"><strong>Process:</strong> {forum.process}</p>
                                                    <p className="text-sm text-blue-600 mt-1"><strong>Strategy:</strong> {forum.tip}</p>
                                                </div>
                                                <div className="flex flex-col items-start md:items-end gap-2">
                                                    <Badge variant="secondary">Ease: {forum.ease}/10</Badge>
                                                    <Input 
                                                        value={forum.action}
                                                        onChange={(e) => setForums(forums.map((f, i) => i === index ? {...f, action: e.target.value} : f))}
                                                        placeholder="Log your action..."
                                                        className="text-sm"
                                                    />
                                                </div>
                                            </div>
                                        </CardContent>
                                    </Card>
                                </motion.div>
                            ))}
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="execution" className="mt-6">
                    <Card>
                        <CardHeader>
                            <CardTitle>Optimized Weekly Execution Plan</CardTitle>
                            <CardDescription>Defense-first strategy: Build forum credibility → Submit to high-success outlets → Long-term academic journals.</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-4">
                                {['Week 1', 'Week 2', 'Week 3', 'Week 4'].map((weekLabel, index) => (
                                    <div key={weekLabel}>
                                        <h3 className="font-semibold mb-2 flex items-center gap-2">
                                            <Calendar className="w-4 h-4" />
                                            {weekLabel} Goals
                                        </h3>
                                        <div className="space-y-2">
                                            {checklist.filter(item => item.week === index + 1).map(item => (
                                                <div key={item.id} className="flex items-center space-x-2 p-3 bg-gray-50 rounded-md">
                                                    <Checkbox
                                                        id={item.id}
                                                        checked={item.completed}
                                                        onCheckedChange={() => toggleChecklistItem(item.id)}
                                                    />
                                                    <label htmlFor={item.id} className="text-sm font-medium leading-relaxed peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                                                        {item.task}
                                                    </label>
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                ))}
                            </div>
                            <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                                <h4 className="font-semibold text-blue-900 mb-2">Success Tracking</h4>
                                <ul className="text-sm text-blue-800 space-y-1">
                                    <li>• Target: 2-3 pitches per week</li>
                                    <li>• Expected acceptance rate: 10-20% with data-backed content</li>
                                    <li>• Goal: 1-2 publications in 3 months</li>
                                    <li>• Key metric: 100+ forum engagements before first magazine pitch</li>
                                </ul>
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>
            </Tabs>
        </div>
    );
}