import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Upload, FileCheck, Link as LinkIcon, Trash2, CheckCircle, AlertTriangle } from 'lucide-react';
import { motion } from "framer-motion";
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";

const initialEvidence = [
    { id: 1, controlId: 'AC.L2-3.1.1', type: 'Log File', name: 'sso_auth_logs_q3.csv', status: 'Verified' },
    { id: 2, controlId: 'AC.L2-3.1.3', type: 'Firewall Config', name: 'palo_alto_export.xml', status: 'Pending Review' },
    { id: 3, controlId: 'IR.L2-3.6.1', type: 'Policy Document', name: 'Incident_Response_Plan_v1.pdf', status: 'Verified' },
];

export default function EvidenceCollectionTracker() {
    const [evidence, setEvidence] = useState(initialEvidence);
    const [newEvidence, setNewEvidence] = useState({ controlId: '', name: '', type: 'Log File' });

    const handleAddEvidence = () => {
        if (!newEvidence.controlId || !newEvidence.name) return;
        setEvidence([...evidence, { ...newEvidence, id: Date.now(), status: 'Pending Review' }]);
        setNewEvidence({ controlId: '', name: '', type: 'Log File' });
    };

    return (
        <div className="space-y-6">
            <BreadcrumbNav currentPageName="EvidenceCollectionTracker" />
            <div className="text-center">
                <h1 className="text-3xl font-bold">Audit Evidence Collection Tracker</h1>
                <p className="text-lg text-gray-600">Centralize and manage all documentation required for your C3PAO assessment.</p>
            </div>

            <Card>
                <CardHeader>
                    <CardTitle>Add New Evidence</CardTitle>
                </CardHeader>
                <CardContent className="flex flex-col md:flex-row gap-4">
                    <Input placeholder="Control ID (e.g., AU.L2-3.3.1)" value={newEvidence.controlId} onChange={(e) => setNewEvidence({...newEvidence, controlId: e.target.value})} />
                    <Input placeholder="Evidence Name (e.g., server_logs.zip)" value={newEvidence.name} onChange={(e) => setNewEvidence({...newEvidence, name: e.target.value})} />
                    <Button onClick={handleAddEvidence}><Upload className="w-4 h-4 mr-2"/> Add Evidence</Button>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>Collected Evidence</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    {evidence.map((item, index) => (
                        <motion.div
                            key={item.id}
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: index * 0.1 }}
                            className="p-4 border rounded-lg flex justify-between items-center"
                        >
                            <div className="flex items-center gap-4">
                                <FileCheck className="w-6 h-6 text-blue-600" />
                                <div>
                                    <p className="font-semibold">{item.name}</p>
                                    <p className="text-sm text-gray-500">Control: <Badge variant="secondary">{item.controlId}</Badge></p>
                                </div>
                            </div>
                            <div className="flex items-center gap-4">
                                <Badge variant={item.status === 'Verified' ? 'default' : 'outline'}>
                                    {item.status === 'Verified' ? <CheckCircle className="w-3 h-3 mr-1 text-green-500"/> : <AlertTriangle className="w-3 h-3 mr-1 text-yellow-500"/>}
                                    {item.status}
                                </Badge>
                                <Button variant="ghost" size="icon" onClick={() => setEvidence(evidence.filter(e => e.id !== item.id))}>
                                    <Trash2 className="w-4 h-4 text-red-500" />
                                </Button>
                            </div>
                        </motion.div>
                    ))}
                </CardContent>
            </Card>
        </div>
    );
}