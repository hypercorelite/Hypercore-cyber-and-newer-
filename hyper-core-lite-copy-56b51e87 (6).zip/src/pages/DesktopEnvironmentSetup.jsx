import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, HardDrive, Zap, Rocket, CheckCircle } from 'lucide-react';
import { motion } from 'framer-motion';
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function DesktopEnvironmentSetup() {
    return (
        <div className="space-y-8">
            <BreadcrumbNav currentPageName="DesktopEnvironmentSetup" />
            <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="text-center">
                <Badge className="mb-4 bg-gray-100 text-gray-800">NEXT STEP</Badge>
                <h1 className="text-4xl font-bold text-gray-900 mb-4 flex items-center justify-center gap-3">
                    <HardDrive className="w-8 h-8 text-gray-600" />
                    Desktop Testing Environment Setup
                </h1>
                <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                    This guide confirms the next phase of prime contractor readiness testing requires a desktop or laptop computer.
                </p>
            </motion.div>

            <Alert className="bg-blue-50 border-blue-200">
                <HardDrive className="h-4 w-4 text-blue-600" />
                <AlertTitle className="text-blue-800">Action Required: Switch to a Desktop/Laptop</AlertTitle>
                <AlertDescription className="text-blue-700">
                    The following security validation tools, **OWASP ZAP** and **Apache JMeter**, are professional-grade desktop applications. They cannot be run on a mobile phone. Please continue this process from a Windows, macOS, or Linux computer.
                </AlertDescription>
            </Alert>

            <div className="grid md:grid-cols-2 gap-8">
                {/* Penetration Testing Card */}
                <motion.div whileHover={{ scale: 1.03 }}>
                    <Card className="h-full flex flex-col">
                        <CardHeader>
                            <CardTitle className="flex items-center gap-3">
                                <Zap className="w-6 h-6 text-blue-600" />
                                1. Live Penetration Testing
                            </CardTitle>
                            <CardDescription>
                                Actively scan your live application for vulnerabilities using the industry-standard OWASP ZAP tool.
                            </CardDescription>
                        </CardHeader>
                        <CardContent className="flex-grow">
                            <p className="mb-4">Your goal is to generate a report showing **zero high or critical vulnerabilities**, providing undeniable proof of your platform's security.</p>
                            <Button asChild className="w-full">
                                <Link to={createPageUrl('LiveSecurityScanGuide')}>
                                    Go to Security Scan Guide <ArrowRight className="w-4 h-4 ml-2" />
                                </Link>
                            </Button>
                        </CardContent>
                    </Card>
                </motion.div>

                {/* Load Testing Card */}
                <motion.div whileHover={{ scale: 1.03 }}>
                     <Card className="h-full flex flex-col">
                        <CardHeader>
                            <CardTitle className="flex items-center gap-3">
                                <Rocket className="w-6 h-6 text-green-600" />
                                2. Performance & Load Testing
                            </CardTitle>
                            <CardDescription>
                                Prove your platform's scalability and resilience by simulating 1,000+ concurrent users with Apache JMeter.
                            </CardDescription>
                        </CardHeader>
                        <CardContent className="flex-grow">
                            <p className="mb-4">Your goal is to capture metrics showing **sub-200ms response times** and **99%+ uptime** under load, proving enterprise-readiness.</p>
                             <Button asChild className="w-full" variant="secondary">
                                <Link to={createPageUrl('JMeterLoadTestingGuide')}>
                                    Go to Load Testing Guide <ArrowRight className="w-4 h-4 ml-2" />
                                </Link>
                            </Button>
                        </CardContent>
                    </Card>
                </motion.div>
            </div>

            <Card className="bg-green-50 border-green-200">
                <CardHeader>
                    <CardTitle className="flex items-center gap-3 text-green-800"><CheckCircle /> You Are in the Final Validation Phase</CardTitle>
                </CardHeader>
                <CardContent>
                    <p className="text-green-700">Completing these two tests provides the final pieces of evidence required to confidently engage with prime contractors. The reports you generate will form the core of your **Prime Contractor Security Report**.</p>
                </CardContent>
            </Card>
        </div>
    );
}