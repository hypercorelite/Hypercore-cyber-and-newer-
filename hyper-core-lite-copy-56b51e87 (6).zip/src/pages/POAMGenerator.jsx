import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { FileText, Download, Bot } from 'lucide-react';
import { motion } from "framer-motion";
import BreadcrumbNav from "../components/navigation/BreadcrumbNav";
import { toast } from "sonner";

export default function POAMGenerator() {
    const [poamItems, setPoamItems] = useState([
        { control: 'AU.L2-3.3.1', weakness: 'Audit logs not consistently collected from all endpoints.', milestone: 'Deploy SIEM agent to all servers.', completionDate: '2025-11-30' },
        { control: 'AC.L2-3.1.3', weakness: 'No DLP solution to monitor CUI exfiltration.', milestone: 'Implement and configure Microsoft Purview.', completionDate: '2025-12-15' },
    ]);

    const handleGenerate = () => {
        let poamText = "Plan of Action & Milestones (POA&M)\n\n";
        poamItems.forEach(item => {
            poamText += `Control: ${item.control}\n`;
            poamText += `Weakness: ${item.weakness}\n`;
            poamText += `Milestone: ${item.milestone}\n`;
            poamText += `Scheduled Completion: ${item.completionDate}\n\n`;
        });
        
        const blob = new Blob([poamText], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = "CMMC_POAM.txt";
        a.click();
        URL.revokeObjectURL(url);
        toast.success("POA&M document generated!");
    };

    return (
        <div className="space-y-6">
            <BreadcrumbNav currentPageName="POAMGenerator" />
            <div className="text-center">
                <h1 className="text-3xl font-bold">POA&M Generator</h1>
                <p className="text-lg text-gray-600">Create your Plan of Action & Milestones for CMMC compliance gaps.</p>
            </div>
            
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2"><Bot /> AI-Suggested POA&M Items</CardTitle>
                    <CardDescription>Based on your gap analysis, here are the recommended POA&M entries. Review and edit as needed.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    {poamItems.map((item, index) => (
                        <motion.div key={index} className="p-4 border rounded-lg space-y-2 bg-gray-50"
                            initial={{ opacity: 0, y: -10 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: index * 0.1 }}
                        >
                            <Input label="Control" defaultValue={item.control} />
                            <Textarea label="Weakness Description" defaultValue={item.weakness} />
                            <Textarea label="Remediation Milestone" defaultValue={item.milestone} />
                            <Input type="date" label="Target Completion Date" defaultValue={item.completionDate} />
                        </motion.div>
                    ))}
                    <Button onClick={handleGenerate} className="w-full" size="lg">
                        <Download className="w-4 h-4 mr-2"/> Generate & Download POA&M
                    </Button>
                </CardContent>
            </Card>
        </div>
    );
}