import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip, PieChart, Pie, Cell } from "recharts";
import { ThreatAlert } from "@/api/entities";
import { SecurityIncident } from "@/api/entities";
import { 
    BarChart3, 
    PieChart as PieChartIcon, 
    TrendingUp,
    Shield,
    AlertTriangle
} from "lucide-react";
import { motion } from "framer-motion";

export default function Analytics() {
    const [threats, setThreats] = useState([]);
    const [incidents, setIncidents] = useState([]);

    useEffect(() => {
        loadData();
    }, []);

    const loadData = async () => {
        try {
            const [threatData, incidentData] = await Promise.all([
                ThreatAlert.list('-created_date', 50),
                SecurityIncident.list('-created_date', 50)
            ]);
            setThreats(threatData);
            setIncidents(incidentData);
        } catch (error) {
            console.error('Failed to load analytics data:', error);
        }
    };

    // Process threat data by type
    const threatsByType = threats.reduce((acc, threat) => {
        acc[threat.threat_type] = (acc[threat.threat_type] || 0) + 1;
        return acc;
    }, {});

    const threatTypeData = Object.entries(threatsByType).map(([type, count]) => ({
        name: type.replace('_', ' '),
        value: count
    }));

    // Process incidents by severity
    const incidentsBySeverity = incidents.reduce((acc, incident) => {
        acc[incident.severity_level] = (acc[incident.severity_level] || 0) + 1;
        return acc;
    }, {});

    const severityData = Object.entries(incidentsBySeverity).map(([severity, count]) => ({
        severity,
        count
    }));

    const COLORS = ['#ef4444', '#f97316', '#eab308', '#22c55e', '#3b82f6', '#8b5cf6'];

    return (
        <div className="min-h-screen bg-gradient-to-br from-gray-50 to-purple-50 p-6">
            <div className="max-w-7xl mx-auto">
                <motion.div
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="mb-8"
                >
                    <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
                        <BarChart3 className="w-8 h-8 text-purple-600" />
                        Security Analytics
                    </h1>
                    <p className="text-gray-600 mt-2">
                        AI-driven insights and threat intelligence
                    </p>
                </motion.div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                    <motion.div
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.2 }}
                    >
                        <Card className="bg-gradient-to-br from-red-50 to-red-100 border-red-200">
                            <CardContent className="p-6 text-center">
                                <AlertTriangle className="w-12 h-12 text-red-600 mx-auto mb-4" />
                                <div className="text-3xl font-bold text-red-600">{threats.length}</div>
                                <div className="text-red-700 font-semibold">Total Threats</div>
                            </CardContent>
                        </Card>
                    </motion.div>

                    <motion.div
                        initial={{ opacity: 0, y: -20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.3 }}
                    >
                        <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
                            <CardContent className="p-6 text-center">
                                <Shield className="w-12 h-12 text-blue-600 mx-auto mb-4" />
                                <div className="text-3xl font-bold text-blue-600">{incidents.length}</div>
                                <div className="text-blue-700 font-semibold">Security Incidents</div>
                            </CardContent>
                        </Card>
                    </motion.div>

                    <motion.div
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.4 }}
                    >
                        <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
                            <CardContent className="p-6 text-center">
                                <TrendingUp className="w-12 h-12 text-green-600 mx-auto mb-4" />
                                <div className="text-3xl font-bold text-green-600">98.7%</div>
                                <div className="text-green-700 font-semibold">AI Accuracy</div>
                            </CardContent>
                        </Card>
                    </motion.div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.5 }}
                    >
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2">
                                    <BarChart3 className="w-5 h-5 text-purple-600" />
                                    Incidents by Severity
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="h-64">
                                    <ResponsiveContainer width="100%" height="100%">
                                        <BarChart data={severityData}>
                                            <XAxis dataKey="severity" />
                                            <YAxis />
                                            <Tooltip />
                                            <Bar dataKey="count" fill="#8b5cf6" />
                                        </BarChart>
                                    </ResponsiveContainer>
                                </div>
                            </CardContent>
                        </Card>
                    </motion.div>

                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.6 }}
                    >
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2">
                                    <PieChartIcon className="w-5 h-5 text-blue-600" />
                                    Threat Types Distribution
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="h-64">
                                    <ResponsiveContainer width="100%" height="100%">
                                        <PieChart>
                                            <Pie
                                                data={threatTypeData}
                                                cx="50%"
                                                cy="50%"
                                                outerRadius={80}
                                                fill="#8884d8"
                                                dataKey="value"
                                                label
                                            >
                                                {threatTypeData.map((entry, index) => (
                                                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                                ))}
                                            </Pie>
                                            <Tooltip />
                                        </PieChart>
                                    </ResponsiveContainer>
                                </div>
                            </CardContent>
                        </Card>
                    </motion.div>
                </div>
            </div>
        </div>
    );
}