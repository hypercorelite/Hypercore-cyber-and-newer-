import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { AlertTriangle, CheckCircle, TrendingDown, TrendingUp, RefreshCw, Zap } from 'lucide-react';
import { motion } from "framer-motion";

export default function RealTimeDriftDetection() {
    const [complianceScore, setComplianceScore] = useState(87);
    const [driftAlerts, setDriftAlerts] = useState([
        {
            id: 1,
            control: "AC.L2-3.1.1",
            title: "Access Control Drift Detected",
            severity: "High",
            description: "Unauthorized privilege escalation detected on server WIN-2019-01",
            timestamp: "2 minutes ago",
            status: "Active"
        },
        {
            id: 2,
            control: "AU.L2-3.3.1",
            title: "Audit Log Gap",
            severity: "Medium", 
            description: "Missing audit logs for authentication events on DB-SERVER-03",
            timestamp: "15 minutes ago",
            status: "Investigating"
        },
        {
            id: 3,
            control: "SC.L2-3.13.1",
            title: "Encryption Configuration Changed",
            severity: "Critical",
            description: "TLS configuration modified on web server - potential CUI exposure risk",
            timestamp: "1 hour ago",
            status: "Resolved"
        }
    ]);

    const severityConfig = {
        'Critical': 'bg-red-100 text-red-800 border-red-300',
        'High': 'bg-orange-100 text-orange-800 border-orange-300',
        'Medium': 'bg-yellow-100 text-yellow-800 border-yellow-300',
        'Low': 'bg-blue-100 text-blue-800 border-blue-300'
    };

    const statusConfig = {
        'Active': 'bg-red-500',
        'Investigating': 'bg-yellow-500',
        'Resolved': 'bg-green-500'
    };

    return (
        <div className="space-y-8">
            <div className="text-center">
                <h1 className="text-3xl font-bold text-gray-900 mb-4 flex items-center justify-center gap-3">
                    <Zap className="w-8 h-8 text-blue-600" />
                    Real-Time CMMC Drift Detection
                </h1>
                <p className="text-lg text-gray-600 max-w-4xl mx-auto">
                    AI-powered continuous monitoring that detects control drift the moment it happens, not months later during an audit.
                </p>
            </div>

            <div className="grid lg:grid-cols-3 gap-6 mb-8">
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <CheckCircle className="w-5 h-5 text-green-600" />
                            Compliance Score
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="text-3xl font-bold text-green-600 mb-2">{complianceScore}%</div>
                        <Progress value={complianceScore} className="mb-2" />
                        <div className="flex items-center gap-2 text-sm text-green-600">
                            <TrendingUp className="w-4 h-4" />
                            +2% from last week
                        </div>
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <AlertTriangle className="w-5 h-5 text-orange-600" />
                            Active Alerts
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="text-3xl font-bold text-orange-600 mb-2">
                            {driftAlerts.filter(alert => alert.status === 'Active').length}
                        </div>
                        <p className="text-sm text-gray-600">Requiring immediate attention</p>
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <RefreshCw className="w-5 h-5 text-blue-600" />
                            Monitoring Status
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="text-lg font-semibold text-green-600 mb-2">All Systems Active</div>
                        <p className="text-sm text-gray-600">Last scan: 30 seconds ago</p>
                        <div className="mt-2">
                            <Badge className="bg-green-100 text-green-800">24/7 Monitoring</Badge>
                        </div>
                    </CardContent>
                </Card>
            </div>

            <Card>
                <CardHeader>
                    <CardTitle>Recent Drift Alerts</CardTitle>
                    <CardDescription>AI-detected changes to your CMMC controls in real-time</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="space-y-4">
                        {driftAlerts.map((alert, index) => (
                            <motion.div
                                key={alert.id}
                                initial={{ opacity: 0, x: -20 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ delay: index * 0.1 }}
                                className={`p-4 rounded-lg border-2 ${severityConfig[alert.severity]}`}
                            >
                                <div className="flex justify-between items-start mb-2">
                                    <div>
                                        <h3 className="font-semibold text-lg">{alert.title}</h3>
                                        <p className="text-sm opacity-75">Control: {alert.control}</p>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        <div className={`w-3 h-3 rounded-full ${statusConfig[alert.status]}`}></div>
                                        <Badge variant="outline">{alert.severity}</Badge>
                                    </div>
                                </div>
                                <p className="text-sm mb-2">{alert.description}</p>
                                <div className="flex justify-between items-center">
                                    <span className="text-xs opacity-75">{alert.timestamp}</span>
                                    <Button size="sm" variant="outline">
                                        View Details
                                    </Button>
                                </div>
                            </motion.div>
                        ))}
                    </div>
                </CardContent>
            </Card>

            <Alert className="bg-blue-50 border-blue-200">
                <Zap className="h-4 w-4 text-blue-600" />
                <AlertTitle className="text-blue-800 font-bold">Why Real-Time Monitoring Matters</AlertTitle>
                <AlertDescription className="text-blue-700">
                    Traditional compliance checks happen quarterly or annually. By then, you've been non-compliant for months, creating False Claims Act exposure. 
                    Our AI monitors every system change, configuration update, and access modification as it happens, ensuring you never drift out of compliance.
                </AlertDescription>
            </Alert>
        </div>
    );
}