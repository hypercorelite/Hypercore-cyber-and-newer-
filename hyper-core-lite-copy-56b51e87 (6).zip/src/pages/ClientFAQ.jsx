
import React, { useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { CheckCircle, Clock, Bot, MessageSquare, Mail, HelpCircle, ArrowRight } from 'lucide-react';
import { motion } from "framer-motion";
import DisclaimerBanner from '../components/legal/DisclaimerBanner';

const faqData = [
    {
        category: "Getting Started",
        questions: [
            {
                question: "How do I start my CMMC compliance journey?",
                answer: "Start with our free AI Gap Analysis. Simply click 'Start Free Trial' and upload a few basic documents about your organization. Our AI will analyze your current compliance posture against all 110 NIST 800-171 controls and provide a detailed readiness report. This process takes about 15-20 minutes and is completely free until December 5th, 2025."
            },
            {
                question: "Is this really free?",
                answer: "Yes, completely. We are seeking SBIR grant case study partners. In exchange for your feedback, you get full, unrestricted access to our platform until December 5th, 2025. You can generate your SSP, all policies, run a gap analysis, and use our automated 90-Day Success Plan. No credit card required."
            },
            {
                question: "What do I actually receive?",
                answer: "You get a complete, C3PAO-ready preparation package and the tools to implement it: 1) a complete System Security Plan (SSP), 2) all 14 required policy documents, 3) an AI-powered gap analysis and readiness score, 4) an automated 90-Day Success Plan to guide you, and 5) access to our AI Support and Knowledge Hub."
            }
        ]
    },
    {
        category: "Pricing & SBIR Partnership",
        questions: [
            {
                question: "What happens after December 5th, 2025?",
                answer: "After the free access period for our SBIR partners ends, you will have the option to subscribe to a low-cost monthly plan to maintain access to the platform, receive continuous security updates, and use our AI support system. All SBIR partners will receive preferential, locked-in pricing for life. There is no obligation to subscribe."
            },
            {
                question: "How is this different from consultants or GRC software?",
                answer: "We solve the problem differently:\n\n1.  **vs. Consultants:** We productize their expertise. Instead of paying $200/hour for manual documentation, our AI does it instantly, more accurately, and for free during the partnership period. We eliminate the time bottleneck and the cost barrier.\n\n2.  **vs. GRC Software:** GRC platforms are empty toolboxes. You still need to hire an expert to fill them with content and run them. Our platform is an expert-in-a-box; it comes pre-loaded with the knowledge and automation to do the work *for* you."
            }
        ]
    },
    {
        category: "Support & Help",
        questions: [
            {
                question: "How do I get help if I have questions?",
                answer: "We use an AI-first support model designed for fast, effective assistance:\n\n1. **AI Support (Instant)**: Our AI assistant is available 24/7 within the platform and can answer 95% of CMMC questions immediately.\n\n2. **Support Tickets**: For complex issues, create a support ticket through your client portal. Our AI will analyze your question and provide an initial response, then escalate to our expert team if needed.\n\n3. **Email Support**: For urgent matters, email us directly at support@hypercorecyber.com. We respond within 1 business day.\n\nNo phone support is provided - this keeps costs low and allows us to maintain detailed records of all support interactions."
            },
            {
                question: "What if the AI can't answer my question?",
                answer: "If our AI assistant cannot provide a complete answer to your question, it will automatically create a support ticket and escalate to our human expert team. We'll respond via email within 1 business day with a detailed answer. The AI learns from these interactions to provide better answers in the future."
            },
            {
                question: "Do you provide phone support?",
                answer: "No, we do not provide phone support. This is intentional - it allows us to:\n\n• Keep costs low and pass savings to our clients\n• Maintain detailed written records of all support interactions\n• Provide 24/7 AI assistance instead of limited phone hours\n• Scale our support to serve thousands of contractors effectively\n\nOur AI assistant + email support model provides faster, more comprehensive help than traditional phone support."
            }
        ]
    },
    {
        category: "Platform Features",
        questions: [
            {
                question: "What is the '90-Day Success Plan'?",
                answer: "It's an automated, week-by-week checklist built directly into our software. It productizes expert guidance, telling you exactly what to do to move from initial assessment to being C3PAO-ready. It's a scalable, self-service feature, not a manual consulting engagement."
            },
            {
                question: "Is this a replacement for a consultant?",
                answer: "Our platform replaces the expensive, time-consuming *documentation and planning* work of a consultant. We automate the 'what' and the 'how'. You will still be responsible for implementation within your organization, and you must hire an accredited C3PAO for your official audit. We make that process dramatically faster, cheaper, and more likely to succeed."
            }
        ]
    },
    {
        category: "Security & Data",
        questions: [
            {
                question: "Is my data secure?",
                answer: "Yes. Security is our top priority. All data is encrypted in transit and at rest. However, we strongly recommend you use anonymized or sample data and avoid uploading actual CUI during the free trial period where possible."
            }
        ]
    }
];


export default function ClientFAQ() {
    useEffect(() => {
        document.title = "SBIR Partnership FAQ - CMMC Compliance | HyperCore";
        document.querySelector('meta[name="description"]')?.setAttribute('content',
            'Get answers about our free CMMC compliance SBIR partnership offer. Learn about pricing after the free period, how we compare to consultants, and what you get.');
    }, []);

    return (
        <div className="min-h-screen bg-white">
            <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center py-16 px-4 bg-gray-50"
            >
                <Badge className="mb-4 bg-green-100 text-green-800" variant="outline">SBIR PARTNERSHIP PROGRAM</Badge>
                <h1 className="text-4xl lg:text-5xl font-extrabold text-gray-900 mb-4 tracking-tight">
                    Frequently Asked Questions
                </h1>
                <p className="text-lg lg:text-xl text-gray-600 max-w-3xl mx-auto">
                    Everything you need to know about our CMMC automation platform and our no-cost SBIR partnership offer.
                </p>
            </motion.div>

            <div className="max-w-4xl mx-auto p-4 lg:p-8 space-y-12">

                <Alert className="bg-blue-50 border-blue-200">
                    <Clock className="h-4 w-4 text-blue-600" />
                    <AlertTitle className="text-blue-800">What Happens After December 5th?</AlertTitle>
                    <AlertDescription className="text-blue-700">
                        Our free SBIR partnership period ends. Partners will have the option to roll into a low-cost subscription with preferential pricing. All generated documents are yours to keep regardless.
                        <Link to={createPageUrl('BetaExpiration')} className="font-semibold underline hover:text-blue-800 ml-2">
                           Read the full details here.
                        </Link>
                    </AlertDescription>
                </Alert>

                <div className="space-y-12"> {/* Container for categories */}
                    {faqData.map((category, categoryIndex) => (
                        <motion.div
                            key={`category-${categoryIndex}`}
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: categoryIndex * 0.05 }}
                        >
                            <h2 className="text-3xl font-bold text-gray-900 mb-6 border-b pb-2">{category.category}</h2>
                            <div className="space-y-6"> {/* Container for questions within a category */}
                                {category.questions.map((faq, questionIndex) => (
                                    <motion.div
                                        key={`question-${categoryIndex}-${questionIndex}`}
                                        initial={{ opacity: 0, y: 20 }}
                                        animate={{ opacity: 1, y: 0 }}
                                        transition={{ delay: (categoryIndex * 0.05) + (questionIndex * 0.03) }}
                                    >
                                        <Card className="border-gray-200 hover:shadow-md transition-shadow">
                                            <CardHeader>
                                                <CardTitle className="text-lg flex items-start gap-3">
                                                    <HelpCircle className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
                                                    {faq.question}
                                                </CardTitle>
                                            </CardHeader>
                                            <CardContent>
                                                <p className="text-gray-700 leading-relaxed" style={{ whiteSpace: 'pre-wrap' }}>{faq.answer}</p>
                                            </CardContent>
                                        </Card>
                                    </motion.div>
                                ))}
                            </div>
                        </motion.div>
                    ))}
                </div>

                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.5 }}
                >
                    <Card className="bg-gray-900 text-white text-center">
                        <CardContent className="p-8 lg:p-10">
                            <h3 className="text-2xl font-bold mb-4">Ready to Solve Your CMMC Problem?</h3>
                            <p className="text-gray-300 mb-6 max-w-2xl mx-auto">
                                The best way to understand our model is to use it. Become an SBIR partner and get your personalized 90-Day Success Plan in minutes.
                            </p>
                            <div className="flex flex-col sm:flex-row gap-4 justify-center">
                                <Button asChild size="lg" className="bg-blue-600 hover:bg-blue-700">
                                    <Link to={createPageUrl('PartnershipTrial')}>
                                        Start Free Partnership <ArrowRight className="w-4 h-4 ml-2" />
                                    </Link>
                                </Button>
                                <Button asChild size="lg" variant="outline" className="border-gray-500 text-white hover:bg-gray-800">
                                    <Link to={createPageUrl('SuccessPlan')}>
                                        <CheckCircle className="w-4 h-4 mr-2" />
                                        Preview the Success Plan
                                    </Link>
                                </Button>
                            </div>
                        </CardContent>
                    </Card>
                </motion.div>

                <DisclaimerBanner />
            </div>
        </div>
    );
}
